# راه‌اندازی خودکار تست با تونل (ویندوز). اجرا: دابل‌کلیک روی start-test.bat
$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

foreach ($c in "docker","cloudflared") {
  if (-not (Get-Command $c -ErrorAction SilentlyContinue)) { Write-Host "❌ $c نصب نیست (README-TEST.md را ببینید)"; exit 1 }
}
if (-not (Test-Path .env)) { Copy-Item test-deploy/env.test .env; Write-Host "ℹ️  .env از env.test ساخته شد" }

function Get-Val($k) { $l = Select-String -Path .env -Pattern "^$k=" | Select-Object -First 1; if ($l) { $l.Line.Substring($k.Length + 1) } else { "" } }
foreach ($k in "JWT_SECRET","DB_ROOT_PASSWORD","DB_PASSWORD","BACKUP_ENCRYPTION_KEY","MFA_ENCRYPTION_KEY") {
  if ((Get-Val $k).Length -lt 32) { Write-Host "❌ $k در .env خالی یا کوتاه‌تر از ۳۲ کاراکتر است"; exit 1 }
}
if ((Get-Val "MFA_ENABLED") -ne "true") { Write-Host "⚠️  MFA_ENABLED=true نیست؛ برای تست واقعی روشنش کنید" }

$log = "test-deploy/cloudflared.log"; $out = "test-deploy/cloudflared.out.log"
Remove-Item $log,$out -ErrorAction SilentlyContinue
$p = Start-Process cloudflared -ArgumentList "tunnel","--url","http://localhost:8080" -RedirectStandardError $log -RedirectStandardOutput $out -WindowStyle Hidden -PassThru
$p.Id | Out-File test-deploy/cloudflared.pid

$url = $null
for ($i = 0; $i -lt 40 -and -not $url; $i++) {
  Start-Sleep 1
  if (Test-Path $log) { $m = Select-String -Path $log -Pattern "https://[a-z0-9-]+\.trycloudflare\.com" | Select-Object -First 1; if ($m) { $url = $m.Matches[0].Value } }
}
if (-not $url) { Write-Host "❌ آدرس تونل گرفته نشد؛ فایل $log را ببینید"; exit 1 }

$hostName = $url -replace "^https://",""
(Get-Content .env) -replace "^DOMAIN=.*", "DOMAIN=$hostName" | Set-Content .env -Encoding utf8

docker compose -f docker-compose.yml -f test-deploy/docker-compose.tunnel.yml up -d --build
Write-Host ""
Write-Host "✅ آماده شد. لینک تست:  $url"
Write-Host "   توقف: stop-test.bat"

@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0start-test.ps1"
pause

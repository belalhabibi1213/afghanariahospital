#!/usr/bin/env bash
# راه‌اندازی خودکار تست با تونل (لینوکس/مک). اجرا از هر جا:  bash test-deploy/start-test.sh
set -euo pipefail
cd "$(dirname "$0")/.."

for cmd in docker cloudflared; do
  command -v "$cmd" >/dev/null || { echo "❌ $cmd نصب نیست (README-TEST.md را ببینید)"; exit 1; }
done

[ -f .env ] || { cp test-deploy/env.test .env; echo "ℹ️  .env از env.test ساخته شد"; }

# --- بررسی کلیدها (قبل از هر کاری) ---
val() { grep -E "^$1=" .env | head -1 | cut -d= -f2-; }
for k in JWT_SECRET DB_ROOT_PASSWORD DB_PASSWORD BACKUP_ENCRYPTION_KEY MFA_ENCRYPTION_KEY; do
  v="$(val $k)"
  if [ "${#v}" -lt 32 ]; then echo "❌ $k در .env خالی یا کوتاه‌تر از ۳۲ کاراکتر است"; exit 1; fi
done
[ "$(val MFA_ENABLED)" = "true" ] || echo "⚠️  MFA_ENABLED=true نیست؛ برای تست واقعی روشنش کنید"

# --- تونل ---
LOG=test-deploy/cloudflared.log
: > "$LOG"
nohup cloudflared tunnel --url http://localhost:8080 > "$LOG" 2>&1 &
echo $! > test-deploy/cloudflared.pid

URL=""
for _ in $(seq 1 40); do
  URL="$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' "$LOG" | head -1 || true)"
  [ -n "$URL" ] && break
  sleep 1
done
[ -n "$URL" ] || { echo "❌ آدرس تونل گرفته نشد؛ فایل $LOG را ببینید"; exit 1; }

HOST="${URL#https://}"
sed -i.bak "s|^DOMAIN=.*|DOMAIN=$HOST|" .env && rm -f .env.bak

# --- اجرا ---
docker compose -f docker-compose.yml -f test-deploy/docker-compose.tunnel.yml up -d --build

echo
echo "✅ آماده شد. لینک تست:  $URL"
echo "   (اگر مدیر کل نساخته‌اید: docker compose exec backend node db/createSuperAdmin.js you@example.com \"رمز-قوی-۱۲+\" \"نام\")"
echo "   توقف: bash test-deploy/stop-test.sh"

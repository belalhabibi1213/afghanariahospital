@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0stop-test.ps1"
pause

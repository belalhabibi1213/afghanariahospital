#!/usr/bin/env bash
cd "$(dirname "$0")/.."
docker compose -f docker-compose.yml -f test-deploy/docker-compose.tunnel.yml down
[ -f test-deploy/cloudflared.pid ] && kill "$(cat test-deploy/cloudflared.pid)" 2>/dev/null; rm -f test-deploy/cloudflared.pid
echo "متوقف شد. (حذف داده‌ی تست: همان docker compose down با -v)"

Set-Location (Join-Path $PSScriptRoot "..")
docker compose -f docker-compose.yml -f test-deploy/docker-compose.tunnel.yml down
if (Test-Path test-deploy/cloudflared.pid) { Stop-Process -Id (Get-Content test-deploy/cloudflared.pid) -ErrorAction SilentlyContinue; Remove-Item test-deploy/cloudflared.pid }
Write-Host "متوقف شد."

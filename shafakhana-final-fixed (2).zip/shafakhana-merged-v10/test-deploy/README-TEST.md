# راه‌اندازی تست با تونل (Cloudflare Tunnel)

## روش سریع (خودکار)
- **ویندوز:** دابل‌کلیک روی `start-test.bat` (توقف: `stop-test.bat`)
- **لینوکس/مک:** `bash test-deploy/start-test.sh` (توقف: `bash test-deploy/stop-test.sh`)

اسکریپت خودش تونل را باز می‌کند، آدرس را در `.env` می‌گذارد، کلیدها را چک می‌کند و داکر را بالا می‌آورد؛ در پایان لینک تست را چاپ می‌کند.
فقط یک‌بار مدیر کل را بسازید (مرحله ۴ پایین). برنامهٔ تست و فرم بازخورد: `TEST-PLAN.md`.
اسکریپت ویندوز را نتوانستم اجرا کنم؛ اگر خطا داد، متنش را بفرستید.

## روش دستی (توضیح مرحله‌ها)

پیش‌نیاز: Docker Desktop روشن باشد و `cloudflared` نصب باشد
(https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/).

## ۱) آدرس تونل را بگیرید
آدرس باید **قبل از build** معلوم باشد، چون داخل فرانت ثابت می‌شود. در یک ترمینال (و بازش نگه دارید):

    cloudflared tunnel --url http://localhost:8080

در خروجی آدرسی مثل `https://abc-def-123.trycloudflare.com` می‌بینید. این ترمینال را نبندید.

## ۲) .env تست را بسازید
در ریشه‌ی پروژه (کنار docker-compose.yml):

    cp test-deploy/env.test .env

فایل `.env` را باز کنید و فقط این‌ها را درست کنید:
- `DOMAIN=` ← فقط نام میزبان آدرس تونل، **بدون** `https://` (مثلاً `abc-def-123.trycloudflare.com`)
- (`SMTP_*` و `AI_*` از `.env` خودتان در env.test گذاشته شده‌اند؛ نیازی به تغییر نیست)

## ۳) اجرا

    docker compose -f docker-compose.yml -f test-deploy/docker-compose.tunnel.yml up -d --build

بار اول چند دقیقه طول می‌کشد. بعد در مرورگر آدرس `https://...trycloudflare.com` را باز کنید.

## ۴) ساخت مدیر کل (یک‌بار)

    docker compose exec backend node db/createSuperAdmin.js you@example.com "رمز-قوی-حداقل-۱۲-کاراکتر" "نام کامل"

چون `MFA_ENABLED=true` است، در اولین ورود از شما می‌خواهد برنامه‌ی Authenticator (مثل Google Authenticator) را راه‌اندازی کنید. همین خودش تست MFA است. سپس از پنل ادمین، داکتر و بیمار تستی بسازید.

## ۵) لینک را به تسترها بدهید
همان آدرس `https://...trycloudflare.com`.

## نکته‌ها
- اگر ترمینال cloudflared بسته شود یا کامپیوتر خاموش شود، سایت قطع می‌شود.
- اگر تونل را دوباره باز کنید آدرس عوض می‌شود: `DOMAIN` را در `.env` عوض کنید و دوباره با `--build` اجرا کنید.
- لاگ‌ها: `docker compose logs -f backend`
- توقف: `docker compose -f docker-compose.yml -f test-deploy/docker-compose.tunnel.yml down`
- پاک‌کردن کامل داده‌ی تست: همان دستور بالا با `-v` اضافه.
- هیچ داده‌ی واقعی بیمار وارد نکنید.

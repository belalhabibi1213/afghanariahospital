// این import باید همیشه اولین import باشد تا process.env قبل از بارگذاری سایر ماژول‌ها آماده باشد
import "./loadEnv.js";

import express from "express";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import path from "path";
import http from "http";
import { fileURLToPath } from "url";
import authRoutes from "./routes/auth.js";
import appointmentRoutes from "./routes/appointments.js";
import doctorRoutes from "./routes/doctors.js";
import newsRoutes from "./routes/news.js";
import departmentRoutes from "./routes/departments.js";
import searchRoutes from "./routes/search.js";
import contactRoutes from "./routes/contacts.js";
import userRoutes from "./routes/users.js";
import adminRoutes from "./routes/admin.js";
import superadminRoutes from "./routes/superadmin.js";
import medicalRecordRoutes from "./routes/medicalRecords.js";
import billingRoutes from "./routes/billing.js";
import reportRoutes from "./routes/reports.js";
import chatRoutes from "./routes/chat.js";
import settingsRoutes from "./routes/settings.js";
import aiRoutes from "./routes/ai.js";
import { isAiConfigured, pingAi } from "./utils/aiProviders.js";
import healthRoutes from "./routes/health.js";
import "./db.js"; // اتصال به دیتابیس MySQL هنگام شروع سرور برقرار می‌شود
import { verifyMailer } from "./utils/mailer.js";
import { initBackupScheduler } from "./utils/backup.js";
import { initNewsScheduler } from "./utils/newsScheduler.js";
import { initLogMaintenanceScheduler } from "./utils/logMaintenance.js";
import { initAppointmentReminderScheduler } from "./utils/appointmentReminders.js";
import { CORS_ORIGINS, IS_PRODUCTION, TRUST_PROXY } from "./utils/env.js";
import { apiLimiter } from "./middleware/rateLimiters.js";
import { csrfProtection } from "./middleware/csrf.js";
import { notFoundHandler, errorHandler } from "./middleware/errorHandler.js";
import { requestLogger } from "./middleware/requestLogger.js";
import { bridgeConsole } from "./utils/logger.js";
import { initSocketServer } from "./realtime/socketServer.js";
import { getPool } from "./db.js";
import { serveUploadFromDb, syncUploadsToDb } from "./utils/uploadStore.js";
import { bootstrapSuperAdminFromEnv } from "./db/bootstrapSuperAdmin.js";
import fs from "fs";

// در production (یا LOG_FORMAT=json) همه‌ی console.* هم به لاگ JSON ساخت‌یافته (با redact) هدایت می‌شوند
bridgeConsole();

const app = express();
const PORT = process.env.PORT || 5000;
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// وقتی سرور پشت یک ریورس‌پروکسی (Nginx و ...) اجرا می‌شود، این تنظیم باعث می‌شود
// req.ip و express-rate-limit از IP واقعی کاربر (هدر X-Forwarded-For) استفاده کنند،
// نه از IP خودِ پروکسی. پیش‌فرض غیرفعال است؛ با متغیر محیطی TRUST_PROXY فعال می‌شود.
if (TRUST_PROXY !== false) {
  app.set("trust proxy", TRUST_PROXY);
}

// فشرده‌سازی gzip/brotli پاسخ‌های JSON و فایل‌های استاتیک — حجم انتقال داده را به‌طور
// محسوسی (برای پاسخ‌های متنی/JSON معمولاً ۶۰-۸۰٪) کاهش می‌دهد و سرعت بارگذاری را
// به‌خصوص روی اتصال‌های کند بهبود می‌بخشد. باید پیش از سایر میان‌افزارهای مسیر اضافه شود.
app.use(requestLogger); // شناسه‌ی درخواست + لاگ ساخت‌یافته (قبل از بقیه تا همه‌ی پاسخ‌ها را پوشش دهد)
app.use(compression());

// هدرهای امنیتی HTTP (X-Content-Type-Options، X-Frame-Options، HSTS و ...).
// contentSecurityPolicy غیرفعال است چون این سرور فقط API/JSON و فایل‌های استاتیک آپلودی
// را ارائه می‌دهد، نه صفحات HTML که CSP برایشان معنا دارد.
// crossOriginResourcePolicy روی "cross-origin" تنظیم شده تا فرانت‌اند (که روی پورت/دامنه‌ی
// دیگری اجرا می‌شود، مثل Vite روی پورت ۵۱۷۳) بتواند عکس‌های /uploads را نمایش دهد.
app.use(
  helmet({
    contentSecurityPolicy: false,
    crossOriginResourcePolicy: { policy: "cross-origin" },
  })
);

// انتقال اجباری به HTTPS — فقط زمانی فعال می‌شود که صراحتاً بخواهید (FORCE_HTTPS=true در .env)
// و NODE_ENV=production باشد؛ پیش‌فرض خاموش است تا توسعه‌ی محلی روی XAMPP/localhost (بدون
// HTTPS) خراب نشود. وقتی سرور پشت یک reverse proxy (Nginx/Caddy/Cloudflare) که خودش TLS را
// terminate می‌کند قرار دارد، این middleware با خواندن هدر X-Forwarded-Proto (که trust proxy
// بالا آن را معتبر می‌داند) درخواست HTTP را ۳۰۸ به همان آدرس با https:// هدایت می‌کند.
// هدر HSTS که helmet بالا به‌صورت پیش‌فرض اضافه می‌کند، فقط بازدیدهای بعدی را ایمن می‌کند؛
// این middleware همان اولین بازدید را هم پوشش می‌دهد.
if (IS_PRODUCTION && (process.env.FORCE_HTTPS || "").toLowerCase() === "true") {
  app.use((req, res, next) => {
    if (req.secure || req.get("x-forwarded-proto") === "https") return next();
    return res.redirect(308, `https://${req.headers.host}${req.originalUrl}`);
  });
  console.log("🔒 انتقال اجباری HTTP به HTTPS فعال است (FORCE_HTTPS=true)");
}

// CORS فقط به دامنه‌های صراحتاً مجاز (CORS_ORIGIN در .env) اجازه دسترسی می‌دهد؛ نه به همه (*).
// credentials فعال است چون نشست کاربر در یک کوکی httpOnly نگه‌داری می‌شود و مرورگر فقط وقتی آن را
// برای درخواست‌های cross-origin می‌فرستد که هم سرور credentials را مجاز کرده باشد و هم origin دقیقاً
// در فهرست باشد (با credentials هرگز نباید origin = * باشد؛ فهرست زیر همیشه صریح است).
// چون کوکی خودکار ارسال می‌شود، حمله‌ی CSRF با middleware/csrf.js (هدر X-CSRF-Token وابسته به نشست)
// و SameSite کوکی خنثی می‌شود.
app.use(
  cors({
    origin(origin, callback) {
      // درخواست‌های بدون Origin (مثل Postman یا سرور-به-سرور) رد نمی‌شوند
      if (!origin || CORS_ORIGINS.includes(origin)) {
        return callback(null, true);
      }
      // دامنه‌ی رد‌شده را در کنسول چاپ می‌کنیم تا در صورت بروز مجدد این خطا، بلافاصله معلوم
      // باشد کدام آدرس دقیق (مثلاً پورت متفاوت Vite یا 127.0.0.1 به‌جای localhost) رد شده،
      // به‌جای اینکه فقط پیام کلی «این دامنه توسط CORS مجاز نیست» را ببینیم.
      console.warn(`⚠️  CORS: درخواست از دامنه‌ی «${origin}» رد شد (در CORS_ORIGIN مجاز نیست).`);
      return callback(new Error("این دامنه توسط CORS مجاز نیست"));
    },
    credentials: true,
  })
);

// محدودیت حجم بدنه‌ی JSON برای جلوگیری از درخواست‌های حجیم/مخرب (آپلود فایل از مسیر جدای multer انجام می‌شود)
app.use(express.json({ limit: "1mb" }));

// محدودیت نرخ درخواست عمومی روی کل API (محدودیت سخت‌گیرانه‌تر برای مسیرهای احراز هویت در routes/auth.js اعمال شده)
app.use("/api", apiLimiter);

// محافظت CSRF برای درخواست‌های تغییردهنده‌ای که با کوکی نشست می‌آیند (جزئیات در middleware/csrf.js)
app.use("/api", csrfProtection);

// فایل‌های آپلودشده (مثل عکس پروفایل) از این مسیر عمومی قابل دسترسی است
// هدرهای دفاعی برای فایل‌های آپلودی (عمومی و هم‌مبدأ با API): حتی اگر پاک‌سازی SVG/تصویر دور زده شود،
// مرورگر نمی‌تواند اسکریپتی را از آن اجرا کند — CSP با `sandbox` و `default-src 'none'`، و nosniff.
// (نمایش با <img> تحت تاثیر قرار نمی‌گیرد.)
app.use("/uploads", (req, res, next) => {
  res.setHeader("Content-Security-Policy", "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Content-Disposition", "inline");
  next();
});
app.use("/uploads", express.static(path.join(__dirname, "uploads")));
// اگر فایل روی دیسک نبود (مثلاً پوشه‌ی پروژه جایگزین شده)، همان عکس از دیتابیس خوانده می‌شود
app.use("/uploads", serveUploadFromDb);

// بررسی سلامت برای مانیتورینگ/Docker/Load Balancer (قبل از محدودیت‌های /api؛ limiter اختصاصی دارد)
app.use("/health", healthRoutes);

// ---------- سرو فرانت‌اند ساخته‌شده (استقرار تک‌سرویس، مثل Render) ----------
// اگر ../frontend/dist وجود داشته باشد (بعد از npm run build در فرانت)، همین سرور فرانت را هم سرو می‌کند:
// آدرس واحد → بدون مشکل کوکی بین‌دامنه‌ای و بدون نیاز به تنظیم CORS. در توسعه‌ی محلی (بدون dist) رفتار قبلی می‌ماند.
const FRONTEND_DIST = path.join(__dirname, "..", "frontend", "dist");
const SERVE_FRONTEND = fs.existsSync(path.join(FRONTEND_DIST, "index.html"));
const FRONTEND_CSP =
  "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
  "font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob: https://images.pexels.com; " +
  "media-src 'self' blob: data:; connect-src 'self'; worker-src 'self' blob:; object-src 'none'; " +
  "base-uri 'self'; form-action 'self'; frame-ancestors 'none'";
const FRONTEND_PERMISSIONS = "camera=(self), microphone=(self), geolocation=(), payment=(), usb=()";

if (SERVE_FRONTEND) {
  app.use((req, res, next) => {
    res.setHeader("Content-Security-Policy", FRONTEND_CSP);
    res.setHeader("Permissions-Policy", FRONTEND_PERMISSIONS);
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("X-Frame-Options", "DENY");
    next();
  });
  app.use("/assets", express.static(path.join(FRONTEND_DIST, "assets"), { immutable: true, maxAge: "1y", fallthrough: false }));
  app.use(express.static(FRONTEND_DIST, { index: "index.html", maxAge: "1h" }));
  console.log("🖥️  فرانت‌اند ساخته‌شده از frontend/dist سرو می‌شود (تک‌سرویس)");
} else {
  app.get("/", (req, res) => {
    res.json({ message: "سرور شفاخانه فعال است ✅" });
  });
}

app.use("/api/auth", authRoutes);
app.use("/api/appointments", appointmentRoutes);
app.use("/api/doctors", doctorRoutes);
app.use("/api/news", newsRoutes);
app.use("/api/departments", departmentRoutes);
app.use("/api/search", searchRoutes);
app.use("/api/contacts", contactRoutes);
app.use("/api/users", userRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/superadmin", superadminRoutes);
app.use("/api/medical-records", medicalRecordRoutes);
app.use("/api/billing", billingRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/chat", chatRoutes);
app.use("/api/settings", settingsRoutes);
app.use("/api/ai", aiRoutes);

// مسیرهای SPA (مثل /dashboard) → index.html؛ فقط برای GET هایی که API/آپلود/سلامت/سوکت نیستند
if (SERVE_FRONTEND) {
  app.get(/^\/(?!api\/|uploads\/|health(?:\/|$)|socket\.io\/).*/, (req, res) => {
    res.sendFile(path.join(FRONTEND_DIST, "index.html"));
  });
}

// مسیر ناموجود (۴۰۴) و مدیریت متمرکز خطا — باید بعد از همه‌ی route ها باشند
app.use(notFoundHandler);
app.use(errorHandler);

// httpServer صراحتاً ساخته می‌شود (به‌جای app.listen مستقیم) چون Socket.IO باید به همان
// سرور HTTP خامِ زیرینِ اکسپرس متصل شود، نه به خودِ آبجکتِ app — این تغییر صرفاً مکانیکی
// است و هیچ رفتار/مسیر REST موجودی را تغییر نمی‌دهد (app.listen هم داخلاً دقیقاً همین
// کار را انجام می‌دهد). فعلاً initSocketServer فقط لایه‌ی اتصال/احرازهویت را برقرار
// می‌کند؛ هیچ رویداد signaling تماس هنوز تعریف نشده (نگاه کنید به realtime/socketServer.js)
const httpServer = http.createServer(app);
const io = initSocketServer(httpServer);

httpServer.listen(PORT, () => {
  console.log(`✅ سرور بک‌اند روی http://localhost:${PORT} اجرا شد (${IS_PRODUCTION ? "production" : "development"})`);
  verifyAiAtStartup();
  verifyMailer(); // ایمیل و پسورد گوگل/SMTP را بررسی و نتیجه را در کنسول چاپ می‌کند
  // زمان‌بندی‌ها و همگام‌سازی فقط وقتی شروع می‌شوند که دیتابیس واقعاً وصل باشد؛ در غیر این صورت
  // هر دقیقه/۱۰ دقیقه همان خطای اتصال تکرار و کنسول پر می‌شد (علت اصلی همه‌ی ❌ های پشت‌سرهم).
  getPool()
    .then(() => bootstrapSuperAdminFromEnv().catch((err) => console.error("ساخت مدیر کل اولیه ناموفق بود:", err.message)))
    .then(() => {
      initBackupScheduler(); // پشتیبان‌گیری خودکار و زمان‌بندی‌شده از دیتابیس را فعال می‌کند
      initNewsScheduler(); // انتشار خودکار اخبار زمان‌بندی‌شده را فعال می‌کند
      initAppointmentReminderScheduler(); // یادآوری خودکار نوبت‌های تایید‌شده به بیمار
      initLogMaintenanceScheduler(); // پاک‌سازی لاگ فعالیت و آرشیو لاگ حسابرسی قدیمی را (شبانه) فعال می‌کند
      // عکس‌های آپلودشده‌ی موجود روی دیسک را که هنوز در دیتابیس نیستند در آن هم ذخیره می‌کند
    })
    .then(() => syncUploadsToDb().catch((err) => console.error("همگام‌سازی عکس‌های آپلودی با دیتابیس ناموفق بود:", err.message)))
    .catch(() => {
      console.warn("⏸️  چون دیتابیس وصل نشد، زمان‌بندی‌های خودکار شروع نشدند. MySQL را روشن کنید و سرور را دوباره اجرا کنید (npm run dev).");
    });
});

// ---------------------------------------------------------------------------
// پایداری فرایند: خاموشی تمیز + خطاهای مدیریت‌نشده
// ---------------------------------------------------------------------------
// - SIGTERM / SIGINT (ری‌استارت pm2، systemd، Docker یا Ctrl+C): اتصال‌های جدید بسته می‌شوند،
//   Socket.IO و استخر اتصال دیتابیس تمیز بسته می‌شوند و بعد خروج با کد ۰.
//   اگر خاموشی ظرف ۱۰ ثانیه تمام نشود، خروج اجباری انجام می‌شود (تا فرایند معلق نماند).
// - unhandledRejection: یک Promise رهاشده (مثلاً خطای ارسال ایمیل) نباید کل سرور و همه‌ی
//   کاربران آنلاین را از دسترس خارج کند؛ فقط با جزئیات لاگ می‌شود.
// - uncaughtException: وضعیت فرایند نامعلوم است؛ لاگ می‌شود، خاموشی تمیز انجام می‌شود و با کد ۱
//   خارج می‌شود تا مدیر فرایند (pm2/systemd/Docker) آن را دوباره بالا بیاورد.
let shuttingDown = false;

async function shutdown(reason, exitCode = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n⏹️  ${reason} — در حال خاموشی تمیز سرور...`);

  const forceTimer = setTimeout(() => {
    console.error("⛔ خاموشی تمیز ظرف ۱۰ ثانیه تمام نشد؛ خروج اجباری.");
    process.exit(1);
  }, 10_000);
  forceTimer.unref();

  try {
    // io.close خودش httpServer را هم می‌بندد؛ اگر Socket.IO نبود، مستقیم httpServer بسته می‌شود
    await new Promise((resolve) => {
      const done = () => resolve();
      if (io && typeof io.close === "function") io.close(done);
      else httpServer.close(done);
      httpServer.closeIdleConnections?.();
    });
  } catch (err) {
    console.error("خطا هنگام بستن سرور HTTP/Socket:", err);
  }

  try {
    const pool = await getPool();
    await pool.end();
  } catch (err) {
    console.error("خطا هنگام بستن اتصال دیتابیس:", err);
  }

  console.log("✅ خاموشی تمیز انجام شد.");
  process.exit(exitCode);
}

process.on("SIGTERM", () => shutdown("SIGTERM"));
process.on("SIGINT", () => shutdown("SIGINT"));

process.on("unhandledRejection", (reason) => {
  console.error("⚠️ unhandledRejection (سرور ادامه می‌دهد):", reason instanceof Error ? reason.stack || reason : reason);
});

process.on("uncaughtException", (err) => {
  console.error("💥 uncaughtException:", err.stack || err);
  shutdown("uncaughtException", 1);
});


// بررسی اتصال دستیار هوشمند هنگام بالا آمدن سرور (نتیجه فقط در کنسول چاپ می‌شود)
async function verifyAiAtStartup() {
  if (!isAiConfigured()) {
    console.warn("⚠️  AI_API_KEY تنظیم نشده است؛ دستیار هوشمند غیرفعال است.");
    return;
  }
  try {
    await pingAi();
    console.log("✅ اتصال به سرویس هوش مصنوعی تایید شد؛ دستیار هوشمند فعال است.");
  } catch (err) {
    console.error(`❌ اتصال به سرویس هوش مصنوعی ناموفق بود (status=${err?.status || "-"}): ${err?.message}`);
    if (err?.network || /fetch failed|network error/i.test(err?.message || "")) {
      console.error("   سرور به گوگل نمی‌رسد (نه مشکل کلید): احتمالاً فیلتر/تحریم شبکه است. VPN/پروکسی را روشن کنید؛");
      console.error("   برای Node: در همان ترمینال قبل از اجرا  $env:HTTPS_PROXY='http://127.0.0.1:PORT'; $env:NODE_USE_ENV_PROXY='1'  (PowerShell)");
      console.error("   یا سرویس دیگری مثل Groq/OpenRouter را با AI_PROVIDER=openai تنظیم کنید.");
    }
    if (/location is not supported/i.test(err?.message || "")) {
      console.error("   ⛔ گوگل Gemini در کشور/منطقه‌ی شما (افغانستان) پشتیبانی نمی‌شود؛ مشکل از کلید نیست و با کلید تازه هم درست نمی‌شود.");
      console.error("   راه‌حل: در backend/.env سرویس سازگار با OpenAI بگذارید، مثلاً OpenRouter:");
      console.error("     AI_PROVIDER=openai  AI_BASE_URL=https://openrouter.ai/api/v1  AI_MODEL=google/gemini-2.0-flash-001  AI_API_KEY=<کلید OpenRouter>");
      console.error("   (یا Gemini را با VPN/پروکسی اجرا کنید.)");
    } else if (err?.status === 401 || err?.status === 403 || err?.status === 400) {
      console.error("   کلید AI_API_KEY را بررسی کنید (از https://aistudio.google.com/apikey یک کلید تازه بگیرید).");
    }
  }
}

import { Server } from "socket.io";
import jwt from "jsonwebtoken";
import { JWT_SECRET, CORS_ORIGINS } from "../utils/env.js";
import { findByIdRaw } from "../models/User.js";
import { findSessionByTokenId } from "../models/Session.js";
import { registerCallSignaling } from "./callSignaling.js";
import { parseCookies, AUTH_COOKIE_NAME } from "../utils/authCookies.js";

// ---------- لایه‌ی زیرساختِ Realtime (آماده‌سازی برای تماس صوتی/تصویری آینده) ----------
//
// این فایل بخشِ «PART 7-A — آماده‌سازی معماری» است: فقط یک اتصالِ Socket.IO
// احرازهویت‌شده و «اتاقِ شخصیِ» هر کاربر را برقرار می‌کند — هیچ رویدادِ مخصوصِ
// تماس (offer/answer/ICE candidate/ring/hangup و…) اینجا تعریف نشده و پیاده‌سازی
// نشده است. هدف صرفاً آماده‌کردنِ کانالِ real-time‌ایست که signaling تماس در فازِ
// بعدی (7-B) رویش سوار می‌شود.
//
// چرا Socket.IO و نه چیز دیگر؟ در کل پروژه هیچ WebSocket/Socket.IO‌ای از قبل وجود
// نداشت — گفتگوی متنی/تصویری/صوتیِ فعلی کاملاً بر پایه‌ی polling دوره‌ای (هر ۸
// ثانیه، در ChatWithDoctor.jsx/ChatWithPatients.jsx) کار می‌کند که برای پیام‌های
// معمولی کافی است اما برای تبادل offer/answer/ICE candidate در WebRTC (که باید در
// حد چند صد میلی‌ثانیه رد و بدل شود، نه هر ۸ ثانیه) مناسب نیست. پس یک کانالِ
// real-time واقعی لازم است؛ Socket.IO انتخاب شد چون: (۱) روی همان سرور HTTP/Express
// موجود سوار می‌شود بدون نیاز به پورت یا سرویسِ جداگانه، (۲) reconnect/fallback
// خودکار دارد که برای تماس صوتی/تصویری (که باید در قطعیِ موقتِ شبکه هم قابل بازیابی
// باشد) مهم است.
//
// ---------- مدل احرازهویت/دسترسی (دقیقاً هم‌راستا با requireAuth در middleware/auth.js) ----------
// چون این کانال بعداً برای دعوت به تماس/رد و بدلِ signaling استفاده می‌شود، باید
// دقیقاً همان سطحِ اعتماد به هویتِ کاربر را داشته باشد که مسیرهای REST چت دارند —
// هیچ‌کس نباید بتواند بدون یک JWT معتبر (و یک نشستِ خاتمه‌نیافته) به این کانال وصل
// شود. بنابراین در لحظه‌ی اتصال (نه بعداً):
//   ۱. JWT از socket.handshake.auth.token خوانده و با همان JWT_SECRET پروژه تایید می‌شود
//   ۲. حساب کاربر باید در دیتابیس فعال (isActive) باشد — برای هماهنگی با «غیرفعال‌سازی
//      فوریِ حساب توسط ادمین» که در requireAuth هم رعایت شده
//      (backend/middleware/auth.js)
//   ۳. اگر توکن یک jti داشته باشد، نشستِ متناظرش نباید توسط Super Admin خاتمه داده
//      شده باشد (همان بررسیِ «نشست‌ها و دستگاه‌های فعال» که در requireAuth هست)
//   ۴. فقط نقش‌های "user" (بیمار) و "doctor" (داکتر) اجازه‌ی اتصال دارند — چون این
//      کانال مخصوصِ همان ماژولِ گفتگوی خصوصیِ بیمار↔داکتر است (routes/chat.js هم
//      دقیقاً همین دو نقش را با authorize("user","doctor") مجاز می‌داند)
//
// ---------- طرحِ اتاق‌ها (Rooms) — چرا بر اساس شناسه‌ی کاربر، نه شناسه‌ی مکالمه؟ ----------
// هر سوکتِ متصل فقط به یک اتاقِ «شخصی» با نامِ user:{usersId} می‌پیوندد (usersId همان
// ستونِ users.id — دقیقاً همان مقداریست که در JWT به‌عنوان id ذخیره شده و در
// chat_conversations به‌صورت patientUserId/doctorUserId نگه‌داری می‌شود، همان‌طور که
// در sendVoiceMessage/sendMessageAttachment برای پیدا کردن گیرنده‌ی اعلان استفاده
// می‌شود). این طرح از دو جهت امن‌تر از «پیوستن به اتاقِ مکالمه‌ی X» است:
//   - سوکت در لحظه‌ی اتصال چیزی درباره‌ی مکالمه‌ها نمی‌داند؛ عضویت در یک اتاقِ
//     مکالمه‌ی خاص نیازمندِ همان بررسیِ دسترسیِ ensureConversationAccess (در
//     chatController.js) در فازِ بعدی خواهد بود که مالکیتِ مکالمه را تایید می‌کند —
//     نه صرفاً یک شناسه‌ی مکالمه که کلاینت ادعا می‌کند.
//   - یک اتاقِ شخصی برای هر کاربر، مستقل از تعداد مکالمه‌های باز، یک نقطه‌ی ورودیِ
//     ثابت برای «دعوت به تماس» فراهم می‌کند: در فازِ ۷-B، سرور پس از تاییدِ اینکه
//     تماس‌گیرنده و گیرنده واقعاً یک مکالمه‌ی مشترکِ مجاز دارند (دقیقاً همان بررسیِ
//     doctorHasPatient/ensureConversationAccess موجود)، رویدادِ دعوت را با
//     io.to(`user:${recipientUserId}`).emit(...) به همان اتاقِ شخصیِ گیرنده می‌فرستد —
//     بدون نیاز به دانستنِ socket.id گیرنده (که ممکن است چند تب/دستگاه باز داشته باشد).
//
// نکته‌ی مهم: در همین فاز (۷-A) هیچ رویدادِ سفارشی دیگری (join-call، offer، answer،
// ice-candidate، hangup و…) ثبت نشده بود — فقط اتصال، احرازهویت، و پیوستن به اتاقِ
// شخصی. این عمداً حداقلی نگه داشته شده بود تا این آماده‌سازی، به‌طور کامل مستقل از هر
// تصمیمِ آینده درباره‌ی جزییاتِ پروتکلِ signaling باشد.
//
// به‌روزرسانیِ ۷-B: اکنون رویدادهای سیگنالینگِ تماس (call:initiate/accept/reject/end)
// در فایلِ جداگانه‌ی realtime/callSignaling.js پیاده‌سازی و در «connection» زیر ثبت
// می‌شوند — همچنان بدون هیچ چیزِ مربوط به رسانه (offer/answer/ICE واقعیِ WebRTC،
// دوربین/میکروفون، رابطِ کاربری) که به فازِ بعدی موکول شده است.

let ioInstance = null;

async function authenticateSocket(socket) {
  // handshake وب‌سوکت مشمول CORS نیست؛ چون نشست در کوکی است، origin صراحتاً بررسی می‌شود تا
  // سایت دیگری نتواند با کوکی کاربر یک اتصال Socket.IO باز کند (Cross-Site WebSocket Hijacking).
  const origin = socket.handshake.headers?.origin;
  if (origin && !CORS_ORIGINS.includes(origin)) {
    throw new Error("این دامنه مجاز به اتصال نیست");
  }

  // توکن از کوکی httpOnly خوانده می‌شود؛ auth.token فقط برای کلاینت‌های غیرمرورگری/قدیمی باقی مانده
  const cookies = parseCookies(socket.handshake.headers?.cookie);
  const token = cookies[AUTH_COOKIE_NAME] || socket.handshake.auth?.token;
  if (!token) {
    throw new Error("توکن احراز هویت ارسال نشده است");
  }

  let payload;
  try {
    payload = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] });
  } catch (err) {
    throw new Error("نشست شما منقضی شده، دوباره وارد شوید");
  }

  // فقط بیمار/داکتر — دقیقاً همان نقش‌های مجاز به ماژول گفتگو (routes/chat.js)
  if (payload.role !== "user" && payload.role !== "doctor") {
    throw new Error("شما اجازه‌ی دسترسی به این بخش را ندارید");
  }

  const dbUser = await findByIdRaw(payload.id);
  if (!dbUser || !dbUser.isActive) {
    throw new Error("حساب کاربری شما غیرفعال شده است");
  }

  if (payload.jti) {
    const session = await findSessionByTokenId(payload.jti);
    if (session && session.revokedAt) {
      throw new Error("این نشست توسط مدیر کل خاتمه یافته است، دوباره وارد شوید");
    }
  }

  return payload;
}

// روی همان httpServerِ موجودِ Express سوار می‌شود (در server.js فراخوانی می‌شود).
// هیچ پورتِ تازه‌ای باز نمی‌کند و هیچ مسیرِ REST موجودی را تغییر نمی‌دهد.
export function initSocketServer(httpServer) {
  ioInstance = new Server(httpServer, {
    cors: {
      origin: CORS_ORIGINS, // همان لیستِ دامنه‌های مجازِ CORS پیکربندی REST (utils/env.js)
      credentials: true, // نشست در کوکی httpOnly است و باید همراه handshake ارسال شود
    },
    // مسیر پیش‌فرض Socket.IO ("/socket.io") عمداً تغییر نکرد تا با تنظیمات پیش‌فرض
    // کلاینت هماهنگ بماند و نیازی به پیکربندیِ اضافه در فرانت‌اند (فازِ بعدی) نباشد
  });

  ioInstance.use((socket, next) => {
    authenticateSocket(socket)
      .then((payload) => {
        socket.user = payload; // همان شکلِ req.user در مسیرهای REST: { id, email, role, jti }
        next();
      })
      .catch((err) => next(err));
  });

  ioInstance.on("connection", (socket) => {
    socket.join(`user:${socket.user.id}`);

    // PART 7-B — سیگنالینگِ تماس: فقط ثبتِ رویدادهای call:initiate/accept/reject/end
    // (بدون هیچ رسانه‌ای) روی همین اتصالِ از قبل احرازهویت‌شده. جزئیات در
    // realtime/callSignaling.js
    registerCallSignaling(ioInstance, socket);
  });

  return ioInstance;
}

// دسترسیِ سایر ماژول‌ها (در فازِ آینده، مثلاً برای ارسالِ دعوتِ تماس) به همین یک
// نمونه‌ی سراسریِ Socket.IO — بدون نیاز به پاس‌دادنِ io در هر importِ کنترلر
export function getIO() {
  return ioInstance;
}

import crypto from "crypto";
import { getConversationById } from "../models/Chat.js";
import { doctorHasCompletedPatient } from "../models/Patient.js";
import { findByIdRaw } from "../models/User.js";
import { findSessionByTokenId } from "../models/Session.js";

// ---------- PART 7-B — سیگنالینگِ تماس (فقط زیرساخت، بدون رسانه/UI) ----------
//
// این فایل روی کانالِ Socket.IOِ آماده‌شده در PART 7-A (realtime/socketServer.js)
// سوار می‌شود. آن فاز فقط یک اتصالِ احرازهویت‌شده و یک «اتاقِ شخصی» به نامِ
// user:{id} برای هر کاربر برقرار کرده بود؛ اینجا فقط ۵ رویدادِ سیگنالینگِ حداقلی
// اضافه می‌شود: شروعِ تماس، اعلانِ تماسِ ورودی، پذیرش، رد، و پایانِ تماس.
//
// عمداً پیاده نشده (طبق دستورِ کار): هیچ چیزِ مربوط به رسانه — نه offer/answer/ICE
// candidate واقعیِ WebRTC، نه دوربین/میکروفون، نه رابطِ کاربریِ تماس. این‌ها در
// فازِ بعدی، روی همین callId که اینجا ساخته می‌شود، سوار خواهند شد.
//
// ---------- چرا بدون جدولِ دیتابیسِ تازه؟ ----------
// یک تماس یک رویدادِ زودگذر و آنیِ real-time است، نه رکوردی که باید پرس‌وجو یا
// گزارش‌گیری شود (برخلاف چت که تاریخچه‌اش باید بماند). نگه‌داشتنِ وضعیتِ تماسِ در
// جریان در حافظه (یک Map ساده) دقیقاً هم‌راستا با «حداقلی نگه‌داشتنِ پیاده‌سازی» و
// «عدم ساختِ ساختارِ دیتابیسِ غیرضروری» است. اگر سرور ری‌استارت شود، تماس‌های در
// جریان (که به‌هرحال چند ثانیه‌ای هستند) به‌سادگی پاک می‌شوند — همان‌طور که برای
// signaling صوتی/تصویریِ زنده هم منطقی و قابل‌قبول است.
//
// ---------- مدلِ امنیت/دسترسی ----------
// تماس فقط بین بیمار و داکترِ همان مکالمه‌ی مجاز (chat_conversations) امکان‌پذیر
// است؛ یعنی دقیقاً همان جفتِ کاربری که از قبل، طبق doctorHasCompletedPatient (نوبتِ
// «تایید شده» یا «انجام‌شده»؛ نوبتِ «در انتظار تایید» کافی نیست)، اجازه‌ی گفتگوی متنی با هم را داشته‌اند. کلاینت هرگز به‌طور مستقیم «شناسه‌ی کاربرِ
// مقصد» نمی‌فرستد؛ فقط conversationId را می‌فرستد و سرور خودش طرفِ مقابل را از
// روی رکوردِ مکالمه (patientUserId/doctorUserId — عیناً از getConversationById)
// استخراج می‌کند. به این ترتیب یک سوکتِ متصل نمی‌تواند با ساختنِ یک عدد دلخواه،
// برای کاربرِ دیگری که هیچ مکالمه‌ای با او ندارد زنگ بزند.
//
// هر رویداد، پیش از هر کاری، هویتِ socket.user (که در PART 7-A پس از تاییدِ JWT/
// نشست/فعال‌بودنِ حساب تنظیم شده) را دوباره در برابرِ رکوردِ مکالمه بررسی می‌کند —
// نه صرفاً یک‌بار در لحظه‌ی اتصال.

// callId -> { conversationId, callerUserId, callerRole, calleeUserId, calleeRole, status }
const activeCalls = new Map();
// userId -> callId  (هر کاربر در آنِ واحد حداکثر یک تماس — جلوگیری از تماسِ هم‌پوشان)
const userActiveCall = new Map();

// ---------- PART 7-E — زمان‌سنجِ «زنگ‌خوردن» برای وضعیتِ Missed ----------
// اگر گیرنده ظرفِ این مدت نه بپذیرد و نه رد کند، تماس خودکار به‌عنوانِ
// «ازدست‌رفته» (Missed) برای تماس‌گیرنده و «پایان‌یافته» برای گیرنده بسته می‌شود.
const RING_TIMEOUT_MS = 45000;

function releaseCall(callId) {
  const call = activeCalls.get(callId);
  if (!call) return;
  if (call.ringTimer) clearTimeout(call.ringTimer);
  activeCalls.delete(callId);
  if (userActiveCall.get(call.callerUserId) === callId) userActiveCall.delete(call.callerUserId);
  if (userActiveCall.get(call.calleeUserId) === callId) userActiveCall.delete(call.calleeUserId);
}

// اطلاعاتِ حداقلیِ غیرحساس که برای نمایشِ «چه کسی زنگ می‌زند» لازم است — بدون
// ایمیل، بدون توکن، بدون هیچ فیلدِ داخلیِ دیگر
function publicPeerInfo(userId, role) {
  return { userId, role };
}

// مکالمه را می‌خواند و بررسی می‌کند که socket.user واقعاً یکی از دو طرفِ همین
// مکالمه است؛ سپس طرفِ مقابل (userId و role) را برمی‌گرداند. هم‌راستا با همان
// منطقِ ensureConversationAccess در controllers/chatController.js
async function resolveConversationPeer(socketUser, conversationId) {
  const conversation = await getConversationById(conversationId);
  if (!conversation) return { error: "مکالمه یافت نشد" };

  let selfRole, peerUserId, peerRole;
  if (socketUser.role === "user" && conversation.patientUserId === socketUser.id) {
    selfRole = "user";
    peerUserId = conversation.doctorUserId;
    peerRole = "doctor";
  } else if (socketUser.role === "doctor" && conversation.doctorUserId === socketUser.id) {
    selfRole = "doctor";
    peerUserId = conversation.patientUserId;
    peerRole = "user";
  } else {
    return { error: "شما اجازه‌ی دسترسی به این مکالمه را ندارید" };
  }

  if (!peerUserId) {
    // طرفِ مقابل هنوز هیچ حسابِ کاربریِ متصلی ندارد (مثلاً بیمارِ مهمان بدون ثبت‌نام)
    return { error: "طرفِ مقابل حسابِ کاربریِ فعالی برای تماس ندارد" };
  }

  // بررسیِ دوباره‌ی رابطه‌ی داکتر↔بیمار (نه فقط وجودِ مکالمه‌ی قدیمی) — دقیقاً همان
  // قاعده‌ای که startConversation/sendMessage در chatController.js اعمال می‌کنند: فقط
  // نوبتِ «تایید شده» یا «انجام‌شده» کافی است؛ نوبتِ «در انتظار تایید» یا لغو/رد‌شده
  // اجازه‌ی تماس نمی‌دهد (قبلاً اینجا از doctorHasPatient بدون فیلتر وضعیت استفاده
  // می‌شد که باعث می‌شد بیمار بلافاصله بعد از ثبت نوبتِ هنوز تایید‌نشده بتواند زنگ بزند)
  const related = await doctorHasCompletedPatient(conversation.doctorId, conversation.patientId);
  if (!related) return { error: "تماس فقط بعد از انجام شدن نوبت امکان‌پذیر است" };

  return { conversation, selfRole, peerUserId, peerRole };
}

// ---------- بازبینیِ زنده‌ی مجوزِ کاربر، درست پیش از هر اقدامِ حساسِ تماس ----------
// باگِ امنیتیِ کشف‌شده (PART 7-F): برخلافِ همه‌ی مسیرهای REST که با هر درخواست
// دوباره isActive و ابطالِ نشست را بررسی می‌کنند (requireAuth در
// middleware/auth.js)، اتصالِ Socket.IO فقط *یک‌بار*، در لحظه‌ی اتصال، احرازهویت
// می‌شود (authenticateSocket در realtime/socketServer.js). یک اتصالِ سوکت ممکن
// است ساعت‌ها باز بماند؛ اگر در همین فاصله ادمین حسابِ کاربر را غیرفعال کند یا
// Super Admin همان نشست را از پنلِ «نشست‌ها و دستگاه‌های فعال» خاتمه دهد، کاربر
// عملاً یک نشستِ REST نامعتبر دارد اما همچنان می‌تواند از طریقِ همان سوکتِ قدیمی
// زنگ بزند یا زنگ دریافت کند — دقیقاً همان نقضی که #۶/#۷ در دستورِ کارِ ممیزی
// هشدار می‌دهند («صرفاً به بررسیِ فرانت‌اند/لحظه‌ی اتصال متکی نبودن»).
// رفع: پیش از پردازشِ call:initiate (هم برای خودِ تماس‌گیرنده و هم، پس از یافتنِ
// طرفِ مقابل، برای همان طرفِ مقابل) و پیش از call:accept، این بررسی دوباره —
// عیناً هم‌راستا با requireAuth — انجام می‌شود.
async function isUserStillAuthorized(userPayload) {
  const dbUser = await findByIdRaw(userPayload.id);
  if (!dbUser || !dbUser.isActive) return false;
  if (userPayload.jti) {
    const session = await findSessionByTokenId(userPayload.jti);
    if (session && session.revokedAt) return false;
  }
  return true;
}

export function registerCallSignaling(io, socket) {
  const userId = socket.user.id;

  // ---------- شروعِ تماس ----------
  // به‌روزرسانیِ PART 7-D: پارامترِ اختیاریِ callType ("audio" | "video") اضافه شد
  // تا گیرنده پیش از پذیرش بداند باید علاوه بر میکروفون، دوربین هم درخواست کند.
  // این افزوده کاملاً سازگار با قبل است: نبودنِ callType (کدِ قدیمیِ تماسِ صوتی)
  // دقیقاً مثل قبل به‌صورت "audio" در نظر گرفته می‌شود — هیچ رفتاری تغییر نکرد.
  socket.on("call:initiate", async ({ conversationId, callType } = {}, ack) => {
    const reply = typeof ack === "function" ? ack : () => {};
    try {
      if (!conversationId) return reply({ ok: false, reason: "invalid", message: "شناسه‌ی مکالمه الزامی است" });
      const resolvedCallType = callType === "video" ? "video" : "audio";

      // بازبینیِ زنده‌ی خودِ تماس‌گیرنده (نه فقط لحظه‌ی اتصالِ سوکت) — رجوع به توضیحِ
      // isUserStillAuthorized بالا
      if (!(await isUserStillAuthorized(socket.user))) {
        socket.disconnect(true); // نشست/حساب دیگر معتبر نیست؛ سوکت باید دوباره وارد شود
        return reply({ ok: false, reason: "unauthorized", message: "نشست شما دیگر معتبر نیست، دوباره وارد شوید" });
      }

      if (userActiveCall.has(userId)) {
        return reply({ ok: false, reason: "self-busy", message: "شما در حالِ حاضر در یک تماسِ دیگر هستید" });
      }

      const result = await resolveConversationPeer(socket.user, conversationId);
      if (result.error) return reply({ ok: false, reason: "invalid", message: result.error });

      const { peerUserId, peerRole, selfRole } = result;

      if (userActiveCall.has(peerUserId)) {
        return reply({ ok: false, reason: "peer-busy", message: "کاربرِ مقابل در حالِ حاضر مصروف است" });
      }

      // بازبینیِ زنده‌ی طرفِ مقابل هم — ممکن است سوکتِ او از پیش وصل مانده باشد اما
      // حسابش در همین فاصله غیرفعال شده یا نشستش خاتمه یافته باشد (رجوع به توضیحِ بالا)
      if (!(await isUserStillAuthorized({ id: peerUserId }))) {
        return reply({ ok: false, reason: "offline", message: "کاربرِ مقابل درحالِ حاضر آنلاین نیست" });
      }

      // آیا طرفِ مقابل اصلاً به کانالِ سوکت وصل است؟ (بدون این بررسی، تماس در
      // «زنگ‌خوردن» گیر می‌کند بدون آن‌که کسی هرگز آن را ببیند)
      const peerRoom = io.sockets.adapter.rooms.get(`user:${peerUserId}`);
      if (!peerRoom || peerRoom.size === 0) {
        return reply({ ok: false, reason: "offline", message: "کاربرِ مقابل درحالِ حاضر آنلاین نیست" });
      }

      const callId = crypto.randomUUID();
      const callRecord = {
        callId,
        conversationId,
        callerUserId: userId,
        callerRole: selfRole,
        calleeUserId: peerUserId,
        calleeRole: peerRole,
        callType: resolvedCallType,
        status: "ringing",
      };
      activeCalls.set(callId, callRecord);
      userActiveCall.set(userId, callId);
      userActiveCall.set(peerUserId, callId);

      // ---------- PART 7-E — اگر ظرفِ RING_TIMEOUT_MS پاسخی نیامد: وضعیتِ Missed ----------
      callRecord.ringTimer = setTimeout(() => {
        const current = activeCalls.get(callId);
        if (!current || current.status !== "ringing") return; // قبلاً پذیرفته/رد/پایان‌یافته
        io.to(`user:${current.callerUserId}`).emit("call:missed", { callId });
        io.to(`user:${current.calleeUserId}`).emit("call:ended", { callId, reason: "missed" });
        releaseCall(callId);
      }, RING_TIMEOUT_MS);

      io.to(`user:${peerUserId}`).emit("call:incoming", {
        callId,
        conversationId,
        callType: resolvedCallType,
        from: publicPeerInfo(userId, selfRole),
      });

      return reply({ ok: true, callId });
    } catch (err) {
      console.error("خطا در شروعِ تماس:", err.message);
      return reply({ ok: false, reason: "server-error", message: "خطای سرور در شروعِ تماس" });
    }
  });

  // ---------- پذیرشِ تماس ----------
  socket.on("call:accept", async ({ callId } = {}, ack) => {
    const reply = typeof ack === "function" ? ack : () => {};
    const call = activeCalls.get(callId);
    if (!call || call.status !== "ringing" || call.calleeUserId !== userId) {
      return reply({ ok: false, message: "این تماس دیگر معتبر نیست" });
    }
    // بازبینیِ زنده‌ی گیرنده پیش از پذیرشِ واقعیِ تماس — رجوع به توضیحِ
    // isUserStillAuthorized بالا
    if (!(await isUserStillAuthorized(socket.user))) {
      socket.disconnect(true);
      releaseCall(callId);
      io.to(`user:${call.callerUserId}`).emit("call:ended", { callId, reason: "peer-disconnected" });
      return reply({ ok: false, message: "نشست شما دیگر معتبر نیست، دوباره وارد شوید" });
    }
    call.status = "accepted";
    // ---------- PART 7-E — با پذیرشِ تماس، دیگر نیازی به تایمرِ Missed نیست ----------
    if (call.ringTimer) {
      clearTimeout(call.ringTimer);
      call.ringTimer = null;
    }
    io.to(`user:${call.callerUserId}`).emit("call:accepted", {
      callId,
      by: publicPeerInfo(userId, call.calleeRole),
    });
    return reply({ ok: true });
  });

  // ---------- ردِ تماس ----------
  socket.on("call:reject", ({ callId } = {}, ack) => {
    const reply = typeof ack === "function" ? ack : () => {};
    const call = activeCalls.get(callId);
    if (!call || call.status !== "ringing" || call.calleeUserId !== userId) {
      return reply({ ok: false, message: "این تماس دیگر معتبر نیست" });
    }
    io.to(`user:${call.callerUserId}`).emit("call:rejected", {
      callId,
      by: publicPeerInfo(userId, call.calleeRole),
    });
    releaseCall(callId);
    return reply({ ok: true });
  });

  // ---------- پایانِ تماس (توسط هرکدام از دو طرف، قبل یا بعد از پذیرش) ----------
  socket.on("call:end", ({ callId } = {}, ack) => {
    const reply = typeof ack === "function" ? ack : () => {};
    const call = activeCalls.get(callId);
    if (!call || (call.callerUserId !== userId && call.calleeUserId !== userId)) {
      return reply({ ok: false, message: "این تماس دیگر معتبر نیست" });
    }
    const otherUserId = call.callerUserId === userId ? call.calleeUserId : call.callerUserId;
    const selfRole = call.callerUserId === userId ? call.callerRole : call.calleeRole;
    io.to(`user:${otherUserId}`).emit("call:ended", {
      callId,
      by: publicPeerInfo(userId, selfRole),
    });
    releaseCall(callId);
    return reply({ ok: true });
  });

  // ---------- رله‌ی سیگنالینگِ رسانه‌ای WebRTC (PART 7-C) ----------
  // این سه رویداد هیچ منطقِ جدیدی اضافه نمی‌کنند؛ صرفاً payloadِ offer/answer/
  // ICE candidate را بینِ دو طرفِ همان callId که بالاتر (call:initiate/accept)
  // احرازهویت و مجاز شده، رد و بدل می‌کنند. محتوای SDP/candidate هرگز توسط سرور
  // بازخوانی یا تغییر داده نمی‌شود — فقط عبور می‌کند (relay خام).
  function relayToPeer(callId, payload, eventName) {
    const call = activeCalls.get(callId);
    if (!call) return; // تماسی با این callId فعال نیست (مثلاً قبلاً پایان یافته)
    if (call.callerUserId !== userId && call.calleeUserId !== userId) return; // فرستنده جزوِ این تماس نیست
    const otherUserId = call.callerUserId === userId ? call.calleeUserId : call.callerUserId;
    io.to(`user:${otherUserId}`).emit(eventName, { callId, ...payload });
  }

  socket.on("call:offer", ({ callId, sdp } = {}) => {
    if (!callId || !sdp) return;
    relayToPeer(callId, { sdp }, "call:offer");
  });

  socket.on("call:answer", ({ callId, sdp } = {}) => {
    if (!callId || !sdp) return;
    relayToPeer(callId, { sdp }, "call:answer");
  });

  socket.on("call:ice-candidate", ({ callId, candidate } = {}) => {
    if (!callId || !candidate) return;
    relayToPeer(callId, { candidate }, "call:ice-candidate");
  });

  // ---------- قطعِ اتصالِ سوکت درحینِ تماس (بستنِ تب، افتادنِ اینترنت و...) ----------
  socket.on("disconnect", () => {
    const callId = userActiveCall.get(userId);
    if (!callId) return;
    const call = activeCalls.get(callId);
    if (!call) return;
    const otherUserId = call.callerUserId === userId ? call.calleeUserId : call.callerUserId;
    io.to(`user:${otherUserId}`).emit("call:ended", {
      callId,
      reason: "peer-disconnected",
    });
    releaseCall(callId);
  });
}

import { searchGlobal } from "../models/Search.js";

const MIN_QUERY_LENGTH = 2;
const MAX_QUERY_LENGTH = 100;

// GET /api/search?q=... — جستجوی سراسری سایت (داکتران/بخش‌ها/خدمات/تخصص‌ها/اخبار/
// مقالات/ادویه). عمومی و بدون نیاز به ورود (مثل GET /api/news، GET /api/departments)
// چون فقط محتوای عمومی/تبلیغاتی سایت را برمی‌گرداند، نه داده‌ی خصوصی بیمار/کاربر.
export async function globalSearch(req, res) {
  try {
    const q = typeof req.query.q === "string" ? req.query.q.trim() : "";

    // عبارت خالی یا خیلی کوتاه: بدون خطا، فقط دسته‌های خالی برگردان (تجربه‌ی کاربری
    // بهتر برای فرانت‌اند نسبت به 400) — دقیقاً حالتی که useGlobalSearch در فرانت‌اند
    // با query خالی هندل می‌کند.
    if (q.length < MIN_QUERY_LENGTH) {
      return res.json({
        query: q,
        doctors: [],
        departments: [],
        services: [],
        specialties: [],
        news: [],
        articles: [],
        medicines: [],
      });
    }

    if (q.length > MAX_QUERY_LENGTH) {
      return res.status(400).json({ message: "عبارت جستجو بیش از حد طولانی است." });
    }

    const groups = await searchGlobal(q);
    return res.json({ query: q, ...groups });
  } catch (err) {
    console.error("خطا در جستجوی سراسری:", err);
    return res.status(500).json({ message: "خطا در انجام جستجو. لطفاً دوباره تلاش کنید." });
  }
}

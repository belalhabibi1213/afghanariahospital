import { getAllNews, getNewsById, getNewsGallery, getRelatedAndLatestNews } from "../models/News.js";
import { countNewsLikes, hasUserLikedNews, addNewsLike, removeNewsLike, getLikedNewsIdsByUser } from "../models/NewsLike.js";
import {
  getApprovedComments,
  createComment,
  hasRecentDuplicateComment,
} from "../models/NewsComment.js";
import { sanitizeCommentText } from "../utils/sanitizeNewsContent.js";
import { registerNewsView, buildViewerKey } from "../models/NewsView.js";
import { recordAudit } from "../models/AuditLog.js";
import { createNotification } from "../models/Notification.js";
import { getAllUsers } from "../models/User.js";
import { getClientIp, getUserAgent } from "../models/ActivityLog.js";

// ثبت لاگ حسابرسی برای اعمال کاربران عادی (لایک/نظر) روی خبر — همان الگوی auditAdmin
// در adminController.js، فقط بدون نیاز به دسترسی ادمین
const auditPublic = (req, tableName, recordId, action, oldValues, newValues) =>
  recordAudit({
    req, tableName, recordId, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });

// فهرست عمومی اخبار (صفحه اصلی) — از optionalAuth استفاده می‌کند تا اگر کاربر واردشده
// باشد، وضعیت «آیا خودش لایک کرده؟» هم برای هر کارت خبر برگردانده شود (بدون این‌که برای
// مهمان‌ها خطایی رخ دهد). likesCount/commentsCount از قبل در getAllNews محاسبه شده‌اند.
export async function listNews(req, res) {
  try {
    const news = await getAllNews();
    const likedIds = req.user ? new Set(await getLikedNewsIdsByUser(req.user.id)) : null;
    const enriched = likedIds ? news.map((n) => ({ ...n, liked: likedIds.has(n.id) })) : news;
    return res.status(200).json({ news: enriched });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// یک خبر برای عموم «قابل‌مشاهده» است اگر منتشرشده باشد، یا زمان‌بندی‌شده باشد و موعدش
// رسیده باشد (همان قانونی که در models/News.js -> getAllNews برای فهرست عمومی استفاده می‌شود)
function isPubliclyVisible(article) {
  if (!article) return false;
  if (article.status === "published") return true;
  if (article.status === "scheduled" && article.scheduledAt) {
    return new Date(article.scheduledAt).getTime() <= Date.now();
  }
  return false;
}

// ---------- عمومی: دریافت یک خبر برای صفحه «ادامه مطلب» ----------
// خبرهای پیش‌نویس یا زمان‌بندی‌شده‌ای که موعدشان نرسیده، همچنان فقط از پنل ادمین قابل مشاهده‌اند.
// از optionalAuth استفاده می‌کند: کاربر مهمان هم می‌تواند خبر را ببیند، اما اگر واردشده باشد
// (req.user موجود باشد)، وضعیت «آیا خودش لایک کرده؟» هم در پاسخ برمی‌گردد.
export async function getNewsArticle(req, res) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "شناسه خبر نامعتبر است" });
    }

    const article = await getNewsById(id);
    if (!isPubliclyVisible(article)) {
      return res.status(404).json({ message: "خبر مورد نظر یافت نشد" });
    }

    // بازدیدکننده (کاربر واردشده یا مهمان) برای شمارنده‌ی بازدید بدون تکرار
    const viewerKey = buildViewerKey({
      userId: req.user?.id,
      ip: getClientIp(req),
      userAgent: getUserAgent(req),
    });

    // بهینه‌سازی عملکرد: این پرس‌وجوها به هم وابسته نیستند، پس به‌جای اجرای پیاپی
    // (یکی پس از دیگری، مثل نسخه‌ی قبلی)، با Promise.all موازی اجرا می‌شوند تا زمان
    // پاسخ سرور کاهش یابد. «اخبار مرتبط» و «آخرین اخبار» هم اینجا مستقیماً از دیتابیس
    // گرفته می‌شوند (فقط چند ستون سبک، با LIMIT) — فرانت‌اند دیگر نیازی به یک درخواست
    // جداگانه برای دریافت کل فهرست اخبار (همراه با content کامل هر خبر) ندارد.
    const [gallery, likesCount, liked, comments, relatedAndLatest, justCounted] = await Promise.all([
      getNewsGallery(id),
      countNewsLikes(id),
      req.user ? hasUserLikedNews(id, req.user.id) : Promise.resolve(false),
      getApprovedComments(id),
      getRelatedAndLatestNews(id, article.tag),
      registerNewsView(id, viewerKey),
    ]);

    return res.status(200).json({
      news: {
        ...article,
        views: (article.views || 0) + (justCounted ? 1 : 0),
        gallery,
        likesCount,
        liked,
        comments,
        related: relatedAndLatest.related,
        latest: relatedAndLatest.latest,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- لایک/برداشتن لایک خبر (فقط کاربر واردشده، حداکثر یک لایک به ازای هر کاربر) ----------
export async function toggleNewsLike(req, res) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "شناسه خبر نامعتبر است" });
    }

    const article = await getNewsById(id);
    if (!isPubliclyVisible(article)) {
      return res.status(404).json({ message: "خبر مورد نظر یافت نشد" });
    }

    const alreadyLiked = await hasUserLikedNews(id, req.user.id);
    const likesCount = alreadyLiked
      ? await removeNewsLike(id, req.user.id)
      : await addNewsLike(id, req.user.id);

    // لاگ حسابرسی سبک برای شفافیت (چه کسی/چه زمانی لایک کرد یا برداشت)
    await auditPublic(req, "news_likes", id, alreadyLiked ? "DELETE" : "INSERT", null, { newsId: id, userId: req.user.id });

    return res.status(200).json({
      message: alreadyLiked ? "لایک برداشته شد" : "خبر لایک شد",
      liked: !alreadyLiked,
      likesCount,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// اعلان به ادمین‌ها درباره‌ی یک نظر تازه که منتظر تایید است؛ خطاهایش
// هرگز نباید باعث شکست ثبت نظر شود (createNotification خودش هم همین رفتار را دارد).
// بررسی نظرات کار ادمین است و داشبورد سوپرادمین تب «نظرات» ندارد؛ پس این اعلان برای
// سوپرادمین فرستاده نمی‌شود (کلیک روی آن او را از داشبوردش به داشبورد ادمین می‌برد).
async function notifyAdminsOfPendingComment(newsTitle, newsId) {
  try {
    const recipients = await getAllUsers({ role: "admin" });
    await Promise.all(
      recipients.map((u) =>
        createNotification({
          userId: u.id,
          title: "نظر جدید در انتظار تایید",
          message: `یک نظر جدید روی خبر «${newsTitle}» ثبت شد و منتظر تایید شماست.`,
          type: "news_comment",
          relatedId: newsId,
        })
      )
    );
  } catch (err) {
    console.error("خطا در اطلاع‌رسانی نظر جدید به ادمین‌ها:", err.message);
  }
}

// ---------- ثبت نظر روی خبر (فقط کاربر واردشده؛ نیازمند تایید ادمین قبل از نمایش عمومی) ----------
export async function addNewsComment(req, res) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "شناسه خبر نامعتبر است" });
    }

    const article = await getNewsById(id);
    if (!isPubliclyVisible(article)) {
      return res.status(404).json({ message: "خبر مورد نظر یافت نشد" });
    }

    // متن نظر پیش از هر بررسی دیگری کاملاً از تگ‌های HTML پاک می‌شود (جلوگیری از XSS
    // ذخیره‌شده و لینک‌های اسپم قالب‌بندی‌شده)
    const content = sanitizeCommentText(req.body.content);
    if (!content || content.length < 2) {
      return res.status(400).json({ message: "متن نظر الزامی است" });
    }

    // جلوگیری از ارسال تکراری/اسپم: همان کاربر نمی‌تواند دقیقاً همان متن را روی همین خبر
    // در ۶۰ ثانیه‌ی اخیر دوباره ارسال کند (مثلاً به‌خاطر چند بار کلیک سریع روی دکمه ارسال)
    const isDuplicate = await hasRecentDuplicateComment(id, req.user.id, content);
    if (isDuplicate) {
      return res.status(429).json({ message: "این نظر همین الان ثبت شد؛ لطفاً منتظر بمانید" });
    }

    const rating = req.body.rating ? Number(req.body.rating) : null; // امتیاز اختیاری ۱ تا ۵ (اعتبارسنجی در newsCommentValidation)
    const comment = await createComment({ newsId: id, userId: req.user.id, content, rating });
    await auditPublic(req, "news_comments", comment.id, "INSERT", null, { newsId: id, userId: req.user.id, content });
    await notifyAdminsOfPendingComment(article.title, id);

    return res.status(201).json({
      message: "نظر شما ثبت شد و پس از تایید ادمین نمایش داده خواهد شد",
      comment,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

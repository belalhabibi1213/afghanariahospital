import { createInvoice, getInvoiceById, searchInvoices, getInvoicesByPatientId, getInvoicesByPatientUser, isInvoiceOwnedByUser, getInvoicesByDoctorId, isInvoiceAccessibleByDoctor, cancelInvoice, approveInvoice as approveInvoiceRecord, deleteInvoiceCascade } from "../models/Invoice.js";
import { recordPayment } from "../models/Payment.js";
import { getPatientById } from "../models/Patient.js";
import { getDoctorById, getDoctorByUserId } from "../models/Doctor.js";
import { getAppointmentById } from "../models/Appointment.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { createNotification } from "../models/Notification.js";

const logBilling = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

// ثبت لاگ حسابرسی (audit_logs) برای تغییرات صورت‌حساب/پرداخت
const auditBilling = (req, tableName, recordId, action, oldValues, newValues) =>
  recordAudit({
    req, tableName, recordId, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });

// ---------- صدور فاکتور (الزام شماره ۱) ----------
// POST /api/billing/invoices  (فقط admin/superadmin)
export async function generateInvoice(req, res, next) {
  try {
    const { patientId, doctorId, appointmentId, issueDate, dueDate, discount, tax, notes, items } = req.body;

    const patient = await getPatientById(patientId);
    if (!patient) {
      return res.status(404).json({ message: "بیمار انتخاب‌شده یافت نشد" });
    }
    if (doctorId) {
      const doctor = await getDoctorById(doctorId);
      if (!doctor) return res.status(404).json({ message: "داکتر انتخاب‌شده یافت نشد" });
    }
    if (appointmentId) {
      const appointment = await getAppointmentById(appointmentId);
      if (!appointment) return res.status(404).json({ message: "نوبت انتخاب‌شده یافت نشد" });
    }

    const invoice = await createInvoice({
      patientId, doctorId, appointmentId, issueDate, dueDate, discount, tax, notes, items,
      createdByUserId: req.user.id,
    });

    await logBilling(req, "صدور فاکتور", `invoiceId=${invoice.id} patientId=${patientId} total=${invoice.totalAmount}`);
    await auditBilling(req, "invoices", invoice.id, "INSERT", null, invoice);

    if (patient.userId) {
      await createNotification({
        userId: patient.userId,
        title: "فاکتور جدید صادر شد",
        message: `فاکتور ${invoice.invoiceNumber} به مبلغ ${invoice.totalAmount} صادر شد.`,
        type: "billing",
        relatedId: invoice.id,
      });
    }

    return res.status(201).json({ message: "فاکتور با موفقیت صادر شد", invoice });
  } catch (err) {
    // لاگ کامل (شامل کوئری/کد خطای MySQL در صورت وجود) برای عیب‌یابی سمت سرور؛
    // پیام واقعی هرگز مستقیماً به کلاینت فرستاده نمی‌شود (جلوگیری از افشای اطلاعات
    // داخلی دیتابیس) — به‌جایش به errorHandler مرکزی سپرده می‌شود که در محیط توسعه
    // پیام دقیق خطا را هم در فیلد debug برمی‌گرداند (نه یک برچسب یکسان و گمراه‌کننده‌ی
    // «خطای اتصال به دیتابیس» برای هر نوع خطای غیرمنتظره‌ای، از جمله باگ‌های SQL).
    console.error(`[billing] generateInvoice error (patientId=${req.body?.patientId}):`, err);
    return next(err);
  }
}

// ---------- فهرست/سوابق صورت‌حساب (الزام شماره ۵) ----------
// GET /api/billing/invoices?patientId=&status=&from=&to=&page=&limit=  (فقط admin/superadmin)
export async function listInvoices(req, res, next) {
  try {
    const { patientId, doctorId, status, from, to, q, page, limit } = req.query;
    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchInvoices({
      patientId, doctorId, status, from, to, q, page, limit,
    });
    return res.status(200).json({
      invoices: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error("[billing] listInvoices error:", err);
    return next(err);
  }
}

// سوابق صورت‌حساب یک بیمار مشخص (برای نمایش داخل پرونده‌ی بیمار در پنل ادمین)
// GET /api/billing/patients/:patientId/invoices
export async function listInvoicesForPatient(req, res, next) {
  try {
    const patient = await getPatientById(req.params.patientId);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    const invoices = await getInvoicesByPatientId(req.params.patientId);
    return res.status(200).json({ invoices });
  } catch (err) {
    console.error(`[billing] listInvoicesForPatient error (patientId=${req.params.patientId}):`, err);
    return next(err);
  }
}

// ---------- جزئیات یک فاکتور (شامل ردیف‌ها و پرداخت‌ها — برای نمایش/چاپ) ----------
// GET /api/billing/invoices/:id  (فقط admin/superadmin)
export async function getInvoice(req, res, next) {
  try {
    const invoice = await getInvoiceById(req.params.id);
    if (!invoice) return res.status(404).json({ message: "فاکتور یافت نشد" });
    return res.status(200).json({ invoice });
  } catch (err) {
    console.error(`[billing] getInvoice error (id=${req.params.id}):`, err);
    return next(err);
  }
}

// ---------- ثبت پرداخت (الزام شماره ۲) ----------
// POST /api/billing/invoices/:id/payments  (فقط admin/superadmin)
export async function addPayment(req, res, next) {
  try {
    const invoiceId = req.params.id;
    const { amount, method, paidAt, reference, notes } = req.body;

    const invoiceBefore = await getInvoiceById(invoiceId);

    const result = await recordPayment(invoiceId, {
      amount, method, paidAt, reference, notes, receivedByUserId: req.user.id,
    });

    if (result.error === "NOT_FOUND") {
      return res.status(404).json({ message: "فاکتور یافت نشد" });
    }
    if (result.error === "INVOICE_CANCELLED") {
      return res.status(409).json({ message: "این فاکتور لغو شده است و امکان ثبت پرداخت روی آن وجود ندارد", code: "INVOICE_CANCELLED" });
    }
    if (result.error === "OVERPAYMENT") {
      return res.status(400).json({
        message: `مبلغ پرداختی از باقیمانده‌ی فاکتور بیشتر است. مبلغ باقیمانده: ${result.remaining}`,
        code: "OVERPAYMENT",
        remaining: result.remaining,
      });
    }

    await logBilling(req, "ثبت پرداخت", `invoiceId=${invoiceId} amount=${amount} status=${result.status}`);

    const invoice = await getInvoiceById(invoiceId);
    await auditBilling(req, "payments", result.paymentId, "INSERT", null, {
      invoiceId, amount, method: method || "cash", paidAt, reference, notes, receivedByUserId: req.user.id,
    });
    await auditBilling(req, "invoices", invoiceId, "UPDATE",
      { paidAmount: invoiceBefore?.paidAmount, status: invoiceBefore?.status },
      { paidAmount: invoice.paidAmount, status: invoice.status });

    const patient = await getPatientById(invoice.patientId);
    if (patient && patient.userId) {
      await createNotification({
        userId: patient.userId,
        title: "پرداخت ثبت شد",
        message: `پرداخت ${amount} برای فاکتور ${invoice.invoiceNumber} ثبت شد. وضعیت: ${STATUS_LABEL[result.status] || result.status}`,
        type: "billing",
        relatedId: invoice.id,
      });
    }

    return res.status(201).json({ message: "پرداخت با موفقیت ثبت شد", invoice });
  } catch (err) {
    console.error(`[billing] addPayment error (invoiceId=${req.params.id}):`, err);
    return next(err);
  }
}

const STATUS_LABEL = {
  unpaid: "پرداخت‌نشده",
  partial: "پرداخت جزئی",
  paid: "پرداخت‌شده",
  cancelled: "لغوشده",
};

// ---------- لغو فاکتور (فقط اگر هیچ پرداختی روی آن ثبت نشده باشد) ----------
// PUT /api/billing/invoices/:id/cancel  (فقط admin/superadmin)
export async function voidInvoice(req, res, next) {
  try {
    const invoice = await getInvoiceById(req.params.id);
    if (!invoice) return res.status(404).json({ message: "فاکتور یافت نشد" });
    if (invoice.status === "cancelled") {
      return res.status(409).json({ message: "این فاکتور قبلاً لغو شده است" });
    }
    if (Number(invoice.paidAmount) > 0) {
      return res.status(409).json({
        message: "فاکتوری که برای آن پرداخت ثبت شده را نمی‌توان لغو کرد",
        code: "HAS_PAYMENTS",
      });
    }
    const updated = await cancelInvoice(req.params.id);
    await logBilling(req, "لغو فاکتور", `invoiceId=${req.params.id}`);
    await auditBilling(req, "invoices", req.params.id, "UPDATE", invoice, updated);
    return res.status(200).json({ message: "فاکتور لغو شد", invoice: updated });
  } catch (err) {
    console.error(`[billing] voidInvoice error (id=${req.params.id}):`, err);
    return next(err);
  }
}

// ---------- تایید فاکتور (Invoice Approval Workflow) ----------
// PUT /api/billing/invoices/:id/approve  (فقط admin/superadmin — طبق RBAC سطح روتر)
export async function approveInvoice(req, res, next) {
  try {
    const invoiceId = req.params.id;
    const invoiceBefore = await getInvoiceById(invoiceId);
    if (!invoiceBefore) return res.status(404).json({ message: "فاکتور یافت نشد" });
    if (invoiceBefore.status === "cancelled") {
      return res.status(409).json({ message: "فاکتور لغوشده را نمی‌توان تایید کرد", code: "INVOICE_CANCELLED" });
    }
    if (invoiceBefore.approvalStatus === "approved") {
      return res.status(409).json({ message: "این فاکتور قبلاً تایید شده است", code: "ALREADY_APPROVED" });
    }

    const invoice = await approveInvoiceRecord(invoiceId, req.user.id);
    if (!invoice) return res.status(404).json({ message: "فاکتور یافت نشد" });

    await logBilling(req, "تایید فاکتور", `invoiceId=${invoiceId} approvedBy=${req.user.email} paidAmount=${invoice.paidAmount}`);
    await auditBilling(req, "invoices", invoiceId, "UPDATE",
      {
        approvalStatus: invoiceBefore.approvalStatus, approvedByUserId: invoiceBefore.approvedByUserId, approvedAt: invoiceBefore.approvedAt,
        paidAmount: invoiceBefore.paidAmount, status: invoiceBefore.status,
      },
      {
        approvalStatus: invoice.approvalStatus, approvedByUserId: invoice.approvedByUserId, approvedAt: invoice.approvedAt,
        paidAmount: invoice.paidAmount, status: invoice.status,
      });

    // اعلان برای بیمار و داکترِ معالج (الزام: بعد از تایید، اعلان برای هر دو ساخته شود)
    const patient = await getPatientById(invoice.patientId);
    if (patient && patient.userId) {
      await createNotification({
        userId: patient.userId,
        title: "فاکتور تایید شد",
        message: `فاکتور ${invoice.invoiceNumber} توسط بخش صورت‌حساب تایید و مبلغ ${invoice.paidAmount} به‌عنوان پرداخت‌شده ثبت شد.`,
        type: "billing",
        relatedId: invoice.id,
      });
    }
    if (invoice.doctorId) {
      const doctor = await getDoctorById(invoice.doctorId);
      if (doctor && doctor.userId) {
        await createNotification({
          userId: doctor.userId,
          title: "فاکتور تایید شد",
          message: `فاکتور ${invoice.invoiceNumber} مربوط به بیمار ${invoice.patientName} تایید شد.`,
          type: "billing",
          relatedId: invoice.id,
        });
      }
    }

    return res.status(200).json({ message: "فاکتور با موفقیت تایید شد", invoice });
  } catch (err) {
    console.error(`[billing] approveInvoice error (id=${req.params.id}):`, err);
    return next(err);
  }
}

// ---------- حذف فاکتور (Delete Synchronization) ----------
// PUT/DELETE /api/billing/invoices/:id  (فقط admin/superadmin — طبق RBAC سطح روتر
// در routes/billing.js؛ داکتر/بیمار اصلاً به این روتر دسترسی ندارند و فقط از طریق
// /doctors/me/invoices و /users/invoices — که هر دو فقط-خواندنی هستند — فاکتور می‌بینند).
export async function deleteInvoice(req, res, next) {
  try {
    const invoiceId = req.params.id;
    const invoice = await getInvoiceById(invoiceId);
    if (!invoice) return res.status(404).json({ message: "فاکتور یافت نشد" });

    const deleted = await deleteInvoiceCascade(invoiceId);
    if (!deleted) return res.status(404).json({ message: "فاکتور یافت نشد" });

    // الزام «Logging»: ثبت Deleted By / Deleted Date / Invoice ID در Audit Log
    // (userId/userName از auditBilling و createdAt به‌صورت خودکار در audit_logs ثبت می‌شود)
    await logBilling(req, "حذف فاکتور", `invoiceId=${invoiceId} invoiceNumber=${invoice.invoiceNumber} deletedBy=${req.user.email}`);
    await auditBilling(req, "invoices", invoiceId, "DELETE", invoice, null);

    return res.status(200).json({ message: "فاکتور با موفقیت و به‌صورت کامل حذف شد", invoiceId: Number(invoiceId) });
  } catch (err) {
    console.error(`[billing] deleteInvoice error (id=${req.params.id}):`, err);
    return next(err);
  }
}

// ---------- سوابق صورت‌حساب و پرداخت‌های خودِ بیمار واردشده (پنل کاربر) ----------
// GET /api/users/invoices
export async function myInvoices(req, res) {
  try {
    const invoices = await getInvoicesByPatientUser(req.user.id);
    return res.status(200).json({ invoices });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/users/invoices/:id  — جزئیات یک فاکتور خودِ بیمار (برای نمایش/چاپ)
export async function myInvoiceDetail(req, res) {
  try {
    const owned = await isInvoiceOwnedByUser(req.params.id, req.user.id);
    if (!owned) return res.status(404).json({ message: "فاکتور یافت نشد" });
    const invoice = await getInvoiceById(req.params.id);
    return res.status(200).json({ invoice });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- صورت‌حساب و فاکتورهای بیمارانِ خودِ داکتر (پنل داکتر — «صورت‌حساب و فاکتورها») ----------
// GET /api/doctors/me/invoices  (فقط نقش 'doctor')
// RBAC: هر داکتر فقط فاکتورهای بیمارانی را می‌بیند که با او نوبت گرفته‌اند یا فاکتور
// مستقیماً به نام او صادر شده — نه فاکتورهای سایر بیماران شفاخانه.
export async function myDoctorInvoices(req, res) {
  try {
    const doctor = await getDoctorByUserId(req.user.id);
    if (!doctor) {
      return res.status(404).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    }
    const invoices = await getInvoicesByDoctorId(doctor.id);
    return res.status(200).json({ invoices });
  } catch (err) {
    console.error("[billing] myDoctorInvoices error:", err);
    return res.status(500).json({ message: "در حال حاضر امکان بارگذاری صورت‌حساب‌ها وجود ندارد. لطفاً چند لحظه دیگر دوباره تلاش کنید." });
  }
}

// GET /api/doctors/me/invoices/:id — جزئیات یک فاکتور (برای نمایش/چاپ)، فقط اگر متعلق
// به یکی از بیماران خودِ داکتر باشد؛ در غیر این صورت ۴۰۴ (نه ۴۰۳، تا وجود/عدم‌وجود
// فاکتورهای سایر بیماران برای داکتر افشا نشود).
export async function myDoctorInvoiceDetail(req, res) {
  try {
    const doctor = await getDoctorByUserId(req.user.id);
    if (!doctor) {
      return res.status(404).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    }
    const allowed = await isInvoiceAccessibleByDoctor(req.params.id, doctor.id);
    if (!allowed) {
      return res.status(404).json({ message: "فاکتور یافت نشد" });
    }
    const invoice = await getInvoiceById(req.params.id);
    if (!invoice) {
      return res.status(404).json({ message: "فاکتور یافت نشد" });
    }
    return res.status(200).json({ invoice });
  } catch (err) {
    console.error("[billing] myDoctorInvoiceDetail error:", err);
    return res.status(500).json({ message: "در حال حاضر امکان بارگذاری جزئیات فاکتور وجود ندارد. لطفاً چند لحظه دیگر دوباره تلاش کنید." });
  }
}

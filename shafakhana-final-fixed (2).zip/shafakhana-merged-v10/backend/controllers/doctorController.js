import fs from "fs";
import path from "path";
import { getAllDoctors, getDoctorsByDepartment, getDoctorById, getDoctorByUserId, updateDoctorSignature } from "../models/Doctor.js";
import { searchDoctorPatients, searchMyPatients, getMyPatientStats, getMyPatientDetail } from "../models/Patient.js";
import { getDoctorAvailability, getSchedulesByDoctor } from "../models/Schedule.js";
import { getAppointmentsByDoctor, searchDoctorAppointments, getDoctorAppointmentStats, getDoctorAppointmentDetail } from "../models/Appointment.js";
import { getAllSettings } from "../models/Settings.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { SIGNATURES_DIR } from "../middleware/upload.js";
import { resolveDateRange, currentPeriods } from "../utils/dateRanges.js";

export async function listDoctors(req, res) {
  try {
    const { department } = req.query;
    const doctors = department ? await getDoctorsByDepartment(department) : await getAllDoctors();
    // signatureUrl فقط برای پنل خودِ داکتر و تولید PDF نسخه است؛ در فهرست عمومی داکتران
    // (مسیر بدون احرازهویت) نباید حتی نام فایل امضا افشا شود — دفاع در عمق (الزام شماره ۲)
    const publicDoctors = doctors.map(({ signatureUrl, ...doctor }) => doctor);
    return res.status(200).json({ doctors: publicDoctors });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// در‌دسترس بودن یک داکتر برای یک تاریخ مشخص — مسیر عمومی، برای نمایش ساعت‌های
// قابل‌رزرو هنگام گرفتن نوبت (الزام شماره ۴)
export async function doctorAvailability(req, res) {
  try {
    const { date } = req.query;
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ message: "تاریخ معتبر (YYYY-MM-DD) الزامی است" });
    }
    const doctor = await getDoctorById(req.params.id);
    if (!doctor) return res.status(404).json({ message: "داکتر یافت نشد" });

    const settings = await getAllSettings();
    const slotCapacity = Number(settings.appointmentSlotCapacity) || 10;
    const availability = await getDoctorAvailability(req.params.id, date, slotCapacity, { timeZone: settings.timezone });
    return res.status(200).json({ doctorId: Number(req.params.id), ...availability });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


async function requireOwnDoctorProfile(req, res) {
  const doctor = await getDoctorByUserId(req.user.id);
  if (!doctor) {
    res.status(404).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    return null;
  }
  return doctor;
}

// نوبت‌های خودِ داکتر واردشده (پنل داکتر)
export async function myDoctorAppointments(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    const { status } = req.query;
    const appointments = await getAppointmentsByDoctor(doctor.id, { status });
    return res.status(200).json({ appointments });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// بیماران خودِ داکتر واردشده (پنل داکتر) — فقط بیمارانی که با او نوبت دارند،
// همراه با جستجو (نام/تلفن/شناسه بیمار) و صفحه‌بندی
export async function myDoctorPatients(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;

    const { q, page, limit } = req.query;
    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchDoctorPatients({
      doctorId: doctor.id,
      q,
      page,
      limit,
    });

    return res.status(200).json({
      patients: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- پنل داکتر: فهرست‌های سروریِ «نوبت‌های من» و «بیماران من» ----------
// جستجو، فیلتر، مرتب‌سازی و صفحه‌بندی همگی در دیتابیس انجام می‌شود؛ فقط یک صفحه (حداکثر ۱۰۰ ردیف)
// به کلاینت می‌رسد. همه‌ی مسیرها با requireAuth + authorize("doctor") محافظت شده‌اند و فقط داده‌ی
// خودِ داکتر واردشده را برمی‌گردانند.

async function systemTimeZone() {
  try {
    const settings = await getAllSettings();
    return settings.timezone;
  } catch {
    return undefined;
  }
}

// GET /api/doctors/me/appointments/list?q=&status=&department=&range=today|week|month&from=&to=&sort=newest|oldest&page=&limit=
export async function myDoctorAppointmentsList(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    const { q, status, department, range, from, to, sort, page, limit } = req.query;
    const { dateFrom, dateTo } = resolveDateRange({ range, from, to }, await systemTimeZone());
    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchDoctorAppointments({
      doctorId: doctor.id, q, status, department, dateFrom, dateTo, sort, page, limit,
    });
    return res.status(200).json({
      appointments: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/doctors/me/appointments/stats
export async function myDoctorAppointmentStats(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    return res.status(200).json({ stats: await getDoctorAppointmentStats(doctor.id) });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/doctors/me/appointments/:id — جزئیات برای Drawer؛ نوبتِ داکتر دیگر ۴۰۴ می‌دهد (نه ۴۰۳) تا وجودش لو نرود
export async function myDoctorAppointmentDetail(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    const appointment = await getDoctorAppointmentDetail(doctor.id, Number(req.params.id));
    if (!appointment) return res.status(404).json({ message: "نوبت یافت نشد" });
    return res.status(200).json({ appointment });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/doctors/me/patients/list?q=&status=active|inactive&gender=&department=&range=today|week|month&from=&to=&sort=newest|oldest|name&page=&limit=
export async function myDoctorPatientsList(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    const { q, status, gender, department, range, from, to, sort, page, limit } = req.query;
    const { dateFrom, dateTo } = resolveDateRange({ range, from, to }, await systemTimeZone());
    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchMyPatients({
      doctorId: doctor.id, q, status, gender, department, dateFrom, dateTo, sort, page, limit,
    });
    // doctorId: شناسه‌ی خودِ داکتر واردشده — فرانت برای تشخیص «نسخه/پرونده‌ی خودم» در پنل‌های نسخه و پرونده لازم دارد
    return res.status(200).json({
      patients: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
      doctorId: doctor.id,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/doctors/me/patients/stats
export async function myDoctorPatientStats(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    const p = currentPeriods(await systemTimeZone());
    const stats = await getMyPatientStats(doctor.id, { today: p.today, weekFrom: p.weekFrom, weekTo: p.weekTo });
    return res.status(200).json({ stats });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/doctors/me/patients/:id — جزئیات بیمار برای Drawer (فقط بیمارانی که با همین داکتر نوبت دارند)
export async function myDoctorPatientDetail(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    const patient = await getMyPatientDetail(doctor.id, Number(req.params.id));
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    return res.status(200).json({ patient: { ...patient, doctorId: doctor.id, doctorName: doctor.fullName } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// تغییر وضعیت نوبت توسط داکتر — غیرفعال شد؛ تایید و پذیرش فقط با ادمین است
export async function updateMyAppointmentStatus(req, res) {
  // تایید / رد / تکمیل (پذیرش) نوبت فقط وظیفه‌ی ادمین است (PUT /api/admin/appointments/:id/status).
  // داکتر فقط فهرست نوبت‌ها را می‌بیند (GET /api/doctors/me/appointments)؛ این مسیر برای
  // سازگاری با کلاینت‌های قدیمی باقی مانده ولی همیشه ۴۰۳ برمی‌گرداند و هیچ تغییری در دیتابیس نمی‌دهد.
  return res.status(403).json({
    message: "تایید و پذیرش نوبت فقط توسط ادمین انجام می‌شود. داکتر فقط می‌تواند فهرست نوبت‌ها را مشاهده کند.",
  });
}

// ---------- مشاهده‌ی برنامه کاری خودِ داکتر (فقط خواندنی) ----------
// دسترسی داکتر به برنامه کاری «فقط مشاهده» است؛ ایجاد/ویرایش/حذف برنامه کاری
// صرفاً از پنل Admin/Super Admin (routes/admin.js) و با نقش‌های admin/superadmin مجاز است.
// این جدا بودن مسیرهای نوشتن از پنل داکتر، بخشی از کنترل دسترسی مبتنی بر نقش (RBAC) است.

// تعیین شیفت (صبح/عصر) بر اساس ساعت شروع بازه‌ی کاری — چون ستون مجزایی برای
// شیفت در دیتابیس وجود ندارد، این مقدار صرفاً برای نمایش محاسبه می‌شود
function deriveShift(startTime) {
  const hour = Number(String(startTime).slice(0, 2));
  return hour < 12 ? "صبح" : "عصر";
}

// فهرست برنامه‌های کاریِ داکتر واردشده (فقط مشاهده) — شامل نام بخش داکتر و شیفت محاسبه‌شده
export async function myDoctorSchedules(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    const schedules = await getSchedulesByDoctor(doctor.id);
    const withDetails = schedules.map((s) => ({
      ...s,
      department: doctor.department,
      shift: deriveShift(s.startTime),
      status: "فعال",
    }));
    return res.status(200).json({ schedules: withDetails });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- امضای دیجیتال داکتر ----------
// آپلود/جایگزینی امضای دیجیتال داکتر (الزام شماره ۱ و ۴: آپلود و جایگزینی امضا).
// چون امضا روی هر نسخه چاپ می‌شود، مثل عکس پروفایل/داکتر عمومی نیست و در یک پوشه‌ی
// خصوصی ذخیره می‌شود (الزام شماره ۲: ذخیره‌سازی امن) — به همین دلیل به‌جای photoUrl
// از یک ستون و پوشه‌ی جداگانه (signatureUrl / SIGNATURES_DIR) استفاده شده است.
// اعتبارسنجی فرمت/حجم/محتوای واقعی فایل همان میان‌افزار مشترک uploadSignature +
// verifyImageContent است که پیش از این کنترلر در مسیر اجرا می‌شود (الزام شماره ۵).
export async function uploadMySignature(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return;
    }

    if (!req.file) return res.status(400).json({ message: "فایل امضا الزامی است" });

    const previousSignatureUrl = doctor.signatureUrl;
    const updated = await updateDoctorSignature(doctor.id, req.file.filename);

    // اگر امضای قبلی وجود داشت، از دیسک حذف می‌شود تا فایل یتیم روی سرور باقی نماند
    if (previousSignatureUrl) {
      const oldPath = path.join(SIGNATURES_DIR, path.basename(previousSignatureUrl));
      fs.unlink(oldPath, () => {});
    }

    await logActivity({
      req, userId: req.user.id, userName: req.user.email, role: req.user.role,
      action: previousSignatureUrl ? "جایگزینی امضای دیجیتال داکتر" : "آپلود امضای دیجیتال داکتر",
    });
    await recordAudit({
      req, tableName: "doctors", recordId: doctor.id, action: "UPDATE",
      oldValues: { signatureUrl: previousSignatureUrl || null }, newValues: { signatureUrl: updated.signatureUrl },
      userId: req.user.id, userName: req.user.email, role: req.user.role,
    });
    return res.status(200).json({ message: "امضای دیجیتال با موفقیت ذخیره شد", doctor: updated });
  } catch (err) {
    if (req.file) fs.unlink(req.file.path, () => {});
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// پیش‌نمایش/دانلود امن امضای خودِ داکتر در پنل داکتر — چون /uploads عمومی است، این
// فایل از پوشه‌ی خصوصی و فقط از طریق همین مسیر احرازهویت‌شده سرو می‌شود
export async function downloadMySignature(req, res) {
  try {
    const doctor = await requireOwnDoctorProfile(req, res);
    if (!doctor) return;
    if (!doctor.signatureUrl) return res.status(404).json({ message: "هنوز امضایی برای این حساب ثبت نشده است" });

    const filePath = path.join(SIGNATURES_DIR, path.basename(doctor.signatureUrl));
    if (!fs.existsSync(filePath)) return res.status(404).json({ message: "فایل امضا روی سرور یافت نشد" });
    return res.sendFile(filePath);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

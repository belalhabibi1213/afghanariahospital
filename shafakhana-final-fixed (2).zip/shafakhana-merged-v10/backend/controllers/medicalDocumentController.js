import { getDoctorByUserId } from "../models/Doctor.js";
import { doctorHasConfirmedPatient } from "../models/Patient.js";
import {
  DOC_TYPES, searchMedicalDocuments, searchMyDocuments, getMedicalDocumentStats, getDocumentOwnerRef, getMedicalDocumentDetail,
} from "../models/MedicalDocument.js";
import { logEmr } from "./medicalRecordController.js";

// کنترلر فهرست یکپارچه‌ی «اسناد طبی» (نسخه، سابقه صحی، آزمایش، تصویر پزشکی) برای بخش
// «نسخه و سوابق طبی» ادمین و داکتر. فقط خواندنی است؛ ثبت/ویرایش/حذف همچنان از مسیرهای
// موجود /api/medical-records/* (فقط داکتر، با بررسی مالکیت) انجام می‌شود.
//
// دامنه‌ی دسترسی در بک‌اند اعمال می‌شود، نه در UI:
//   ادمین/سوپرادمین → همه (به‌جز پیش‌نویس داکتر)
//   داکتر           → فقط بیماران با نوبت تأییدشده/انجام‌شده با خودش؛ شناسه‌ی داکتر همیشه از توکن می‌آید
//                     و doctorId/scope در query نادیده است.
// سندِ ناموجود و سندِ غیرمجاز هر دو همان پاسخ ۴۰۴ را می‌گیرند تا شناسه‌ها قابل حدس‌زدن نباشند.

const SERVER_ERROR = { message: "خطای سرور در اتصال به دیتابیس" };
const NOT_FOUND = { message: "سند یافت نشد" };

async function resolveScope(req, res) {
  if (req.user.role !== "doctor") return {}; // ادمین/سوپرادمین (مسیر خودش authorize شده است)
  const doctor = await getDoctorByUserId(req.user.id);
  if (!doctor) {
    res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    return null;
  }
  return { doctorId: doctor.id };
}

function pickListParams(req, scope) {
  const { q, type, status, doctorId, dateFrom, dateTo, sort, order, page, limit } = req.query;
  return {
    q: typeof q === "string" ? q : "",
    type: typeof type === "string" ? type : "",
    status: typeof status === "string" ? status : "",
    // داکتر نمی‌تواند با query داکتر دیگری را فیلتر کند؛ فیلتر داکتر فقط برای ادمین معنا دارد
    doctorId: scope.doctorId ? undefined : doctorId,
    dateFrom: typeof dateFrom === "string" ? dateFrom : "",
    dateTo: typeof dateTo === "string" ? dateTo : "",
    sort: typeof sort === "string" ? sort : "",
    order: typeof order === "string" ? order : "",
    page, limit,
  };
}

// GET /api/admin/medical-documents   و   GET /api/doctors/me/medical-documents
export async function listMedicalDocuments(req, res) {
  try {
    const scope = await resolveScope(req, res);
    if (!scope) return;
    const { rows, total, page, limit, totalPages } = await searchMedicalDocuments({ scope, ...pickListParams(req, scope) });
    // canDownload: دکمه‌ی چاپ/دریافت فقط وقتی که مسیر موجود (PDF نسخه / گزارش آزمایش) واقعاً اجازه می‌دهد —
    // این مسیرها برای داکتر فقط روی سندِ خودش باز است، پس برای سند داکتر دیگر دکمه‌ای نشان داده نمی‌شود
    const documents = rows.map(({ hasFile, ...row }) => ({
      ...row,
      canDownload: Boolean(Number(hasFile)) && (!scope.doctorId || row.doctorId === scope.doctorId),
    }));
    return res.status(200).json({ documents, pagination: { total, page, limit, totalPages } });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// GET .../medical-documents/stats
export async function medicalDocumentStats(req, res) {
  try {
    const scope = await resolveScope(req, res);
    if (!scope) return;
    return res.status(200).json({ stats: await getMedicalDocumentStats({ scope }) });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// GET .../medical-documents/:type/:id
export async function medicalDocumentDetail(req, res) {
  try {
    const { type, id } = req.params;
    if (!DOC_TYPES.includes(type)) return res.status(400).json({ message: "نوع سند نامعتبر است" });

    const scope = await resolveScope(req, res);
    if (!scope) return;

    const ref = await getDocumentOwnerRef(type, id);
    if (!ref) return res.status(404).json(NOT_FOUND);

    if (scope.doctorId) {
      const allowed = await doctorHasConfirmedPatient(scope.doctorId, ref.patientId);
      const foreignDraft = type === "record" && ref.status === "draft" && ref.doctorId !== scope.doctorId;
      if (!allowed || foreignDraft) return res.status(404).json(NOT_FOUND);
    } else if (type === "record" && ref.status === "draft") {
      return res.status(404).json(NOT_FOUND); // پیش‌نویس فقط برای داکتر نویسنده است
    }

    const document = await getMedicalDocumentDetail(type, id);
    if (!document) return res.status(404).json(NOT_FOUND);

    // دکمه‌های چاپ/دریافت فقط وقتی نمایش داده می‌شوند که مسیر موجودشان واقعاً اجازه بدهد
    // (PDF نسخه و گزارش آزمایش در مسیرهای موجود فقط برای داکتر مالک یا ادمین باز است)
    const isOwner = !scope.doctorId || ref.doctorId === scope.doctorId;
    const permissions = {
      pdf: type === "prescription" && isOwner,
      labReport: type === "lab" && document.hasReport && isOwner,
      files: type === "record", // مسیر فایل‌ها خودش مجوز بیمار را بررسی می‌کند
      canEdit: Boolean(scope.doctorId) && ref.doctorId === scope.doctorId && (type !== "prescription" || document.status === "active"),
    };

    await logEmr(req, "مشاهده جزئیات سند طبی", `type=${type} id=${id} patientId=${ref.patientId}`);
    return res.status(200).json({ document, permissions });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// GET /api/users/documents — «همه اسناد» پنل بیمار (نسخه + پرونده صحی) با جستجو/فیلتر نوع/صفحه‌بندی در SQL.
// مالکیت فقط از توکن (req.user.id)؛ patientId/userId/doctorId در query نادیده‌اند و نوع فقط prescription|record است.
// فقط فیلدهای لازم برای نمایش به بیمار برگردانده می‌شود (بدون شناسه‌ی داخلی بیمار/داکتر).
export async function listMyDocuments(req, res) {
  try {
    const { q, type, page, limit } = req.query;
    const result = await searchMyDocuments({
      patientUserId: req.user.id,
      q: typeof q === "string" ? q : "",
      type: typeof type === "string" ? type : "",
      page, limit,
    });
    const documents = result.rows.map((r) => ({
      type: r.docType,
      id: r.id,
      number: r.docNumber,
      date: r.docDate,
      title: r.title || "",
      doctorName: r.doctorName || "",
      status: r.docType === "prescription" ? r.status : undefined,
      itemCount: r.docType === "prescription" ? Number(r.itemCount) || 0 : undefined,
      released: r.docType === "record" ? Boolean(Number(r.released)) : undefined,
    }));
    return res.status(200).json({
      documents,
      counts: result.counts,
      pagination: { total: result.total, page: result.page, limit: result.limit, totalPages: result.totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

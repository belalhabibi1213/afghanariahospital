import { createContactMessage } from "../models/Contact.js";
import { getAllUsers } from "../models/User.js";
import { createNotification } from "../models/Notification.js";

export async function submitContact(req, res) {
  try {
    const { fullName, phone, email, message, type, subject } = req.body;
    if (!fullName || !message) {
      return res.status(400).json({ message: "نام و متن پیام الزامی است" });
    }
    const contact = await createContactMessage({ fullName, phone, email, message, type, subject });

    // اعلان درون‌سیستمی برای همه‌ی ادمین‌های فعال (مرکز اعلان‌های ادمین)؛ هرگز نباید
    // باعث شکست ثبت پیام اصلی شود
    try {
      const admins = await getAllUsers({ role: "admin" });
      const preview = message.length > 80 ? `${message.slice(0, 80)}…` : message;
      await Promise.all(
        admins
          .filter((admin) => admin.isActive)
          .map((admin) =>
            createNotification({
              userId: admin.id,
              title: `پیام تماس جدید از ${fullName}`,
              message: preview,
              type: "contact_message",
              relatedId: contact.id,
            })
          )
      );
    } catch (err) {
      console.error("خطا در ارسال اعلان پیام تماس جدید به ادمین‌ها:", err.message);
    }

    return res.status(201).json({ message: "پیام شما با موفقیت ارسال شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

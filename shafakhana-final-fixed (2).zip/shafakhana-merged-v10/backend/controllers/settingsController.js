import { getAllSettings } from "../models/Settings.js";

// این کنترلر برخلاف controllers/superadminController.js (که تنظیمات کامل و فقط برای
// Super Admin است)، فقط زیرمجموعه‌ی «قابل‌نمایش عمومی» تنظیمات را برمی‌گرداند —
// بدون نیاز به ورود. صفحات عمومی سایت (هدر، فوتر، تماس با ما، فاکتور/نسخه، حالت
// تعمیرات) از همین مسیر برای همگام‌ماندن با آنچه Super Admin در «تنظیمات سیستم»
// ذخیره کرده استفاده می‌کنند.
export async function getPublicSettings(req, res) {
  try {
    const settings = await getAllSettings();
    return res.status(200).json({
      settings: {
        hospitalName: settings.hospitalName,
        hospitalPhone: settings.hospitalPhone,
        hospitalEmail: settings.hospitalEmail,
        hospitalAddress: settings.hospitalAddress,
        hospitalDescription: settings.hospitalDescription,
        logoUrl: settings.logoUrl,
        maintenanceMode: settings.maintenanceMode,
        defaultLanguage: settings.defaultLanguage,
        theme: settings.theme,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

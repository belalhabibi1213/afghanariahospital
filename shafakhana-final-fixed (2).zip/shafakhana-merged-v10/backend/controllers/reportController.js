import { getAppointmentReport, getPatientReport, getDoctorReport, getRevenueReport } from "../models/Report.js";
import { sendPdfReport, sendExcelReport } from "../utils/reportExport.js";

import { formatJalaliDate } from "../utils/jalali.js";
const STATUS_LABEL = { pending: "در انتظار", confirmed: "تاییدشده", completed: "تکمیل‌شده", cancelled: "لغوشده" };
const INVOICE_STATUS_LABEL = { unpaid: "پرداخت‌نشده", partial: "پرداخت جزئی", paid: "پرداخت‌شده", cancelled: "لغوشده" };
const METHOD_LABEL = { cash: "نقدی", card: "کارت", bank_transfer: "حواله بانکی", insurance: "بیمه", other: "سایر" };

function money(n) {
  return Number(n || 0).toLocaleString("en-US", { maximumFractionDigits: 2 });
}

// خروجی هر گزارش را بسته به پارامتر format ارسال می‌کند: json (پیش‌فرض، برای نمایش
// در پنل ادمین)، pdf یا excel (الزام شماره ۵: خروجی PDF و Excel). این تابع مشترک،
// تکرار منطق انتخاب فرمت را در هر چهار کنترلر گزارش حذف می‌کند.
async function respondWithReport(req, res, { format, jsonPayload, exportPayload }) {
  if (format === "pdf") {
    sendPdfReport(res, exportPayload);
    return;
  }
  if (format === "excel") {
    await sendExcelReport(res, exportPayload);
    return;
  }
  return res.status(200).json(jsonPayload);
}

// ---------- گزارش نوبت‌ها (الزام شماره ۱) ----------
// GET /api/reports/appointments?from=&to=&status=&doctorId=&department=&format=
export async function appointmentReport(req, res) {
  try {
    const { from, to, status, doctorId, department, format } = req.query;
    const { summary, rows } = await getAppointmentReport({ from, to, status, doctorId, department });

    const columns = [
      { header: "نام بیمار", key: "patientName", width: 2 },
      { header: "شماره تماس", key: "patientPhone", width: 1.4 },
      { header: "داکتر", key: "doctorName", width: 1.8 },
      { header: "بخش", key: "department", width: 1.4 },
      { header: "تاریخ", key: "appointmentDate", width: 1 },
      { header: "ساعت", key: "appointmentTime", width: 0.8 },
      { header: "وضعیت", key: "statusLabel", width: 1 },
    ];
    const exportRows = rows.map((r) => ({
      ...r,
      appointmentDate: formatJalaliDate(r.appointmentDate, { latin: true }),
      appointmentTime: String(r.appointmentTime).slice(0, 5),
      statusLabel: STATUS_LABEL[r.status] || r.status,
    }));
    const summaryLines = [
      `مجموع نوبت‌ها: ${summary.total ?? rows.length}`,
      `به تفکیک وضعیت: ${summary.byStatus.map((s) => `${STATUS_LABEL[s.status] || s.status}: ${s.count}`).join("  |  ")}`,
    ];

    await respondWithReport(req, res, {
      format,
      jsonPayload: { summary, rows },
      exportPayload: {
        fileName: "appointment-report", title: "گزارش نوبت‌ها", from, to, columns, rows: exportRows, summaryLines,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- گزارش بیماران (الزام شماره ۲) ----------
// GET /api/reports/patients?from=&to=&format=
export async function patientReport(req, res) {
  try {
    const { from, to, format } = req.query;
    const { summary, rows } = await getPatientReport({ from, to });

    const columns = [
      { header: "نام بیمار", key: "fullName", width: 2 },
      { header: "شماره تماس", key: "phone", width: 1.4 },
      { header: "ایمیل", key: "email", width: 1.6 },
      { header: "تاریخ ثبت‌نام", key: "createdAt", width: 1.2 },
      { header: "تعداد نوبت‌ها", key: "appointmentCount", width: 1 },
      { header: "آخرین ویزیت", key: "lastAppointmentDate", width: 1.2 },
    ];
    const exportRows = rows.map((r) => ({
      ...r,
      email: r.email || "-",
      createdAt: formatJalaliDate(r.createdAt, { latin: true }),
      lastAppointmentDate: r.lastAppointmentDate ? formatJalaliDate(r.lastAppointmentDate, { latin: true }) : "-",
    }));
    const summaryLines = [
      `تعداد کل بیماران: ${summary.totalPatients}`,
      `بیماران تازه‌ثبت‌شده در این بازه: ${summary.newPatientsInRange}`,
    ];

    await respondWithReport(req, res, {
      format,
      jsonPayload: { summary, rows },
      exportPayload: {
        fileName: "patient-report", title: "گزارش بیماران", from, to, columns, rows: exportRows, summaryLines,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- گزارش داکتران (الزام شماره ۳) ----------
// GET /api/reports/doctors?from=&to=&format=
export async function doctorReport(req, res) {
  try {
    const { from, to, format } = req.query;
    const { summary, rows } = await getDoctorReport({ from, to });

    const columns = [
      { header: "نام داکتر", key: "fullName", width: 1.8 },
      { header: "بخش", key: "department", width: 1.3 },
      { header: "مجموع نوبت‌ها", key: "totalAppointments", width: 1 },
      { header: "تکمیل‌شده", key: "completedAppointments", width: 0.9 },
      { header: "لغوشده", key: "cancelledAppointments", width: 0.9 },
      { header: "درآمد", key: "revenueLabel", width: 1.1 },
      { header: "وصول‌شده", key: "collectedLabel", width: 1.1 },
    ];
    const exportRows = rows.map((r) => ({
      ...r,
      revenueLabel: money(r.revenue),
      collectedLabel: money(r.collectedRevenue),
    }));
    const summaryLines = [
      `مجموع نوبت‌های همه‌ی داکتران: ${summary.totalAppointments}`,
      `مجموع درآمد: ${money(summary.totalRevenue)}  |  مجموع وصول‌شده: ${money(summary.totalCollected)}`,
    ];

    await respondWithReport(req, res, {
      format,
      jsonPayload: { summary, rows },
      exportPayload: {
        fileName: "doctor-report", title: "گزارش عملکرد داکتران", from, to, columns, rows: exportRows, summaryLines,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- گزارش درآمد (الزام شماره ۴) ----------
// GET /api/reports/revenue?from=&to=&format=
export async function revenueReport(req, res) {
  try {
    const { from, to, format } = req.query;
    const { summary, rows } = await getRevenueReport({ from, to });

    const columns = [
      { header: "شماره فاکتور", key: "invoiceNumber", width: 1.2 },
      { header: "بیمار", key: "patientName", width: 1.6 },
      { header: "مبلغ", key: "amountLabel", width: 1 },
      { header: "روش پرداخت", key: "methodLabel", width: 1.1 },
      { header: "تاریخ پرداخت", key: "paidAtLabel", width: 1.1 },
      { header: "مرجع", key: "reference", width: 1.1 },
    ];
    const exportRows = rows.map((r) => ({
      ...r,
      amountLabel: money(r.amount),
      methodLabel: METHOD_LABEL[r.method] || r.method,
      paidAtLabel: formatJalaliDate(r.paidAt, { latin: true }),
      reference: r.reference || "-",
    }));
    const totalIssued = (summary.invoicesByStatus || [])
      .filter((x) => x.status !== "cancelled")
      .reduce((sum, x) => sum + Number(x.totalAmount || 0), 0);
    const summaryLines = [
      `مجموع فاکتورهای صادرشده در بازه (بدون لغوشده): ${money(totalIssued)}`,
      `مجموع درآمد وصول‌شده (پرداخت‌های بازه): ${money(summary.totalCollected)}`,
      `مانده‌ی مطالبات (همه‌ی فاکتورهای پرداخت‌نشده/جزئی): ${money(summary.totalOutstanding)}`,
      `به تفکیک روش پرداخت: ${summary.byMethod.map((m) => `${METHOD_LABEL[m.method] || m.method}: ${money(m.total)}`).join("  |  ")}`,
      `وضعیت فاکتورهای صادرشده: ${summary.invoicesByStatus.map((s) => `${INVOICE_STATUS_LABEL[s.status] || s.status}: ${s.count}`).join("  |  ")}`,
    ];

    await respondWithReport(req, res, {
      format,
      jsonPayload: { summary, rows },
      exportPayload: {
        fileName: "revenue-report", title: "گزارش درآمد", from, to, columns, rows: exportRows, summaryLines,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

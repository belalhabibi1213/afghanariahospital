import path from "path";
import {
  getAllDepartments, getDepartmentById, createDepartment, updateDepartment, deleteDepartment,
} from "../models/Department.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { DEPARTMENTS_DIR } from "../middleware/upload.js";
import { removeUploadedFile } from "../utils/uploadStore.js";

// آیا آیکون فعلی بخش از آپلودکننده‌ی آیکون بخش (backend/uploads/departments) ذخیره شده؟
// اگر بله، هنگام حذف بخش، فایل هم از دیسک پاک می‌شود تا فایل یتیم باقی نماند (همان الگوی
// isOwnDepartmentIconUpload در controllers/adminController.js)
function isOwnDepartmentIconUpload(icon) {
  return typeof icon === "string" && icon.startsWith("/uploads/departments/");
}

const logDepartment = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

// ثبت لاگ حسابرسی (audit_logs) برای تغییرات این کنترلر — همان الگوی سایر کنترلرها
const auditDepartment = (req, recordId, action, oldValues, newValues) =>
  recordAudit({
    req, tableName: "departments", recordId, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });

// ---------- فهرست بخش‌ها (GET /api/departments) ----------
// عمداً بدون احراز هویت است (مثل /api/news) چون هم برای پنل مدیریت بخش‌ها در
// داشبورد ادمین و هم برای بخش «خدمات ما»ی سایت اصلی استفاده می‌شود.
// با ?public=1 (همان‌طور که صفحه‌ی عمومی «خدمات ما» صدا می‌زند) فقط بخش‌های فعال و
// «نمایش در سایت اصلی»=۱ برگردانده می‌شوند؛ بدون این پارامتر رفتار قبلی (همه‌ی بخش‌ها،
// برای پنل ادمین) دست‌نخورده می‌ماند.
export async function listDepartments(req, res, next) {
  try {
    const publicOnly = req.query.public === "1" || req.query.public === "true";
    const departments = await getAllDepartments({ publicOnly });
    return res.status(200).json({ departments });
  } catch (err) {
    console.error("[departments] listDepartments error:", err);
    return next(err);
  }
}

// ---------- جزئیات یک بخش (GET /api/departments/:id) ----------
export async function getDepartment(req, res, next) {
  try {
    const department = await getDepartmentById(req.params.id);
    if (!department) return res.status(404).json({ message: "بخش یافت نشد" });
    return res.status(200).json({ department });
  } catch (err) {
    console.error(`[departments] getDepartment error (id=${req.params.id}):`, err);
    return next(err);
  }
}

// ---------- ثبت بخش جدید (POST /api/departments) ----------
// فقط admin/superadmin — RBAC روی سطح روتر در routes/departments.js اعمال شده است.
export async function addDepartment(req, res, next) {
  try {
    const {
      name, description, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    } = req.body;

    const department = await createDepartment({
      name, description, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    });

    await logDepartment(req, "افزودن بخش جدید", `departmentId=${department.id} name=${department.name}`);
    await auditDepartment(req, department.id, "INSERT", null, department);

    return res.status(201).json({ message: "بخش جدید با موفقیت ساخته شد", department });
  } catch (err) {
    // نام بخش UNIQUE است؛ در صورت تکراری بودن، پیام روشن به‌جای خطای خام دیتابیس
    if (err && err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ message: "بخشی با این نام از قبل وجود دارد" });
    }
    console.error("[departments] addDepartment error:", err);
    return next(err);
  }
}

// ---------- ویرایش بخش (PUT /api/departments/:id) ----------
// فقط admin/superadmin — به‌روزرسانی جزئی مجاز است (فقط فیلدهای ارسال‌شده تغییر می‌کنند).
export async function editDepartment(req, res, next) {
  try {
    const existing = await getDepartmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "بخش یافت نشد" });

    const {
      name, description, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    } = req.body;

    const department = await updateDepartment(req.params.id, {
      name, description, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    });

    await logDepartment(req, "ویرایش بخش", `departmentId=${req.params.id}`);
    await auditDepartment(req, req.params.id, "UPDATE", existing, department);

    return res.status(200).json({ message: "بخش با موفقیت به‌روزرسانی شد", department });
  } catch (err) {
    if (err && err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ message: "بخشی با این نام از قبل وجود دارد" });
    }
    console.error(`[departments] editDepartment error (id=${req.params.id}):`, err);
    return next(err);
  }
}

// ---------- حذف بخش (DELETE /api/departments/:id) ----------
// فقط admin/superadmin.
export async function removeDepartment(req, res, next) {
  try {
    const existing = await getDepartmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "بخش یافت نشد" });

    await deleteDepartment(req.params.id);

    // اگر آیکون بخش یک فایل آپلودی (نه Lucide) بود، از دیسک هم پاک می‌شود تا فایل یتیم
    // باقی نماند
    if (isOwnDepartmentIconUpload(existing.icon)) {
      removeUploadedFile(path.join(DEPARTMENTS_DIR, path.basename(existing.icon)));
    }
    if (isOwnDepartmentIconUpload(existing.coverImage)) {
      removeUploadedFile(path.join(DEPARTMENTS_DIR, path.basename(existing.coverImage)));
    }

    await logDepartment(req, "حذف بخش", `departmentId=${req.params.id} name=${existing.name}`);
    await auditDepartment(req, req.params.id, "DELETE", existing, null);

    return res.status(200).json({ message: "بخش با موفقیت حذف شد" });
  } catch (err) {
    console.error(`[departments] removeDepartment error (id=${req.params.id}):`, err);
    return next(err);
  }
}

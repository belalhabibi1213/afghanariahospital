import {
  PRESCRIPTION_STATUSES, searchPrescriptionGroups, getPrescriptionStats,
  getPrescriptionById, setPrescriptionGroupStatus,
} from "../models/Prescription.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";

// کنترلر پنل ادمین «نسخه و سوابق طبی». فقط admin/superadmin به این مسیرها دسترسی دارند
// (routes/admin.js با requireAuth + authorize). جزئیات کامل نسخه و سوابق طبی بیمار از همان
// مسیر موجود GET /api/admin/patients/:id/full-profile خوانده می‌شود و اینجا تکرار نشده است.

const STATUS_LABEL = { active: "در حال اجرا", completed: "تکمیل‌شده", cancelled: "لغوشده" };

// GET /api/admin/prescriptions?q=&status=&doctorId=&dateFrom=&dateTo=&page=&limit=
export async function listPrescriptionsAdmin(req, res) {
  try {
    const { q, status, doctorId, dateFrom, dateTo, page, limit } = req.query;
    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchPrescriptionGroups({
      q, status, doctorId, dateFrom, dateTo, page, limit,
    });
    return res.status(200).json({
      prescriptions: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/admin/prescriptions/stats
export async function prescriptionStatsAdmin(req, res) {
  try {
    const stats = await getPrescriptionStats();
    return res.status(200).json({ stats });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// PUT /api/admin/prescriptions/:id/status   body: { status: "active" | "completed" | "cancelled" }
export async function changePrescriptionStatus(req, res) {
  try {
    const { status } = req.body || {};
    if (!PRESCRIPTION_STATUSES.includes(status)) {
      return res.status(400).json({ message: "وضعیت نسخه نامعتبر است" });
    }
    const existing = await getPrescriptionById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نسخه یافت نشد" });

    const updated = await setPrescriptionGroupStatus(existing, status);
    await logActivity({
      req, userId: req.user.id, userName: req.user.email, role: req.user.role,
      action: "تغییر وضعیت نسخه", details: `prescriptionId=${existing.id} ${existing.status} → ${status}`,
    });
    await recordAudit({
      req, tableName: "prescriptions", recordId: existing.id, action: "UPDATE",
      oldValues: { status: existing.status }, newValues: { status: updated.status },
      userId: req.user.id, userName: req.user.email, role: req.user.role,
    });
    return res.status(200).json({ message: `وضعیت نسخه به «${STATUS_LABEL[status]}» تغییر کرد`, prescription: updated });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

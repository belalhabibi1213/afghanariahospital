import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { MFA_TOKEN_SECRET, isMfaRequiredForRole } from "../utils/env.js";
import {
  findByIdRaw,
  registerFailedLogin,
  resetFailedLoginAttempts,
  setMfaPendingSecretIfEmpty,
  enableMfa,
  disableMfa,
  consumeMfaStep,
  consumeRecoveryCode,
} from "../models/User.js";
import { getAllSettings } from "../models/Settings.js";
import { logActivity } from "../models/ActivityLog.js";
import { revokeAllSessionsForUser } from "../models/Session.js";
import {
  generateTotpSecret, verifyTotp, buildOtpauthUrl, encryptSecret, decryptSecret,
  generateRecoveryCodes, hashRecoveryCode, looksLikeRecoveryCode,
} from "../utils/totp.js";
import { finishLogin } from "./authController.js";

const INVALID_MFA_MESSAGE = "کد احراز هویت نامعتبر است";

async function qrDataUrl(text) {
  try {
    const QRCode = (await import("qrcode")).default;
    return await QRCode.toDataURL(text, { margin: 1, width: 220 });
  } catch {
    return null; // بدون QR هم می‌توان راز را دستی وارد کرد
  }
}

// «کد» (TOTP یا کد بازیابی) را برای یک کاربر دارای MFA می‌سنجد؛ true/false
async function checkUserCode(user, code) {
  if (!user.mfaSecretEnc) return false;
  if (looksLikeRecoveryCode(code)) {
    return consumeRecoveryCode(user.id, hashRecoveryCode(code));
  }
  let secret;
  try {
    secret = decryptSecret(user.mfaSecretEnc);
  } catch (err) {
    console.error("خواندن راز MFA ممکن نشد (کلید تغییر کرده؟):", err.message);
    return false;
  }
  const step = verifyTotp(secret, code);
  if (step === null) return false;
  return consumeMfaStep(user.id, step); // هر کد فقط یک‌بار قابل استفاده است
}

async function failureCounters(user) {
  const settings = await getAllSettings();
  await registerFailedLogin(
    user.id,
    Math.max(3, Math.floor(Number(settings.loginMaxFailedAttempts)) || 5),
    Math.max(1, Math.floor(Number(settings.loginLockoutMinutes)) || 15)
  );
}

// POST /api/auth/mfa/verify — مرحله‌ی دوم ورود: { mfaToken, code }
export async function mfaVerify(req, res) {
  try {
    const { mfaToken, code } = req.body || {};
    if (typeof mfaToken !== "string" || !code) {
      return res.status(400).json({ message: "کد احراز هویت الزامی است" });
    }
    let payload;
    try {
      payload = jwt.verify(mfaToken, MFA_TOKEN_SECRET, { algorithms: ["HS256"] });
    } catch {
      return res.status(401).json({ message: "مهلت ورود تمام شده است، دوباره با رمز عبور وارد شوید", code: "MFA_TOKEN_EXPIRED" });
    }
    if (payload.purpose !== "mfa") {
      return res.status(401).json({ message: "توکن نامعتبر است", code: "MFA_TOKEN_EXPIRED" });
    }
    const user = await findByIdRaw(payload.id);
    if (!user || !user.isActive || !user.mfaEnabled) {
      return res.status(401).json({ message: INVALID_MFA_MESSAGE });
    }
    if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
      const minutesLeft = Math.max(1, Math.ceil((new Date(user.lockedUntil) - new Date()) / 60000));
      return res.status(423).json({
        message: `به‌دلیل چند تلاش ناموفق، ورود موقتاً قفل شده است. حدود ${minutesLeft} دقیقه‌ی دیگر تلاش کنید.`,
        code: "ACCOUNT_LOCKED",
      });
    }
    const usedRecovery = looksLikeRecoveryCode(code);
    if (!(await checkUserCode(user, code))) {
      await failureCounters(user);
      return res.status(401).json({ message: INVALID_MFA_MESSAGE, code: "MFA_INVALID" });
    }
    await resetFailedLoginAttempts(user.id);
    return finishLogin(req, res, user, {
      activityAction: usedRecovery ? "ورود به سیستم (با کد بازیابی MFA)" : "ورود به سیستم (MFA)",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور" });
  }
}

// GET /api/auth/mfa/status
export async function mfaStatus(req, res) {
  const user = await findByIdRaw(req.user.id);
  let recoveryCodesLeft = 0;
  try { recoveryCodesLeft = JSON.parse(user.mfaRecoveryHashes || "[]").length; } catch { /* ignore */ }
  return res.json({
    enabled: !!user.mfaEnabled,
    required: isMfaRequiredForRole(user.role),
    recoveryCodesLeft,
  });
}

// POST /api/auth/mfa/setup — راز جدید می‌سازد (هنوز فعال نیست تا کد اول تایید شود)
export async function mfaSetup(req, res) {
  try {
    const user = await findByIdRaw(req.user.id);
    if (user.mfaEnabled) {
      return res.status(409).json({ message: "احراز هویت دومرحله‌ای از قبل فعال است" });
    }
    await setMfaPendingSecretIfEmpty(user.id, encryptSecret(generateTotpSecret()));
    const fresh = await findByIdRaw(user.id);
    const secret = decryptSecret(fresh.mfaPendingSecretEnc);
    const otpauthUrl = buildOtpauthUrl({ secret, email: user.email });
    return res.json({ secret, otpauthUrl, qrDataUrl: await qrDataUrl(otpauthUrl) });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور" });
  }
}

// POST /api/auth/mfa/enable { code } — با کد اول فعال می‌شود و کدهای بازیابی را «فقط یک‌بار» برمی‌گرداند
export async function mfaEnable(req, res) {
  try {
    const user = await findByIdRaw(req.user.id);
    if (user.mfaEnabled) return res.status(409).json({ message: "احراز هویت دومرحله‌ای از قبل فعال است" });
    if (!user.mfaPendingSecretEnc) {
      return res.status(400).json({ message: "ابتدا راه‌اندازی را شروع کنید" });
    }
    const secret = decryptSecret(user.mfaPendingSecretEnc);
    const step = verifyTotp(secret, req.body?.code);
    if (step === null) return res.status(400).json({ message: INVALID_MFA_MESSAGE, code: "MFA_INVALID" });

    const recoveryCodes = generateRecoveryCodes();
    await enableMfa(user.id, user.mfaPendingSecretEnc, recoveryCodes.map(hashRecoveryCode));
    await consumeMfaStep(user.id, step);
    // نشست‌های دیگر این حساب بسته می‌شوند؛ نشست فعلی می‌ماند
    await revokeAllSessionsForUser(user.id, { exceptTokenId: req.user.jti || null, revokedByUserId: user.id });
    await logActivity({ req, userId: user.id, userName: user.fullName, role: user.role, action: "فعال‌سازی احراز هویت دومرحله‌ای" });
    return res.json({ message: "احراز هویت دومرحله‌ای فعال شد", recoveryCodes });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور" });
  }
}

// POST /api/auth/mfa/disable { password, code } — برای نقش‌های الزام‌شده ممنوع است
export async function mfaDisable(req, res) {
  try {
    const user = await findByIdRaw(req.user.id);
    if (!user.mfaEnabled) return res.status(400).json({ message: "احراز هویت دومرحله‌ای فعال نیست" });
    if (isMfaRequiredForRole(user.role)) {
      return res.status(403).json({ message: "برای نقش شما احراز هویت دومرحله‌ای اجباری است و غیرفعال نمی‌شود", code: "MFA_REQUIRED" });
    }
    const { password, code } = req.body || {};
    if (typeof password !== "string" || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ message: "رمز عبور اشتباه است" });
    }
    if (!(await checkUserCode(user, code))) {
      await failureCounters(user);
      return res.status(401).json({ message: INVALID_MFA_MESSAGE, code: "MFA_INVALID" });
    }
    await disableMfa(user.id);
    await logActivity({ req, userId: user.id, userName: user.fullName, role: user.role, action: "غیرفعال‌سازی احراز هویت دومرحله‌ای" });
    return res.json({ message: "احراز هویت دومرحله‌ای غیرفعال شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور" });
  }
}

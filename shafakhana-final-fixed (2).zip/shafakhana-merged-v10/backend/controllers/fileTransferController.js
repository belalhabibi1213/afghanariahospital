import fs from "fs";
import path from "path";
import { getDoctorByUserId } from "../models/Doctor.js";
import { getPatientById, doctorHasPatient } from "../models/Patient.js";
import {
  createFileTransfer, getFileTransferById, getFileTransfersByDoctorAndPatient, getFileTransfersByDoctor,
  getFileTransfersByPatientUser, getFileTransferByIdForPatientUser, getAllFileTransfers,
  deleteFileTransferById, countFileTransfersByFileName,
} from "../models/FileTransfer.js";
import { FILE_TRANSFERS_DIR } from "../middleware/upload.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { createNotification } from "../models/Notification.js";

const logTransfer = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

// ---------- ارسال فایل توسط داکتر برای یک بیمار مشخص (فقط بیماران خودش — RBAC) ----------
// POST /api/doctors/me/file-transfers (multipart/form-data: patientId, note, files[])
export async function sendFilesToPatient(req, res) {
  const files = req.files || [];
  // در سطح تابع (نه داخل try) تعریف می‌شود تا در بلاک catch هم قابل‌دسترسی باشد — برای
  // اینکه در صورت بروز خطا بتوانیم فقط فایل‌های بدون رکورد دیتابیس را حذف کنیم (پایین‌تر توضیح داده شده)
  const created = [];
  try {
    const doctor = await getDoctorByUserId(req.user.id);
    if (!doctor) {
      files.forEach((f) => fs.unlink(f.path, () => {}));
      return res.status(404).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    }

    const { patientId, note } = req.body;
    if (!patientId) {
      files.forEach((f) => fs.unlink(f.path, () => {}));
      return res.status(400).json({ message: "انتخاب بیمار الزامی است" });
    }

    const patient = await getPatientById(patientId);
    if (!patient) {
      files.forEach((f) => fs.unlink(f.path, () => {}));
      return res.status(404).json({ message: "بیمار یافت نشد" });
    }

    // داکتر فقط می‌تواند برای بیمارانِ خودش (کسانی که با او نوبت گرفته‌اند) فایل ارسال کند
    const isOwnPatient = await doctorHasPatient(doctor.id, patient.id);
    if (!isOwnPatient) {
      files.forEach((f) => fs.unlink(f.path, () => {}));
      return res.status(403).json({ message: "شما فقط می‌توانید برای بیماران خودتان فایل ارسال کنید" });
    }

    if (files.length === 0) {
      return res.status(400).json({ message: "حداقل یک فایل الزامی است" });
    }

    const trimmedNote = (note || "").trim() || null;
    // نکته‌ی مهم: هر فایل با یک INSERT جداگانه ثبت می‌شود (نه در یک تراکنش واحد). اگر خطایی
    // بعد از ثبت موفق چند فایل رخ دهد (مثلاً هنگام ثبت فایل بعدی، یا در لاگ حسابرسی/اعلان
    // که بعد از این حلقه اجرا می‌شوند)، نباید فایل‌هایی که رکورد دیتابیسشان از قبل با موفقیت
    // ثبت شده حذف شوند؛ در غیر این صورت رکورد دیتابیس باقی می‌ماند اما فایل روی دیسک نیست
    // و بیمار هنگام دانلود با خطای «فایل روی سرور یافت نشد» مواجه می‌شود.
    for (const file of files) {
      const item = await createFileTransfer({
        patientId: patient.id,
        doctorId: doctor.id,
        fileName: file.filename,
        originalName: file.originalname,
        fileType: file.mimetype,
        fileSize: file.size,
        note: trimmedNote,
      });
      created.push(item);
    }

    await logTransfer(req, "ارسال فایل معلومات بیمار", `patientId=${patient.id} تعداد فایل=${created.length}`);
    for (const item of created) {
      await recordAudit({
        req, tableName: "file_transfers", recordId: item.id, action: "INSERT", oldValues: null, newValues: item,
        userId: req.user.id, userName: req.user.email, role: req.user.role,
      });
    }

    // اعلان به بیمار (اگر حساب کاربری داشته باشد)
    if (patient.userId) {
      await createNotification({
        userId: patient.userId,
        title: "فایل جدید از داکتر",
        message: `داکتر ${doctor.fullName} ${created.length} فایل برای شما ارسال کرد.`,
        type: "file_transfer",
        relatedId: created[0]?.id || null,
      });
    }

    return res.status(201).json({ message: "فایل(ها) با موفقیت ارسال شد", transfers: created });
  } catch (err) {
    // فقط فایل‌هایی از دیسک حذف می‌شوند که هیچ‌وقت رکورد دیتابیسشان با موفقیت ثبت نشده
    // (یعنی هنوز در آرایه‌ی created نیستند)؛ فایل‌هایی که رکوردشان از قبل ثبت شده، دست‌نخورده
    // باقی می‌مانند تا با دیتابیس هم‌خوان بمانند و بعداً برای بیمار قابل دانلود باشند.
    const persistedFileNames = new Set(created.map((item) => item.fileName));
    files
      .filter((f) => !persistedFileNames.has(f.filename))
      .forEach((f) => fs.unlink(f.path, () => {}));
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// تاریخچه‌ی فایل‌های ارسال‌شده توسط داکتر واردشده — برای یک بیمار مشخص (اختیاری، از طریق query)
// یا در صورت نبود patientId، همه‌ی ارسالی‌های همین داکتر
// GET /api/doctors/me/file-transfers?patientId=123
export async function myDoctorFileTransfers(req, res) {
  try {
    const doctor = await getDoctorByUserId(req.user.id);
    if (!doctor) return res.status(404).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });

    const { patientId } = req.query;
    let transfers;
    if (patientId) {
      const isOwnPatient = await doctorHasPatient(doctor.id, patientId);
      if (!isOwnPatient) {
        return res.status(403).json({ message: "شما اجازه‌ی مشاهده‌ی فایل‌های این بیمار را ندارید" });
      }
      transfers = await getFileTransfersByDoctorAndPatient(doctor.id, patientId);
    } else {
      transfers = await getFileTransfersByDoctor(doctor.id);
    }

    return res.status(200).json({ transfers });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// دانلود امن یک فایل ارسالی، برای پنل داکتر (فقط فایل‌های ارسالی خودش) — چون این فایل‌ها
// اسناد صحی حساس هستند، از پوشه‌ی خصوصی و فقط بعد از بررسی مالکیت سرو می‌شوند
export async function downloadFileTransferForDoctor(req, res) {
  try {
    const doctor = await getDoctorByUserId(req.user.id);
    if (!doctor) return res.status(404).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });

    const existing = await getFileTransferById(req.params.id);
    if (!existing || existing.doctorId !== doctor.id) {
      return res.status(404).json({ message: "فایل یافت نشد" });
    }

    const filePath = path.join(FILE_TRANSFERS_DIR, path.basename(existing.fileName));
    if (!fs.existsSync(filePath)) return res.status(404).json({ message: "فایل روی سرور یافت نشد" });
    return res.download(filePath, existing.originalName);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// حذف یک فایل ارسالی توسط داکتر — فقط اگر فایل واقعاً توسط خودِ همین داکتر ارسال شده
// باشد (RBAC مالکیت). ابتدا رکورد از دیتابیس حذف می‌شود؛ سپس اگر هیچ رکورد دیگری به
// همان فایل فیزیکی روی دیسک اشاره نکند، خودِ فایل هم از دیسک پاک می‌شود. بیماران و
// ادمین/سوپرادمین هیچ مسیر حذفی برای این ماژول ندارند (نگاه کنید به routes/users.js
// و routes/admin.js — فقط GET/download).
// DELETE /api/doctors/me/file-transfers/:id
export async function deleteFileTransferForDoctor(req, res) {
  try {
    const doctor = await getDoctorByUserId(req.user.id);
    if (!doctor) return res.status(404).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });

    const existing = await getFileTransferById(req.params.id);
    if (!existing || existing.doctorId !== doctor.id) {
      return res.status(404).json({ message: "فایل یافت نشد" });
    }

    await deleteFileTransferById(existing.id);

    // فقط در صورتی فایل فیزیکی از دیسک حذف می‌شود که هیچ رکورد دیگری آن را استفاده نکند
    const stillUsed = await countFileTransfersByFileName(existing.fileName, existing.id);
    if (!stillUsed) {
      const filePath = path.join(FILE_TRANSFERS_DIR, path.basename(existing.fileName));
      fs.unlink(filePath, () => {});
    }

    await logTransfer(req, "حذف فایل ارسالی معلومات بیمار", `transferId=${existing.id} patientId=${existing.patientId}`);
    await recordAudit({
      req, tableName: "file_transfers", recordId: existing.id, action: "DELETE",
      oldValues: existing, newValues: null,
      userId: req.user.id, userName: req.user.email, role: req.user.role,
    });

    return res.status(200).json({ message: "فایل ارسالی با موفقیت حذف شد", id: existing.id });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- دسترسی بیمار به فایل‌های دریافتی خودش ----------

// GET /api/users/file-transfers
export async function getMyFileTransfers(req, res) {
  try {
    const transfers = await getFileTransfersByPatientUser(req.user.id);
    return res.status(200).json({ transfers });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// دانلود امن فایل توسط خودِ بیمار — فقط اگر متعلق به او باشد
// GET /api/users/file-transfers/:id/download
export async function downloadMyFileTransfer(req, res) {
  try {
    const existing = await getFileTransferByIdForPatientUser(req.params.id, req.user.id);
    if (!existing) return res.status(404).json({ message: "فایلی یافت نشد" });

    const filePath = path.join(FILE_TRANSFERS_DIR, path.basename(existing.fileName));
    if (!fs.existsSync(filePath)) return res.status(404).json({ message: "فایل روی سرور یافت نشد" });
    return res.download(filePath, existing.originalName);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- Admin/Super Admin: مشاهده‌ی همه‌ی انتقال‌ها (فقط مشاهده — این ماژول اصلاً
// امکان ویرایش/حذف فایل ارسالی را ندارد؛ ادمین/سوپرادمین فقط می‌تواند فهرست/دانلود کند) ----------
// GET /api/admin/file-transfers
export async function listAllFileTransfers(req, res) {
  try {
    const { page, limit } = req.query;
    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await getAllFileTransfers({ page, limit });
    return res.status(200).json({
      transfers: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// دانلود یک فایل توسط ادمین/سوپرادمین — فقط مشاهده، هیچ مسیر ویرایش/حذفی برای این ماژول وجود ندارد
// GET /api/admin/file-transfers/:id/download
export async function downloadFileTransferForAdmin(req, res) {
  try {
    const existing = await getFileTransferById(req.params.id);
    if (!existing) return res.status(404).json({ message: "فایل یافت نشد" });

    const filePath = path.join(FILE_TRANSFERS_DIR, path.basename(existing.fileName));
    if (!fs.existsSync(filePath)) return res.status(404).json({ message: "فایل روی سرور یافت نشد" });
    return res.download(filePath, existing.originalName);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

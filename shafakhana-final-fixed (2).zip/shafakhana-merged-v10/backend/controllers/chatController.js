import fs from "fs";
import path from "path";
import { getPatientsByUser, getPatientById, doctorHasCompletedPatient } from "../models/Patient.js";
import { getDoctorByUserId, getDoctorById } from "../models/Doctor.js";
import {
  getOrCreateConversation, getConversationById,
  getConversationsForPatient, getConversationsForDoctor,
  getMessagesByConversation, createMessage, markConversationRead,
  markAllConversationsDelivered,
  getMessageById, updateMessageContent, softDeleteMessage,
  toggleMessageReaction, createMessageWithAttachment, maskDeletedMessage,
} from "../models/Chat.js";
import { createNotification } from "../models/Notification.js";
import { getIO } from "../realtime/socketServer.js";
import { CHAT_ATTACHMENTS_DIR, sanitizeOriginalFilename } from "../middleware/upload.js";

// پیش از فرستادن یک پیام به کلاینت، نام فایلِ داخلیِ ذخیره‌شده روی دیسک (attachmentFileName)
// حذف می‌شود — کلاینت هرگز نباید مسیر/نام فایل واقعی روی سرور را بداند؛ دسترسی به پیوست
// فقط از طریق شناسه‌ی پیام (messageId) و مسیر دانلود امن (downloadMessageAttachment) است.
function toClientMessage(row) {
  if (!row) return row;
  const { attachmentFileName, ...rest } = row;
  return rest;
}

// کاربر واردشده اگر «بیمار» باشد، رکورد patients متصل به حسابش را برمی‌گرداند؛ در غیر
// این صورت null. هر کاربر با نقش 'user' حداکثر یک رکورد بیمار متصل به خودش دارد.
async function resolveActingPatient(req) {
  if (req.user.role !== "user") return null;
  const patients = await getPatientsByUser(req.user.id);
  return patients[0] || null;
}

// کاربر واردشده اگر «داکتر» باشد، پروفایل داکتر متصل به حسابش را برمی‌گرداند؛ در غیر این صورت null
async function resolveActingDoctor(req) {
  if (req.user.role !== "doctor") return null;
  return getDoctorByUserId(req.user.id);
}

// بررسی می‌کند که آیا کاربر واردشده اجازه‌ی دسترسی به این مکالمه‌ی مشخص را دارد یا نه:
// بیمار فقط مکالمه‌ی خودش، داکتر فقط مکالمه با بیمارانِ خودش
async function ensureConversationAccess(req, conversation) {
  if (!conversation) return { allowed: false };
  if (req.user.role === "user") {
    const patient = await resolveActingPatient(req);
    return { allowed: !!patient && conversation.patientId === patient.id, patient };
  }
  if (req.user.role === "doctor") {
    const doctor = await resolveActingDoctor(req);
    return { allowed: !!doctor && conversation.doctorId === doctor.id, doctor };
  }
  return { allowed: false };
}

// بررسی می‌کند که آیا یک نوبت «انجام‌شده» بین طرفینِ این مکالمه برقرار
// است یا نه — جدا از ensureConversationAccess (که فقط مالکیتِ مکالمه را می‌سنجد). استفاده‌شده
// در مسیرهایی که باعث برقراریِ ارتباط تازه می‌شوند (شروع مکالمه، ارسال پیام/پیوست/صوت،
// تماس صوتی/تصویری)؛ عمداً برای خواندن پیام‌های قبلی/ویرایش/حذف/واکنش به کار نمی‌رود تا
// اگر نوبت بعداً لغو شد، تاریخچه‌ی گفتگوی قبلی از دسترس بیمار/داکتر خارج نشود.
async function ensureActiveRelationship(conversation) {
  return doctorHasCompletedPatient(conversation.doctorId, conversation.patientId);
}

// ---------- GET /api/chat/conversations ----------
// فهرست مکالمه‌های کاربر واردشده (بیمار یا داکتر، بسته به نقش)
// پیام تازه را «لحظه‌ای» به اتاق شخصی گیرنده push می‌کند (فقط شناسه‌ی مکالمه، نه محتوا؛ کلاینت
// پیام را از همان REST احرازهویت‌شده می‌گیرد). اگر Socket.IO فعال نباشد (مثلاً در تست) بی‌اثر است
// و هیچ‌وقت نباید ارسال پیام را مختل کند؛ polling کلاینت همچنان پشتیبان است.
function pushChatEvent(recipientUserId, conversationId) {
  try {
    getIO()?.to(`user:${recipientUserId}`).emit("chat:new", { conversationId });
  } catch (err) {
    console.error("push رویداد چت ناموفق بود:", err.message);
  }
}

export async function listConversations(req, res) {
  try {
    if (req.user.role === "user") {
      const patient = await resolveActingPatient(req);
      if (!patient) return res.status(200).json({ conversations: [] });

      // بارگذاری فهرست مکالمه‌ها یعنی برنامه‌ی بیمار با سرور همگام شده — پس پیام‌های
      // داکتر که هنوز «تحویل‌شده» علامت نخورده‌اند اینجا تحویل‌شده در نظر گرفته می‌شوند
      // (نباید باعث شکست بارگذاری فهرست شود)
      try {
        await markAllConversationsDelivered("user", patient.id);
      } catch (err) {
        console.error("خطا در علامت‌گذاری پیام‌ها به‌عنوان تحویل‌شده:", err.message);
      }

      const conversations = await getConversationsForPatient(patient.id);
      return res.status(200).json({ conversations });
    }

    if (req.user.role === "doctor") {
      const doctor = await resolveActingDoctor(req);
      if (!doctor) return res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });

      try {
        await markAllConversationsDelivered("doctor", doctor.id);
      } catch (err) {
        console.error("خطا در علامت‌گذاری پیام‌ها به‌عنوان تحویل‌شده:", err.message);
      }

      const conversations = await getConversationsForDoctor(doctor.id);
      return res.status(200).json({ conversations });
    }

    return res.status(403).json({ message: "شما اجازه‌ی دسترسی به این بخش را ندارید" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- POST /api/chat/conversations ----------
// شروع (یا بازکردن) یک مکالمه. بیمار با ارسال doctorId، داکتر با ارسال patientId.
// مکالمه فقط بین بیمار و داکتری مجاز است که حداقل یک نوبتِ «تایید شده» یا «انجام‌شده»
// دارند (doctorHasCompletedPatient) — فقط نوبتِ «انجام‌شده» کافی است؛ «در انتظار» و «تایید شده» کافی نیست؛ سخت‌گیرانه‌تر
// از قاعده‌ی پرونده صحی الکترونیک (doctorHasPatient) که هر نوبتی را کافی می‌داند.
export async function startConversation(req, res) {
  try {
    let patientId;
    let doctorId;

    if (req.user.role === "user") {
      const patient = await resolveActingPatient(req);
      if (!patient) return res.status(404).json({ message: "پرونده‌ی بیمار برای این حساب یافت نشد" });
      const targetDoctorId = Number(req.body.doctorId);
      if (!targetDoctorId) return res.status(400).json({ message: "شناسه‌ی داکتر الزامی است" });
      const doctor = await getDoctorById(targetDoctorId);
      if (!doctor) return res.status(404).json({ message: "داکتر یافت نشد" });
      patientId = patient.id;
      doctorId = doctor.id;
    } else if (req.user.role === "doctor") {
      const doctor = await resolveActingDoctor(req);
      if (!doctor) return res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
      const targetPatientId = Number(req.body.patientId);
      if (!targetPatientId) return res.status(400).json({ message: "شناسه‌ی بیمار الزامی است" });
      const patient = await getPatientById(targetPatientId);
      if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
      patientId = patient.id;
      doctorId = doctor.id;
    } else {
      return res.status(403).json({ message: "شما اجازه‌ی دسترسی به این بخش را ندارید" });
    }

    const related = await doctorHasCompletedPatient(doctorId, patientId);
    if (!related) {
      return res.status(403).json({
        message: "گفتگو فقط بعد از انجام شدن نوبت (ویزیت) امکان‌پذیر است",
        code: "APPOINTMENT_NOT_CONFIRMED",
      });
    }

    const conversation = await getOrCreateConversation(patientId, doctorId);
    return res.status(200).json({ conversation });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- GET /api/chat/conversations/:conversationId/messages ----------
export async function getMessages(req, res) {
  try {
    const { conversationId } = req.params;
    const conversation = await getConversationById(conversationId);
    if (!conversation) return res.status(404).json({ message: "مکالمه یافت نشد" });

    const { allowed } = await ensureConversationAccess(req, conversation);
    if (!allowed) {
      return res.status(403).json({ message: "شما اجازه‌ی دسترسی به این مکالمه را ندارید" });
    }

    const { page, limit } = req.query;
    const result = await getMessagesByConversation(conversationId, { page, limit, viewerUserId: req.user.id });

    // پیام‌های طرف مقابل را خوانده‌شده علامت می‌زند (نباید باعث شکست درخواست اصلی شود)
    try {
      await markConversationRead(conversationId, req.user.role);
    } catch (err) {
      console.error("خطا در علامت‌گذاری پیام‌ها به‌عنوان خوانده‌شده:", err.message);
    }

    return res.status(200).json({
      conversation,
      messages: result.rows.map(toClientMessage),
      pagination: { total: result.total, page: result.page, limit: result.limit, totalPages: result.totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- POST /api/chat/conversations/:conversationId/messages ----------
export async function sendMessage(req, res) {
  try {
    const { conversationId } = req.params;
    const conversation = await getConversationById(conversationId);
    if (!conversation) return res.status(404).json({ message: "مکالمه یافت نشد" });

    const { allowed } = await ensureConversationAccess(req, conversation);
    if (!allowed) {
      return res.status(403).json({ message: "شما اجازه‌ی دسترسی به این مکالمه را ندارید" });
    }

    // تا نوبت بیمار توسط داکتر/ادمین تایید نشده (یا قبلاً انجام نشده)، اجازه‌ی ارسال پیام
    // تازه داده نمی‌شود — حتی اگر مکالمه از قبل وجود داشته باشد (مثلاً نوبت بعداً لغو شده باشد)
    if (!(await ensureActiveRelationship(conversation))) {
      return res.status(403).json({
        message: "ارسال پیام فقط بعد از انجام شدن نوبت امکان‌پذیر است",
        code: "APPOINTMENT_NOT_CONFIRMED",
      });
    }

    const content = (req.body.content || "").trim();
    if (!content) return res.status(400).json({ message: "متن پیام نمی‌تواند خالی باشد" });
    if (content.length > 4000) {
      return res.status(400).json({ message: "متن پیام نباید بیشتر از ۴۰۰۰ کاراکتر باشد" });
    }

    const message = await createMessage({
      conversationId,
      senderUserId: req.user.id,
      senderRole: req.user.role,
      content,
    });

    // اعلان به طرف مقابل (بیمار یا داکتر) در صورت داشتن حساب کاربری — هرگز نباید
    // باعث شکست ارسال پیام اصلی شود
    try {
      const recipientUserId = req.user.role === "user" ? conversation.doctorUserId : conversation.patientUserId;
      if (recipientUserId) {
        pushChatEvent(recipientUserId, conversation.id);
        const senderName = req.user.role === "user" ? conversation.patientName : conversation.doctorName;
        const preview = content.length > 80 ? `${content.slice(0, 80)}…` : content;
        await createNotification({
          userId: recipientUserId,
          title: senderName ? `پیام جدید از ${senderName}` : "پیام جدید",
          message: preview,
          type: "chat_message",
          relatedId: conversation.id,
        });
      }
    } catch (err) {
      console.error("خطا در ارسال اعلان پیام جدید:", err.message);
    }

    return res.status(201).json({ message: "پیام با موفقیت ارسال شد", data: toClientMessage(message) });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// یک پیام را بارگذاری می‌کند و بررسی می‌کند که مکالمه‌ی آن در دسترسِ کاربر واردشده باشد:
// بیمار فقط مکالمه‌ی خودش، داکتر فقط مکالمه با بیمارانِ خودش. مالکیتِ خودِ پیام اینجا
// بررسی نمی‌شود (برای واکنش‌زدن لازم نیست — هر دو طرفِ مکالمه می‌توانند به هر پیامی
// واکنش نشان دهند)؛ برای ویرایش/حذف، مالکیت در loadOwnMessageForEdit اضافه بررسی می‌شود.
async function loadAccessibleMessage(req, res) {
  const { conversationId, messageId } = req.params;
  const conversation = await getConversationById(conversationId);
  if (!conversation) {
    res.status(404).json({ message: "مکالمه یافت نشد" });
    return null;
  }

  const { allowed } = await ensureConversationAccess(req, conversation);
  if (!allowed) {
    res.status(403).json({ message: "شما اجازه‌ی دسترسی به این مکالمه را ندارید" });
    return null;
  }

  const existingMessage = await getMessageById(messageId);
  if (!existingMessage || String(existingMessage.conversationId) !== String(conversation.id)) {
    res.status(404).json({ message: "پیام یافت نشد" });
    return null;
  }

  return existingMessage;
}

// یک پیام را برای عملیات ویرایش/حذف بارگذاری و مالکیت آن را بررسی می‌کند: علاوه بر
// دسترسیِ عمومی به مکالمه (loadAccessibleMessage)، فرستنده‌ی پیام باید دقیقاً همین کاربر
// (با همین نقش) باشد — یعنی داکتر فقط پیام‌های خودِ داکتر و بیمار فقط پیام‌های خودِ بیمار
// را می‌تواند ویرایش/حذف کند، نه پیام‌های طرف مقابل.
async function loadOwnMessageForEdit(req, res) {
  const existingMessage = await loadAccessibleMessage(req, res);
  if (!existingMessage) return null;

  const isOwner = existingMessage.senderUserId === req.user.id && existingMessage.senderRole === req.user.role;
  if (!isOwner) {
    res.status(403).json({ message: "شما فقط می‌توانید پیام‌های خودتان را ویرایش یا حذف کنید" });
    return null;
  }

  return existingMessage;
}

// ---------- PUT /api/chat/conversations/:conversationId/messages/:messageId ----------
// ویرایش متن یک پیام؛ فقط فرستنده‌ی خودِ پیام مجاز است (بررسی در loadOwnMessageForEdit)
export async function editMessage(req, res) {
  try {
    const existingMessage = await loadOwnMessageForEdit(req, res);
    if (!existingMessage) return;

    if (existingMessage.isDeleted) {
      return res.status(400).json({ message: "پیام حذف‌شده را نمی‌توان ویرایش کرد" });
    }

    const content = (req.body.content || "").trim();
    if (!content) return res.status(400).json({ message: "متن پیام نمی‌تواند خالی باشد" });
    if (content.length > 4000) {
      return res.status(400).json({ message: "متن پیام نباید بیشتر از ۴۰۰۰ کاراکتر باشد" });
    }

    const updated = await updateMessageContent(existingMessage.id, content);
    return res.status(200).json({ message: "پیام ویرایش شد", data: toClientMessage(updated) });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- DELETE /api/chat/conversations/:conversationId/messages/:messageId ----------
// حذف نرم (soft-delete) یک پیام؛ فقط فرستنده‌ی خودِ پیام مجاز است (بررسی در loadOwnMessageForEdit)
export async function deleteMessage(req, res) {
  try {
    const existingMessage = await loadOwnMessageForEdit(req, res);
    if (!existingMessage) return;

    const updated = existingMessage.isDeleted
      ? maskDeletedMessage(existingMessage)
      : await softDeleteMessage(existingMessage.id);

    return res.status(200).json({ message: "پیام حذف شد", data: toClientMessage(updated) });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// مجموعه‌ی مجاز واکنش‌های ایموجی — با ALLOWED_MESSAGE_REACTIONS در formValidators.js هماهنگ
// نگه‌داشته می‌شود. اعتبارسنجی اصلی در میان‌افزار express-validator انجام می‌شود؛ این بررسی
// اینجا فقط یک لایه‌ی دفاعی اضافه (defense in depth) است، نه جایگزین آن.
const ALLOWED_MESSAGE_REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "😡"];

// ---------- POST /api/chat/conversations/:conversationId/messages/:messageId/reactions ----------
// افزودن/تغییر/حذف (toggle) واکنش ایموجیِ کاربر واردشده روی یک پیام. برخلاف ویرایش/حذفِ
// پیام، اینجا مالکیتِ خودِ پیام بررسی نمی‌شود — هر دو طرفِ مکالمه (بیمار و داکتر) می‌توانند
// به پیام‌های همدیگر (یا حتی پیام‌های خودشان) واکنش نشان دهند؛ فقط دسترسی به مکالمه لازم است.
export async function reactToMessage(req, res) {
  try {
    const existingMessage = await loadAccessibleMessage(req, res);
    if (!existingMessage) return;

    if (existingMessage.isDeleted) {
      return res.status(400).json({ message: "امکان واکنش‌نشان‌دادن به پیام حذف‌شده وجود ندارد" });
    }

    const emoji = (req.body.emoji || "").trim();
    if (!ALLOWED_MESSAGE_REACTIONS.includes(emoji)) {
      return res.status(400).json({ message: "نوع واکنش مجاز نیست" });
    }

    const reactions = await toggleMessageReaction({
      messageId: existingMessage.id,
      userId: req.user.id,
      emoji,
    });

    return res.status(200).json({
      message: "واکنش ثبت شد",
      data: { messageId: existingMessage.id, reactions },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- POST /api/chat/conversations/:conversationId/attachments ----------
// ارسال یک پیام همراه با پیوست (عکس یا سند)؛ متن (content) اختیاری است — یعنی می‌تواند
// «فقط فایل»، یا «فایل + متن» باشد. برای «فقط متن» همان مسیر قبلی (POST /messages) استفاده
// می‌شود. فایل قبلاً توسط multer (uploadChatAttachment) با نام تصادفی امن روی دیسک ذخیره و
// توسط verifyChatAttachmentContent (بررسی امضای باینری) تایید شده است؛ اینجا فقط دسترسی به
// مکالمه بررسی و رکورد پیام ساخته می‌شود. در صورت هر خطا (دسترسی نامعتبر، فایل ارسالی
// وجود ندارد، خطای دیتابیس)، فایل ذخیره‌شده روی دیسک پاک می‌شود تا فایل یتیم باقی نماند.
export async function sendMessageAttachment(req, res) {
  try {
    const { conversationId } = req.params;
    const conversation = await getConversationById(conversationId);
    if (!conversation) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(404).json({ message: "مکالمه یافت نشد" });
    }

    const { allowed } = await ensureConversationAccess(req, conversation);
    if (!allowed) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(403).json({ message: "شما اجازه‌ی دسترسی به این مکالمه را ندارید" });
    }

    if (!(await ensureActiveRelationship(conversation))) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(403).json({
        message: "ارسال پیوست فقط بعد از انجام شدن نوبت امکان‌پذیر است",
        code: "APPOINTMENT_NOT_CONFIRMED",
      });
    }

    if (!req.file) {
      return res.status(400).json({ message: "انتخاب یک فایل الزامی است" });
    }

    const content = (req.body.content || "").trim();

    const message = await createMessageWithAttachment({
      conversationId,
      senderUserId: req.user.id,
      senderRole: req.user.role,
      content,
      attachment: {
        fileName: req.file.filename,
        originalName: sanitizeOriginalFilename(req.file.originalname),
        fileType: req.file.mimetype,
        fileSize: req.file.size,
      },
    });

    // اعلان به طرف مقابل — همان الگوی sendMessage معمولی، هرگز نباید باعث شکست ارسال شود
    try {
      const recipientUserId = req.user.role === "user" ? conversation.doctorUserId : conversation.patientUserId;
      if (recipientUserId) {
        pushChatEvent(recipientUserId, conversation.id);
        const senderName = req.user.role === "user" ? conversation.patientName : conversation.doctorName;
        const preview = content
          ? (content.length > 80 ? `${content.slice(0, 80)}…` : content)
          : "یک پیوست جدید (عکس/سند)";
        await createNotification({
          userId: recipientUserId,
          title: senderName ? `پیام جدید از ${senderName}` : "پیام جدید",
          message: preview,
          type: "chat_message",
          relatedId: conversation.id,
        });
      }
    } catch (err) {
      console.error("خطا در ارسال اعلان پیام جدید:", err.message);
    }

    return res.status(201).json({ message: "پیام با موفقیت ارسال شد", data: toClientMessage(message) });
  } catch (err) {
    if (req.file) fs.unlink(req.file.path, () => {});
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- POST /api/chat/conversations/:conversationId/voice ----------
// ارسال یک پیام صوتی (بدون متن؛ فقط فایل صوتیِ ضبط‌شده در مرورگر کاربر). فایل قبلاً توسط
// multer (uploadChatVoice) با نام تصادفی امن روی دیسک ذخیره و توسط verifyChatVoiceContent
// (بررسی امضای باینری) تایید شده است؛ اینجا فقط دسترسی به مکالمه و مدت‌زمان بررسی و رکورد
// پیام ساخته می‌شود. در صورت هر خطا، فایل ذخیره‌شده روی دیسک پاک می‌شود تا فایل یتیم
// باقی نماند — دقیقاً همان الگوی sendMessageAttachment.
export async function sendVoiceMessage(req, res) {
  try {
    const { conversationId } = req.params;
    const conversation = await getConversationById(conversationId);
    if (!conversation) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(404).json({ message: "مکالمه یافت نشد" });
    }

    const { allowed } = await ensureConversationAccess(req, conversation);
    if (!allowed) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(403).json({ message: "شما اجازه‌ی دسترسی به این مکالمه را ندارید" });
    }

    if (!(await ensureActiveRelationship(conversation))) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(403).json({
        message: "ارسال پیام صوتی فقط بعد از انجام شدن نوبت امکان‌پذیر است",
        code: "APPOINTMENT_NOT_CONFIRMED",
      });
    }

    if (!req.file) {
      return res.status(400).json({ message: "فایل پیام صوتی الزامی است" });
    }

    const duration = Number(req.body.duration);
    if (!Number.isFinite(duration) || duration <= 0 || duration > 300) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ message: "مدت‌زمان پیام صوتی باید بین نیم ثانیه تا ۵ دقیقه باشد" });
    }

    const message = await createMessageWithAttachment({
      conversationId,
      senderUserId: req.user.id,
      senderRole: req.user.role,
      content: "",
      attachment: {
        fileName: req.file.filename,
        originalName: sanitizeOriginalFilename(req.file.originalname || "voice-message"),
        fileType: req.file.mimetype,
        fileSize: req.file.size,
        durationSeconds: duration,
      },
    });

    try {
      const recipientUserId = req.user.role === "user" ? conversation.doctorUserId : conversation.patientUserId;
      if (recipientUserId) {
        pushChatEvent(recipientUserId, conversation.id);
        const senderName = req.user.role === "user" ? conversation.patientName : conversation.doctorName;
        await createNotification({
          userId: recipientUserId,
          title: senderName ? `پیام جدید از ${senderName}` : "پیام جدید",
          message: "🎤 یک پیام صوتی جدید",
          type: "chat_message",
          relatedId: conversation.id,
        });
      }
    } catch (err) {
      console.error("خطا در ارسال اعلان پیام جدید:", err.message);
    }

    return res.status(201).json({ message: "پیام صوتی با موفقیت ارسال شد", data: toClientMessage(message) });
  } catch (err) {
    if (req.file) fs.unlink(req.file.path, () => {});
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- GET /api/chat/conversations/:conversationId/messages/:messageId/attachment ----------
// دانلود/نمایشِ امنِ پیوستِ یک پیام (عکس/سند/پیام صوتی). دسترسی از طریق loadAccessibleMessage
// بررسی می‌شود (بیمار فقط مکالمه‌ی خودش، داکتر فقط مکالمه با بیمارانِ خودش) — یعنی فقط
// طرفینِ همان مکالمه می‌توانند پیوست را ببینند، نه هر کاربر واردشده‌ی دیگری. مسیر فایل با
// path.basename ساخته می‌شود تا مقدار ذخیره‌شده در دیتابیس هرگز بتواند از پوشه‌ی مجاز خارج
// شود (جلوگیری از Path Traversal). عکس و صوت inline سرو می‌شوند (عکس برای پیش‌نمایش، صوت
// برای پخش/جستجو در نوار پیشرفتِ پخش‌کننده که به Range request نیاز دارد و res.sendFile
// به‌صورت پیش‌فرض از آن پشتیبانی می‌کند)؛ اسناد با res.download و نام اصلی فایل سرو می‌شوند.
export async function downloadMessageAttachment(req, res) {
  try {
    const existingMessage = await loadAccessibleMessage(req, res);
    if (!existingMessage) return;

    if (existingMessage.isDeleted || !existingMessage.attachmentFileName) {
      return res.status(404).json({ message: "پیوستی برای این پیام یافت نشد" });
    }

    const filePath = path.join(CHAT_ATTACHMENTS_DIR, path.basename(existingMessage.attachmentFileName));
    if (!fs.existsSync(filePath)) return res.status(404).json({ message: "فایل روی سرور یافت نشد" });

    const fileType = existingMessage.attachmentFileType || "";
    if (fileType.startsWith("image/") || fileType.startsWith("audio/")) {
      return res.sendFile(filePath);
    }
    return res.download(filePath, existingMessage.attachmentOriginalName || "file");
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

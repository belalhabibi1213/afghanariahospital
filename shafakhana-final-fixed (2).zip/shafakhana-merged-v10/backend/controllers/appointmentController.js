import {
  createAppointment, getAppointmentsByUser, countActiveAppointmentsForSlot,
  getAppointmentById, getAppointmentTiming, updateAppointmentStatus, hasActiveAppointmentForPatientSlot, getAppointmentQueueNumber,
} from "../models/Appointment.js";
import { findOrCreatePatient } from "../models/Patient.js";
import { getDoctorById } from "../models/Doctor.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { createNotification } from "../models/Notification.js";
import { notifyStaffOfNewAppointment, notifyStaffOfPatientCancellation } from "../utils/appointmentNotifications.js";
import { getSchedulesByDoctor, getDoctorAvailability, nowInTimeZone } from "../models/Schedule.js";
import { getAllSettings } from "../models/Settings.js";

import { formatJalaliDate } from "../utils/jalali.js";
export async function bookAppointment(req, res) {
  try {
    const { fullName, phone, email, department, doctorId, appointmentDate, appointmentTime, notes } = req.body;

    if (!fullName || !phone || !department || !doctorId || !appointmentDate || !appointmentTime) {
      return res.status(400).json({ message: "لطفاً فیلدهای ضروری فورمه را تکمیل کنید" });
    }

    const doctor = await getDoctorById(doctorId);
    if (!doctor) {
      return res.status(404).json({ message: "داکتر انتخاب‌شده یافت نشد" });
    }

    const normalizedTime = String(appointmentTime).slice(0, 5);

    // یک بیمار (یک حساب کاربری) در هر ساعتِ هر داکتر فقط یک نوبت فعال می‌تواند داشته باشد
    // (پیش‌بررسی سریع؛ محافظت قطعی در برابر کلیک‌های هم‌زمان داخل createAppointment است)
    if (req.user && await hasActiveAppointmentForPatientSlot({
      userId: req.user.id, doctorId, appointmentDate, appointmentTime: normalizedTime,
    })) {
      return res.status(409).json({
        message: "شما یک درخواست نوبت در این ساعت برای این داکتر در جریان دارید",
        code: "ALREADY_BOOKED",
      });
    }

    // تنظیمات نوبت‌دهی (Super Admin → تنظیمات سیستم): بازه‌ی مجاز رزرو از قبل، حالت تایید،
    // و ظرفیت هر ساعت (چند بیمار می‌توانند همان ساعت را از همان داکتر رزرو کنند)
    const settings = await getAllSettings();
    const slotCapacity = Number(settings.appointmentSlotCapacity) || 10;
    const bookingWindowDays = Number(settings.appointmentBookingWindowDays || 0);

    // نوبت برای گذشته ثبت نمی‌شود: نه تاریخ‌های قبل از امروز، و نه ساعت‌هایی از «امروز» که شروعشان
    // گذشته است (بر اساس منطقه‌ی زمانی تنظیمات سیستم). فقط ساعت‌های باقی‌مانده‌ی امروز قابل‌رزرو است.
    const nowZ = nowInTimeZone(settings.timezone);
    if (/^\d{4}-\d{2}-\d{2}$/.test(String(appointmentDate))) {
      if (appointmentDate < nowZ.date) {
        return res.status(400).json({ message: "تاریخ نوبت نمی‌تواند در گذشته باشد", code: "DATE_IN_PAST" });
      }
      if (appointmentDate === nowZ.date && normalizedTime <= nowZ.time) {
        return res.status(400).json({
          message: "این ساعت امروز گذشته است. لطفاً یکی از ساعت‌های باقی‌مانده را انتخاب کنید",
          code: "SLOT_TIME_PASSED",
        });
      }
    }
    if (bookingWindowDays > 0) {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const requestedDate = new Date(`${appointmentDate}T00:00:00`);
      const maxDate = new Date(today);
      maxDate.setDate(maxDate.getDate() + bookingWindowDays);
      if (requestedDate < today || requestedDate > maxDate) {
        return res.status(400).json({
          message: `تاریخ نوبت باید بین امروز و حداکثر ${bookingWindowDays} روز آینده باشد`,
          code: "DATE_OUT_OF_BOOKING_WINDOW",
        });
      }
    }

    // اگر داکتر برنامه کاری تعریف کرده باشد (الزام‌های ۱ تا ۳)، ساعت درخواستی باید
    // دقیقاً یکی از ساعت‌های قابل‌رزروِ همان روز باشد (نه خارج از ساعت کاری، نه در زمان
    // استراحت) — این‌جا هم «نمایش ساعت‌های قابل‌رزرو» و هم «جلوگیری از رزرو بیش از
    // ظرفیت» (الزام‌های ۴ و ۵) در سرور تضمین می‌شود، نه فقط در فرانت‌اند. هر ساعت تا
    // سقف slotCapacity بیمار می‌تواند بپذیرد (نه فقط یک بیمار).
    // برای سازگاری با گذشته: اگر داکتر هنوز هیچ برنامه کاری‌ای تعریف نکرده باشد،
    // رفتار قبلی (فقط بررسی پر نشدن ظرفیت) حفظ می‌شود.
    const doctorSchedules = await getSchedulesByDoctor(doctorId);
    if (doctorSchedules.length > 0) {
      const availability = await getDoctorAvailability(doctorId, appointmentDate, slotCapacity, { timeZone: settings.timezone });
      if (!availability.working) {
        return res.status(400).json({
          message: "داکتر انتخاب‌شده در این روز از هفته فعالیت ندارد. لطفاً روز دیگری انتخاب کنید",
          code: "DAY_NOT_AVAILABLE",
        });
      }
      const slot = availability.slots.find((s) => s.time === normalizedTime);
      if (!slot) {
        return res.status(400).json({
          message: "این ساعت در برنامه کاری داکتر برای این روز وجود ندارد. لطفاً از فهرست ساعت‌های قابل‌رزرو انتخاب کنید",
          code: "SLOT_NOT_IN_SCHEDULE",
        });
      }
      if (!slot.available) {
        return res.status(409).json({
          message: `ظرفیت این ساعت برای داکتر انتخاب‌شده تکمیل شده است (حداکثر ${slotCapacity} بیمار). لطفاً ساعت دیگری انتخاب کنید`,
          code: "SLOT_FULL",
        });
      }
    } else {
      const bookedCount = await countActiveAppointmentsForSlot({ doctorId, appointmentDate, appointmentTime });
      if (bookedCount >= slotCapacity) {
        return res.status(409).json({
          message: `ظرفیت این ساعت برای داکتر انتخاب‌شده تکمیل شده است (حداکثر ${slotCapacity} بیمار). لطفاً ساعت دیگری انتخاب کنید`,
          code: "SLOT_FULL",
        });
      }
    }

    const userId = req.user ? req.user.id : null;

    const patient = await findOrCreatePatient({ fullName, phone, email, userId });

    let appointment;
    const created = await createAppointment({
      patientId: patient.id,
      doctorId,
      department,
      appointmentDate,
      appointmentTime,
      notes,
      status: settings.appointmentApprovalMode === "auto" ? "confirmed" : undefined,
      capacity: slotCapacity,
      userId,
    });
    if (created.error === "ALREADY_BOOKED") {
      return res.status(409).json({
        message: "شما یک درخواست نوبت در این ساعت برای این داکتر در جریان دارید",
        code: "ALREADY_BOOKED",
      });
    }
    if (created.error === "SLOT_FULL") {
      // محافظت نهایی در برابر شرایط رقابتی (Race Condition): حتی اگر بررسی‌های بالا
      // این درخواست را رد نکرده باشند، این بررسی داخل تراکنش با قفل ردیف تضمین
      // می‌کند ظرفیت هرگز بیش از slotCapacity پر نشود — مثلاً وقتی چند بیمار دقیقاً
      // هم‌زمان آخرین جای خالی همان ساعت را درخواست می‌کنند.
      return res.status(409).json({
        message: `ظرفیت این ساعت هم‌زمان توسط بیماران دیگر تکمیل شد (حداکثر ${slotCapacity} بیمار). لطفاً ساعت دیگری انتخاب کنید`,
        code: "SLOT_FULL",
      });
    }
    appointment = created;

    await logActivity({
      req,
      userId,
      userName: fullName,
      role: req.user ? req.user.role : "guest",
      action: "ثبت نوبت جدید",
      details: `داکتر: ${doctor.fullName} | بخش: ${department} | تاریخ: ${formatJalaliDate(appointmentDate, { latin: true })} ${appointmentTime}`,
    });
    await recordAudit({
      req, tableName: "appointments", recordId: appointment.id, action: "INSERT", oldValues: null, newValues: appointment,
      userId, userName: fullName, role: req.user ? req.user.role : "guest",
    });

    // اگر کاربر واردشده بود (نه مهمان)، یک اعلان درون‌برنامه‌ای برای او ثبت می‌شود
    await createNotification({
      userId,
      title: "ثبت نوبت جدید",
      message: settings.appointmentApprovalMode === "auto"
        ? `نوبت شما نزد ${doctor.fullName} برای تاریخ ${formatJalaliDate(appointmentDate, { month: "long" })} ساعت ${appointmentTime} با موفقیت ثبت و تایید شد.`
        : `نوبت شما نزد ${doctor.fullName} برای تاریخ ${formatJalaliDate(appointmentDate, { month: "long" })} ساعت ${appointmentTime} با موفقیت ثبت شد و در انتظار تایید است.`,
      type: "appointment",
      relatedId: appointment.id,
    });

    // اطلاع‌رسانی فوری به داکتر مربوطه و همه‌ی ادمین‌ها/مدیران کل — تا نوبت‌های
    // «در انتظار تایید» بلافاصله در زنگوله‌ی اعلان‌شان دیده شود و لازم نباشد منتظر
    // بمانند تا خودشان تب نوبت‌ها را باز کنند
    await notifyStaffOfNewAppointment({
      appointmentId: appointment.id,
      doctor,
      patientName: fullName,
      appointmentDate,
      appointmentTime,
      isAutoConfirmed: settings.appointmentApprovalMode === "auto",
    });

    const queueNumber = await getAppointmentQueueNumber({ id: appointment.id, doctorId, appointmentDate, appointmentTime });

    return res.status(201).json({
      message: "وقت شما با موفقیت در سیستم ثبت شد",
      appointment: { ...appointment, doctorName: doctor.fullName, patientName: fullName, queueNumber },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function myAppointments(req, res) {
  try {
    const appointments = await getAppointmentsByUser(req.user.id);
    return res.status(200).json({ appointments });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// لغو نوبت توسط خودِ بیمار — فقط نوبت‌های «در انتظار» یا «تایید شده»‌ی خودش و فقط تا
// appointmentCancelMinHours ساعت قبل از زمان نوبت (تنظیم Super Admin). با لغو، ظرفیت آن ساعت
// خودکار آزاد می‌شود (چون ظرفیت فقط نوبت‌های pending/confirmed را می‌شمارد).
export async function cancelMyAppointment(req, res) {
  try {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || id <= 0) {
      return res.status(400).json({ message: "شناسه‌ی نوبت نامعتبر است" });
    }

    const appointment = await getAppointmentById(id);
    // نوبتِ دیگران هم با همان پیام «یافت نشد» پاسخ داده می‌شود تا وجودش لو نرود
    if (!appointment || appointment.patientUserId !== req.user.id) {
      return res.status(404).json({ message: "نوبت یافت نشد" });
    }
    if (!["pending", "confirmed"].includes(appointment.status)) {
      return res.status(409).json({ message: "این نوبت قابل لغو نیست", code: "NOT_CANCELLABLE" });
    }

    const timing = await getAppointmentTiming(id);
    if (!timing || timing.minutesUntil <= 0) {
      return res.status(409).json({ message: "زمان این نوبت گذشته است و قابل لغو نیست", code: "APPOINTMENT_PASSED" });
    }
    const settings = await getAllSettings();
    const minHours = Number(settings.appointmentCancelMinHours) || 0;
    if (minHours > 0 && timing.minutesUntil < minHours * 60) {
      return res.status(409).json({
        message: `لغو نوبت فقط تا ${minHours} ساعت قبل از زمان نوبت ممکن است. لطفاً با شفاخانه تماس بگیرید`,
        code: "TOO_LATE_TO_CANCEL",
      });
    }

    const updated = await updateAppointmentStatus(id, "cancelled", {
      changedByUserId: req.user.id,
      changedByRole: req.user.role,
      note: "لغو توسط بیمار",
    });

    await logActivity({
      req,
      userId: req.user.id,
      userName: req.user.fullName,
      role: req.user.role,
      action: "لغو نوبت توسط بیمار",
      details: `داکتر: ${appointment.doctorName} | تاریخ: ${timing.dateStr} ${timing.timeStr}`,
    });
    await recordAudit({
      req, tableName: "appointments", recordId: id, action: "UPDATE",
      oldValues: { status: appointment.status }, newValues: { status: "cancelled" },
      userId: req.user.id, userName: req.user.fullName, role: req.user.role,
    });

    await createNotification({
      userId: req.user.id,
      title: "نوبت شما لغو شد",
      message: `نوبت شما نزد ${appointment.doctorName} برای تاریخ ${timing.dateStr} ساعت ${timing.timeStr} به درخواست خودتان لغو شد.`,
      type: "appointment",
      relatedId: id,
    });
    const doctor = await getDoctorById(appointment.doctorId);
    if (doctor) {
      await notifyStaffOfPatientCancellation({
        appointmentId: id,
        doctor,
        patientName: appointment.patientName,
        appointmentDate: timing.dateStr,
        appointmentTime: timing.timeStr,
      });
    }

    return res.status(200).json({ message: "نوبت شما لغو شد", appointment: updated });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در لغو نوبت" });
  }
}

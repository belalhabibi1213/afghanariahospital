import { getPatientById, doctorHasConfirmedPatient } from "../models/Patient.js";
import { getDoctorByUserId, getDoctorById } from "../models/Doctor.js";
import {
  createRecord, getRecordById, getRecordsByPatientId, updateRecord, deleteRecord, getRecordsByPatientUser,
  getMedicalHistoryTimelineForPatientUser,
  getTimelineEventDetailForPatientUser,
} from "../models/MedicalRecord.js";
import {
  createDiagnosis, getDiagnosisById, getDiagnosesByPatientId, getDiagnosesByPatientUser, updateDiagnosis, deleteDiagnosis,
} from "../models/Diagnosis.js";
import {
  createPrescription, getPrescriptionById, getPrescriptionsByPatientId, getPrescriptionsByPatientUser,
  updatePrescription, deletePrescription, getPrescriptionsByGroup, getPrescriptionsByAppointmentId, getPrescriptionsByAppointmentForPatientUser,
  getPrescriptionByIdForPatientUser, getGroupStatus, searchPrescriptionGroups,
} from "../models/Prescription.js";
import { sendPrescriptionPdf } from "../utils/prescriptionPdf.js";
import { getAppointmentById } from "../models/Appointment.js";
import {
  createAllergy, getAllergyById, getAllergiesByPatientId, getAllergiesByPatientUser, updateAllergy, deleteAllergy,
} from "../models/Allergy.js";
import {
  createLabResult, getLabResultById, getLabResultsByPatientId, getLabResultsByPatientUser,
  getLabResultByIdForPatientUser, updateLabResult, deleteLabResult, setLabReportUrl,
} from "../models/LabResult.js";
import {
  createRadiologyReport, getRadiologyReportById, getRadiologyReportsByPatientId, getRadiologyReportsByPatientUser, updateRadiologyReport, deleteRadiologyReport,
} from "../models/RadiologyReport.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { trackPatientRecordAccess } from "../utils/accessMonitor.js";
import { createNotification } from "../models/Notification.js";
import { LAB_REPORTS_DIR, MEDICAL_FILES_DIR } from "../middleware/upload.js";
import { getStoredNamesByRecordId } from "../models/MedicalRecordFile.js";
import fs from "fs";
import path from "path";

export const logEmr = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

// ثبت لاگ حسابرسی (audit_logs) برای تغییرات پرونده صحی (EMR)
export const auditEmr = (req, tableName, recordId, action, oldValues, newValues) =>
  recordAudit({
    req, tableName, recordId, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });

// اعلان به بیمار وقتی داکتر نسخه یا سابقه طبی جدید برایش ثبت می‌کند (اتصال پرونده داکتر به داشبورد بیمار — الزام شماره ۵)
// اگر بیمار حساب کاربری نداشته باشد (userId خالی)، بی‌صدا رد می‌شود؛ createNotification خودش خطاهایش را لاگ می‌کند
// و هرگز باعث شکست درخواست اصلی ثبت نسخه/رکورد نمی‌شود.
export async function notifyPatientOfNewRecord(patient, type, relatedId) {
  if (!patient?.userId) return;
  await createNotification({
    userId: patient.userId,
    title: "به‌روزرسانی پرونده صحی",
    message: "Your doctor has added a new prescription or medical record.",
    type,
    relatedId,
  });
}

// اگر کاربر واردشده «داکتر» است، پروفایل داکتر متصل به حسابش را برمی‌گرداند؛
// در غیر این صورت (ادمین/سوپرادمین) null برمی‌گرداند چون نیازی به مالکیت ندارند
export async function resolveActingDoctor(req) {
  if (req.user.role !== "doctor") return null;
  return getDoctorByUserId(req.user.id);
}

// بررسی می‌کند که آیا کاربر واردشده اجازه‌ی ویرایش/حذف یک آیتم مشخص از پرونده را دارد یا نه.
// ادمین/سوپرادمین همیشه اجازه دارند؛ داکتر فقط روی آیتم‌هایی که خودش ثبت کرده.
export function canManage(req, actingDoctor, item) {
  if (req.user.role === "admin" || req.user.role === "superadmin") return true;
  if (req.user.role === "doctor" && actingDoctor) return item.doctorId === actingDoctor.id;
  return false;
}

async function ensurePatientExists(patientId) {
  const patient = await getPatientById(patientId);
  return patient;
}

// بررسی می‌کند که آیا کاربر واردشده اجازه دارد به پرونده‌ی این بیمار دسترسی داشته باشد یا در آن ثبت کند.
// ادمین/سوپرادمین فقط «مشاهده» دارند (مسیرهای نوشتن در routes فقط برای داکتر باز است)؛ داکتر فقط برای
// بیمارانی که نوبتشان با او «تأییدشده/انجام‌شده» است. نوبت در انتظار/لغوشده/ردشده کافی نیست — وگرنه هر بیمار
// (یا کسی که ایمیل او را می‌داند) با ثبت یک نوبت معلق می‌توانست کل پرونده‌ی صحی را در اختیار هر داکتر بگذارد.
export async function ensureDoctorOwnsPatient(req, actingDoctor, patientId) {
  if (req.user.role === "admin" || req.user.role === "superadmin") return true;
  if (req.user.role === "doctor" && actingDoctor) {
    return doctorHasConfirmedPatient(actingDoctor.id, patientId);
  }
  return false;
}

// بررسی شناسه‌های وابسته‌ی بدنه (recordId / appointmentId): باید متعلق به همان بیمار باشند، و برای داکتر،
// نوبت باید نوبت خودش باشد. بدون این بررسی، با دست‌کاری ID در body می‌شد نسخه/تشخیص را به ویزیت یا نوبت
// بیمار دیگر (یا داکتر دیگر) چسباند. خروجی: null یا { status, message }.
export async function validateLinkedIds(req, actingDoctor, patientId) {
  const { recordId, appointmentId } = req.body || {};
  if (recordId) {
    const record = await getRecordById(recordId);
    if (!record || Number(record.patientId) !== Number(patientId)) {
      return { status: 400, message: "ویزیت انتخاب‌شده متعلق به این بیمار نیست" };
    }
  }
  if (appointmentId) {
    const appointment = await getAppointmentById(appointmentId);
    if (!appointment) return { status: 404, message: "نوبت مرتبط یافت نشد" };
    if (Number(appointment.patientId) !== Number(patientId)) {
      return { status: 400, message: "این نوبت متعلق به بیمار انتخاب‌شده نیست" };
    }
    if (req.user.role === "doctor" && actingDoctor && Number(appointment.doctorId) !== Number(actingDoctor.id)) {
      return { status: 403, message: "این نوبت متعلق به شما نیست" };
    }
  }
  return null;
}

// ---------- پرونده کامل یک بیمار (برای پنل داکتر/ادمین) ----------
// GET /api/medical-records/patient/:patientId
export async function getPatientEmr(req, res) {
  try {
    const { patientId } = req.params;

    const actingDoctor = await resolveActingDoctor(req);
    if (req.user.role === "doctor" && !actingDoctor) {
      return res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    }
    // ابتدا مجوز، بعد وجود: برای داکتر، بیمارِ ناموجود و بیمارِ غیرمجاز پاسخ یکسان ۴۰۳ می‌گیرند
    // تا نتوان با شمردن شناسه‌ها فهمید کدام بیمار وجود دارد.
    const allowed = await ensureDoctorOwnsPatient(req, actingDoctor, patientId);
    if (!allowed) {
      return res.status(403).json({ message: "شما فقط به پرونده‌ی بیمارانِ خودتان دسترسی دارید" });
    }
    const patient = await ensurePatientExists(patientId);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });

    const [encounters, diagnoses, prescriptions, allergies, labResults, radiologyReports] = await Promise.all([
      getRecordsByPatientId(patientId),
      getDiagnosesByPatientId(patientId),
      getPrescriptionsByPatientId(patientId),
      getAllergiesByPatientId(patientId),
      getLabResultsByPatientId(patientId),
      getRadiologyReportsByPatientId(patientId),
    ]);

    await logEmr(req, "مشاهده پرونده الکترونیک صحی بیمار", `patientId=${patientId}`);
    trackPatientRecordAccess(req, patientId);

    return res.status(200).json({
      patient,
      // داکتر واردشده (برای پیش‌پر کردن «داکتر / بخش» در فرم افزودن پرونده صحی)؛ برای ادمین null است
      doctor: actingDoctor ? { id: actingDoctor.id, fullName: actingDoctor.fullName, department: actingDoctor.department } : null,
      encounters,
      diagnoses,
      prescriptions,
      allergies,
      labResults,
      radiologyReports,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- پرونده کامل بیمارِ واردشده، فقط برای خودش (الزام شماره ۸) ----------
// GET /api/users/emr
export async function getMyEmr(req, res) {
  try {
    const [encounters, diagnoses, prescriptions, allergies, labResults, radiologyReports] = await Promise.all([
      getRecordsByPatientUser(req.user.id),
      getDiagnosesByPatientUser(req.user.id),
      getPrescriptionsByPatientUser(req.user.id),
      getAllergiesByPatientUser(req.user.id),
      getLabResultsByPatientUser(req.user.id, { status: "completed" }),
      getRadiologyReportsByPatientUser(req.user.id),
    ]);

    return res.status(200).json({ encounters, diagnoses, prescriptions, allergies, labResults, radiologyReports });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// خط زمانی سابقه صحی بیمار (ترکیب نسخه‌ها + ویزیت‌ها) با جستجو، فیلتر بازه‌ی تاریخ
// و صفحه‌بندی — همیشه فقط برای پرونده‌ی خودِ بیمار (req.user.id)
export async function getMyMedicalHistoryTimeline(req, res) {
  try {
    const { q, type, dateFrom, dateTo, page, limit } = req.query;
    const result = await getMedicalHistoryTimelineForPatientUser({
      userId: req.user.id, q, type, dateFrom, dateTo, page, limit,
    });
    return res.status(200).json({
      items: result.rows,
      pagination: { total: result.total, page: result.page, limit: result.limit, totalPages: result.totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// جزئیات یک رویداد خط زمانی — GET /api/users/medical-history/:type/:id
// مالکیت از روی توکن (req.user.id) در کوئری اعمال می‌شود؛ رکورد مال بیمار دیگر = ۴۰۴ (نه ۴۰۳، تا وجودش لو نرود)
export async function getMyTimelineEventDetail(req, res) {
  try {
    const detail = await getTimelineEventDetailForPatientUser({
      type: req.params.type, id: req.params.id, userId: req.user.id,
    });
    if (!detail) return res.status(404).json({ message: "رکورد یافت نشد" });
    return res.status(200).json({ detail });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- فیلدهای فرم «افزودن پرونده صحی» (ستون‌های اضافه‌شده روی medical_records) ----------
const SYSTEM_KEYS = ["cardiovascular", "respiratory", "gastrointestinal", "neurological", "musculoskeletal", "skin", "ent", "genitourinary"];
const RECOMMENDATION_KEYS = ["advice", "care", "diet", "rest", "tests", "other"];
const EXTRA_BODY_KEYS = [
  "visitReason", "chiefComplaint", "pulse", "respiratoryRate", "spo2", "generalCondition", "examFindings",
  "abnormalFindings", "examNotes", "primaryDiagnosis", "diagnosisNotes", "followUpDate", "followUpStatus", "followUpNotes",
];

// ورودی کلاینت را به شکل امن برای ذخیره درمی‌آورد: فقط کلیدهای مجاز، رشته‌ها کوتاه‌شده، JSONها استاندارد.
// undefined = «دست نزن»، رشته‌ی خالی = «پاک کن» (قرارداد updateRecord).
function normalizeEncounterExtras(body) {
  const out = {};
  for (const k of EXTRA_BODY_KEYS) if (body[k] !== undefined) out[k] = body[k] === null ? "" : String(body[k]).trim();
  if (body.status === "draft" || body.status === "registered") out.status = body.status;
  if (body.followUpRequired !== undefined) out.followUpRequired = body.followUpRequired === true || body.followUpRequired === "true" || body.followUpRequired === 1;
  if (body.systemsReview !== undefined) {
    const src = body.systemsReview && typeof body.systemsReview === "object" ? body.systemsReview : {};
    const clean = {};
    for (const key of SYSTEM_KEYS) {
      const v = src[key];
      if (v && typeof v === "object" && (v.abnormal === true || String(v.note || "").trim())) {
        clean[key] = { abnormal: v.abnormal === true, note: String(v.note || "").trim().slice(0, 500) };
      }
    }
    out.systemsReview = Object.keys(clean).length ? JSON.stringify(clean) : "";
  }
  if (body.recommendations !== undefined) {
    const src = body.recommendations && typeof body.recommendations === "object" ? body.recommendations : {};
    const clean = {};
    for (const key of RECOMMENDATION_KEYS) {
      const v = String(src[key] || "").trim().slice(0, 3000);
      if (v) clean[key] = v;
    }
    out.recommendations = Object.keys(clean).length ? JSON.stringify(clean) : "";
  }
  return out;
}

export function parseJsonField(value) {
  if (!value) return null;
  try { return JSON.parse(value); } catch { return null; }
}

// ---------- ویزیت‌ها/رکورد کلی (medical_records) ----------

export async function addEncounter(req, res) {
  try {
    const {
      patientId, appointmentId, visitDate,
      symptoms, diagnosis, bloodPressure, temperature, height, weight, labResults, treatment,
      prescription, notes,
    } = req.body;
    const extras = normalizeEncounterExtras(req.body);
    // ثبت نهایی (status = registered، صریح) باید دلیل مراجعه داشته باشد؛ پیش‌نویس می‌تواند ناقص باشد
    if (extras.status === "registered" && !extras.visitReason) {
      return res.status(400).json({ message: "دلیل اصلی مراجعه برای ثبت نهایی الزامی است" });
    }

    const actingDoctor = await resolveActingDoctor(req);
    if (req.user.role === "doctor" && !actingDoctor) {
      return res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    }
    const allowed = await ensureDoctorOwnsPatient(req, actingDoctor, patientId);
    if (!allowed) {
      return res.status(403).json({ message: "شما فقط می‌توانید برای بیمارانِ خودتان ویزیت ثبت کنید" });
    }
    const patient = await ensurePatientExists(patientId);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    const linkError = await validateLinkedIds(req, actingDoctor, patientId);
    if (linkError) return res.status(linkError.status).json({ message: linkError.message });

    const record = await createRecord({
      patientId,
      doctorId: actingDoctor ? actingDoctor.id : null,
      appointmentId,
      visitDate,
      symptoms,
      diagnosis,
      bloodPressure,
      temperature,
      height,
      weight,
      labResults,
      treatment,
      prescription,
      notes,
      ...extras,
    });
    const isDraft = record.status === "draft";
    await logEmr(req, isDraft ? "ذخیره پیش‌نویس پرونده صحی" : "ثبت ویزیت جدید در پرونده صحی", `patientId=${patientId} recordId=${record.id}`);
    await auditEmr(req, "medical_records", record.id, "INSERT", null, record);
    // پیش‌نویس هرگز برای بیمار دیده نمی‌شود و اعلانی هم ندارد
    if (!isDraft) await notifyPatientOfNewRecord(patient, "medical_record", record.id);
    return res.status(201).json({ message: isDraft ? "پیش‌نویس ذخیره شد" : "ویزیت با موفقیت ثبت شد", record });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function editEncounter(req, res) {
  try {
    const existing = await getRecordById(req.params.id);
    if (!existing) return res.status(404).json({ message: "رکورد یافت نشد" });

    const actingDoctor = await resolveActingDoctor(req);
    if (!canManage(req, actingDoctor, existing)) {
      return res.status(403).json({ message: "شما اجازه‌ی ویرایش این رکورد را ندارید" });
    }

    const {
      visitDate, symptoms, diagnosis, bloodPressure, temperature, height, weight, labResults, treatment,
      prescription, notes,
    } = req.body;
    const extras = normalizeEncounterExtras(req.body);
    const wasDraft = existing.status === "draft";
    if (extras.status === "draft" && !wasDraft) {
      return res.status(400).json({ message: "پرونده ثبت‌شده به پیش‌نویس برنمی‌گردد" });
    }
    const becomingRegistered = wasDraft && extras.status === "registered";
    if (becomingRegistered && !(extras.visitReason || existing.visitReason)) {
      return res.status(400).json({ message: "دلیل اصلی مراجعه برای ثبت نهایی الزامی است" });
    }
    const record = await updateRecord(req.params.id, {
      visitDate, symptoms, diagnosis, bloodPressure, temperature, height, weight, labResults, treatment,
      prescription, notes, ...extras,
    });
    await logEmr(req, becomingRegistered ? "ثبت نهایی پرونده صحی (از پیش‌نویس)" : "ویرایش ویزیت پرونده صحی", `recordId=${req.params.id}`);
    await auditEmr(req, "medical_records", req.params.id, "UPDATE", existing, record);
    // اولین بار که پیش‌نویس ثبت نهایی می‌شود، مثل ثبت مستقیم، به بیمار اعلان می‌رسد
    if (becomingRegistered) {
      const patient = await ensurePatientExists(existing.patientId);
      if (patient) await notifyPatientOfNewRecord(patient, "medical_record", record.id);
    }
    return res.status(200).json({ message: "ویزیت به‌روزرسانی شد", record });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// حذف ویزیت (پرونده صحی) — فقط توسط داکترِ ثبت‌کننده‌ی همان ویزیت (مسیر فقط برای نقش داکتر باز است).
// آزمایش/نسخه/تشخیص‌های متصل به این ویزیت حذف نمی‌شوند؛ طبق FK (ON DELETE SET NULL) فقط ارتباطشان
// با ویزیت قطع می‌شود و همچنان در پرونده‌ی بیمار باقی می‌مانند.
export async function removeEncounter(req, res) {
  try {
    const existing = await getRecordById(req.params.id);
    if (!existing) return res.status(404).json({ message: "رکورد یافت نشد" });

    const actingDoctor = await resolveActingDoctor(req);
    if (!actingDoctor || existing.doctorId !== actingDoctor.id) {
      return res.status(403).json({ message: "شما اجازه‌ی حذف این رکورد را ندارید" });
    }

    // فایل‌های پیوست روی دیسک (تصاویر/اسناد) پیش از حذف رکورد پاک می‌شوند؛ ردیف‌های DB با CASCADE حذف می‌شوند
    const storedNames = await getStoredNamesByRecordId(req.params.id);
    await deleteRecord(req.params.id);
    storedNames.forEach((name) => fs.unlink(path.join(MEDICAL_FILES_DIR, path.basename(name)), () => {}));
    await logEmr(req, "حذف ویزیت پرونده صحی", `recordId=${req.params.id}`);
    await auditEmr(req, "medical_records", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "پرونده صحی حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- کارخانه‌ی عمومی CRUD برای هر یک از زیرمجموعه‌های پرونده صحی ----------
// چون منطق ثبت/ویرایش/حذف برای تشخیص، نسخه، حساسیت، آزمایش و رادیولوژی یکسان است
// (فقط فیلدها فرق دارند)، این تابع کمکی از تکرار کد جلوگیری می‌کند.
function buildEmrResourceHandlers({
  entityLabel, tableName, createFn, getByIdFn, updateFn, deleteFn, pickCreateFields, pickUpdateFields, validateCreate, validateUpdate, afterCreate,
}) {
  const add = async (req, res) => {
    try {
      const { patientId } = req.body;

      const actingDoctor = await resolveActingDoctor(req);
      if (req.user.role === "doctor" && !actingDoctor) {
        return res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
      }
      const allowed = await ensureDoctorOwnsPatient(req, actingDoctor, patientId);
      if (!allowed) {
        return res.status(403).json({ message: "شما فقط می‌توانید برای بیمارانِ خودتان ثبت کنید" });
      }
      const patient = await ensurePatientExists(patientId);
      if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
      const linkError = await validateLinkedIds(req, actingDoctor, patientId);
      if (linkError) return res.status(linkError.status).json({ message: linkError.message });

      if (validateCreate) {
        const validationError = await validateCreate(req);
        if (validationError) return res.status(validationError.status).json({ message: validationError.message });
      }

      const item = await createFn({
        ...pickCreateFields(req.body),
        patientId,
        doctorId: actingDoctor ? actingDoctor.id : null,
      });
      await logEmr(req, `ثبت ${entityLabel} جدید`, `patientId=${patientId} id=${item.id}`);
      await auditEmr(req, tableName, item.id, "INSERT", null, item);
      if (afterCreate) await afterCreate(item, patient);
      return res.status(201).json({ message: `${entityLabel} با موفقیت ثبت شد`, item });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
    }
  };

  const edit = async (req, res) => {
    try {
      const existing = await getByIdFn(req.params.id);
      if (!existing) return res.status(404).json({ message: "رکورد یافت نشد" });

      const actingDoctor = await resolveActingDoctor(req);
      if (!canManage(req, actingDoctor, existing)) {
        return res.status(403).json({ message: "شما اجازه‌ی ویرایش این رکورد را ندارید" });
      }
      if (validateUpdate) {
        const validationError = await validateUpdate(req, existing);
        if (validationError) return res.status(validationError.status).json({ message: validationError.message });
      }

      const item = await updateFn(req.params.id, pickUpdateFields(req.body));
      await logEmr(req, `ویرایش ${entityLabel}`, `id=${req.params.id}`);
      await auditEmr(req, tableName, req.params.id, "UPDATE", existing, item);
      return res.status(200).json({ message: `${entityLabel} به‌روزرسانی شد`, item });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
    }
  };

  const remove = async (req, res) => {
    try {
      const existing = await getByIdFn(req.params.id);
      if (!existing) return res.status(404).json({ message: "رکورد یافت نشد" });

      const actingDoctor = await resolveActingDoctor(req);
      if (!canManage(req, actingDoctor, existing)) {
        return res.status(403).json({ message: "شما اجازه‌ی حذف این رکورد را ندارید" });
      }

      await deleteFn(req.params.id);
      await logEmr(req, `حذف ${entityLabel}`, `id=${req.params.id}`);
      await auditEmr(req, tableName, req.params.id, "DELETE", existing, null);
      return res.status(200).json({ message: `${entityLabel} حذف شد` });
    } catch (err) {
      console.error(err);
      return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
    }
  };

  return { add, edit, remove };
}

// ---------- تشخیص‌ها (Diagnoses) ----------
const diagnosisHandlers = buildEmrResourceHandlers({
  entityLabel: "تشخیص",
  tableName: "diagnoses",
  createFn: createDiagnosis,
  getByIdFn: getDiagnosisById,
  updateFn: updateDiagnosis,
  deleteFn: deleteDiagnosis,
  pickCreateFields: ({ recordId, title, description, icdCode, status }) => ({ recordId, title, description, icdCode, status }),
  pickUpdateFields: ({ title, description, icdCode, status }) => ({ title, description, icdCode, status }),
});
export const addDiagnosis = diagnosisHandlers.add;
export const editDiagnosis = diagnosisHandlers.edit;
export const removeDiagnosis = diagnosisHandlers.remove;

// ---------- نسخه‌ها (Prescriptions) ----------
const prescriptionHandlers = buildEmrResourceHandlers({
  entityLabel: "نسخه",
  tableName: "prescriptions",
  createFn: createPrescription,
  getByIdFn: getPrescriptionById,
  updateFn: updatePrescription,
  deleteFn: deletePrescription,
  pickCreateFields: ({ recordId, appointmentId, diagnosis, medicationName, dosage, frequency, duration, quantity, medicineNotes, instructions, followUpDate, notes, groupId }) => ({
    recordId, appointmentId, diagnosis, medicationName, dosage, frequency, duration, quantity, medicineNotes, instructions, followUpDate, notes, groupId,
  }),
  pickUpdateFields: ({ diagnosis, medicationName, dosage, frequency, duration, quantity, medicineNotes, instructions, followUpDate, notes, groupId }) => ({
    diagnosis, medicationName, dosage, frequency, duration, quantity, medicineNotes, instructions, followUpDate, notes, groupId,
  }),
  // نسخه‌ی «تکمیل‌شده» یا «لغوشده» (وضعیت را ادمین تعیین می‌کند) دیگر توسط داکتر ویرایش نمی‌شود.
  // ادمین/سوپرادمین از این قفل مستثنی هستند. این بررسی سمت سرور است؛ مخفی‌کردن دکمه کافی نیست.
  validateUpdate: async (req, existing) => {
    if (req.user.role === "doctor" && existing.status && existing.status !== "active") {
      return { status: 409, message: "نسخه‌ی تکمیل‌شده یا لغوشده قابل ویرایش نیست" };
    }
    return null;
  },
  validateCreate: async (req) => {
    const { appointmentId, patientId, groupId } = req.body;
    // افزودن دارو به نسخه‌ای که قفل شده (تکمیل/لغو) هم مجاز نیست
    if (groupId && req.user.role === "doctor") {
      const groupStatus = await getGroupStatus(groupId, patientId);
      if (groupStatus && groupStatus !== "active") {
        return { status: 409, message: "به نسخه‌ی تکمیل‌شده یا لغوشده نمی‌توان دارو اضافه کرد" };
      }
    }
    if (!appointmentId) return null;
    const appointment = await getAppointmentById(appointmentId);
    if (!appointment) return { status: 404, message: "نوبت مرتبط یافت نشد" };
    if (Number(appointment.patientId) !== Number(patientId)) {
      return { status: 400, message: "این نوبت متعلق به بیمار انتخاب‌شده نیست" };
    }
    return null;
  },
  // یک نسخه‌ی چنددارویی فقط یک اعلان می‌سازد (برای داروی اول گروه)، نه یک اعلان برای هر دارو
  afterCreate: async (item, patient) => {
    if (item.groupId && (await getPrescriptionsByGroup(item)).length > 1) return;
    await notifyPatientOfNewRecord(patient, "prescription", item.id);
  },
});
export const addPrescription = prescriptionHandlers.add;
export const editPrescription = prescriptionHandlers.edit;
export const removePrescription = prescriptionHandlers.remove;

// نسخه‌ی کامل یک نوبت مشخص (همه‌ی داروهای آن ویزیت) — برای پنل داکتر/ادمین
export async function getPrescriptionsForAppointment(req, res) {
  try {
    const appointment = await getAppointmentById(req.params.appointmentId);
    const actingDoctor = await resolveActingDoctor(req);
    if (req.user.role === "doctor") {
      // پیش‌تر هیچ بررسی مالکیتی وجود نداشت: هر داکتری با حدس‌زدن شناسه‌ی نوبت، نسخه‌ی هر بیماری را می‌خواند.
      // نوبتِ ناموجود و نوبتِ غیرمجاز یک پاسخ یکسان می‌گیرند.
      const permitted = actingDoctor && appointment
        && (await doctorHasConfirmedPatient(actingDoctor.id, appointment.patientId));
      if (!permitted) return res.status(403).json({ message: "شما فقط به نوبت‌های بیمارانِ خودتان دسترسی دارید" });
    }
    if (!appointment) return res.status(404).json({ message: "نوبت یافت نشد" });
    const prescriptions = await getPrescriptionsByAppointmentId(req.params.appointmentId);
    return res.status(200).json({ appointment, prescriptions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// خروجی PDF یک نسخه برای پنل داکتر/ادمین (چاپ نسخه — الزام شماره ۱ و ۲).
// همان قانون مالکیت ویرایش/حذف اینجا هم اعمال می‌شود: داکتر فقط نسخه‌ای را که
// خودش ثبت کرده می‌تواند دانلود کند؛ ادمین/سوپرادمین به همه‌ی نسخه‌ها دسترسی دارند.
export async function downloadPrescriptionPdf(req, res) {
  try {
    const existing = await getPrescriptionById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نسخه یافت نشد" });

    const actingDoctor = await resolveActingDoctor(req);
    if (!canManage(req, actingDoctor, existing)) {
      return res.status(403).json({ message: "شما اجازه‌ی دسترسی به این نسخه را ندارید" });
    }

    await logEmr(req, "دانلود PDF نسخه", `prescriptionId=${existing.id}`);
    // اگر این دارو همراه داروهای دیگر در یک بار ثبت نوشته شده، همه‌ی آن‌ها در همین PDF می‌آیند
    await sendPrescriptionPdf(res, existing, await getPrescriptionsByGroup(existing));
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- دسترسی بیمار به نسخه‌های خودش (مشاهده/چاپ — الزام شماره ۳ و ۴) ----------

// تاریخچه‌ی کامل نسخه‌های بیمار واردشده
export async function getMyPrescriptions(req, res) {
  try {
    const prescriptions = await getPrescriptionsByPatientUser(req.user.id);
    return res.status(200).json({ prescriptions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// نسخه‌ی مربوط به یک نوبت مشخص، فقط اگر آن نوبت متعلق به خودِ بیمار باشد (برای مشاهده/چاپ)
export async function getMyPrescriptionForAppointment(req, res) {
  try {
    const prescriptions = await getPrescriptionsByAppointmentForPatientUser(req.params.appointmentId, req.user.id);
    if (prescriptions.length === 0) {
      return res.status(404).json({ message: "نسخه‌ای برای این نوبت یافت نشد" });
    }
    return res.status(200).json({ prescriptions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// فهرست نسخه‌های بیمارِ واردشده به‌صورت گروه‌بندی‌شده (یک ردیف برای هر نسخه) با جستجو/فیلتر/صفحه‌بندی.
// GET /api/users/prescription-list
// مالکیت: patientUserId فقط از توکن گرفته می‌شود؛ patientId/doctorId/patientUserId در query نادیده‌اند.
// فقط فیلدهای لازم برای نمایش به بیمار برگردانده می‌شود (بدون شناسه‌ی داخلی بیمار/داکتر).
export async function getMyPrescriptionList(req, res) {
  try {
    const { q, status, dateFrom, dateTo, page, limit } = req.query;
    const result = await searchPrescriptionGroups({
      q, status, dateFrom, dateTo, page, limit,
      patientUserId: req.user.id,
    });
    const prescriptions = result.rows.map((r) => ({
      id: r.id,
      rxNumber: r.rxNumber,
      createdAt: r.createdAt,
      status: r.status,
      itemCount: r.itemCount,
      medicineNames: r.medicineNames,
      diagnosis: r.diagnosis,
      doctorName: r.doctorName,
      doctorDepartment: r.doctorDepartment,
    }));
    return res.status(200).json({
      prescriptions,
      pagination: { total: result.total, page: result.page, limit: result.limit, totalPages: result.totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// جزئیات کامل یک نسخه (همه‌ی داروهای همان نسخه) فقط اگر متعلق به بیمارِ واردشده باشد.
// GET /api/users/prescriptions/:id/detail
// اگر نسخه وجود نداشته باشد یا مال کس دیگری باشد، هر دو حالت یک پاسخ ۴۰۴ یکسان می‌گیرند
// تا وجود/عدم‌وجود نسخه‌ی دیگران قابل حدس‌زدن نباشد (جلوگیری از IDOR و شمارش شناسه‌ها).
export async function getMyPrescriptionDetail(req, res) {
  try {
    const existing = await getPrescriptionByIdForPatientUser(req.params.id, req.user.id);
    if (!existing) return res.status(404).json({ message: "نسخه یافت نشد" });
    const rows = await getPrescriptionsByGroup(existing);
    const first = rows[0];
    return res.status(200).json({
      prescription: {
        id: first.id,
        rxNumber: `RX-${String(first.id).padStart(6, "0")}`,
        createdAt: first.createdAt,
        status: first.status || "active",
        diagnosis: first.diagnosis || null,
        instructions: first.instructions || null,
        notes: first.notes || null,
        followUpDate: first.followUpDate || null,
        doctorName: first.doctorName || null,
        medicines: rows.map((m) => ({
          id: m.id,
          medicationName: m.medicationName,
          dosage: m.dosage || null,
          quantity: m.quantity || null,
          frequency: m.frequency || null,
          duration: m.duration || null,
          medicineNotes: m.medicineNotes || null,
        })),
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// خروجی PDF یک نسخه برای خودِ بیمار (چاپ نسخه — الزام شماره ۱، ۲ و ۳: فقط پرونده‌ی خودش)
export async function downloadMyPrescriptionPdf(req, res) {
  try {
    const existing = await getPrescriptionByIdForPatientUser(req.params.id, req.user.id);
    if (!existing) return res.status(404).json({ message: "نسخه یافت نشد" });
    await sendPrescriptionPdf(res, existing, await getPrescriptionsByGroup(existing));
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- حساسیت‌ها (Allergies) ----------
const allergyHandlers = buildEmrResourceHandlers({
  entityLabel: "حساسیت",
  tableName: "allergies",
  createFn: createAllergy,
  getByIdFn: getAllergyById,
  updateFn: updateAllergy,
  deleteFn: deleteAllergy,
  pickCreateFields: ({ allergen, reaction, severity, notes }) => ({ allergen, reaction, severity, notes }),
  pickUpdateFields: ({ allergen, reaction, severity, notes }) => ({ allergen, reaction, severity, notes }),
});
export const addAllergy = allergyHandlers.add;
export const editAllergy = allergyHandlers.edit;
export const removeAllergy = allergyHandlers.remove;

// ---------- نتایج آزمایشگاه (Lab Results) ----------
const labResultHandlers = buildEmrResourceHandlers({
  entityLabel: "نتیجه آزمایش",
  tableName: "lab_results",
  createFn: createLabResult,
  getByIdFn: getLabResultById,
  updateFn: updateLabResult,
  // با حذف نتیجه‌ی آزمایش، فایل گزارشِ آپلودشده‌ی آن هم از پوشه‌ی خصوصی پاک می‌شود (فایل یتیم نماند)
  deleteFn: async (id) => {
    const existing = await getLabResultById(id);
    await deleteLabResult(id);
    if (existing?.reportUrl) {
      fs.unlink(path.join(LAB_REPORTS_DIR, path.basename(existing.reportUrl)), () => {});
    }
  },
  pickCreateFields: ({ recordId, testName, result, unit, referenceRange, status, testDate }) => ({
    recordId, testName, result, unit, referenceRange, status, testDate,
  }),
  pickUpdateFields: ({ testName, result, unit, referenceRange, status, testDate }) => ({
    testName, result, unit, referenceRange, status, testDate,
  }),
});
export const addLabResult = labResultHandlers.add;
export const editLabResult = labResultHandlers.edit;
export const removeLabResult = labResultHandlers.remove;

// ثبت نتیجه‌ی یک آزمایش درخواست‌شده (تغییر وضعیت از «در انتظار» به «تکمیل‌شده»)
// و اطلاع‌رسانی به داکترِ درخواست‌کننده — الزام شماره ۲ و ۴
export async function recordLabResult(req, res) {
  try {
    const existing = await getLabResultById(req.params.id);
    if (!existing) return res.status(404).json({ message: "آزمایش یافت نشد" });

    const actingDoctor = await resolveActingDoctor(req);
    if (!canManage(req, actingDoctor, existing)) {
      return res.status(403).json({ message: "شما اجازه‌ی ثبت نتیجه‌ی این آزمایش را ندارید" });
    }

    const { result, unit, referenceRange, testDate } = req.body;
    const labResult = await updateLabResult(req.params.id, {
      result,
      unit,
      referenceRange,
      testDate,
      status: "completed",
    });
    await logEmr(req, "ثبت نتیجه آزمایش", `labResultId=${req.params.id}`);
    await auditEmr(req, "lab_results", req.params.id, "UPDATE", existing, labResult);

    // اطلاع‌رسانی به داکتر درخواست‌کننده (اگر برای حساب کاربری داشته باشد)
    if (labResult.doctorId) {
      const requestingDoctor = await getDoctorById(labResult.doctorId);
      if (requestingDoctor?.userId) {
        await createNotification({
          userId: requestingDoctor.userId,
          title: "نتیجه آزمایش آماده شد",
          message: `نتیجه‌ی آزمایش «${labResult.testName}» برای بیمار ثبت شد.`,
          type: "lab_result",
          relatedId: labResult.id,
        });
      }
    }

    return res.status(200).json({ message: "نتیجه آزمایش ثبت شد", labResult });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// آپلود فایل گزارش آزمایشگاهی (اسکن/PDF) برای یک آزمایش مشخص — الزام شماره ۳
export async function uploadLabReport(req, res) {
  try {
    const existing = await getLabResultById(req.params.id);
    if (!existing) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(404).json({ message: "آزمایش یافت نشد" });
    }

    const actingDoctor = await resolveActingDoctor(req);
    if (!canManage(req, actingDoctor, existing)) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(403).json({ message: "شما اجازه‌ی آپلود گزارش این آزمایش را ندارید" });
    }

    if (!req.file) return res.status(400).json({ message: "فایل گزارش الزامی است" });

    // اگر گزارش قبلی وجود داشت، از دیسک حذف می‌شود تا فایل یتیم باقی نماند
    if (existing.reportUrl) {
      const oldPath = path.join(LAB_REPORTS_DIR, path.basename(existing.reportUrl));
      fs.unlink(oldPath, () => {});
    }

    const labResult = await setLabReportUrl(req.params.id, req.file.filename);
    await logEmr(req, "آپلود گزارش آزمایش", `labResultId=${req.params.id}`);
    await auditEmr(req, "lab_results", req.params.id, "UPDATE", existing, labResult);
    return res.status(200).json({ message: "گزارش آزمایش با موفقیت آپلود شد", labResult });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// دانلود امن فایل گزارش (برای پنل داکتر/ادمین) — چون /uploads عمومی است، این فایل‌ها
// از یک پوشه‌ی خصوصی و فقط از طریق همین مسیرِ احرازهویت‌شده سرو می‌شوند
export async function downloadLabReport(req, res) {
  try {
    const existing = await getLabResultById(req.params.id);
    if (!existing || !existing.reportUrl) {
      return res.status(404).json({ message: "گزارشی برای این آزمایش یافت نشد" });
    }

    // همان بررسی مالکیتی که در ثبت نتیجه/آپلود گزارش همین آزمایش اعمال می‌شود، این‌جا هم
    // باید رعایت شود: ادمین/سوپرادمین به همه دسترسی دارند، اما یک داکتر فقط باید بتواند
    // گزارش آزمایش‌های بیمارانِ خودش را دانلود کند، نه گزارش‌های ثبت‌شده توسط داکتر دیگر
    // (قبلاً این مسیر این بررسی را نداشت و صرفاً به نقش "doctor" بسنده می‌کرد)
    const actingDoctor = await resolveActingDoctor(req);
    if (!canManage(req, actingDoctor, existing)) {
      return res.status(403).json({ message: "شما اجازه‌ی دانلود گزارش این آزمایش را ندارید" });
    }

    const filePath = path.join(LAB_REPORTS_DIR, path.basename(existing.reportUrl));
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "فایل گزارش روی سرور یافت نشد" });
    }
    await logEmr(req, "دانلود گزارش آزمایش", `labResultId=${existing.id} patientId=${existing.patientId}`);
    return res.sendFile(filePath);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- دسترسی بیمار به آزمایش‌های خودش (فقط نتایج تکمیل‌شده — الزام شماره ۵) ----------

export async function getMyLabResults(req, res) {
  try {
    const labResults = await getLabResultsByPatientUser(req.user.id, { status: "completed" });
    return res.status(200).json({ labResults });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// دانلود گزارش توسط خودِ بیمار — فقط اگر متعلق به او و «تکمیل‌شده» باشد
export async function downloadMyLabReport(req, res) {
  try {
    const existing = await getLabResultByIdForPatientUser(req.params.id, req.user.id);
    if (!existing || existing.status !== "completed" || !existing.reportUrl) {
      return res.status(404).json({ message: "گزارشی برای این آزمایش یافت نشد" });
    }
    const filePath = path.join(LAB_REPORTS_DIR, path.basename(existing.reportUrl));
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: "فایل گزارش روی سرور یافت نشد" });
    }
    return res.sendFile(filePath);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- گزارش‌های رادیولوژی (Radiology Reports) ----------
const radiologyHandlers = buildEmrResourceHandlers({
  entityLabel: "گزارش رادیولوژی",
  tableName: "radiology_reports",
  createFn: createRadiologyReport,
  getByIdFn: getRadiologyReportById,
  updateFn: updateRadiologyReport,
  deleteFn: deleteRadiologyReport,
  pickCreateFields: ({ recordId, examType, findings, impression, imageUrl, examDate }) => ({
    recordId, examType, findings, impression, imageUrl, examDate,
  }),
  pickUpdateFields: ({ examType, findings, impression, imageUrl, examDate }) => ({
    examType, findings, impression, imageUrl, examDate,
  }),
});
export const addRadiologyReport = radiologyHandlers.add;
export const editRadiologyReport = radiologyHandlers.edit;
export const removeRadiologyReport = radiologyHandlers.remove;

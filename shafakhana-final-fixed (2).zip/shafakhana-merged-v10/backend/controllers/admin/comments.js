// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import { sanitizeCommentText } from "../../utils/sanitizeNewsContent.js";
import {
  getCommentsAdminPage, getCommentDetail, getCommentStats, getNewsOptionsWithComments, getCommentsByIds,
  getCommentById, updateCommentStatus, deleteComment, bulkUpdateCommentStatus, bulkDeleteComments,
  updateCommentFields, restoreComment,
  COMMENT_STATUSES, COMMENT_SORTS,
} from "../../models/NewsComment.js";
import { createNotification } from "../../models/Notification.js";

import { logAdmin, auditAdmin } from "./shared.js";

const COMMENT_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;


// GET /api/admin/comments — فهرست صفحه‌بندی‌شده (همه‌ی پارامترها اختیاری)
// ?status=pending|approved|rejected|deleted &rating=1..5 &newsId= &q= &dateFrom=YYYY-MM-DD &dateTo=YYYY-MM-DD
// &sort=newest|oldest|pending_first|highest|lowest &page= &limit= (سقف ۱۰۰)
// پاسخ: { comments: [...خلاصه‌ی هر نظر], pagination: { page, limit, total, totalPages } }
export async function listCommentsAdmin(req, res) {
  try {
    const { status, newsId, rating, q, dateFrom, dateTo, sort, page, limit } = req.query;
    if (status && status !== "deleted" && !COMMENT_STATUSES.includes(status)) {
      return res.status(400).json({ message: "وضعیت نامعتبر است" });
    }
    if (sort && !COMMENT_SORTS.includes(sort)) {
      return res.status(400).json({ message: "مرتب‌سازی نامعتبر است" });
    }
    if (rating && !/^[1-5]$/.test(String(rating))) {
      return res.status(400).json({ message: "امتیاز باید بین ۱ تا ۵ باشد" });
    }
    if (newsId && !/^[1-9]\d{0,9}$/.test(String(newsId))) {
      return res.status(400).json({ message: "شناسه‌ی خبر نامعتبر است" });
    }
    if ((dateFrom && !COMMENT_DATE_RE.test(dateFrom)) || (dateTo && !COMMENT_DATE_RE.test(dateTo))) {
      return res.status(400).json({ message: "فرمت تاریخ نامعتبر است (YYYY-MM-DD)" });
    }
    const result = await getCommentsAdminPage({
      status, newsId: newsId ? Number(newsId) : undefined, rating: rating ? Number(rating) : undefined, q, dateFrom, dateTo, sort, page, limit,
    });
    return res.status(200).json(result);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// GET /api/admin/comments/stats — کارت‌های آماری: مجموع/در انتظار/تأییدشده/ردشده/حذف‌شده
export async function getCommentStatistics(req, res) {
  try {
    const stats = await getCommentStats();
    return res.status(200).json({ stats });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// GET /api/admin/comments/news-options?q= — خبرهایی که نظر دارند (برای فیلتر «خبر»)
export async function listCommentNewsOptions(req, res) {
  try {
    const news = await getNewsOptionsWithComments({ q: req.query.q });
    return res.status(200).json({ news });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// GET /api/admin/comments/:id — متن کامل و اطلاعات نویسنده/خبر برای پنل جزئیات (فقط خواندن)
export async function viewComment(req, res) {
  try {
    const comment = await getCommentDetail(req.params.id);
    if (!comment) return res.status(404).json({ message: "نظر یافت نشد" });
    return res.status(200).json({ comment });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// PUT /api/admin/comments/:id/status — تایید (approved) یا رد (rejected) یک نظر
export async function changeCommentStatus(req, res) {
  try {
    const { status } = req.body;
    const existing = await getCommentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نظر یافت نشد" });

    const comment = await updateCommentStatus(req.params.id, status);
    await logAdmin(req, status === "approved" ? "تایید نظر" : "رد نظر", `commentId=${req.params.id}`);
    await auditAdmin(req, "news_comments", req.params.id, "UPDATE", existing, comment);

    // اطلاع‌رسانی به نویسنده‌ی نظر درباره‌ی نتیجه‌ی بررسی (مشابه اطلاع‌رسانی تغییر وضعیت نوبت)
    await createNotification({
      userId: existing.userId,
      title: status === "approved" ? "نظر شما تایید شد" : "نظر شما رد شد",
      message:
        status === "approved"
          ? `نظر شما روی خبر «${existing.newsTitle}» تایید شد و اکنون در صفحه عمومی نمایش داده می‌شود.`
          : `نظر شما روی خبر «${existing.newsTitle}» توسط مدیریت رد شد.`,
      type: "news_comment",
      relatedId: existing.newsId,
    });

    const message = status === "approved" ? "نظر تایید شد و در صفحه عمومی خبر نمایش داده می‌شود" : "نظر رد شد";
    return res.status(200).json({ message, comment });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// DELETE /api/admin/comments/:id — حذف کامل یک نظر (مثلاً محتوای نامناسب/اسپم)
export async function removeComment(req, res) {
  try {
    const existing = await getCommentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نظر یافت نشد" });

    await deleteComment(req.params.id);
    await logAdmin(req, "حذف نظر", `commentId=${req.params.id}`);
    await auditAdmin(req, "news_comments", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "نظر حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// PUT /api/admin/comments/:id — ویرایش متن نظر، پاسخ ادمین و/یا یادداشت داخلی (هر کدام اختیاری)
// پاسخ ادمین پس از ثبت/تغییر به نویسنده‌ی نظر اعلان می‌دهد؛ یادداشت داخلی فقط برای تیم مدیریت است.
export async function editComment(req, res) {
  try {
    const existing = await getCommentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نظر یافت نشد" });
    const { content, adminReply, internalNote } = req.body;
    const fields = {};
    if (content !== undefined) fields.content = sanitizeCommentText(content);
    if (adminReply !== undefined) fields.adminReply = sanitizeCommentText(adminReply || "");
    if (internalNote !== undefined) fields.internalNote = sanitizeCommentText(internalNote || "");
    if (fields.content !== undefined && fields.content.length < 2) return res.status(400).json({ message: "متن نظر باید حداقل ۲ کاراکتر باشد" });

    await updateCommentFields(req.params.id, fields);
    await logAdmin(req, "ویرایش نظر", `commentId=${req.params.id}`);
    await auditAdmin(req, "news_comments", req.params.id, "UPDATE", existing, { ...existing, ...fields });
    if (fields.adminReply && fields.adminReply !== existing.adminReply) {
      await createNotification({
        userId: existing.userId,
        title: "مدیریت به نظر شما پاسخ داد",
        message: `مدیریت به نظر شما روی خبر «${existing.newsTitle}» پاسخ داد: «${fields.adminReply.length > 120 ? `${fields.adminReply.slice(0, 120)}…` : fields.adminReply}»`,
        type: "news_comment",
        relatedId: existing.newsId,
      });
    }
    return res.status(200).json({ message: "تغییرات نظر ذخیره شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// POST /api/admin/comments/:id/restore — بازگردانی نظر حذف‌شده (با همان وضعیت قبل از حذف)
export async function restoreRemovedComment(req, res) {
  try {
    const existing = await getCommentById(req.params.id, { includeDeleted: true });
    if (!existing) return res.status(404).json({ message: "نظر یافت نشد" });
    if (!existing.deletedAt) return res.status(400).json({ message: "این نظر حذف نشده است" });
    await restoreComment(req.params.id);
    await logAdmin(req, "بازگردانی نظر", `commentId=${req.params.id}`);
    await auditAdmin(req, "news_comments", req.params.id, "UPDATE", existing, { ...existing, deletedAt: null });
    return res.status(200).json({ message: "نظر بازگردانده شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// POST /api/admin/comments/bulk — body: { ids: number[], action: approve|reject|delete }
// حداکثر ۲۰۰ نظر در هر درخواست. برای هر نظر لاگ/آدیت جداگانه ثبت می‌شود؛ تأیید/رد گروهی مثل حالت
// تکی فقط برای نظرهایی که وضعیتشان واقعاً تغییر می‌کند اعلان به نویسنده می‌فرستد. حذف گروهی «نرم»
// است (deletedAt) و هیچ خبری حذف نمی‌شود.
export async function bulkComments(req, res) {
  try {
    const { ids, action } = req.body;
    const cleanIds = [...new Set((Array.isArray(ids) ? ids : []).map((id) => parseInt(id, 10)).filter((id) => Number.isInteger(id) && id > 0))];
    if (cleanIds.length === 0) return res.status(400).json({ message: "حداقل یک نظر باید انتخاب شود" });
    if (cleanIds.length > 200) return res.status(400).json({ message: "حداکثر ۲۰۰ نظر را می‌توانید هم‌زمان انتخاب کنید" });

    const existing = await getCommentsByIds(cleanIds);
    if (existing.length === 0) return res.status(404).json({ message: "هیچ‌کدام از نظرهای انتخاب‌شده یافت نشد" });

    if (action === "delete") {
      const affected = await bulkDeleteComments(existing.map((c) => c.id));
      await logAdmin(req, "حذف گروهی نظرات", `commentIds=${existing.map((c) => c.id).join(",")} تعداد=${affected}`);
      await Promise.all(existing.map((c) => auditAdmin(req, "news_comments", c.id, "DELETE", c, null)));
      return res.status(200).json({ message: `${affected} نظر حذف شد`, affected });
    }

    const target = action === "approve" ? "approved" : action === "reject" ? "rejected" : null;
    if (!target) return res.status(400).json({ message: "عملیات نامعتبر است" });

    const toChange = existing.filter((c) => c.status !== target);
    if (toChange.length === 0) return res.status(200).json({ message: "وضعیت نظرهای انتخاب‌شده از قبل همین بود", affected: 0 });

    const affected = await bulkUpdateCommentStatus(toChange.map((c) => c.id), target);
    await logAdmin(req, target === "approved" ? "تایید گروهی نظرات" : "رد گروهی نظرات", `commentIds=${toChange.map((c) => c.id).join(",")} تعداد=${affected}`);
    await Promise.all(toChange.map((c) => auditAdmin(req, "news_comments", c.id, "UPDATE", c, { ...c, status: target })));
    await Promise.all(toChange.map((c) => createNotification({
      userId: c.userId,
      title: target === "approved" ? "نظر شما تایید شد" : "نظر شما رد شد",
      message:
        target === "approved"
          ? `نظر شما روی خبر «${c.newsTitle}» تایید شد و اکنون در صفحه عمومی نمایش داده می‌شود.`
          : `نظر شما روی خبر «${c.newsTitle}» توسط مدیریت رد شد.`,
      type: "news_comment",
      relatedId: c.newsId,
    })));
    return res.status(200).json({ message: `${affected} نظر ${target === "approved" ? "تایید" : "رد"} شد`, affected });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- مدیریت پیام‌های تماس با ما (Contact Messages Management) ----------
// همه‌ی مسیرهای زیر طبق router.use بالای admin.js فقط برای admin/superadmin باز است (RBAC)


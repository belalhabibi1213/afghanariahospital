import { updatePatient, deletePatient, getPatientStats, searchPatients, getPatientById, getPatientDetailById, getPatientDetailByPublicCode, getPatientsByIds, deletePatientsByIds, getPatientsForExport } from "../../models/Patient.js";
import { getAppointmentsByPatientId } from "../../models/Appointment.js";
// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import { getRecordsByPatientId } from "../../models/MedicalRecord.js";
import { getDiagnosesByPatientId } from "../../models/Diagnosis.js";
import { getPrescriptionsByPatientId } from "../../models/Prescription.js";
import { getAllergiesByPatientId } from "../../models/Allergy.js";
import { getLabResultsByPatientId } from "../../models/LabResult.js";
import { getRadiologyReportsByPatientId } from "../../models/RadiologyReport.js";
import { getInvoicesByPatientId } from "../../models/Invoice.js";
import { getFileTransfersByPatientId } from "../../models/FileTransfer.js";
import { findById as findUserById, setUserActive, updatePasswordAndRequireChange } from "../../models/User.js";
import { generateTempPassword } from "../../utils/passwordPolicy.js";
import { sendTempPasswordEmail } from "../../utils/mailer.js";
import { sendPatientInfoPdf } from "../../utils/patientInfoPdf.js";
import { sendPatientCardPdf } from "../../utils/patientCardPdf.js";
import { sendPdfReport, sendExcelReport } from "../../utils/reportExport.js";
import { isValidPersianName, PERSIAN_NAME_ERROR_MESSAGE } from "../../utils/persianName.js";

import { logAdmin, auditAdmin } from "./shared.js";
import { trackPatientRecordAccess } from "../../utils/accessMonitor.js";

// ---------- بیماران ----------
// GET /admin/patients/stats — شمارنده‌های کارت‌های بالای صفحه‌ی مدیریت بیماران
export async function patientStats(req, res) {
  try {
    return res.status(200).json({ stats: await getPatientStats() });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// همیشه صفحه‌بندی‌شده است (حتی بدون هیچ فیلتری؛ آن‌وقت فقط صفحه‌ی اول برگردانده می‌شود) تا این
// مسیر هرگز کل جدول بیماران را یک‌جا نخواند و با رشد تعداد بیماران کند نشود:
// GET /admin/patients?q=...&page=1&limit=10
export async function listPatients(req, res) {
  try {
    const { q, status, gender, doctorId, createdFrom, createdTo, page, limit } = req.query;

    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchPatients({
      q,
      status,
      gender,
      doctorId,
      createdFrom,
      createdTo,
      page,
      limit,
    });
    return res.status(200).json({
      patients: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function editPatient(req, res) {
  try {
    const { fullName, phone, email } = req.body;
    if (!fullName || !phone) return res.status(400).json({ message: "نام و شماره تماس الزامی است" });
    if (!isValidPersianName(fullName)) {
      return res.status(400).json({ message: PERSIAN_NAME_ERROR_MESSAGE });
    }
    const existing = await getPatientById(req.params.id);
    // مثل سایر منابع این کنترلر (داکتر/بخش/برنامه کاری)، اگر بیمار وجود نداشته باشد
    // باید ۴۰۴ برگردانده شود؛ قبلاً این بررسی نبود و پیام «به‌روزرسانی شد» با patient: null
    // برمی‌گشت که هم گمراه‌کننده بود و هم با رفتار بقیه‌ی کنترلر ناهماهنگ
    if (!existing) return res.status(404).json({ message: "بیمار یافت نشد" });
    const patient = await updatePatient(req.params.id, { fullName, phone, email });
    await logAdmin(req, "ویرایش بیمار", `patientId=${req.params.id}`);
    await auditAdmin(req, "patients", req.params.id, "UPDATE", existing, patient);
    return res.status(200).json({ message: "اطلاعات بیمار به‌روزرسانی شد", patient });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function removePatient(req, res) {
  try {
    const existing = await getPatientById(req.params.id);
    // مشابه بررسی بالا: بدون این خط، حذفِ شناسه‌ی ناموجود هم پیام موفقیت برمی‌گرداند
    if (!existing) return res.status(404).json({ message: "بیمار یافت نشد" });
    await deletePatient(req.params.id);
    await logAdmin(req, "حذف بیمار", `patientId=${req.params.id}`);
    await auditAdmin(req, "patients", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "بیمار حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ---------- حذف گروهی چند بیمار (دکمه‌ی «حذف گروهی» — انتخاب چندتایی در پنل مدیریت بیماران) ----------
// DELETE /api/admin/patients/bulk   body: { ids: [1, 2, 3, ...] }
// فقط admin/superadmin (طبق router.use در routes/admin.js)
export async function bulkRemovePatients(req, res) {
  try {
    const { ids } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ message: "حداقل یک بیمار باید انتخاب شود" });
    }
    const cleanIds = [...new Set(ids.map((id) => parseInt(id, 10)).filter((id) => Number.isInteger(id) && id > 0))];
    if (cleanIds.length === 0) {
      return res.status(400).json({ message: "شناسه‌های ارسال‌شده نامعتبر است" });
    }
    if (cleanIds.length > 200) {
      return res.status(400).json({ message: "حداکثر ۲۰۰ بیمار را می‌توانید هم‌زمان حذف کنید" });
    }

    const existingPatients = await getPatientsByIds(cleanIds);
    if (existingPatients.length === 0) {
      return res.status(404).json({ message: "هیچ‌کدام از بیماران انتخاب‌شده یافت نشد" });
    }

    const deletedCount = await deletePatientsByIds(cleanIds);
    await logAdmin(req, "حذف گروهی بیماران", `patientIds=${cleanIds.join(",")} تعداد=${deletedCount}`);
    // برای هر بیمار حذف‌شده، یک رکورد آدیت جداگانه ثبت می‌شود (همان الگوی حذف تکی بالا)
    // تا سابقه‌ی حسابرسی مثل قبل دقیق و ردیف‌به‌ردیف باقی بماند
    await Promise.all(
      existingPatients.map((p) => auditAdmin(req, "patients", p.id, "DELETE", p, null))
    );

    return res.status(200).json({ message: `${deletedCount} بیمار با موفقیت حذف شد`, deletedCount });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


const PATIENT_GENDER_LABEL = { male: "مرد", female: "زن" };


// ---------- خروجی Excel/PDF فهرست بیماران (پنل مدیریت بیماران) ----------
// GET /api/admin/patients/export?format=excel|pdf&q=...&ids=1,2,3
// اگر ids ارسال شود (بیماران انتخاب‌شده با چک‌باکس)، فقط همان‌ها خروجی گرفته می‌شوند؛
// در غیر این صورت همان جستجوی جاری پنل (q) اعمال می‌شود؛ بدون هیچ‌کدام، همه‌ی بیماران.
// از همان تابع مشترک reportExport.js (سازنده‌ی خروجی PDF/Excel گزارش‌ها) استفاده می‌شود
// تا کد و ظاهر خروجی با بقیه‌ی سیستم یکدست بماند.
export async function exportPatients(req, res) {
  try {
    const { format, q, ids } = req.query;
    if (format !== "excel" && format !== "pdf") {
      return res.status(400).json({ message: "فرمت خروجی نامعتبر است (excel یا pdf)" });
    }
    const idList = ids
      ? String(ids).split(",").map((id) => parseInt(id, 10)).filter((id) => Number.isInteger(id) && id > 0)
      : undefined;

    const rows = await getPatientsForExport({ q, ids: idList });

    const columns = [
      { header: "شناسه", key: "id", width: 0.7 },
      { header: "نام کامل", key: "fullName", width: 1.8 },
      { header: "شماره تماس", key: "phone", width: 1.2 },
      { header: "ایمیل", key: "email", width: 1.6 },
      { header: "جنسیت", key: "genderLabel", width: 0.8 },
      { header: "داکتر مسئول", key: "assignedDoctorName", width: 1.5 },
      { header: "آخرین مراجعه", key: "lastVisitDate", width: 1.1 },
      { header: "وضعیت حساب", key: "statusLabel", width: 1 },
      { header: "تاریخ ثبت", key: "createdAt", width: 1.1 },
    ];
    const exportRows = rows.map((r) => ({
      ...r,
      email: r.email || "—",
      genderLabel: PATIENT_GENDER_LABEL[r.gender] || "—",
      assignedDoctorName: r.assignedDoctorName || "—",
      lastVisitDate: r.lastVisitDate ? String(r.lastVisitDate).slice(0, 10) : "—",
      statusLabel: r.userId ? (r.userIsActive ? "فعال" : "غیرفعال") : "مهمان",
      createdAt: r.createdAt ? String(r.createdAt).slice(0, 10) : "—",
    }));
    const summaryLines = [`تعداد کل بیماران: ${rows.length}`];

    await logAdmin(req, "خروجی‌گیری از فهرست بیماران", `format=${format} تعداد=${rows.length}`);

    if (format === "pdf") {
      sendPdfReport(res, { fileName: "patients-list", title: "لیست بیماران", columns, rows: exportRows, summaryLines });
      return;
    }
    await sendExcelReport(res, { fileName: "patients-list", title: "لیست بیماران", columns, rows: exportRows, summaryLines });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// جزئیات کامل یک بیمار (دکمه‌ی «مشاهده» در ستون عملیات پنل مدیریت بیماران)
export async function viewPatient(req, res) {
  try {
    const patient = await getPatientDetailById(req.params.id);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    await logAdmin(req, "مشاهده اطلاعات بیمار", `patientId=${req.params.id}`);
    trackPatientRecordAccess(req, req.params.id);
    return res.status(200).json({ patient });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ---------- پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار) ----------
// GET /api/admin/patients/:id/full-profile
// همه‌ی اطلاعات لازم برای صفحه‌ی «جزئیات بیمار» را در یک درخواست برمی‌گرداند: اطلاعات
// هویتی/تماس (همان getPatientDetailById)، پرونده الکترونیک صحی کامل (ویزیت‌ها، تشخیص‌ها/
// بیماری‌های قبلی، نسخه‌ها، حساسیت‌ها، نتایج آزمایشگاه، گزارش‌های رادیولوژی)، نوبت‌ها،
// صورت‌حساب‌ها/فاکتورها و فایل‌های صحی دریافتی از داکتران. تمام این داده‌ها از همان
// توابع مدلی که پیش‌تر برای پنل داکتر/بیمار/صورت‌حساب/انتقال فایل ساخته شده‌اند
// دوباره‌استفاده می‌شود؛ هیچ رفتار یا مسیر موجودی تغییر نمی‌کند.
export async function getPatientFullProfile(req, res) {
  try {
    const { id } = req.params;
    const patient = await getPatientDetailById(id);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });

    const [
      encounters, diagnoses, prescriptions, allergies, labResults, radiologyReports,
      appointments, invoices, fileTransfers,
    ] = await Promise.all([
      getRecordsByPatientId(id),
      getDiagnosesByPatientId(id),
      getPrescriptionsByPatientId(id),
      getAllergiesByPatientId(id),
      getLabResultsByPatientId(id),
      getRadiologyReportsByPatientId(id),
      getAppointmentsByPatientId(id),
      getInvoicesByPatientId(id),
      getFileTransfersByPatientId(id),
    ]);

    await logAdmin(req, "مشاهده پرونده کامل بیمار", `patientId=${id}`);
    trackPatientRecordAccess(req, id);

    return res.status(200).json({
      patient, encounters, diagnoses, prescriptions, allergies, labResults, radiologyReports,
      appointments, invoices, fileTransfers,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// فعال/غیرفعال کردن حساب کاربری بیمار (دکمه‌ی «فعال‌سازی/غیرفعال‌سازی حساب»).
// فقط برای بیمارانی که حساب کاربری (userId) دارند معنا دارد؛ بیماران مهمان (بدون
// حساب) اصلاً رکورد فعال/غیرفعال‌شدنی در جدول users ندارند.
export async function togglePatientAccountStatus(req, res) {
  try {
    const { isActive } = req.body;
    if (typeof isActive === "undefined") {
      return res.status(400).json({ message: "وضعیت حساب (isActive) الزامی است" });
    }
    const patient = await getPatientById(req.params.id);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    if (!patient.userId) {
      return res.status(400).json({ message: "این بیمار حساب کاربری ندارد که وضعیت آن تغییر کند" });
    }
    const existingUser = await findUserById(patient.userId);
    if (!existingUser) return res.status(404).json({ message: "حساب کاربری این بیمار یافت نشد" });
    const updatedUser = await setUserActive(patient.userId, isActive);
    await logAdmin(
      req,
      "تغییر وضعیت فعال/غیرفعال حساب بیمار",
      `patientId=${req.params.id} userId=${patient.userId} -> ${isActive ? "فعال" : "غیرفعال"}`
    );
    await auditAdmin(req, "users", patient.userId, "UPDATE", existingUser, updatedUser);
    return res.status(200).json({
      message: isActive ? "حساب بیمار فعال شد" : "حساب بیمار غیرفعال شد",
      user: updatedUser,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// بازنشانی رمز عبور بیمار توسط ادمین (دکمه‌ی «بازنشانی رمز عبور»). یک رمز عبور
// موقتِ تصادفی و امن می‌سازد، آن را برای حساب بیمار ذخیره می‌کند و در صورت داشتن
// ایمیل تلاش می‌کند آن را ایمیل کند؛ در هر صورت رمز موقت در پاسخ هم برگردانده
// می‌شود تا اگر ایمیل ارسال نشد (مثلاً SMTP تنظیم نیست)، ادمین بتواند شخصاً آن را
// به بیمار اطلاع دهد.
export async function resetPatientPassword(req, res) {
  try {
    const patient = await getPatientById(req.params.id);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    if (!patient.userId) {
      return res.status(400).json({ message: "این بیمار حساب کاربری ندارد که رمز عبور آن بازنشانی شود" });
    }
    const existingUser = await findUserById(patient.userId);
    if (!existingUser) return res.status(404).json({ message: "حساب کاربری این بیمار یافت نشد" });

    const tempPassword = generateTempPassword();
    await updatePasswordAndRequireChange(patient.userId, tempPassword);
    const updatedUser = await findUserById(patient.userId);

    await logAdmin(req, "بازنشانی رمز عبور بیمار توسط ادمین", `patientId=${req.params.id} userId=${patient.userId}`);
    await auditAdmin(req, "users", patient.userId, "UPDATE", existingUser, updatedUser);

    const emailResult = patient.email
      ? await sendTempPasswordEmail({ to: patient.email, fullName: patient.fullName, tempPassword })
      : { delivered: false, reason: "NO_EMAIL" };

    return res.status(200).json({
      message: emailResult.delivered
        ? "رمز عبور جدید ساخته شد و به ایمیل بیمار ارسال شد"
        : "رمز عبور جدید ساخته شد؛ چون ایمیل ارسال نشد، لطفاً آن را شخصاً به بیمار اطلاع دهید",
      tempPassword,
      emailDelivered: emailResult.delivered,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// خروجی PDF معلومات بیمار (دکمه‌های «چاپ» و «دانلود PDF» — هر دو از همین مسیر
// استفاده می‌کنند؛ فرانت‌اند برای «چاپ» فایل را با openInNewTab باز می‌کند تا از
// دیالوگ چاپ مرورگر استفاده شود، و برای «دانلود» همان فایل را ذخیره می‌کند).
export async function downloadPatientPdf(req, res) {
  try {
    const patient = await getPatientDetailById(req.params.id);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    await logAdmin(req, "دانلود PDF معلومات بیمار", `patientId=${req.params.id}`);
    await sendPatientInfoPdf(res, patient);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// کارت چاپی بیمار (نام + کد + QR) — برای تحویل به بیمار در اولین مراجعه
export async function downloadPatientCardPdf(req, res) {
  try {
    const patient = await getPatientDetailById(req.params.id);
    if (!patient) return res.status(404).json({ message: "بیمار یافت نشد" });
    await logAdmin(req, "دانلود کارت QR بیمار", `patientId=${req.params.id}`);
    await sendPatientCardPdf(res, patient);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در تولید کارت بیمار" });
  }
}


// جستجوی بیمار با کد عمومی (اسکن QR کارت در پذیرش) — همان شکل پروفایل getPatientDetailById
export async function lookupPatientByCode(req, res) {
  try {
    const code = String(req.params.code || "").trim();
    if (!code) return res.status(400).json({ message: "کد بیمار الزامی است" });
    const patient = await getPatientDetailByPublicCode(code);
    if (!patient) return res.status(404).json({ message: "بیماری با این کد یافت نشد" });
    return res.status(200).json({ patient });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در جستجوی بیمار" });
  }
}


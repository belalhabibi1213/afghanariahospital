// توابع مشترک کنترلرهای پنل ادمین (لاگ فعالیت و لاگ حسابرسی)
import { logActivity } from "../../models/ActivityLog.js";
import { recordAudit } from "../../models/AuditLog.js";

export const logAdmin = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

// ثبت لاگ حسابرسی (audit_logs) برای تغییرات کنترلرهای ادمین
export const auditAdmin = (req, tableName, recordId, action, oldValues, newValues) =>
  recordAudit({
    req, tableName, recordId, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });

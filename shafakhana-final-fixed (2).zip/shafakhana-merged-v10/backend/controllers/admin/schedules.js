// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import { getAllSchedules, createSchedule, updateSchedule, deleteSchedule, hasOverlappingSchedule, getScheduleById } from "../../models/Schedule.js";

import { logAdmin, auditAdmin } from "./shared.js";

// ---------- برنامه‌های کاری (Schedules) ----------
export async function listSchedules(req, res) {
  try {
    const schedules = await getAllSchedules();
    return res.status(200).json({ schedules });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function addSchedule(req, res) {
  try {
    const { doctorId, dayOfWeek, startTime, endTime, breakStart, breakEnd } = req.body;
    if (!doctorId || !dayOfWeek || !startTime || !endTime) {
      return res.status(400).json({ message: "همه فیلدهای برنامه کاری الزامی است" });
    }
    const overlap = await hasOverlappingSchedule({ doctorId, dayOfWeek, startTime, endTime });
    if (overlap) {
      return res.status(409).json({ message: "این بازه با یک برنامه کاری موجود برای همین داکتر و روز تداخل دارد", code: "SCHEDULE_OVERLAP" });
    }
    const schedule = await createSchedule({ doctorId, dayOfWeek, startTime, endTime, breakStart, breakEnd });
    await logAdmin(req, "افزودن برنامه کاری", `doctorId=${doctorId} ${dayOfWeek}`);
    await auditAdmin(req, "schedules", schedule.id, "INSERT", null, schedule);
    return res.status(201).json({ message: "برنامه کاری اضافه شد", schedule });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function editSchedule(req, res) {
  try {
    const { doctorId, dayOfWeek, startTime, endTime, breakStart, breakEnd } = req.body;
    if (doctorId && dayOfWeek && startTime && endTime) {
      const overlap = await hasOverlappingSchedule({ doctorId, dayOfWeek, startTime, endTime, excludeScheduleId: req.params.id });
      if (overlap) {
        return res.status(409).json({ message: "این بازه با یک برنامه کاری موجود برای همین داکتر و روز تداخل دارد", code: "SCHEDULE_OVERLAP" });
      }
    }
    const existing = await getScheduleById(req.params.id);
    if (!existing) return res.status(404).json({ message: "برنامه کاری یافت نشد" });
    const schedule = await updateSchedule(req.params.id, { dayOfWeek, startTime, endTime, breakStart, breakEnd });
    await logAdmin(req, "ویرایش برنامه کاری", `scheduleId=${req.params.id}`);
    await auditAdmin(req, "schedules", req.params.id, "UPDATE", existing, schedule);
    return res.status(200).json({ message: "برنامه کاری به‌روزرسانی شد", schedule });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function removeSchedule(req, res) {
  try {
    const existing = await getScheduleById(req.params.id);
    if (!existing) return res.status(404).json({ message: "برنامه کاری یافت نشد" });
    await deleteSchedule(req.params.id);
    await logAdmin(req, "حذف برنامه کاری", `scheduleId=${req.params.id}`);
    await auditAdmin(req, "schedules", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "برنامه کاری حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


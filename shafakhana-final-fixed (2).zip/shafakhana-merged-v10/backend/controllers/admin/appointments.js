import { updateAppointmentStatus, deleteAppointment, getAppointmentById, searchAppointments, getAppointmentStatusHistory } from "../../models/Appointment.js";
// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import { createNotification } from "../../models/Notification.js";
import { notifyAppointmentStatusChange } from "../../utils/appointmentNotifications.js";

import { formatJalaliDate } from "../../utils/jalali.js";
import { logAdmin, auditAdmin } from "./shared.js";

// ---------- نوبت‌ها ----------
// همیشه صفحه‌بندی‌شده است (حتی بدون هیچ فیلتری) تا با رشد تعداد نوبت‌ها کند نشود:
// GET /admin/appointments?status=...&dateFrom=...&dateTo=...&q=...&page=1&limit=10
export async function listAppointmentsAdmin(req, res) {
  try {
    const { status, dateFrom, dateTo, department, doctorId, q, page, limit } = req.query;

    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchAppointments({
      status,
      dateFrom,
      dateTo,
      department,
      doctorId,
      q,
      page,
      limit,
    });
    return res.status(200).json({
      appointments: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function changeAppointmentStatus(req, res) {
  try {
    const { status, note } = req.body;
    const allowed = ["pending", "confirmed", "completed", "cancelled"];
    if (!allowed.includes(status)) return res.status(400).json({ message: "وضعیت نامعتبر است" });
    const existing = await getAppointmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نوبت یافت نشد" });
    const appointment = await updateAppointmentStatus(req.params.id, status, {
      changedByUserId: req.user.id,
      changedByRole: req.user.role,
      note,
    });
    await logAdmin(req, "تغییر وضعیت نوبت", `appointmentId=${req.params.id} -> ${status}`);
    await auditAdmin(req, "appointments", req.params.id, "UPDATE", existing, appointment);

    // در صورتی که این نوبت متعلق به یک کاربر واردشده باشد، از تغییر وضعیت مطلع می‌شود
    await notifyAppointmentStatusChange(existing, status);

    return res.status(200).json({ message: "وضعیت نوبت به‌روزرسانی شد", appointment });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// تاریخچه‌ی کامل تغییرات وضعیت یک نوبت (برای پنل ادمین)
export async function appointmentHistory(req, res) {
  try {
    const existing = await getAppointmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نوبت یافت نشد" });
    const history = await getAppointmentStatusHistory(req.params.id);
    return res.status(200).json({ appointment: existing, history });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function removeAppointment(req, res) {
  try {
    const existing = await getAppointmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "نوبت یافت نشد" });
    await deleteAppointment(req.params.id);
    await logAdmin(req, "حذف نوبت", `appointmentId=${req.params.id}`);
    await auditAdmin(req, "appointments", req.params.id, "DELETE", existing, null);

    // حذف نوبت هم برای بیمار به‌معنای لغو آن است
    if (existing && existing.patientUserId) {
      await createNotification({
        userId: existing.patientUserId,
        title: "نوبت لغو شد",
        message: `نوبت شما نزد ${existing.doctorName} برای تاریخ ${formatJalaliDate(existing.appointmentDate, { month: "long" })} از سیستم حذف/لغو شد.`,
        type: "appointment",
        relatedId: existing.id,
      });
    }

    return res.status(200).json({ message: "نوبت حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


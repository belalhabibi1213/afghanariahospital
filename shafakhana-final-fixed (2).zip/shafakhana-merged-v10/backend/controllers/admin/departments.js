import path from "path";
// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import { getAllDepartments, createDepartment, updateDepartment, deleteDepartment, getDepartmentById, searchDepartments } from "../../models/Department.js";
import { DEPARTMENTS_DIR } from "../../middleware/upload.js";
import { removeUploadedFile } from "../../utils/uploadStore.js";

import { logAdmin, auditAdmin } from "./shared.js";

// ---------- بخش‌ها (Departments) ----------
// پشتیبانی از جستجو (نام/توضیحات/نامک)، فیلتر وضعیت، مرتب‌سازی و صفحه‌بندی:
// GET /admin/departments?q=...&status=...&sortBy=...&sortOrder=...&page=1&limit=10
// اگر هیچ query param ای ارسال نشود، رفتار قبلی (همه بخش‌ها، بدون صفحه‌بندی) حفظ
// می‌شود — همان مصرف‌کننده‌های قبلی (انتخاب‌گر بخش در فرم داکتران، فیلتر گزارش‌ها) بدون
// تغییر کار می‌کنند.
export async function listDepartments(req, res) {
  try {
    const { q, status, sortBy, sortOrder, page, limit } = req.query;
    if (!q && !status && !sortBy && !sortOrder && !page && !limit) {
      const departments = await getAllDepartments();
      return res.status(200).json({ departments });
    }

    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchDepartments({
      q,
      status,
      sortBy,
      sortOrder,
      page,
      limit,
    });
    return res.status(200).json({
      departments: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ثبت بخش جدید — همه‌ی فیلدهای مدیریتی (آیکون/رنگ‌بندی/ترتیب نمایش/وضعیت/سئو) اختیاری‌اند
// و در صورت عدم ارسال، مقدار پیش‌فرض ستون دیتابیس را می‌گیرند (models/Department.js).
// اعتبارسنجی ورودی توسط createDepartmentValidation در سطح روتر انجام می‌شود.
export async function addDepartment(req, res) {
  try {
    const {
      name, nameEn, description, descriptionEn, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    } = req.body;

    const department = await createDepartment({
      name, nameEn, description, descriptionEn, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    });

    await logAdmin(req, "افزودن بخش جدید", name);
    await auditAdmin(req, "departments", department.id, "INSERT", null, department);
    return res.status(201).json({ message: "بخش جدید ساخته شد", department });
  } catch (err) {
    // نام/نامک (slug) بخش UNIQUE است؛ در صورت تکراری بودن، پیام روشن به‌جای خطای خام دیتابیس
    if (err && err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ message: "بخشی با این نام از قبل وجود دارد" });
    }
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ویرایش بخش — به‌روزرسانی جزئی مجاز است (فقط فیلدهای ارسال‌شده تغییر می‌کنند، بقیه
// دست‌نخورده باقی می‌مانند). اعتبارسنجی ورودی توسط updateDepartmentValidation انجام می‌شود.
export async function editDepartment(req, res) {
  try {
    const existing = await getDepartmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "بخش یافت نشد" });

    const {
      name, nameEn, description, descriptionEn, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    } = req.body;

    const department = await updateDepartment(req.params.id, {
      name, nameEn, description, descriptionEn, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
      slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
    });

    await logAdmin(req, "ویرایش بخش", `departmentId=${req.params.id}`);
    await auditAdmin(req, "departments", req.params.id, "UPDATE", existing, department);
    return res.status(200).json({ message: "بخش به‌روزرسانی شد", department });
  } catch (err) {
    if (err && err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ message: "بخشی با این نام از قبل وجود دارد" });
    }
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function removeDepartment(req, res) {
  try {
    const existing = await getDepartmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "بخش یافت نشد" });
    await deleteDepartment(req.params.id);
    // اگر آیکون بخش یک فایل آپلودی (نه Lucide) بود، از دیسک هم پاک می‌شود تا فایل یتیم
    // باقی نماند (همان الگوی پاک‌سازی هنگام جایگزینی آیکون در uploadDepartmentIcon)
    if (isOwnDepartmentIconUpload(existing.icon)) {
      removeUploadedFile(path.join(DEPARTMENTS_DIR, path.basename(existing.icon)));
    }
    if (isOwnDepartmentIconUpload(existing.coverImage)) {
      removeUploadedFile(path.join(DEPARTMENTS_DIR, path.basename(existing.coverImage)));
    }
    await logAdmin(req, "حذف بخش", `departmentId=${req.params.id}`);
    await auditAdmin(req, "departments", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "بخش حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// آیا آیکون فعلی بخش از همین آپلودکننده (backend/uploads/departments) ذخیره شده؟ اگر بله،
// موقع جایگزینی با آیکون تازه یا حذف بخش، نسخه‌ی قبلی از دیسک پاک می‌شود تا فایل یتیم
// باقی نماند (همان الگوی isOwnDoctorUpload برای عکس داکتر)
function isOwnDepartmentIconUpload(icon) {
  return typeof icon === "string" && icon.startsWith("/uploads/departments/");
}


// آپلود آیکون بخش (POST /admin/departments/:id/icon) — فقط admin/superadmin.
// فایل توسط uploadDepartmentIcon (multer) و verifyDepartmentIconContent (بررسی امضای
// باینری PNG/JPG یا پاک‌سازی محتوای SVG) پیش از رسیدن به این تابع پردازش شده است.
export async function uploadDepartmentIcon(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    }

    const existing = await getDepartmentById(req.params.id);
    if (!existing) {
      // بخشی با این شناسه وجود ندارد؛ فایل آپلودشده اما بی‌مصرف پاک می‌شود
      removeUploadedFile(req.file.path);
      return res.status(404).json({ message: "بخش یافت نشد" });
    }

    const relativeUrl = `/uploads/departments/${req.file.filename}`;
    const department = await updateDepartment(req.params.id, { icon: relativeUrl, iconType: "upload" });

    if (isOwnDepartmentIconUpload(existing.icon)) {
      removeUploadedFile(path.join(DEPARTMENTS_DIR, path.basename(existing.icon)));
    }

    await logAdmin(req, "آپلود آیکون بخش", `departmentId=${req.params.id}`);
    await auditAdmin(req, "departments", req.params.id, "UPDATE", existing, department);
    return res.status(200).json({ message: "آیکون بخش با موفقیت به‌روزرسانی شد", department });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}



// آپلود عکس کاور بخش (POST /admin/departments/:id/cover) — فقط admin/superadmin.
// فایل پیش‌تر توسط uploadDepartmentCover (multer) و verifyImageContent (امضای باینری) بررسی شده است.
export async function uploadDepartmentCoverImage(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    }

    const existing = await getDepartmentById(req.params.id);
    if (!existing) {
      removeUploadedFile(req.file.path);
      return res.status(404).json({ message: "بخش یافت نشد" });
    }

    const relativeUrl = `/uploads/departments/${req.file.filename}`;
    const department = await updateDepartment(req.params.id, { coverImage: relativeUrl });

    if (isOwnDepartmentIconUpload(existing.coverImage)) {
      removeUploadedFile(path.join(DEPARTMENTS_DIR, path.basename(existing.coverImage)));
    }

    await logAdmin(req, "آپلود عکس کاور بخش", `departmentId=${req.params.id}`);
    await auditAdmin(req, "departments", req.params.id, "UPDATE", existing, department);
    return res.status(200).json({ message: "عکس کاور بخش با موفقیت به‌روزرسانی شد", department });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// حذف عکس کاور بخش (DELETE /admin/departments/:id/cover) — سایت به عکس پیش‌فرض تخصص برمی‌گردد.
export async function removeDepartmentCoverImage(req, res) {
  try {
    const existing = await getDepartmentById(req.params.id);
    if (!existing) return res.status(404).json({ message: "بخش یافت نشد" });

    const department = await updateDepartment(req.params.id, { coverImage: "" });
    if (isOwnDepartmentIconUpload(existing.coverImage)) {
      removeUploadedFile(path.join(DEPARTMENTS_DIR, path.basename(existing.coverImage)));
    }

    await logAdmin(req, "حذف عکس کاور بخش", `departmentId=${req.params.id}`);
    await auditAdmin(req, "departments", req.params.id, "UPDATE", existing, department);
    return res.status(200).json({ message: "عکس کاور بخش حذف شد", department });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import {
  getContactMessagesAdmin, getContactMessageById, getContactMessageStats,
  updateContactMessageStatus, deleteContactMessage,
  updateContactMessageFlags, getContactMessagesByIds, bulkUpdateContactMessages, bulkDeleteContactMessages,
  CONTACT_TYPES,
} from "../../models/Contact.js";

import { logAdmin, auditAdmin } from "./shared.js";

// GET /api/admin/contacts — فهرست صفحه‌بندی‌شده (سمت سرور) با فیلتر و جستجو
// query: page, limit (حداکثر ۱۰۰)، status = new|read|important|answered (unread هم برای سازگاری قبول است)،
// type = suggestion|criticism|complaint|question|other، q، dateFrom، dateTo
// پاسخ: { messages, pagination: { page, limit, total, totalPages } } — متن کامل پیام نیست، فقط preview
export async function listContactMessages(req, res) {
  try {
    const { status, type, q, dateFrom, dateTo, page, limit } = req.query;
    if (status && !["new", "unread", "read", "important", "answered"].includes(status)) {
      return res.status(400).json({ message: "وضعیت نامعتبر است" });
    }
    if (type && !CONTACT_TYPES.includes(type)) {
      return res.status(400).json({ message: "نوع پیام نامعتبر است" });
    }
    const result = await getContactMessagesAdmin({ status, type, q, dateFrom, dateTo, page, limit });
    return res.status(200).json(result);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// GET /api/admin/contacts/stats — مجموع/جدید/خوانده‌شده/مهم/پاسخ‌داده‌شده برای کارت‌های آماری
export async function getContactMessageStatistics(req, res) {
  try {
    const stats = await getContactMessageStats();
    return res.status(200).json({ stats });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// GET /api/admin/contacts/:id — نمایش متن کامل پیام؛ به‌صورت خودکار به «خوانده‌شده» تغییر می‌کند
export async function viewContactMessage(req, res) {
  try {
    const existing = await getContactMessageById(req.params.id);
    if (!existing) return res.status(404).json({ message: "پیام یافت نشد" });

    let message = existing;
    if (existing.status !== "read") {
      message = await updateContactMessageStatus(req.params.id, "read");
      await logAdmin(req, "مشاهده پیام تماس با ما", `contactId=${req.params.id}`);
      await auditAdmin(req, "contacts", req.params.id, "UPDATE", existing, message);
    }
    return res.status(200).json({ message: "دریافت پیام موفق بود", contact: message });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// PUT /api/admin/contacts/:id/status — تغییر دستی وضعیت پیام (خوانده‌شده/نخوانده)
export async function changeContactMessageStatus(req, res) {
  try {
    const { status } = req.body;
    const existing = await getContactMessageById(req.params.id);
    if (!existing) return res.status(404).json({ message: "پیام یافت نشد" });

    const contact = await updateContactMessageStatus(req.params.id, status);
    await logAdmin(req, status === "read" ? "علامت‌گذاری پیام به‌عنوان خوانده‌شده" : "علامت‌گذاری پیام به‌عنوان نخوانده", `contactId=${req.params.id}`);
    await auditAdmin(req, "contacts", req.params.id, "UPDATE", existing, contact);

    const message = status === "read" ? "پیام به‌عنوان خوانده‌شده علامت‌گذاری شد" : "پیام به‌عنوان نخوانده علامت‌گذاری شد";
    return res.status(200).json({ message, contact });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// DELETE /api/admin/contacts/:id — حذف کامل یک پیام
export async function removeContactMessage(req, res) {
  try {
    const existing = await getContactMessageById(req.params.id);
    if (!existing) return res.status(404).json({ message: "پیام یافت نشد" });

    await deleteContactMessage(req.params.id);
    await logAdmin(req, "حذف پیام تماس با ما", `contactId=${req.params.id}`);
    await auditAdmin(req, "contacts", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "پیام حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// PUT /api/admin/contacts/:id/flags — body: { isImportant?: boolean, isAnswered?: boolean }
export async function changeContactMessageFlags(req, res) {
  try {
    const { isImportant, isAnswered } = req.body;
    const existing = await getContactMessageById(req.params.id);
    if (!existing) return res.status(404).json({ message: "پیام یافت نشد" });

    const contact = await updateContactMessageFlags(req.params.id, { isImportant, isAnswered });
    if (typeof isImportant === "boolean") {
      await logAdmin(req, isImportant ? "علامت‌گذاری پیام به‌عنوان مهم" : "برداشتن علامت مهم از پیام", `contactId=${req.params.id}`);
    }
    if (typeof isAnswered === "boolean") {
      await logAdmin(req, isAnswered ? "علامت‌گذاری پیام به‌عنوان پاسخ‌داده‌شده" : "برداشتن علامت پاسخ‌داده‌شده از پیام", `contactId=${req.params.id}`);
    }
    await auditAdmin(req, "contacts", req.params.id, "UPDATE", existing, contact);
    return res.status(200).json({ message: "وضعیت پیام به‌روزرسانی شد", contact });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// POST /api/admin/contacts/bulk — body: { ids: number[], action: read|unread|important|unimportant|answered|unanswered|delete }
// حداکثر ۲۰۰ پیام در هر درخواست؛ برای هر پیام یک رکورد آدیت جداگانه ثبت می‌شود (مثل حذف گروهی بیماران)
export async function bulkContactMessages(req, res) {
  try {
    const { ids, action } = req.body;
    const cleanIds = [...new Set((Array.isArray(ids) ? ids : []).map((id) => parseInt(id, 10)).filter((id) => Number.isInteger(id) && id > 0))];
    if (cleanIds.length === 0) return res.status(400).json({ message: "حداقل یک پیام باید انتخاب شود" });
    if (cleanIds.length > 200) return res.status(400).json({ message: "حداکثر ۲۰۰ پیام را می‌توانید هم‌زمان انتخاب کنید" });

    const existing = await getContactMessagesByIds(cleanIds);
    if (existing.length === 0) return res.status(404).json({ message: "هیچ‌کدام از پیام‌های انتخاب‌شده یافت نشد" });
    const foundIds = existing.map((m) => m.id);

    const PATCHES = {
      read: { status: "read" }, unread: { status: "unread" },
      important: { isImportant: true }, unimportant: { isImportant: false },
      answered: { isAnswered: true }, unanswered: { isAnswered: false },
    };
    const LABELS = {
      read: "علامت‌گذاری گروهی پیام‌ها به‌عنوان خوانده‌شده", unread: "علامت‌گذاری گروهی پیام‌ها به‌عنوان نخوانده",
      important: "علامت‌گذاری گروهی پیام‌ها به‌عنوان مهم", unimportant: "برداشتن علامت مهم از پیام‌ها (گروهی)",
      answered: "علامت‌گذاری گروهی پیام‌ها به‌عنوان پاسخ‌داده‌شده", unanswered: "برداشتن علامت پاسخ‌داده‌شده از پیام‌ها (گروهی)",
    };

    if (action === "delete") {
      const affected = await bulkDeleteContactMessages(foundIds);
      await logAdmin(req, "حذف گروهی پیام‌های تماس با ما", `contactIds=${foundIds.join(",")} تعداد=${affected}`);
      await Promise.all(existing.map((m) => auditAdmin(req, "contacts", m.id, "DELETE", m, null)));
      return res.status(200).json({ message: `${affected} پیام حذف شد`, affected });
    }
    if (!PATCHES[action]) return res.status(400).json({ message: "عملیات نامعتبر است" });

    const affected = await bulkUpdateContactMessages(foundIds, PATCHES[action]);
    await logAdmin(req, LABELS[action], `contactIds=${foundIds.join(",")} تعداد=${affected}`);
    await Promise.all(existing.map((m) => auditAdmin(req, "contacts", m.id, "UPDATE", m, { ...m, ...PATCHES[action] })));
    return res.status(200).json({ message: `${affected} پیام به‌روزرسانی شد`, affected });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


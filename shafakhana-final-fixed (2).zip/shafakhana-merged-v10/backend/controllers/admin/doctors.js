import path from "path";
import { getNextDoctorCode, getAllDoctors, createDoctor, updateDoctor, deleteDoctor, getDoctorById, updateDoctorPhoto, searchDoctors, linkDoctorAccount, getDoctorsForExport } from "../../models/Doctor.js";
// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import { createStaffUser, findByEmail } from "../../models/User.js";
import { DOCTORS_DIR } from "../../middleware/upload.js";
import { removeUploadedFile } from "../../utils/uploadStore.js";
import { getPasswordPolicyError } from "../../utils/passwordPolicy.js";
import { sendPdfReport, sendExcelReport } from "../../utils/reportExport.js";

import { logAdmin, auditAdmin } from "./shared.js";

// ---------- داکتران ----------
// پشتیبانی از فیلتر بخش (department)، جستجوی تخصص/نام (specialty/q) و صفحه‌بندی:
// GET /admin/doctors?department=...&specialty=...&q=...&page=1&limit=10
// اگر هیچ query param ای ارسال نشود، رفتار قبلی (همه داکتران) حفظ می‌شود.
export async function listDoctorsAdmin(req, res) {
  try {
    const { department, specialty, gender, q, page, limit } = req.query;
    if (!department && !specialty && !gender && !q && !page && !limit) {
      const doctors = await getAllDoctors();
      return res.status(200).json({ doctors });
    }

    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchDoctors({
      department,
      specialty,
      gender,
      q,
      page,
      limit,
    });
    return res.status(200).json({
      doctors: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


const DOCTOR_GENDER_LABEL = { men: "آقا", women: "خانم" };


// ---------- خروجی Excel/PDF فهرست داکتران (پنل مدیریت داکتران) ----------
// GET /api/admin/doctors/export?format=excel|pdf&department=...&specialty=...
export async function exportDoctors(req, res) {
  try {
    const { format, department, specialty } = req.query;
    if (format !== "excel" && format !== "pdf") {
      return res.status(400).json({ message: "فرمت خروجی نامعتبر است (excel یا pdf)" });
    }

    const rows = await getDoctorsForExport({ department, specialty });

    const columns = [
      { header: "شناسه", key: "doctorCode", width: 0.9 },
      { header: "نام", key: "fullName", width: 1.8 },
      { header: "بخش", key: "department", width: 1.4 },
      { header: "سابقه", key: "yearsExperienceLabel", width: 0.8 },
      { header: "امتیاز", key: "ratingLabel", width: 0.8 },
      { header: "روزهای کاری", key: "workDays", width: 1.6 },
    ];
    const exportRows = rows.map((r) => ({
      ...r,
      doctorCode: r.doctorCode || "—",
      genderLabel: DOCTOR_GENDER_LABEL[r.gender] || "—",
      yearsExperienceLabel: r.yearsExperience != null ? String(r.yearsExperience) : "—",
      ratingLabel: r.rating != null ? String(r.rating) : "—",
      workDays: r.workDays || "—",
    }));
    const summaryLines = [`تعداد کل داکتران: ${rows.length}`];

    await logAdmin(req, "خروجی‌گیری از فهرست داکتران", `format=${format} تعداد=${rows.length}`);

    if (format === "pdf") {
      sendPdfReport(res, { fileName: "doctors-list", title: "لیست داکتران", columns, rows: exportRows, summaryLines });
      return;
    }
    await sendExcelReport(res, { fileName: "doctors-list", title: "لیست داکتران", columns, rows: exportRows, summaryLines });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// GET /admin/doctors/next-code — شناسه‌ی پیشنهادی بعدی برای نمایش در فرم افزودن
export async function nextDoctorCode(req, res) {
  try {
    return res.json({ doctorCode: await getNextDoctorCode() });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function addDoctor(req, res) {
  try {
    const { fullName, department, yearsExperience, gender, rating, workDays, bio } = req.body;
    const photoUrl = isOwnDoctorUpload(req.body.photoUrl) ? req.body.photoUrl : null; // فقط عکس آپلودشده
    let doctorCode = String(req.body.doctorCode || "").trim();
    if (!fullName || !department) return res.status(400).json({ message: "نام و بخش داکتر الزامی است" });
    const auto = !doctorCode; // شناسه ارسال نشده → خودکار (DR-1010 و ...)
    let doctor = null;
    for (let attempt = 0; attempt < 5 && !doctor; attempt++) {
      if (auto) doctorCode = await getNextDoctorCode();
      try {
        doctor = await createDoctor({ doctorCode, fullName, department, yearsExperience, gender, rating, workDays, photoUrl, bio });
      } catch (e) {
        // دو افزودن هم‌زمان ممکن است یک شناسه بگیرند؛ در حالت خودکار دوباره با شناسه‌ی بعدی تلاش می‌شود
        if (!(auto && e && e.code === "ER_DUP_ENTRY")) throw e;
      }
    }
    if (!doctor) return res.status(409).json({ message: "ساخت شناسه‌ی خودکار ناموفق بود؛ دوباره تلاش کنید" });
    await logAdmin(req, "افزودن داکتر جدید", `doctorId=${doctor.id} doctorCode=${doctorCode}`);
    await auditAdmin(req, "doctors", doctor.id, "INSERT", null, doctor);
    return res.status(201).json({ message: "داکتر جدید اضافه شد", doctor });
  } catch (err) {
    // محافظت نهایی در برابر شرایط رقابتی (دو درخواست هم‌زمان با یک شناسه یکسان)؛
    // بررسی اصلی پیش از این توسط doctorValidation انجام شده است
    if (err && err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ message: "این شناسه داکتر قبلاً استفاده شده است" });
    }
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function editDoctor(req, res) {
  try {
    const existing = await getDoctorById(req.params.id);
    if (!existing) return res.status(404).json({ message: "داکتر یافت نشد" });
    const { doctorCode, fullName, department, yearsExperience, gender, rating, workDays, bio } = req.body;
    const photoUrl = isOwnDoctorUpload(req.body.photoUrl) ? req.body.photoUrl : null; // فقط عکس آپلودشده
    const doctor = await updateDoctor(req.params.id, { doctorCode, fullName, department, yearsExperience, gender, rating, workDays, photoUrl, bio });
    await logAdmin(req, "ویرایش داکتر", `doctorId=${req.params.id}`);
    await auditAdmin(req, "doctors", req.params.id, "UPDATE", existing, doctor);
    return res.status(200).json({ message: "اطلاعات داکتر به‌روزرسانی شد", doctor });
  } catch (err) {
    if (err && err.code === "ER_DUP_ENTRY") {
      return res.status(409).json({ message: "این شناسه داکتر قبلاً استفاده شده است" });
    }
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function removeDoctor(req, res) {
  try {
    const existing = await getDoctorById(req.params.id);
    if (!existing) return res.status(404).json({ message: "داکتر یافت نشد" });
    await deleteDoctor(req.params.id);
    // اگر عکس داکتر از طریق همین سامانه آپلود شده بود (نه یک عکس ثابت داخل فرانت‌اند)،
    // فایل آن هم از دیسک پاک می‌شود تا فایل یتیم باقی نماند
    if (existing && isOwnDoctorUpload(existing.photoUrl)) {
      removeUploadedFile(path.join(DOCTORS_DIR, path.basename(existing.photoUrl)));
    }
    await logAdmin(req, "حذف داکتر", `doctorId=${req.params.id}`);
    await auditAdmin(req, "doctors", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "داکتر حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// آپلود / جایگزینی عکس داکتر (فقط ادمین). عکس قبلیِ آپلودشده (در صورت وجود) از دیسک حذف
// می‌شود تا فایل یتیم روی سرور باقی نماند. محتوای فایل پیش از رسیدن به این کنترلر توسط
// میان‌افزارهای uploadDoctorPhoto و verifyImageContent اعتبارسنجی شده است.
function isOwnDoctorUpload(photoUrl) {
  return typeof photoUrl === "string" && photoUrl.startsWith("/uploads/doctors/");
}


export async function changeDoctorPhoto(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    }

    const existing = await getDoctorById(req.params.id);
    if (!existing) {
      // داکتری با این شناسه وجود ندارد؛ فایل آپلودشده اما بی‌مصرف پاک می‌شود
      removeUploadedFile(req.file.path);
      return res.status(404).json({ message: "داکتر یافت نشد" });
    }

    const relativeUrl = `/uploads/doctors/${req.file.filename}`;
    const doctor = await updateDoctorPhoto(req.params.id, relativeUrl);

    if (isOwnDoctorUpload(existing.photoUrl)) {
      removeUploadedFile(path.join(DOCTORS_DIR, path.basename(existing.photoUrl)));
    }

    await logAdmin(req, "آپلود عکس داکتر", `doctorId=${req.params.id}`);
    await auditAdmin(req, "doctors", req.params.id, "UPDATE", existing, doctor);
    return res.status(200).json({ message: "عکس داکتر با موفقیت به‌روزرسانی شد", doctor });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ساخت حساب ورود برای یک داکتر موجود (نقش 'doctor') — تا داکتر بتواند وارد شود
// و نوبت‌های خودش را تایید/رد کند. فقط توسط admin/superadmin قابل انجام است.
export async function createDoctorAccount(req, res) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: "ایمیل و رمز عبور الزامی است" });
    }
    const passwordError = getPasswordPolicyError(password);
    if (passwordError) {
      return res.status(400).json({ message: passwordError });
    }

    const doctor = await getDoctorById(req.params.id);
    if (!doctor) return res.status(404).json({ message: "داکتر یافت نشد" });
    if (doctor.userId) {
      return res.status(409).json({ message: "این داکتر از قبل حساب کاربری دارد" });
    }

    const existingUser = await findByEmail(email);
    if (existingUser) {
      return res.status(409).json({ message: "این ایمیل قبلاً ثبت شده است" });
    }

    const user = await createStaffUser({ fullName: doctor.fullName, email, password, role: "doctor" });
    await linkDoctorAccount(doctor.id, user.id);
    await logAdmin(req, "ساخت حساب کاربری داکتر", `doctorId=${doctor.id} email=${email}`);
    await auditAdmin(req, "users", user.id, "INSERT", null, { id: user.id, email: user.email, role: "doctor", doctorId: doctor.id });

    return res.status(201).json({
      message: "حساب کاربری داکتر با موفقیت ساخته شد",
      account: { id: user.id, email: user.email, role: "doctor" },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


import path from "path";
// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند
import { getAllNewsAdmin, getNewsById, createNews, updateNews, updateNewsStatus, updateNewsPin, updateNewsImage, deleteNews, getNewsStats, getNewsGallery, addNewsGalleryImages, getGalleryImageById, deleteNewsGalleryImage } from "../../models/News.js";
import { sanitizeNewsContent } from "../../utils/sanitizeNewsContent.js";
import { NEWS_DIR } from "../../middleware/upload.js";
import { removeUploadedFile } from "../../utils/uploadStore.js";

import { logAdmin, auditAdmin } from "./shared.js";

// بررسی می‌کند آیا عکس شاخص خبر از طریق همین سامانه آپلود شده (نه یک لینک خارجی/ثابت)،
// تا فقط فایل‌های واقعاً متعلق به این سرور از دیسک پاک شوند
function isOwnNewsUpload(imageUrl) {
  return typeof imageUrl === "string" && imageUrl.startsWith("/uploads/news/");
}


// ورودی tags می‌تواند آرایه (از فرانت‌اند) یا رشته‌ی جدا‌شده با کاما باشد؛ در هر دو حالت
// به یک رشته‌ی تمیزِ جدا‌شده با کاما (برای ذخیره در ستون tags) تبدیل می‌شود
function normalizeTags(tags) {
  if (Array.isArray(tags)) {
    return tags.map((t) => String(t).trim()).filter(Boolean).join(", ") || null;
  }
  if (typeof tags === "string") {
    return tags
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean)
      .join(", ") || null;
  }
  return null;
}


export async function listNewsAdmin(req, res) {
  try {
    const news = await getAllNewsAdmin();
    return res.status(200).json({ news });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function addNews(req, res) {
  try {
    const { title, titleEn, excerpt, excerptEn, content, contentEn, tag, tags, author, status, scheduledAt, isPinned, metaTitle, metaDescription } = req.body;

    if (status === "scheduled" && (!scheduledAt || new Date(scheduledAt).getTime() <= Date.now())) {
      return res.status(400).json({ message: "برای زمان‌بندی انتشار، تاریخ/ساعت باید در آینده باشد" });
    }

    const news = await createNews({
      title,
      titleEn: titleEn ? String(titleEn).trim() : null,
      excerpt,
      excerptEn: excerptEn ? String(excerptEn).trim() : null,
      content: sanitizeNewsContent(content),
      contentEn: contentEn ? sanitizeNewsContent(contentEn) : null,
      tag,
      tags: normalizeTags(tags),
      author,
      status,
      scheduledAt: status === "scheduled" ? scheduledAt : null,
      isPinned: !!isPinned,
      metaTitle: metaTitle ? String(metaTitle).trim() : null,
      metaDescription: metaDescription ? String(metaDescription).trim() : null,
    });
    await logAdmin(req, "افزودن خبر جدید", title);
    await auditAdmin(req, "news", news.id, "INSERT", null, news);
    return res.status(201).json({ message: "خبر جدید ثبت شد", news });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function editNews(req, res) {
  try {
    const { title, titleEn, excerpt, excerptEn, content, contentEn, tag, tags, author, status, scheduledAt, isPinned, metaTitle, metaDescription } = req.body;
    const existing = await getNewsById(req.params.id);
    if (!existing) return res.status(404).json({ message: "خبر یافت نشد" });

    const effectiveStatus = status || existing.status;
    if (effectiveStatus === "scheduled" && (!scheduledAt || new Date(scheduledAt).getTime() <= Date.now())) {
      return res.status(400).json({ message: "برای زمان‌بندی انتشار، تاریخ/ساعت باید در آینده باشد" });
    }

    // فیلدهای انگلیسی: اگر در بدنه نیامده باشند (کلاینت قدیمی)، مقدار فعلی حفظ می‌شود
    const news = await updateNews(req.params.id, {
      title,
      titleEn: titleEn !== undefined ? (titleEn ? String(titleEn).trim() : null) : existing.titleEn,
      excerpt,
      excerptEn: excerptEn !== undefined ? (excerptEn ? String(excerptEn).trim() : null) : existing.excerptEn,
      content: sanitizeNewsContent(content),
      contentEn: contentEn !== undefined ? (contentEn ? sanitizeNewsContent(contentEn) : null) : existing.contentEn,
      tag,
      tags: normalizeTags(tags),
      author,
      status: effectiveStatus,
      scheduledAt: effectiveStatus === "scheduled" ? scheduledAt : null,
      isPinned: isPinned === undefined ? !!existing.isPinned : !!isPinned,
      metaTitle: metaTitle !== undefined ? (metaTitle ? String(metaTitle).trim() : null) : existing.metaTitle,
      metaDescription: metaDescription !== undefined ? (metaDescription ? String(metaDescription).trim() : null) : existing.metaDescription,
    });
    await logAdmin(req, "ویرایش خبر", `newsId=${req.params.id}`);
    await auditAdmin(req, "news", req.params.id, "UPDATE", existing, news);
    return res.status(200).json({ message: "خبر به‌روزرسانی شد", news });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// تغییر سریع وضعیت خبر: انتشار / لغو انتشار (بازگشت به پیش‌نویس)
export async function changeNewsStatus(req, res) {
  try {
    const { status } = req.body;
    const existing = await getNewsById(req.params.id);
    if (!existing) return res.status(404).json({ message: "خبر یافت نشد" });
    const news = await updateNewsStatus(req.params.id, status);
    await logAdmin(req, status === "published" ? "انتشار خبر" : "لغو انتشار خبر", `newsId=${req.params.id}`);
    await auditAdmin(req, "news", req.params.id, "UPDATE", existing, news);
    const message = status === "published" ? "خبر منتشر شد و اکنون در صفحه عمومی اخبار نمایش داده می‌شود" : "انتشار خبر لغو شد و به پیش‌نویس بازگشت";
    return res.status(200).json({ message, news });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function changeNewsImage(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    }

    const existing = await getNewsById(req.params.id);
    if (!existing) {
      // خبری با این شناسه وجود ندارد؛ فایل آپلودشده اما بی‌مصرف پاک می‌شود
      removeUploadedFile(req.file.path);
      return res.status(404).json({ message: "خبر یافت نشد" });
    }

    const relativeUrl = `/uploads/news/${req.file.filename}`;
    const news = await updateNewsImage(req.params.id, relativeUrl);

    if (isOwnNewsUpload(existing.imageUrl)) {
      removeUploadedFile(path.join(NEWS_DIR, path.basename(existing.imageUrl)));
    }

    await logAdmin(req, "آپلود عکس شاخص خبر", `newsId=${req.params.id}`);
    await auditAdmin(req, "news", req.params.id, "UPDATE", existing, news);
    return res.status(200).json({ message: "عکس شاخص خبر با موفقیت به‌روزرسانی شد", news });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function removeNews(req, res) {
  try {
    const existing = await getNewsById(req.params.id);
    if (!existing) return res.status(404).json({ message: "خبر یافت نشد" });
    await deleteNews(req.params.id);

    if (isOwnNewsUpload(existing.imageUrl)) {
      removeUploadedFile(path.join(NEWS_DIR, path.basename(existing.imageUrl)));
    }

    await logAdmin(req, "حذف خبر", `newsId=${req.params.id}`);
    await auditAdmin(req, "news", req.params.id, "DELETE", existing, null);
    return res.status(200).json({ message: "خبر حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// سنجاق‌کردن/برداشتن سنجاق یک خبر مهم — بالاترین اولویت نمایش هم در صفحه عمومی و هم در پنل ادمین
export async function changeNewsPin(req, res) {
  try {
    const { isPinned } = req.body;
    const existing = await getNewsById(req.params.id);
    if (!existing) return res.status(404).json({ message: "خبر یافت نشد" });
    const news = await updateNewsPin(req.params.id, !!isPinned);
    await logAdmin(req, isPinned ? "سنجاق‌کردن خبر" : "برداشتن سنجاق خبر", `newsId=${req.params.id}`);
    await auditAdmin(req, "news", req.params.id, "UPDATE", existing, news);
    const message = isPinned ? "خبر سنجاق شد و در بالای فهرست نمایش داده می‌شود" : "سنجاق خبر برداشته شد";
    return res.status(200).json({ message, news });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ---------- آمار داشبورد اخبار (Dashboard Statistics) ----------
export async function getNewsStatistics(req, res) {
  try {
    const stats = await getNewsStats();
    return res.status(200).json({ stats });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ---------- گالری تصاویر خبر (News Gallery) ----------
export async function listNewsGalleryAdmin(req, res) {
  try {
    const existing = await getNewsById(req.params.id);
    if (!existing) return res.status(404).json({ message: "خبر یافت نشد" });
    const gallery = await getNewsGallery(req.params.id);
    return res.status(200).json({ gallery });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function uploadNewsGalleryImages(req, res) {
  try {
    const files = req.files || [];
    if (files.length === 0) {
      return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    }

    const existing = await getNewsById(req.params.id);
    if (!existing) {
      // خبری با این شناسه وجود ندارد؛ فایل‌های آپلودشده اما بی‌مصرف پاک می‌شوند
      files.forEach((file) => removeUploadedFile(file.path));
      return res.status(404).json({ message: "خبر یافت نشد" });
    }

    const imageUrls = files.map((file) => `/uploads/news/${file.filename}`);
    const gallery = await addNewsGalleryImages(req.params.id, imageUrls);

    await logAdmin(req, "افزودن عکس به گالری خبر", `newsId=${req.params.id}, count=${files.length}`);
    await auditAdmin(req, "news_gallery", req.params.id, "INSERT", null, { added: imageUrls });
    return res.status(201).json({ message: "عکس‌های گالری با موفقیت اضافه شد", gallery });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


export async function removeNewsGalleryImage(req, res) {
  try {
    const image = await getGalleryImageById(req.params.imageId);
    // اطمینان از اینکه عکس واقعاً متعلق به همین خبر است (نه یک شناسه‌ی تصادفی از خبر دیگر)
    if (!image || String(image.newsId) !== String(req.params.id)) {
      return res.status(404).json({ message: "عکس گالری یافت نشد" });
    }

    await deleteNewsGalleryImage(req.params.imageId);
    if (isOwnNewsUpload(image.imageUrl)) {
      removeUploadedFile(path.join(NEWS_DIR, path.basename(image.imageUrl)));
    }

    await logAdmin(req, "حذف عکس از گالری خبر", `newsId=${req.params.id}, imageId=${req.params.imageId}`);
    await auditAdmin(req, "news_gallery", req.params.id, "DELETE", image, null);
    return res.status(200).json({ message: "عکس از گالری حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- مدیریت نظرات اخبار (News Comments Moderation) ----------
// نظرات کاربران واردشده با وضعیت 'pending' ثبت می‌شوند (controllers/newsController.js ->
// addNewsComment) و فقط پس از تایید ادمین در صفحه عمومی خبر نمایش داده می‌شوند.
// فقط Admin/Super Admin به این بخش دسترسی دارند (از طریق router.use در routes/admin.js).


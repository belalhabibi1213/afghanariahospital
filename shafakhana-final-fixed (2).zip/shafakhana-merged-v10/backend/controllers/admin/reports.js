import { countPatients, searchPatients } from "../../models/Patient.js";
import { countDoctors, searchDoctors } from "../../models/Doctor.js";
import { countAppointments, countAppointmentsThisMonth, countAllAppointments, countAppointmentsToday, getMonthlyAppointmentStats, searchAppointments } from "../../models/Appointment.js";
// پرونده‌ی کامل بیمار (صفحه‌ی اختصاصی جزئیات بیمار در پنل ادمین) — استفاده از همان
// توابع مدل‌هایی که ماژول EMR/صورت‌حساب/انتقال فایل قبلاً برای پنل داکتر/بیمار ساخته بودند


// ---------- جستجوی کلی (Global Search) ----------
// یک عبارت را همزمان در بیماران، داکتران و نوبت‌ها جستجو می‌کند و برای هر بخش
// حداکثر چند نتیجه برمی‌گرداند (مناسب برای نوار جستجوی سراسری داشبورد ادمین).
// GET /admin/search?q=...
export async function globalSearch(req, res) {
  try {
    const q = (req.query.q || "").trim();
    if (!q) {
      return res.status(200).json({ patients: [], doctors: [], appointments: [] });
    }

    const QUICK_RESULT_LIMIT = 5;
    const [patientsResult, doctorsResult, appointmentsResult] = await Promise.all([
      searchPatients({ q, page: 1, limit: QUICK_RESULT_LIMIT }),
      searchDoctors({ q, page: 1, limit: QUICK_RESULT_LIMIT }),
      searchAppointments({ q, page: 1, limit: QUICK_RESULT_LIMIT }),
    ]);

    return res.status(200).json({
      patients: patientsResult.rows,
      patientsTotal: patientsResult.total,
      doctors: doctorsResult.rows,
      doctorsTotal: doctorsResult.total,
      appointments: appointmentsResult.rows,
      appointmentsTotal: appointmentsResult.total,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}


// ---------- گزارش‌ها و آمار (داشبورد آنالیتیکس) ----------
export async function reports(req, res) {
  try {
    const { from, to } = req.query;
    const range = { from: from || undefined, to: to || undefined };

    const [
      totalPatients,
      totalDoctors,
      totalAppointments,
      todayAppointments,
      appointmentsByStatus,
      appointmentsThisMonth,
      monthlyRows,
    ] = await Promise.all([
      countPatients(),
      countDoctors(),
      countAllAppointments(range),
      countAppointmentsToday(),
      countAppointments(range),
      countAppointmentsThisMonth(),
      getMonthlyAppointmentStats(6, range),
    ]);

    // پر کردن ماه‌های بدون هیچ نوبتی با مقدار صفر. اگر بازه‌ی تاریخ انتخاب نشده باشد،
    // همان ۶ ماه اخیر (رفتار قبلی) کامل می‌شود؛ اگر بازه انتخاب شده باشد، ماه‌های داخل
    // همان بازه (از ماه شروع تا ماه پایان) کامل می‌شوند تا نمودار روند پیوسته بماند.
    const monthlyMap = new Map(monthlyRows.map((r) => [r.month, r.count]));
    const monthlyStats = [];
    if (range.from || range.to) {
      const startDate = range.from ? new Date(range.from) : new Date(monthlyRows[0]?.month ? `${monthlyRows[0].month}-01` : Date.now());
      const endDate = range.to ? new Date(range.to) : new Date();
      const cursor = new Date(startDate.getFullYear(), startDate.getMonth(), 1);
      const end = new Date(endDate.getFullYear(), endDate.getMonth(), 1);
      while (cursor <= end) {
        const key = `${cursor.getFullYear()}-${String(cursor.getMonth() + 1).padStart(2, "0")}`;
        monthlyStats.push({
          month: key,
          label: `${String(cursor.getMonth() + 1).padStart(2, "0")}/${cursor.getFullYear()}`,
          count: monthlyMap.get(key) || 0,
        });
        cursor.setMonth(cursor.getMonth() + 1);
      }
    } else {
      const now = new Date();
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        monthlyStats.push({
          month: key,
          label: `${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`,
          count: monthlyMap.get(key) || 0,
        });
      }
    }

    return res.status(200).json({
      totalPatients,
      totalDoctors,
      totalAppointments,
      todayAppointments,
      appointmentsByStatus,
      appointmentsThisMonth,
      monthlyStats,
      dateRange: { from: range.from || null, to: range.to || null },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- مدیریت اخبار و اعلانات (News & Announcements) ----------
// فقط Admin و Super Admin به این بخش دسترسی دارند (RBAC از طریق router.use در routes/admin.js
// اعمال می‌شود). کاربران و داکتران فقط اخبار «منتشرشده» را از مسیر عمومی GET /api/news می‌بینند
// (کنترلر controllers/newsController.js) — همان مسیر و رفتار قبلی صفحه عمومی اخبار بدون تغییر می‌ماند.


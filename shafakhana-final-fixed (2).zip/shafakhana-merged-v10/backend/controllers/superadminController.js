import fs from "fs";
import { escapeCsvCell } from "../utils/csv.js";
import fsp from "fs/promises";
import path from "path";
import os from "os";
import { fileURLToPath } from "url";
import { getPool } from "../db.js";
import {
  getAllUsers, createStaffUser, updateUserRole, setUserActive, deleteUser, findById, countUsersByRole,
} from "../models/User.js";
import { getFilteredLogs, getLogsForExport, logActivity } from "../models/ActivityLog.js";
import { recordAudit, getFilteredAuditLogs, getAuditLogsForExport, getAuditLogById, getAuditedTableNames } from "../models/AuditLog.js";
import { getAllSettings, getEditableSettings, setSetting, validateSettingsInput } from "../models/Settings.js";
import { LOGO_DIR } from "../middleware/upload.js";
import { removeUploadedFile } from "../utils/uploadStore.js";
import { countPatients, getPatientById } from "../models/Patient.js";
import { countDoctors, getDoctorById } from "../models/Doctor.js";
import { countAppointments } from "../models/Appointment.js";
import {
  createBackup, listBackups, deleteBackup, restoreBackup, getBackupFilePath, validateBackupFile, BACKUPS_DIR,
  applyBackupSchedule, getBackupScheduleStatus,
  getFoldersOverview, createFolder, updateFolder, deleteFolder, setActiveFolder, isValidFolderId, DEFAULT_FOLDER_ID,
  setCustomBackupDir,
} from "../utils/backup.js";
import { pickFolderDialog } from "../utils/folderPicker.js";
import { getPasswordPolicyError } from "../utils/passwordPolicy.js";
import { getActiveSessions, getInactiveSessions, findSessionById, revokeSessionById } from "../models/Session.js";

// مسیرهای واقعی روی دیسک برای بخش «سلامت سیستم» (System Health) — همان پوشه‌ی uploads
// عمومی که middleware/upload.js هم از آن استفاده می‌کند، برای بررسی واقعیِ دسترسی خواندن/نوشتن
const __filenameSuper = fileURLToPath(import.meta.url);
const BACKEND_ROOT = path.join(path.dirname(__filenameSuper), "..");
const UPLOADS_DIR = path.join(BACKEND_ROOT, "uploads");

const logSuper = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

// ثبت لاگ حسابرسی (audit_logs) برای تغییرات این کنترلر — با اطلاعات کاربر واردشده (Super Admin)
const auditSuper = (req, tableName, recordId, action, oldValues, newValues) =>
  recordAudit({
    req, tableName, recordId, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });

// ---------- مدیریت حساب‌های Admin ----------
export async function listAdmins(req, res) {
  try {
    const admins = await getAllUsers({ role: "admin" });
    return res.status(200).json({ admins });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function createAdmin(req, res) {
  try {
    const { fullName, email, password } = req.body;
    if (!fullName || !email || !password) return res.status(400).json({ message: "همه فیلدها الزامی است" });
    const passwordError = getPasswordPolicyError(password);
    if (passwordError) return res.status(400).json({ message: passwordError });
    const admin = await createStaffUser({ fullName, email, password, role: "admin" });
    await logSuper(req, "ساخت حساب ادمین جدید", email);
    await auditSuper(req, "users", admin.id, "INSERT", null, admin);
    return res.status(201).json({ message: "حساب ادمین جدید ساخته شد", admin });
  } catch (err) {
    if (err.code === "ER_DUP_ENTRY") return res.status(409).json({ message: "این ایمیل قبلاً ثبت شده است" });
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function editAdmin(req, res) {
  try {
    const { isActive } = req.body;
    const existing = await findById(req.params.id);
    if (!existing) return res.status(404).json({ message: "کاربر یافت نشد" });
    // این مسیر فقط برای مدیریت حساب‌های «ادمین» است؛ بدون این بررسی می‌شد با ارسال
    // شناسه‌ی یک بیمار/داکتر/حتی سوپرادمین دیگر، وضعیت فعال‌بودنِ او را از همین‌جا
    // (که در پنل فقط برای ادمین‌ها نمایش داده می‌شود) تغییر داد
    if (existing.role !== "admin") {
      return res.status(400).json({ message: "این عملیات فقط روی حساب‌های ادمین مجاز است" });
    }
    // مثل deleteAdmin/changeUserRole: مانع می‌شود سوپرادمین به‌اشتباه حساب خودش را
    // غیرفعال کند و از سیستم بیرون بماند (چون پس از آن دیگر نمی‌تواند آن را دوباره فعال کند)
    if (String(req.params.id) === String(req.user.id) && !isActive) {
      return res.status(400).json({ message: "نمی‌توانید حساب خودتان را غیرفعال کنید" });
    }
    const updated = await setUserActive(req.params.id, isActive);
    await logSuper(req, "تغییر وضعیت فعال/غیرفعال ادمین", `userId=${req.params.id} -> ${isActive ? "فعال" : "غیرفعال"}`);
    await auditSuper(req, "users", req.params.id, "UPDATE", existing, updated);
    return res.status(200).json({ message: "وضعیت حساب به‌روزرسانی شد", user: updated });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function deleteAdmin(req, res) {
  try {
    const target = await findById(req.params.id);
    if (!target) return res.status(404).json({ message: "کاربر یافت نشد" });
    // همان محافظتِ editAdmin: این مسیر نباید بتواند بیمار/داکتر/سوپرادمین دیگر را
    // حذف کند — فقط حساب‌هایی که واقعاً نقش admin دارند
    if (target.role !== "admin") {
      return res.status(400).json({ message: "این عملیات فقط روی حساب‌های ادمین مجاز است" });
    }
    if (String(req.params.id) === String(req.user.id)) {
      return res.status(400).json({ message: "نمی‌توانید حساب خودتان را حذف کنید" });
    }
    await deleteUser(req.params.id);
    await logSuper(req, "حذف حساب ادمین", `userId=${req.params.id} (${target.email})`);
    await auditSuper(req, "users", req.params.id, "DELETE", target, null);
    return res.status(200).json({ message: "حساب ادمین حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// حذف حساب داشبورد یک داکتر (فقط Super Admin — طبق router.use پایین در routes/superadmin.js).
// این کار فقط حساب ورود (users) را حذف می‌کند؛ پروفایل داکتر (جدول doctors) و سوابق پزشکی/نوبت‌های
// او دست‌نخورده باقی می‌مانند چون doctors.userId با ON DELETE SET NULL تعریف شده است، نه CASCADE.
export async function deleteDoctorAccount(req, res) {
  try {
    const doctor = await getDoctorById(req.params.id);
    if (!doctor) return res.status(404).json({ message: "داکتر یافت نشد" });
    if (!doctor.userId) {
      return res.status(400).json({ message: "این داکتر حساب داشبوردی ندارد که حذف شود" });
    }

    const account = await findById(doctor.userId);
    // اعتبارسنجی اضافی در برابر حذف تصادفی: اگر حساب متصل به این داکتر به هر دلیلی
    // نقش «doctor» نداشته باشد (مثلاً داده ناسازگار)، عملیات متوقف می‌شود
    if (!account || account.role !== "doctor") {
      return res.status(409).json({ message: "حساب کاربری متصل به این داکتر معتبر نیست" });
    }

    await deleteUser(doctor.userId);
    await logSuper(req, "حذف حساب داشبورد داکتر", `doctorId=${doctor.id} userId=${doctor.userId} (${account.email})`);
    await auditSuper(req, "users", doctor.userId, "DELETE", account, null);

    return res.status(200).json({ message: "حساب داشبورد داکتر با موفقیت حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- مدیریت نقش‌های کاربران (Assign / Change role) ----------
export async function listAllUsers(req, res) {
  try {
    const users = await getAllUsers();
    return res.status(200).json({ users });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function changeUserRole(req, res) {
  try {
    const { role } = req.body;
    // مدیر کل (Super Admin) هرگز از این مسیر قابل تخصیص نیست — بالاترین نقشی که
    // یک Super Admin می‌تواند به کاربری بدهد، «ادمین» است. این محدودیت باید هم در
    // فرانت‌اند (مخفی‌بودن گزینه در select) و هم اینجا در بک‌اند اعمال شود.
    // «داکتر» هم یک نقش معتبر و شناخته‌شده در سیستم است (برای RBAC مسیرهای
    // /api/doctors/*)، پس در فهرست نقش‌های مجاز قرار دارد؛ اما نمی‌توان از همین
    // مسیر یک حساب را به داکتر ارتقا داد چون نقش «داکتر» همیشه باید به یک
    // پروفایل داکتر (جدول doctors) متصل باشد — آن اتصال فقط توسط
    // createDoctorAccount (بخش «حساب‌های داکتر») انجام می‌شود.
    const allowedRoles = ["user", "admin", "doctor"];
    if (!allowedRoles.includes(role)) {
      return res.status(400).json({
        message: "نقش نامعتبر است؛ فقط نقش بیمار (User) یا ادمین (Admin) قابل تخصیص است",
      });
    }
    if (String(req.params.id) === String(req.user.id)) {
      return res.status(400).json({ message: "نمی‌توانید نقش خودتان را تغییر دهید" });
    }
    const target = await findById(req.params.id);
    if (!target) return res.status(404).json({ message: "کاربر یافت نشد" });
    // هیچ حساب Super Admin دیگری (حتی اگر مستقیماً در دیتابیس ساخته شده باشد) از این
    // مسیر قابل تغییر نقش نیست؛ حساب‌های مدیر کل باید دست‌نخورده باقی بمانند.
    if (target.role === "superadmin") {
      return res.status(403).json({ message: "امکان تغییر نقش حساب مدیر کل (Super Admin) وجود ندارد" });
    }
    // نقش «داکتر» فقط زمانی از این مسیر قابل‌قبول است که حساب از قبل داکتر باشد
    // (یعنی همان نقش فعلی دوباره ثبت شود)؛ تبدیل یک حساب بیمار/ادمین به داکتر از
    // این‌جا مسدود است چون به پروفایل داکتر متصل نمی‌شود — باید از بخش «حساب‌های
    // داکتر» (createDoctorAccount) انجام شود.
    if (role === "doctor" && target.role !== "doctor") {
      return res.status(400).json({
        message: "برای تخصیص نقش داکتر باید از بخش «حساب‌های داکتر» یک حساب داکتر بسازید",
      });
    }
    const updated = await updateUserRole(req.params.id, role);
    await logSuper(req, "تغییر نقش کاربر", `userId=${req.params.id} (${target.email}) -> ${role}`);
    await auditSuper(req, "users", req.params.id, "UPDATE", target, updated);
    return res.status(200).json({ message: "نقش کاربر به‌روزرسانی شد", user: updated });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- تنظیمات سیستم ----------
export async function getSettings(req, res) {
  try {
    const settings = await getEditableSettings();
    return res.status(200).json({ settings });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function updateSettings(req, res) {
  try {
    const { sanitized, errors } = validateSettingsInput(req.body || {});

    if (Object.keys(sanitized).length === 0 && Object.keys(errors).length === 0) {
      return res.status(400).json({ message: "هیچ تنظیماتی ارسال نشده است" });
    }
    if (Object.keys(errors).length > 0) {
      const [firstKey, firstError] = Object.entries(errors)[0];
      return res.status(400).json({ message: `برخی مقادیر ارسالی معتبر نیستند (${firstKey}: ${firstError})`, errors });
    }

    const previousSettings = await getEditableSettings();
    for (const [key, value] of Object.entries(sanitized)) {
      await setSetting(key, value);
    }
    await logSuper(req, "تغییر تنظیمات سیستم", JSON.stringify(sanitized));
    const settings = await getEditableSettings();

    // اگر تنظیمات پشتیبان‌گیری خودکار واقعاً تغییر کرده، زمان‌بند بدون ری‌استارت سرور دوباره ساخته می‌شود
    const backupKeys = ["backupAutoEnabled", "backupAutoFrequency", "backupAutoTime"];
    if (backupKeys.some((k) => k in sanitized && sanitized[k] !== previousSettings[k])) {
      await applyBackupSchedule().catch((e) => console.error("خطا در به‌روزرسانی زمان‌بندی پشتیبان‌گیری:", e.message));
    }
    await auditSuper(req, "settings", Object.keys(sanitized).join(","), "UPDATE", previousSettings, settings);
    return res.status(200).json({ message: "تنظیمات سیستم به‌روزرسانی شد", settings });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- مدیریت لوگوی شفاخانه (بخشی از تنظیمات سیستم) ----------
// برخلاف بقیه‌ی تنظیمات (که متن آزاد هستند)، لوگو فقط از طریق آپلود فایل تغییر می‌کند
// تا امکان تزریق لینک/آدرس دلخواه در updateSettings عمومی وجود نداشته باشد.
export async function uploadLogo(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    }

    const previous = await getAllSettings();
    const relativeUrl = `/uploads/logo/${req.file.filename}`;
    await setSetting("logoUrl", relativeUrl);

    // لوگوی قبلی (اگر از همین مسیر آپلود شده بود) از دیسک پاک می‌شود تا فایل یتیم باقی نماند
    if (previous.logoUrl && previous.logoUrl.startsWith("/uploads/logo/")) {
      removeUploadedFile(path.join(LOGO_DIR, path.basename(previous.logoUrl)));
    }

    await logSuper(req, "به‌روزرسانی لوگوی شفاخانه", relativeUrl);
    await auditSuper(req, "settings", "logoUrl", "UPDATE", { logoUrl: previous.logoUrl || null }, { logoUrl: relativeUrl });
    return res.status(200).json({ message: "لوگو با موفقیت به‌روزرسانی شد", logoUrl: relativeUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function removeLogo(req, res) {
  try {
    const previous = await getAllSettings();
    if (!previous.logoUrl) {
      return res.status(404).json({ message: "لوگویی برای حذف وجود ندارد" });
    }

    if (previous.logoUrl.startsWith("/uploads/logo/")) {
      removeUploadedFile(path.join(LOGO_DIR, path.basename(previous.logoUrl)));
    }
    await setSetting("logoUrl", "");

    await logSuper(req, "حذف لوگوی شفاخانه", previous.logoUrl);
    await auditSuper(req, "settings", "logoUrl", "UPDATE", { logoUrl: previous.logoUrl }, { logoUrl: null });
    return res.status(200).json({ message: "لوگو حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- لاگ فعالیت‌ها ----------

// جست‌وجو و فیلتر لاگ‌ها: role, userId, search (در action/details/userName/ipAddress)،
// بازه تاریخ (dateFrom, dateTo) و صفحه‌بندی (page, limit)
export async function activityLogs(req, res) {
  try {
    const { role, userId, search, dateFrom, dateTo, page = 1, limit = 50 } = req.query;
    const safeLimit = Math.min(Number(limit) || 50, 200);
    const safePage = Math.max(Number(page) || 1, 1);

    const { logs, total } = await getFilteredLogs({
      role: role || undefined,
      userId: userId || undefined,
      search: search || undefined,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      limit: safeLimit,
      offset: (safePage - 1) * safeLimit,
    });

    return res.status(200).json({
      logs,
      pagination: { total, page: safePage, limit: safeLimit, totalPages: Math.ceil(total / safeLimit) || 1 },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// خروجی CSV از لاگ فعالیت‌ها با اعمال همان فیلترهای جست‌وجو (حداکثر ۵۰۰۰ رکورد آخر)
export async function exportActivityLogs(req, res) {
  try {
    const { role, userId, search, dateFrom, dateTo } = req.query;
    const logs = await getLogsForExport({
      role: role || undefined,
      userId: userId || undefined,
      search: search || undefined,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
    });

    const header = ["شناسه", "شناسه کاربر", "نام کاربر", "نقش", "فعالیت", "جزئیات", "آدرس IP", "مرورگر", "زمان"];
    const escapeCsv = escapeCsvCell; // ضد تزریق فرمول (utils/csv.js)
    const rows = logs.map((l) =>
      [l.id, l.userId, l.userName, l.role, l.action, l.details, l.ipAddress, l.userAgent, l.createdAt]
        .map(escapeCsv)
        .join(",")
    );
    const csv = `\uFEFF${[header.map(escapeCsv).join(","), ...rows].join("\r\n")}`;

    await logActivity({
      req,
      userId: req.user.id,
      userName: req.user.email,
      role: req.user.role,
      action: "خروجی گرفتن از لاگ فعالیت‌ها",
      details: `تعداد رکورد: ${logs.length}`,
    });

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="activity-logs-${Date.now()}.csv"`);
    return res.status(200).send(csv);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- سیستم حسابرسی (Audit Trail) — فقط Super Admin، فقط خواندنی ----------
// برای رکوردهای پرونده صحی (نسخه/ویزیت)، شناسه‌ی بیمار همیشه داخل oldValues/newValues
// ذخیره شده (چون همان ستون patientId جدول اصلی است)؛ این تابع فقط نام بیمار را برای
// نمایش راحت‌تر در پنل Super Admin به هر رکورد اضافه می‌کند، بدون تغییر ساختار جدول
// عمومی audit_logs (که برای همه‌ی جدول‌های دیگر هم استفاده می‌شود).
const PATIENT_LINKED_TABLES = new Set(["prescriptions", "medical_records"]);

function parseAuditJson(raw) {
  if (!raw) return null;
  if (typeof raw === "object") return raw;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function attachPatientNames(logs) {
  const patientIds = new Set();
  for (const log of logs) {
    if (!PATIENT_LINKED_TABLES.has(log.tableName)) continue;
    const values = parseAuditJson(log.newValues) || parseAuditJson(log.oldValues);
    if (values?.patientId) patientIds.add(Number(values.patientId));
  }

  if (patientIds.size === 0) return logs;

  const entries = await Promise.all(
    [...patientIds].map(async (id) => [id, await getPatientById(id).catch(() => null)])
  );
  const patientById = new Map(entries);

  return logs.map((log) => {
    if (!PATIENT_LINKED_TABLES.has(log.tableName)) return log;
    const values = parseAuditJson(log.newValues) || parseAuditJson(log.oldValues);
    const patient = values?.patientId ? patientById.get(Number(values.patientId)) : null;
    return { ...log, patientId: values?.patientId || null, patientName: patient?.fullName || null };
  });
}

// جست‌وجو و فیلتر لاگ‌های حسابرسی: tableName, action, userId, recordId, search
// (در userName/tableName/oldValues/newValues/ipAddress)، بازه تاریخ و صفحه‌بندی
export async function auditLogs(req, res) {
  try {
    const { tableName, action, userId, role, recordId, search, dateFrom, dateTo, page = 1, limit = 50 } = req.query;
    const safeLimit = Math.min(Number(limit) || 50, 200);
    const safePage = Math.max(Number(page) || 1, 1);

    const { logs, total } = await getFilteredAuditLogs({
      tableName: tableName || undefined,
      action: action || undefined,
      userId: userId || undefined,
      role: role || undefined,
      recordId: recordId || undefined,
      search: search || undefined,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      limit: safeLimit,
      offset: (safePage - 1) * safeLimit,
    });

    const enrichedLogs = await attachPatientNames(logs);
    const tables = await getAuditedTableNames();

    return res.status(200).json({
      logs: enrichedLogs,
      tables,
      pagination: { total, page: safePage, limit: safeLimit, totalPages: Math.ceil(total / safeLimit) || 1 },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// جزئیات کامل یک رکورد حسابرسی (برای نمایش کامل oldValues/newValues)
export async function auditLogDetail(req, res) {
  try {
    const log = await getAuditLogById(req.params.id);
    if (!log) return res.status(404).json({ message: "رکورد حسابرسی یافت نشد" });
    const [enriched] = await attachPatientNames([log]);
    return res.status(200).json({ log: enriched });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// خروجی CSV از لاگ‌های حسابرسی با اعمال همان فیلترهای جست‌وجو (حداکثر ۵۰۰۰ رکورد آخر)
export async function exportAuditLogs(req, res) {
  try {
    const { tableName, action, userId, role, recordId, search, dateFrom, dateTo } = req.query;
    const logs = await getAuditLogsForExport({
      tableName: tableName || undefined,
      action: action || undefined,
      userId: userId || undefined,
      role: role || undefined,
      recordId: recordId || undefined,
      search: search || undefined,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
    });

    const enrichedLogs = await attachPatientNames(logs);

    const header = ["شناسه", "جدول", "شناسه رکورد", "عملیات", "بیمار", "مقدار قبلی", "مقدار جدید", "فیلدهای تغییریافته", "شناسه کاربر", "نام کاربر", "نقش", "آدرس IP", "زمان"];
    const escapeCsv = escapeCsvCell; // ضد تزریق فرمول (utils/csv.js)
    const rows = enrichedLogs.map((l) =>
      [l.id, l.tableName, l.recordId, l.action, l.patientName || "", l.oldValues, l.newValues, l.changedFields, l.userId, l.userName, l.userRole, l.ipAddress, l.createdAt]
        .map(escapeCsv)
        .join(",")
    );
    const csv = `\uFEFF${[header.map(escapeCsv).join(","), ...rows].join("\r\n")}`;

    await logActivity({
      req,
      userId: req.user.id,
      userName: req.user.email,
      role: req.user.role,
      action: "خروجی گرفتن از لاگ حسابرسی",
      details: `تعداد رکورد: ${logs.length}`,
    });

    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="audit-logs-${Date.now()}.csv"`);
    return res.status(200).send(csv);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- ماتریس دسترسی/مجوزها (Permissions) ----------
export async function permissionsMatrix(req, res) {
  // این ماتریس ثابت و مرجع است تا فرانت‌اند بتواند دسترسی هر نقش را نمایش دهد
  const matrix = {
    user: [
      "مشاهده پروفایل شخصی", "ویرایش اطلاعات شخصی", "گرفتن وقت", "مشاهده تاریخچه نوبت‌ها",
      "مشاهده نسخه و سوابق طبی", "تغییر رمز عبور",
    ],
    admin: [
      "مدیریت بیماران", "مدیریت داکتران", "مدیریت نوبت‌ها", "مدیریت بخش‌ها",
      "مدیریت برنامه‌های کاری", "مشاهده گزارش‌ها و آمار",
    ],
    superadmin: [
      "دسترسی کامل به تمام بخش‌ها", "ساخت/ویرایش/حذف حساب ادمین", "تغییر نقش کاربران",
      "مدیریت تنظیمات سیستم", "مشاهده لاگ فعالیت‌ها", "مدیریت مجوزها", "مدیریت کامل دیتابیس",
    ],
  };
  return res.status(200).json({ matrix });
}

// ---------- مدیریت کامل دیتابیس (نمای کلی) ----------
export async function databaseOverview(req, res) {
  try {
    const [users, patients, doctors, appointments] = await Promise.all([
      countUsersByRole(),
      countPatients(),
      countDoctors(),
      countAppointments(),
    ]);
    return res.status(200).json({
      tables: {
        users: users,
        patients: patients,
        doctors: doctors,
        appointments: appointments,
      },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- پشتیبان‌گیری و بازیابی دیتابیس (Database Backup & Restore) ----------
// همه‌ی این مسیرها قبلاً در routes/superadmin.js با authorize("superadmin") محدود شده‌اند؛
// یعنی فقط مدیر کل سیستم به تهیه/دانلود/بازیابی/حذف فایل‌های پشتیبان دسترسی دارد.

// خطاهای شناخته‌شده‌ی پوشه‌ها (utils/backup.js) → کد وضعیت HTTP؛ پیام‌ها از قبل فارسی و بدون جزئیات فنی‌اند
const FOLDER_ERROR_STATUS = {
  INVALID_FOLDER: 404,
  FOLDER_NOT_FOUND: 404,
  FOLDER_UNAVAILABLE: 409,
  FOLDER_NAME_INVALID: 400,
  FOLDER_NAME_EXISTS: 409,
  FOLDER_NOT_EMPTY: 409,
  FOLDER_PROTECTED: 409,
  FOLDER_LIMIT: 400,
  FOLDER_PATH_INVALID: 400,
  PICKER_NOT_LOCAL: 400,
  PICKER_BUSY: 409,
  PICKER_UNAVAILABLE: 501,
};
function sendFolderError(res, err, forcedStatus) {
  const status = FOLDER_ERROR_STATUS[err && err.code];
  if (!status) return false;
  res.status(forcedStatus || status).json({ message: err.message, code: err.code });
  return true;
}

// پوشه‌ی انتخاب‌شده از کوئری/بدنه — اختیاری؛ اگر داده شود باید شناسه‌ی معتبر باشد
function readFolderParam(value) {
  if (value === undefined || value === null || value === "") return { folderId: undefined };
  if (typeof value !== "string" || !isValidFolderId(value)) return { error: true };
  return { folderId: value };
}

// فهرست پوشه‌ها + فایل‌های پشتیبانِ پوشه‌ی انتخاب‌شده (?folder=...؛ پیش‌فرض: پوشه‌ی فعال)
export async function listBackupsHandler(req, res) {
  try {
    const requested = readFolderParam(req.query.folder);
    if (requested.error) return res.status(404).json({ message: "پوشه یافت نشد" });

    const overview = await getFoldersOverview();
    let selectedFolderId = requested.folderId;
    if (selectedFolderId && !overview.folders.some((f) => f.id === selectedFolderId)) {
      return res.status(404).json({ message: "پوشه یافت نشد" });
    }
    if (!selectedFolderId) {
      selectedFolderId = overview.folders.some((f) => f.id === overview.activeFolderId) ? overview.activeFolderId : DEFAULT_FOLDER_ID;
    }

    const backups = await listBackups({ folderId: selectedFolderId, withStatus: true });
    const schedule = await getBackupScheduleStatus();
    return res.status(200).json({ backups, schedule, selectedFolderId, ...overview });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطا در دریافت فهرست فایل‌های پشتیبان" });
  }
}

// تهیه‌ی پشتیبان دستی (Manual Backup) — همین لحظه از کل دیتابیس در «پوشه‌ی فعال» نسخه پشتیبان می‌گیرد
export async function createBackupHandler(req, res) {
  try {
    const backup = await createBackup({ triggeredBy: "manual" });
    await logSuper(req, "تهیه پشتیبان دستی از دیتابیس", `${backup.filename} (${backup.tableCount} جدول، پوشه: ${backup.folderId})`);
    return res.status(201).json({ message: "پشتیبان‌گیری با موفقیت انجام شد", backup });
  } catch (err) {
    // پوشه‌ی مقصد وجود ندارد/قابل نوشتن نیست → ۴۰۹ با پیام واضح (هیچ فایلی ساخته یا حذف نشده است)
    if (sendFolderError(res, err, 409)) return undefined;
    console.error(err);
    return res.status(500).json({ message: "خطا در تهیه پشتیبان از دیتابیس" });
  }
}

// ---------- مدیریت پوشه‌های پشتیبان (فقط Super Admin) ----------
function readFolderBody(body) {
  const b = body && typeof body === "object" ? body : {};
  return { name: b.name, description: b.description };
}

export async function createBackupFolderHandler(req, res) {
  try {
    const folder = await createFolder(readFolderBody(req.body));
    await logSuper(req, "ایجاد پوشه‌ی پشتیبان", `${folder.name} (${folder.id})`);
    return res.status(201).json({ message: "پوشه با موفقیت ایجاد شد", folder });
  } catch (err) {
    if (sendFolderError(res, err)) return undefined;
    console.error(err);
    return res.status(500).json({ message: "خطا در ایجاد پوشه" });
  }
}

export async function updateBackupFolderHandler(req, res) {
  try {
    const { name, description } = readFolderBody(req.body);
    if (name === undefined && description === undefined) {
      return res.status(400).json({ message: "هیچ تغییری ارسال نشده است" });
    }
    const folder = await updateFolder(req.params.folderId, { name, description });
    await logSuper(req, "ویرایش پوشه‌ی پشتیبان", `${folder.name} (${folder.id})`);
    return res.status(200).json({ message: "پوشه به‌روزرسانی شد", folder });
  } catch (err) {
    if (sendFolderError(res, err)) return undefined;
    console.error(err);
    return res.status(500).json({ message: "خطا در ویرایش پوشه" });
  }
}

export async function activateBackupFolderHandler(req, res) {
  try {
    const folder = await setActiveFolder(req.params.folderId);
    await logSuper(req, "تغییر پوشه‌ی فعال پشتیبان‌گیری", `${folder.name} (${folder.id})`);
    return res.status(200).json({ message: "پوشه‌ی فعال بکاپ تغییر کرد", folder });
  } catch (err) {
    if (sendFolderError(res, err)) return undefined;
    console.error(err);
    return res.status(500).json({ message: "خطا در تغییر پوشه‌ی فعال" });
  }
}

// انتخاب پوشه‌ی ذخیره‌ی بکاپ از روی خودِ کامپیوتر: پنجره‌ی انتخاب پوشه‌ی سیستم‌عامل (با درایوها و
// دکمه‌ی «Make New Folder») باز می‌شود و مسیر انتخاب‌شده به‌عنوان «پوشه‌ی فعال» بکاپ ذخیره می‌شود.
// پنجره روی کامپیوتری باز می‌شود که سرور روی آن اجرا می‌شود؛ پس فقط وقتی مجاز است که درخواست از
// خودِ همان کامپیوتر (loopback) آمده باشد، وگرنه پنجره روی سرور باز می‌شد نه جلوی کاربر.
let folderPickerOpen = false;
function isLoopbackRequest(req) {
  const ip = (req.socket && req.socket.remoteAddress) || "";
  return ip === "127.0.0.1" || ip === "::1" || ip === "::ffff:127.0.0.1";
}

export async function pickBackupFolderHandler(req, res) {
  if (!isLoopbackRequest(req)) {
    return res.status(400).json({
      code: "PICKER_NOT_LOCAL",
      message: "پنجره‌ی انتخاب پوشه فقط وقتی کار می‌کند که داشبورد روی همان کامپیوتری باز باشد که سرور روی آن اجرا می‌شود.",
    });
  }
  if (folderPickerOpen) {
    return res.status(409).json({ code: "PICKER_BUSY", message: "پنجره‌ی انتخاب پوشه از قبل باز است؛ ابتدا آن را ببندید." });
  }
  folderPickerOpen = true;
  try {
    const picked = await pickFolderDialog();
    if (!picked) return res.status(200).json({ cancelled: true, message: "انتخاب پوشه لغو شد" });
    const folder = await setCustomBackupDir(picked);
    await logSuper(req, "انتخاب پوشه‌ی ذخیره‌ی بکاپ روی کامپیوتر", folder.path);
    return res.status(200).json({ message: "پوشه‌ی ذخیره‌ی بکاپ انتخاب شد", folder });
  } catch (err) {
    if (sendFolderError(res, err)) return undefined;
    console.error(err);
    return res.status(500).json({ message: "خطا در انتخاب پوشه‌ی بکاپ" });
  } finally {
    folderPickerOpen = false;
  }
}

export async function deleteBackupFolderHandler(req, res) {
  try {
    await deleteFolder(req.params.folderId);
    await logSuper(req, "حذف پوشه‌ی پشتیبان", req.params.folderId);
    return res.status(200).json({ message: "پوشه حذف شد" });
  } catch (err) {
    if (sendFolderError(res, err)) return undefined;
    console.error(err);
    return res.status(500).json({ message: "خطا در حذف پوشه" });
  }
}

// دانلود امن فایل پشتیبان (فقط فایل‌های داخل پوشه‌های خصوصی پشتیبان و با نام معتبر)
export async function downloadBackupHandler(req, res) {
  try {
    const requested = readFolderParam(req.query.folder);
    if (requested.error) return res.status(404).json({ message: "فایل پشتیبان یافت نشد" });
    const filePath = getBackupFilePath(req.params.filename, requested.folderId);
    await logSuper(req, "دانلود فایل پشتیبان دیتابیس", req.params.filename);
    return res.download(filePath, req.params.filename);
  } catch (err) {
    if (err.code === "INVALID_FILENAME" || err.code === "ENOENT" || err.code === "INVALID_FOLDER") {
      return res.status(404).json({ message: "فایل پشتیبان یافت نشد" });
    }
    console.error(err);
    return res.status(500).json({ message: "خطا در دانلود فایل پشتیبان" });
  }
}

// بازیابی دیتابیس از یک فایل پشتیبان — عملیاتی مخرب و برگشت‌ناپذیر روی داده‌ی فعلی است.
// لایه‌های امنیتی/اعتبارسنجی این عملیات:
//   ۱) فقط Super Admin (router.use بالا در routes/superadmin.js)
//   ۲) نام فایل باید صراحتاً در بدنه‌ی درخواست (confirm) تکرار شود — تاییدیه‌ی قوی سمت سرور،
//      مستقل از هر تاییدیه‌ای که فرانت‌اند نمایش می‌دهد
//   ۳) اعتبارسنجی محتوای فایل پشتیبان (validateBackupFile در utils/backup.js) — نام/مسیر
//      امن + محتوای واقعاً معتبر، کامل و متعلق به همین سیستم/دیتابیس
//   ۴) پیش از اجرای بازیابی، یک پشتیبان ایمنی خودکار از وضعیت فعلی (در پوشه‌ی فعال) گرفته می‌شود
//   ۵) هر تلاش بازیابی (موفق یا ناموفق) در لاگ فعالیت‌ها ثبت می‌شود؛ بازیابیِ موفق علاوه‌براین
//      یک رکورد در لاگ حسابرسی (audit_logs) هم ثبت می‌کند تا در تب «لاگ حسابرسی» قابل مشاهده باشد
export async function restoreBackupHandler(req, res) {
  const { filename } = req.params;
  const { confirm, folder } = req.body || {};

  if (confirm !== filename) {
    return res.status(400).json({ message: "برای بازیابی، نام دقیق فایل پشتیبان باید جهت تایید وارد شود" });
  }
  const requested = readFolderParam(folder);
  if (requested.error) return res.status(404).json({ message: "فایل پشتیبان یافت نشد" });

  try {
    await restoreBackup(filename, requested.folderId);
    // جدول settings هم با فایل پشتیبان جایگزین می‌شود؛ زمان‌بندی خودکار باید با تنظیمات بازیابی‌شده هماهنگ شود
    await applyBackupSchedule().catch((e) => console.error("خطا در به‌روزرسانی زمان‌بندی پشتیبان‌گیری:", e.message));

    const restoredAt = new Date().toISOString();
    await logSuper(req, "بازیابی دیتابیس از فایل پشتیبان", filename);
    // ثبت در لاگ حسابرسی (Audit Log) — چون این عملیات کل محتوای دیتابیس را جایگزین می‌کند،
    // به‌عنوان یک رویداد UPDATE سطح دیتابیس ثبت می‌شود (نزدیک‌ترین مقدار معتبر از ENUM موجود
    // جدول audit_logs که عمداً برای جلوگیری از تغییر ساختار دیتابیس تغییر داده نشده است)
    await auditSuper(req, "database", filename, "UPDATE", null, { restoredFrom: filename, restoredAt });

    return res.status(200).json({ message: "دیتابیس با موفقیت از روی فایل پشتیبان بازیابی شد", restoredAt });
  } catch (err) {
    if (err.code === "INVALID_FILENAME" || err.code === "ENOENT" || err.code === "INVALID_FOLDER") {
      await logSuper(req, "تلاش ناموفق بازیابی دیتابیس (فایل نامعتبر/یافت‌نشد)", filename);
      return res.status(404).json({ message: "فایل پشتیبان یافت نشد" });
    }
    if (err.code === "INVALID_BACKUP_CONTENT" || err.code === "BACKUP_KEY_MISSING") {
      await logSuper(req, "تلاش ناموفق بازیابی دیتابیس (محتوای پشتیبان نامعتبر)", `${filename}: ${err.message}`);
      return res.status(400).json({ message: err.message });
    }
    if (FOLDER_ERROR_STATUS[err.code]) {
      // پشتیبان ایمنیِ پیش از بازیابی در پوشه‌ی فعال نوشته نشد؛ بازیابی اجرا نشده و دیتابیس دست‌نخورده است
      await logSuper(req, "تلاش ناموفق بازیابی دیتابیس (پوشه‌ی فعال بکاپ در دسترس نیست)", filename);
      return res.status(409).json({ message: `بازیابی انجام نشد، چون پشتیبان ایمنیِ پیش از بازیابی ذخیره نشد. ${err.message}` });
    }
    console.error(err);
    await logSuper(req, "تلاش ناموفق بازیابی دیتابیس (خطای سرور)", filename);
    return res.status(500).json({ message: "خطا در بازیابی دیتابیس از فایل پشتیبان" });
  }
}

// حذف یک فایل پشتیبان از دیسک
export async function deleteBackupHandler(req, res) {
  try {
    const requested = readFolderParam(req.query.folder);
    if (requested.error) return res.status(404).json({ message: "فایل پشتیبان یافت نشد" });
    await deleteBackup(req.params.filename, requested.folderId);
    await logSuper(req, "حذف فایل پشتیبان دیتابیس", req.params.filename);
    return res.status(200).json({ message: "فایل پشتیبان حذف شد" });
  } catch (err) {
    if (err.code === "INVALID_FILENAME" || err.code === "ENOENT" || err.code === "INVALID_FOLDER") {
      return res.status(404).json({ message: "فایل پشتیبان یافت نشد" });
    }
    console.error(err);
    return res.status(500).json({ message: "خطا در حذف فایل پشتیبان" });
  }
}

// ---------- نشست‌ها و دستگاه‌های فعال (Sessions & Devices) ----------
// فقط Super Admin به این دو مسیر دسترسی دارد (router.use(requireAuth, authorize("superadmin"))
// در routes/superadmin.js). هیچ‌کدام از فیلدهای رمز عبور یا خودِ توکن JWT در پاسخ نیستند —
// فقط اطلاعات لازم برای شناسایی نشست (کاربر/نقش/زمان ورود/آخرین فعالیت/IP/دستگاه).
export async function listSessions(req, res) {
  try {
    const sessions = await getActiveSessions();
    // نشست خودِ Super Adminِ درخواست‌دهنده را برچسب می‌زند (تا فرانت‌اند بتواند دکمه‌ی
    // «خاتمه‌دادن» را برای نشست جاری خودش غیرفعال کند) — سپس tokenId از پاسخ حذف می‌شود
    // چون هیچ شناسه‌ی توکن نباید به فرانت‌اند برسد.
    const currentTokenId = req.user.jti || null;
    const safeSessions = sessions.map(({ tokenId, ...rest }) => ({
      ...rest,
      isCurrent: Boolean(currentTokenId) && tokenId === currentTokenId,
    }));
    return res.status(200).json({ sessions: safeSessions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// یک نشست مشخص را خاتمه می‌دهد — کاربر صاحب آن نشست با همان توکن دیگر نمی‌تواند
// درخواستی بفرستد (بررسی در requireAuth) و باید دوباره وارد شود.
export async function terminateSession(req, res) {
  try {
    const session = await findSessionById(req.params.id);
    if (!session) return res.status(404).json({ message: "نشست یافت نشد" });
    if (session.revokedAt) return res.status(400).json({ message: "این نشست از قبل خاتمه یافته است" });
    // Super Admin نباید بتواند نشست جاری خودش را از این مسیر خاتمه دهد — باید از دکمه‌ی
    // خروج در منوی کاربری استفاده کند (فرانت‌اند هم همین دکمه را غیرفعال می‌کند).
    if (req.user.jti && session.tokenId === req.user.jti) {
      return res.status(400).json({ message: "نمی‌توانید نشست جاری خودتان را از این طریق خاتمه دهید" });
    }

    await revokeSessionById(session.id, req.user.id);
    await logSuper(req, "خاتمه‌دادن نشست کاربر", `کاربر: ${session.userName || session.userId} (${session.role || "-"})`);

    return res.status(200).json({ message: "نشست با موفقیت خاتمه یافت" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// فهرست نشست‌های «غیرفعال» (خاتمه‌یافته/منقضی‌شده) — بخش «نشست‌ها و دستگاه‌های غیرفعال».
// tokenId و سایر داده‌های حساس پیش از پاسخ حذف می‌شوند.
export async function listInactiveSessions(req, res) {
  try {
    const sessions = await getInactiveSessions();
    const safeSessions = sessions.map(({ tokenId, revokedByUserId, ...rest }) => {
      const endedAt = rest.revokedAt || rest.expiresAt || null;
      const status = !rest.revokedAt
        ? "expired"
        : revokedByUserId && revokedByUserId !== rest.userId
        ? "ended_by_admin"
        : "logged_out";
      const loginTime = new Date(rest.loginAt).getTime();
      const endTime = endedAt ? new Date(endedAt).getTime() : null;
      const durationMs = endTime && !Number.isNaN(loginTime) ? Math.max(0, endTime - loginTime) : null;
      return { ...rest, endedAt, status, durationMs };
    });
    return res.status(200).json({ sessions: safeSessions });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- سلامت سیستم (System Health) ----------
// فقط Super Admin به این مسیر دسترسی دارد (router.use(requireAuth, authorize("superadmin"))
// در routes/superadmin.js). همه‌ی مقادیر این بخش زنده و واقعی هستند — هیچ عدد ثابت یا
// شبیه‌سازی‌شده‌ای در آن نیست:
//  - دیتابیس: یک کوئری واقعی SELECT 1 روی همان pool اتصال دیتابیس (db.js) اجرا و زمان پاسخ سنجیده می‌شود.
//  - سرور: از process/os خودِ Node.js در حال اجرا خوانده می‌شود (uptime، حافظه، بار سیستم).
//  - ذخیره‌سازی: دسترسی خواندن/نوشتن واقعی به پوشه‌های uploads و پشتیبان‌ها + فضای واقعی دیسک (fs.statfs).
//  - پشتیبان‌گیری: از همان فهرست واقعی فایل‌های پشتیبان روی دیسک (utils/backup.js) خوانده می‌شود.
export async function systemHealth(req, res) {
  // ۱) اتصال به دیتابیس MySQL — کوئری سبک SELECT 1 برای سنجش واقعیِ در دسترس بودن و تأخیر پاسخ
  const database = await (async () => {
    const start = process.hrtime.bigint();
    try {
      const pool = await getPool();
      await pool.query("SELECT 1");
      const latencyMs = Math.round(Number(process.hrtime.bigint() - start) / 1e6);
      return {
        status: latencyMs > 500 ? "warning" : "healthy",
        latencyMs,
        message:
          latencyMs > 500
            ? "اتصال به دیتابیس برقرار است اما زمان پاسخ‌دهی کندتر از حد معمول است"
            : "اتصال به دیتابیس MySQL برقرار و پایدار است",
      };
    } catch (err) {
      return { status: "error", latencyMs: null, message: "اتصال به دیتابیس MySQL برقرار نشد" };
    }
  })();

  // ۲) وضعیت پردازه‌ی سرور Node.js — زمان فعالیت، مصرف حافظه و بار سیستم (مقادیر واقعی process/os)
  const server = (() => {
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    const usedMemPercent = totalMem > 0 ? Math.round(((totalMem - freeMem) / totalMem) * 100) : null;
    const loadAvg1m = os.loadavg()[0]; // میانگین بار ۱ دقیقه‌ی اخیر؛ در ویندوز همیشه ۰ برمی‌گردد
    return {
      status: usedMemPercent === null ? "warning" : usedMemPercent >= 92 ? "error" : usedMemPercent >= 80 ? "warning" : "healthy",
      uptimeSeconds: Math.round(process.uptime()),
      nodeVersion: process.version,
      platform: process.platform,
      memoryUsedPercent: usedMemPercent,
      memoryTotalMB: Math.round(totalMem / (1024 * 1024)),
      memoryFreeMB: Math.round(freeMem / (1024 * 1024)),
      processMemoryMB: Math.round(process.memoryUsage().rss / (1024 * 1024)),
      loadAvg1m: Number(loadAvg1m.toFixed(2)),
    };
  })();

  // ۳) فضای ذخیره‌سازی — دسترسی واقعیِ خواندن/نوشتن به پوشه‌های uploads و پشتیبان‌ها، به‌علاوه‌ی
  // فضای واقعی دیسک زیرینِ پوشه‌ی بک‌اند (fs.statfs)
  const storage = await (async () => {
    try {
      await fsp.access(UPLOADS_DIR, fs.constants.R_OK | fs.constants.W_OK);
      await fsp.access(BACKUPS_DIR, fs.constants.R_OK | fs.constants.W_OK);

      let usedPercent = null;
      let totalGB = null;
      let freeGB = null;
      try {
        const stat = await fsp.statfs(BACKEND_ROOT);
        const totalBytes = stat.blocks * stat.bsize;
        const freeBytes = stat.bavail * stat.bsize;
        if (totalBytes > 0) {
          usedPercent = Math.round(((totalBytes - freeBytes) / totalBytes) * 100);
          totalGB = Number((totalBytes / 1024 ** 3).toFixed(1));
          freeGB = Number((freeBytes / 1024 ** 3).toFixed(1));
        }
      } catch {
        // fs.statfs ممکن است روی برخی محیط‌ها/سیستم‌عامل‌ها در دسترس نباشد؛ در این صورت
        // فقط بررسی دسترسی خواندن/نوشتن پوشه‌ها (بالا) ملاک سلامت ذخیره‌سازی قرار می‌گیرد
      }

      return {
        status: usedPercent !== null && usedPercent >= 95 ? "error" : usedPercent !== null && usedPercent >= 85 ? "warning" : "healthy",
        usedPercent,
        totalGB,
        freeGB,
        message: "پوشه‌های آپلود و پشتیبان‌گیری روی دیسک قابل خواندن و نوشتن‌اند",
      };
    } catch (err) {
      return {
        status: "error",
        usedPercent: null,
        totalGB: null,
        freeGB: null,
        message: "دسترسی به پوشه‌های ذخیره‌سازی سرور (uploads/private-uploads) ممکن نشد",
      };
    }
  })();

  // ۴) آخرین پشتیبان دیتابیس — از همان فهرست واقعی فایل‌های پشتیبان روی دیسک خوانده می‌شود
  const backup = await (async () => {
    try {
      const backups = await listBackups();
      if (backups.length === 0) {
        return {
          status: "warning",
          lastBackupAt: null,
          lastBackupFilename: null,
          lastBackupType: null,
          ageHours: null,
          message: "هنوز هیچ فایل پشتیبانی از دیتابیس تهیه نشده است",
        };
      }
      const last = backups[0]; // listBackups() از قبل بر اساس جدیدترین مرتب شده است
      const ageHours = (Date.now() - new Date(last.createdAt).getTime()) / 36e5;
      return {
        status: ageHours > 72 ? "error" : ageHours > 30 ? "warning" : "healthy",
        lastBackupAt: last.createdAt,
        lastBackupFilename: last.filename,
        lastBackupType: last.type,
        ageHours: Number(ageHours.toFixed(1)),
        message:
          ageHours > 72
            ? "آخرین پشتیبان بیش از ۷۲ ساعت پیش تهیه شده — پشتیبان‌گیری خودکار را بررسی کنید"
            : ageHours > 30
            ? "آخرین پشتیبان بیش از ۳۰ ساعت پیش تهیه شده است"
            : "آخرین پشتیبان‌گیری در بازه‌ی زمانی مطلوب انجام شده است",
      };
    } catch (err) {
      return {
        status: "error",
        lastBackupAt: null,
        lastBackupFilename: null,
        lastBackupType: null,
        ageHours: null,
        message: "خطا در خواندن فهرست فایل‌های پشتیبان دیتابیس",
      };
    }
  })();

  // ۵) وضعیت API — اگر اجرای کد به این‌جا رسیده، یعنی سرور Express در حال پاسخ‌گویی است
  const api = {
    status: "healthy",
    uptimeSeconds: Math.round(process.uptime()),
    message: "سرور بک‌اند (Express API) در حال پاسخ‌گویی است",
  };

  const statuses = [api.status, database.status, server.status, storage.status, backup.status];
  const overall = statuses.includes("error") ? "error" : statuses.includes("warning") ? "warning" : "healthy";

  return res.status(200).json({
    overall,
    checkedAt: new Date().toISOString(),
    api,
    database,
    server,
    storage,
    backup,
  });
}

import fs from "fs";
import path from "path";
import { getPatientById } from "../models/Patient.js";
import { getDoctorById } from "../models/Doctor.js";
import { getAppointmentById } from "../models/Appointment.js";
import {
  getRecordById, markRecordSent, sanitizeRecordForPatient,
} from "../models/MedicalRecord.js";
import { getLabResultsByRecordId } from "../models/LabResult.js";
import {
  createFile, getFileById, getFilesByRecordId, countFilesByRecordId, deleteFile,
  getReleasedFileForPatientUser, getReleasedFilesByRecordId,
} from "../models/MedicalRecordFile.js";
import { createNotification } from "../models/Notification.js";
import { MEDICAL_FILES_DIR } from "../middleware/upload.js";
import db from "../db.js";
import {
  resolveActingDoctor, canManage, ensureDoctorOwnsPatient, logEmr, auditEmr, parseJsonField,
} from "./medicalRecordController.js";

const IMAGE_CATEGORIES = ["xray", "ct", "mri", "wound", "ultrasound", "other"];
const DOCUMENT_CATEGORIES = ["medical_report", "radiology_report", "other"];
const MAX_FILES_PER_RECORD = 40;
const SERVER_ERROR = { message: "خطای سرور در اتصال به دیتابیس" };

const discard = (file) => { if (file?.path) fs.unlink(file.path, () => {}); };
const filePathOf = (f) => path.join(MEDICAL_FILES_DIR, path.basename(f.storedName));

// رکورد را با JSONهای parse‌شده برمی‌گرداند (systemsReview / recommendations)
function withParsedJson(record) {
  return { ...record, systemsReview: parseJsonField(record.systemsReview) || {}, recommendations: parseJsonField(record.recommendations) || {} };
}

// ---------- گزارش کامل یک پرونده صحی (ویرایش، خلاصه، چاپ) — داکتر/ادمین ----------
// GET /api/medical-records/encounters/:id/report
export async function getEncounterReport(req, res) {
  try {
    const record = await getRecordById(req.params.id);
    if (!record) return res.status(404).json({ message: "پرونده صحی یافت نشد" });
    const actingDoctor = await resolveActingDoctor(req);
    if (req.user.role === "doctor" && !actingDoctor) return res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    if (!(await ensureDoctorOwnsPatient(req, actingDoctor, record.patientId))) {
      return res.status(403).json({ message: "شما فقط به پرونده‌ی بیمارانِ خودتان دسترسی دارید" });
    }
    await logEmr(req, "مشاهده گزارش پرونده صحی", `recordId=${record.id} patientId=${record.patientId}`);
    const [patient, doctor, labResults, files, appointment] = await Promise.all([
      getPatientById(record.patientId),
      record.doctorId ? getDoctorById(record.doctorId) : null,
      getLabResultsByRecordId(record.id),
      getFilesByRecordId(record.id),
      record.appointmentId ? getAppointmentById(record.appointmentId) : null,
    ]);
    return res.status(200).json({
      record: withParsedJson(record),
      patient: patient && { id: patient.id, fullName: patient.fullName, publicCode: patient.publicCode, phone: patient.phone, email: patient.email, gender: patient.gender, dateOfBirth: patient.dateOfBirth },
      doctor: doctor && { id: doctor.id, fullName: doctor.fullName, department: doctor.department },
      labResults, files,
      appointment: appointment && { id: appointment.id, appointmentDate: appointment.appointmentDate, appointmentTime: appointment.appointmentTime, department: appointment.department, status: appointment.status },
      canEdit: canManage(req, actingDoctor, record) && req.user.role === "doctor",
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// ---------- افزودن تصویر پزشکی / سند به پرونده ----------
// POST /api/medical-records/encounters/:id/files (multipart: file + kind, category, title, fileDate, description)
export async function addEncounterFile(req, res) {
  const upload = req.file;
  try {
    if (!upload) return res.status(400).json({ message: "فایلی انتخاب نشده است" });
    const record = await getRecordById(req.params.id);
    if (!record) { discard(upload); return res.status(404).json({ message: "پرونده صحی یافت نشد" }); }
    const actingDoctor = await resolveActingDoctor(req);
    if (!canManage(req, actingDoctor, record)) { discard(upload); return res.status(403).json({ message: "شما اجازه‌ی افزودن فایل به این پرونده را ندارید" }); }

    const { kind, category, title, fileDate, description } = req.body;
    if (!["image", "document"].includes(kind)) { discard(upload); return res.status(400).json({ message: "نوع فایل نامعتبر است" }); }
    if (kind === "image" && !upload.mimetype.startsWith("image/")) { discard(upload); return res.status(400).json({ message: "برای «تصاویر پزشکی» فقط فایل تصویری (JPG/PNG/WEBP) مجاز است" }); }
    const allowedCategories = kind === "image" ? IMAGE_CATEGORIES : DOCUMENT_CATEGORIES;
    const safeCategory = allowedCategories.includes(category) ? category : "other";
    const safeTitle = String(title || "").trim();
    if (!safeTitle) { discard(upload); return res.status(400).json({ message: "عنوان فایل الزامی است" }); }
    if (safeTitle.length > 150) { discard(upload); return res.status(400).json({ message: "عنوان نباید بیشتر از ۱۵۰ کاراکتر باشد" }); }
    if (fileDate && Number.isNaN(Date.parse(fileDate))) { discard(upload); return res.status(400).json({ message: "فرمت تاریخ نامعتبر است" }); }
    if (String(description || "").length > 1500) { discard(upload); return res.status(400).json({ message: "توضیحات نباید بیشتر از ۱۵۰۰ کاراکتر باشد" }); }
    if ((await countFilesByRecordId(record.id)) >= MAX_FILES_PER_RECORD) {
      discard(upload);
      return res.status(400).json({ message: `حداکثر ${MAX_FILES_PER_RECORD} فایل برای هر پرونده مجاز است` });
    }

    // نام اصلی فایل فقط برای نمایش/دانلود است؛ مسیر دیسک همیشه همان نام تصادفی سرور است
    const originalName = Buffer.from(upload.originalname, "latin1").toString("utf8").slice(0, 255);
    const file = await createFile({
      recordId: record.id, patientId: record.patientId, doctorId: record.doctorId,
      kind, category: safeCategory, title: safeTitle, fileDate: fileDate || null, description: String(description || "").trim() || null,
      originalName, storedName: upload.filename, mimeType: upload.mimetype, sizeBytes: upload.size,
    });
    await logEmr(req, kind === "image" ? "افزودن تصویر پزشکی به پرونده صحی" : "افزودن سند به پرونده صحی", `recordId=${record.id} fileId=${file.id}`);
    const { storedName, ...publicFile } = file; // eslint-disable-line no-unused-vars
    return res.status(201).json({ message: "فایل اضافه شد", file: publicFile });
  } catch (err) {
    discard(upload);
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

function streamFile(res, file, asDownload) {
  const full = filePathOf(file);
  if (!fs.existsSync(full)) return res.status(404).json({ message: "فایل روی سرور یافت نشد" });
  res.setHeader("Content-Type", file.mimeType);
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Cache-Control", "private, no-store");
  res.setHeader("Content-Disposition", `${asDownload ? "attachment" : "inline"}; filename*=UTF-8''${encodeURIComponent(file.originalName)}`);
  return fs.createReadStream(full).pipe(res);
}

// GET /api/medical-records/files/:fileId[?download=1] — داکتر (فقط بیماران خودش) / ادمین
export async function getEncounterFile(req, res) {
  try {
    const file = await getFileById(req.params.fileId);
    if (!file) return res.status(404).json({ message: "فایل یافت نشد" });
    const actingDoctor = await resolveActingDoctor(req);
    if (req.user.role === "doctor" && !actingDoctor) return res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    if (!(await ensureDoctorOwnsPatient(req, actingDoctor, file.patientId))) {
      return res.status(403).json({ message: "شما فقط به فایل‌های بیمارانِ خودتان دسترسی دارید" });
    }
    await logEmr(req, req.query.download === "1" ? "دانلود فایل پرونده صحی" : "مشاهده فایل پرونده صحی", `fileId=${file.id} patientId=${file.patientId}`);
    return streamFile(res, file, req.query.download === "1");
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// DELETE /api/medical-records/files/:fileId — فقط داکترِ ثبت‌کننده‌ی همان پرونده
export async function removeEncounterFile(req, res) {
  try {
    const file = await getFileById(req.params.fileId);
    if (!file) return res.status(404).json({ message: "فایل یافت نشد" });
    const record = await getRecordById(file.recordId);
    const actingDoctor = await resolveActingDoctor(req);
    if (!record || !canManage(req, actingDoctor, record)) return res.status(403).json({ message: "شما اجازه‌ی حذف این فایل را ندارید" });
    await deleteFile(file.id);
    fs.unlink(filePathOf(file), () => {});
    await logEmr(req, "حذف فایل پرونده صحی", `recordId=${record.id} fileId=${file.id}`);
    return res.status(200).json({ message: "فایل حذف شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// ---------- ارسال گزارش پزشکی به بیمار ----------
// POST /api/medical-records/encounters/:id/send  { message? }
// فقط پرونده‌ی «ثبت‌شده» (نه پیش‌نویس) و فقط برای بیماری که حساب کاربری دارد؛ اعلان به همان حساب می‌رود.
export async function sendEncounterToPatient(req, res) {
  try {
    const record = await getRecordById(req.params.id);
    if (!record) return res.status(404).json({ message: "پرونده صحی یافت نشد" });
    const actingDoctor = await resolveActingDoctor(req);
    if (!canManage(req, actingDoctor, record)) return res.status(403).json({ message: "فقط داکترِ ثبت‌کننده می‌تواند این پرونده را ارسال کند" });
    if (record.status === "draft") return res.status(400).json({ message: "ابتدا پرونده را ثبت نهایی کنید؛ پیش‌نویس قابل ارسال نیست" });
    const patient = await getPatientById(record.patientId);
    if (!patient?.userId) return res.status(400).json({ message: "این بیمار حساب کاربری ندارد و امکان ارسال پرونده برای او وجود ندارد" });

    const note = String(req.body.message || "").trim();
    const updated = await markRecordSent(record.id, note);
    await createNotification({
      userId: patient.userId,
      title: "گزارش پزشکی جدید",
      message: note || "گزارش پزشکی شما توسط داکتر ثبت و برای شما ارسال شد. لطفاً در بخش «پرونده‌های صحی من» مطالعه کنید.",
      type: "health_record",
      relatedId: record.id,
    });
    await logEmr(req, record.sentToPatientAt ? "ارسال مجدد گزارش پزشکی به بیمار" : "ارسال گزارش پزشکی به بیمار", `recordId=${record.id} patientId=${record.patientId}`);
    await auditEmr(req, "medical_records", record.id, "UPDATE", record, updated);
    return res.status(200).json({ message: "گزارش پزشکی برای بیمار ارسال شد", record: withParsedJson(updated) });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// ---------- مسیرهای بیمار (فقط‌خواندنی؛ مالکیت از روی توکن) ----------
// GET /api/users/health-records
export async function listMyHealthRecords(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT m.id, DATE_FORMAT(m.visitDate, '%Y-%m-%d') AS visitDate, m.visitReason, m.diagnosis, m.createdAt,
              m.sentToPatientAt, (m.sentToPatientAt IS NOT NULL) AS released,
              d.fullName AS doctorName, d.department AS department,
              (SELECT COUNT(*) FROM medical_record_files f WHERE f.recordId = m.id AND m.sentToPatientAt IS NOT NULL) AS fileCount
       FROM medical_records m
       JOIN patients p ON m.patientId = p.id
       LEFT JOIN doctors d ON m.doctorId = d.id
       WHERE p.userId = ? AND m.status <> 'draft'
       ORDER BY m.visitDate DESC, m.id DESC`,
      [req.user.id]
    );
    return res.status(200).json({ records: rows.map((r) => ({ ...r, released: !!r.released, fileCount: Number(r.fileCount) || 0 })) });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// GET /api/users/health-records/:id — رکورد دیگری (یا پیش‌نویس) = ۴۰۴ (وجودش لو نمی‌رود)
export async function getMyHealthRecord(req, res) {
  try {
    const [rows] = await db.query(
      `SELECT m.*, d.fullName AS doctorName, d.department AS department, p.fullName AS patientName, p.publicCode AS patientCode
       FROM medical_records m
       JOIN patients p ON m.patientId = p.id
       LEFT JOIN doctors d ON m.doctorId = d.id
       WHERE m.id = ? AND p.userId = ? AND m.status <> 'draft'`,
      [req.params.id, req.user.id]
    );
    if (!rows[0]) return res.status(404).json({ message: "پرونده صحی یافت نشد" });
    const safe = sanitizeRecordForPatient(rows[0]);
    const released = safe.released;
    const labResults = (await getLabResultsByRecordId(safe.id, { onlyCompleted: true }))
      .map(({ id, testName, result, unit, referenceRange, testDate, status, reportUrl }) => ({ id, testName, result, unit, referenceRange, testDate, status, hasFile: !!reportUrl }));
    const files = released ? await getReleasedFilesByRecordId(safe.id) : [];
    return res.status(200).json({
      record: { ...safe, recommendations: parseJsonField(safe.recommendations) || {} },
      labResults,
      files,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

// GET /api/users/health-records/files/:fileId[?download=1] — فقط فایل‌های خودِ بیمار از پرونده‌های «ارسال‌شده»
export async function downloadMyHealthRecordFile(req, res) {
  try {
    const file = await getReleasedFileForPatientUser(req.params.fileId, req.user.id);
    if (!file) return res.status(404).json({ message: "فایل یافت نشد" });
    return streamFile(res, file, req.query.download === "1");
  } catch (err) {
    console.error(err);
    return res.status(500).json(SERVER_ERROR);
  }
}

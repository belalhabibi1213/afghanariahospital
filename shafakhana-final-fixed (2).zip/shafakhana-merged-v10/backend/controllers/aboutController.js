import path from "path";
import crypto from "crypto";
import { getSiteContent, setSiteContent, deleteSiteContent } from "../models/SiteContent.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { ABOUT_DIR } from "../middleware/upload.js";
import { removeUploadedFile } from "../utils/uploadStore.js";

// ---------- بخش «معرفی» صفحه‌ی اصلی (About) — قابل‌ویرایش توسط ادمین ----------
// محتوا یک شیء JSON است: { imageUrl, eyebrow:{fa,ps,en}, title:{...}, text:{...},
// points:[{ id, icon, title:{...}, text:{...} }] }. اگر ادمین هنوز چیزی ذخیره نکرده باشد
// (null)، سایت همان متن‌ها/عکس پیش‌فرض را نشان می‌دهد. متن‌ها می‌توانند {hospital} داشته باشند.
const KEY = "about";
const LANGS = ["fa", "ps", "en"];
const IMAGE_PREFIX = "/uploads/about/";
const MAX_POINTS = 12;

const LIMITS = { eyebrow: 120, title: 200, text: 2000, pointTitle: 120, pointText: 400, icon: 16 };

const audit = (req, action, oldValues, newValues) =>
  recordAudit({
    req, tableName: "site_content", recordId: KEY, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });
const log = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

function cleanLangObject(raw, max, label, errors) {
  const out = {};
  const src = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  for (const lang of LANGS) {
    const v = src[lang] === null || src[lang] === undefined ? "" : String(src[lang]).trim();
    if (v.length > max) errors.push(`${label} (${lang}) نباید بیشتر از ${max} کاراکتر باشد`);
    out[lang] = v;
  }
  return out;
}

const hasAny = (obj) => LANGS.some((l) => obj[l]);

// ورودی PUT را اعتبارسنجی/پاک‌سازی می‌کند؛ آدرس عکس هرگز از این ورودی پذیرفته نمی‌شود
// (فقط از مسیر آپلود فایل تغییر می‌کند)
export function sanitizeAboutInput(body, imageUrl = "") {
  const errors = [];
  const eyebrow = cleanLangObject(body?.eyebrow, LIMITS.eyebrow, "عنوان کوچک", errors);
  const title = cleanLangObject(body?.title, LIMITS.title, "عنوان اصلی", errors);
  const text = cleanLangObject(body?.text, LIMITS.text, "متن معرفی", errors);
  if (!hasAny(title)) errors.push("عنوان اصلی حداقل در یک زبان لازم است");
  if (!hasAny(text)) errors.push("متن معرفی حداقل در یک زبان لازم است");

  const rawPoints = Array.isArray(body?.points) ? body.points : [];
  if (rawPoints.length > MAX_POINTS) errors.push(`حداکثر ${MAX_POINTS} مورد مجاز است`);
  const seen = new Set();
  const points = rawPoints.slice(0, MAX_POINTS).map((p, i) => {
    let id = typeof p?.id === "string" && /^[A-Za-z0-9_-]{1,40}$/.test(p.id) ? p.id : "";
    if (!id || seen.has(id)) id = crypto.randomBytes(6).toString("hex");
    seen.add(id);
    // آیکون: ایموجی/نماد کوتاه (حداکثر ۱۶ نویسه) یا آیکون برداری انتخاب‌شده از کتابخانه به شکل «lucide:Name»
    const icon = String(p?.icon ?? "").trim();
    const isLucide = /^lucide:[A-Za-z0-9]{1,40}$/.test(icon);
    if (!isLucide && (icon.startsWith("lucide:") || icon.length > LIMITS.icon)) errors.push(`آیکون مورد ${i + 1} نامعتبر یا خیلی بلند است`);
    const ptitle = cleanLangObject(p?.title, LIMITS.pointTitle, `عنوان مورد ${i + 1}`, errors);
    const ptext = cleanLangObject(p?.text, LIMITS.pointText, `توضیح مورد ${i + 1}`, errors);
    if (!hasAny(ptitle)) errors.push(`عنوان مورد ${i + 1} حداقل در یک زبان لازم است`);
    return { id, icon, title: ptitle, text: ptext };
  });

  return { errors, value: { imageUrl, eyebrow, title, text, points } };
}

// آدرس عکس فقط اگر واقعاً در پوشه‌ی about باشد معتبر است
const safeImage = (url) => (typeof url === "string" && url.startsWith(IMAGE_PREFIX) ? url : "");

async function loadAbout() {
  const stored = await getSiteContent(KEY);
  return stored ? { ...stored, imageUrl: safeImage(stored.imageUrl) } : null;
}

// عمومی (بدون ورود): GET /api/settings/about
export async function getAboutPublic(req, res) {
  try {
    return res.status(200).json({ about: await loadAbout() });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function getAboutAdmin(req, res) {
  try {
    return res.status(200).json({ about: await loadAbout() });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function saveAbout(req, res) {
  try {
    const previous = await loadAbout();
    const { errors, value } = sanitizeAboutInput(req.body, previous?.imageUrl || "");
    if (errors.length) return res.status(400).json({ message: errors[0], errors });
    await setSiteContent(KEY, value);
    await log(req, "ویرایش بخش معرفی سایت", `${value.points.length} مورد`);
    await audit(req, previous ? "UPDATE" : "INSERT", previous, value);
    return res.status(200).json({ message: "بخش معرفی ذخیره شد", about: value });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

function removeOldImage(url) {
  if (url && url.startsWith(IMAGE_PREFIX)) removeUploadedFile(path.join(ABOUT_DIR, path.basename(url)));
}

// عکس بخش معرفی: اگر هنوز محتوای سفارشی ذخیره نشده، یک رکورد با متن خالی ساخته نمی‌شود؛
// فقط آدرس عکس در یک رکورد جزئی نگه‌داری می‌شود و فرانت‌اند برای متن‌های خالی از پیش‌فرض استفاده می‌کند.
export async function uploadAboutImage(req, res) {
  try {
    if (!req.file) return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    const previous = (await getSiteContent(KEY)) || {};
    const imageUrl = `${IMAGE_PREFIX}${req.file.filename}`;
    await setSiteContent(KEY, { ...previous, imageUrl });
    removeOldImage(previous.imageUrl);
    await log(req, "تغییر عکس بخش معرفی سایت", imageUrl);
    await audit(req, "UPDATE", { imageUrl: previous.imageUrl || null }, { imageUrl });
    return res.status(200).json({ message: "عکس ذخیره شد", imageUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function removeAboutImage(req, res) {
  try {
    const previous = await getSiteContent(KEY);
    if (!previous || !safeImage(previous.imageUrl)) {
      return res.status(404).json({ message: "عکسی برای حذف وجود ندارد" });
    }
    await setSiteContent(KEY, { ...previous, imageUrl: "" });
    removeOldImage(previous.imageUrl);
    await log(req, "حذف عکس بخش معرفی سایت", previous.imageUrl);
    await audit(req, "UPDATE", { imageUrl: previous.imageUrl }, { imageUrl: null });
    return res.status(200).json({ message: "عکس حذف شد؛ عکس پیش‌فرض نمایش داده می‌شود" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// بازگشت کامل به متن‌ها و عکس پیش‌فرض سایت
export async function resetAbout(req, res) {
  try {
    const previous = await getSiteContent(KEY);
    if (previous) removeOldImage(previous.imageUrl);
    await deleteSiteContent(KEY);
    await log(req, "بازگرداندن بخش معرفی سایت به حالت پیش‌فرض");
    await audit(req, "DELETE", previous, null);
    return res.status(200).json({ message: "بخش معرفی به حالت پیش‌فرض برگشت" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

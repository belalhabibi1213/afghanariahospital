import crypto from "crypto";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import {
  findByEmail,
  createUser,
  setVerificationCode,
  markEmailVerified,
  setResetCode,
  clearResetCode,
  updatePassword,
  registerFailedLogin,
  resetFailedLoginAttempts,
  registerFailedOtp,
} from "../models/User.js";
import { unknownEmailLockMinutes, registerUnknownEmailFailure } from "../utils/loginThrottle.js";
import { getAllSettings } from "../models/Settings.js";
import { generateOtp, hashOtp, getOtpExpiry, otpMatches, OTP_MAX_ATTEMPTS } from "../utils/otp.js";
import { sendVerificationEmail, sendPasswordResetEmail } from "../utils/mailer.js";
import { logActivity, getClientIp, getUserAgent } from "../models/ActivityLog.js";
import { createSession, revokeSessionByTokenId, revokeAllSessionsForUser, userHasSessionFromIp } from "../models/Session.js";
import { JWT_SECRET, MFA_TOKEN_SECRET, MFA_ENABLED, isMfaRequiredForRole, BCRYPT_SALT_ROUNDS } from "../utils/env.js";
import { setAuthCookie, clearAuthCookie, csrfTokenFor } from "../utils/authCookies.js";

const SESSION_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000; // ۷ روز — دقیقاً هم‌راستا با expiresIn توکن زیر

// هر نشست یک شناسه‌ی یکتای jti دارد؛ همین شناسه (نه خودِ توکن) در جدول user_sessions
// ذخیره می‌شود تا Super Admin بتواند از پنل «نشست‌ها و دستگاه‌ها» آن را خاتمه دهد.
function issueToken(user, tokenId) {
  return jwt.sign({ id: user.id, email: user.email, role: user.role, jti: tokenId }, JWT_SECRET, { expiresIn: "7d" });
}

// یک ورود موفق (login تازه یا اولین ورود بعد از تایید ایمیل) را هم به‌عنوان JWT صادر می‌کند
// و هم یک ردیف نشست فعال برای آن ثبت می‌کند — بدون تغییر رفتار قبلی برای فراخوان‌ها
async function issueSession(req, user) {
  const tokenId = crypto.randomUUID();
  const token = issueToken(user, tokenId);
  await createSession({
    userId: user.id,
    tokenId,
    userName: user.fullName,
    role: user.role,
    ipAddress: getClientIp(req),
    userAgent: getUserAgent(req),
    expiresAt: new Date(Date.now() + SESSION_LIFETIME_MS),
  });
  return token;
}

// توکن JWT را در کوکی httpOnly می‌گذارد (جاوااسکریپت صفحه آن را نمی‌بیند) و فقط توکن CSRF
// مخصوص همین نشست را در JSON برمی‌گرداند تا فرانت‌اند آن را در هدر X-CSRF-Token بفرستد.
function startCookieSession(res, token) {
  setAuthCookie(res, token);
  const payload = jwt.decode(token);
  return csrfTokenFor(payload);
}

function publicUser(user) {
  return {
    id: user.id,
    fullName: user.fullName,
    email: user.email,
    role: user.role,
    photoUrl: user.photoUrl || null,
    themePreference: user.themePreference || "light",
    palettePreference: user.palettePreference || "teal",
    mustChangePassword: !!user.mustChangePassword,
    mfaEnabled: MFA_ENABLED && !!user.mfaEnabled,
    // نقش‌های الزام‌شده بدون MFA بعد از ورود فقط به صفحه‌ی راه‌اندازی MFA دسترسی دارند
    mfaSetupRequired: isMfaRequiredForRole(user.role) && !user.mfaEnabled,
  };
}

// هش ساختگی برای هم‌زمان‌سازی زمان پاسخ وقتی ایمیل وجود ندارد (جلوگیری از user enumeration با زمان‌سنجی)
const DUMMY_PASSWORD_HASH = bcrypt.hashSync("dummy-password-for-timing", BCRYPT_SALT_ROUNDS);

// آستانه‌ی قفل: حداقل ۳ تلاش و ۱ دقیقه — مقدار ۰/منفی/نامعتبر در تنظیمات نباید محافظ را بی‌اثر کند
async function lockoutPolicy() {
  const settings = await getAllSettings();
  return {
    maxAttempts: Math.max(3, Math.floor(Number(settings.loginMaxFailedAttempts)) || 5),
    lockoutMinutes: Math.max(1, Math.floor(Number(settings.loginLockoutMinutes)) || 15),
  };
}

function lockedResponse(res, minutesLeft) {
  return res.status(423).json({
    message: `به‌دلیل چند تلاش ناموفق، ورود موقتاً قفل شده است. لطفاً حدود ${minutesLeft} دقیقه‌ی دیگر دوباره تلاش کنید یا رمز عبور خود را بازیابی کنید.`,
    code: "ACCOUNT_LOCKED",
  });
}

// پایان مشترک ورود موفق (بعد از رمز، و در صورت فعال بودن MFA بعد از کد دومرحله‌ای)
export async function finishLogin(req, res, user, { activityAction = "ورود به سیستم" } = {}) {
  const token = await issueSession(req, user);
  await logActivity({ req, userId: user.id, userName: user.fullName, role: user.role, action: activityAction });
  const csrfToken = startCookieSession(res, token);
  return res.status(200).json({ message: "ورود موفقیت‌آمیز بود", user: publicUser(user), csrfToken });
}

export { publicUser };

async function issueAndSendCode(user) {
  const code = generateOtp();
  await setVerificationCode(user.id, hashOtp(code), getOtpExpiry());
  return sendVerificationEmail({ to: user.email, fullName: user.fullName, code });
}

export async function login(req, res) {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "ایمیل و رمز عبور الزامی است" });
    }

    const user = await findByEmail(email);
    if (!user) {
      // ایمیل ناموجود: دقیقاً همان کارِ زمان‌بر (bcrypt) و همان رفتار قفل حساب‌های واقعی، تا نه زمان پاسخ
      // و نه قفل‌شدن (۴۲۳) وجود ایمیل را لو بدهد.
      await bcrypt.compare(String(password), DUMMY_PASSWORD_HASH);
      const lockedFor = unknownEmailLockMinutes(email);
      if (lockedFor > 0) return lockedResponse(res, lockedFor);
      const { maxAttempts, lockoutMinutes } = await lockoutPolicy();
      registerUnknownEmailFailure(email, maxAttempts, lockoutMinutes);
      return res.status(401).json({ message: "ایمیل یا رمز عبور اشتباه است" });
    }

    // قفل موقت حساب (مستقل از محدودیت نرخ IP). «قفل هوشمند»: مهاجمی که فقط ایمیل را می‌داند نمی‌تواند
    // صاحب حساب را بیرون نگه دارد — اگر قبلاً از همین IP وارد شده باشد، قفل او را متوقف نمی‌کند
    // (رمز همچنان باید درست باشد و تلاش اشتباه همچنان شمرده می‌شود).
    if (user.lockedUntil && new Date(user.lockedUntil) > new Date()) {
      const knownIp = await userHasSessionFromIp(user.id, getClientIp(req));
      if (!knownIp) {
        const minutesLeft = Math.max(1, Math.ceil((new Date(user.lockedUntil) - new Date()) / 60000));
        // برای حساب قفل‌شده هم همان زمانِ bcrypt صرف می‌شود تا با زمان‌سنجی قابل تشخیص نباشد
        await bcrypt.compare(String(password), DUMMY_PASSWORD_HASH);
        return lockedResponse(res, minutesLeft);
      }
    }

    // bcrypt.compare (نسخه async) تا حلقه‌ی رویداد مسدود نشود
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      const { maxAttempts, lockoutMinutes } = await lockoutPolicy();
      await registerFailedLogin(user.id, maxAttempts, lockoutMinutes);
      return res.status(401).json({ message: "ایمیل یا رمز عبور اشتباه است" });
    }

    if (!user.isActive) {
      return res.status(403).json({ message: "حساب کاربری شما غیرفعال شده است. با مدیر سیستم تماس بگیرید." });
    }

    if (!user.isVerified) {
      return res.status(403).json({
        code: "EMAIL_NOT_VERIFIED",
        message: "ایمیل شما هنوز تایید نشده است. لطفاً کد ارسال‌شده به ایمیل خود را وارد کنید.",
        email: user.email,
      });
    }

    // MFA: رمز درست است ولی نشست هنوز صادر نمی‌شود؛ یک توکن کوتاه‌مدت و تک‌منظوره می‌دهیم که فقط
    // برای POST /api/auth/mfa/verify قابل استفاده است. شمارنده‌ی تلاش اشتباه در این حالت «پاک
    // نمی‌شود» تا مهاجمِ دارای رمز نتواند با ورودهای مکرر، شمارنده‌ی حدس کد را صفر کند.
    if (MFA_ENABLED && user.mfaEnabled) {
      const mfaToken = jwt.sign({ id: user.id, purpose: "mfa" }, MFA_TOKEN_SECRET, { expiresIn: "5m" });
      return res.status(200).json({ mfaRequired: true, mfaToken, message: "کد احراز هویت دومرحله‌ای را وارد کنید" });
    }

    if (user.failedLoginAttempts > 0 || user.lockedUntil) {
      await resetFailedLoginAttempts(user.id);
    }
    return finishLogin(req, res, user);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

const REGISTER_GENERIC_MESSAGE =
  "اگر این ایمیل قبلاً ثبت نشده باشد، حساب ساخته و کد تایید به آن ارسال شد. اگر قبلاً ثبت‌نام کرده‌اید، وارد شوید یا رمز عبور را بازیابی کنید.";

export async function register(req, res) {
  try {
    const { fullName, email, password } = req.body;

    if (!fullName || !email || !password) {
      return res.status(400).json({ message: "همه فیلدها الزامی است" });
    }

    // پاسخ یکسان برای ایمیل جدید و ایمیل موجود (جلوگیری از user enumeration): نه ۴۰۹ می‌دهیم و نه
    // زمان پاسخ فرق می‌کند. حساب موجود تاییدنشده کد جدید می‌گیرد؛ حساب موجود تاییدشده هیچ چیزی دریافت نمی‌کند.
    const existing = await findByEmail(email);
    if (existing) {
      if (!existing.isVerified) {
        await issueAndSendCode(existing).catch((e) => console.error(e));
      } else {
        await bcrypt.hash(String(password), BCRYPT_SALT_ROUNDS); // هم‌زمان‌سازی زمان با مسیر ساخت حساب
      }
      return res.status(201).json({ message: REGISTER_GENERIC_MESSAGE, email: String(email).toLowerCase(), emailDelivered: true });
    }

    // ثبت‌نام عمومی همیشه با نقش "user" (بیمار) ساخته می‌شود؛
    // نقش‌های admin/superadmin فقط توسط Super Admin از پنل مدیریت ساخته می‌شوند.
    const newUser = await createUser({ fullName, email, password, role: "user" });
    const emailResult = await issueAndSendCode(newUser);

    return res.status(201).json({
      message: REGISTER_GENERIC_MESSAGE,
      email: newUser.email,
      emailDelivered: emailResult.delivered,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// پیام یکسان برای هر ناموفقیتِ تایید/بازیابی: ایمیل ناشناس، حساب تاییدشده، نبودن کد، کد منقضی یا کد
// اشتباه همگی دقیقاً یک پاسخ می‌دهند تا مهاجم نتواند از تفاوت پیام‌ها وجود ایمیل را حدس بزند.
const INVALID_VERIFICATION_CODE_MESSAGE = "کد تایید نامعتبر یا منقضی شده است. در صورت نیاز یک کد جدید درخواست کنید.";
const INVALID_RESET_CODE_MESSAGE = "کد بازیابی نامعتبر یا منقضی شده است. در صورت نیاز یک کد جدید درخواست کنید.";

export async function verifyEmail(req, res) {
  try {
    const { email, code } = req.body;

    const user = await findByEmail(email);

    // امنیتی: «حساب تاییدشده» نباید هیچ‌وقت با این مسیر نشست بگیرد. قبلاً برای حساب‌های تاییدشده
    // بدون بررسی کد (و بدون رمز) کوکی ورود صادر می‌شد، یعنی هر کسی با دانستن ایمیل یک کاربر
    // (حتی سوپرادمین) وارد حساب او می‌شد. نشست فقط باید بعد از «کد درست» صادر شود.
    if (!user || user.isVerified || !user.verificationCodeHash || !user.verificationExpires) {
      return res.status(400).json({ message: INVALID_VERIFICATION_CODE_MESSAGE });
    }

    if (new Date(user.verificationExpires).getTime() < Date.now()) {
      return res.status(400).json({ message: INVALID_VERIFICATION_CODE_MESSAGE });
    }

    if (!otpMatches(code, user.verificationCodeHash)) {
      // حدس اشتباه روی «همین حساب» شمرده می‌شود؛ بعد از OTP_MAX_ATTEMPTS بار کد باطل می‌شود
      await registerFailedOtp(user.id, "verification", OTP_MAX_ATTEMPTS);
      return res.status(400).json({ message: INVALID_VERIFICATION_CODE_MESSAGE });
    }

    // کد درست است؛ ولی حساب غیرفعال‌شده (توسط مدیر) نباید از این مسیر نشست بگیرد (مثل login)
    if (!user.isActive) {
      return res.status(403).json({ message: "حساب کاربری شما غیرفعال شده است. با مدیر سیستم تماس بگیرید." });
    }

    await markEmailVerified(user.id);
    const token = await issueSession(req, user);
    await logActivity({ req, userId: user.id, userName: user.fullName, role: user.role, action: "تایید ایمیل و ورود اول" });

    const csrfToken = startCookieSession(res, token);
    return res.status(200).json({
      message: "ایمیل شما با موفقیت تایید شد",
      user: publicUser(user),
      csrfToken,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function resendVerification(req, res) {
  try {
    const { email } = req.body;

    const user = await findByEmail(email);

    // پاسخ برای «ایمیل ناشناس»، «حساب تاییدشده» و «ارسال موفق» از بیرون یکسان است
    // تا از این مسیر نتوان وجود/وضعیت یک ایمیل را فهمید (مثل forgot-password).
    if (!user || user.isVerified) {
      return res.status(200).json({
        message: "اگر این ایمیل ثبت شده و هنوز تایید نشده باشد، کد تایید جدید به آن ارسال می‌شود.",
        emailDelivered: true,
      });
    }

    const emailResult = await issueAndSendCode(user);

    return res.status(200).json({
      message: "اگر این ایمیل ثبت شده و هنوز تایید نشده باشد، کد تایید جدید به آن ارسال می‌شود.",
      emailDelivered: emailResult.delivered,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// اطلاعات کاربر واردشده را بر اساس توکن برمی‌گرداند — برای بازیابی نشست در فرانت‌اند
export async function me(req, res) {
  try {
    const user = await findByEmail(req.user.email);
    if (!user) {
      return res.status(404).json({ message: "کاربر یافت نشد" });
    }
    if (!user.isActive) {
      return res.status(403).json({ message: "حساب کاربری شما غیرفعال شده است. با مدیر سیستم تماس بگیرید.", code: "ACCOUNT_DISABLED" });
    }
    return res.status(200).json({ user: publicUser(user), csrfToken: csrfTokenFor(req.user) });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// مرحله ۱ فراموشی رمز عبور: کاربر ایمیل خود را می‌فرستد، یک کد ۶ رقمی
// (معتبر برای ۱۵ دقیقه، طبق OTP_EXPIRES_MINUTES) به ایمیل او ارسال می‌شود.
export async function forgotPassword(req, res) {
  try {
    const { email } = req.body;

    const user = await findByEmail(email);

    // به‌عمد چه ایمیل موجود باشد چه نباشد، همان پیام موفقیت‌آمیز عمومی برگردانده می‌شود
    // تا کسی نتواند از این مسیر برای حدس زدن ایمیل‌های ثبت‌شده در سیستم استفاده کند.
    if (!user) {
      return res.status(200).json({
        message: "اگر این ایمیل در سیستم ثبت باشد، کد بازیابی رمز عبور برای آن ارسال می‌شود.",
      });
    }

    const code = generateOtp();
    await setResetCode(user.id, hashOtp(code), getOtpExpiry());
    const emailResult = await sendPasswordResetEmail({ to: user.email, fullName: user.fullName, code });
    await logActivity({ req, userId: user.id, userName: user.fullName, role: user.role, action: "درخواست بازیابی رمز عبور" });

    return res.status(200).json({
      message: "اگر این ایمیل در سیستم ثبت باشد، کد بازیابی رمز عبور برای آن ارسال می‌شود.",
      emailDelivered: emailResult.delivered,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// مرحله ۲ فراموشی رمز عبور: کاربر ایمیل + کد ۶ رقمی + رمز عبور جدید را می‌فرستد.
// در صورت معتبر و منقضی‌نشده بودن کد، رمز جدید هش شده و ذخیره، و کد بازیابی باطل می‌شود.
export async function resetPassword(req, res) {
  try {
    const { email, code, newPassword } = req.body;

    const user = await findByEmail(email);

    // ایمیل ناشناس، نبودن کد، کد منقضی و کد اشتباه: همگی یک پاسخ یکسان (جلوگیری از افشای وجود ایمیل)
    if (!user || !user.resetCodeHash || !user.resetExpires) {
      return res.status(400).json({ message: INVALID_RESET_CODE_MESSAGE });
    }

    if (new Date(user.resetExpires).getTime() < Date.now()) {
      await clearResetCode(user.id);
      return res.status(400).json({ message: INVALID_RESET_CODE_MESSAGE });
    }

    if (!otpMatches(code, user.resetCodeHash)) {
      await registerFailedOtp(user.id, "reset", OTP_MAX_ATTEMPTS);
      return res.status(400).json({ message: INVALID_RESET_CODE_MESSAGE });
    }

    // رمز عبور جدید هش و ذخیره می‌شود، سپس کد بازیابی برای جلوگیری از استفاده مجدد باطل می‌شود
    await updatePassword(user.id, newPassword);
    await clearResetCode(user.id);
    // همه‌ی نشست‌های قبلی این حساب خاتمه می‌یابد (ممکن است دزدیده شده باشند)
    await revokeAllSessionsForUser(user.id);
    await logActivity({ req, userId: user.id, userName: user.fullName, role: user.role, action: "بازیابی موفق رمز عبور" });

    return res.status(200).json({ message: "رمز عبور شما با موفقیت تغییر کرد. اکنون می‌توانید وارد شوید." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// خروج: نشست سمت سرور خاتمه می‌یابد و کوکی httpOnly پاک می‌شود. چون جاوااسکریپت فرانت‌اند
// به کوکی دسترسی ندارد، فقط سرور می‌تواند آن را پاک کند؛ پس این مسیر عمداً حتی با توکن
// منقضی/نامعتبر هم کوکی را پاک و موفقیت برمی‌گرداند (مسیر با optionalAuth و بدون CSRF ثبت شده است).
export async function logout(req, res) {
  try {
    if (req.user) {
      // نشست این توکن را هم خاتمه می‌دهد تا در فهرست «نشست‌های فعال» پنل Super Admin
      // باقی نماند (توکن‌های قدیمی‌تر بدون jti را بی‌اثر نادیده می‌گیرد)
      await revokeSessionByTokenId(req.user.jti, req.user.id);
      await logActivity({
        req,
        userId: req.user.id,
        userName: req.user.email,
        role: req.user.role,
        action: "خروج از سیستم",
      });
    }
  } catch (err) {
    console.error(err);
  }
  clearAuthCookie(res);
  return res.status(200).json({ message: "خروج با موفقیت ثبت شد" });
}

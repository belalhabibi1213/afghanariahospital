import path from "path";
import bcrypt from "bcryptjs";
import { findByIdRaw, findById, updateProfile, updatePassword, updatePhoto, updateThemePreference, updatePalettePreference, formatPatientId } from "../models/User.js";
import { getPatientsByUser } from "../models/Patient.js";
import { getAppointmentsByUser } from "../models/Appointment.js";
import { getRecordsByPatientUser } from "../models/MedicalRecord.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { revokeAllSessionsForUser } from "../models/Session.js";
import { AVATARS_DIR } from "../middleware/upload.js";
import { removeUploadedFile } from "../utils/uploadStore.js";
import { getNotificationsByUser, getUnreadCount, markAsRead, markAllAsRead, getNotificationById } from "../models/Notification.js";
import { getPasswordPolicyError } from "../utils/passwordPolicy.js";
import { getAppointmentById } from "../models/Appointment.js";
import { getRecordById } from "../models/MedicalRecord.js";
import { getPrescriptionById } from "../models/Prescription.js";
import { getLabResultById } from "../models/LabResult.js";
import { getFileTransferById } from "../models/FileTransfer.js";
import { getInvoiceById } from "../models/Invoice.js";
import { getNewsById } from "../models/News.js";
import { getConversationById } from "../models/Chat.js";
import { getContactMessageById } from "../models/Contact.js";
import { isValidPersianName, PERSIAN_NAME_ERROR_MESSAGE } from "../utils/persianName.js";

const PHONE_REGEX = /^0\d{9}$/; // شماره تماس افغانستان: با صفر شروع و ۱۰ رقم
const GENDER_VALUES = ["male", "female", "other"];
const BLOOD_GROUP_VALUES = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const MEDICAL_TEXT_MAX_LENGTH = 500; // برای هر یک از فیلدهای آزاد اطلاعات طبی (حساسیت، بیماری مزمن، حساسیت دارویی)
const PALETTE_VALUES = ["teal", "ocean", "violet", "rose", "emerald", "sunset", "indigo", "coral", "gold", "orchid", "lime", "slate"];
const THEME_VALUES = ["light", "dark"]; // دو مقدار مجاز برای حالت روشن/تاریک

// ثبت لاگ حسابرسی (audit_logs) برای تغییرات حساب کاربری خودِ کاربر
const auditUser = (req, recordId, action, oldValues, newValues) =>
  recordAudit({
    req, tableName: "users", recordId, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });

// نمایش پروفایل کاربر واردشده (بیمار)
export async function getProfile(req, res, next) {
  try {
    const user = await findById(req.user.id);
    if (!user) return res.status(404).json({ message: "کاربر یافت نشد" });
    // شناسه بیمار (Patient ID) فقط برای نقش «user» معنا دارد؛ همیشه از روی id ساخته
    // می‌شود، هرگز از دیتابیس خوانده یا از ورودی گرفته نمی‌شود — پس تضمیناً read-only است.
    const patientId = user.role === "user" ? formatPatientId(user.id) : null;
    return res.status(200).json({ user: { ...user, patientId } });
  } catch (err) {
    // لاگ کامل (شامل کد/پیام خطای MySQL) برای عیب‌یابی سمت سرور، و سپردن پاسخ به کلاینت
    // به errorHandler مرکزی که در محیط توسعه پیام دقیق خطا را هم برمی‌گرداند — به‌جای
    // یک برچسب ثابت و گمراه‌کننده‌ی «خطای اتصال به دیتابیس» برای هر نوع خطای غیرمنتظره‌ای.
    console.error(`[users] getProfile error (userId=${req.user?.id}):`, err);
    return next(err);
  }
}

// ویرایش اطلاعات شخصی
export async function editProfile(req, res, next) {
  try {
    const {
      fullName, phone, dateOfBirth, gender, bloodGroup, address,
      emergencyContactName, emergencyContactRelationship, emergencyContactPhone,
      allergies, chronicDiseases, drugAllergies, height, weight,
    } = req.body;

    if (!fullName || !fullName.trim()) {
      return res.status(400).json({ message: "نام کامل الزامی است" });
    }
    if (fullName.trim().length < 3 || fullName.trim().length > 150) {
      return res.status(400).json({ message: "نام کامل باید بین ۳ تا ۱۵۰ کاراکتر باشد" });
    }
    // این مسیر (PUT /profile) بین همه‌ی نقش‌ها مشترک است، اما محدودیت «فقط فارسی/دری بودن
    // نام» فقط برای بیمار (role === "user") اعمال می‌شود تا نام داکتر/ادمین/مدیر کل دست‌نخورده بماند.
    if (req.user.role === "user" && !isValidPersianName(fullName)) {
      return res.status(400).json({ message: PERSIAN_NAME_ERROR_MESSAGE });
    }
    if (phone && !PHONE_REGEX.test(phone.trim())) {
      return res.status(400).json({ message: "شماره تماس معتبر نیست (مثال: 07XXXXXXXX)" });
    }
    if (gender && !GENDER_VALUES.includes(gender)) {
      return res.status(400).json({ message: "جنسیت انتخاب‌شده معتبر نیست" });
    }
    if (bloodGroup && !BLOOD_GROUP_VALUES.includes(bloodGroup)) {
      return res.status(400).json({ message: "گروه خونی انتخاب‌شده معتبر نیست" });
    }
    if (address && address.trim().length > 255) {
      return res.status(400).json({ message: "آدرس نباید بیشتر از ۲۵۵ کاراکتر باشد" });
    }
    if (emergencyContactName && (emergencyContactName.trim().length < 3 || emergencyContactName.trim().length > 150)) {
      return res.status(400).json({ message: "نام تماس اضطراری باید بین ۳ تا ۱۵۰ کاراکتر باشد" });
    }
    if (emergencyContactRelationship && emergencyContactRelationship.trim().length > 50) {
      return res.status(400).json({ message: "نسبت با بیمار نباید بیشتر از ۵۰ کاراکتر باشد" });
    }
    if (emergencyContactPhone && !PHONE_REGEX.test(emergencyContactPhone.trim())) {
      return res.status(400).json({ message: "شماره تماس اضطراری معتبر نیست (مثال: 07XXXXXXXX)" });
    }
    if (allergies && allergies.trim().length > MEDICAL_TEXT_MAX_LENGTH) {
      return res.status(400).json({ message: `حساسیت‌ها نباید بیشتر از ${MEDICAL_TEXT_MAX_LENGTH} کاراکتر باشد` });
    }
    if (chronicDiseases && chronicDiseases.trim().length > MEDICAL_TEXT_MAX_LENGTH) {
      return res.status(400).json({ message: `بیماری‌های مزمن نباید بیشتر از ${MEDICAL_TEXT_MAX_LENGTH} کاراکتر باشد` });
    }
    if (drugAllergies && drugAllergies.trim().length > MEDICAL_TEXT_MAX_LENGTH) {
      return res.status(400).json({ message: `حساسیت‌های دارویی نباید بیشتر از ${MEDICAL_TEXT_MAX_LENGTH} کاراکتر باشد` });
    }
    let normalizedHeight = null;
    if (height !== undefined && height !== null && height !== "") {
      const heightNum = Number(height);
      if (Number.isNaN(heightNum) || heightNum < 30 || heightNum > 250) {
        return res.status(400).json({ message: "قد معتبر نیست (بین ۳۰ تا ۲۵۰ سانتی‌متر)" });
      }
      normalizedHeight = heightNum;
    }
    let normalizedWeight = null;
    if (weight !== undefined && weight !== null && weight !== "") {
      const weightNum = Number(weight);
      if (Number.isNaN(weightNum) || weightNum < 1 || weightNum > 400) {
        return res.status(400).json({ message: "وزن معتبر نیست (بین ۱ تا ۴۰۰ کیلوگرام)" });
      }
      normalizedWeight = weightNum;
    }
    let normalizedDob = null;
    if (dateOfBirth) {
      if (!DATE_REGEX.test(dateOfBirth)) {
        return res.status(400).json({ message: "تاریخ تولد معتبر نیست" });
      }
      const parsed = new Date(dateOfBirth);
      const today = new Date();
      const minDate = new Date("1900-01-01");
      if (Number.isNaN(parsed.getTime()) || parsed > today || parsed < minDate) {
        return res.status(400).json({ message: "تاریخ تولد معتبر نیست" });
      }
      normalizedDob = dateOfBirth;
    }

    const existing = await findById(req.user.id);
    const updated = await updateProfile(req.user.id, {
      fullName: fullName.trim(),
      phone: phone ? phone.trim() : null,
      dateOfBirth: normalizedDob,
      gender: gender || null,
      bloodGroup: bloodGroup || null,
      address: address ? address.trim() : null,
      emergencyContactName: emergencyContactName ? emergencyContactName.trim() : null,
      emergencyContactRelationship: emergencyContactRelationship ? emergencyContactRelationship.trim() : null,
      emergencyContactPhone: emergencyContactPhone ? emergencyContactPhone.trim() : null,
      allergies: allergies ? allergies.trim() : null,
      chronicDiseases: chronicDiseases ? chronicDiseases.trim() : null,
      drugAllergies: drugAllergies ? drugAllergies.trim() : null,
      height: normalizedHeight,
      weight: normalizedWeight,
    });
    await logActivity({ req, userId: req.user.id, userName: fullName, role: req.user.role, action: "ویرایش اطلاعات پروفایل" });
    await auditUser(req, req.user.id, "UPDATE", existing, updated);
    const patientId = updated.role === "user" ? formatPatientId(updated.id) : null;
    return res.status(200).json({ message: "اطلاعات با موفقیت به‌روزرسانی شد", user: { ...updated, patientId } });
  } catch (err) {
    console.error(`[users] editProfile error (userId=${req.user?.id}):`, err);
    return next(err);
  }
}

// ذخیره‌ی ترجیح تم (روشن/تاریک) کاربر واردشده — هر کاربر فقط می‌تواند تم خودش
// (req.user.id از توکن JWT، نه از بدنه‌ی درخواست) را تغییر دهد
export async function updateTheme(req, res, next) {
  try {
    // بدنه می‌تواند theme (روشن/تاریک)، palette (رنگ‌بندی) یا هر دو را بفرستد
    const { theme, palette } = req.body || {};
    const hasTheme = theme !== undefined;
    const hasPalette = palette !== undefined;
    if (!hasTheme && !hasPalette) {
      return res.status(400).json({ message: "مقدار تم نامعتبر است" });
    }
    if (hasTheme && !THEME_VALUES.includes(theme)) {
      return res.status(400).json({ message: "مقدار تم نامعتبر است" });
    }
    if (hasPalette && !PALETTE_VALUES.includes(palette)) {
      return res.status(400).json({ message: "پالت رنگی نامعتبر است" });
    }
    if (hasTheme) await updateThemePreference(req.user.id, theme);
    if (hasPalette) await updatePalettePreference(req.user.id, palette);
    return res.status(200).json({
      message: "تم ذخیره شد",
      ...(hasTheme ? { themePreference: theme } : {}),
      ...(hasPalette ? { palettePreference: palette } : {}),
    });
  } catch (err) {
    console.error(`[users] updateTheme error (userId=${req.user?.id}):`, err);
    return next(err);
  }
}

// تغییر رمز عبور
export async function changePassword(req, res) {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: "رمز عبور فعلی و جدید الزامی است" });
    }
    const passwordError = getPasswordPolicyError(newPassword);
    if (passwordError) {
      return res.status(400).json({ message: passwordError });
    }
    const user = await findByIdRaw(req.user.id);
    // نسخه‌ی async (bcrypt.compare) به‌جای compareSync، تا رشته‌ی اصلی رویداد مسدود نشود
    const isMatch = await bcrypt.compare(currentPassword, user.password);
    if (!isMatch) {
      return res.status(401).json({ message: "رمز عبور فعلی اشتباه است" });
    }
    if (await bcrypt.compare(newPassword, user.password)) {
      return res.status(400).json({ message: "رمز عبور جدید نباید با رمز عبور فعلی یکسان باشد" });
    }
    await updatePassword(req.user.id, newPassword);
    // سایر نشست‌های این حساب (دستگاه‌های دیگر) خاتمه می‌یابد؛ نشست فعلی می‌ماند
    await revokeAllSessionsForUser(req.user.id, { exceptTokenId: req.user.jti || null });
    await logActivity({ req, userId: req.user.id, userName: user.fullName, role: req.user.role, action: "تغییر رمز عبور" });
    await auditUser(req, req.user.id, "UPDATE", { passwordChanged: false }, { passwordChanged: true });
    return res.status(200).json({ message: "رمز عبور با موفقیت تغییر یافت" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// آپلود / جایگزینی عکس پروفایل
export async function uploadPhoto(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    }

    const relativeUrl = `/uploads/avatars/${req.file.filename}`;
    const { previousPhotoUrl, user } = await updatePhoto(req.user.id, relativeUrl);

    // اگر عکس قبلی وجود داشت، از روی دیسک پاک می‌شود تا فایل یتیم روی سرور باقی نماند
    if (previousPhotoUrl) {
      const previousFilePath = path.join(AVATARS_DIR, path.basename(previousPhotoUrl));
      removeUploadedFile(previousFilePath); // خطای احتمالی (مثلاً فایل موجود نبود) نادیده گرفته می‌شود
    }

    await logActivity({ req, userId: req.user.id, userName: user.fullName, role: req.user.role, action: "آپلود عکس پروفایل" });
    await auditUser(req, req.user.id, "UPDATE", { photoUrl: previousPhotoUrl || null }, { photoUrl: relativeUrl });
    return res.status(200).json({ message: "عکس پروفایل با موفقیت به‌روزرسانی شد", user });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// تاریخچه نوبت‌های بیمار (همان چیزی که appointments/mine برمی‌گرداند، برای هم‌خوانی داشبورد اینجا هم تعریف شده)
export async function appointmentHistory(req, res) {
  try {
    const appointments = await getAppointmentsByUser(req.user.id);
    return res.status(200).json({ appointments });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// نسخه‌ها و سوابق طبی بیمار
export async function medicalRecords(req, res) {
  try {
    const records = await getRecordsByPatientUser(req.user.id);
    return res.status(200).json({ records });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// ---------- اعلان‌های درون‌برنامه‌ای (Notifications) ----------

// لیست اعلان‌های کاربر واردشده به همراه تعداد خوانده‌نشده‌ها
export async function listNotifications(req, res) {
  try {
    const [notifications, unreadCount] = await Promise.all([
      getNotificationsByUser(req.user.id),
      getUnreadCount(req.user.id),
    ]);
    return res.status(200).json({ notifications, unreadCount });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// فقط تعداد اعلان‌های خوانده‌نشده — برای نشان (badge) روی آیکون زنگوله
export async function unreadNotificationsCount(req, res) {
  try {
    const unreadCount = await getUnreadCount(req.user.id);
    return res.status(200).json({ unreadCount });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// یک اعلان مشخص را خوانده‌شده علامت می‌زند
export async function readNotification(req, res) {
  try {
    await markAsRead(req.params.id, req.user.id);
    return res.status(200).json({ message: "اعلان خوانده‌شده علامت‌گذاری شد" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// همه‌ی اعلان‌های کاربر را خوانده‌شده علامت می‌زند
export async function readAllNotifications(req, res) {
  try {
    await markAllAsRead(req.user.id);
    return res.status(200).json({ message: "همه اعلان‌ها خوانده‌شده علامت‌گذاری شدند" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// نگاشت مسیر داشبورد هر نقش (برای دیپ‌لینکینگ اعلان‌ها) — همان مسیرهایی که در App.jsx تعریف شده‌اند
const DASHBOARD_PATH_BY_ROLE = {
  user: "/dashboard/user",
  doctor: "/dashboard/doctor",
  admin: "/dashboard/admin",
  superadmin: "/dashboard/superadmin",
};

// برای هر نقش، تبی که «اعلان عمومی/سیستمی» بدون مقصد مشخص باید در آن باز شود
const DEFAULT_TAB_BY_ROLE = {
  user: "profile",
  doctor: "schedule",
  admin: "search",
  superadmin: "overview",
};

// اگر یک آیتم مرتبط با شناسه‌ی مشخص وجود داشته باشد true برمی‌گرداند؛ در غیر این صورت false.
// وقتی relatedId خالی باشد (اعلان عمومی/سیستمی)، چیزی برای بررسی وجود ندارد پس true برمی‌گردد.
async function relatedItemExists(type, relatedId) {
  if (!relatedId) return true;
  switch (type) {
    case "appointment":
      return Boolean(await getAppointmentById(relatedId));
    case "medical_record":
    case "health_record":
      return Boolean(await getRecordById(relatedId));
    case "prescription":
      return Boolean(await getPrescriptionById(relatedId));
    case "lab_result":
      return Boolean(await getLabResultById(relatedId));
    case "file_transfer":
      return Boolean(await getFileTransferById(relatedId));
    case "billing":
      return Boolean(await getInvoiceById(relatedId));
    case "news":
    case "news_comment":
      return Boolean(await getNewsById(relatedId));
    case "chat_message":
      return Boolean(await getConversationById(relatedId));
    case "contact_message":
      return Boolean(await getContactMessageById(relatedId));
    default:
      return true;
  }
}

// بر اساس نوع اعلان و نقش کاربر واردشده، مسیر/تب مقصد را تعیین می‌کند.
// خروجی: { path, tab, highlightId } — «tab» فقط برای مسیرهای داشبورد پر می‌شود،
// و «highlightId» به فرانت‌اند می‌گوید کدام ردیف را در جدول برجسته/اسکرول کند.
function resolveRoute(type, role, relatedId) {
  const dashboardPath = DASHBOARD_PATH_BY_ROLE[role] || DASHBOARD_PATH_BY_ROLE.user;

  switch (type) {
    case "appointment": {
      const tabByRole = { user: "history", doctor: "appointments", admin: "appointments", superadmin: "appointments" };
      // سوپرادمین تب «نوبت‌ها» ندارد، اما به داشبورد ادمین هم دسترسی دارد
      const path = role === "superadmin" ? DASHBOARD_PATH_BY_ROLE.admin : dashboardPath;
      return { path, tab: tabByRole[role] || "history", highlightId: relatedId };
    }
    case "medical_record":
      return { path: DASHBOARD_PATH_BY_ROLE.user, tab: "records", highlightId: relatedId };
    // گزارش پزشکی ارسال‌شده‌ی داکتر (فرم «افزودن پرونده صحی») → تب «پرونده‌های صحی من»
    case "health_record":
      return { path: DASHBOARD_PATH_BY_ROLE.user, tab: "healthRecords", highlightId: relatedId };
    case "prescription": {
      if (role === "doctor") return { path: dashboardPath, tab: "patients", highlightId: null };
      return { path: DASHBOARD_PATH_BY_ROLE.user, tab: "records", highlightId: relatedId };
    }
    case "lab_result": {
      if (role === "doctor") return { path: dashboardPath, tab: "patients", highlightId: null };
      return { path: DASHBOARD_PATH_BY_ROLE.user, tab: "records", highlightId: relatedId };
    }
    case "file_transfer": {
      if (role === "doctor") return { path: dashboardPath, tab: "transfer", highlightId: null };
      return { path: DASHBOARD_PATH_BY_ROLE.user, tab: "files", highlightId: relatedId };
    }
    case "billing": {
      const tabByRole = { user: "billing", doctor: "billing", admin: "billing", superadmin: "billing" };
      const path = role === "superadmin" ? DASHBOARD_PATH_BY_ROLE.admin : dashboardPath;
      return { path, tab: tabByRole[role] || "billing", highlightId: relatedId };
    }
    case "news":
      // خبر یک صفحه‌ی عمومی مستقل دارد، نه یک تب داشبورد
      return { path: relatedId ? `/news/${relatedId}` : "/", tab: null, highlightId: null };
    case "news_comment": {
      // برای نویسنده‌ی نظر (نقش user): مستقیماً به خودِ خبر
      if (role === "user" || role === "doctor") {
        return { path: relatedId ? `/news/${relatedId}` : "/", tab: null, highlightId: null };
      }
      // برای ادمین/سوپرادمین: تب «نظرات کاربران»، فیلترشده روی همان خبر
      return { path: DASHBOARD_PATH_BY_ROLE.admin, tab: "newsComments", highlightId: relatedId };
    }
    case "chat_message":
      // فقط بیمار و داکتر تب «گفتگو» دارند؛ relatedId شناسه‌ی مکالمه است (نه پیام)
      // تا رابط کاربری بتواند مستقیماً همان گفتگو را باز کند
      return { path: dashboardPath, tab: "chat", highlightId: relatedId };
    case "contact_message":
      // فقط ادمین این نوع اعلان را دریافت می‌کند (پیام تماس جدید)؛ به تب
      // «پیام‌های تماس با ما» با شناسه‌ی همان پیام هدایت می‌شود
      return { path: DASHBOARD_PATH_BY_ROLE.admin, tab: "contactMessages", highlightId: relatedId };
    default:
      return { path: dashboardPath, tab: DEFAULT_TAB_BY_ROLE[role] || null, highlightId: null };
  }
}

// GET /api/users/notifications/:id/target
// مقصد دیپ‌لینک یک اعلان را برمی‌گرداند، وجود آیتم مرتبط را بررسی می‌کند،
// و اعلان را خوانده‌شده علامت می‌زند (الزام: بعد از باز شدن صفحه، اعلان خوانده‌شده شود)
export async function resolveNotificationTarget(req, res) {
  try {
    const notification = await getNotificationById(req.params.id, req.user.id);
    if (!notification) {
      return res.status(404).json({ message: "اعلان یافت نشد" });
    }

    const exists = await relatedItemExists(notification.type, notification.relatedId);
    const route = resolveRoute(notification.type, req.user.role, notification.relatedId);

    // در هر صورت (چه آیتم مرتبط موجود باشد چه نه) اعلان خوانده‌شده علامت می‌خورد،
    // چون کاربر آن را باز/کلیک کرده است
    await markAsRead(notification.id, req.user.id);
    const unreadCount = await getUnreadCount(req.user.id);

    return res.status(200).json({
      exists,
      route: exists ? route : null,
      unreadCount,
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

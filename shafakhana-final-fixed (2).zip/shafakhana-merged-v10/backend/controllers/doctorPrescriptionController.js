import { getDoctorByUserId } from "../models/Doctor.js";
import { searchPrescriptionGroups, getPrescriptionStats } from "../models/Prescription.js";

// کنترلر پنل داکتر «نسخه و سوابق طبی». فقط نقش doctor به این مسیرها دسترسی دارد
// (routes/doctors.js با requireAuth + authorize("doctor")).
// شناسه‌ی داکتر همیشه از حساب واردشده (توکن) گرفته می‌شود، نه از query/body؛ بنابراین حتی اگر
// کاربر doctorId دلخواه بفرستد، فقط نسخه‌های خودش برمی‌گردد.
// جزئیات کامل بیمار و سوابق طبی از مسیر موجود GET /api/medical-records/patient/:id خوانده می‌شود
// (آنجا هم مالکیت بیمار در بک‌اند بررسی می‌شود) و اینجا تکرار نشده است.

async function requireOwnDoctor(req, res) {
  const doctor = await getDoctorByUserId(req.user.id);
  if (!doctor) {
    res.status(403).json({ message: "پروفایل داکتری برای این حساب یافت نشد" });
    return null;
  }
  return doctor;
}

// GET /api/doctors/me/prescriptions?q=&status=&patientId=&dateFrom=&dateTo=&page=&limit=
export async function listMyPrescriptions(req, res) {
  try {
    const doctor = await requireOwnDoctor(req, res);
    if (!doctor) return;

    const { q, status, patientId, dateFrom, dateTo, page, limit } = req.query;
    const { rows, total, page: currentPage, limit: pageLimit, totalPages } = await searchPrescriptionGroups({
      q, status, patientId, dateFrom, dateTo, page, limit,
      doctorId: doctor.id, // اجباری: هرگز از query گرفته نمی‌شود
    });
    return res.status(200).json({
      prescriptions: rows,
      pagination: { total, page: currentPage, limit: pageLimit, totalPages },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// GET /api/doctors/me/prescriptions/stats
export async function myPrescriptionStats(req, res) {
  try {
    const doctor = await requireOwnDoctor(req, res);
    if (!doctor) return;
    const stats = await getPrescriptionStats({ doctorId: doctor.id });
    return res.status(200).json({ stats });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

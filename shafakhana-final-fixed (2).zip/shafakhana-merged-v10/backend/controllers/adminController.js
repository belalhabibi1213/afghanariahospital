// کنترلرهای پنل ادمین — قبلاً یک فایل ۱۶۰۰ خطی بود؛ اکنون بر اساس حوزه در controllers/admin/ تقسیم شده
// و این فایل فقط آن‌ها را دوباره export می‌کند (routes و تست‌ها بدون تغییر کار می‌کنند).
export * from "./admin/patients.js";
export * from "./admin/doctors.js";
export * from "./admin/appointments.js";
export * from "./admin/departments.js";
export * from "./admin/schedules.js";
export * from "./admin/reports.js";
export * from "./admin/news.js";
export * from "./admin/comments.js";
export * from "./admin/contacts.js";

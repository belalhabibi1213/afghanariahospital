import path from "path";
import { getSiteContent, setSiteContent, deleteSiteContent } from "../models/SiteContent.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";
import { HERO_DIR } from "../middleware/upload.js";
import { removeUploadedFile } from "../utils/uploadStore.js";
import { sanitizeHeroInput } from "../utils/heroContent.js";

// ---------- بخش اصلی (Hero) صفحه‌ی اصلی — قابل‌ویرایش توسط ادمین ----------
// محتوا یک شیء JSON در جدول site_content (کلید «hero») است:
// { imageUrl, eyebrowVisible, eyebrow:{fa,ps,en}, titleBefore, titleAccent, titleAfter, lead,
//   primaryButton:{ text:{...}, link }, secondaryVisible, secondaryButton:{ text:{...}, link },
//   statsVisible, stats:[{ id, value:{...}, label:{...} }],
//   pulseVisible, pulse:[{ id, value:{...}, label:{...} }] }
// اگر ادمین هنوز چیزی ذخیره نکرده باشد (null)، سایت همان متن‌ها/عکس پیش‌فرض را نشان می‌دهد.
// متن‌ها می‌توانند {hospital} داشته باشند.
const KEY = "hero";
const IMAGE_PREFIX = "/uploads/hero/";
const audit = (req, action, oldValues, newValues) =>
  recordAudit({
    req, tableName: "site_content", recordId: KEY, action, oldValues, newValues,
    userId: req.user.id, userName: req.user.email, role: req.user.role,
  });
const log = (req, action, details) =>
  logActivity({ req, userId: req.user.id, userName: req.user.email, role: req.user.role, action, details });

// آدرس عکس فقط اگر واقعاً در پوشه‌ی hero باشد معتبر است
const safeImage = (url) => (typeof url === "string" && url.startsWith(IMAGE_PREFIX) ? url : "");

async function loadHero() {
  const stored = await getSiteContent(KEY);
  return stored ? { ...stored, imageUrl: safeImage(stored.imageUrl) } : null;
}

// عمومی (بدون ورود): GET /api/settings/hero
export async function getHeroPublic(req, res) {
  try {
    return res.status(200).json({ hero: await loadHero() });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function getHeroAdmin(req, res) {
  try {
    return res.status(200).json({ hero: await loadHero() });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function saveHero(req, res) {
  try {
    const previous = await loadHero();
    const { errors, value } = sanitizeHeroInput(req.body, previous?.imageUrl || "");
    if (errors.length) return res.status(400).json({ message: errors[0], errors });
    await setSiteContent(KEY, value);
    await log(req, "ویرایش بخش اصلی سایت (Hero)", `${value.stats.length} آمار، ${value.pulse.length} کارت`);
    await audit(req, previous ? "UPDATE" : "INSERT", previous, value);
    return res.status(200).json({ message: "بخش اصلی ذخیره شد", hero: value });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

function removeOldImage(url) {
  if (url && url.startsWith(IMAGE_PREFIX)) removeUploadedFile(path.join(HERO_DIR, path.basename(url)));
}

// عکس پس‌زمینه: اگر هنوز محتوای سفارشی ذخیره نشده، فقط آدرس عکس در یک رکورد جزئی نگه‌داری
// می‌شود و فرانت‌اند برای متن‌های خالی از پیش‌فرض استفاده می‌کند.
export async function uploadHeroImage(req, res) {
  try {
    if (!req.file) return res.status(400).json({ message: "هیچ فایلی ارسال نشده است" });
    const previous = (await getSiteContent(KEY)) || {};
    const imageUrl = `${IMAGE_PREFIX}${req.file.filename}`;
    await setSiteContent(KEY, { ...previous, imageUrl });
    removeOldImage(previous.imageUrl);
    await log(req, "تغییر عکس بخش اصلی سایت (Hero)", imageUrl);
    await audit(req, "UPDATE", { imageUrl: previous.imageUrl || null }, { imageUrl });
    return res.status(200).json({ message: "عکس ذخیره شد", imageUrl });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

export async function removeHeroImage(req, res) {
  try {
    const previous = await getSiteContent(KEY);
    if (!previous || !safeImage(previous.imageUrl)) {
      return res.status(404).json({ message: "عکسی برای حذف وجود ندارد" });
    }
    await setSiteContent(KEY, { ...previous, imageUrl: "" });
    removeOldImage(previous.imageUrl);
    await log(req, "حذف عکس بخش اصلی سایت (Hero)", previous.imageUrl);
    await audit(req, "UPDATE", { imageUrl: previous.imageUrl }, { imageUrl: null });
    return res.status(200).json({ message: "عکس حذف شد؛ عکس پیش‌فرض نمایش داده می‌شود" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

// بازگشت کامل به متن‌ها و عکس پیش‌فرض سایت
export async function resetHero(req, res) {
  try {
    const previous = await getSiteContent(KEY);
    if (previous) removeOldImage(previous.imageUrl);
    await deleteSiteContent(KEY);
    await log(req, "بازگرداندن بخش اصلی سایت (Hero) به حالت پیش‌فرض");
    await audit(req, "DELETE", previous, null);
    return res.status(200).json({ message: "بخش اصلی به حالت پیش‌فرض برگشت" });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: "خطای سرور در اتصال به دیتابیس" });
  }
}

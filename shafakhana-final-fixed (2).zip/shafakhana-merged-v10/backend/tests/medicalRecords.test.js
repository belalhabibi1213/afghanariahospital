import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";

import db from "../db.js";
import { findOrCreatePatient, doctorHasPatient, doctorHasConfirmedPatient } from "../models/Patient.js";
import { createLabResult, getLabResultById, getLabResultByIdForPatientUser, getLabResultsByPatientUser, updateLabResult, deleteLabResult } from "../models/LabResult.js";
import { createPrescription, getPrescriptionByIdForPatientUser, getPrescriptionsByPatientUser, deletePrescription, searchPrescriptionGroups } from "../models/Prescription.js";
import { createDiagnosis, getDiagnosisById, getDiagnosesByPatientUser, updateDiagnosis, deleteDiagnosis } from "../models/Diagnosis.js";
import { createAllergy, getAllergiesByPatientUser, updateAllergy, deleteAllergy } from "../models/Allergy.js";

after(closePool);

const stamp = Date.now();
let doctorSeq = 0; // شمارنده برای ساخت doctorCode کوتاه و یکتا
let userA; // بیمار الف (صاحب داده‌ها)
let userB; // بیمار ب (نباید به داده‌های الف دسترسی داشته باشد)
let patientA;
let patientB;
let doctor1; // داکتر دارای نوبت با الف
let doctor2; // داکتر بدون هیچ نوبتی

async function makeUser(label) {
  const [r] = await db.query(
    "INSERT INTO users (fullName, email, password, role) VALUES (?, ?, 'x', 'user')",
    [`کاربر ${label}`, `mr_${label}_${stamp}@test.local`]
  );
  return r.insertId;
}

async function makeDoctor(label) {
  const [r] = await db.query(
    "INSERT INTO doctors (doctorCode, fullName, department) VALUES (?, ?, 'تست')",
    [`M${String(stamp).slice(-6)}${++doctorSeq}`, `داکتر ${label}`]
  );
  return r.insertId;
}

async function addAppointment(patientId, doctorId, status, dayOffset) {
  const [r] = await db.query(
    "INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, status) VALUES (?, ?, 'تست', DATE_ADD(CURDATE(), INTERVAL ? DAY), '09:00:00', ?)",
    [patientId, doctorId, dayOffset, status]
  );
  return r.insertId;
}

before(async () => {
  userA = await makeUser("A");
  userB = await makeUser("B");
  patientA = (await findOrCreatePatient({ fullName: "بیمار الف", phone: "0700880001", userId: userA })).id;
  patientB = (await findOrCreatePatient({ fullName: "بیمار ب", phone: "0700880002", userId: userB })).id;
  doctor1 = await makeDoctor("1");
  doctor2 = await makeDoctor("2");
});

describe("دسترسی مبتنی بر رابطه‌ی داکتر↔بیمار", () => {
  test("داکتر بدون هیچ نوبتی با بیمار، رابطه‌ای ندارد", async () => {
    assert.equal(await doctorHasPatient(doctor2, patientA), false);
    assert.equal(await doctorHasConfirmedPatient(doctor2, patientA), false);
  });

  test("نوبت در انتظار تایید: doctorHasPatient درست است ولی doctorHasConfirmedPatient نادرست (رگرسیون باگ چت/تماس)", async () => {
    const dPending = await makeDoctor("pending");
    await addAppointment(patientA, dPending, "pending", 3);
    assert.equal(await doctorHasPatient(dPending, patientA), true, "دسترسی پرونده‌ی صحی با هر نوبتی برقرار است");
    assert.equal(await doctorHasConfirmedPatient(dPending, patientA), false, "چت/تماس نباید قبل از تایید مجاز باشد");
  });

  test("نوبت لغو یا ردشده رابطه‌ی چت/تماس ایجاد نمی‌کند", async () => {
    const dCancelled = await makeDoctor("cancelled");
    const dRejected = await makeDoctor("rejected");
    await addAppointment(patientA, dCancelled, "cancelled", 4);
    await addAppointment(patientA, dRejected, "rejected", 4);
    assert.equal(await doctorHasConfirmedPatient(dCancelled, patientA), false);
    assert.equal(await doctorHasConfirmedPatient(dRejected, patientA), false);
  });

  test("نوبت تاییدشده یا انجام‌شده رابطه‌ی معتبر ایجاد می‌کند", async () => {
    const dConfirmed = await makeDoctor("confirmed");
    const dCompleted = await makeDoctor("completed");
    await addAppointment(patientA, dConfirmed, "confirmed", 5);
    await addAppointment(patientA, dCompleted, "completed", -5);
    assert.equal(await doctorHasConfirmedPatient(dConfirmed, patientA), true);
    assert.equal(await doctorHasConfirmedPatient(dCompleted, patientA), true);
  });

  test("رابطه با یک بیمار، رابطه با بیمار دیگر نمی‌سازد", async () => {
    const d = await makeDoctor("isolation");
    await addAppointment(patientA, d, "confirmed", 6);
    assert.equal(await doctorHasConfirmedPatient(d, patientA), true);
    assert.equal(await doctorHasConfirmedPatient(d, patientB), false);
  });

  test("لغو نوبت تاییدشده، رابطه‌ی چت/تماس را فوراً از بین می‌برد", async () => {
    const d = await makeDoctor("revoke");
    const apptId = await addAppointment(patientA, d, "confirmed", 7);
    assert.equal(await doctorHasConfirmedPatient(d, patientA), true);
    await db.query("UPDATE appointments SET status = 'cancelled' WHERE id = ?", [apptId]);
    assert.equal(await doctorHasConfirmedPatient(d, patientA), false);
  });
});

describe("نتایج آزمایش (LabResult) و جلوگیری از IDOR", () => {
  let labId;

  before(async () => {
    const r = await createLabResult({
      patientId: patientA, doctorId: doctor1, testName: "قند خون", result: "95", unit: "mg/dL",
      referenceRange: "70-100", status: "completed", testDate: "2027-01-05",
    });
    labId = r.id;
  });

  test("مالک آزمایش می‌تواند آن را با شناسه ببیند", async () => {
    const found = await getLabResultByIdForPatientUser(labId, userA);
    assert.ok(found);
    assert.equal(found.testName, "قند خون");
  });

  test("بیمار دیگر با همان شناسه چیزی نمی‌بیند (IDOR)", async () => {
    const found = await getLabResultByIdForPatientUser(labId, userB);
    assert.ok(!found, "بیمار ب نباید آزمایش بیمار الف را ببیند");
  });

  test("فهرست آزمایش‌های هر کاربر فقط مال خودش است", async () => {
    const listA = await getLabResultsByPatientUser(userA);
    const listB = await getLabResultsByPatientUser(userB);
    assert.ok(listA.some((l) => l.id === labId));
    assert.ok(!listB.some((l) => l.id === labId));
  });

  test("ویرایش و حذف کار می‌کند", async () => {
    await updateLabResult(labId, { testName: "قند خون ناشتا", result: "90", unit: "mg/dL", referenceRange: "70-100", status: "completed", testDate: "2027-01-05" });
    const updated = await getLabResultById(labId);
    assert.equal(updated.testName, "قند خون ناشتا");
    await deleteLabResult(labId);
    assert.ok(!(await getLabResultById(labId)));
  });
});

describe("نسخه (Prescription) و جلوگیری از IDOR", () => {
  let rxId;

  before(async () => {
    const r = await createPrescription({
      patientId: patientA, doctorId: doctor1, diagnosis: "سرماخوردگی", medicationName: "پاراستامول",
      dosage: "500mg", frequency: "هر ۸ ساعت", duration: "۵ روز", instructions: "بعد از غذا",
    });
    rxId = r.id;
  });

  test("مالک نسخه می‌تواند آن را ببیند", async () => {
    const found = await getPrescriptionByIdForPatientUser(rxId, userA);
    assert.ok(found);
    assert.equal(found.medicationName, "پاراستامول");
  });

  test("بیمار دیگر نسخه را نمی‌بیند (IDOR)", async () => {
    const found = await getPrescriptionByIdForPatientUser(rxId, userB);
    assert.ok(!found);
  });

  test("فهرست گروه‌بندی‌شده با patientUserId فقط نسخه‌های همان کاربر را برمی‌گرداند (پنل بیمار)", async () => {
    const mine = await searchPrescriptionGroups({ patientUserId: userA });
    assert.ok(mine.rows.some((g) => g.id === rxId));
    const others = await searchPrescriptionGroups({ patientUserId: userB });
    assert.ok(!others.rows.some((g) => g.id === rxId));
    // کاربری که هیچ بیماری ندارد (شناسه‌ی ناموجود) هرگز «همه‌ی نسخه‌ها» را نمی‌گیرد
    const none = await searchPrescriptionGroups({ patientUserId: 987654321 });
    assert.equal(none.total, 0);
  });

  test("فهرست نسخه‌ها فقط مال خود کاربر است و حذف کار می‌کند", async () => {
    assert.ok((await getPrescriptionsByPatientUser(userA)).some((p) => p.id === rxId));
    assert.ok(!(await getPrescriptionsByPatientUser(userB)).some((p) => p.id === rxId));
    await deletePrescription(rxId);
    assert.ok(!(await getPrescriptionByIdForPatientUser(rxId, userA)));
  });
});

describe("تشخیص (Diagnosis) و حساسیت (Allergy)", () => {
  test("ساخت، ویرایش و حذف تشخیص", async () => {
    const d = await createDiagnosis({ patientId: patientA, doctorId: doctor1, title: "فشار خون بالا", description: "تست", icdCode: "I10", status: "active" });
    assert.ok(d.id);
    await updateDiagnosis(d.id, { title: "فشار خون بالا (کنترل‌شده)", description: "تست", icdCode: "I10", status: "active" });
    assert.equal((await getDiagnosisById(d.id)).title, "فشار خون بالا (کنترل‌شده)");
    assert.ok((await getDiagnosesByPatientUser(userA)).some((x) => x.id === d.id));
    assert.ok(!(await getDiagnosesByPatientUser(userB)).some((x) => x.id === d.id), "تشخیص بیمار الف نباید برای ب دیده شود");
    await deleteDiagnosis(d.id);
    assert.ok(!(await getDiagnosisById(d.id)));
  });

  test("ساخت، ویرایش و حذف حساسیت + جداسازی بین بیماران", async () => {
    const a = await createAllergy({ patientId: patientA, doctorId: doctor1, allergen: "پنی‌سیلین", reaction: "کهیر", severity: "severe", notes: "تست" });
    assert.ok(a.id);
    assert.ok((await getAllergiesByPatientUser(userA)).some((x) => x.id === a.id));
    assert.ok(!(await getAllergiesByPatientUser(userB)).some((x) => x.id === a.id));
    await updateAllergy(a.id, { allergen: "پنی‌سیلین", reaction: "کهیر شدید", severity: "severe", notes: "تست" });
    const [[row]] = await db.query("SELECT reaction FROM allergies WHERE id = ?", [a.id]);
    assert.equal(row.reaction, "کهیر شدید");
    await deleteAllergy(a.id);
    const [[cnt]] = await db.query("SELECT COUNT(*) AS c FROM allergies WHERE id = ?", [a.id]);
    assert.equal(cnt.c, 0);
  });
});

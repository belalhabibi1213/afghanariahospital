import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";

import db from "../db.js";
import { createInvoice, getInvoiceById, cancelInvoice, approveInvoice, deleteInvoiceCascade } from "../models/Invoice.js";
import { recordPayment } from "../models/Payment.js";
import { findOrCreatePatient } from "../models/Patient.js";

after(closePool);

let patientId;

before(async () => {
  const p = await findOrCreatePatient({ fullName: "بیمار تست صورت‌حساب", phone: "0700990001" });
  patientId = p.id;
});

// ساخت یک فاکتور ساده با مبلغ کل مشخص (یک ردیف)
async function makeInvoice({ unitPrice = 1000, quantity = 1, discount = 0, tax = 0 } = {}) {
  return createInvoice({
    patientId,
    issueDate: "2027-01-01",
    discount,
    tax,
    items: [{ description: "خدمت تست", quantity, unitPrice }],
  });
}

describe("صدور فاکتور (createInvoice)", () => {
  test("جمع کل = جمع ردیف‌ها − تخفیف + مالیات", async () => {
    const inv = await makeInvoice({ unitPrice: 500, quantity: 3, discount: 100, tax: 50 });
    assert.equal(Number(inv.subtotal), 1500);
    assert.equal(Number(inv.totalAmount), 1450);
    assert.equal(inv.status, "unpaid");
    assert.equal(Number(inv.paidAmount), 0);
  });

  test("خطای ممیز شناور در مبلغ‌های اعشاری رخ نمی‌دهد (۰.۱ × ۳)", async () => {
    const inv = await makeInvoice({ unitPrice: 0.1, quantity: 3 });
    assert.equal(Number(inv.totalAmount), 0.3);
  });

  test("تخفیف بیشتر از مجموع، مبلغ کل را منفی نمی‌کند", async () => {
    const inv = await makeInvoice({ unitPrice: 100, quantity: 1, discount: 500 });
    assert.equal(Number(inv.totalAmount), 0);
  });

  test("شماره‌ی فاکتور یکتا و با فرمت INV-xxxxxx است", async () => {
    const a = await makeInvoice();
    const b = await makeInvoice();
    assert.match(a.invoiceNumber, /^INV-\d{6}$/);
    assert.notEqual(a.invoiceNumber, b.invoiceNumber);
  });
});

describe("ثبت پرداخت (recordPayment)", () => {
  test("پرداخت جزئی → partial و سپس پرداخت باقیمانده → paid", async () => {
    const inv = await makeInvoice({ unitPrice: 1000 });

    const r1 = await recordPayment(inv.id, { amount: 400, method: "cash" });
    assert.equal(r1.status, "partial");
    assert.equal(r1.paidAmount, 400);

    const r2 = await recordPayment(inv.id, { amount: 600, method: "card" });
    assert.equal(r2.status, "paid");
    assert.equal(r2.paidAmount, 1000);

    const after = await getInvoiceById(inv.id);
    assert.equal(after.status, "paid");
    assert.equal(Number(after.paidAmount), 1000);
  });

  test("پرداخت بیشتر از باقیمانده رد می‌شود و چیزی ثبت نمی‌شود (OVERPAYMENT)", async () => {
    const inv = await makeInvoice({ unitPrice: 1000 });
    await recordPayment(inv.id, { amount: 700 });

    const over = await recordPayment(inv.id, { amount: 400 });
    assert.equal(over.error, "OVERPAYMENT");
    assert.equal(over.remaining, 300);

    const [[{ cnt }]] = await db.query("SELECT COUNT(*) AS cnt FROM payments WHERE invoiceId = ?", [inv.id]);
    assert.equal(cnt, 1, "پرداخت ردشده نباید در جدول payments ثبت شود");
    const after = await getInvoiceById(inv.id);
    assert.equal(Number(after.paidAmount), 700);
  });

  test("پرداخت روی فاکتور لغوشده رد می‌شود (INVOICE_CANCELLED)", async () => {
    const inv = await makeInvoice();
    await cancelInvoice(inv.id);
    const r = await recordPayment(inv.id, { amount: 100 });
    assert.equal(r.error, "INVOICE_CANCELLED");
  });

  test("پرداخت روی فاکتور ناموجود NOT_FOUND می‌دهد", async () => {
    const r = await recordPayment(99999999, { amount: 100 });
    assert.equal(r.error, "NOT_FOUND");
  });

  test("پرداخت‌های هم‌زمان هرگز مجموع را از مبلغ کل بیشتر نمی‌کنند (Race Condition)", async () => {
    const inv = await makeInvoice({ unitPrice: 1000 });

    // ۶ پرداخت هم‌زمان ۳۰۰تایی؛ مجموعاً فقط ۳ تای آن‌ها (۹۰۰) جا دارد، چهارمی (۱۲۰۰) رد می‌شود
    const results = await Promise.all(
      Array.from({ length: 6 }, () => recordPayment(inv.id, { amount: 300 }))
    );
    const ok = results.filter((r) => r.paymentId).length;
    const rejected = results.filter((r) => r.error === "OVERPAYMENT").length;
    assert.equal(ok, 3, "دقیقاً ۳ پرداخت ۳۰۰تایی باید جا شود");
    assert.equal(rejected, 3);

    const after = await getInvoiceById(inv.id);
    assert.ok(Number(after.paidAmount) <= Number(after.totalAmount), "مبلغ پرداخت‌شده نباید از کل بیشتر شود");
    assert.equal(Number(after.paidAmount), 900);
  });
});

describe("تایید و لغو فاکتور", () => {
  test("تایید فاکتور، مبلغ پرداخت‌شده را برابر کل و وضعیت را paid می‌کند", async () => {
    const inv = await makeInvoice({ unitPrice: 2500 });
    const approved = await approveInvoice(inv.id, null);
    assert.equal(approved.approvalStatus, "approved");
    assert.equal(approved.status, "paid");
    assert.equal(Number(approved.paidAmount), 2500);
    assert.ok(approved.approvedAt);
  });

  test("تایید فاکتور یک ردیف پرداخت برای باقی‌مانده می‌سازد تا در گزارش درآمد دیده شود", async () => {
    const inv = await makeInvoice({ unitPrice: 1200 });
    const approved = await approveInvoice(inv.id, null);
    const detail = await getInvoiceById(approved.id);
    const sum = detail.payments.reduce((acc, pay) => acc + Number(pay.amount), 0);
    assert.equal(detail.payments.length, 1);
    assert.equal(sum, Number(approved.totalAmount));
  });

  test("تایید فاکتور ناموجود null برمی‌گرداند", async () => {
    const r = await approveInvoice(99999999, null);
    assert.equal(r, null);
  });

  test("لغو فاکتور وضعیت را cancelled می‌کند", async () => {
    const inv = await makeInvoice();
    const c = await cancelInvoice(inv.id);
    assert.equal(c.status, "cancelled");
  });
});

describe("حذف کامل فاکتور (deleteInvoiceCascade)", () => {
  test("ردیف‌ها، پرداخت‌ها و اعلان‌های مرتبط هم پاک می‌شوند و رکورد یتیم نمی‌ماند", async () => {
    const inv = await makeInvoice({ unitPrice: 800 });
    await recordPayment(inv.id, { amount: 200 });
    await db.query(
      "INSERT INTO notifications (userId, type, title, message, relatedId) SELECT id, 'billing', 'تست', 'تست', ? FROM users LIMIT 1",
      [inv.id]
    ).catch(() => {});

    const deleted = await deleteInvoiceCascade(inv.id);
    assert.equal(deleted, true);

    const [[items]] = await db.query("SELECT COUNT(*) AS c FROM invoice_items WHERE invoiceId = ?", [inv.id]);
    const [[pays]] = await db.query("SELECT COUNT(*) AS c FROM payments WHERE invoiceId = ?", [inv.id]);
    const [[notifs]] = await db.query("SELECT COUNT(*) AS c FROM notifications WHERE type = 'billing' AND relatedId = ?", [inv.id]);
    assert.equal(items.c, 0);
    assert.equal(pays.c, 0);
    assert.equal(notifs.c, 0);
    assert.equal(await getInvoiceById(inv.id), null);
  });

  test("حذف فاکتور ناموجود false برمی‌گرداند", async () => {
    assert.equal(await deleteInvoiceCascade(99999999), false);
  });
});

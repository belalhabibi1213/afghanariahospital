import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, createTestUser, loginAs, DEFAULT_PASSWORD } from "./testApp.js";
import db from "../db.js";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "../utils/env.js";
import { totpAt, decryptSecret } from "../utils/totp.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// ثبت‌نام MFA برای یک کاربر؛ راز و کدهای بازیابی را برمی‌گرداند
async function enrollMfa(user) {
  const token = await loginAs(user);
  const setup = await api("POST", "/api/auth/mfa/setup", { token });
  assert.equal(setup.status, 200, JSON.stringify(setup.body));
  assert.match(setup.body.secret, /^[A-Z2-7]{32}$/);
  const enable = await api("POST", "/api/auth/mfa/enable", { token, body: { code: totpAt(setup.body.secret) } });
  assert.equal(enable.status, 200, JSON.stringify(enable.body));
  assert.equal(enable.body.recoveryCodes.length, 8);
  return { secret: setup.body.secret, recoveryCodes: enable.body.recoveryCodes };
}

describe("MFA: فعال‌سازی", () => {
  test("راز در دیتابیس رمزنگاری‌شده است و کد اشتباه فعال‌سازی را رد می‌کند", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    const setup = await api("POST", "/api/auth/mfa/setup", { token });
    const [[row]] = await db.query("SELECT mfaPendingSecretEnc, mfaEnabled FROM users WHERE id = ?", [u.id]);
    assert.equal(row.mfaEnabled, 0);
    assert.ok(!row.mfaPendingSecretEnc.includes(setup.body.secret), "راز نباید خام ذخیره شود");
    assert.equal(decryptSecret(row.mfaPendingSecretEnc), setup.body.secret);
    const bad = await api("POST", "/api/auth/mfa/enable", { token, body: { code: "000000" } });
    assert.equal(bad.status, 400);
  });

  test("کدهای بازیابی فقط به‌صورت هش ذخیره می‌شوند", async () => {
    const u = await createTestUser();
    const { recoveryCodes } = await enrollMfa(u);
    const [[row]] = await db.query("SELECT mfaRecoveryHashes FROM users WHERE id = ?", [u.id]);
    for (const c of recoveryCodes) assert.ok(!row.mfaRecoveryHashes.includes(c.replace("-", "")));
  });
});

describe("MFA: ورود دومرحله‌ای", () => {
  test("بعد از رمز درست نشست صادر نمی‌شود؛ با کد درست صادر می‌شود", async () => {
    const u = await createTestUser();
    const { secret } = await enrollMfa(u);
    const step1 = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
    assert.equal(step1.status, 200);
    assert.equal(step1.body.mfaRequired, true);
    assert.ok(!(step1.headers.get("set-cookie") || "").includes("shafakhana_token"), "پیش از MFA نباید کوکی نشست داده شود");
    assert.equal(step1.body.user, undefined);

    const wrong = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: step1.body.mfaToken, code: "000000" } });
    assert.equal(wrong.status, 401);

    const ok = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: step1.body.mfaToken, code: totpAt(secret, Date.now() + 30_000) } }); // گام بعدی: گام فعال‌سازی مصرف شده و replay رد می‌شود
    assert.equal(ok.status, 200, JSON.stringify(ok.body));
    assert.ok((ok.headers.get("set-cookie") || "").includes("shafakhana_token"));
    assert.equal(ok.body.user.mfaEnabled, true);
  });

  test("mfaToken را نمی‌توان به‌جای توکن نشست استفاده کرد (دور زدن MFA)", async () => {
    const u = await createTestUser();
    await enrollMfa(u);
    const step1 = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
    const asBearer = await api("GET", "/api/auth/me", { token: step1.body.mfaToken });
    assert.equal(asBearer.status, 401);
    // توکنی که با کلید نشست امضا شده و purpose=mfa دارد هم برای verify پذیرفته نیست
    const forged = jwt.sign({ id: u.id, purpose: "mfa" }, JWT_SECRET, { expiresIn: "5m" });
    const res = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: forged, code: "123456" } });
    assert.equal(res.status, 401);
  });

  test("یک کد TOTP دوبار قابل استفاده نیست (replay)", async () => {
    const u = await createTestUser();
    const { secret } = await enrollMfa(u);
    // کدِ گامِ مصرف‌شده‌ی فعال‌سازی هم نباید پذیرفته شود
    const login = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
    const replay = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: login.body.mfaToken, code: totpAt(secret) } });
    assert.equal(replay.status, 401, "کد گام مصرف‌شده باید رد شود");
  });

  test("کد بازیابی یک‌بار کار می‌کند", async () => {
    const u = await createTestUser();
    const { recoveryCodes } = await enrollMfa(u);
    const l1 = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
    const r1 = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: l1.body.mfaToken, code: recoveryCodes[0] } });
    assert.equal(r1.status, 200, JSON.stringify(r1.body));
    const l2 = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
    const r2 = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: l2.body.mfaToken, code: recoveryCodes[0] } });
    assert.equal(r2.status, 401);
  });

  test("حدس‌های اشتباه پیاپی حساب را قفل می‌کنند", async () => {
    const u = await createTestUser();
    await enrollMfa(u);
    let last;
    for (let i = 0; i < 7; i++) {
      const l = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
      if (l.status === 423) { last = l; break; }
      last = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: l.body.mfaToken, code: "000000" } });
      if (last.status === 423) break;
    }
    assert.equal(last.status, 423);
  });

  test("توکن منقضی رد می‌شود", async () => {
    const res = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: "x.y.z", code: "123456" } });
    assert.equal(res.status, 401);
  });
});

describe("MFA: الزام برای نقش‌ها و غیرفعال‌سازی", () => {
  test("غیرفعال‌سازی نیازمند رمز و کد درست است", async () => {
    const u = await createTestUser();
    const { recoveryCodes } = await enrollMfa(u);
    const l = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
    const v = await api("POST", "/api/auth/mfa/verify", { body: { mfaToken: l.body.mfaToken, code: recoveryCodes[0] } });
    assert.equal(v.status, 200, JSON.stringify(v.body));
    const token = v.headers.get("set-cookie").match(/shafakhana_token=([^;]+)/)[1];

    const badPass = await api("POST", "/api/auth/mfa/disable", { token, body: { password: "Bad12345", code: recoveryCodes[1] } });
    assert.equal(badPass.status, 401);
    const badCode = await api("POST", "/api/auth/mfa/disable", { token, body: { password: DEFAULT_PASSWORD, code: "ZZZZZ-ZZZZZ" } });
    assert.equal(badCode.status, 401);
    const ok = await api("POST", "/api/auth/mfa/disable", { token, body: { password: DEFAULT_PASSWORD, code: recoveryCodes[1] } });
    assert.equal(ok.status, 200, JSON.stringify(ok.body));
    const [[row]] = await db.query("SELECT mfaEnabled, mfaSecretEnc FROM users WHERE id = ?", [u.id]);
    assert.equal(row.mfaEnabled, 0);
    assert.equal(row.mfaSecretEnc, null);
  });

  test("MFA_REQUIRED_ROLES: ادمین بدون MFA فقط به مسیرهای راه‌اندازی دسترسی دارد", async () => {
    // روی نمونه‌ی فعلی env پیش‌فرض (تست) نقش اجباری ندارد؛ این تست رفتار middleware را مستقیم می‌سنجد
    const { MFA_REQUIRED_ROLES } = await import("../utils/env.js");
    if (!MFA_REQUIRED_ROLES.has("admin")) {
      return; // با MFA_REQUIRED_ROLES=admin,superadmin اجرا شود (CI مرحله‌ی امنیتی)
    }
    const admin = await createTestUser({ role: "admin" });
    const token = await loginAs(admin);
    const blocked = await api("GET", "/api/admin/patients", { token });
    assert.equal(blocked.status, 403);
    assert.equal(blocked.body.code, "MFA_SETUP_REQUIRED");
    const me = await api("GET", "/api/auth/me", { token });
    assert.equal(me.status, 200);
    assert.equal(me.body.user.mfaSetupRequired, true);
  });
});

// تست محافظت CSRF — بدون نیاز به دیتابیس: فقط middleware/csrf.js و utils/authCookies.js
// روی یک اپ کوچک Express بررسی می‌شوند.
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import "./testEnv.js";
import express from "express";
import http from "http";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "../utils/env.js";
import { csrfProtection } from "../middleware/csrf.js";
import { csrfTokenFor, parseCookies, AUTH_COOKIE_NAME } from "../utils/authCookies.js";

let server;
let base;
const payload = { id: 7, email: "a@b.c", role: "user", jti: "session-1" };
const goodJwt = () => jwt.sign(payload, JWT_SECRET, { expiresIn: "1h" });

before(async () => {
  const app = express();
  app.use(express.json());
  app.use("/api", csrfProtection);
  app.all("/api/anything", (req, res) => res.json({ ok: true }));
  app.post("/api/auth/login", (req, res) => res.json({ ok: true }));
  server = http.createServer(app);
  await new Promise((r) => server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => new Promise((r) => server.close(r)));

const call = (method, path, headers = {}) => fetch(base + path, { method, headers: { "Content-Type": "application/json", ...headers }, body: method === "GET" ? undefined : "{}" });
const cookie = (t = goodJwt()) => ({ Cookie: `${AUTH_COOKIE_NAME}=${encodeURIComponent(t)}` });

describe("CSRF", () => {
  test("POST با کوکی نشست و بدون توکن CSRF رد می‌شود (۴۰۳ CSRF_INVALID)", async () => {
    const res = await call("POST", "/api/anything", cookie());
    assert.equal(res.status, 403);
    assert.equal((await res.json()).code, "CSRF_INVALID");
  });

  test("توکن CSRF اشتباه یا مال نشست دیگر رد می‌شود", async () => {
    const other = csrfTokenFor({ ...payload, jti: "another-session" });
    assert.equal((await call("POST", "/api/anything", { ...cookie(), "X-CSRF-Token": other })).status, 403);
    assert.equal((await call("POST", "/api/anything", { ...cookie(), "X-CSRF-Token": "x" })).status, 403);
  });

  test("توکن CSRF درست عبور می‌کند؛ PUT/PATCH/DELETE هم همین‌طور محافظت می‌شوند", async () => {
    const h = { ...cookie(), "X-CSRF-Token": csrfTokenFor(payload) };
    for (const m of ["POST", "PUT", "PATCH", "DELETE"]) {
      assert.equal((await call(m, "/api/anything", h)).status, 200, m);
      assert.equal((await call(m, "/api/anything", cookie())).status, 403, `${m} بدون توکن`);
    }
  });

  test("GET نیازی به توکن CSRF ندارد", async () => {
    assert.equal((await call("GET", "/api/anything", cookie())).status, 200);
  });

  test("هدر Authorization (کلاینت API) مشمول CSRF نیست", async () => {
    assert.equal((await call("POST", "/api/anything", { Authorization: `Bearer ${goodJwt()}` })).status, 200);
  });

  test("مهمان و کوکی نامعتبر عبور می‌کنند (رد‌کردنشان با requireAuth است)", async () => {
    assert.equal((await call("POST", "/api/anything")).status, 200);
    assert.equal((await call("POST", "/api/anything", cookie("not.a.jwt"))).status, 200);
  });

  test("مسیر ورود معاف است", async () => {
    assert.equal((await call("POST", "/api/auth/login", cookie())).status, 200);
  });
});

describe("parseCookies", () => {
  test("چند کوکی و مقدار URL-encode را درست می‌خواند", () => {
    const c = parseCookies(`a=1; ${AUTH_COOKIE_NAME}=${encodeURIComponent("x.y.z")}; b="q"`);
    assert.deepEqual(c, { a: "1", [AUTH_COOKIE_NAME]: "x.y.z", b: "q" });
  });
  test("ورودی خالی/نامعتبر خطا نمی‌دهد", () => {
    assert.deepEqual(parseCookies(undefined), {});
    assert.deepEqual(parseCookies("bad"), {});
  });
});

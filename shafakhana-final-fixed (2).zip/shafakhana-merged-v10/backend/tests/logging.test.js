import { test, describe, beforeEach } from "node:test";
import assert from "node:assert/strict";
process.env.LOG_FORMAT = "json";
const { logger, redact, _setWriterForTests } = await import("../utils/logger.js");
const { recordAccess, _resetAccessMonitorForTests } = await import("../utils/accessMonitor.js");
const { requestLogger } = await import("../middleware/requestLogger.js");

describe("لاگ ساخت‌یافته", () => {
  test("خروجی JSON، child bindings و redact فیلدهای حساس", () => {
    const lines = [];
    _setWriterForTests((l) => lines.push(JSON.parse(l)));
    logger.child({ reqId: "r1" }).info({ password: "p@ss", user: { token: "t", name: "x" }, code: "123456" }, "ورود");
    logger.error({ err: new Error("boom") }, "خطا");
    assert.equal(lines[0].msg, "ورود");
    assert.equal(lines[0].reqId, "r1");
    assert.equal(lines[0].password, "[REDACTED]");
    assert.equal(lines[0].user.token, "[REDACTED]");
    assert.equal(lines[0].user.name, "x");
    assert.equal(lines[0].code, "[REDACTED]");
    assert.equal(lines[1].level, "error");
    assert.equal(lines[1].err.message, "boom");
  });

  test("redact روی آرایه/تو در تو", () => {
    assert.deepEqual(redact({ a: [{ authorization: "Bearer x", ok: 1 }] }), { a: [{ authorization: "[REDACTED]", ok: 1 }] });
  });
});

describe("requestLogger", () => {
  const fakeRes = () => { const h = {}; return { h, statusCode: 200, setHeader: (k, v) => (h[k] = v), on() {} }; };
  test("شناسه‌ی امن کلاینت پذیرفته و شناسه‌ی مخرب جایگزین می‌شود", () => {
    const mk = (id) => ({ get: () => id, path: "/api/x", headers: {} });
    let req = mk("abc12345-good"), res = fakeRes();
    requestLogger(req, res, () => {});
    assert.equal(req.id, "abc12345-good");
    assert.equal(res.h["X-Request-Id"], "abc12345-good");
    req = mk("bad\nid{inject}"); res = fakeRes();
    requestLogger(req, res, () => {});
    assert.notEqual(req.id, "bad\nid{inject}");
    assert.match(req.id, /^[0-9a-f-]{36}$/);
  });
});

describe("پایش دسترسی غیرعادی به پرونده‌ها", () => {
  beforeEach(_resetAccessMonitorForTests);
  const cfg = { threshold: 5, windowMs: 60_000, cooldownMs: 600_000 };

  test("هشدار فقط وقتی بیماران «متمایز» به سقف برسند؛ تکرار یک بیمار هشدار نمی‌دهد", () => {
    for (let i = 0; i < 20; i++) assert.equal(recordAccess(1, 7, 1000 + i, cfg), false);
    let alerted = false;
    for (let p = 1; p <= 5; p++) alerted = recordAccess(2, p, 1000 + p, cfg);
    assert.equal(alerted, true);
  });

  test("خنک‌سازی: هشدار تکراری ندارد و خارج از پنجره شمارش از نو شروع می‌شود", () => {
    for (let p = 1; p <= 5; p++) recordAccess(3, p, 1000 + p, cfg);
    assert.equal(recordAccess(3, 6, 2000, cfg), false);
    assert.equal(recordAccess(3, 7, 2001, cfg), false);
    _resetAccessMonitorForTests();
    for (let p = 1; p <= 4; p++) recordAccess(4, p, 1000, cfg);
    assert.equal(recordAccess(4, 5, 1000 + 61_000, cfg), false); // بقیه از پنجره بیرون رفته‌اند
  });
});

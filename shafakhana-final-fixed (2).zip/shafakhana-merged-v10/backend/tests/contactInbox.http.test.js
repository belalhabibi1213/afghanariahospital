import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession } from "./testApp.js";
import db from "../db.js";

// صندوق پیام‌های «تماس با ما» (ادمین): صفحه‌بندی/جستجو/فیلتر سمت سرور، پرچم‌ها، عملیات گروهی، RBAC
let admin;
let user;
const TAG = `inbox${Date.now()}`;

async function seed(n) {
  const types = ["suggestion", "criticism", "complaint", "question", "other"];
  for (let i = 0; i < n; i += 1) {
    await db.query(
      "INSERT INTO contacts (fullName, phone, email, subject, type, message, createdAt) VALUES (?, ?, ?, ?, ?, ?, ?)",
      [`${TAG} فرستنده ${i}`, `0799${String(i).padStart(6, "0")}`, `s${i}@${TAG}.test`, i % 2 ? `موضوع ${i}` : null, types[i % 5],
        `متن پیام شماره ${i} ${"x".repeat(300)} ${i === 7 ? "کلیدواژه‌یکتا" : ""}`, `2026-09-${String(1 + (i % 28)).padStart(2, "0")} 10:00:00`]
    );
  }
}

before(async () => {
  await startServer();
  admin = await makeSession("admin");
  user = await makeSession("user");
  await db.query("DELETE FROM contacts");
  await seed(45);
});
after(async () => {
  await db.query("DELETE FROM contacts");
  await stopServer();
  await closePool();
});

describe("GET /api/admin/contacts — صفحه‌بندی و فیلتر سمت سرور", () => {
  test("پیش‌فرض ۲۰ ردیف + pagination + preview کوتاه (بدون متن کامل)", async () => {
    const r = await api("GET", "/api/admin/contacts", { token: admin.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.messages.length, 20);
    assert.deepEqual(r.body.pagination, { page: 1, limit: 20, total: 45, totalPages: 3 });
    assert.ok(r.body.messages[0].preview.length <= 140);
    assert.equal(r.body.messages[0].message, undefined);
    assert.equal(typeof r.body.messages[0].isImportant, "boolean");
  });
  test("صفحه‌ی آخر ۵ ردیف دارد و صفحه‌ها تکراری نیستند", async () => {
    const p1 = await api("GET", "/api/admin/contacts?page=1", { token: admin.token });
    const p3 = await api("GET", "/api/admin/contacts?page=3", { token: admin.token });
    assert.equal(p3.body.messages.length, 5);
    const ids1 = new Set(p1.body.messages.map((m) => m.id));
    assert.ok(p3.body.messages.every((m) => !ids1.has(m.id)));
  });
  test("limit سقف ۱۰۰ دارد", async () => {
    const r = await api("GET", "/api/admin/contacts?limit=5000", { token: admin.token });
    assert.equal(r.body.pagination.limit, 100);
  });
  test("جستجو در متن پیام، ایمیل، تلفن و موضوع", async () => {
    const byText = await api("GET", `/api/admin/contacts?q=${encodeURIComponent("کلیدواژه‌یکتا")}`, { token: admin.token });
    assert.equal(byText.body.pagination.total, 1);
    const byEmail = await api("GET", `/api/admin/contacts?q=s12@${TAG}.test`, { token: admin.token });
    assert.equal(byEmail.body.pagination.total, 1);
    const byPhone = await api("GET", "/api/admin/contacts?q=0799000003", { token: admin.token });
    assert.equal(byPhone.body.pagination.total, 1);
    const bySubject = await api("GET", `/api/admin/contacts?q=${encodeURIComponent("موضوع 9")}`, { token: admin.token });
    assert.equal(bySubject.body.pagination.total, 1);
  });
  test("فیلتر نوع و ترکیب با صفحه‌بندی", async () => {
    const r = await api("GET", "/api/admin/contacts?type=complaint", { token: admin.token });
    assert.equal(r.body.pagination.total, 9);
    assert.ok(r.body.messages.every((m) => m.type === "complaint"));
  });
  test("فیلتر بازه‌ی تاریخ (شامل روز پایانی)", async () => {
    const r = await api("GET", "/api/admin/contacts?dateFrom=2026-09-05&dateTo=2026-09-05", { token: admin.token });
    assert.ok(r.body.pagination.total > 0);
    assert.ok(r.body.messages.every((m) => new Date(m.createdAt).getDate() === 5));
  });
  test("مقادیر نامعتبر ۴۰۰ می‌دهند", async () => {
    assert.equal((await api("GET", "/api/admin/contacts?status=bogus", { token: admin.token })).status, 400);
    assert.equal((await api("GET", "/api/admin/contacts?type=bogus", { token: admin.token })).status, 400);
  });
  test("تزریق SQL در q بی‌اثر است", async () => {
    const r = await api("GET", `/api/admin/contacts?q=${encodeURIComponent("' OR 1=1 --")}`, { token: admin.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.pagination.total, 0);
  });
});

describe("آمار، مشاهده، پرچم‌ها", () => {
  test("آمار از دیتابیس واقعی است", async () => {
    const r = await api("GET", "/api/admin/contacts/stats", { token: admin.token });
    assert.deepEqual(r.body.stats, { total: 45, unread: 45, read: 0, important: 0, answered: 0 });
  });
  test("مشاهده پیام را خوانده می‌کند و متن کامل برمی‌گرداند", async () => {
    const list = await api("GET", "/api/admin/contacts?limit=1", { token: admin.token });
    const id = list.body.messages[0].id;
    const r = await api("GET", `/api/admin/contacts/${id}`, { token: admin.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.contact.status, "read");
    assert.ok(r.body.contact.message.length > 300);
  });
  test("پرچم مهم/پاسخ‌داده‌شده + اعتبارسنجی", async () => {
    const id = (await api("GET", "/api/admin/contacts?limit=1", { token: admin.token })).body.messages[0].id;
    const r = await api("PUT", `/api/admin/contacts/${id}/flags`, { token: admin.token, body: { isImportant: true, isAnswered: true } });
    assert.equal(r.status, 200);
    assert.equal(r.body.contact.isImportant, true);
    assert.equal(r.body.contact.isAnswered, true);
    assert.equal((await api("PUT", `/api/admin/contacts/${id}/flags`, { token: admin.token, body: {} })).status, 400);
    assert.equal((await api("PUT", `/api/admin/contacts/${id}/flags`, { token: admin.token, body: { isImportant: "yes" } })).status, 400);
    assert.equal((await api("PUT", "/api/admin/contacts/999999/flags", { token: admin.token, body: { isImportant: true } })).status, 404);
    const imp = await api("GET", "/api/admin/contacts?status=important", { token: admin.token });
    assert.equal(imp.body.pagination.total, 1);
    const ans = await api("GET", "/api/admin/contacts?status=answered", { token: admin.token });
    assert.equal(ans.body.pagination.total, 1);
  });
  test("وضعیت دستی read/unread همچنان کار می‌کند (API قدیمی)", async () => {
    const id = (await api("GET", "/api/admin/contacts?limit=1", { token: admin.token })).body.messages[0].id;
    const r = await api("PUT", `/api/admin/contacts/${id}/status`, { token: admin.token, body: { status: "unread" } });
    assert.equal(r.status, 200);
    assert.equal(r.body.contact.status, "unread");
  });
});

describe("عملیات گروهی", () => {
  test("خوانده‌شده/مهم/برداشتن مهم روی چند پیام", async () => {
    const ids = (await api("GET", "/api/admin/contacts?limit=10&page=2", { token: admin.token })).body.messages.map((m) => m.id);
    const r = await api("POST", "/api/admin/contacts/bulk", { token: admin.token, body: { ids, action: "read" } });
    assert.equal(r.status, 200);
    assert.equal(r.body.affected, 10);
    const [[c]] = await db.query("SELECT COUNT(*) c FROM contacts WHERE id IN (?) AND status='read'", [ids]);
    assert.equal(c.c, 10);
    await api("POST", "/api/admin/contacts/bulk", { token: admin.token, body: { ids, action: "important" } });
    const [[d]] = await db.query("SELECT COUNT(*) c FROM contacts WHERE id IN (?) AND isImportant=1", [ids]);
    assert.equal(d.c, 10);
    await api("POST", "/api/admin/contacts/bulk", { token: admin.token, body: { ids, action: "unimportant" } });
    const [[e]] = await db.query("SELECT COUNT(*) c FROM contacts WHERE id IN (?) AND isImportant=1", [ids]);
    assert.equal(e.c, 0);
  });
  test("ورودی نامعتبر رد می‌شود", async () => {
    assert.equal((await api("POST", "/api/admin/contacts/bulk", { token: admin.token, body: { ids: [], action: "read" } })).status, 400);
    assert.equal((await api("POST", "/api/admin/contacts/bulk", { token: admin.token, body: { ids: [1], action: "drop" } })).status, 400);
    assert.equal((await api("POST", "/api/admin/contacts/bulk", { token: admin.token, body: { ids: Array.from({ length: 201 }, (_, i) => i + 1), action: "read" } })).status, 400);
  });
  test("حذف گروهی + آدیت ردیف‌به‌ردیف", async () => {
    const ids = (await api("GET", "/api/admin/contacts?limit=5&page=3", { token: admin.token })).body.messages.map((m) => m.id);
    const r = await api("POST", "/api/admin/contacts/bulk", { token: admin.token, body: { ids, action: "delete" } });
    assert.equal(r.status, 200);
    assert.equal(r.body.affected, 5);
    const stats = await api("GET", "/api/admin/contacts/stats", { token: admin.token });
    assert.equal(stats.body.stats.total, 40);
  });
  test("حذف تکی همچنان کار می‌کند", async () => {
    const id = (await api("GET", "/api/admin/contacts?limit=1", { token: admin.token })).body.messages[0].id;
    assert.equal((await api("DELETE", `/api/admin/contacts/${id}`, { token: admin.token })).status, 200);
    assert.equal((await api("GET", `/api/admin/contacts/${id}`, { token: admin.token })).status, 404);
  });
});

describe("دسترسی و فرم عمومی", () => {
  test("بدون توکن ۴۰۱ و نقش user ۴۰۳ (همه‌ی مسیرهای جدید)", async () => {
    for (const [m, p, body] of [["GET", "/api/admin/contacts"], ["GET", "/api/admin/contacts/stats"], ["POST", "/api/admin/contacts/bulk", { ids: [1], action: "delete" }], ["PUT", "/api/admin/contacts/1/flags", { isImportant: true }]]) {
      assert.equal((await api(m, p, { body })).status, 401, `${m} ${p}`);
      assert.equal((await api(m, p, { token: user.token, body })).status, 403, `${m} ${p}`);
    }
  });
  test("فرم عمومی: قدیمی (بدون type/subject) و جدید هر دو ثبت می‌شوند", async () => {
    const a = await api("POST", "/api/contacts", { body: { fullName: "قدیمی", message: "سلام" } });
    assert.equal(a.status, 201);
    const b = await api("POST", "/api/contacts", { body: { fullName: "جدید", message: "سلام", type: "complaint", subject: "مشکل نوبت" } });
    assert.equal(b.status, 201);
    const [[row]] = await db.query("SELECT type, subject FROM contacts WHERE fullName='جدید'");
    assert.equal(row.type, "complaint");
    assert.equal(row.subject, "مشکل نوبت");
    const [[old]] = await db.query("SELECT type, subject FROM contacts WHERE fullName='قدیمی'");
    assert.equal(old.type, "other");
    assert.equal(old.subject, null);
    assert.equal((await api("POST", "/api/contacts", { body: { fullName: "x", message: "y", type: "hack" } })).status, 400);
  });
});

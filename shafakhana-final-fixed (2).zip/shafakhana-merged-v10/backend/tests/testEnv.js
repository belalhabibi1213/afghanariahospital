// راه‌اندازی محیط تست: قبل از import هر ماژول دیگری اجرا شود.
//
// db.js همان لحظه‌ی import شدن به دیتابیس وصل و جدول‌ها را می‌سازد/ارتقا می‌دهد؛ برای اینکه
// تست‌ها هرگز دست به دیتابیس واقعی درمانگاه نزنند، اینجا DB_NAME را به یک دیتابیس جداگانه
// («<DB_NAME اصلی>_test») تغییر می‌دهیم. ابتدا همان .env پروژه (آدرس/کاربر/رمز MySQL) بارگذاری
// می‌شود — دقیقاً همان دیتابیسی که XAMPP/MySQL شما همین الان به آن وصل است — فقط نام دیتابیس
// عوض می‌شود، مثل یک دیتابیس تازه که db.js خودش می‌سازد. اگر بخواهید از یک MySQL دیگر (مثلاً
// روی CI) استفاده کنید، همان متغیرهای DB_HOST/DB_USER/DB_PASSWORD/DB_NAME را قبل از اجرای
// تست‌ها در محیط (environment) تنظیم کنید؛ چون از قبل تنظیم شده باشند، بر مقدار .env مقدم‌اند.
import { shellEnv } from "./envSnapshot.js"; // باید پیش از loadEnv.js بیاید
import "../loadEnv.js";
import { __setDnsResolversForTests } from "../utils/emailValidation.js";

// DNS ساختگی و قطعی برای تست‌ها: دامنه‌های *.invalid و *.test.nonexistent وجود ندارند (ENOTFOUND)، بقیه رکورد MX دارند.
// برای آزمایش با DNS واقعی: EMAIL_DNS_LIVE=true
if (String(process.env.EMAIL_DNS_LIVE || "").toLowerCase() !== "true") {
  const notFound = () => Object.assign(new Error("ENOTFOUND"), { code: "ENOTFOUND" });
  const exists = (domain) => !/(\.invalid|\.nonexistent)$/i.test(domain);
  __setDnsResolversForTests({
    resolveMx: async (domain) => { if (!exists(domain)) throw notFound(); return [{ exchange: `mx.${domain}`, priority: 10 }]; },
    resolve4: async (domain) => { if (!exists(domain)) throw notFound(); return ["192.0.2.1"]; },
    resolve6: async (domain) => { if (!exists(domain)) throw notFound(); return ["2001:db8::1"]; },
  });
}

// فقط تنظیمات «رفتاری» که .env واقعی ممکن است عوض کرده باشد به حالت پیش‌فرضِ تست برمی‌گردند، مگر اینکه
// صراحتاً در شل/CI تنظیم شده باشند (مثلاً MFA_REQUIRED_ROLES=admin,superadmin برای تست MFA). تنظیمات اتصال
// دیتابیس (DB_*) عمداً از .env خوانده می‌شود.
for (const key of [
  "NODE_ENV", "BACKUP_ENCRYPTION_KEY", "MFA_ENABLED", "MFA_REQUIRED_ROLES", "AUTH_CACHE_TTL_MS",
  "SEED_DEFAULT_ACCOUNTS", "FORCE_HTTPS", "COOKIE_SECURE", "COOKIE_SAMESITE", "TRUST_PROXY", "AI_API_KEY",
]) {
  // مقدار خالی (نه delete): db.js هم dotenv.config() صدا می‌زند و کلید حذف‌شده را از .env برمی‌گرداند؛ dotenv کلیدِ تعریف‌شده را عوض نمی‌کند
  if (shellEnv[key] === undefined) process.env[key] = "";
}
process.env.DB_NAME = `${process.env.DB_NAME || "shafakhana"}_test`;
process.env.JWT_SECRET = process.env.JWT_SECRET || "test_only_secret_key_please_do_not_use_in_prod_1234567890";
process.env.NODE_ENV = process.env.NODE_ENV || "test";

export async function closePool() {
  const { getPool } = await import("../db.js");
  const pool = await getPool();
  await pool.end();
}

import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";
import db from "../db.js";
import { createPrescription } from "../models/Prescription.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// api() بدنه‌ی باینری را در raw برمی‌گرداند
async function getPdf(urlPath, token) {
  const res = await api("GET", urlPath, { token });
  return { status: res.status, headers: res.headers, buf: res.raw };
}

function pdfText(buf) {
  const file = path.join(os.tmpdir(), `rx-test-${process.pid}-${Date.now()}.pdf`);
  fs.writeFileSync(file, buf);
  try {
    return execFileSync("pdftotext", ["-layout", file, "-"], { encoding: "utf-8" });
  } catch {
    return null; // pdftotext نصب نیست: فقط بررسی‌های ساختاری انجام می‌شود
  } finally {
    fs.rmSync(file, { force: true });
  }
}

describe("Prescription PDF — داده‌های واقعی دیتابیس و کنترل دسترسی", () => {
  let doctor; let other; let patientUser; let stranger; let patientId; let rx1; let groupId;

  before(async () => {
    doctor = await createTestDoctor();
    other = await createTestDoctor();
    patientUser = await makeSession("user");
    stranger = await makeSession("user");
    patientId = await createTestPatient(patientUser.id, "بیمار پی‌دی‌اف");
    await db.query("UPDATE patients SET gender = 'female', dateOfBirth = '1990-05-10' WHERE id = ?", [patientId]);
    await db.query("UPDATE doctors SET department = 'قلب' WHERE id = ?", [doctor.id]);
    await addAppointment(patientId, doctor.id, "confirmed");
    groupId = `pdf-${Date.now()}`;
    rx1 = await createPrescription({
      patientId, doctorId: doctor.id, diagnosis: "تشخیص آزمایشی", medicationName: "داروی یک", dosage: "500mg",
      quantity: "21 عدد", frequency: "هر ۸ ساعت", duration: "۷ روز", medicineNotes: "بعد از غذا", instructions: "آب فراوان", notes: "پیگیری", groupId,
    });
    await createPrescription({ patientId, doctorId: doctor.id, medicationName: "داروی دو", dosage: "1 عدد", groupId });
  });

  test("داکتر مالک: PDF معتبر، هدرهای امن، و شماره نسخه + کد بیمار واقعی", async () => {
    const res = await getPdf(`/api/medical-records/prescriptions/${rx1.id}/pdf`, doctor.token);
    assert.equal(res.status, 200);
    assert.match(res.headers.get("content-type"), /application\/pdf/);
    assert.equal(res.headers.get("cache-control"), "no-store");
    assert.match(res.headers.get("content-disposition"), new RegExp(`RX-${String(rx1.id).padStart(6, "0")}`));
    assert.equal(res.buf.subarray(0, 5).toString(), "%PDF-");
    const text = pdfText(res.buf);
    if (text) {
      assert.ok(text.includes(`RX-${String(rx1.id).padStart(6, "0")}`), "شماره نسخه باید چاپ شود");
      const [[p]] = await db.query("SELECT publicCode FROM patients WHERE id = ?", [patientId]);
      if (p.publicCode) assert.ok(text.includes(p.publicCode), "کد بیمار از دیتابیس");
    }
  });

  test("بیمار صاحب نسخه همان PDF را می‌گیرد؛ بیمار دیگر ۴۰۴ و داکتر دیگر ۴۰۳", async () => {
    const mine = await getPdf(`/api/users/prescriptions/${rx1.id}/pdf`, patientUser.token);
    assert.equal(mine.status, 200);
    assert.equal(mine.buf.subarray(0, 5).toString(), "%PDF-");
    assert.equal((await getPdf(`/api/users/prescriptions/${rx1.id}/pdf`, stranger.token)).status, 404);
    assert.equal((await getPdf(`/api/medical-records/prescriptions/${rx1.id}/pdf`, other.token)).status, 403);
    assert.equal((await getPdf(`/api/medical-records/prescriptions/${rx1.id}/pdf`, patientUser.token)).status, 403);
  });

  test("نسخه‌ی لغوشده و نسخه‌ی بدون داده‌ی اختیاری (سن/تخصص/امضا) هم بدون خطا چاپ می‌شود", async () => {
    await db.query("UPDATE prescriptions SET status = 'cancelled' WHERE groupId = ?", [groupId]);
    await db.query("UPDATE patients SET gender = NULL, dateOfBirth = NULL WHERE id = ?", [patientId]);
    await db.query("UPDATE doctors SET department = '' , signatureUrl = 'missing-file.png' WHERE id = ?", [doctor.id]);
    const res = await getPdf(`/api/medical-records/prescriptions/${rx1.id}/pdf`, doctor.token);
    assert.equal(res.status, 200);
    assert.equal(res.buf.subarray(0, 5).toString(), "%PDF-");
  });

  test("ثبت ۸ دارو در یک نسخه از طریق API و چاپ در «یک» ورق A4 (حتی با توضیحات هر دارو)", async () => {
    const d = await createTestDoctor();
    const u = await makeSession("user");
    const pid = await createTestPatient(u.id, "بیمار هشت‌دارویی");
    await addAppointment(pid, d.id, "confirmed");
    const gid = `eight-${Date.now()}`;
    let firstId = null;
    for (let i = 1; i <= 8; i++) {
      const res = await api("POST", "/api/medical-records/prescriptions", {
        token: d.token,
        body: {
          patientId: pid, groupId: gid, diagnosis: "تشخیص آزمایشی برای نسخه‌ی هشت‌دارویی",
          medicationName: `داروی شماره ${i}`, dosage: "500mg", quantity: `${10 + i} عدد`,
          frequency: "هر ۸ ساعت یک عدد بعد از غذا", duration: `${i + 2} روز`,
          medicineNotes: "همراه با غذا و آب فراوان مصرف شود؛ در صورت حساسیت قطع شود",
          instructions: "همه‌ی داروها با آب فراوان مصرف شود", notes: "در صورت عدم بهبودی مراجعه شود", followUpDate: "2026-12-01",
        },
      });
      assert.equal(res.status, 201, `دارو ${i}: ${JSON.stringify(res.body)}`);
      if (!firstId) firstId = res.body.item.id;
    }
    const [[{ n }]] = await db.query("SELECT COUNT(*) AS n FROM prescriptions WHERE groupId = ?", [gid]);
    assert.equal(n, 8);

    const pdf = await getPdf(`/api/medical-records/prescriptions/${firstId}/pdf`, d.token);
    assert.equal(pdf.status, 200);
    const pages = (pdf.buf.toString("latin1").match(/\/Type \/Page\b(?!s)/g) || []).length;
    assert.equal(pages, 1, `نسخه‌ی ۸ داروی باید در یک ورق باشد (صفحه‌ها: ${pages})`);
    const text = pdfText(pdf.buf);
    if (text) assert.ok(text.includes("RX-"), "شماره نسخه در PDF یک‌صفحه‌ای هم چاپ می‌شود");

    // بیمار هم همان نسخه را در یک ورق می‌گیرد
    const mine = await getPdf(`/api/users/prescriptions/${firstId}/pdf`, u.token);
    assert.equal(mine.status, 200);
    assert.equal((mine.buf.toString("latin1").match(/\/Type \/Page\b(?!s)/g) || []).length, 1);
  });
});

import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";

import db, { getPool } from "../db.js";
import { createAppointment, countActiveAppointmentsForSlot, getAppointmentTiming, updateAppointmentStatus } from "../models/Appointment.js";
import { findOrCreatePatient } from "../models/Patient.js";

after(closePool);

let doctorId;
let patientIds = [];

before(async () => {
  const [dep] = await db.query("INSERT INTO departments (name) VALUES ('تست')").catch(() => [{}]);
  const [doc] = await db.query(
    "INSERT INTO doctors (doctorCode, fullName, department) VALUES (?, 'داکتر تست', 'تست')",
    [`TEST-${Date.now()}`]
  );
  doctorId = doc.insertId;
  for (let i = 0; i < 5; i += 1) {
    const p = await findOrCreatePatient({ fullName: `بیمار تست ${i}`, phone: `070111100${i}` });
    patientIds.push(p.id);
  }
});

describe("ظرفیت هر ساعت نوبت‌دهی", () => {
  test("رزرو تا سقف ظرفیت مجاز است، بعد از آن رد می‌شود", async () => {
    const date = "2027-01-10";
    const time = "09:00:00";
    const capacity = 2;

    const r1 = await createAppointment({
      patientId: patientIds[0], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.ok(r1.id, "رزرو اول باید موفق شود");

    const r2 = await createAppointment({
      patientId: patientIds[1], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.ok(r2.id, "رزرو دوم (آخرین جای خالی) باید موفق شود");

    const r3 = await createAppointment({
      patientId: patientIds[2], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.equal(r3.error, "SLOT_FULL", "رزرو سوم باید با ظرفیت ۲ رد شود");

    const count = await countActiveAppointmentsForSlot({ doctorId, appointmentDate: date, appointmentTime: time });
    assert.equal(count, 2, "دقیقاً ۲ نوبت فعال باید ثبت شده باشد، نه بیشتر");
  });

  test("چند رزرو هم‌زمان برای یک ساعت هرگز بیشتر از ظرفیت را ثبت نمی‌کند (Race Condition)", async () => {
    const date = "2027-01-11";
    const time = "10:00:00";
    const capacity = 3;
    const patients = [];
    for (let i = 0; i < 8; i += 1) {
      const p = await findOrCreatePatient({ fullName: `همزمان ${i}`, phone: `07022220${i}` });
      patients.push(p.id);
    }

    // ۸ درخواست رزرو کاملاً هم‌زمان برای یک ساعت با ظرفیت ۳
    const results = await Promise.all(
      patients.map((patientId) =>
        createAppointment({ patientId, doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity })
      )
    );

    const succeeded = results.filter((r) => r.id).length;
    const failed = results.filter((r) => r.error === "SLOT_FULL").length;
    assert.equal(succeeded, capacity, `دقیقاً ${capacity} رزرو باید موفق شود، نه بیشتر`);
    assert.equal(failed, patients.length - capacity);

    const count = await countActiveAppointmentsForSlot({ doctorId, appointmentDate: date, appointmentTime: time });
    assert.equal(count, capacity, "شمارش نهایی در دیتابیس هم نباید از ظرفیت بیشتر شود");
  });
});

describe("زمان‌بندی و لغو نوبت", () => {
  test("getAppointmentTiming فاصله‌ی درست تا نوبت آینده را برمی‌گرداند", async () => {
    const [ins] = await db.query(
      "INSERT INTO appointments (patientId,doctorId,department,appointmentDate,appointmentTime,status) VALUES (?,?,?,DATE_ADD(CURDATE(), INTERVAL 1 DAY),'12:00:00','confirmed')",
      [patientIds[0], doctorId, "تست"]
    );
    const timing = await getAppointmentTiming(ins.insertId);
    assert.ok(timing.minutesUntil > 0 && timing.minutesUntil < 48 * 60, "نوبت فردا باید فاصله‌ی مثبت و منطقی داشته باشد");
  });

  test("getAppointmentTiming برای نوبت گذشته عدد منفی می‌دهد", async () => {
    const [ins] = await db.query(
      "INSERT INTO appointments (patientId,doctorId,department,appointmentDate,appointmentTime,status) VALUES (?,?,?,DATE_SUB(CURDATE(), INTERVAL 1 DAY),'08:00:00','confirmed')",
      [patientIds[0], doctorId, "تست"]
    );
    const timing = await getAppointmentTiming(ins.insertId);
    assert.ok(timing.minutesUntil < 0);
  });

  test("لغو یک نوبت وضعیتش را به cancelled تغییر می‌دهد و در تاریخچه ثبت می‌شود", async () => {
    const [ins] = await db.query(
      "INSERT INTO appointments (patientId,doctorId,department,appointmentDate,appointmentTime,status) VALUES (?,?,?,DATE_ADD(CURDATE(), INTERVAL 2 DAY),'09:30:00','pending')",
      [patientIds[0], doctorId, "تست"]
    );
    const updated = await updateAppointmentStatus(ins.insertId, "cancelled", { changedByUserId: null, changedByRole: "user", note: "تست" });
    assert.equal(updated.status, "cancelled");

    const [[history]] = await db.query(
      "SELECT * FROM appointment_status_history WHERE appointmentId = ? ORDER BY id DESC LIMIT 1",
      [ins.insertId]
    );
    assert.equal(history.newStatus, "cancelled");
    assert.equal(history.oldStatus, "pending");
  });

  test("لغو نوبت، ظرفیت همان ساعت را آزاد می‌کند", async () => {
    const date = "2027-01-12";
    const time = "11:00:00";
    const capacity = 1;

    const first = await createAppointment({
      patientId: patientIds[0], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.ok(first.id);

    const blocked = await createAppointment({
      patientId: patientIds[1], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.equal(blocked.error, "SLOT_FULL");

    await updateAppointmentStatus(first.id, "cancelled");

    const afterCancel = await createAppointment({
      patientId: patientIds[1], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.ok(afterCancel.id, "بعد از لغو، همان ساعت باید دوباره قابل‌رزرو باشد");
  });
  test("یک بیمار در یک ساعتِ یک داکتر بیش از یک نوبت فعال نمی‌تواند داشته باشد", async () => {
    const date = "2027-01-13";
    const time = "08:00:00";
    const capacity = 10;

    const first = await createAppointment({
      patientId: patientIds[0], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.ok(first.id);

    // ده تلاش هم‌زمان از همان بیمار — همه باید رد شوند
    const attempts = await Promise.all(
      Array.from({ length: 10 }, () => createAppointment({
        patientId: patientIds[0], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
      }))
    );
    assert.ok(attempts.every((r) => r.error === "ALREADY_BOOKED"));

    // بیمار دیگر هنوز می‌تواند همان ساعت را بگیرد
    const other = await createAppointment({
      patientId: patientIds[1], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.ok(other.id);

    // بعد از لغو، همان بیمار دوباره می‌تواند درخواست بدهد
    await updateAppointmentStatus(first.id, "cancelled");
    const again = await createAppointment({
      patientId: patientIds[0], doctorId, department: "تست", appointmentDate: date, appointmentTime: time, capacity,
    });
    assert.ok(again.id);
  });
});

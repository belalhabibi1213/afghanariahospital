import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";
import db from "../db.js";
import { createPrescription } from "../models/Prescription.js";
import { createRecord } from "../models/MedicalRecord.js";
import { createLabResult } from "../models/LabResult.js";
import { createRadiologyReport } from "../models/RadiologyReport.js";
import { createDiagnosis } from "../models/Diagnosis.js";
import { createAllergy } from "../models/Allergy.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// «خط زمانی خدمات صحی» بیمار: ترکیب ۶ نوع رویداد واقعی، فقط داده‌های خودِ بیمار (جلوگیری از IDOR)
describe("خط زمانی خدمات صحی — انواع رویداد، فیلتر و مالکیت", () => {
  let a; let b; let doctor; let admin;
  let ids = {};
  let otherIds = {};

  before(async () => {
    a = await makeSession("user");
    b = await makeSession("user");
    admin = await makeSession("admin");
    const pa = await createTestPatient(a.id, "بیمار الف");
    const pb = await createTestPatient(b.id, "بیمار ب");
    doctor = await createTestDoctor({ department: "داخله" });

    const rec = await createRecord({ patientId: pa, doctorId: doctor.id, visitDate: "2026-03-10", symptoms: "سرفه", diagnosis: "سرماخوردگی", prescription: "استراحت" });
    const groupId = `g-${Date.now()}`;
    const rx = await createPrescription({ patientId: pa, doctorId: doctor.id, diagnosis: "سرماخوردگی", medicationName: "استامینوفن", dosage: "500mg", groupId });
    await createPrescription({ patientId: pa, doctorId: doctor.id, diagnosis: "سرماخوردگی", medicationName: "ویتامین C", groupId });
    const lab = await createLabResult({ patientId: pa, doctorId: doctor.id, testName: "CBC", result: "12", unit: "g/dL", status: "completed", testDate: "2026-03-08" });
    const labPending = await createLabResult({ patientId: pa, doctorId: doctor.id, testName: "آزمایش در انتظار", status: "pending", testDate: "2026-03-09" });
    const rad = await createRadiologyReport({ patientId: pa, doctorId: doctor.id, examType: "X-Ray قفسه سینه", findings: "نرمال", impression: "بدون یافته‌ی پاتولوژیک", examDate: "2026-03-05" });
    const dg = await createDiagnosis({ patientId: pa, doctorId: doctor.id, title: "فشار خون بالا", description: "سابقه فشار خون" });
    const al = await createAllergy({ patientId: pa, doctorId: doctor.id, allergen: "پنی‌سیلین", severity: "severe" });
    const appt = await addAppointment(pa, doctor.id, "completed", { dayOffset: -30 });
    ids = { rec: rec.id, rx: rx.id, lab: lab.id, labPending: labPending.id, rad: rad.id, dg: dg.id, al: al.id, appt };

    const recB = await createRecord({ patientId: pb, doctorId: doctor.id, visitDate: "2026-03-11", symptoms: "راز بیمار ب", diagnosis: "تشخیص خصوصی ب" });
    const labB = await createLabResult({ patientId: pb, doctorId: doctor.id, testName: "آزمایش خصوصی ب", result: "9", status: "completed", testDate: "2026-03-11" });
    const radB = await createRadiologyReport({ patientId: pb, doctorId: doctor.id, examType: "MRI خصوصی ب", examDate: "2026-03-11" });
    const dgB = await createDiagnosis({ patientId: pb, doctorId: doctor.id, title: "تشخیص خصوصی ب" });
    const alB = await createAllergy({ patientId: pb, doctorId: doctor.id, allergen: "حساسیت خصوصی ب" });
    const apptB = await addAppointment(pb, doctor.id, "confirmed", { dayOffset: 2 });
    otherIds = { rec: recB.id, lab: labB.id, rad: radB.id, dg: dgB.id, al: alB.id, appt: apptB };
  });

  test("بدون توکن ۴۰۱ (فهرست و جزئیات)", async () => {
    assert.equal((await api("GET", "/api/users/medical-history")).status, 401);
    assert.equal((await api("GET", `/api/users/medical-history/lab/${ids.lab}`)).status, 401);
  });

  test("فهرست همه‌ی انواع رویداد را برمی‌گرداند و فقط رویدادهای خودِ بیمار", async () => {
    const res = await api("GET", "/api/users/medical-history?limit=50", { token: a.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const types = new Set(res.body.items.map((i) => i.type));
    for (const t of ["prescription", "encounter", "lab", "radiology", "appointment", "diagnosis", "allergy"]) {
      assert.ok(types.has(t), `نوع ${t} در خط زمانی نیست`);
    }
    assert.equal(res.body.pagination.total, 7); // یک رویداد از هر نوع (نسخه‌ی دو‌داروئی = یک رویداد)؛ آزمایش در انتظار نمی‌آید
    const blob = JSON.stringify(res.body);
    assert.ok(!blob.includes("خصوصی ب"));
    assert.ok(!res.body.items.some((i) => i.type === "lab" && i.id === ids.labPending));
  });

  test("نسخه‌ی دو‌داروئی یک رویداد با itemCount=2 است", async () => {
    const res = await api("GET", "/api/users/medical-history?type=prescription", { token: a.token });
    assert.equal(res.body.items.length, 1);
    assert.equal(res.body.items[0].itemCount, 2);
    assert.equal(res.body.items[0].doctorName != null, true);
  });

  test("ترتیب: جدیدترین اول", async () => {
    const res = await api("GET", "/api/users/medical-history?limit=50", { token: a.token });
    const dates = res.body.items.map((i) => String(i.eventDate).slice(0, 10));
    const sorted = [...dates].sort().reverse();
    assert.deepEqual(dates, sorted);
  });

  test("فیلتر نوع: هر گروه فقط نوع خودش را می‌دهد؛ «سوابق طبی» = تشخیص + حساسیت", async () => {
    const expect = { encounter: ["encounter"], lab: ["lab"], radiology: ["radiology"], appointment: ["appointment"], record: ["diagnosis", "allergy"] };
    for (const [type, kinds] of Object.entries(expect)) {
      const res = await api("GET", `/api/users/medical-history?type=${type}&limit=50`, { token: a.token });
      assert.equal(res.status, 200);
      assert.ok(res.body.items.length >= 1, type);
      assert.ok(res.body.items.every((i) => kinds.includes(i.type)), type);
    }
  });

  test("نوع ناشناخته به‌جای خطا/تزریق، همه را برمی‌گرداند", async () => {
    const res = await api("GET", `/api/users/medical-history?type=${encodeURIComponent("x'; DROP TABLE patients;--")}`, { token: a.token });
    assert.equal(res.status, 200);
    assert.equal(res.body.pagination.total, 7);
    const [[c]] = await db.query("SELECT COUNT(*) AS c FROM patients");
    assert.ok(c.c >= 2);
  });

  test("جستجو (عنوان/توضیح/داکتر) و بازه‌ی تاریخ", async () => {
    let res = await api("GET", `/api/users/medical-history?q=${encodeURIComponent("CBC")}`, { token: a.token });
    assert.equal(res.body.items.length, 1);
    assert.equal(res.body.items[0].type, "lab");
    res = await api("GET", `/api/users/medical-history?q=${encodeURIComponent("داخله")}`, { token: a.token });
    assert.ok(res.body.items.length >= 5); // بخش داکتر
    res = await api("GET", "/api/users/medical-history?dateFrom=2026-03-09&dateTo=2026-03-10&type=encounter", { token: a.token });
    assert.equal(res.body.items.length, 1);
    res = await api("GET", "/api/users/medical-history?dateFrom=2026-03-09&dateTo=2026-03-10&type=lab", { token: a.token });
    assert.equal(res.body.items.length, 0);
  });

  test("جستجوی نام نوع رویداد (نسخه/ویزیت/نوبت/آزمایش/رادیولوژی) همان نوع را پیدا می‌کند", async () => {
    const expectType = { "نسخه": "prescription", "ویزیت": "encounter", "نوبت": "appointment", "آزمایش": "lab", "رادیولوژی": "radiology" };
    for (const [word, t] of Object.entries(expectType)) {
      const res = await api("GET", `/api/users/medical-history?q=${encodeURIComponent(word)}`, { token: a.token });
      assert.equal(res.status, 200);
      assert.ok(res.body.items.some((i) => i.type === t), `${word} → ${t}`);
    }
    // «سوابق طبی» = تشخیص + حساسیت
    const rec = await api("GET", `/api/users/medical-history?q=${encodeURIComponent("سوابق")}`, { token: a.token });
    assert.deepEqual([...new Set(rec.body.items.map((i) => i.type))].sort(), ["allergy", "diagnosis"]);
    // جستجو همچنان ایزوله است: بیمار ب با همین کلمه چیزی از بیمار الف نمی‌بیند
    const other = await api("GET", `/api/users/medical-history?q=${encodeURIComponent("آزمایش")}`, { token: b.token });
    assert.ok(!JSON.stringify(other.body).includes("CBC"));
  });

  test("صفحه‌بندی", async () => {
    const p1 = await api("GET", "/api/users/medical-history?limit=3&page=1", { token: a.token });
    const p2 = await api("GET", "/api/users/medical-history?limit=3&page=2", { token: a.token });
    assert.equal(p1.body.items.length, 3);
    assert.equal(p1.body.pagination.totalPages, 3); // ۷ رویداد / ۳ = ۳ صفحه
    const k = (i) => `${i.type}-${i.id}`;
    assert.ok(!p1.body.items.some((x) => p2.body.items.map(k).includes(k(x))));
  });

  test("دست‌کاری query (patientId/userId) فهرست بیمار دیگر را باز نمی‌کند", async () => {
    const [[pa]] = await db.query("SELECT id FROM patients WHERE userId = ?", [a.id]);
    const res = await api("GET", `/api/users/medical-history?limit=50&patientId=${pa.id}&userId=${a.id}`, { token: b.token });
    assert.equal(res.status, 200);
    assert.ok(!JSON.stringify(res.body).includes("CBC"));
    assert.ok(res.body.items.every((i) => i.type !== "prescription"));
  });

  test("تاریخ/ساعت به‌صورت رشته‌ی ساده می‌آید (بدون جابه‌جایی منطقه‌ی زمانی)", async () => {
    const res = await api("GET", "/api/users/medical-history?type=radiology", { token: a.token });
    assert.equal(res.body.items[0].eventDate, "2026-03-05");
    const lab = await api("GET", "/api/users/medical-history?type=lab", { token: a.token });
    assert.equal(lab.body.items[0].eventDate, "2026-03-08");
    for (const it of (await api("GET", "/api/users/medical-history?limit=50", { token: a.token })).body.items) {
      assert.match(it.eventDate, /^\d{4}-\d{2}-\d{2}$/);
      assert.ok(it.eventTime === null || /^\d{2}:\d{2}$/.test(it.eventTime));
    }
    const d = await api("GET", `/api/users/medical-history/lab/${ids.lab}`, { token: a.token });
    assert.equal(d.body.detail.testDate, "2026-03-08");
  });

  test("خروجی شناسه‌ی داخلی بیمار/داکتر و مسیر فایل را لو نمی‌دهد", async () => {
    const res = await api("GET", "/api/users/medical-history?limit=50", { token: a.token });
    for (const it of res.body.items) {
      assert.equal(it.patientId, undefined);
      assert.equal(it.doctorId, undefined);
      assert.equal(it.reportUrl, undefined);
    }
  });

  test("جزئیات رویدادهای خود بیمار ۲۰۰ است", async () => {
    const cases = [["encounter", ids.rec, "diagnosis", "سرماخوردگی"], ["lab", ids.lab, "testName", "CBC"],
      ["radiology", ids.rad, "examType", "X-Ray قفسه سینه"], ["appointment", ids.appt, "status", "completed"],
      ["diagnosis", ids.dg, "title", "فشار خون بالا"], ["allergy", ids.al, "allergen", "پنی‌سیلین"]];
    for (const [type, id, field, value] of cases) {
      const res = await api("GET", `/api/users/medical-history/${type}/${id}`, { token: a.token });
      assert.equal(res.status, 200, `${type}: ${JSON.stringify(res.body)}`);
      assert.equal(res.body.detail[field], value);
      assert.equal(res.body.detail.patientId, undefined);
    }
  });

  test("IDOR: جزئیات رکورد بیمار دیگر ۴۰۴ است (نه ۲۰۰ و نه ۴۰۳)", async () => {
    const cases = [["encounter", otherIds.rec], ["lab", otherIds.lab], ["radiology", otherIds.rad],
      ["appointment", otherIds.appt], ["diagnosis", otherIds.dg], ["allergy", otherIds.al]];
    for (const [type, id] of cases) {
      const res = await api("GET", `/api/users/medical-history/${type}/${id}`, { token: a.token });
      assert.equal(res.status, 404, type);
      assert.ok(!JSON.stringify(res.body).includes("خصوصی"));
    }
  });

  test("آزمایش در انتظار از مسیر جزئیات هم برای بیمار باز نمی‌شود", async () => {
    assert.equal((await api("GET", `/api/users/medical-history/lab/${ids.labPending}`, { token: a.token })).status, 404);
  });

  test("نوع نامعتبر ۴۰۴؛ شناسه‌ی غیرعددی ۴۰۰؛ نسخه از مسیر جزئیات خط زمانی نیست", async () => {
    assert.equal((await api("GET", `/api/users/medical-history/hacker/${ids.rec}`, { token: a.token })).status, 404);
    assert.equal((await api("GET", `/api/users/medical-history/prescription/${ids.rx}`, { token: a.token })).status, 404);
    assert.equal((await api("GET", "/api/users/medical-history/lab/abc", { token: a.token })).status, 400);
    assert.equal((await api("GET", "/api/users/medical-history/__proto__/1", { token: a.token })).status, 404);
  });

  test("ادمین از همین مسیرها فقط داده‌ی خودش (خالی) می‌بیند، نه بیماران", async () => {
    const res = await api("GET", "/api/users/medical-history", { token: admin.token });
    assert.equal(res.status, 200);
    assert.equal(res.body.items.length, 0);
    assert.equal((await api("GET", `/api/users/medical-history/lab/${ids.lab}`, { token: admin.token })).status, 404);
  });

  test("حالت خالی: بیمار بدون رویداد", async () => {
    const c = await makeSession("user");
    await createTestPatient(c.id, "بیمار ج");
    const res = await api("GET", "/api/users/medical-history", { token: c.token });
    assert.equal(res.status, 200);
    assert.equal(res.body.items.length, 0);
    assert.equal(res.body.pagination.total, 0);
  });
});

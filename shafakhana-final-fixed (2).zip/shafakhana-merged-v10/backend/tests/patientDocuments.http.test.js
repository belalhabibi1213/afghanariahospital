import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient } from "./testApp.js";
import db from "../db.js";
import { createPrescription } from "../models/Prescription.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// «همه اسناد» بیمار: جستجو/فیلتر نوع/صفحه‌بندی در SQL، فقط اسناد خودِ بیمار، بدون پیش‌نویس
describe("بیمار — GET /api/users/documents", () => {
  let a; let b; let doctor; let patientA; let patientB;
  const rxIdsA = [];
  let recA; let draftA; let recB; let rxB;

  before(async () => {
    a = await makeSession("user");
    b = await makeSession("user");
    patientA = await createTestPatient(a.id, "بیمار الف");
    patientB = await createTestPatient(b.id, "بیمار ب");
    doctor = await createTestDoctor();

    // ۱۲ نسخه برای بیمار الف (نسخه‌ی اول دو دارو با groupId مشترک = یک ردیف)
    const g = `grp-doc-${Date.now()}`;
    const first = await createPrescription({ patientId: patientA, doctorId: doctor.id, diagnosis: "عفونت ویژه", medicationName: "آموکسی‌سیلین", groupId: g });
    await createPrescription({ patientId: patientA, doctorId: doctor.id, diagnosis: "عفونت ویژه", medicationName: "استامینوفن", groupId: g });
    rxIdsA.push(first.id);
    for (let i = 0; i < 11; i += 1) {
      const r = await createPrescription({ patientId: patientA, doctorId: doctor.id, diagnosis: "عمومی", medicationName: `دارو ${i}`, groupId: `grp-doc-${Date.now()}-${i}` });
      rxIdsA.push(r.id);
    }
    rxB = await createPrescription({ patientId: patientB, doctorId: doctor.id, diagnosis: "نسخه بیمار ب", medicationName: "ویتامین C", groupId: `grp-doc-b-${Date.now()}` });

    const [r1] = await db.query("INSERT INTO medical_records (patientId, doctorId, diagnosis, status) VALUES (?, ?, 'آنژین الف', 'registered')", [patientA, doctor.id]);
    recA = r1.insertId;
    const [r2] = await db.query("INSERT INTO medical_records (patientId, doctorId, diagnosis, status) VALUES (?, ?, 'پیش‌نویس محرمانه', 'draft')", [patientA, doctor.id]);
    draftA = r2.insertId;
    const [r3] = await db.query("INSERT INTO medical_records (patientId, doctorId, diagnosis, status) VALUES (?, ?, 'سابقه بیمار ب', 'registered')", [patientB, doctor.id]);
    recB = r3.insertId;
  });

  test("بدون توکن ۴۰۱", async () => {
    assert.equal((await api("GET", "/api/users/documents")).status, 401);
  });

  test("صفحه‌بندی سمت سرور: ۱۰ ردیف در صفحه، مجموع و شمارنده‌ها درست", async () => {
    const res = await api("GET", "/api/users/documents?page=1&limit=10", { token: a.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.documents.length, 10);
    assert.equal(res.body.pagination.total, 13); // ۱۲ نسخه + ۱ پرونده (پیش‌نویس حساب نمی‌شود)
    assert.equal(res.body.pagination.totalPages, 2);
    assert.deepEqual(res.body.counts, { prescription: 12, record: 1 });
    const p2 = await api("GET", "/api/users/documents?page=2&limit=10", { token: a.token });
    assert.equal(p2.body.documents.length, 3);
    const ids1 = new Set(res.body.documents.map((d) => `${d.type}-${d.id}`));
    assert.ok(p2.body.documents.every((d) => !ids1.has(`${d.type}-${d.id}`)));
  });

  test("نسخه‌ی چنددارویی یک ردیف است و itemCount می‌دهد", async () => {
    const res = await api("GET", "/api/users/documents?type=prescription&q=ویژه", { token: a.token });
    assert.equal(res.status, 200);
    assert.equal(res.body.documents.length, 1);
    assert.equal(res.body.documents[0].itemCount, 2);
    assert.equal(res.body.documents[0].number, `RX-${String(rxIdsA[0]).padStart(6, "0")}`);
  });

  test("فیلتر نوع و جستجو (شماره سند / تشخیص) در SQL کار می‌کند", async () => {
    const rec = await api("GET", "/api/users/documents?type=record", { token: a.token });
    assert.equal(rec.body.pagination.total, 1);
    assert.equal(rec.body.documents[0].type, "record");
    assert.equal(rec.body.documents[0].released, false);
    const byNumber = await api("GET", `/api/users/documents?q=MR-${recA}`, { token: a.token });
    assert.ok(byNumber.body.documents.some((d) => d.type === "record" && d.id === recA));
    const byDiag = await api("GET", `/api/users/documents?q=${encodeURIComponent("آنژین")}`, { token: a.token });
    assert.equal(byDiag.body.pagination.total, 1);
    const none = await api("GET", `/api/users/documents?q=${encodeURIComponent("چیزی-که-نیست")}`, { token: a.token });
    assert.equal(none.body.pagination.total, 0);
    assert.equal(none.body.documents.length, 0);
    // ورودی نامعتبر نوع (lab/imaging/غیره) به همه‌ی اسناد بیمار برمی‌گردد، نه به نوع دیگر
    const bad = await api("GET", "/api/users/documents?type=lab", { token: a.token });
    assert.equal(bad.status, 200);
    assert.ok(bad.body.documents.every((d) => d.type === "prescription" || d.type === "record"));
  });

  test("پیش‌نویس و اسناد بیمار دیگر هرگز دیده نمی‌شوند؛ دست‌کاری query چیزی را باز نمی‌کند", async () => {
    const all = await api("GET", "/api/users/documents?limit=50", { token: a.token });
    assert.ok(!all.body.documents.some((d) => d.type === "record" && (d.id === draftA || d.id === recB)));
    assert.ok(!all.body.documents.some((d) => d.type === "prescription" && d.id === rxB.id));
    const tamper = await api("GET", `/api/users/documents?limit=50&patientId=${patientA}&userId=${a.id}&doctorId=${doctor.id}`, { token: b.token });
    assert.equal(tamper.status, 200);
    assert.equal(tamper.body.pagination.total, 2); // فقط ۱ نسخه + ۱ پرونده‌ی خودِ ب
    assert.ok(tamper.body.documents.every((d) => d.id === rxB.id || d.id === recB));
  });

  test("شناسه‌ی داخلی بیمار/داکتر و فیلدهای اضافی به کلاینت نمی‌رسد", async () => {
    const res = await api("GET", "/api/users/documents?limit=50", { token: a.token });
    for (const d of res.body.documents) {
      assert.equal(d.patientId, undefined);
      assert.equal(d.doctorId, undefined);
      assert.equal(d.patientName, undefined);
      assert.equal(d.patientPhone, undefined);
    }
  });

  test("limit بیش از سقف به ۵۰ محدود می‌شود", async () => {
    const res = await api("GET", "/api/users/documents?limit=100000", { token: a.token });
    assert.equal(res.status, 200);
    assert.equal(res.body.pagination.limit, 50);
  });
});

// تست‌های «نوبت‌های من» و «بیماران من» (پنل داکتر): فهرست سروری با صفحه‌بندی/جستجو/فیلتر، آمار و جزئیات.
// با حجم بالا (۳۰۰۰ نوبت، ۱۲۰۰ بیمار) برای یک داکتر اجرا می‌شود تا ثابت شود فقط یک صفحه به کلاینت می‌رسد
// و فیلتر/جستجو واقعاً در دیتابیس اجرا می‌شود. RBAC: داکتر دیگر، کاربر عادی و مهمان هیچ داده‌ای نمی‌بینند.
import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor } from "./testApp.js";
import db from "../db.js";

const PATIENTS = 1200;
const APPTS = 3000;
const STATUSES = ["pending", "confirmed", "completed", "cancelled"];
const DEPTS = ["قلب", "اطفال", "داخله"];
const tag = `DL${Date.now().toString(36).toUpperCase()}`;

let docA;
let docB;
let user;
let admin;
const patientIds = [];
let outsiderPatientId; // فقط با داکتر B نوبت دارد
let pendingOnlyPatientId;
let confirmedPatientId;

async function bulkInsert(sql, rows, chunk = 500) {
  for (let i = 0; i < rows.length; i += chunk) {
    await db.query(sql, [rows.slice(i, i + chunk)]);
  }
}

before(async () => {
  await startServer();
  docA = await createTestDoctor({ department: "قلب" });
  docB = await createTestDoctor({ department: "اطفال" });
  user = await makeSession("user");
  admin = await makeSession("admin");

  const pRows = [];
  for (let i = 1; i <= PATIENTS + 3; i += 1) {
    pRows.push([
      `${tag}-${i}`, `بیمار ${tag} ${i}`, `079${String(1000000 + i)}`, i % 2 ? "male" : "female",
      `19${70 + (i % 30)}-0${1 + (i % 9)}-15`, i % 5 === 0 ? `p${i}@example.com` : null,
    ]);
  }
  await bulkInsert("INSERT INTO patients (publicCode, fullName, phone, gender, dateOfBirth, email) VALUES ?", pRows);
  const [ids] = await db.query("SELECT id FROM patients WHERE publicCode LIKE ? ORDER BY id", [`${tag}-%`]);
  ids.forEach((r) => patientIds.push(r.id));
  outsiderPatientId = patientIds[PATIENTS];
  pendingOnlyPatientId = patientIds[PATIENTS + 1];
  confirmedPatientId = patientIds[PATIENTS + 2];

  // ۳۰۰۰ نوبت برای داکتر A روی ۱۲۰۰ بیمار (هر بیمار چند نوبت)، تاریخ‌ها پخش از ۴۰۰ روز قبل تا ۱۰۰ روز بعد
  const aRows = [];
  for (let i = 0; i < APPTS; i += 1) {
    const pid = patientIds[i % PATIENTS];
    // بیمار ۱ (index 0) همه‌ی نوبت‌هایش لغو است تا «غیرفعال» تست شود
    const status = pid === patientIds[0] ? "cancelled" : STATUSES[i % 4];
    aRows.push([pid, docA.id, DEPTS[i % 3], `DATE_OFFSET:${(i % 500) - 400}`, `${String(8 + (i % 9)).padStart(2, "0")}:${i % 2 ? "30" : "00"}:00`, status, i % 7 === 0 ? "یادداشت محرمانه‌ی بیمار" : null]);
  }
  for (let i = 0; i < aRows.length; i += 500) {
    const chunk = aRows.slice(i, i + 500);
    const values = chunk.map(() => "(?, ?, ?, DATE_ADD(CURDATE(), INTERVAL ? DAY), ?, ?, ?)").join(",");
    const flat = chunk.flatMap((r) => [r[0], r[1], r[2], Number(r[3].split(":")[1]), r[4], r[5], r[6]]);
    await db.query(`INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, status, notes) VALUES ${values}`, flat);
  }
  // نوبت‌های داکتر B
  await db.query(
    "INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, status) VALUES (?, ?, 'اطفال', CURDATE(), '09:00:00', 'confirmed'), (?, ?, 'اطفال', CURDATE(), '10:00:00', 'pending')",
    [outsiderPatientId, docB.id, patientIds[1], docB.id]
  );
  // بیمار فقط‌معلق و بیمار تاییدشده برای داکتر A
  await db.query(
    "INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, status) VALUES (?, ?, 'قلب', CURDATE(), '11:00:00', 'pending'), (?, ?, 'قلب', CURDATE(), '12:00:00', 'confirmed')",
    [pendingOnlyPatientId, docA.id, confirmedPatientId, docA.id]
  );
  await db.query("INSERT INTO prescriptions (patientId, doctorId, medicationName, dosage, frequency, duration) VALUES (?, ?, 'پاراستامول', '500mg', 'روزی ۲ بار', '۵ روز')", [confirmedPatientId, docA.id]).catch(() => {});
});

after(async () => {
  await db.query("DELETE FROM patients WHERE publicCode LIKE ?", [`${tag}-%`]);
  await stopServer();
  await closePool();
});

const get = (path, token = docA.token) => api("GET", path, { token });
const dbCount = async (sql, params = []) => Number((await db.query(sql, params))[0][0].c);

describe("RBAC", () => {
  for (const path of [
    "/api/doctors/me/appointments/list", "/api/doctors/me/appointments/stats",
    "/api/doctors/me/patients/list", "/api/doctors/me/patients/stats",
  ]) {
    test(`${path}: مهمان ۴۰۱، کاربر عادی و ادمین ۴۰۳`, async () => {
      assert.equal((await api("GET", path)).status, 401);
      assert.equal((await get(path, user.token)).status, 403);
      assert.equal((await get(path, admin.token)).status, 403);
    });
  }
});

describe("نوبت‌های من — فهرست سروری", () => {
  test("فقط یک صفحه برمی‌گردد و total از دیتابیس است", async () => {
    const t0 = Date.now();
    const res = await get("/api/doctors/me/appointments/list");
    const ms = Date.now() - t0;
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const expected = await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ?", [docA.id]);
    assert.equal(res.body.pagination.total, expected);
    assert.ok(expected >= APPTS);
    assert.equal(res.body.appointments.length, 20);
    assert.equal(res.body.pagination.limit, 20);
    assert.equal(res.body.pagination.totalPages, Math.ceil(expected / 20));
    assert.ok(JSON.stringify(res.body).length < 20000, "حجم پاسخ باید کوچک بماند");
    console.log(`  [perf] appointments/list با ${expected} نوبت: ${ms}ms، ${JSON.stringify(res.body).length} بایت`);
  });

  test("ردیف‌ها فقط ستون‌های لازم دارند (بدون یادداشت) و فقط نوبت‌های همین داکتر", async () => {
    const res = await get("/api/doctors/me/appointments/list?limit=100");
    for (const a of res.body.appointments) {
      assert.equal("notes" in a, false);
      assert.match(a.appointmentDate, /^\d{4}-\d{2}-\d{2}$/);
      assert.match(a.appointmentTime, /^\d{2}:\d{2}$/);
    }
    const ids = res.body.appointments.map((a) => a.id);
    const [[{ c }]] = await db.query("SELECT COUNT(*) AS c FROM appointments WHERE id IN (?) AND doctorId <> ?", [ids, docA.id]);
    assert.equal(Number(c), 0);
  });

  test("limit بیش از ۱۰۰ سقف می‌خورد؛ limit/page نامعتبر به پیش‌فرض برمی‌گردد", async () => {
    assert.equal((await get("/api/doctors/me/appointments/list?limit=100000")).body.appointments.length, 100);
    const bad = await get("/api/doctors/me/appointments/list?limit=abc&page=-4");
    assert.equal(bad.status, 200);
    assert.equal(bad.body.pagination.page, 1);
    assert.equal(bad.body.appointments.length, 20);
  });

  test("صفحه‌ی ۲ با صفحه‌ی ۱ تفاوت دارد و صفحه‌ی آخر ناقص است", async () => {
    const p1 = await get("/api/doctors/me/appointments/list?limit=50&page=1");
    const p2 = await get("/api/doctors/me/appointments/list?limit=50&page=2");
    const s1 = new Set(p1.body.appointments.map((a) => a.id));
    assert.ok(p2.body.appointments.every((a) => !s1.has(a.id)));
    const last = await get(`/api/doctors/me/appointments/list?limit=50&page=${p1.body.pagination.totalPages}`);
    assert.ok(last.body.appointments.length >= 1 && last.body.appointments.length <= 50);
  });

  test("فیلتر وضعیت در دیتابیس اجرا می‌شود", async () => {
    for (const status of STATUSES) {
      const res = await get(`/api/doctors/me/appointments/list?status=${status}&limit=100`);
      const expected = await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ? AND status = ?", [docA.id, status]);
      assert.equal(res.body.pagination.total, expected, status);
      assert.ok(res.body.appointments.every((a) => a.status === status));
    }
    // مقدار نامعتبر نادیده گرفته می‌شود (نه خطا و نه لیست خالی)
    const junk = await get("/api/doctors/me/appointments/list?status=evil'--");
    assert.equal(junk.status, 200);
    assert.equal(junk.body.pagination.total, await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ?", [docA.id]));
  });

  test("فیلتر بخش + ترکیب با وضعیت", async () => {
    const res = await get(`/api/doctors/me/appointments/list?department=${encodeURIComponent("اطفال")}&status=confirmed&limit=100`);
    const expected = await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ? AND department = 'اطفال' AND status = 'confirmed'", [docA.id]);
    assert.equal(res.body.pagination.total, expected);
    assert.ok(res.body.appointments.every((a) => a.department === "اطفال" && a.status === "confirmed"));
  });

  test("جستجو: نام، شماره پرونده، تلفن و شماره نوبت", async () => {
    const pid = patientIds[10];
    const [[p]] = await db.query("SELECT fullName, publicCode, phone FROM patients WHERE id = ?", [pid]);
    // نام و شماره پرونده «شامل‌بودن» هستند (…-11 داخل …-110 هم هست)؛ پس مرجع، همان LIKE در دیتابیس است. تلفن ۱۰ رقمیِ کامل یکتاست.
    for (const q of [p.fullName, p.publicCode, p.phone]) {
      const like = `%${q}%`;
      const expected = await dbCount(
        "SELECT COUNT(*) AS c FROM appointments a JOIN patients p ON p.id = a.patientId WHERE a.doctorId = ? AND (p.fullName LIKE ? OR p.publicCode LIKE ? OR p.phone LIKE ?)",
        [docA.id, like, like, like]
      );
      const res = await get(`/api/doctors/me/appointments/list?q=${encodeURIComponent(q)}&limit=100`);
      assert.equal(res.body.pagination.total, expected, q);
      assert.ok(res.body.appointments.some((a) => a.patientId === pid), q);
    }
    const exactPhone = await get(`/api/doctors/me/appointments/list?q=${encodeURIComponent(p.phone)}`);
    assert.ok(exactPhone.body.appointments.every((a) => a.patientId === pid));
    const [[appt]] = await db.query("SELECT id FROM appointments WHERE doctorId = ? ORDER BY id LIMIT 1", [docA.id]);
    // عبارت عددی علاوه بر شماره نوبت، داخل نام/کد/تلفن هم جستجو می‌شود (LIKE) و نتایج زیادند؛ پس صفحه‌ی اول
    // الزاماً شامل نوبت مورد نظر نیست. همه‌ی صفحه‌ها پیمایش می‌شوند و مجموع با شمارش مرجع دیتابیس مقایسه می‌شود.
    const idLike = `%${appt.id}%`;
    const expectedById = await dbCount(
      "SELECT COUNT(*) AS c FROM appointments a JOIN patients p ON p.id = a.patientId WHERE a.doctorId = ? AND (p.fullName LIKE ? OR p.publicCode LIKE ? OR p.phone LIKE ? OR a.id = ?)",
      [docA.id, idLike, idLike, idLike, appt.id]
    );
    let found = false;
    let seen = 0;
    for (let page = 1; page <= 50 && !found; page += 1) {
      const byId = await get(`/api/doctors/me/appointments/list?q=${appt.id}&limit=100&page=${page}`);
      assert.equal(byId.body.pagination.total, expectedById);
      seen += byId.body.appointments.length;
      found = byId.body.appointments.some((a) => a.id === appt.id);
      if (seen >= expectedById) break;
    }
    assert.ok(found, `نوبت ${appt.id} در نتایج جستجوی عددی پیدا نشد`);
  });

  test("جستجو: % و _ متن عادی هستند و همه‌چیز را برنمی‌گردانند؛ SQL injection اثری ندارد", async () => {
    for (const q of ["%", "_", "%%%", "' OR 1=1 --", "\\"]) {
      const res = await get(`/api/doctors/me/appointments/list?q=${encodeURIComponent(q)}`);
      assert.equal(res.status, 200, q);
      assert.equal(res.body.pagination.total, 0, `q=${q}`);
    }
  });

  test("جستجو داده‌ی داکتر دیگر را نشت نمی‌دهد", async () => {
    const [[p]] = await db.query("SELECT publicCode FROM patients WHERE id = ?", [outsiderPatientId]);
    const res = await get(`/api/doctors/me/appointments/list?q=${encodeURIComponent(p.publicCode)}`);
    assert.equal(res.body.pagination.total, 0);
  });

  test("فیلتر تاریخ: امروز، بازه‌ی دلخواه، مقدار نامعتبر نادیده گرفته می‌شود", async () => {
    const today = await get("/api/doctors/me/appointments/list?range=today&limit=100");
    const expectedToday = await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ? AND appointmentDate = CURDATE()", [docA.id]);
    // CURDATE سرور دیتابیس و منطقه‌ی زمانی سیستم (Asia/Kabul) ممکن است حوالی نیمه‌شب فرق کنند؛ فقط سازگاری را می‌سنجیم
    assert.ok(today.body.pagination.total >= 0);
    assert.ok(today.body.appointments.every((a) => a.appointmentDate === today.body.appointments[0].appointmentDate));
    if (expectedToday > 0 && today.body.pagination.total > 0) assert.ok(today.body.pagination.total <= expectedToday + 5);

    const [[{ lo, hi }]] = await db.query("SELECT DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL -30 DAY), '%Y-%m-%d') AS lo, DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL -20 DAY), '%Y-%m-%d') AS hi");
    const custom = await get(`/api/doctors/me/appointments/list?from=${lo}&to=${hi}&limit=100`);
    const expected = await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ? AND appointmentDate BETWEEN ? AND ?", [docA.id, lo, hi]);
    assert.equal(custom.body.pagination.total, expected);
    assert.ok(custom.body.appointments.every((a) => a.appointmentDate >= lo && a.appointmentDate <= hi));

    const junk = await get("/api/doctors/me/appointments/list?from=not-a-date&to=2026-13-45");
    assert.equal(junk.status, 200);
    assert.equal(junk.body.pagination.total, await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ?", [docA.id]));

    for (const range of ["week", "month"]) {
      const r = await get(`/api/doctors/me/appointments/list?range=${range}&limit=100`);
      assert.equal(r.status, 200);
    }
  });

  test("مرتب‌سازی جدیدترین/قدیمی‌ترین", async () => {
    const newest = (await get("/api/doctors/me/appointments/list?sort=newest&limit=100")).body.appointments;
    const oldest = (await get("/api/doctors/me/appointments/list?sort=oldest&limit=100")).body.appointments;
    const key = (a) => `${a.appointmentDate} ${a.appointmentTime}`;
    for (let i = 1; i < newest.length; i += 1) assert.ok(key(newest[i - 1]) >= key(newest[i]));
    for (let i = 1; i < oldest.length; i += 1) assert.ok(key(oldest[i - 1]) <= key(oldest[i]));
    assert.ok(key(newest[0]) > key(oldest[0]));
  });
});

describe("نوبت‌های من — آمار و جزئیات", () => {
  test("آمار دقیقاً برابر شمارش دیتابیس است و فهرست بخش‌ها می‌دهد", async () => {
    const res = await get("/api/doctors/me/appointments/stats");
    assert.equal(res.status, 200);
    const s = res.body.stats;
    for (const st of STATUSES) assert.equal(s[st], await dbCount("SELECT COUNT(*) AS c FROM appointments WHERE doctorId = ? AND status = ?", [docA.id, st]));
    assert.equal(s.total, s.pending + s.confirmed + s.completed + s.cancelled);
    assert.deepEqual([...s.departments].sort(), [...DEPTS].sort());
  });

  test("جزئیات نوبت خودش ۲۰۰ و شامل یادداشت و اطلاعات بیمار است", async () => {
    const [[a]] = await db.query("SELECT id FROM appointments WHERE doctorId = ? AND notes IS NOT NULL LIMIT 1", [docA.id]);
    const res = await get(`/api/doctors/me/appointments/${a.id}`);
    assert.equal(res.status, 200);
    assert.equal(res.body.appointment.notes, "یادداشت محرمانه‌ی بیمار");
    assert.ok(res.body.appointment.patientCode.startsWith(tag));
  });

  test("نوبت داکتر دیگر ۴۰۴ و شناسه‌ی نامعتبر ۴۰۰", async () => {
    const [[b]] = await db.query("SELECT id FROM appointments WHERE doctorId = ? LIMIT 1", [docB.id]);
    assert.equal((await get(`/api/doctors/me/appointments/${b.id}`)).status, 404);
    assert.equal((await get("/api/doctors/me/appointments/abc")).status, 400);
    assert.equal((await get("/api/doctors/me/appointments/99999999")).status, 404);
  });

  test("مسیر قدیمی /me/appointments بدون تغییر کار می‌کند", async () => {
    const res = await get("/api/doctors/me/appointments");
    assert.equal(res.status, 200);
    assert.ok(res.body.appointments.length >= APPTS);
  });
});

describe("بیماران من — فهرست سروری", () => {
  test("ردیف‌ها بیمار یکتا هستند و total برابر شمارش یکتا در دیتابیس", async () => {
    const t0 = Date.now();
    const res = await get("/api/doctors/me/patients/list?limit=100");
    const ms = Date.now() - t0;
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const expected = await dbCount("SELECT COUNT(DISTINCT patientId) AS c FROM appointments WHERE doctorId = ?", [docA.id]);
    assert.equal(res.body.pagination.total, expected);
    assert.equal(res.body.patients.length, 100);
    assert.equal(new Set(res.body.patients.map((p) => p.patientId)).size, 100);
    assert.ok(JSON.stringify(res.body).length < 60000);
    console.log(`  [perf] patients/list با ${expected} بیمار یکتا: ${ms}ms`);
    const row = res.body.patients[0];
    for (const k of ["patientId", "patientCode", "patientName", "gender", "age", "phone", "department", "lastVisitDate", "isActive", "hasConfirmed"]) assert.ok(k in row, k);
    assert.equal("email" in row, false);
  });

  test("جستجو: نام، شماره پرونده، تلفن، ایمیل", async () => {
    const pid = patientIds[4]; // i=5 → ایمیل دارد
    const [[p]] = await db.query("SELECT fullName, publicCode, phone, email FROM patients WHERE id = ?", [pid]);
    assert.ok(p.email);
    for (const q of [p.fullName, p.publicCode, p.phone, p.email]) {
      const like = `%${q}%`;
      const expected = await dbCount(
        "SELECT COUNT(DISTINCT a.patientId) AS c FROM appointments a JOIN patients p ON p.id = a.patientId WHERE a.doctorId = ? AND (p.fullName LIKE ? OR p.phone LIKE ? OR p.email LIKE ? OR p.publicCode LIKE ?)",
        [docA.id, like, like, like, like]
      );
      const res = await get(`/api/doctors/me/patients/list?q=${encodeURIComponent(q)}&limit=100`);
      assert.equal(res.body.pagination.total, expected, q);
      assert.ok(res.body.patients.some((x) => x.patientId === pid), q);
    }
    // تلفن/ایمیل کامل یکتا هستند
    for (const q of [p.phone, p.email]) {
      const res = await get(`/api/doctors/me/patients/list?q=${encodeURIComponent(q)}`);
      assert.equal(res.body.pagination.total, 1, q);
      assert.equal(res.body.patients[0].patientId, pid);
    }
    assert.equal((await get(`/api/doctors/me/patients/list?q=${encodeURIComponent("%")}`)).body.pagination.total, 0);
  });

  test("بیمار داکتر دیگر در جستجو دیده نمی‌شود", async () => {
    const [[p]] = await db.query("SELECT publicCode FROM patients WHERE id = ?", [outsiderPatientId]);
    assert.equal((await get(`/api/doctors/me/patients/list?q=${encodeURIComponent(p.publicCode)}`)).body.pagination.total, 0);
  });

  test("فیلتر جنسیت، بخش و وضعیت در دیتابیس", async () => {
    const male = await get("/api/doctors/me/patients/list?gender=male&limit=100");
    const expMale = await dbCount("SELECT COUNT(DISTINCT a.patientId) AS c FROM appointments a JOIN patients p ON p.id = a.patientId WHERE a.doctorId = ? AND p.gender = 'male'", [docA.id]);
    assert.equal(male.body.pagination.total, expMale);
    assert.ok(male.body.patients.every((p) => p.gender === "male"));

    const dept = await get(`/api/doctors/me/patients/list?department=${encodeURIComponent("داخله")}`);
    const expDept = await dbCount("SELECT COUNT(DISTINCT patientId) AS c FROM appointments WHERE doctorId = ? AND department = 'داخله'", [docA.id]);
    assert.equal(dept.body.pagination.total, expDept);

    const inactive = await get("/api/doctors/me/patients/list?status=inactive&limit=100");
    const expInactive = await dbCount("SELECT COUNT(*) AS c FROM (SELECT patientId FROM appointments WHERE doctorId = ? GROUP BY patientId HAVING SUM(status <> 'cancelled') = 0) t", [docA.id]);
    assert.equal(inactive.body.pagination.total, expInactive);
    assert.ok(expInactive >= 1);
    assert.ok(inactive.body.patients.every((p) => p.isActive === false));
    const active = await get("/api/doctors/me/patients/list?status=active");
    assert.equal(active.body.pagination.total + inactive.body.pagination.total, (await get("/api/doctors/me/patients/list")).body.pagination.total);
  });

  test("فیلتر تاریخ آخرین مراجعه و مرتب‌سازی", async () => {
    const [[{ lo, hi }]] = await db.query("SELECT DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL -100 DAY), '%Y-%m-%d') AS lo, DATE_FORMAT(DATE_ADD(CURDATE(), INTERVAL -50 DAY), '%Y-%m-%d') AS hi");
    const res = await get(`/api/doctors/me/patients/list?from=${lo}&to=${hi}&limit=100`);
    assert.equal(res.status, 200);
    assert.ok(res.body.patients.every((p) => p.lastVisitDate >= lo && p.lastVisitDate <= hi));
    const byName = (await get("/api/doctors/me/patients/list?sort=name&limit=100")).body.patients.map((p) => p.patientName);
    assert.deepEqual(byName, [...byName].sort((x, y) => x.localeCompare(y, "en")) );
  });

  test("مسیر قدیمی /me/patients (ردیف به‌ازای نوبت) بدون تغییر کار می‌کند", async () => {
    const res = await get("/api/doctors/me/patients?limit=10");
    assert.equal(res.status, 200);
    assert.ok("appointmentId" in res.body.patients[0]);
  });
});

describe("بیماران من — آمار و جزئیات", () => {
  test("آمار از دیتابیس: کل، فعال، امروز، هفته", async () => {
    const res = await get("/api/doctors/me/patients/stats");
    assert.equal(res.status, 200);
    const s = res.body.stats;
    assert.equal(s.total, await dbCount("SELECT COUNT(DISTINCT patientId) AS c FROM appointments WHERE doctorId = ?", [docA.id]));
    assert.equal(s.active, await dbCount("SELECT COUNT(*) AS c FROM (SELECT patientId FROM appointments WHERE doctorId = ? GROUP BY patientId HAVING SUM(status <> 'cancelled') > 0) t", [docA.id]));
    assert.ok(s.active < s.total);
    assert.ok(s.today >= 2 && s.week >= s.today);
    assert.deepEqual([...s.departments].sort(), [...DEPTS].sort());
  });

  test("جزئیات بیمارِ تاییدشده: اطلاعات کامل + نوبت‌ها + خلاصه سوابق", async () => {
    const res = await get(`/api/doctors/me/patients/${confirmedPatientId}`);
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const p = res.body.patient;
    assert.equal(p.patientId, confirmedPatientId);
    assert.equal(p.hasConfirmed, true);
    assert.ok(p.dateOfBirth);
    assert.ok(p.summary && typeof p.summary.prescriptionCount === "number" && typeof p.summary.recordCount === "number");
    assert.ok(p.appointments.length >= 1);
  });

  test("بیمار فقط‌معلق: ایمیل/تاریخ تولد/آدرس/سوابق null (مثل قانون فهرست قدیمی)", async () => {
    const res = await get(`/api/doctors/me/patients/${pendingOnlyPatientId}`);
    assert.equal(res.status, 200);
    const p = res.body.patient;
    assert.equal(p.hasConfirmed, false);
    assert.equal(p.summary, null);
    assert.equal(p.email, null);
    assert.equal(p.dateOfBirth, null);
    assert.equal(p.address, null);
  });

  test("بیمار داکتر دیگر ۴۰۴؛ شناسه نامعتبر ۴۰۰", async () => {
    assert.equal((await get(`/api/doctors/me/patients/${outsiderPatientId}`)).status, 404);
    assert.equal((await get("/api/doctors/me/patients/xyz")).status, 400);
    assert.equal((await get(`/api/doctors/me/patients/${confirmedPatientId}`, docB.token)).status, 404);
  });
});

import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import os from "os";
import path from "path";
import { closePool } from "./testEnv.js";

// پوشه‌ی پشتیبان‌ها را به یک مسیر موقت می‌بریم تا تست‌ها هرگز با فایل‌های واقعی
// private-uploads/backups برخورد نکنند. باید قبل از import شدن utils/backup.js (که از طریق
// testApp → routes → controller وارد می‌شود) تنظیم شود، پس testApp را دینامیک import می‌کنیم.
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), "bk-folders-test-"));
process.env.BACKUP_STORAGE_DIR = TMP;
const { startServer, stopServer, api, makeSession } = await import("./testApp.js");
const { setSetting } = await import("../models/Settings.js");
const { default: db } = await import("../db.js");
const { stopBackupScheduler, setCustomBackupDir } = await import("../utils/backup.js");

let superadmin;
let admin;
let folderA; // { id, name }
let folderB;
let defaultBackup; // بکاپ ساخته‌شده در پوشه‌ی پیش‌فرض
let backupInA;

const FOLDER_ID = /^f-[0-9a-f]{8}$/;
const FILENAME = /^backup-manual-\d{8}-\d{6}-[0-9a-f]{8}\.sql$/;

const list = (folder) => api("GET", `/api/superadmin/backups${folder ? `?folder=${encodeURIComponent(folder)}` : ""}`, { token: superadmin.token });
const createFolder = (body) => api("POST", "/api/superadmin/backups/folders", { token: superadmin.token, body });
const activate = (id) => api("POST", `/api/superadmin/backups/folders/${encodeURIComponent(id)}/activate`, { token: superadmin.token });
const manualBackup = () => api("POST", "/api/superadmin/backups", { token: superadmin.token });
const folderDir = (id) => (id === "default" ? TMP : path.join(TMP, id));

before(async () => {
  await startServer();
  superadmin = await makeSession("superadmin");
  admin = await makeSession("admin");
  await setSetting("backupRetentionCount", "50");
  await setSetting("backupActiveFolder", "default");
});
after(async () => {
  stopBackupScheduler(); // بازیابی، زمان‌بند cron را دوباره می‌سازد؛ بدون توقف، پروسه‌ی تست باز می‌ماند
  await stopServer();
  await closePool();
  fs.rmSync(TMP, { recursive: true, force: true });
});

describe("دسترسی (فقط سوپرادمین، در بک‌اند)", () => {
  const routes = [
    ["POST", "/api/superadmin/backups/folders", { name: "تست دسترسی" }],
    ["POST", "/api/superadmin/backups/folders/pick"],
    ["PUT", "/api/superadmin/backups/folders/f-00000000", { name: "تست" }],
    ["POST", "/api/superadmin/backups/folders/f-00000000/activate"],
    ["DELETE", "/api/superadmin/backups/folders/f-00000000"],
  ];
  for (const [method, url, body] of routes) {
    test(`${method} ${url}: بدون توکن ۴۰۱ و برای ادمین ۴۰۳`, async () => {
      const anon = await api(method, url, { body });
      assert.equal(anon.status, 401);
      const asAdmin = await api(method, url, { token: admin.token, body });
      assert.equal(asAdmin.status, 403);
    });
  }
  test("ادمین معمولی نمی‌تواند فهرست پوشه‌ها را ببیند", async () => {
    const res = await api("GET", "/api/superadmin/backups", { token: admin.token });
    assert.equal(res.status, 403);
  });
});

describe("ایجاد و فهرست پوشه‌ها", () => {
  test("پیش از هر چیز فقط «پوشه‌ی پیش‌فرض» وجود دارد و فعال است", async () => {
    const res = await list();
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.activeFolderId, "default");
    assert.equal(res.body.selectedFolderId, "default");
    assert.equal(res.body.activeFolderAvailable, true);
    const def = res.body.folders.find((f) => f.id === "default");
    assert.ok(def && def.isDefault && def.isActive);
    assert.ok(Array.isArray(res.body.backups));
    assert.ok(res.body.schedule && res.body.schedule.timezone);
  });

  test("ایجاد پوشه موفق است و روی دیسک با شناسه‌ی کنترل‌شده ساخته می‌شود (نه با نام کاربر)", async () => {
    const res = await createFolder({ name: "  بکاپ‌های   روزانه ", description: "نسخه‌های روزانه" });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    folderA = res.body.folder;
    assert.match(folderA.id, FOLDER_ID);
    assert.equal(folderA.name, "بکاپ‌های روزانه"); // فاصله‌های اضافی نرمال می‌شود
    assert.equal(folderA.description, "نسخه‌های روزانه");
    assert.equal(folderA.count, 0);
    assert.ok(fs.statSync(folderDir(folderA.id)).isDirectory());
    assert.ok(!fs.existsSync(path.join(TMP, folderA.name)));

    const res2 = await createFolder({ name: "نسخه‌های مهم" });
    assert.equal(res2.status, 201);
    folderB = res2.body.folder;
  });

  test("نام تکراری (حتی با حروف/فاصله متفاوت) رد می‌شود", async () => {
    const res = await createFolder({ name: "بکاپ‌های روزانه" });
    assert.equal(res.status, 409);
    const resDefault = await createFolder({ name: "پوشه پیش‌فرض" });
    assert.equal(resDefault.status, 409);
  });

  test("نام نامعتبر رد می‌شود", async () => {
    for (const bad of [undefined, null, 42, "", " ", "ا", "x".repeat(51), "<script>", "a\u0000b"]) {
      const res = await createFolder({ name: bad });
      assert.equal(res.status, 400, `name=${JSON.stringify(bad)} → ${res.status}`);
    }
    const longDesc = await createFolder({ name: "توضیح طولانی", description: "x".repeat(201) });
    assert.equal(longDesc.status, 400);
  });

  test("نامی مثل ../../etc فقط یک نام نمایشی است و هیچ مسیری روی دیسک ساخته نمی‌شود", async () => {
    const before = fs.readdirSync(TMP).sort();
    const res = await createFolder({ name: "../../etc" });
    assert.equal(res.status, 201);
    const after = fs.readdirSync(TMP).sort();
    const created = after.filter((n) => !before.includes(n));
    assert.equal(created.length, 1);
    assert.match(created[0], FOLDER_ID);
    // پاک‌سازی (پوشه‌ی خالی و غیرفعال است)
    const del = await api("DELETE", `/api/superadmin/backups/folders/${res.body.folder.id}`, { token: superadmin.token });
    assert.equal(del.status, 200);
  });

  test("فهرست، پوشه‌های ساخته‌شده را با تعداد و مسیر نسبی برمی‌گرداند", async () => {
    const res = await list();
    const a = res.body.folders.find((f) => f.id === folderA.id);
    assert.ok(a);
    assert.equal(a.count, 0);
    assert.equal(a.isActive, false);
    assert.equal(a.writable, true);
    assert.ok(a.path.endsWith(`/${folderA.id}`) && !path.isAbsolute(a.path));
  });
});

describe("انتخاب پوشه‌ی فعال و ذخیره‌ی بکاپ‌ها", () => {
  test("بکاپ دستی در پوشه‌ی فعال ذخیره می‌شود", async () => {
    const act = await activate(folderA.id);
    assert.equal(act.status, 200, JSON.stringify(act.body));

    const res = await manualBackup();
    assert.equal(res.status, 201, JSON.stringify(res.body));
    backupInA = res.body.backup;
    assert.equal(backupInA.folderId, folderA.id);
    assert.match(backupInA.filename, FILENAME);
    assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)));
    assert.ok(!fs.existsSync(path.join(TMP, backupInA.filename)));
    // هیچ فایل موقتی (.part) باقی نمانده است
    assert.deepEqual(fs.readdirSync(folderDir(folderA.id)).filter((n) => n.endsWith(".part")), []);

    const inA = await list(folderA.id);
    assert.equal(inA.body.backups.length, 1);
    assert.equal(inA.body.backups[0].filename, backupInA.filename);
    assert.equal(inA.body.backups[0].status, "ok");
    assert.equal(inA.body.backups[0].folderId, folderA.id);
    const inDefault = await list("default");
    assert.ok(!inDefault.body.backups.some((b) => b.filename === backupInA.filename));
  });

  test("پوشه‌ی فعال در دیتابیس (settings) ذخیره می‌شود و پس از راه‌اندازی مجدد هم همان می‌ماند", async () => {
    const [[row]] = await db.query("SELECT value FROM settings WHERE `key` = 'backupActiveFolder'");
    assert.equal(row.value, folderA.id);
    const res = await list();
    assert.equal(res.body.activeFolderId, folderA.id);
    assert.equal(res.body.selectedFolderId, folderA.id); // پیش‌فرض نمایش = پوشه‌ی فعال
  });

  test("تغییر پوشه‌ی فعال، بکاپ‌های قبلی را حذف یا جابه‌جا نمی‌کند", async () => {
    const act = await activate("default");
    assert.equal(act.status, 200);
    const res = await manualBackup();
    assert.equal(res.status, 201);
    defaultBackup = res.body.backup;
    assert.equal(defaultBackup.folderId, "default");

    assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)), "بکاپ پوشه‌ی قبلی باید سر جایش باشد");
    assert.ok(fs.existsSync(path.join(TMP, defaultBackup.filename)));
    const inA = await list(folderA.id);
    assert.equal(inA.body.backups.length, 1);
  });

  test("فعال‌سازی پوشه‌ی ناموجود یا شناسه‌ی نامعتبر رد می‌شود و پوشه‌ی فعال تغییر نمی‌کند", async () => {
    for (const id of ["f-deadbeef", "..", "../..", "f-ZZZZZZZZ", "default%2F..", "x"]) {
      const res = await activate(id);
      assert.equal(res.status, 404, `${id} → ${res.status}`);
    }
    const [[row]] = await db.query("SELECT value FROM settings WHERE `key` = 'backupActiveFolder'");
    assert.equal(row.value, "default");
  });

  test("کلید backupActiveFolder از مسیر عمومی تنظیمات قابل تغییر نیست", async () => {
    const res = await api("PUT", "/api/superadmin/settings", { token: superadmin.token, body: { backupActiveFolder: folderB.id } });
    assert.equal(res.status, 400);
    const [[row]] = await db.query("SELECT value FROM settings WHERE `key` = 'backupActiveFolder'");
    assert.equal(row.value, "default");
  });

  test("نام فایل بکاپ شامل تاریخ/ساعت است و یکتاست", async () => {
    assert.notEqual(defaultBackup.filename, backupInA.filename);
    assert.match(defaultBackup.filename, /^backup-manual-\d{8}-\d{6}-[0-9a-f]{8}\.sql$/);
  });
});

describe("نگهداری (Retention) فقط در همان پوشه", () => {
  test("حذف قدیمی‌ترها فقط داخل پوشه‌ی مقصد انجام می‌شود", async () => {
    await setSetting("backupRetentionCount", "1");
    try {
      assert.equal((await activate(folderB.id)).status, 200);
      const first = await manualBackup();
      const second = await manualBackup();
      assert.equal(first.status, 201);
      assert.equal(second.status, 201);
      const inB = await list(folderB.id);
      assert.equal(inB.body.backups.length, 1);
      assert.equal(inB.body.backups[0].filename, second.body.backup.filename);
      // پوشه‌های دیگر دست‌نخورده‌اند
      assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)));
      assert.ok(fs.existsSync(path.join(TMP, defaultBackup.filename)));
    } finally {
      await setSetting("backupRetentionCount", "50");
      await activate("default");
    }
  });
});

describe("دانلود / حذف با پوشه و امنیت مسیر", () => {
  test("دانلود از پوشه‌ی درست موفق است", async () => {
    const res = await api("GET", `/api/superadmin/backups/${backupInA.filename}/download?folder=${folderA.id}`, { token: superadmin.token });
    assert.equal(res.status, 200);
    assert.ok(res.raw.toString("utf8").includes("پشتیبان دیتابیس"));
  });

  test("بدون پارامتر پوشه هم فایل در همه‌ی پوشه‌ها پیدا می‌شود (سازگاری با کلاینت قبلی)", async () => {
    const res = await api("GET", `/api/superadmin/backups/${backupInA.filename}/download`, { token: superadmin.token });
    assert.equal(res.status, 200);
  });

  test("فایل در پوشه‌ی اشتباه ۴۰۴ است", async () => {
    const res = await api("GET", `/api/superadmin/backups/${backupInA.filename}/download?folder=default`, { token: superadmin.token });
    assert.equal(res.status, 404);
  });

  test("Path Traversal در پارامتر پوشه و نام فایل مسدود است", async () => {
    const attempts = [
      `/api/superadmin/backups/${backupInA.filename}/download?folder=..`,
      `/api/superadmin/backups/${backupInA.filename}/download?folder=${encodeURIComponent("../..")}`,
      `/api/superadmin/backups/${backupInA.filename}/download?folder=${encodeURIComponent(`../${path.basename(TMP)}/${folderA.id}`)}`,
      `/api/superadmin/backups/${encodeURIComponent("../../etc/passwd")}/download`,
      `/api/superadmin/backups/${encodeURIComponent(`${folderA.id}/${backupInA.filename}`)}/download`,
      `/api/superadmin/backups/${encodeURIComponent("..\\..\\secret.sql")}/download`,
    ];
    for (const url of attempts) {
      const res = await api("GET", url, { token: superadmin.token });
      assert.ok([400, 404].includes(res.status), `${url} → ${res.status}`);
    }
    const del = await api("DELETE", `/api/superadmin/backups/${backupInA.filename}?folder=${encodeURIComponent("../..")}`, { token: superadmin.token });
    assert.equal(del.status, 404);
    assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)));
  });

  test("حذف بکاپ با پوشه‌ی اشتباه انجام نمی‌شود؛ با پوشه‌ی درست انجام می‌شود", async () => {
    const wrong = await api("DELETE", `/api/superadmin/backups/${backupInA.filename}?folder=default`, { token: superadmin.token });
    assert.equal(wrong.status, 404);
    assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)));
  });
});

describe("تغییر نام و حذف پوشه", () => {
  test("تغییر نام فقط متادیتاست و فایل‌ها سر جای خود می‌مانند", async () => {
    const res = await api("PUT", `/api/superadmin/backups/folders/${folderA.id}`, { token: superadmin.token, body: { name: "آرشیو روزانه", description: "" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.folder.name, "آرشیو روزانه");
    assert.equal(res.body.folder.count, 1);
    assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)));
    folderA.name = "آرشیو روزانه";
  });

  test("تغییر نام به نام تکراری، به پوشه‌ی پیش‌فرض، یا شناسه‌ی نامعتبر رد می‌شود", async () => {
    const dup = await api("PUT", `/api/superadmin/backups/folders/${folderA.id}`, { token: superadmin.token, body: { name: folderB.name } });
    assert.equal(dup.status, 409);
    const def = await api("PUT", "/api/superadmin/backups/folders/default", { token: superadmin.token, body: { name: "چیز دیگر" } });
    assert.equal(def.status, 409);
    const bad = await api("PUT", `/api/superadmin/backups/folders/${encodeURIComponent("../x")}`, { token: superadmin.token, body: { name: "چیز دیگر" } });
    assert.equal(bad.status, 404);
    const empty = await api("PUT", `/api/superadmin/backups/folders/${folderA.id}`, { token: superadmin.token, body: {} });
    assert.equal(empty.status, 400);
  });

  test("پوشه‌ی دارای بکاپ، پوشه‌ی فعال و پوشه‌ی پیش‌فرض حذف نمی‌شوند", async () => {
    const hasBackup = await api("DELETE", `/api/superadmin/backups/folders/${folderA.id}`, { token: superadmin.token });
    assert.equal(hasBackup.status, 409);
    assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)), "فایل نباید حذف شده باشد");

    assert.equal((await activate(folderB.id)).status, 200);
    const active = await api("DELETE", `/api/superadmin/backups/folders/${folderB.id}`, { token: superadmin.token });
    assert.equal(active.status, 409);
    assert.ok(fs.existsSync(folderDir(folderB.id)));
    assert.equal((await activate("default")).status, 200);

    const def = await api("DELETE", "/api/superadmin/backups/folders/default", { token: superadmin.token });
    assert.equal(def.status, 409);
    assert.ok(fs.existsSync(path.join(TMP, defaultBackup.filename)));
  });

  test("پوشه‌ی خالی و غیرفعال حذف می‌شود و حذف هرگز بازگشتی نیست", async () => {
    const tmp = await createFolder({ name: "موقت برای حذف" });
    assert.equal(tmp.status, 201);
    const id = tmp.body.folder.id;
    // یک فایل ناشناس داخل پوشه می‌گذاریم؛ حتی فایل غیرپشتیبان هم باعث رد حذف می‌شود
    fs.writeFileSync(path.join(folderDir(id), "notes.txt"), "x");
    const blocked = await api("DELETE", `/api/superadmin/backups/folders/${id}`, { token: superadmin.token });
    assert.equal(blocked.status, 409);
    assert.ok(fs.existsSync(path.join(folderDir(id), "notes.txt")));
    fs.unlinkSync(path.join(folderDir(id), "notes.txt"));

    const ok = await api("DELETE", `/api/superadmin/backups/folders/${id}`, { token: superadmin.token });
    assert.equal(ok.status, 200, JSON.stringify(ok.body));
    assert.ok(!fs.existsSync(folderDir(id)));
    const gone = await api("DELETE", `/api/superadmin/backups/folders/${id}`, { token: superadmin.token });
    assert.equal(gone.status, 404);
  });
});

describe("پوشه‌ی غیرقابل‌دسترس و فایل‌های ناقص", () => {
  test("اگر پوشه‌ی فعال از روی دیسک حذف شده باشد: خطای واضح، بدون فایل جدید و بدون آسیب به بکاپ‌های قبلی", async () => {
    const temp = await createFolder({ name: "پوشه‌ی ناپدیدشونده" });
    const id = temp.body.folder.id;
    assert.equal((await activate(id)).status, 200);
    fs.rmSync(folderDir(id), { recursive: true });

    const before = fs.readdirSync(TMP).sort();
    const res = await manualBackup();
    assert.equal(res.status, 409, JSON.stringify(res.body));
    assert.ok(res.body.message.includes("پوشه"));
    assert.deepEqual(fs.readdirSync(TMP).sort(), before, "هیچ فایل/پوشه‌ای نباید ساخته یا حذف شده باشد");
    assert.ok(fs.existsSync(path.join(TMP, defaultBackup.filename)));

    const overview = await list();
    assert.equal(overview.status, 200);
    assert.equal(overview.body.activeFolderAvailable, false);
    assert.ok(overview.body.activeFolderMessage);
    assert.equal(overview.body.selectedFolderId, "default"); // به پوشه‌ی پیش‌فرض برمی‌گردد
    assert.ok(overview.body.backups.some((b) => b.filename === defaultBackup.filename));

    assert.equal((await activate("default")).status, 200);
    assert.equal((await manualBackup()).status, 201);
  });

  test("فایل خالی یا ناقص «سالم» معرفی نمی‌شود و بازیابی‌اش رد می‌شود", async () => {
    const emptyName = "backup-manual-20200101-000000-aaaaaaaa.sql";
    const truncatedName = "backup-manual-20200102-000000-bbbbbbbb.sql";
    fs.writeFileSync(path.join(TMP, emptyName), "");
    const real = fs.readFileSync(path.join(TMP, defaultBackup.filename), "utf8");
    fs.writeFileSync(path.join(TMP, truncatedName), real.slice(0, Math.floor(real.length / 2)));

    const res = await list("default");
    const byName = Object.fromEntries(res.body.backups.map((b) => [b.filename, b]));
    assert.equal(byName[emptyName].status, "corrupt");
    assert.equal(byName[truncatedName].status, "corrupt");
    assert.equal(byName[defaultBackup.filename].status, "ok");

    for (const name of [emptyName, truncatedName]) {
      const restore = await api("POST", `/api/superadmin/backups/${name}/restore`, { token: superadmin.token, body: { confirm: name, folder: "default" } });
      assert.equal(restore.status, 400, `${name} → ${restore.status} ${JSON.stringify(restore.body)}`);
    }

    // «آخرین بکاپ موفق» پوشه، فایل ناقصِ جدیدتر را حساب نمی‌کند
    const futureCorrupt = "backup-manual-20990101-000000-cccccccc.sql";
    fs.writeFileSync(path.join(TMP, futureCorrupt), "");
    const overview = await list("default");
    const def = overview.body.folders.find((f) => f.id === "default");
    const newestOk = overview.body.backups.filter((b) => b.status === "ok").map((b) => new Date(b.createdAt).getTime()).sort((a, b) => b - a)[0];
    assert.equal(new Date(def.lastBackupAt).getTime(), newestOk);

    for (const name of [emptyName, truncatedName, futureCorrupt]) fs.unlinkSync(path.join(TMP, name));
  });

  test("بازیابی بدون تایید نام دقیق فایل، یا با پوشه‌ی مخرب، انجام نمی‌شود", async () => {
    const noConfirm = await api("POST", `/api/superadmin/backups/${backupInA.filename}/restore`, { token: superadmin.token, body: { folder: folderA.id } });
    assert.equal(noConfirm.status, 400);
    const badFolder = await api("POST", `/api/superadmin/backups/${backupInA.filename}/restore`, {
      token: superadmin.token, body: { confirm: backupInA.filename, folder: "../.." },
    });
    assert.equal(badFolder.status, 404);
  });
});

describe("حذف بکاپ و بازیابی از پوشه‌ی غیرپیش‌فرض (انتهایی؛ دیتابیس تست را جایگزین می‌کند)", () => {
  test("بازیابی از بکاپِ داخل پوشه‌ی A موفق است و پشتیبان ایمنی در پوشه‌ی فعال ساخته می‌شود", async () => {
    assert.equal((await activate("default")).status, 200);
    const before = (await list("default")).body.backups.length;
    const res = await api("POST", `/api/superadmin/backups/${backupInA.filename}/restore`, {
      token: superadmin.token, body: { confirm: backupInA.filename, folder: folderA.id },
    });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const after = await list("default");
    assert.ok(after.body.backups.length >= before + 1);
    assert.ok(after.body.backups.some((b) => b.type === "pre-restore"));
    assert.ok(fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)), "فایل منبع پس از بازیابی هنوز موجود است");
  });

  test("حذف بکاپ از پوشه‌اش انجام می‌شود", async () => {
    const del = await api("DELETE", `/api/superadmin/backups/${backupInA.filename}?folder=${folderA.id}`, { token: superadmin.token });
    assert.equal(del.status, 200, JSON.stringify(del.body));
    assert.ok(!fs.existsSync(path.join(folderDir(folderA.id), backupInA.filename)));
    const inA = await list(folderA.id);
    assert.equal(inA.body.backups.length, 0);
  });
});

describe("پوشه‌ی انتخاب‌شده روی کامپیوتر (مسیر دلخواه)", () => {
  // پنجره‌ی انتخاب پوشه‌ی سیستم‌عامل در تست باز نمی‌شود؛ خروجی آن (مسیر انتخاب‌شده) مستقیم به
  // setCustomBackupDir داده می‌شود که همان تابعی است که کنترلر بعد از انتخاب کاربر صدا می‌زند.
  const CUSTOM_TMP = fs.mkdtempSync(path.join(os.tmpdir(), "bk-custom-test-"));

  test("درایو/ریشه، مسیر نسبی و فایل به‌جای پوشه رد می‌شوند", async () => {
    const root = path.parse(CUSTOM_TMP).root;
    await assert.rejects(() => setCustomBackupDir(root), { code: "FOLDER_PATH_INVALID" });
    await assert.rejects(() => setCustomBackupDir("relative/path"), { code: "FOLDER_PATH_INVALID" });
    const file = path.join(CUSTOM_TMP, "not-a-folder.txt");
    fs.writeFileSync(file, "x");
    await assert.rejects(() => setCustomBackupDir(file), { code: "FOLDER_NOT_FOUND" });
    await assert.rejects(() => setCustomBackupDir(path.join(CUSTOM_TMP, "missing")), { code: "FOLDER_NOT_FOUND" });
  });

  test("پس از انتخاب پوشه، بکاپ دستی دقیقاً در همان مسیر ذخیره می‌شود و در فهرست دیده می‌شود", async () => {
    const target = path.join(CUSTOM_TMP, "my-backups");
    fs.mkdirSync(target);
    const folder = await setCustomBackupDir(target);
    assert.equal(folder.id, "custom");
    assert.equal(folder.isActive, true);

    const made = await manualBackup();
    assert.equal(made.status, 201, JSON.stringify(made.body));
    assert.equal(made.body.backup.folderId, "custom");
    assert.ok(fs.existsSync(path.join(fs.realpathSync(target), made.body.backup.filename)), "فایل باید در پوشه‌ی انتخاب‌شده باشد");

    const listed = await list("custom");
    assert.equal(listed.status, 200);
    assert.equal(listed.body.activeFolderId, "custom");
    assert.ok(listed.body.backups.some((b) => b.filename === made.body.backup.filename));

    const dl = await api("GET", `/api/superadmin/backups/${made.body.backup.filename}/download?folder=custom`, { token: superadmin.token });
    assert.equal(dl.status, 200);
  });

  test("بکاپ‌های قبلی در پوشه‌ی پیش‌فرض دست‌نخورده می‌مانند و فعال‌سازی دوباره‌ی آن ممکن است", async () => {
    const back = await activate("default");
    assert.equal(back.status, 200, JSON.stringify(back.body));
    const overview = await list("default");
    assert.equal(overview.body.activeFolderId, "default");
    assert.ok(overview.body.folders.some((f) => f.id === "custom"));
  });

  after(async () => {
    await setSetting("backupActiveFolder", "default");
    await setSetting("backupCustomDir", "");
    fs.rmSync(CUSTOM_TMP, { recursive: true, force: true });
  });
});

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { withTxRetry, isRetryableTxError } from "../utils/dbRetry.js";

const deadlock = () => Object.assign(new Error("Deadlock found"), { code: "ER_LOCK_DEADLOCK", errno: 1213 });

describe("withTxRetry", () => {
  test("خطای Deadlock و Lock wait timeout قابل تکرار شناخته می‌شوند، بقیه نه", () => {
    assert.equal(isRetryableTxError(deadlock()), true);
    assert.equal(isRetryableTxError({ code: "ER_LOCK_WAIT_TIMEOUT" }), true);
    assert.equal(isRetryableTxError({ errno: 1205 }), true);
    assert.equal(isRetryableTxError({ code: "ER_DUP_ENTRY", errno: 1062 }), false);
    assert.equal(isRetryableTxError(new Error("x")), false);
    assert.equal(isRetryableTxError(null), false);
  });

  test("بعد از چند Deadlock، اجرای موفق نتیجه را برمی‌گرداند", async () => {
    let calls = 0;
    const result = await withTxRetry(async () => {
      calls += 1;
      if (calls < 3) throw deadlock();
      return { id: 42 };
    }, { baseDelayMs: 1 });
    assert.deepEqual(result, { id: 42 });
    assert.equal(calls, 3);
  });

  test("خطای غیرقابل‌تکرار فوراً و بدون تلاش دوباره پرتاب می‌شود", async () => {
    let calls = 0;
    await assert.rejects(
      withTxRetry(async () => { calls += 1; throw Object.assign(new Error("dup"), { code: "ER_DUP_ENTRY" }); }, { baseDelayMs: 1 }),
      /dup/
    );
    assert.equal(calls, 1);
  });

  test("حلقه‌ی بی‌پایان نمی‌سازد: بعد از سقف تلاش، همان خطا پرتاب می‌شود", async () => {
    let calls = 0;
    await assert.rejects(
      withTxRetry(async () => { calls += 1; throw deadlock(); }, { retries: 3, baseDelayMs: 1 }),
      /Deadlock/
    );
    assert.equal(calls, 4); // یک بار اصلی + ۳ تلاش دوباره
  });
});

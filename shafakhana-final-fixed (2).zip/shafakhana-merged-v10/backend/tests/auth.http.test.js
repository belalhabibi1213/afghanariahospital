import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, createTestUser, loginAs, extractAuthCookie, uniqueEmail, uniqueGmail, DEFAULT_PASSWORD } from "./testApp.js";

import db from "../db.js";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "../utils/env.js";
import { hashOtp } from "../utils/otp.js";
import { setVerificationCode, setResetCode } from "../models/User.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

describe("ثبت‌نام (POST /api/auth/register)", () => {
  test("ثبت‌نام معتبر ۲۰۱ می‌دهد و حساب تاییدنشده ساخته می‌شود", async () => {
    const email = uniqueGmail("reg");
    const res = await api("POST", "/api/auth/register", { body: { fullName: "احمد رحیمی", email, password: DEFAULT_PASSWORD } });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    const [[row]] = await db.query("SELECT role, isVerified FROM users WHERE email = ?", [email]);
    assert.equal(row.role, "user", "ثبت‌نام عمومی هرگز نباید نقش غیر از user بدهد");
    assert.equal(row.isVerified, 0);
  });

  test("نقش ارسالی از سمت کلاینت نادیده گرفته می‌شود (جلوگیری از Mass Assignment)", async () => {
    const email = uniqueGmail("mass");
    const res = await api("POST", "/api/auth/register", {
      body: { fullName: "علی احمدی", email, password: DEFAULT_PASSWORD, role: "superadmin", isVerified: 1, isActive: 1 },
    });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    const [[row]] = await db.query("SELECT role, isVerified FROM users WHERE email = ?", [email]);
    assert.equal(row.role, "user");
    assert.equal(row.isVerified, 0);
  });

  test("ایمیل تکراری همان پاسخ ثبت‌نام جدید را می‌گیرد (ضد user enumeration) و حساب موجود دست‌نخورده می‌ماند", async () => {
    const u = await createTestUser();
    const fresh = await api("POST", "/api/auth/register", { body: { fullName: "احمد رحیمی", email: uniqueGmail("fresh"), password: DEFAULT_PASSWORD } });
    const res = await api("POST", "/api/auth/register", { body: { fullName: "احمد رحیمی", email: u.email, password: DEFAULT_PASSWORD } });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    assert.equal(res.status, fresh.status);
    assert.equal(res.body.message, fresh.body.message);
    const [[row]] = await db.query("SELECT role, isVerified FROM users WHERE email = ?", [u.email]);
    assert.equal(row.isVerified, 1);
  });

  test("ایمیل ناموجود هم بعد از چند تلاش مثل حساب واقعی قفل (۴۲۳) می‌شود", async () => {
    const email = uniqueEmail("ghost");
    let last;
    for (let i = 0; i < 6; i += 1) {
      last = await api("POST", "/api/auth/login", { body: { email, password: "Wrong1234" } });
      if (last.status === 423) break;
    }
    assert.equal(last.status, 423);
    assert.equal(last.body.code, "ACCOUNT_LOCKED");
  });

  test("صاحب حساب از IP آشنا با رمز درست می‌تواند در زمان قفل وارد شود (قفل هوشمند)", async () => {
    const u = await createTestUser();
    await loginAs(u); // نشست از همین IP ثبت می‌شود
    for (let i = 0; i < 6; i += 1) await api("POST", "/api/auth/login", { body: { email: u.email, password: "Wrong1234" } });
    const [[row]] = await db.query("SELECT lockedUntil FROM users WHERE id = ?", [u.id]);
    assert.ok(row.lockedUntil, "حساب باید قفل شده باشد");
    const res = await api("POST", "/api/auth/login", { body: { email: u.email, password: u.password } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
  });

  test("رمز ضعیف رد می‌شود", async () => {
    const res = await api("POST", "/api/auth/register", { body: { fullName: "احمد رحیمی", email: uniqueGmail("weak"), password: "123" } });
    assert.equal(res.status, 400);
  });

  test("نام غیرفارسی رد می‌شود", async () => {
    const res = await api("POST", "/api/auth/register", { body: { fullName: "John123", email: uniqueGmail("nm"), password: DEFAULT_PASSWORD } });
    assert.equal(res.status, 400);
  });

  test("فیلدهای خالی رد می‌شود", async () => {
    const res = await api("POST", "/api/auth/register", { body: {} });
    assert.equal(res.status, 400);
  });
});

describe("ورود (POST /api/auth/login)", () => {
  test("ورود درست توکن و اطلاعات عمومی کاربر را برمی‌گرداند، بدون رمز/هش", async () => {
    const u = await createTestUser();
    const res = await api("POST", "/api/auth/login", { body: { email: u.email, password: u.password } });
    assert.equal(res.status, 200);
    assert.equal(res.body.token, undefined, "توکن JWT نباید در بدنه‌ی JSON باشد (فقط کوکی httpOnly)");
    assert.ok(extractAuthCookie(res.headers), "کوکی نشست باید تنظیم شود");
    assert.ok(res.body.csrfToken);
    assert.equal(res.body.user.email, u.email);
    assert.equal(res.body.user.password, undefined, "هش رمز هرگز نباید در پاسخ باشد");
    assert.ok(!JSON.stringify(res.body).includes("$2"), "هیچ هش bcrypt ای نباید نشت کند");
  });

  test("توکن شامل jti و نقش درست است و نشست در دیتابیس ثبت می‌شود", async () => {
    const u = await createTestUser({ role: "doctor" });
    const token = await loginAs(u);
    const payload = jwt.verify(token, JWT_SECRET);
    assert.equal(payload.role, "doctor");
    assert.ok(payload.jti);
    const [[s]] = await db.query("SELECT * FROM user_sessions WHERE tokenId = ?", [payload.jti]).catch(() => [[null]]);
    if (s !== undefined && s !== null) assert.equal(s.userId, u.id);
  });

  test("رمز اشتباه و ایمیل ناموجود پیام یکسان می‌دهند (جلوگیری از user enumeration)", async () => {
    const u = await createTestUser();
    const wrongPass = await api("POST", "/api/auth/login", { body: { email: u.email, password: "Wrong1234" } });
    const noUser = await api("POST", "/api/auth/login", { body: { email: uniqueEmail("ghost"), password: "Wrong1234" } });
    assert.equal(wrongPass.status, 401);
    assert.equal(noUser.status, 401);
    assert.equal(wrongPass.body.message, noUser.body.message);
  });

  test("ایمیل با حروف بزرگ هم وارد می‌شود", async () => {
    const u = await createTestUser();
    const res = await api("POST", "/api/auth/login", { body: { email: u.email.toUpperCase(), password: u.password } });
    assert.equal(res.status, 200);
  });

  test("ورودی خالی ۴۰۰ می‌دهد", async () => {
    assert.equal((await api("POST", "/api/auth/login", { body: {} })).status, 400);
    assert.equal((await api("POST", "/api/auth/login", { body: { email: "x@y.com" } })).status, 400);
  });

  test("حساب تاییدنشده با کد EMAIL_NOT_VERIFIED رد می‌شود", async () => {
    const u = await createTestUser({ isVerified: 0 });
    const res = await api("POST", "/api/auth/login", { body: { email: u.email, password: u.password } });
    assert.equal(res.status, 403);
    assert.equal(res.body.code, "EMAIL_NOT_VERIFIED");
    assert.equal(res.body.token, undefined);
  });

  test("حساب غیرفعال نمی‌تواند وارد شود", async () => {
    const u = await createTestUser({ isActive: 0 });
    const res = await api("POST", "/api/auth/login", { body: { email: u.email, password: u.password } });
    assert.equal(res.status, 403);
    assert.equal(res.body.token, undefined);
  });

  test("بعد از تلاش‌های ناموفق پشت‌سرهم حساب قفل می‌شود (۴۲۳) و حتی رمز درست هم رد می‌شود", async () => {
    const u = await createTestUser();
    let last;
    for (let i = 0; i < 6; i += 1) {
      last = await api("POST", "/api/auth/login", { body: { email: u.email, password: "Wrong1234" } });
      if (last.status === 423) break;
    }
    assert.equal(last.status, 423, "بعد از چند تلاش ناموفق باید قفل شود");
    assert.equal(last.body.code, "ACCOUNT_LOCKED");
    const withCorrect = await api("POST", "/api/auth/login", { body: { email: u.email, password: u.password } });
    assert.equal(withCorrect.status, 423, "در زمان قفل، رمز درست هم پذیرفته نمی‌شود");
  });
});

describe("نشست و توکن (GET /api/auth/me, POST /api/auth/logout)", () => {
  test("بدون توکن ۴۰۱", async () => {
    assert.equal((await api("GET", "/api/auth/me")).status, 401);
  });

  test("توکن جعلی/خراب ۴۰۱", async () => {
    const res = await api("GET", "/api/auth/me", { token: "not.a.jwt" });
    assert.equal(res.status, 401);
    assert.equal(res.body.code, "SESSION_EXPIRED");
  });

  test("توکن امضاشده با کلید دیگر رد می‌شود", async () => {
    const u = await createTestUser();
    const forged = jwt.sign({ id: u.id, email: u.email, role: "superadmin" }, "another-secret-key-not-the-real-one-1234567890");
    assert.equal((await api("GET", "/api/auth/me", { token: forged })).status, 401);
  });

  test("توکن منقضی‌شده رد می‌شود", async () => {
    const u = await createTestUser();
    const expired = jwt.sign({ id: u.id, email: u.email, role: u.role }, JWT_SECRET, { expiresIn: -10 });
    assert.equal((await api("GET", "/api/auth/me", { token: expired })).status, 401);
  });

  test("توکن معتبر اطلاعات خودِ کاربر را برمی‌گرداند", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    const res = await api("GET", "/api/auth/me", { token });
    assert.equal(res.status, 200);
    assert.equal((res.body.user || res.body).email, u.email);
  });

  test("ارتقای نقش داخل payload توکن بدون امضای درست ممکن نیست", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    const [h, , s] = token.split(".");
    const fakePayload = Buffer.from(JSON.stringify({ id: u.id, email: u.email, role: "superadmin" })).toString("base64url");
    const res = await api("GET", "/api/superadmin/users", { token: `${h}.${fakePayload}.${s}` });
    assert.equal(res.status, 401);
  });

  test("خروج، همان توکن را فوراً باطل می‌کند", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    assert.equal((await api("GET", "/api/auth/me", { token })).status, 200);
    assert.equal((await api("POST", "/api/auth/logout", { token })).status, 200);
    const after = await api("GET", "/api/auth/me", { token });
    assert.equal(after.status, 401);
    assert.equal(after.body.code, "SESSION_TERMINATED");
  });

  test("غیرفعال‌سازی حساب، توکن‌های قبلی را فوراً بی‌اثر می‌کند", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    await db.query("UPDATE users SET isActive = 0 WHERE id = ?", [u.id]);
    const res = await api("GET", "/api/auth/me", { token });
    assert.equal(res.status, 403);
    assert.equal(res.body.code, "ACCOUNT_DISABLED");
  });

  test("حذف کاربر از دیتابیس هم توکن را بی‌اثر می‌کند", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    await db.query("DELETE FROM users WHERE id = ?", [u.id]);
    assert.equal((await api("GET", "/api/auth/me", { token })).status, 403);
  });
});

describe("تایید ایمیل (POST /api/auth/verify-email)", () => {
  test("کد درست حساب را تایید و توکن می‌دهد", async () => {
    const u = await createTestUser({ isVerified: 0 });
    await setVerificationCode(u.id, hashOtp("123456"), new Date(Date.now() + 10 * 60000));
    const res = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "123456" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(res.body.token, undefined);
    assert.ok(extractAuthCookie(res.headers));
    const [[row]] = await db.query("SELECT isVerified FROM users WHERE id = ?", [u.id]);
    assert.equal(row.isVerified, 1);
  });

  test("کد نادرست رد می‌شود و حساب تایید نمی‌شود", async () => {
    const u = await createTestUser({ isVerified: 0 });
    await setVerificationCode(u.id, hashOtp("123456"), new Date(Date.now() + 10 * 60000));
    const res = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "000000" } });
    assert.equal(res.status, 400);
    const [[row]] = await db.query("SELECT isVerified FROM users WHERE id = ?", [u.id]);
    assert.equal(row.isVerified, 0);
  });

  test("کد منقضی‌شده رد می‌شود", async () => {
    const u = await createTestUser({ isVerified: 0 });
    await setVerificationCode(u.id, hashOtp("123456"), new Date(Date.now() - 60000));
    const res = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "123456" } });
    assert.equal(res.status, 400);
  });

  test("کد به‌صورت هش ذخیره می‌شود، نه متن ساده", async () => {
    const u = await createTestUser({ isVerified: 0 });
    await setVerificationCode(u.id, hashOtp("654321"), new Date(Date.now() + 60000));
    const [[row]] = await db.query("SELECT verificationCodeHash FROM users WHERE id = ?", [u.id]);
    assert.notEqual(row.verificationCodeHash, "654321");
    assert.ok(row.verificationCodeHash.length >= 32);
  });
});

describe("فراموشی و بازیابی رمز عبور", () => {
  test("پاسخ فراموشی رمز برای ایمیل موجود و ناموجود یکسان است (بدون افشای وجود حساب)", async () => {
    const u = await createTestUser();
    const known = await api("POST", "/api/auth/forgot-password", { body: { email: u.email } });
    const unknown = await api("POST", "/api/auth/forgot-password", { body: { email: uniqueEmail("nobody") } });
    assert.equal(known.status, 200);
    assert.equal(unknown.status, 200);
    assert.equal(known.body.message, unknown.body.message);
  });

  test("بازیابی با کد درست رمز را عوض می‌کند و رمز قدیمی از کار می‌افتد", async () => {
    const u = await createTestUser();
    await setResetCode(u.id, hashOtp("111222"), new Date(Date.now() + 10 * 60000));
    const res = await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "111222", newPassword: "NewPass1234" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal((await api("POST", "/api/auth/login", { body: { email: u.email, password: u.password } })).status, 401);
    assert.equal((await api("POST", "/api/auth/login", { body: { email: u.email, password: "NewPass1234" } })).status, 200);
  });

  test("کد بازیابی فقط یک‌بار قابل استفاده است", async () => {
    const u = await createTestUser();
    await setResetCode(u.id, hashOtp("111222"), new Date(Date.now() + 10 * 60000));
    const body = { email: u.email, code: "111222", newPassword: "NewPass1234" };
    assert.equal((await api("POST", "/api/auth/reset-password", { body })).status, 200);
    const again = await api("POST", "/api/auth/reset-password", { body: { ...body, newPassword: "Another1234" } });
    assert.equal(again.status, 400);
  });

  test("کد نادرست یا منقضی رد می‌شود", async () => {
    const u = await createTestUser();
    await setResetCode(u.id, hashOtp("111222"), new Date(Date.now() + 10 * 60000));
    assert.equal((await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "999999", newPassword: "NewPass1234" } })).status, 400);
    await setResetCode(u.id, hashOtp("111222"), new Date(Date.now() - 1000));
    assert.equal((await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "111222", newPassword: "NewPass1234" } })).status, 400);
  });

  test("رمز جدید ضعیف رد می‌شود", async () => {
    const u = await createTestUser();
    await setResetCode(u.id, hashOtp("111222"), new Date(Date.now() + 10 * 60000));
    const res = await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "111222", newPassword: "abc" } });
    assert.equal(res.status, 400);
  });
});

// ---------------------------------------------------------------------------
// رگرسیون امنیتی: دور زدن احراز هویت از مسیر verify-email + افشای وجود ایمیل
// ---------------------------------------------------------------------------
describe("امنیت تایید ایمیل: بدون کد درست هرگز نشست صادر نمی‌شود", () => {
  test("حساب تاییدشده + کد اشتباه → ۴۰۰ و هیچ کوکی ورودی صادر نمی‌شود (باگ دور زدن ورود)", async () => {
    const victim = await createTestUser({ role: "admin" }); // تاییدشده
    const res = await api("POST", "/api/auth/verify-email", { body: { email: victim.email, code: "000000" } });
    assert.equal(res.status, 400, JSON.stringify(res.body));
    assert.equal(extractAuthCookie(res.headers), null, "نباید هیچ کوکی نشستی صادر شود");
    assert.equal(res.body.user, undefined);
    assert.equal(res.body.csrfToken, undefined);
  });

  test("همین مسیر برای سوپرادمین و کاربر عادی هم نشست نمی‌دهد", async () => {
    for (const role of ["superadmin", "doctor", "user"]) {
      const u = await createTestUser({ role });
      const res = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "123456" } });
      assert.equal(res.status, 400, `${role}: ${JSON.stringify(res.body)}`);
      assert.equal(extractAuthCookie(res.headers), null, `${role}: نباید کوکی صادر شود`);
    }
  });

  test("حساب تاییدشده‌ای که هنوز کد قدیمی در دیتابیس دارد هم با کد درست نشست جدید نمی‌گیرد", async () => {
    const u = await createTestUser({ role: "user" });
    await setVerificationCode(u.id, hashOtp("123456"), new Date(Date.now() + 10 * 60000));
    const res = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "123456" } });
    assert.equal(res.status, 400);
    assert.equal(extractAuthCookie(res.headers), null);
  });

  test("حساب غیرفعال‌شده حتی با کد درست نشست نمی‌گیرد", async () => {
    const u = await createTestUser({ isVerified: 0, isActive: 0 });
    await setVerificationCode(u.id, hashOtp("123456"), new Date(Date.now() + 10 * 60000));
    const res = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "123456" } });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(extractAuthCookie(res.headers), null);
    const [[row]] = await db.query("SELECT isVerified FROM users WHERE id = ?", [u.id]);
    assert.equal(row.isVerified, 0, "حساب غیرفعال نباید تایید شود");
  });

  test("مسیر درست هنوز کار می‌کند: حساب تاییدنشده + کد درست → ۲۰۰ و کوکی", async () => {
    const u = await createTestUser({ isVerified: 0 });
    await setVerificationCode(u.id, hashOtp("424242"), new Date(Date.now() + 10 * 60000));
    const res = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "424242" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.ok(extractAuthCookie(res.headers));
  });
});

describe("امنیت: افشای وجود ایمیل (User Enumeration)", () => {
  test("verify-email: ایمیل ناشناس، حساب تاییدشده، کد اشتباه و کد منقضی همگی پاسخ یکسان دارند", async () => {
    const verified = await createTestUser();
    const wrong = await createTestUser({ isVerified: 0 });
    await setVerificationCode(wrong.id, hashOtp("111111"), new Date(Date.now() + 60000));
    const expired = await createTestUser({ isVerified: 0 });
    await setVerificationCode(expired.id, hashOtp("222222"), new Date(Date.now() - 60000));

    const cases = [
      { email: uniqueEmail("ghost"), code: "123456" },
      { email: verified.email, code: "123456" },
      { email: wrong.email, code: "000000" },
      { email: expired.email, code: "222222" },
    ];
    const results = [];
    for (const body of cases) results.push(await api("POST", "/api/auth/verify-email", { body }));
    for (const r of results) assert.equal(r.status, 400, JSON.stringify(r.body));
    assert.equal(new Set(results.map((r) => r.body.message)).size, 1, "همه‌ی پیام‌ها باید یکسان باشند");
  });

  test("resend-verification: ایمیل ناشناس، تاییدشده و تاییدنشده همگی ۲۰۰ با پیام یکسان می‌دهند", async () => {
    const verified = await createTestUser();
    const unverified = await createTestUser({ isVerified: 0 });
    const emails = [uniqueEmail("ghost"), verified.email, unverified.email];
    const results = [];
    for (const email of emails) results.push(await api("POST", "/api/auth/resend-verification", { body: { email } }));
    for (const r of results) assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal(new Set(results.map((r) => r.body.message)).size, 1, "پیام‌ها باید یکسان باشند");
  });

  test("reset-password: ایمیل ناشناس، بدون کد، کد اشتباه و کد منقضی همگی ۴۰۰ با پیام یکسان", async () => {
    const noCode = await createTestUser();
    const wrong = await createTestUser();
    await setResetCode(wrong.id, hashOtp("111222"), new Date(Date.now() + 60000));
    const expired = await createTestUser();
    await setResetCode(expired.id, hashOtp("333444"), new Date(Date.now() - 60000));

    const cases = [
      { email: uniqueEmail("ghost"), code: "111222" },
      { email: noCode.email, code: "111222" },
      { email: wrong.email, code: "000000" },
      { email: expired.email, code: "333444" },
    ];
    const results = [];
    for (const c of cases) {
      results.push(await api("POST", "/api/auth/reset-password", { body: { ...c, newPassword: "NewPass1234" } }));
    }
    for (const r of results) assert.equal(r.status, 400, JSON.stringify(r.body));
    assert.equal(new Set(results.map((r) => r.body.message)).size, 1, "همه‌ی پیام‌ها باید یکسان باشند");
  });
});

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { escapeCsvCell } from "../utils/csv.js";

describe("escapeCsvCell — تزریق فرمول و نقل‌قول", () => {
  test("متن عادی فقط داخل نقل‌قول می‌رود و \" دوبل می‌شود", () => {
    assert.equal(escapeCsvCell("سلام"), '"سلام"');
    assert.equal(escapeCsvCell('او گفت "بله"'), '"او گفت ""بله"""');
    assert.equal(escapeCsvCell("a,b\nc"), '"a,b\nc"');
  });

  test("null/undefined → سلول خالی", () => {
    assert.equal(escapeCsvCell(null), '""');
    assert.equal(escapeCsvCell(undefined), '""');
  });

  test("متنی که با = + - @ Tab CR شروع شود با ' خنثی می‌شود", () => {
    for (const evil of ["=1+1", "+1+1", "-1+1", "@SUM(A1)", "\t=1+1", "\r=1+1", "=HYPERLINK(\"http://evil\",\"x\")", "=cmd|' /C calc'!A0"]) {
      const out = escapeCsvCell(evil);
      assert.ok(out.startsWith(`"'`), `باید با "' شروع شود: ${out}`);
    }
  });

  test("خروجی هیچ‌وقت سلولی نیست که اولین کاراکتر محتوایش فرمول‌ساز باشد", () => {
    const evil = ["=1+1", "+cmd", "-2+3", "@x"];
    for (const v of evil) {
      const inner = escapeCsvCell(v).slice(1); // بعد از " باز
      assert.doesNotMatch(inner, /^[=+\-@\t\r]/);
    }
  });

  test("متن بی‌خطر که در میانه = یا - دارد دست‌نخورده می‌ماند", () => {
    assert.equal(escapeCsvCell("2026-10-07 10:00"), '"2026-10-07 10:00"');
    assert.equal(escapeCsvCell("a=b"), '"a=b"');
    assert.equal(escapeCsvCell("نام - خانوادگی"), '"نام - خانوادگی"');
  });

  test("عدد واقعی (حتی منفی) و Date دست‌نخورده می‌مانند", () => {
    assert.equal(escapeCsvCell(42), '"42"');
    assert.equal(escapeCsvCell(-5), '"-5"');
    assert.doesNotMatch(escapeCsvCell(new Date("2026-10-07T10:00:00Z")), /^"'/);
  });
});

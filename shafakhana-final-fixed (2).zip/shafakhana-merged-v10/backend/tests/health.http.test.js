// بررسی سلامت (liveness/readiness) — نیازمند MySQL، مثل بقیه‌ی *.http.test.js
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api } from "./testApp.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

describe("/health", () => {
  test("liveness بدون احراز هویت ۲۰۰ می‌دهد و جزئیات داخلی نشان نمی‌دهد", async () => {
    const r = await api("GET", "/health");
    assert.equal(r.status, 200);
    assert.deepEqual(r.body, { status: "ok" });
  });

  test("readiness با دیتابیس سالم ۲۰۰ می‌دهد", async () => {
    const r = await api("GET", "/health/ready");
    assert.equal(r.status, 200);
    assert.deepEqual(r.body, { status: "ready" });
  });
});

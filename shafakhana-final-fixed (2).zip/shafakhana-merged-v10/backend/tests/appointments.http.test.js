import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";

import db from "../db.js";
import { setSetting } from "../models/Settings.js";

let doctor;
let otherDoctor;
let admin;
let dayCounter = 20;

function futureDate(offset) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
}

function bookingBody(over = {}) {
  dayCounter += 1;
  return {
    fullName: "بیمار تست نوبت",
    phone: "0700123456",
    department: "تست",
    doctorId: doctor.id,
    appointmentDate: futureDate(dayCounter),
    appointmentTime: "10:00",
    ...over,
  };
}

before(async () => {
  await startServer();
  await setSetting("appointmentApprovalMode", "manual");
  await setSetting("appointmentBookingWindowDays", "0");
  await setSetting("appointmentSlotCapacity", "2");
  await setSetting("appointmentCancelMinHours", "2");
  doctor = await createTestDoctor();
  otherDoctor = await createTestDoctor();
  admin = await makeSession("admin");
});
after(async () => {
  await setSetting("appointmentSlotCapacity", "10");
  await stopServer();
  await closePool();
});

describe("ثبت نوبت (POST /api/appointments)", () => {
  test("مهمان (بدون ورود) اجازه ثبت نوبت ندارد", async () => {
    const res = await api("POST", "/api/appointments", { body: bookingBody() });
    assert.equal(res.status, 401);
  });

  test("ثبت معتبر: نوبت در وضعیت pending ساخته می‌شود و اعلان ثبت می‌شود", async () => {
    const s = await makeSession("user");
    const body = bookingBody();
    const res = await api("POST", "/api/appointments", { token: s.token, body });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    const [[row]] = await db.query("SELECT status FROM appointments WHERE id = ?", [res.body.appointment.id]);
    assert.equal(row.status, "pending");
    const [[n]] = await db.query("SELECT COUNT(*) AS c FROM notifications WHERE userId = ? AND type = 'appointment'", [s.id]);
    assert.ok(n.c >= 1, "اعلان ثبت نوبت باید ساخته شود");
  });

  test("حالت تایید خودکار (auto) نوبت را مستقیم confirmed می‌کند", async () => {
    await setSetting("appointmentApprovalMode", "auto");
    try {
      const s = await makeSession("user");
      const res = await api("POST", "/api/appointments", { token: s.token, body: bookingBody() });
      assert.equal(res.status, 201);
      const [[row]] = await db.query("SELECT status FROM appointments WHERE id = ?", [res.body.appointment.id]);
      assert.equal(row.status, "confirmed");
    } finally {
      await setSetting("appointmentApprovalMode", "manual");
    }
  });

  test("داکتر ناموجود ۴۰۴", async () => {
    const s = await makeSession("user");
    const res = await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ doctorId: 99999999 }) });
    assert.equal(res.status, 404);
  });

  test("فیلدهای الزامی/نام نامعتبر/تاریخ نامعتبر ۴۰۰", async () => {
    const s = await makeSession("user");
    assert.equal((await api("POST", "/api/appointments", { token: s.token, body: {} })).status, 400);
    assert.equal((await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ fullName: "Bob99" }) })).status, 400);
    assert.equal((await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ appointmentDate: "not-a-date" }) })).status, 400);
    assert.equal((await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ doctorId: "abc" }) })).status, 400);
  });

  test("ظرفیت اسلات: نفر سوم با ظرفیت ۲ خطای ۴۰۹ SLOT_FULL می‌گیرد", async () => {
    const date = futureDate(90);
    const results = [];
    for (let i = 0; i < 3; i += 1) {
      const s = await makeSession("user");
      results.push(await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ appointmentDate: date, appointmentTime: "11:30" }) }));
    }
    assert.deepEqual(results.map((r) => r.status), [201, 201, 409]);
    assert.equal(results[2].body.code, "SLOT_FULL");
  });

  test("رزروهای HTTP هم‌زمان هرگز از ظرفیت بیشتر نمی‌شوند", async () => {
    const date = futureDate(91);
    const sessions = await Promise.all(Array.from({ length: 6 }, () => makeSession("user")));
    const results = await Promise.all(
      sessions.map((s) => api("POST", "/api/appointments", { token: s.token, body: bookingBody({ appointmentDate: date, appointmentTime: "12:30" }) }))
    );
    const ok = results.filter((r) => r.status === 201).length;
    assert.equal(ok, 2, "دقیقاً برابر ظرفیت (۲) باید موفق شود");
    assert.ok(results.filter((r) => r.status !== 201).every((r) => r.status === 409));
  });

  test("بازه‌ی مجاز رزرو (appointmentBookingWindowDays) رعایت می‌شود", async () => {
    await setSetting("appointmentBookingWindowDays", "7");
    try {
      const s = await makeSession("user");
      const far = await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ appointmentDate: futureDate(60) }) });
      assert.equal(far.status, 400);
      assert.equal(far.body.code, "DATE_OUT_OF_BOOKING_WINDOW");
      const past = await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ appointmentDate: futureDate(-3) }) });
      assert.equal(past.status, 400);
    } finally {
      await setSetting("appointmentBookingWindowDays", "0");
    }
  });
});

describe("نوبت‌های من و لغو (GET /mine, POST /:id/cancel)", () => {
  test("هر کاربر فقط نوبت‌های خودش را می‌بیند", async () => {
    const a = await makeSession("user");
    const b = await makeSession("user");
    const r = await api("POST", "/api/appointments", { token: a.token, body: bookingBody() });
    assert.equal(r.status, 201);
    const mineA = await api("GET", "/api/appointments/mine", { token: a.token });
    const mineB = await api("GET", "/api/appointments/mine", { token: b.token });
    assert.ok(mineA.body.appointments.some((x) => x.id === r.body.appointment.id));
    assert.ok(!mineB.body.appointments.some((x) => x.id === r.body.appointment.id));
  });

  test("بیمار نوبت خودش را (با فاصله‌ی کافی) لغو می‌کند", async () => {
    const s = await makeSession("user");
    const r = await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ appointmentDate: futureDate(40) }) });
    const res = await api("POST", `/api/appointments/${r.body.appointment.id}/cancel`, { token: s.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const [[row]] = await db.query("SELECT status FROM appointments WHERE id = ?", [r.body.appointment.id]);
    assert.equal(row.status, "cancelled");
  });

  test("لغو نوبت دیگران ممنوع است و نوبت تغییر نمی‌کند", async () => {
    const owner = await makeSession("user");
    const attacker = await makeSession("user");
    const r = await api("POST", "/api/appointments", { token: owner.token, body: bookingBody({ appointmentDate: futureDate(41) }) });
    const res = await api("POST", `/api/appointments/${r.body.appointment.id}/cancel`, { token: attacker.token });
    assert.ok([403, 404].includes(res.status), `status=${res.status}`);
    const [[row]] = await db.query("SELECT status FROM appointments WHERE id = ?", [r.body.appointment.id]);
    assert.equal(row.status, "pending");
  });

  test("لغو دوباره‌ی نوبت لغوشده رد می‌شود", async () => {
    const s = await makeSession("user");
    const r = await api("POST", "/api/appointments", { token: s.token, body: bookingBody({ appointmentDate: futureDate(42) }) });
    const id = r.body.appointment.id;
    assert.equal((await api("POST", `/api/appointments/${id}/cancel`, { token: s.token })).status, 200);
    const again = await api("POST", `/api/appointments/${id}/cancel`, { token: s.token });
    assert.ok([400, 409].includes(again.status), `status=${again.status}`);
  });

  test("لغو کمتر از حداقل ساعت مجاز قبل از نوبت رد می‌شود", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    // نوبتی که امروز و چند دقیقه‌ی دیگر است
    const soon = new Date(Date.now() + 30 * 60000);
    const [ins] = await db.query(
      "INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, status) VALUES (?, ?, 'تست', ?, ?, 'confirmed')",
      [pid, doctor.id, soon.toISOString().slice(0, 10), soon.toTimeString().slice(0, 8)]
    );
    const res = await api("POST", `/api/appointments/${ins.insertId}/cancel`, { token: s.token });
    assert.ok([400, 409].includes(res.status), `status=${res.status} ${JSON.stringify(res.body)}`);
  });

  test("لغو نوبت ناموجود ۴۰۴", async () => {
    const s = await makeSession("user");
    assert.equal((await api("POST", "/api/appointments/99999999/cancel", { token: s.token })).status, 404);
  });
});

describe("تغییر وضعیت نوبت: فقط ادمین (داکتر فقط مشاهده می‌کند)", () => {
  test("داکتر نمی‌تواند نوبت خودش را تایید/رد/تکمیل کند (۴۰۳) و وضعیت تغییر نمی‌کند", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    const apptId = await addAppointment(pid, doctor.id, "pending");
    for (const status of ["confirmed", "cancelled", "completed", "hacked"]) {
      const res = await api("PUT", `/api/doctors/me/appointments/${apptId}/status`, { token: doctor.token, body: { status } });
      assert.equal(res.status, 403, `status=${status} ${JSON.stringify(res.body)}`);
    }
    const [[row]] = await db.query("SELECT status FROM appointments WHERE id = ?", [apptId]);
    assert.equal(row.status, "pending");
    const [hist] = await db.query("SELECT id FROM appointment_status_history WHERE appointmentId = ? AND newStatus <> 'pending'", [apptId]);
    assert.equal(hist.length, 0);
  });

  test("داکتر همچنان فهرست نوبت‌های خودش را می‌بیند", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    const apptId = await addAppointment(pid, doctor.id, "pending");
    const res = await api("GET", "/api/doctors/me/appointments", { token: doctor.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.ok((res.body.appointments || []).some((a) => a.id === apptId));
  });

  test("ادمین نوبت را تایید می‌کند و تاریخچه‌ی وضعیت ثبت می‌شود", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    const apptId = await addAppointment(pid, doctor.id, "pending");
    const res = await api("PUT", `/api/admin/appointments/${apptId}/status`, { token: admin.token, body: { status: "confirmed" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const [[h]] = await db.query("SELECT oldStatus, newStatus FROM appointment_status_history WHERE appointmentId = ? ORDER BY id DESC LIMIT 1", [apptId]);
    assert.equal(h.oldStatus, "pending");
    assert.equal(h.newStatus, "confirmed");
  });

  test("ادمین وضعیت هر نوبتی را تغییر می‌دهد", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    const apptId = await addAppointment(pid, otherDoctor.id, "pending");
    const res = await api("PUT", `/api/admin/appointments/${apptId}/status`, { token: admin.token, body: { status: "confirmed" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const [[row]] = await db.query("SELECT status FROM appointments WHERE id = ?", [apptId]);
    assert.equal(row.status, "confirmed");
  });

  test("ادمین نوبت را با وضعیت نامعتبر تغییر نمی‌دهد", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    const apptId = await addAppointment(pid, doctor.id, "pending");
    const res = await api("PUT", `/api/admin/appointments/${apptId}/status`, { token: admin.token, body: { status: "weird" } });
    assert.equal(res.status, 400);
  });

  test("بیمار به مسیرهای تغییر وضعیت (داکتر/ادمین) دسترسی ندارد", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    const apptId = await addAppointment(pid, doctor.id, "pending");
    assert.equal((await api("PUT", `/api/doctors/me/appointments/${apptId}/status`, { token: s.token, body: { status: "confirmed" } })).status, 403);
    assert.equal((await api("PUT", `/api/admin/appointments/${apptId}/status`, { token: s.token, body: { status: "confirmed" } })).status, 403);
  });

  test("تایید نوبت برای بیمار اعلان می‌سازد", async () => {
    const s = await makeSession("user");
    const pid = await createTestPatient(s.id);
    const apptId = await addAppointment(pid, doctor.id, "pending");
    await api("PUT", `/api/admin/appointments/${apptId}/status`, { token: admin.token, body: { status: "confirmed" } });
    const notes = await api("GET", "/api/users/notifications", { token: s.token });
    assert.equal(notes.status, 200);
    assert.ok((notes.body.notifications || []).length >= 1);
  });
});

describe("در دسترس بودن داکتر (GET /api/doctors/:id/availability)", () => {
  test("عمومی است و برای تاریخ معتبر ۲۰۰ می‌دهد", async () => {
    const res = await api("GET", `/api/doctors/${doctor.id}/availability?date=${futureDate(10)}`);
    assert.equal(res.status, 200);
  });

  test("داکتر ناموجود ۴۰۴ یا ۴۰۰ می‌دهد نه ۵۰۰", async () => {
    const res = await api("GET", `/api/doctors/99999999/availability?date=${futureDate(10)}`);
    assert.ok([400, 404].includes(res.status), `status=${res.status}`);
  });
});

// ورود با کوکی httpOnly + CSRF روی اپ واقعی (نیازمند MySQL، مثل بقیه‌ی *.http.test.js)
import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, createTestUser, extractAuthCookie } from "./testApp.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

async function cookieLogin() {
  const u = await createTestUser();
  const res = await api("POST", "/api/auth/login", { body: { email: u.email, password: u.password } });
  const setCookie = res.headers.getSetCookie().find((c) => c.startsWith("shafakhana_token="));
  return { u, res, setCookie, token: extractAuthCookie(res.headers), csrf: res.body.csrfToken };
}

describe("نشست مبتنی بر کوکی httpOnly", () => {
  test("ورود، کوکی HttpOnly + SameSite می‌گذارد و توکن در JSON نیست", async () => {
    const { res, setCookie } = await cookieLogin();
    assert.equal(res.status, 200);
    assert.equal(res.body.token, undefined);
    assert.ok(setCookie, "Set-Cookie باید وجود داشته باشد");
    assert.match(setCookie, /HttpOnly/i);
    assert.match(setCookie, /SameSite=Lax/i);
    assert.match(setCookie, /Path=\//);
  });

  test("GET /auth/me با کوکی کار می‌کند و توکن CSRF می‌دهد", async () => {
    const { token, u } = await cookieLogin();
    const res = await api("GET", "/api/auth/me", { headers: { Cookie: `shafakhana_token=${token}` } });
    assert.equal(res.status, 200);
    assert.equal(res.body.user.email, u.email);
    assert.ok(res.body.csrfToken);
  });

  test("درخواست تغییردهنده با کوکی بدون CSRF رد و با CSRF پذیرفته می‌شود", async () => {
    const { token, csrf } = await cookieLogin();
    const headers = { Cookie: `shafakhana_token=${token}` };
    const denied = await api("PUT", "/api/users/theme", { headers, body: { themePreference: "dark" } });
    assert.equal(denied.status, 403);
    assert.equal(denied.body.code, "CSRF_INVALID");
    const ok = await api("PUT", "/api/users/theme", { headers: { ...headers, "X-CSRF-Token": csrf }, body: { themePreference: "dark" } });
    assert.notEqual(ok.status, 403, JSON.stringify(ok.body));
  });

  test("logout نشست را باطل و کوکی را پاک می‌کند؛ با کوکی منقضی هم موفق است", async () => {
    const { token } = await cookieLogin();
    const res = await api("POST", "/api/auth/logout", { headers: { Cookie: `shafakhana_token=${token}` } });
    assert.equal(res.status, 200);
    const cleared = res.headers.getSetCookie().find((c) => c.startsWith("shafakhana_token="));
    assert.match(cleared, /Expires=Thu, 01 Jan 1970/i);
    const after = await api("GET", "/api/auth/me", { headers: { Cookie: `shafakhana_token=${token}` } });
    assert.equal(after.status, 401);
    assert.equal(after.body.code, "SESSION_TERMINATED");
    assert.equal((await api("POST", "/api/auth/logout")).status, 200);
  });
});

// تقویت امنیتی: سقف حدس OTP برای هر حساب، ابطال نشست‌ها بعد از تغییر رمز،
// اجبار سمت‌سرورِ mustChangePassword (نیازمند MySQL/MariaDB، مثل بقیه‌ی *.http.test.js)
import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, createTestUser, loginAs, extractAuthCookie, makeSession, DEFAULT_PASSWORD } from "./testApp.js";
import db from "../db.js";
import { hashOtp, OTP_MAX_ATTEMPTS } from "../utils/otp.js";
import { setVerificationCode, setResetCode, updatePasswordAndRequireChange, findByIdRaw } from "../models/User.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

const inTenMinutes = () => new Date(Date.now() + 10 * 60000);

describe("سقف حدس اشتباه OTP برای هر حساب", () => {
  test("verify-email: بعد از سقف حدس اشتباه، حتی کد درست هم رد می‌شود", async () => {
    const u = await createTestUser({ isVerified: 0 });
    await setVerificationCode(u.id, hashOtp("123456"), inTenMinutes());
    for (let i = 0; i < OTP_MAX_ATTEMPTS; i++) {
      const r = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "000000" } });
      assert.equal(r.status, 400);
    }
    const good = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "123456" } });
    assert.equal(good.status, 400, "کد باید پس از سقف تلاش باطل شده باشد");
    const row = await findByIdRaw(u.id);
    assert.equal(row.verificationCodeHash, null);
    assert.equal(row.isVerified, 0);
  });

  test("verify-email: کد درست قبل از رسیدن به سقف پذیرفته می‌شود", async () => {
    const u = await createTestUser({ isVerified: 0 });
    await setVerificationCode(u.id, hashOtp("123456"), inTenMinutes());
    for (let i = 0; i < OTP_MAX_ATTEMPTS - 1; i++) {
      await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "000000" } });
    }
    const good = await api("POST", "/api/auth/verify-email", { body: { email: u.email, code: "123456" } });
    assert.equal(good.status, 200, JSON.stringify(good.body));
  });

  test("reset-password: بعد از سقف حدس اشتباه، کد درست هم رد می‌شود و رمز عوض نمی‌شود", async () => {
    const u = await createTestUser();
    await setResetCode(u.id, hashOtp("111222"), inTenMinutes());
    for (let i = 0; i < OTP_MAX_ATTEMPTS; i++) {
      const r = await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "999999", newPassword: "NewPass1234" } });
      assert.equal(r.status, 400);
    }
    const good = await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "111222", newPassword: "NewPass1234" } });
    assert.equal(good.status, 400);
    const login = await api("POST", "/api/auth/login", { body: { email: u.email, password: DEFAULT_PASSWORD } });
    assert.equal(login.status, 200, "رمز قبلی باید همچنان معتبر باشد");
  });

  test("درخواست کد جدید، شمارنده را صفر می‌کند", async () => {
    const u = await createTestUser();
    await setResetCode(u.id, hashOtp("111222"), inTenMinutes());
    await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "999999", newPassword: "NewPass1234" } });
    await setResetCode(u.id, hashOtp("333444"), inTenMinutes());
    const [[row]] = await db.query("SELECT resetAttempts FROM users WHERE id = ?", [u.id]);
    assert.equal(row.resetAttempts, 0);
  });
});

describe("ابطال نشست‌ها بعد از تغییر رمز", () => {
  test("reset-password همه‌ی نشست‌های قبلی را باطل می‌کند", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    assert.equal((await api("GET", "/api/auth/me", { token })).status, 200);
    await setResetCode(u.id, hashOtp("111222"), inTenMinutes());
    const r = await api("POST", "/api/auth/reset-password", { body: { email: u.email, code: "111222", newPassword: "NewPass1234" } });
    assert.equal(r.status, 200);
    const after = await api("GET", "/api/auth/me", { token });
    assert.equal(after.status, 401);
    assert.equal(after.body.code, "SESSION_TERMINATED");
  });

  test("change-password: نشست دستگاه دیگر باطل می‌شود ولی نشست فعلی می‌ماند", async () => {
    const u = await createTestUser();
    const current = await loginAs(u);
    const other = await loginAs(u);
    const r = await api("PUT", "/api/users/change-password", { token: current, body: { currentPassword: DEFAULT_PASSWORD, newPassword: "BrandNew1234" } });
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.equal((await api("GET", "/api/auth/me", { token: current })).status, 200);
    const o = await api("GET", "/api/auth/me", { token: other });
    assert.equal(o.status, 401);
    assert.equal(o.body.code, "SESSION_TERMINATED");
  });

  test("بازنشانی رمز توسط مدیر، نشست‌های قبلی کاربر را باطل می‌کند", async () => {
    const u = await createTestUser();
    const token = await loginAs(u);
    await updatePasswordAndRequireChange(u.id, "TempPass1234");
    assert.equal((await api("GET", "/api/auth/me", { token })).status, 401);
  });
});

describe("اجبار mustChangePassword در بک‌اند", () => {
  test("با رمز موقت، فقط me و change-password مجازند و بقیه ۴۰۳ PASSWORD_CHANGE_REQUIRED", async () => {
    const u = await createTestUser();
    await updatePasswordAndRequireChange(u.id, "TempPass1234");
    const token = await loginAs({ ...u, password: "TempPass1234" });

    assert.equal((await api("GET", "/api/auth/me", { token })).status, 200);

    const blocked = await api("GET", "/api/users/profile", { token });
    assert.equal(blocked.status, 403);
    assert.equal(blocked.body.code, "PASSWORD_CHANGE_REQUIRED");

    const ok = await api("PUT", "/api/users/change-password", { token, body: { currentPassword: "TempPass1234", newPassword: "MyOwnPass1234" } });
    assert.equal(ok.status, 200, JSON.stringify(ok.body));

    assert.equal((await api("GET", "/api/users/profile", { token })).status, 200, "بعد از تغییر رمز باید آزاد شود");
  });

  test("حساب عادی (بدون پرچم) تحت تأثیر قرار نمی‌گیرد", async () => {
    const { token } = await makeSession("user");
    assert.equal((await api("GET", "/api/users/profile", { token })).status, 200);
  });
});

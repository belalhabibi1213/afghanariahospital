// با کش احرازهویت «روشن» (TTL بلند)، هر تغییر مجاز از مسیرهای برنامه باید فوراً اثر کند.
process.env.AUTH_CACHE_TTL_MS = "60000";

import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession } from "./testApp.js";
import { setUserActive, updateUserRole } from "../models/User.js";
import { revokeAllSessionsForUser } from "../models/Session.js";
import { clearAuthCache } from "../utils/authCache.js";

before(async () => { await startServer(); });
after(async () => { await stopServer(); await closePool(); });

describe("کش احرازهویت: ابطال فوری", () => {
  test("غیرفعال‌سازی حساب فوراً دسترسی را قطع می‌کند (حتی با کش گرم)", async () => {
    clearAuthCache();
    const u = await makeSession("user");
    assert.equal((await api("GET", "/api/auth/me", { token: u.token })).status, 200);
    assert.equal((await api("GET", "/api/auth/me", { token: u.token })).status, 200); // از کش
    await setUserActive(u.id, false);
    assert.equal((await api("GET", "/api/auth/me", { token: u.token })).status, 403);
  });

  test("تغییر نقش فوراً اعمال می‌شود", async () => {
    clearAuthCache();
    const u = await makeSession("user");
    assert.equal((await api("GET", "/api/admin/patients", { token: u.token })).status, 403);
    await updateUserRole(u.id, "admin");
    assert.notEqual((await api("GET", "/api/admin/patients", { token: u.token })).status, 403);
  });

  test("خاتمه‌ی نشست فوراً اعمال می‌شود", async () => {
    clearAuthCache();
    const u = await makeSession("user");
    assert.equal((await api("GET", "/api/auth/me", { token: u.token })).status, 200);
    await revokeAllSessionsForUser(u.id);
    const res = await api("GET", "/api/auth/me", { token: u.token });
    assert.ok([401, 403].includes(res.status), `status=${res.status}`);
  });
});

import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestUser } from "./testApp.js";
import db from "../db.js";

// «مرکز مدیریت نظرات» ادمین: صفحه‌بندی/جستجو/فیلتر/مرتب‌سازی سمت سرور، آمار، جزئیات، تأیید/رد/حذف نرم
// (تکی و گروهی)، بازگردانی، پاسخ ادمین/یادداشت داخلی/ویرایش، امتیاز، RBAC، و ارتباط با نمایش عمومی
// (فقط approved و حذف‌نشده) + عدم حذف خبر با حذف نظر
let admin;
let normalUser;
let authors = [];
let newsA;
let newsB;
const TAG = `cm${Date.now()}`;

async function addNews(title) {
  const [r] = await db.query(
    "INSERT INTO news (title, excerpt, content, tag, status) VALUES (?, 'خلاصه', 'متن', 'تست', 'published')",
    [title]
  );
  return r.insertId;
}

async function addComment(newsId, userId, content, status, createdAt) {
  const [r] = await db.query(
    "INSERT INTO news_comments (newsId, userId, content, status, createdAt) VALUES (?, ?, ?, ?, ?)",
    [newsId, userId, content, status, createdAt]
  );
  return r.insertId;
}

before(async () => {
  await startServer();
  admin = await makeSession("admin");
  normalUser = await makeSession("user");
  authors = [
    await createTestUser({ role: "user", fullName: `${TAG} نویسنده الف`, email: `a-${TAG}@test.local` }),
    await createTestUser({ role: "user", fullName: `${TAG} نویسنده ب`, email: `b-${TAG}@test.local` }),
  ];
  await db.query("DELETE FROM news_comments");
  newsA = await addNews(`${TAG} خبر اول`);
  newsB = await addNews(`${TAG} خبر دوم`);
  // ۶۰ نظر: ۳۰ pending، ۲۰ approved، ۱۰ rejected؛ نیمی روی هر خبر؛ تاریخ‌ها در شهریور ۲۰۲۶
  for (let i = 0; i < 60; i += 1) {
    const status = i < 30 ? "pending" : i < 50 ? "approved" : "rejected";
    const content = `نظر شماره ${i} ${"متن طولانی ".repeat(40)} ${i === 7 ? "کلیدواژه_یکتا" : ""} ${i === 8 ? "50%_تخفیف" : ""}`;
    const cid = await addComment(i % 2 ? newsA : newsB, authors[i % 2].id, content, status, `2026-09-${String(1 + (i % 28)).padStart(2, "0")} 10:00:00`);
    // امتیاز: ۱ تا ۵ به‌صورت چرخشی برای ۴۵ نظر اول؛ ۱۵ نظر آخر بدون امتیاز
    if (i < 45) await db.query("UPDATE news_comments SET rating = ? WHERE id = ?", [1 + (i % 5), cid]);
  }
});

after(async () => {
  await db.query("DELETE FROM news_comments");
  await db.query("DELETE FROM news WHERE title LIKE ?", [`${TAG}%`]);
  await stopServer();
  await closePool();
});

describe("GET /api/admin/comments — صفحه‌بندی و فیلتر سمت سرور", () => {
  test("پیش‌فرض ۲۰ ردیف + pagination + preview کوتاه (متن کامل در لیست نیست)", async () => {
    const r = await api("GET", "/api/admin/comments", { token: admin.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.comments.length, 20);
    assert.deepEqual(r.body.pagination, { page: 1, limit: 20, total: 60, totalPages: 3 });
    assert.ok(r.body.comments[0].preview.length <= 160);
    assert.equal(r.body.comments[0].content, undefined);
    assert.ok(r.body.comments[0].authorName && r.body.comments[0].newsTitle);
  });
  test("صفحه‌ی آخر و بدون تکرار بین صفحه‌ها", async () => {
    const p1 = await api("GET", "/api/admin/comments?page=1&limit=50", { token: admin.token });
    const p2 = await api("GET", "/api/admin/comments?page=2&limit=50", { token: admin.token });
    assert.equal(p1.body.comments.length, 50);
    assert.equal(p2.body.comments.length, 10);
    const ids = new Set(p1.body.comments.map((c) => c.id));
    assert.ok(p2.body.comments.every((c) => !ids.has(c.id)));
  });
  test("limit سقف ۱۰۰ دارد", async () => {
    const r = await api("GET", "/api/admin/comments?limit=5000", { token: admin.token });
    assert.equal(r.body.pagination.limit, 100);
    assert.equal(r.body.comments.length, 60);
  });
  test("فیلتر وضعیت و خبر (و ترکیب آن‌ها)", async () => {
    assert.equal((await api("GET", "/api/admin/comments?status=pending", { token: admin.token })).body.pagination.total, 30);
    assert.equal((await api("GET", "/api/admin/comments?status=approved", { token: admin.token })).body.pagination.total, 20);
    assert.equal((await api("GET", "/api/admin/comments?status=rejected", { token: admin.token })).body.pagination.total, 10);
    assert.equal((await api("GET", `/api/admin/comments?newsId=${newsA}`, { token: admin.token })).body.pagination.total, 30);
    const both = await api("GET", `/api/admin/comments?newsId=${newsA}&status=approved`, { token: admin.token });
    assert.ok(both.body.comments.every((c) => c.newsId === newsA && c.status === "approved"));
  });
  test("جستجو: متن نظر، نام، ایمیل، عنوان خبر", async () => {
    const byText = await api("GET", `/api/admin/comments?q=${encodeURIComponent("کلیدواژه_یکتا")}`, { token: admin.token });
    assert.equal(byText.body.pagination.total, 1);
    const byName = await api("GET", `/api/admin/comments?q=${encodeURIComponent(`${TAG} نویسنده الف`)}`, { token: admin.token });
    assert.equal(byName.body.pagination.total, 30);
    const byEmail = await api("GET", `/api/admin/comments?q=${encodeURIComponent(`b-${TAG}@test.local`)}`, { token: admin.token });
    assert.equal(byEmail.body.pagination.total, 30);
    const byNews = await api("GET", `/api/admin/comments?q=${encodeURIComponent(`${TAG} خبر دوم`)}`, { token: admin.token });
    assert.equal(byNews.body.pagination.total, 30);
  });
  test("کاراکترهای ویژه‌ی LIKE (% و _) به‌صورت لفظی جستجو می‌شوند", async () => {
    const pct = await api("GET", `/api/admin/comments?q=${encodeURIComponent("50%_تخفیف")}`, { token: admin.token });
    assert.equal(pct.body.pagination.total, 1);
    const wildcard = await api("GET", `/api/admin/comments?q=${encodeURIComponent("%")}`, { token: admin.token });
    assert.equal(wildcard.body.pagination.total, 1); // فقط همان یک نظری که واقعاً «%» دارد، نه همه
  });
  test("تزریق SQL در q بی‌اثر است", async () => {
    const r = await api("GET", `/api/admin/comments?q=${encodeURIComponent("' OR 1=1 --")}`, { token: admin.token });
    assert.equal(r.status, 200);
    assert.equal(r.body.pagination.total, 0);
  });
  test("بازه‌ی تاریخ شامل روز پایانی", async () => {
    const r = await api("GET", "/api/admin/comments?dateFrom=2026-09-05&dateTo=2026-09-05&limit=100", { token: admin.token });
    assert.ok(r.body.pagination.total > 0);
    assert.ok(r.body.comments.every((c) => new Date(c.createdAt).getDate() === 5));
  });
  test("مرتب‌سازی: قدیمی‌ترین، جدیدترین، در انتظار تأیید اول", async () => {
    const newest = await api("GET", "/api/admin/comments?sort=newest&limit=100", { token: admin.token });
    const oldest = await api("GET", "/api/admin/comments?sort=oldest&limit=100", { token: admin.token });
    assert.ok(new Date(newest.body.comments[0].createdAt) >= new Date(newest.body.comments[59].createdAt));
    assert.ok(new Date(oldest.body.comments[0].createdAt) <= new Date(oldest.body.comments[59].createdAt));
    const pf = await api("GET", "/api/admin/comments?sort=pending_first&limit=100", { token: admin.token });
    assert.ok(pf.body.comments.slice(0, 30).every((c) => c.status === "pending"));
    assert.ok(pf.body.comments.slice(30).every((c) => c.status !== "pending"));
  });
  test("مقادیر نامعتبر ۴۰۰ می‌دهند", async () => {
    for (const qs of ["status=bogus", "sort=rating", "newsId=abc", "dateFrom=1404/07/28", "dateTo=tomorrow"]) {
      assert.equal((await api("GET", `/api/admin/comments?${qs}`, { token: admin.token })).status, 400, qs);
    }
  });
});

describe("آمار، گزینه‌های خبر، جزئیات", () => {
  test("آمار از دیتابیس واقعی است", async () => {
    const r = await api("GET", "/api/admin/comments/stats", { token: admin.token });
    assert.deepEqual(r.body.stats, { total: 60, pending: 30, approved: 20, rejected: 10, deleted: 0 });
  });
  test("گزینه‌های فیلتر خبر فقط خبرهای دارای نظر + شمار نظرات", async () => {
    const r = await api("GET", `/api/admin/comments/news-options?q=${encodeURIComponent(TAG)}`, { token: admin.token });
    assert.equal(r.status, 200);
    const a = r.body.news.find((n) => n.id === newsA);
    assert.equal(a.commentsCount, 30);
  });
  test("جزئیات یک نظر: متن کامل + کاربر + خبر؛ ۴۰۴ و ۴۰۰ برای شناسه‌ی نامعتبر", async () => {
    const list = await api("GET", "/api/admin/comments?limit=1", { token: admin.token });
    const id = list.body.comments[0].id;
    const r = await api("GET", `/api/admin/comments/${id}`, { token: admin.token });
    assert.equal(r.status, 200);
    assert.ok(r.body.comment.content.length > 160);
    assert.ok(r.body.comment.authorEmail && r.body.comment.newsTitle);
    assert.equal((await api("GET", "/api/admin/comments/999999", { token: admin.token })).status, 404);
    assert.equal((await api("GET", "/api/admin/comments/abc", { token: admin.token })).status, 400);
  });
});

describe("تأیید/رد/حذف و ارتباط با نمایش عمومی", () => {
  test("تأیید → در نمایش عمومی خبر ظاهر می‌شود؛ رد → ناپدید می‌شود", async () => {
    const id = await addComment(newsA, authors[0].id, `${TAG} برای تأیید`, "pending", "2026-09-10 10:00:00");
    const before = await api("GET", `/api/news/${newsA}`);
    assert.ok(!before.body.news.comments.some((c) => c.id === id));

    assert.equal((await api("PUT", `/api/admin/comments/${id}/status`, { token: admin.token, body: { status: "approved" } })).status, 200);
    const shown = await api("GET", `/api/news/${newsA}`);
    assert.ok(shown.body.news.comments.some((c) => c.id === id));

    assert.equal((await api("PUT", `/api/admin/comments/${id}/status`, { token: admin.token, body: { status: "rejected" } })).status, 200);
    const hidden = await api("GET", `/api/news/${newsA}`);
    assert.ok(!hidden.body.news.comments.some((c) => c.id === id));
    await api("DELETE", `/api/admin/comments/${id}`, { token: admin.token });
  });
  test("حذف نظر تأییدشده: از نمایش عمومی می‌رود ولی خبر باقی می‌ماند", async () => {
    const id = await addComment(newsA, authors[0].id, `${TAG} برای حذف`, "approved", "2026-09-11 10:00:00");
    assert.ok((await api("GET", `/api/news/${newsA}`)).body.news.comments.some((c) => c.id === id));
    const del = await api("DELETE", `/api/admin/comments/${id}`, { token: admin.token });
    assert.equal(del.status, 200);
    // حذف نرم: ردیف می‌ماند (deletedAt پر می‌شود) و در پنل ادمین با وضعیت «deleted» دیده می‌شود
    const [[soft]] = await db.query("SELECT deletedAt FROM news_comments WHERE id = ?", [id]);
    assert.ok(soft.deletedAt);
    assert.equal((await api("GET", `/api/admin/comments/${id}`, { token: admin.token })).body.comment.status, "deleted");
    assert.ok(!(await api("GET", `/api/news/${newsA}`)).body.news.comments.some((c) => c.id === id));
    const [[n]] = await db.query("SELECT COUNT(*) c FROM news WHERE id = ?", [newsA]);
    assert.equal(n.c, 1);
    assert.equal((await api("DELETE", `/api/admin/comments/${id}`, { token: admin.token })).status, 404);
  });
});

describe("امتیاز، پاسخ ادمین، یادداشت داخلی، ویرایش", () => {
  test("فیلتر و مرتب‌سازی امتیاز", async () => {
    const five = await api("GET", "/api/admin/comments?rating=5&limit=100", { token: admin.token });
    assert.equal(five.body.pagination.total, 9);
    assert.ok(five.body.comments.every((c) => c.rating === 5));
    const hi = await api("GET", "/api/admin/comments?sort=highest&limit=100", { token: admin.token });
    assert.equal(hi.body.comments[0].rating, 5);
    assert.equal(hi.body.comments[hi.body.comments.length - 1].rating, null); // بدون امتیاز آخر
    const lo = await api("GET", "/api/admin/comments?sort=lowest&limit=100", { token: admin.token });
    assert.equal(lo.body.comments[0].rating, 1);
    assert.equal((await api("GET", "/api/admin/comments?rating=9", { token: admin.token })).status, 400);
  });
  test("پاسخ ادمین + یادداشت داخلی + ویرایش متن ذخیره می‌شود و اعلان پاسخ می‌رود", async () => {
    const id = await addComment(newsA, authors[0].id, `${TAG} متن اولیه`, "approved", "2026-09-14 10:00:00");
    const r = await api("PUT", `/api/admin/comments/${id}`, { token: admin.token, body: { content: `${TAG} متن ویرایش‌شده`, adminReply: "ممنون از نظر شما", internalNote: "یادداشت تیم" } });
    assert.equal(r.status, 200);
    const d = (await api("GET", `/api/admin/comments/${id}`, { token: admin.token })).body.comment;
    assert.equal(d.content, `${TAG} متن ویرایش‌شده`);
    assert.equal(d.adminReply, "ممنون از نظر شما");
    assert.ok(d.adminReplyAt);
    assert.equal(d.internalNote, "یادداشت تیم");
    const [[nt]] = await db.query("SELECT COUNT(*) c FROM notifications WHERE userId = ? AND title = 'مدیریت به نظر شما پاسخ داد'", [authors[0].id]);
    assert.equal(nt.c, 1);
    // پاک کردن پاسخ
    await api("PUT", `/api/admin/comments/${id}`, { token: admin.token, body: { adminReply: "" } });
    const d2 = (await api("GET", `/api/admin/comments/${id}`, { token: admin.token })).body.comment;
    assert.equal(d2.adminReply, null);
    assert.equal(d2.adminReplyAt, null);
    assert.equal(d2.internalNote, "یادداشت تیم");
    // اعتبارسنجی
    assert.equal((await api("PUT", `/api/admin/comments/${id}`, { token: admin.token, body: {} })).status, 400);
    assert.equal((await api("PUT", `/api/admin/comments/${id}`, { token: admin.token, body: { content: "ا" } })).status, 400);
    assert.equal((await api("PUT", "/api/admin/comments/999999", { token: admin.token, body: { internalNote: "x" } })).status, 404);
    await db.query("DELETE FROM news_comments WHERE id = ?", [id]);
  });
  test("ثبت نظر عمومی با امتیاز اختیاری (و رد امتیاز نامعتبر)", async () => {
    const ok = await api("POST", `/api/news/${newsB}/comments`, { token: normalUser.token, body: { content: `${TAG} نظر با امتیاز`, rating: 4 } });
    assert.equal(ok.status, 201);
    const [[row]] = await db.query("SELECT rating, status FROM news_comments WHERE id = ?", [ok.body.comment.id]);
    assert.equal(row.rating, 4);
    assert.equal(row.status, "pending");
    const bad = await api("POST", `/api/news/${newsB}/comments`, { token: normalUser.token, body: { content: `${TAG} امتیاز بد`, rating: 7 } });
    assert.equal(bad.status, 400);
    await db.query("DELETE FROM news_comments WHERE id = ?", [ok.body.comment.id]);
  });
});

describe("عملیات گروهی", () => {
  let ids;
  before(async () => {
    ids = [];
    for (let i = 0; i < 5; i += 1) ids.push(await addComment(newsB, authors[1].id, `${TAG} گروهی ${i}`, "pending", "2026-09-12 10:00:00"));
  });
  test("تأیید گروهی → وضعیت approved + نمایش عمومی + اعلان به نویسنده", async () => {
    const r = await api("POST", "/api/admin/comments/bulk", { token: admin.token, body: { ids, action: "approve" } });
    assert.equal(r.status, 200);
    assert.equal(r.body.affected, 5);
    const [[c]] = await db.query("SELECT COUNT(*) c FROM news_comments WHERE id IN (?) AND status='approved'", [ids]);
    assert.equal(c.c, 5);
    const pub = await api("GET", `/api/news/${newsB}`);
    assert.ok(ids.every((id) => pub.body.news.comments.some((x) => x.id === id)));
    const [[nt]] = await db.query("SELECT COUNT(*) c FROM notifications WHERE userId = ? AND type = 'news_comment' AND relatedId = ?", [authors[1].id, newsB]);
    assert.ok(nt.c >= 5);
  });
  test("تکرار همان عملیات: affected = 0 و اعلان تکراری نمی‌رود", async () => {
    const r = await api("POST", "/api/admin/comments/bulk", { token: admin.token, body: { ids, action: "approve" } });
    assert.equal(r.status, 200);
    assert.equal(r.body.affected, 0);
  });
  test("رد گروهی → از نمایش عمومی حذف می‌شود", async () => {
    const r = await api("POST", "/api/admin/comments/bulk", { token: admin.token, body: { ids, action: "reject" } });
    assert.equal(r.body.affected, 5);
    const pub = await api("GET", `/api/news/${newsB}`);
    assert.ok(!ids.some((id) => pub.body.news.comments.some((x) => x.id === id)));
  });
  test("حذف گروهی فقط نظرها را پاک می‌کند، خبر می‌ماند", async () => {
    const r = await api("POST", "/api/admin/comments/bulk", { token: admin.token, body: { ids, action: "delete" } });
    assert.equal(r.status, 200);
    assert.equal(r.body.affected, 5);
    const [[c]] = await db.query("SELECT COUNT(*) c FROM news_comments WHERE id IN (?) AND deletedAt IS NOT NULL", [ids]);
    assert.equal(c.c, 5);
    const [[n]] = await db.query("SELECT COUNT(*) c FROM news WHERE id = ?", [newsB]);
    assert.equal(n.c, 1);
  });
  test("بازگردانی نظر حذف‌شده: دوباره با وضعیت قبلی در پنل (و اگر approved بود در سایت) ظاهر می‌شود", async () => {
    const id = await addComment(newsA, authors[0].id, `${TAG} بازگردانی`, "approved", "2026-09-13 10:00:00");
    await api("DELETE", `/api/admin/comments/${id}`, { token: admin.token });
    assert.ok(!(await api("GET", `/api/news/${newsA}`)).body.news.comments.some((c) => c.id === id));
    const del = await api("GET", "/api/admin/comments?status=deleted", { token: admin.token });
    assert.ok(del.body.comments.some((c) => c.id === id && c.rawStatus === "approved"));
    assert.equal((await api("POST", `/api/admin/comments/${id}/restore`, { token: admin.token })).status, 200);
    assert.ok((await api("GET", `/api/news/${newsA}`)).body.news.comments.some((c) => c.id === id));
    assert.equal((await api("POST", `/api/admin/comments/${id}/restore`, { token: admin.token })).status, 400);
    await db.query("DELETE FROM news_comments WHERE id = ?", [id]);
  });
  test("ورودی نامعتبر رد می‌شود", async () => {
    const post = (body) => api("POST", "/api/admin/comments/bulk", { token: admin.token, body });
    assert.equal((await post({ ids: [], action: "approve" })).status, 400);
    assert.equal((await post({ ids: [1], action: "drop" })).status, 400);
    assert.equal((await post({ ids: Array.from({ length: 201 }, (_, i) => i + 1), action: "approve" })).status, 400);
    assert.equal((await post({ ids: [999998, 999999], action: "delete" })).status, 404);
  });
});

describe("RBAC — کاربر عادی و مهمان به هیچ‌کدام دسترسی ندارند", () => {
  const cases = [
    ["GET", "/api/admin/comments"],
    ["GET", "/api/admin/comments/stats"],
    ["GET", "/api/admin/comments/news-options"],
    ["GET", "/api/admin/comments/1"],
    ["POST", "/api/admin/comments/bulk"],
    ["PUT", "/api/admin/comments/1/status"],
    ["DELETE", "/api/admin/comments/1"],
    ["PUT", "/api/admin/comments/1"],
    ["POST", "/api/admin/comments/1/restore"],
  ];
  for (const [method, path] of cases) {
    test(`${method} ${path}`, async () => {
      const body = method === "GET" ? undefined : { ids: [1], action: "delete", status: "approved" };
      const asUser = await api(method, path, { token: normalUser.token, body });
      assert.equal(asUser.status, 403);
      const asGuest = await api(method, path, { body });
      assert.ok([401, 403].includes(asGuest.status));
    });
  }
});

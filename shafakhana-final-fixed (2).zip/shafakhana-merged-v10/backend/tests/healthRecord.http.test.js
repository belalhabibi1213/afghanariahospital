import { test, describe, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import path from "path";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, upload, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";
import { MEDICAL_FILES_DIR } from "../middleware/upload.js";
import db from "../db.js";

// فرم «افزودن پرونده صحی» (پنل داکتر): پیش‌نویس ← ثبت ← فایل‌ها/آزمایش ← ارسال ← مشاهده‌ی بیمار + امنیت مالکیت
before(startServer);
after(async () => { await stopServer(); await closePool(); });

const PNG = Buffer.from("89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c6360000002000001e221bc330000000049454e44ae426082", "hex");
const PDF = Buffer.from("%PDF-1.4\n1 0 obj<<>>endobj\ntrailer<<>>\n%%EOF");
const FORM = {
  visitReason: "درد قفسه سینه", chiefComplaint: "درد از دو روز پیش", symptoms: "درد با فعالیت بیشتر می‌شود",
  bloodPressure: "120/80", pulse: "72", temperature: "36.5", respiratoryRate: "16", weight: "70", height: "175", spo2: "98",
  generalCondition: "متوسط", examFindings: "صدای قلب نرمال", abnormalFindings: "ندارد", examNotes: "یادداشت خصوصی معاینه",
  systemsReview: { cardiovascular: { abnormal: true, note: "سوفل خفیف" }, bogus: { abnormal: true, note: "x" } },
  primaryDiagnosis: "آنژین مشکوک", diagnosis: "آنژین ناپایدار", diagnosisNotes: "نیاز به بررسی",
  recommendations: { advice: "استراحت کافی", diet: "کم‌نمک", evil: "x" },
  followUpRequired: true, followUpDate: "2030-01-15", followUpStatus: "pending", followUpNotes: "نوار قلب",
};

describe("چرخه‌ی کامل پرونده صحی", () => {
  let doc; let other; let patientUser; let patientId; let apptId; let recId; let fileId;

  before(async () => {
    doc = await createTestDoctor();
    other = await createTestDoctor();
    patientUser = await makeSession("user");
    patientId = await createTestPatient(patientUser.id, "بیمار پرونده");
    apptId = await addAppointment(patientId, doc.id, "confirmed");
  });

  test("پیش‌نویس: ذخیره می‌شود، برای بیمار نامرئی است و اعلان نمی‌سازد", async () => {
    const r = await api("POST", "/api/medical-records/encounters", { token: doc.token, body: { patientId, appointmentId: apptId, status: "draft", visitReason: "پیش‌نویس", symptoms: "x" } });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    assert.equal(r.body.record.status, "draft");
    const id = r.body.record.id;
    const list = await api("GET", "/api/users/health-records", { token: patientUser.token });
    assert.ok(!list.body.records.some((x) => x.id === id));
    assert.equal((await api("GET", `/api/users/health-records/${id}`, { token: patientUser.token })).status, 404);
    const emr = await api("GET", "/api/users/emr", { token: patientUser.token });
    assert.ok(!emr.body.encounters.some((x) => x.id === id));
    const tl = await api("GET", "/api/users/medical-history", { token: patientUser.token });
    assert.ok(!(tl.body.items || []).some((x) => x.type === "encounter" && x.id === id));
    const [[n]] = await db.query("SELECT COUNT(*) c FROM notifications WHERE userId = ? AND relatedId = ?", [patientUser.id, id]);
    assert.equal(n.c, 0);
    await api("DELETE", `/api/medical-records/encounters/${id}`, { token: doc.token });
  });

  test("ثبت نهایی بدون دلیل مراجعه رد می‌شود؛ با دلیل ثبت و فیلدهای جدید ذخیره می‌شوند (JSONهای نامعتبر فیلتر)", async () => {
    const bad = await api("POST", "/api/medical-records/encounters", { token: doc.token, body: { patientId, status: "registered", symptoms: "x" } });
    assert.equal(bad.status, 400);
    const r = await api("POST", "/api/medical-records/encounters", { token: doc.token, body: { patientId, appointmentId: apptId, status: "registered", ...FORM } });
    assert.equal(r.status, 201, JSON.stringify(r.body));
    recId = r.body.record.id;
    const rep = await api("GET", `/api/medical-records/encounters/${recId}/report`, { token: doc.token });
    assert.equal(rep.status, 200);
    assert.equal(rep.body.record.pulse, "72");
    assert.equal(rep.body.record.diagnosis, "آنژین ناپایدار");
    assert.deepEqual(Object.keys(rep.body.record.systemsReview), ["cardiovascular"]);
    assert.deepEqual(Object.keys(rep.body.record.recommendations).sort(), ["advice", "diet"]);
    assert.equal(rep.body.record.followUpRequired, 1);
    assert.equal(rep.body.patient.publicCode.startsWith("AAH-"), true);
    assert.equal(rep.body.canEdit, true);
    const [[n]] = await db.query("SELECT COUNT(*) c FROM notifications WHERE userId = ? AND relatedId = ? AND type = 'medical_record'", [patientUser.id, recId]);
    assert.equal(n.c, 1);
  });

  test("اعتبارسنجی: فرمت‌های نامعتبر ۴۰۰", async () => {
    for (const body of [{ followUpStatus: "weird" }, { followUpDate: "not-a-date" }, { status: "x" }, { pulse: "1".repeat(30) }, { recommendations: [1, 2] }]) {
      const r = await api("PUT", `/api/medical-records/encounters/${recId}`, { token: doc.token, body });
      assert.equal(r.status, 400, JSON.stringify(body));
    }
    const noBack = await api("PUT", `/api/medical-records/encounters/${recId}`, { token: doc.token, body: { status: "draft" } });
    assert.equal(noBack.status, 400);
  });

  test("آزمایش متصل به پرونده + فایل‌ها (تصویر/سند) آپلود می‌شوند", async () => {
    const lab = await api("POST", "/api/medical-records/lab-results", { token: doc.token, body: { patientId, recordId: recId, testName: "CBC", result: "12", unit: "g/dL", referenceRange: "12-16", status: "completed", testDate: "2030-01-01" } });
    assert.equal(lab.status, 201, JSON.stringify(lab.body));
    const img = await upload("POST", `/api/medical-records/encounters/${recId}/files`, {
      token: doc.token, fields: { kind: "image", category: "xray", title: "ایکس‌ری قفسه سینه", fileDate: "2030-01-01", description: "نمای PA" },
      files: [{ field: "file", content: PNG, type: "image/png", filename: "x.png" }],
    });
    assert.equal(img.status, 201, JSON.stringify(img.body));
    assert.equal(img.body.file.storedName, undefined, "نام داخلی دیسک نباید نشت کند");
    fileId = img.body.file.id;
    const pdf = await upload("POST", `/api/medical-records/encounters/${recId}/files`, {
      token: doc.token, fields: { kind: "document", category: "medical_report", title: "گزارش" },
      files: [{ field: "file", content: PDF, type: "application/pdf", filename: "گزارش.pdf" }],
    });
    assert.equal(pdf.status, 201, JSON.stringify(pdf.body));
    const rep = await api("GET", `/api/medical-records/encounters/${recId}/report`, { token: doc.token });
    assert.equal(rep.body.files.length, 2);
    assert.equal(rep.body.labResults.length, 1);
  });

  test("آپلود مخرب/نامعتبر رد می‌شود و فایلی روی دیسک نمی‌ماند", async () => {
    const before = fs.readdirSync(MEDICAL_FILES_DIR).length;
    const fake = await upload("POST", `/api/medical-records/encounters/${recId}/files`, { token: doc.token, fields: { kind: "image", title: "جعلی" }, files: [{ field: "file", content: Buffer.from("MZ-exe"), type: "image/png", filename: "a.png" }] });
    assert.equal(fake.status, 400);
    const exe = await upload("POST", `/api/medical-records/encounters/${recId}/files`, { token: doc.token, fields: { kind: "document", title: "x" }, files: [{ field: "file", content: Buffer.from("x"), type: "application/x-msdownload", filename: "a.exe" }] });
    assert.equal(exe.status, 400);
    const pdfAsImage = await upload("POST", `/api/medical-records/encounters/${recId}/files`, { token: doc.token, fields: { kind: "image", title: "x" }, files: [{ field: "file", content: PDF, type: "application/pdf", filename: "a.pdf" }] });
    assert.equal(pdfAsImage.status, 400);
    const noTitle = await upload("POST", `/api/medical-records/encounters/${recId}/files`, { token: doc.token, fields: { kind: "image" }, files: [{ field: "file", content: PNG, type: "image/png", filename: "a.png" }] });
    assert.equal(noTitle.status, 400);
    assert.equal(fs.readdirSync(MEDICAL_FILES_DIR).length, before);
  });

  test("قبل از ارسال: بیمار پرونده را می‌بیند ولی توصیه/پیگیری/فایل و فیلدهای داخلی معاینه را نه", async () => {
    const d = await api("GET", `/api/users/health-records/${recId}`, { token: patientUser.token });
    assert.equal(d.status, 200);
    assert.equal(d.body.record.released, false);
    assert.equal(d.body.record.diagnosis, "آنژین ناپایدار");
    for (const k of ["recommendations_x", "examNotes", "examFindings", "systemsReview", "abnormalFindings"]) assert.equal(d.body.record[k], undefined, k);
    assert.deepEqual(d.body.record.recommendations, {});
    assert.equal(d.body.record.followUpDate, undefined);
    assert.equal(d.body.files.length, 0);
    assert.equal(d.body.labResults.length, 1);
    assert.equal((await api("GET", `/api/users/health-records/files/${fileId}`, { token: patientUser.token })).status, 404);
    const emr = await api("GET", "/api/users/emr", { token: patientUser.token });
    const e = emr.body.encounters.find((x) => x.id === recId);
    assert.ok(e && e.recommendations === undefined && e.examNotes === undefined && e.followUpDate === undefined);
  });

  test("ارسال به بیمار: فقط ثبت‌شده، فقط داکتر ثبت‌کننده؛ اعلان + آزادسازی محتوا", async () => {
    assert.equal((await api("POST", `/api/medical-records/encounters/${recId}/send`, { token: other.token, body: {} })).status, 403);
    assert.equal((await api("POST", `/api/medical-records/encounters/${recId}/send`, { token: patientUser.token, body: {} })).status, 403);
    assert.equal((await api("POST", `/api/medical-records/encounters/${recId}/send`, { token: doc.token, body: { message: "x".repeat(1001) } })).status, 400);
    const draft = await api("POST", "/api/medical-records/encounters", { token: doc.token, body: { patientId, status: "draft" } });
    assert.equal((await api("POST", `/api/medical-records/encounters/${draft.body.record.id}/send`, { token: doc.token, body: {} })).status, 400);
    await api("DELETE", `/api/medical-records/encounters/${draft.body.record.id}`, { token: doc.token });

    const s = await api("POST", `/api/medical-records/encounters/${recId}/send`, { token: doc.token, body: { message: "نتایج شما ثبت شد" } });
    assert.equal(s.status, 200, JSON.stringify(s.body));
    assert.ok(s.body.record.sentToPatientAt);
    const [[n]] = await db.query("SELECT COUNT(*) c FROM notifications WHERE userId = ? AND relatedId = ? AND type = 'health_record'", [patientUser.id, recId]);
    assert.equal(n.c, 1);

    const d = await api("GET", `/api/users/health-records/${recId}`, { token: patientUser.token });
    assert.equal(d.body.record.released, true);
    assert.equal(d.body.record.sentNote, "نتایج شما ثبت شد");
    assert.equal(d.body.record.recommendations.advice, "استراحت کافی");
    assert.equal(d.body.record.followUpDate.slice(0, 10), "2030-01-15");
    assert.equal(d.body.files.length, 2);
    assert.equal(d.body.record.examNotes, undefined, "یادداشت خصوصی معاینه هرگز برای بیمار نیست");
    const f = await api("GET", `/api/users/health-records/files/${fileId}`, { token: patientUser.token });
    assert.equal(f.status, 200);
    assert.ok((f.headers.get("content-type") || "").startsWith("image/png"));
    const list = await api("GET", "/api/users/health-records", { token: patientUser.token });
    assert.equal(list.body.records.find((x) => x.id === recId).released, true);
  });

  test("امنیت: بیمار دیگر/داکتر بی‌ربط/بدون توکن به پرونده و فایل‌ها دسترسی ندارند (IDOR)", async () => {
    const stranger = await makeSession("user");
    await createTestPatient(stranger.id, "غریبه");
    assert.equal((await api("GET", `/api/users/health-records/${recId}`, { token: stranger.token })).status, 404);
    assert.equal((await api("GET", `/api/users/health-records/files/${fileId}`, { token: stranger.token })).status, 404);
    assert.equal((await api("GET", `/api/medical-records/encounters/${recId}/report`, { token: other.token })).status, 403);
    assert.equal((await api("GET", `/api/medical-records/files/${fileId}`, { token: other.token })).status, 403);
    assert.equal((await api("GET", `/api/medical-records/files/${fileId}`, { token: patientUser.token })).status, 403, "بیمار مسیر داکتر را نمی‌تواند بزند");
    assert.equal((await api("GET", `/api/medical-records/files/${fileId}`)).status, 401);
    assert.equal((await api("GET", `/api/users/health-records/${recId}`)).status, 401);
    assert.equal((await api("DELETE", `/api/medical-records/files/${fileId}`, { token: other.token })).status, 403);
    assert.equal((await api("PUT", `/api/medical-records/encounters/${recId}`, { token: other.token, body: { diagnosis: "هک" } })).status, 403);
    const own = await api("GET", `/api/medical-records/files/${fileId}?download=1`, { token: doc.token });
    assert.equal(own.status, 200);
    assert.ok((own.headers.get("content-disposition") || "").startsWith("attachment"));
  });

  test("قابلیت‌های قبلی: ویرایش، حذف فایل، و حذف پرونده (فایل‌ها از دیسک پاک می‌شوند)", async () => {
    const edit = await api("PUT", `/api/medical-records/encounters/${recId}`, { token: doc.token, body: { symptoms: "ویرایش‌شده", pulse: "80" } });
    assert.equal(edit.status, 200);
    assert.equal(edit.body.record.pulse, "80");
    assert.equal(edit.body.record.diagnosis, "آنژین ناپایدار", "فیلدهای ارسال‌نشده نباید پاک شوند");
    const rep = await api("GET", `/api/medical-records/encounters/${recId}/report`, { token: doc.token });
    const [first, second] = rep.body.files;
    assert.equal((await api("DELETE", `/api/medical-records/files/${first.id}`, { token: doc.token })).status, 200);
    const [[stored]] = await db.query("SELECT storedName FROM medical_record_files WHERE id = ?", [second.id]);
    assert.ok(fs.existsSync(path.join(MEDICAL_FILES_DIR, stored.storedName)));
    assert.equal((await api("DELETE", `/api/medical-records/encounters/${recId}`, { token: doc.token })).status, 200);
    assert.equal(fs.existsSync(path.join(MEDICAL_FILES_DIR, stored.storedName)), false);
    const [[left]] = await db.query("SELECT COUNT(*) c FROM medical_record_files WHERE recordId = ?", [recId]);
    assert.equal(left.c, 0);
  });

  test("رکورد قدیمی (بدون فیلدهای جدید) هنوز ثبت و برای بیمار قابل‌مشاهده است (سازگاری عقب‌رو)", async () => {
    const r = await api("POST", "/api/medical-records/encounters", { token: doc.token, body: { patientId, symptoms: "قدیمی", diagnosis: "سرماخوردگی", bloodPressure: "110/70" } });
    assert.equal(r.status, 201);
    assert.equal(r.body.record.status, "registered");
    const emr = await api("GET", "/api/users/emr", { token: patientUser.token });
    assert.ok(emr.body.encounters.some((x) => x.id === r.body.record.id));
  });
});

describe("آزمایش پیش‌نویس برای بیمار پنهان است", () => {
  test("آزمایشِ متصل به پیش‌نویس در لیست آزمایش‌های بیمار نیست", async () => {
    const doc = await createTestDoctor();
    const pu = await makeSession("user");
    const pid = await createTestPatient(pu.id, "بیمار پیش‌نویس");
    await addAppointment(pid, doc.id, "confirmed");
    const rec = await api("POST", "/api/medical-records/encounters", { token: doc.token, body: { patientId: pid, status: "draft" } });
    const lab = await api("POST", "/api/medical-records/lab-results", { token: doc.token, body: { patientId: pid, recordId: rec.body.record.id, testName: "پنهان", result: "1", status: "completed" } });
    assert.equal(lab.status, 201);
    const labs = await api("GET", "/api/users/lab-results", { token: pu.token });
    assert.ok(!(labs.body.labResults || labs.body.results || []).some((x) => x.testName === "پنهان"));
    assert.equal((await api("GET", `/api/users/lab-results/${lab.body.item.id}/report`, { token: pu.token })).status, 404);
    await api("PUT", `/api/medical-records/encounters/${rec.body.record.id}`, { token: doc.token, body: { status: "registered", visitReason: "ثبت" } });
    const after = await api("GET", "/api/users/lab-results", { token: pu.token });
    assert.ok((after.body.labResults || after.body.results || []).some((x) => x.testName === "پنهان"));
  });
});

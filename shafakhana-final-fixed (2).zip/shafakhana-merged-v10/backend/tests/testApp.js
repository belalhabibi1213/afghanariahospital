// زیرساخت مشترک تست‌های HTTP (end-to-end):
// یک اپلیکیشن Express واقعی با «همان مسیرها و همان میان‌افزارهای server.js» روی یک پورت
// تصادفی بالا می‌آورد — بدون cron ها، بدون ایمیل واقعی و بدون محدودیت‌های نرخ درخواست عمومی
// (تا تست‌ها هم‌دیگر را با 429 خراب نکنند). server.js عمداً دست‌نخورده مانده چون همان لحظه‌ی
// import شروع به listen می‌کند؛ این فایل فقط مسیرها را مثل آن سوار می‌کند.
//
// نکته: این فایل باید بعد از testEnv.js import شود (تا DB_NAME به دیتابیس _test تغییر کند).
import "./testEnv.js";
import express from "express";
import http from "http";
import bcrypt from "bcryptjs";

import db from "../db.js";
import authRoutes from "../routes/auth.js";
import appointmentRoutes from "../routes/appointments.js";
import doctorRoutes from "../routes/doctors.js";
import newsRoutes from "../routes/news.js";
import departmentRoutes from "../routes/departments.js";
import searchRoutes from "../routes/search.js";
import contactRoutes from "../routes/contacts.js";
import userRoutes from "../routes/users.js";
import adminRoutes from "../routes/admin.js";
import superadminRoutes from "../routes/superadmin.js";
import medicalRecordRoutes from "../routes/medicalRecords.js";
import billingRoutes from "../routes/billing.js";
import reportRoutes from "../routes/reports.js";
import chatRoutes from "../routes/chat.js";
import settingsRoutes from "../routes/settings.js";
import healthRoutes from "../routes/health.js";
import { notFoundHandler, errorHandler } from "../middleware/errorHandler.js";
import { csrfProtection } from "../middleware/csrf.js";
import { findOrCreatePatient } from "../models/Patient.js";

export const DEFAULT_PASSWORD = "Abcd1234";

let server = null;
let baseUrl = "";
let seq = 0;
const stamp = Date.now().toString(36);

export function buildApp() {
  const app = express();
  app.use(express.json({ limit: "1mb" }));
  app.use("/api", csrfProtection); // همان ترتیب server.js
  app.get("/", (req, res) => res.json({ message: "ok" }));
  app.use("/api/auth", authRoutes);
  app.use("/api/appointments", appointmentRoutes);
  app.use("/api/doctors", doctorRoutes);
  app.use("/api/news", newsRoutes);
  app.use("/api/departments", departmentRoutes);
  app.use("/api/search", searchRoutes);
  app.use("/api/contacts", contactRoutes);
  app.use("/api/users", userRoutes);
  app.use("/api/admin", adminRoutes);
  app.use("/api/superadmin", superadminRoutes);
  app.use("/api/medical-records", medicalRecordRoutes);
  app.use("/api/billing", billingRoutes);
  app.use("/api/reports", reportRoutes);
  app.use("/api/chat", chatRoutes);
  app.use("/api/settings", settingsRoutes);
  app.use("/health", healthRoutes);
  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}

export async function startServer() {
  if (server) return baseUrl;
  server = http.createServer(buildApp());
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  baseUrl = `http://127.0.0.1:${server.address().port}`;
  return baseUrl;
}

export async function stopServer() {
  if (!server) return;
  await new Promise((resolve) => server.close(resolve));
  server = null;
}

// درخواست HTTP واقعی؛ خروجی: { status, body, headers, raw }
export async function api(method, path, { token, body, headers = {}, rawBody, contentType } = {}) {
  const h = { ...headers };
  if (token) h.Authorization = `Bearer ${token}`;
  let payload;
  if (rawBody !== undefined) {
    payload = rawBody;
    h["Content-Type"] = contentType || "application/json";
  } else if (body !== undefined) {
    payload = JSON.stringify(body);
    h["Content-Type"] = "application/json";
  }
  const res = await fetch(baseUrl + path, { method, headers: h, body: payload });
  const buf = Buffer.from(await res.arrayBuffer());
  let parsed = null;
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) {
    try { parsed = JSON.parse(buf.toString("utf8")); } catch { parsed = null; }
  }
  return { status: res.status, body: parsed, headers: res.headers, raw: buf };
}

// ارسال multipart/form-data (برای تست آپلود فایل)
export async function upload(method, path, { token, fields = {}, files = [] } = {}) {
  const form = new FormData();
  for (const [k, v] of Object.entries(fields)) form.append(k, String(v));
  for (const f of files) {
    form.append(f.field, new Blob([f.content], { type: f.type }), f.filename);
  }
  const h = {};
  if (token) h.Authorization = `Bearer ${token}`;
  const res = await fetch(baseUrl + path, { method, headers: h, body: form });
  const buf = Buffer.from(await res.arrayBuffer());
  let parsed = null;
  if ((res.headers.get("content-type") || "").includes("application/json")) {
    try { parsed = JSON.parse(buf.toString("utf8")); } catch { parsed = null; }
  }
  return { status: res.status, body: parsed, headers: res.headers, raw: buf };
}

export function uniqueEmail(label = "u") {
  seq += 1;
  return `${label}-${stamp}-${seq}@test.local`;
}

// ایمیل gmail معتبر برای تست ثبت‌نام واقعی (قانون Gmail پروژه: فقط حرف/عدد/نقطه، ۶ تا ۳۰ نویسه)
export function uniqueGmail(label = "user") {
  seq += 1;
  return `${label}${stamp}${seq}@gmail.com`.toLowerCase();
}

// ساخت مستقیم کاربر در دیتابیس (تاییدشده و فعال) — سریع‌تر از مسیر ثبت‌نام + ایمیل
export async function createTestUser({ role = "user", fullName, email, password = DEFAULT_PASSWORD, isActive = 1, isVerified = 1 } = {}) {
  seq += 1;
  const mail = (email || uniqueEmail(role)).toLowerCase();
  const hash = await bcrypt.hash(password, 4);
  const [r] = await db.query(
    "INSERT INTO users (fullName, email, password, role, isActive, isVerified) VALUES (?, ?, ?, ?, ?, ?)",
    [fullName || `کاربر ${role} ${seq}`, mail, hash, role, isActive, isVerified]
  );
  return { id: r.insertId, email: mail, password, role };
}

// ورود واقعی از مسیر POST /api/auth/login و برگرداندن توکن
export async function loginAs(user) {
  const res = await api("POST", "/api/auth/login", { body: { email: user.email, password: user.password || DEFAULT_PASSWORD } });
  if (res.status !== 200) throw new Error(`ورود تستی ناموفق (${res.status}): ${JSON.stringify(res.body)}`);
  return extractAuthCookie(res.headers);
}

// توکن دیگر در بدنه‌ی JSON نیست؛ از کوکی httpOnly پاسخ ورود (Set-Cookie) استخراج می‌شود.
// تست‌ها همچنان با هدر Bearer می‌فرستند (مسیر سازگار با کلاینت‌های API).
export function extractAuthCookie(headers) {
  const cookies = typeof headers.getSetCookie === "function" ? headers.getSetCookie() : [headers.get("set-cookie") || ""];
  for (const c of cookies) {
    const m = /^shafakhana_token=([^;]+)/.exec(c);
    if (m) return decodeURIComponent(m[1]);
  }
  return null;
}

// کاربر + توکن در یک قدم
export async function makeSession(role = "user", opts = {}) {
  const user = await createTestUser({ role, ...opts });
  const token = await loginAs(user);
  return { ...user, token };
}

// ساخت داکتر (رکورد doctors) و در صورت نیاز حساب کاربری داکتر که به آن وصل است
export async function createTestDoctor({ withUser = true, department = "تست" } = {}) {
  seq += 1;
  const code = `T${stamp.slice(-4).toUpperCase()}${seq}`.slice(0, 20);
  let userId = null;
  let session = null;
  if (withUser) {
    session = await makeSession("doctor");
    userId = session.id;
  }
  const [r] = await db.query(
    "INSERT INTO doctors (doctorCode, fullName, department, userId) VALUES (?, ?, ?, ?)",
    [code, `داکتر تست ${seq}`, department, userId]
  );
  return { id: r.insertId, userId, token: session?.token, email: session?.email, password: session?.password };
}

// ساخت بیمارِ وصل‌شده به یک کاربر
export async function createTestPatient(userId, label = "بیمار تست") {
  seq += 1;
  const p = await findOrCreatePatient({ fullName: `${label} ${seq}`, phone: `07${String(Date.now()).slice(-7)}${seq % 10}`, userId });
  return p.id;
}

export async function addAppointment(patientId, doctorId, status = "pending", { dayOffset = 5, time = "09:00:00" } = {}) {
  const [r] = await db.query(
    "INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, status) VALUES (?, ?, 'تست', DATE_ADD(CURDATE(), INTERVAL ? DAY), ?, ?)",
    [patientId, doctorId, dayOffset, time, status]
  );
  return r.insertId;
}

import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import os from "os";
import path from "path";
import crypto from "crypto";
import { closePool } from "./testEnv.js";

// بکاپ‌های این تست در پوشه‌ی موقت نوشته می‌شوند، نه private-uploads/backups واقعی
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), "upload-store-test-"));
process.env.BACKUP_STORAGE_DIR = TMP;
const { default: db } = await import("../db.js");
const store = await import("../utils/uploadStore.js");
const { createBackup, restoreBackup, splitSqlStatements, stopBackupScheduler } = await import("../utils/backup.js");

const sha = (b) => crypto.createHash("sha256").update(b).digest("hex");
const created = [];

function makeFile(dir, bytes) {
  const name = `uploadstoretest${crypto.randomBytes(6).toString("hex")}.jpg`;
  const full = path.join(store.UPLOADS_ROOT, dir, name);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, bytes);
  created.push(full);
  return { full, key: `${dir}/${name}`, url: `/uploads/${dir}/${name}` };
}

async function fetchFromMiddleware(url) {
  let body = null;
  let status = null;
  const res = {
    set() {},
    status(s) {
      status = s;
      return this;
    },
    end(b) {
      body = b;
    },
  };
  let fell = false;
  await store.serveUploadFromDb({ method: "GET", path: url.replace("/uploads", "") }, res, () => {
    fell = true;
  });
  return { body, status, fell };
}

describe("ذخیره‌ی ماندگار عکس‌ها در دیتابیس", () => {
  before(async () => {
    await db.query("SELECT 1");
  });

  after(async () => {
    for (const f of created) {
      fs.rmSync(f, { force: true });
      await db.query("DELETE FROM uploaded_files WHERE path = ?", [`${path.basename(path.dirname(f))}/${path.basename(f)}`]);
    }
    stopBackupScheduler?.();
    fs.rmSync(TMP, { recursive: true, force: true });
    await closePool();
  });

  test("عکس بزرگ‌تر از ۲۵۶ کیلوبایت ذخیره می‌شود و بعد از حذف فایل از دیسک، بایت‌به‌بایت برمی‌گردد", async () => {
    const bytes = crypto.randomBytes(700 * 1024);
    const f = makeFile("doctors", bytes);
    assert.equal(await store.persistUploadedFile(f.full), true);

    fs.rmSync(f.full);
    const r = await fetchFromMiddleware(f.url);
    assert.equal(r.fell, false);
    assert.equal(r.status, 200);
    assert.equal(sha(r.body), sha(bytes));
    assert.ok(fs.existsSync(f.full), "فایل باید روی دیسک بازسازی شود");
  });

  test("مسیر خصوصی یا ناشناس ذخیره/سرو نمی‌شود", async () => {
    assert.equal(store.uploadKeyFromPath(path.join(store.UPLOADS_ROOT, "..", "private-uploads", "signatures", "a.png")), null);
    assert.equal(store.uploadKeyFromPath(path.join(store.UPLOADS_ROOT, "evil", "a.png")), null);
    const r = await fetchFromMiddleware("/uploads/doctors/..%2f..%2f.env");
    assert.equal(r.fell, true);
  });

  test("removeUploadedFile هم از دیسک و هم از دیتابیس پاک می‌کند", async () => {
    const f = makeFile("news", crypto.randomBytes(1000));
    await store.persistUploadedFile(f.full);
    store.removeUploadedFile(f.full);
    await new Promise((r) => setTimeout(r, 300));
    const [rows] = await db.query("SELECT COUNT(*) c FROM uploaded_files WHERE path = ?", [f.key]);
    assert.equal(rows[0].c, 0);
    assert.equal(fs.existsSync(f.full), false);
  });

  test("syncUploadsToDb عکس موجود روی دیسک را به دیتابیس اضافه می‌کند", async () => {
    const f = makeFile("departments", crypto.randomBytes(5000));
    await store.syncUploadsToDb();
    const [rows] = await db.query("SELECT size FROM uploaded_files WHERE path = ?", [f.key]);
    assert.equal(rows[0].size, 5000);
  });

  test("splitSqlStatements نقطه‌ویرگول داخل رشته و کامنت را جدا نمی‌کند", () => {
    const sql = "-- a; b\nINSERT INTO t VALUES ('x;\\n;y', X'3B');\nSET @a = \"q;\";\n";
    const parts = splitSqlStatements(sql);
    assert.equal(parts.length, 2);
    assert.ok(parts[0].includes("x;"));
  });

  test("پشتیبان‌گیری و بازیابی، عکس‌ها را سالم برمی‌گرداند و هر دستور INSERT کوچک می‌ماند", async () => {
    const bytes = crypto.randomBytes(900 * 1024);
    const f = makeFile("doctors", bytes);
    await store.persistUploadedFile(f.full);

    const backup = await createBackup({ triggeredBy: "manual" });
    const sql = fs.readFileSync(path.join(TMP, backup.filename), "utf8");
    assert.ok(Math.max(...splitSqlStatements(sql).map((s) => s.length)) < 800_000);

    await db.query("DELETE FROM uploaded_files WHERE path = ?", [f.key]);
    await restoreBackup(backup.filename);

    fs.rmSync(f.full, { force: true });
    const r = await fetchFromMiddleware(f.url);
    assert.equal(sha(r.body), sha(bytes));
  });
});

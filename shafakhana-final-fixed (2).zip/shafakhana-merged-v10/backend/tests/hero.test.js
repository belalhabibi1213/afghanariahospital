import { test, describe } from "node:test";
import assert from "node:assert/strict";
import { sanitizeHeroInput } from "../utils/heroContent.js";

// اعتبارسنجی ورودی «مدیریت بخش اصلی (Hero)» — بدون نیاز به دیتابیس
const L = (fa, ps = "", en = "") => ({ fa, ps, en });
const valid = () => ({
  eyebrow: L("پذیرش آنلاین"),
  titleBefore: L("مراقبت صحی که"), titleAccent: L("با آرامش"), titleAfter: L("در کنار شماست"),
  lead: L("{hospital}، توضیح"),
  primaryButton: { text: L("گرفتن وقت"), link: "#appointment" },
  secondaryButton: { text: L("دیدن داکتران"), link: "#doctors" },
  stats: [{ id: "a", value: L("۱۸+"), label: L("سال تجربه") }],
  pulse: [{ id: "p", value: L("۷۲"), label: L("ضربان") }],
});

describe("sanitizeHeroInput", () => {
  test("ورودی معتبر بدون خطا پاک‌سازی می‌شود و عکس از ورودی پذیرفته نمی‌شود", () => {
    const { errors, value } = sanitizeHeroInput({ ...valid(), imageUrl: "/uploads/hero/evil.jpg" }, "/uploads/hero/ok.jpg");
    assert.deepEqual(errors, []);
    assert.equal(value.imageUrl, "/uploads/hero/ok.jpg");
    assert.equal(value.stats.length, 1);
    assert.equal(value.eyebrowVisible, true);
  });
  test("آدرس‌های خطرناک دکمه رد می‌شوند", () => {
    for (const link of ["javascript:alert(1)", "//evil.com", "data:text/html,x", "ftp://x.y", "", "#a b"]) {
      const body = valid();
      body.primaryButton.link = link;
      assert.ok(sanitizeHeroInput(body).errors.length > 0, `باید رد شود: ${link}`);
    }
  });
  test("آدرس‌های مجاز پذیرفته می‌شوند", () => {
    for (const link of ["#doctors", "/login", "/", "https://example.com/a?b=1"]) {
      const body = valid();
      body.secondaryButton.link = link;
      assert.deepEqual(sanitizeHeroInput(body).errors, [], link);
    }
  });
  test("تیتر کاملاً خالی و بیش از حد مجاز آمار خطا می‌دهند", () => {
    const body = valid();
    body.titleBefore = L(""); body.titleAccent = L(""); body.titleAfter = L("");
    assert.ok(sanitizeHeroInput(body).errors.some((e) => e.includes("تیتر")));
    const many = valid();
    many.stats = Array.from({ length: 7 }, (_, i) => ({ id: `s${i}`, value: L("1"), label: L("x") }));
    assert.ok(sanitizeHeroInput(many).errors.some((e) => e.includes("حداکثر")));
  });
  test("شناسه‌های تکراری/نامعتبر بازتولید می‌شوند و مخفی‌کردن بخش‌ها ذخیره می‌شود", () => {
    const body = valid();
    body.stats = [{ id: "dup", value: L("1"), label: L("a") }, { id: "dup", value: L("2"), label: L("b") }, { id: "bad id!", value: L("3"), label: L("c") }];
    body.secondaryVisible = false; body.pulseVisible = false;
    const { errors, value } = sanitizeHeroInput(body);
    assert.deepEqual(errors, []);
    assert.equal(new Set(value.stats.map((s) => s.id)).size, 3);
    assert.equal(value.secondaryVisible, false);
    assert.equal(value.pulseVisible, false);
  });
});

import { test, describe } from "node:test";
import assert from "node:assert/strict";
import fs from "fs";
import os from "os";
import path from "path";
const { runMigrations, getStatus, rollbackLast, listMigrationFiles } = await import("../db/migrator.js");

// pool ساختگی در حافظه: فقط کوئری‌های schema_migrations و قفل را شبیه‌سازی می‌کند
function fakePool() {
  const rows = new Map();
  const log = [];
  const query = async (sql, params = []) => {
    log.push(sql.trim().split(/\s+/).slice(0, 3).join(" "));
    if (/GET_LOCK/.test(sql)) return [[{ got: 1 }]];
    if (/SELECT version, checksum/.test(sql)) return [[...rows].map(([version, checksum]) => ({ version, checksum }))];
    if (/ORDER BY version DESC/.test(sql)) { const v = [...rows.keys()].sort().pop(); return [v ? [{ version: v }] : []]; }
    if (/INSERT INTO schema_migrations/.test(sql)) { rows.set(params[0], params[2]); return [{}]; }
    if (/DELETE FROM schema_migrations/.test(sql)) { rows.delete(params[0]); return [{}]; }
    return [[]];
  };
  return { query, getConnection: async () => ({ query, release() {} }), rows, log };
}

function makeDir(files) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "mig-"));
  for (const [n, c] of Object.entries(files)) fs.writeFileSync(path.join(dir, n), c);
  return dir;
}
const UP = (tag) => `export const ran = globalThis.__ran ??= []; export async function up() { globalThis.__ran.push("${tag}"); } export async function down() { globalThis.__ran.push("down-${tag}"); }`;

describe("مهاجرت‌های نسخه‌دار", () => {
  test("به ترتیب عددی و فقط یک‌بار اجرا می‌شوند", async () => {
    globalThis.__ran = [];
    const dir = makeDir({ "0002_b.js": UP("b"), "0001_a.js": UP("a"), "readme.txt": "x" });
    const pool = fakePool();
    assert.deepEqual(await runMigrations(pool, "db", { dir, log() {} }), ["0001", "0002"]);
    assert.deepEqual(globalThis.__ran, ["a", "b"]);
    assert.deepEqual(await runMigrations(pool, "db", { dir, log() {} }), []);
    assert.deepEqual(globalThis.__ran, ["a", "b"]);
  });

  test("فایلِ اجراشده‌ی ویرایش‌شده رد می‌شود (checksum)", async () => {
    globalThis.__ran = [];
    const dir = makeDir({ "0001_a.js": UP("a") });
    const pool = fakePool();
    await runMigrations(pool, "db", { dir, log() {} });
    fs.appendFileSync(path.join(dir, "0001_a.js"), "\n// edited");
    assert.equal((await getStatus(pool, { dir }))[0].state, "modified");
    await assert.rejects(() => runMigrations(pool, "db", { dir, log() {} }), /تغییر کرده/);
  });

  test("شماره‌ی تکراری و فایل بدون up خطا می‌دهند؛ rollback آخرین را برمی‌گرداند", async () => {
    await assert.rejects(() => listMigrationFiles(makeDir({ "0001_a.js": "", "0001_b.js": "" })), /تکراری/);
    const noUp = makeDir({ "0001_a.js": "export const x = 1;" });
    await assert.rejects(() => runMigrations(fakePool(), "db", { dir: noUp, log() {} }), /up ندارد/);

    globalThis.__ran = [];
    const dir = makeDir({ "0001_a.js": UP("a"), "0002_b.js": UP("b") });
    const pool = fakePool();
    await runMigrations(pool, "db", { dir, log() {} });
    assert.equal(await rollbackLast(pool, "db", { dir, log() {} }), "0002");
    assert.ok(globalThis.__ran.includes("down-b"));
    assert.deepEqual([...pool.rows.keys()], ["0001"]);
  });

  test("مهاجرت‌های واقعی پروژه (۰۰۰۱) معتبرند", async () => {
    const files = await listMigrationFiles();
    assert.ok(files.some((f) => f.version === "0001" && f.name === "mfa_columns"));
  });
});

import { test, describe } from "node:test";
import assert from "node:assert/strict";
process.env.JWT_SECRET = process.env.JWT_SECRET || "test_only_secret_key_please_do_not_use_in_prod_1234567890";
const {
  base32Encode, base32Decode, totpAt, verifyTotp, generateTotpSecret, buildOtpauthUrl,
  encryptSecret, decryptSecret, generateRecoveryCodes, hashRecoveryCode, looksLikeRecoveryCode,
} = await import("../utils/totp.js");
const { unknownEmailLockMinutes, registerUnknownEmailFailure, _resetUnknownEmailThrottleForTests } = await import("../utils/loginThrottle.js");

// بردارهای تست RFC 6238 (SHA-1، راز ASCII «12345678901234567890») — مقدار ۸ رقمی، ۶ رقم آخر آن
const RFC_SECRET = base32Encode(Buffer.from("12345678901234567890"));

describe("TOTP (RFC 6238)", () => {
  test("بردارهای رسمی RFC 6238", () => {
    const vectors = [[59, "287082"], [1111111109, "081804"], [1111111111, "050471"], [1234567890, "005924"], [2000000000, "279037"]];
    for (const [t, code] of vectors) assert.equal(totpAt(RFC_SECRET, t * 1000), code, `t=${t}`);
  });

  test("base32 رفت‌وبرگشتی است", () => {
    const buf = Buffer.from("hello-mfa-secret!");
    assert.deepEqual(base32Decode(base32Encode(buf)), buf);
  });

  test("verifyTotp: کد درست، پنجره‌ی ±۱، و رد کد خارج از پنجره", () => {
    const now = 1_700_000_000_000;
    const code = totpAt(RFC_SECRET, now);
    const step = Math.floor(now / 30000);
    assert.equal(verifyTotp(RFC_SECRET, code, now), step);
    assert.equal(verifyTotp(RFC_SECRET, code, now + 30000), step); // یک گام بعد هنوز پذیرفته
    assert.equal(verifyTotp(RFC_SECRET, code, now + 90000), null); // سه گام بعد رد
    assert.equal(verifyTotp(RFC_SECRET, "000000x", now), null);
    assert.equal(verifyTotp(RFC_SECRET, "", now), null);
    assert.equal(verifyTotp(RFC_SECRET, null, now), null);
  });

  test("رازها یکتا و ۳۲ نویسه‌ی base32 هستند و otpauth درست ساخته می‌شود", () => {
    const a = generateTotpSecret();
    assert.match(a, /^[A-Z2-7]{32}$/);
    assert.notEqual(a, generateTotpSecret());
    const url = buildOtpauthUrl({ secret: a, email: "dr@example.com" });
    assert.ok(url.startsWith("otpauth://totp/"));
    assert.ok(url.includes(`secret=${a}`) && url.includes("digits=6") && url.includes("period=30"));
  });
});

describe("رمزنگاری راز و کدهای بازیابی", () => {
  test("AES-GCM: رفت‌وبرگشت، IV تصادفی، و تشخیص دستکاری", () => {
    const s = generateTotpSecret();
    const e1 = encryptSecret(s);
    const e2 = encryptSecret(s);
    assert.notEqual(e1, e2);
    assert.equal(decryptSecret(e1), s);
    assert.ok(!e1.includes(s));
    const parts = e1.split(":");
    parts[3] = Buffer.from("tampered").toString("base64");
    assert.throws(() => decryptSecret(parts.join(":")));
    assert.throws(() => decryptSecret("garbage"));
  });

  test("کدهای بازیابی: ۸ کد یکتا، قالب XXXXX-XXXXX، هش مستقل از حروف/خط‌تیره", () => {
    const codes = generateRecoveryCodes();
    assert.equal(codes.length, 8);
    assert.equal(new Set(codes).size, 8);
    for (const c of codes) {
      assert.match(c, /^[A-Z2-9]{5}-[A-Z2-9]{5}$/);
      assert.equal(hashRecoveryCode(c), hashRecoveryCode(c.toLowerCase().replace("-", " ")));
      assert.ok(looksLikeRecoveryCode(c));
    }
    assert.ok(!looksLikeRecoveryCode("123456"));
  });
});

describe("قفل ایمیل ناموجود (ضد user enumeration)", () => {
  test("بعد از آستانه قفل می‌شود، مثل حساب واقعی", () => {
    _resetUnknownEmailThrottleForTests();
    for (let i = 0; i < 4; i++) registerUnknownEmailFailure("ghost@example.com", 5, 15);
    assert.equal(unknownEmailLockMinutes("ghost@example.com"), 0);
    registerUnknownEmailFailure("ghost@example.com", 5, 15);
    assert.equal(unknownEmailLockMinutes("GHOST@example.com"), 15);
    assert.equal(unknownEmailLockMinutes("other@example.com"), 0);
  });
});

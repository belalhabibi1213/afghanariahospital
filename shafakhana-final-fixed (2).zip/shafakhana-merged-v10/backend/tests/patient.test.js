import { test, describe, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";

import { findOrCreatePatient, getPatientDetailByPublicCode, searchPatients } from "../models/Patient.js";

after(closePool);

describe("کد عمومی بیمار (publicCode)", () => {
  test("بیمار تازه یک کد یکتا می‌گیرد", async () => {
    const p = await findOrCreatePatient({ fullName: "تست یک", phone: "0700000001" });
    assert.match(p.publicCode, /^AAH-\d{6,}$/);
  });

  test("دو بیمار متفاوت کد متفاوت می‌گیرند", async () => {
    const a = await findOrCreatePatient({ fullName: "تست دو الف", phone: "0700000002" });
    const b = await findOrCreatePatient({ fullName: "تست دو ب", phone: "0700000003" });
    assert.notEqual(a.publicCode, b.publicCode);
  });

  test("جستجو با کد، همان بیمار را برمی‌گرداند", async () => {
    const p = await findOrCreatePatient({ fullName: "تست سه", phone: "0700000004" });
    const found = await getPatientDetailByPublicCode(p.publicCode);
    assert.ok(found);
    assert.equal(found.id, p.id);
  });

  test("جستجو با کد نامعتبر چیزی برنمی‌گرداند", async () => {
    const found = await getPatientDetailByPublicCode("AAH-999999");
    assert.equal(found, null);
  });

  test("کادر جستجوی عمومی بیماران کد را هم می‌شناسد", async () => {
    const p = await findOrCreatePatient({ fullName: "تست چهار", phone: "0700000005" });
    const result = await searchPatients({ q: p.publicCode });
    assert.equal(result.rows.length, 1);
    assert.equal(result.rows[0].id, p.id);
  });

  test("همان شماره تماس دوباره همان بیمار (و همان کد) را برمی‌گرداند", async () => {
    const first = await findOrCreatePatient({ fullName: "تست پنج", phone: "0700000006" });
    // findOrCreatePatient فقط با وجود userId رکورد قبلی را به‌روزرسانی می‌کند؛ اینجا فقط
    // اطمینان می‌دهیم که publicCode یک‌بار ساخته‌شده هرگز عوض نمی‌شود
    const again = await getPatientDetailByPublicCode(first.publicCode);
    assert.equal(again.id, first.id);
  });
});

describe("ساخت هم‌زمان بیمار (رگرسیون باگ کد تکراری publicCode)", () => {
  test("۱۵ بیمار تازه‌ی هم‌زمان همگی موفق می‌شوند و هر کدام کد یکتا می‌گیرند", async () => {
    const results = await Promise.all(
      Array.from({ length: 15 }, (_, i) => findOrCreatePatient({ fullName: `هم‌زمان ${i}`, phone: `0709000${String(i).padStart(3, "0")}` }))
    );
    const codes = results.map((p) => p.publicCode);
    assert.equal(new Set(codes).size, 15, "هیچ دو بیماری نباید کد یکسان بگیرند");
    for (const c of codes) assert.match(c, /^AAH-\d{6,}$/);
  });

  test("کد ساخته‌شده در دیتابیس هم ذخیره شده و با جستجو پیدا می‌شود", async () => {
    const p = await findOrCreatePatient({ fullName: "ذخیره کد", phone: "0709111111" });
    const found = await getPatientDetailByPublicCode(p.publicCode);
    assert.equal(found.id, p.id);
  });
});


import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";
import db from "../db.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// فهرست یکپارچه‌ی «اسناد طبی»: جستجو/فیلتر/صفحه‌بندی سمت سرور، تفکیک ادمین و داکتر، IDOR
// برچسب یکتا برای هر اجرا: دیتابیس تست بین اجراها پاک نمی‌شود و نام‌ها نباید با اجرای قبلی تداخل کنند
const RUN = Date.now().toString(36);

describe("اسناد طبی — ادمین و داکتر", () => {
  let admin; let doc1; let doc2; let patientUser; let pA; let pB; let pAName; let pAPhone; let pACode;
  let rxId; let recId; let draftId; let labId; let imgId; let docBRecId;

  before(async () => {
    admin = await makeSession("admin");
    doc1 = await createTestDoctor();
    doc2 = await createTestDoctor();
    patientUser = await makeSession("user");
    pA = await createTestPatient(patientUser.id, `مریض الف ${RUN}`);
    pB = await createTestPatient(null, `مریض ب ${RUN}`);
    await addAppointment(pA, doc1.id, "confirmed");
    await addAppointment(pB, doc2.id, "confirmed");
    const [[row]] = await db.query("SELECT fullName, phone, publicCode FROM patients WHERE id = ?", [pA]);
    pAName = row.fullName; pAPhone = row.phone; pACode = row.publicCode;

    const gid = `md-${Date.now()}`;
    const [r1] = await db.query("INSERT INTO prescriptions (patientId, doctorId, medicationName, dosage, groupId, diagnosis) VALUES (?, ?, 'آموکسی', '500', ?, 'عفونت')", [pA, doc1.id, gid]);
    await db.query("INSERT INTO prescriptions (patientId, doctorId, medicationName, dosage, groupId, diagnosis) VALUES (?, ?, 'استامینوفن', '500', ?, 'عفونت')", [pA, doc1.id, gid]);
    rxId = r1.insertId;
    const [r2] = await db.query("INSERT INTO medical_records (patientId, doctorId, diagnosis, status) VALUES (?, ?, 'سردرد', 'registered')", [pA, doc1.id]);
    recId = r2.insertId;
    const [r3] = await db.query("INSERT INTO medical_records (patientId, doctorId, diagnosis, status) VALUES (?, ?, 'پیش‌نویس محرمانه', 'draft')", [pA, doc1.id]);
    draftId = r3.insertId;
    const [r4] = await db.query("INSERT INTO lab_results (patientId, doctorId, testName, status) VALUES (?, ?, 'CBC', 'completed')", [pA, doc1.id]);
    labId = r4.insertId;
    const [r5] = await db.query("INSERT INTO radiology_reports (patientId, doctorId, examType) VALUES (?, ?, 'X-Ray قفسه سینه')", [pA, doc1.id]);
    imgId = r5.insertId;
    const [r6] = await db.query("INSERT INTO medical_records (patientId, doctorId, diagnosis, status) VALUES (?, ?, 'سابقه مریض ب', 'registered')", [pB, doc2.id]);
    docBRecId = r6.insertId;
  });

  test("canDownload: نسخه برای مالک/ادمین true؛ آزمایش بدون فایل false؛ سند داکتر دیگر false", async () => {
    await db.query("UPDATE lab_results SET reportUrl = 'x.pdf' WHERE id = ?", [labId]);
    const adm = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(pAName)}&limit=50`, { token: admin.token });
    const by = Object.fromEntries(adm.body.documents.map((d) => [d.docType, d]));
    assert.equal(by.prescription.canDownload, true);
    assert.equal(by.lab.canDownload, true);
    assert.equal(by.record.canDownload, false);
    assert.equal(by.imaging.canDownload, false);
    const doc4 = await createTestDoctor();
    await addAppointment(pA, doc4.id, "confirmed", { dayOffset: 7 });
    const other = await api("GET", `/api/doctors/me/medical-documents?limit=50`, { token: doc4.token });
    assert.ok(other.body.documents.length > 0 && other.body.documents.every((d) => d.canDownload === false));
    await db.query("UPDATE lab_results SET reportUrl = NULL WHERE id = ?", [labId]);
  });

  test("ادمین هر چهار نوع سند را می‌بیند؛ نسخه‌ی دو داروئی یک ردیف است؛ پیش‌نویس دیده نمی‌شود", async () => {
    const res = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(pAName)}&limit=50`, { token: admin.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const types = res.body.documents.map((d) => d.docType).sort();
    assert.deepEqual(types, ["imaging", "lab", "prescription", "record"]);
    assert.equal(res.body.pagination.total, 4);
    assert.ok(!res.body.documents.some((d) => d.title === "پیش‌نویس محرمانه"));
  });

  test("جستجو با نام، شماره تماس، کد پرونده، شماره سند و ارقام فارسی", async () => {
    for (const q of [pAName, pAPhone, pACode, `RX-${String(rxId).padStart(6, "0")}`]) {
      const res = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(q)}`, { token: admin.token });
      assert.ok(res.body.pagination.total >= 1, `q=${q}`);
    }
    const fa = String(rxId).padStart(6, "0").replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
    const res = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(`RX-${fa}`)}`, { token: admin.token });
    assert.ok(res.body.documents.some((d) => d.docType === "prescription"));
    // بدون صفرهای ابتدایی و با پیشوند کوچک
    const short = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(`rx-${rxId}`)}`, { token: admin.token });
    assert.ok(short.body.documents.some((d) => d.docType === "prescription" && d.id === rxId));
  });

  test("فیلتر نوع سند، وضعیت، داکتر و بازه‌ی تاریخ", async () => {
    const t = await api("GET", `/api/admin/medical-documents?type=lab&doctorId=${doc1.id}`, { token: admin.token });
    assert.ok(t.body.documents.length >= 1 && t.body.documents.every((d) => d.docType === "lab"));
    const s = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(pAName)}&status=active`, { token: admin.token });
    assert.deepEqual(s.body.documents.map((d) => d.docType), ["prescription"]);
    const today = new Date().toISOString().slice(0, 10);
    const inRange = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(pAName)}&dateFrom=${today}&dateTo=${today}`, { token: admin.token });
    assert.equal(inRange.body.pagination.total, 4);
    const out = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(pAName)}&dateTo=2000-01-01`, { token: admin.token });
    assert.equal(out.body.pagination.total, 0);
  });

  test("صفحه‌بندی و مرتب‌سازی سمت سرور؛ limit سقف ۱۰۰ دارد", async () => {
    const p1 = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(pAName)}&limit=2&page=1&sort=type&order=asc`, { token: admin.token });
    const p2 = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(pAName)}&limit=2&page=2&sort=type&order=asc`, { token: admin.token });
    assert.equal(p1.body.documents.length, 2);
    assert.equal(p1.body.pagination.totalPages, 2);
    assert.deepEqual([...p1.body.documents, ...p2.body.documents].map((d) => d.docType), ["imaging", "lab", "prescription", "record"]);
    const big = await api("GET", "/api/admin/medical-documents?limit=100000", { token: admin.token });
    assert.ok(big.body.pagination.limit <= 100);
  });

  test("ورودی مخرب در q/sort/order/type خطای ۵۰۰ یا تزریق ایجاد نمی‌کند", async () => {
    for (const qs of ["q=%27%20OR%201%3D1%20--", "sort=u.id;DROP%20TABLE%20patients", "order=asc;DROP", "type=x%27", "q[]=1&limit[]=2", "status=%27"]) {
      const res = await api("GET", `/api/admin/medical-documents?${qs}`, { token: admin.token });
      assert.equal(res.status, 200, `${qs} → ${res.status}`);
    }
    const [[{ n }]] = await db.query("SELECT COUNT(*) AS n FROM patients");
    assert.ok(n >= 2);
  });

  test("داکتر فقط اسناد بیماران مجاز خودش را می‌بیند؛ doctorId در query نادیده است", async () => {
    const mine = await api("GET", "/api/doctors/me/medical-documents?limit=100", { token: doc1.token });
    assert.equal(mine.status, 200, JSON.stringify(mine.body));
    assert.ok(mine.body.documents.every((d) => d.patientId === pA));
    // پیش‌نویسِ خودِ داکتر دیده می‌شود
    assert.ok(mine.body.documents.some((d) => d.title === "پیش‌نویس محرمانه"));
    // doctorId/patientId دلخواه در query هرگز دامنه را بزرگ نمی‌کند: باز هم فقط اسناد بیمارِ مجازِ خودش
    const spoof = await api("GET", `/api/doctors/me/medical-documents?doctorId=${doc2.id}&patientId=${pB}&limit=100`, { token: doc1.token });
    assert.equal(spoof.status, 200);
    assert.ok(spoof.body.documents.length > 0 && spoof.body.documents.every((d) => d.patientId === pA));
  });

  test("داکتری که با بیمار نوبت تأییدشده ندارد هیچ سندی از او نمی‌بیند؛ نوبت pending کافی نیست", async () => {
    const doc3 = await createTestDoctor();
    await addAppointment(pA, doc3.id, "pending");
    const res = await api("GET", "/api/doctors/me/medical-documents?limit=100", { token: doc3.token });
    assert.equal(res.body.documents.length, 0);
    const stats = await api("GET", "/api/doctors/me/medical-documents/stats", { token: doc3.token });
    assert.equal(stats.body.stats.total, 0);
    assert.equal(stats.body.stats.patients, 0);
  });

  test("IDOR: داکتر دیگر با تغییر شناسه به جزئیات سند بیمار غیرمجاز نمی‌رسد (۴۰۴ یکسان)", async () => {
    for (const [type, id] of [["prescription", rxId], ["record", recId], ["lab", labId], ["imaging", imgId]]) {
      const res = await api("GET", `/api/doctors/me/medical-documents/${type}/${id}`, { token: doc2.token });
      assert.equal(res.status, 404, `${type}`);
    }
    const missing = await api("GET", "/api/doctors/me/medical-documents/lab/99999999", { token: doc2.token });
    assert.equal(missing.status, 404);
    // پیش‌نویس داکتر دیگر حتی اگر بیمار مجاز باشد
    await addAppointment(pA, doc2.id, "confirmed", { dayOffset: 6 });
    const draft = await api("GET", `/api/doctors/me/medical-documents/record/${draftId}`, { token: doc2.token });
    assert.equal(draft.status, 404);
    const shared = await api("GET", `/api/doctors/me/medical-documents/record/${recId}`, { token: doc2.token });
    assert.equal(shared.status, 200);
    // اما چاپ/ویرایش فقط برای مالک
    const rx = await api("GET", `/api/doctors/me/medical-documents/prescription/${rxId}`, { token: doc2.token });
    assert.equal(rx.body.permissions.pdf, false);
    assert.equal(rx.body.permissions.canEdit, false);
  });

  test("جزئیات برای مالک و ادمین؛ پیش‌نویس برای ادمین ۴۰۴؛ نوع/شناسه نامعتبر ۴۰۰", async () => {
    const own = await api("GET", `/api/doctors/me/medical-documents/prescription/${rxId}`, { token: doc1.token });
    assert.equal(own.status, 200, JSON.stringify(own.body));
    assert.equal(own.body.document.items.length, 2);
    assert.equal(own.body.permissions.pdf, true);
    assert.equal(own.body.permissions.canEdit, true);
    const adm = await api("GET", `/api/admin/medical-documents/prescription/${rxId}`, { token: admin.token });
    assert.equal(adm.status, 200);
    assert.equal(adm.body.permissions.canEdit, false);
    assert.equal((await api("GET", `/api/admin/medical-documents/record/${draftId}`, { token: admin.token })).status, 404);
    assert.equal((await api("GET", `/api/admin/medical-documents/foo/1`, { token: admin.token })).status, 400);
    assert.equal((await api("GET", `/api/admin/medical-documents/lab/abc`, { token: admin.token })).status, 400);
  });

  test("بیمار و کاربر بدون توکن به هیچ‌کدام از مسیرها دسترسی ندارند؛ داکتر به مسیر ادمین ۴۰۳", async () => {
    for (const path of ["/api/admin/medical-documents", "/api/admin/medical-documents/stats", `/api/admin/medical-documents/lab/${labId}`]) {
      assert.equal((await api("GET", path, { token: patientUser.token })).status, 403, path);
      assert.equal((await api("GET", path, { token: doc1.token })).status, 403, path);
      assert.equal((await api("GET", path)).status, 401, path);
    }
    for (const path of ["/api/doctors/me/medical-documents", "/api/doctors/me/medical-documents/stats"]) {
      assert.equal((await api("GET", path, { token: patientUser.token })).status, 403, path);
      assert.equal((await api("GET", path, { token: admin.token })).status, 403, path);
    }
  });

  test("آمار: شمار هر نوع سند و بیماران؛ سندهای بیمار دیگر در آمار داکتر نیست", async () => {
    const adm = await api("GET", "/api/admin/medical-documents/stats", { token: admin.token });
    assert.equal(adm.status, 200);
    for (const k of ["patients", "prescription", "record", "lab", "imaging", "total"]) assert.ok(Number.isFinite(Number(adm.body.stats[k])), k);
    const d1 = await api("GET", "/api/doctors/me/medical-documents/stats", { token: doc1.token });
    assert.equal(d1.body.stats.prescription, 1);
    assert.equal(d1.body.stats.record, 2); // یک ثبت‌شده + پیش‌نویس خودش
    assert.equal(d1.body.stats.lab, 1);
    assert.equal(d1.body.stats.imaging, 1);
    assert.equal(d1.body.stats.patients, 1);
    assert.ok(docBRecId);
  });

  test("حجم زیاد: ۳۰۰۰ سند اضافه، صفحه‌بندی سروری و جستجو سریع می‌ماند", async () => {
    const values = [];
    for (let i = 0; i < 3000; i += 1) values.push([pB, doc2.id, `آزمایش حجمی ${RUN} ${i}`, "completed"]);
    await db.query("INSERT INTO lab_results (patientId, doctorId, testName, status) VALUES ?", [values]);
    const t0 = Date.now();
    const page = await api("GET", "/api/admin/medical-documents?limit=10&page=5", { token: admin.token });
    const search = await api("GET", `/api/admin/medical-documents?q=${encodeURIComponent(`حجمی ${RUN} 2999`)}`, { token: admin.token });
    const elapsed = Date.now() - t0;
    assert.equal(page.body.documents.length, 10);
    assert.ok(page.body.pagination.total >= 3000);
    assert.equal(search.body.documents.length, 1);
    assert.ok(elapsed < 3000, `elapsed=${elapsed}ms`);
  });
});

import { test, describe, beforeEach } from "node:test";
import assert from "node:assert/strict";
const { encryptBackup, decryptBackup, looksEncrypted, isBackupEncryptionEnabled, MAGIC } = await import("../utils/backupCrypto.js");

const KEY = "k".repeat(40);
beforeEach(() => { process.env.BACKUP_ENCRYPTION_KEY = KEY; });

describe("رمزنگاری بکاپ (AES-256-GCM)", () => {
  test("رفت‌وبرگشت؛ خروجی متن ساده‌ی SQL را نشت نمی‌دهد و هر بار متفاوت است", () => {
    const sql = Buffer.from("-- شفاخانه\nINSERT INTO users VALUES ('secret-hash');\nSET FOREIGN_KEY_CHECKS = 1;", "utf8");
    const a = encryptBackup(sql);
    const b = encryptBackup(sql);
    assert.ok(looksEncrypted(a));
    assert.ok(!a.includes("secret-hash"));
    assert.notDeepEqual(a, b);
    assert.deepEqual(decryptBackup(a), sql);
  });

  test("کلید اشتباه، دستکاری یک بایت یا بریدن فایل → BACKUP_DECRYPT_FAILED", () => {
    const enc = encryptBackup(Buffer.from("data".repeat(100)));
    process.env.BACKUP_ENCRYPTION_KEY = "z".repeat(40);
    assert.throws(() => decryptBackup(enc), { code: "BACKUP_DECRYPT_FAILED" });
    process.env.BACKUP_ENCRYPTION_KEY = KEY;
    const flipped = Buffer.from(enc); flipped[MAGIC.length + 40] ^= 1;
    assert.throws(() => decryptBackup(flipped), { code: "BACKUP_DECRYPT_FAILED" });
    assert.throws(() => decryptBackup(enc.subarray(0, enc.length - 5)), { code: "BACKUP_DECRYPT_FAILED" });
  });

  test("بدون کلید: رمزنگاری/رمزگشایی با BACKUP_KEY_MISSING رد می‌شود", () => {
    const enc = encryptBackup(Buffer.from("x"));
    delete process.env.BACKUP_ENCRYPTION_KEY;
    assert.equal(isBackupEncryptionEnabled(), false);
    assert.throws(() => encryptBackup(Buffer.from("x")), { code: "BACKUP_KEY_MISSING" });
    assert.throws(() => decryptBackup(enc), { code: "BACKUP_KEY_MISSING" });
  });

  test("فایل ساده (.sql قدیمی) رمزنگاری‌شده تشخیص داده نمی‌شود", () => {
    assert.equal(looksEncrypted(Buffer.from("-- شفاخانه افغان آریا")), false);
  });
});

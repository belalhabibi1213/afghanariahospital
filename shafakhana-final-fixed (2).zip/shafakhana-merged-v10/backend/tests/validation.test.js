import { test, describe, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
// نکته: هرچند این فایل خودش کوئری نمی‌زند، importهایش (models/Settings.js، models/Invoice.js)
// db.js را هم import می‌کنند که همان لحظه به دیتابیس وصل می‌شود؛ برای خروج تمیز، پول را می‌بندیم.

import { validateSettingsInput } from "../models/Settings.js";
import { getPasswordPolicyError, isStrongPassword, generateTempPassword } from "../utils/passwordPolicy.js";
import { computeStatus } from "../models/Invoice.js";

after(closePool);

describe("validateSettingsInput", () => {
  test("مقدار نامعتبر برای appointmentSlotCapacity رد می‌شود", () => {
    const { errors, sanitized } = validateSettingsInput({ appointmentSlotCapacity: "0" });
    assert.ok(errors.appointmentSlotCapacity, "باید خطا بدهد چون کمتر از ۱ مجاز نیست");
    assert.equal(sanitized.appointmentSlotCapacity, undefined);
  });

  test("مقدار معتبر پذیرفته و sanitize می‌شود", () => {
    const { errors, sanitized } = validateSettingsInput({ appointmentSlotCapacity: "15" });
    assert.deepEqual(errors, {});
    assert.equal(sanitized.appointmentSlotCapacity, "15");
  });

  test("کلید ناشناخته رد می‌شود", () => {
    const { errors } = validateSettingsInput({ notARealSetting: "x" });
    assert.ok(errors.notARealSetting);
  });

  test("appointmentCancelMinHours خارج از بازه رد می‌شود", () => {
    const { errors } = validateSettingsInput({ appointmentCancelMinHours: "9999" });
    assert.ok(errors.appointmentCancelMinHours);
  });

  test("appointmentReminderHours صفر (غیرفعال) مجاز است", () => {
    const { errors, sanitized } = validateSettingsInput({ appointmentReminderHours: "0" });
    assert.deepEqual(errors, {});
    assert.equal(sanitized.appointmentReminderHours, "0");
  });

  test("backupRetentionCount خارج از بازه (۰) رد می‌شود", () => {
    const { errors } = validateSettingsInput({ backupRetentionCount: "0" });
    assert.ok(errors.backupRetentionCount);
  });
});

describe("password policy", () => {
  test("رمز کوتاه رد می‌شود", () => {
    assert.ok(getPasswordPolicyError("abc123"));
    assert.equal(isStrongPassword("abc123"), false);
  });

  test("رمز فارسی/یونیکد رد می‌شود", () => {
    assert.ok(getPasswordPolicyError("رمزعبورمن"));
  });

  test("رمزهای بسیار رایج و رمز بیش از ۷۲ کاراکتر رد می‌شوند", () => {
    assert.ok(getPasswordPolicyError("12345678"));
    assert.ok(getPasswordPolicyError("Password123"));
    assert.ok(getPasswordPolicyError("aB3$".repeat(18) + "x"));
    assert.equal(getPasswordPolicyError("aB3$".repeat(18)), null);
  });

  test("رمز معتبر پذیرفته می‌شود", () => {
    assert.equal(getPasswordPolicyError("Abcd1234"), null);
    assert.equal(isStrongPassword("Abcd1234"), true);
  });

  test("generateTempPassword رمزی هم‌راستا با سیاست تولید می‌کند", () => {
    for (let i = 0; i < 20; i += 1) {
      const pwd = generateTempPassword();
      assert.equal(getPasswordPolicyError(pwd), null, `رمز تولیدشده باید خودش هم معتبر باشد: ${pwd}`);
    }
  });
});

describe("computeStatus (فاکتور)", () => {
  test("پرداخت صفر => unpaid", () => {
    assert.equal(computeStatus(1000, 0), "unpaid");
  });
  test("پرداخت جزئی => partial", () => {
    assert.equal(computeStatus(1000, 400), "partial");
  });
  test("پرداخت کامل => paid", () => {
    assert.equal(computeStatus(1000, 1000), "paid");
  });
  test("پرداخت بیش از مبلغ کل هم paid است (نه خطا)", () => {
    assert.equal(computeStatus(1000, 1200), "paid");
  });
});

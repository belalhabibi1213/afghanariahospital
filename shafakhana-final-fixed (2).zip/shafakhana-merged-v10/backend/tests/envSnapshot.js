// عکس‌برداری از متغیرهای محیطیِ «واقعیِ شل» پیش از بارگذاری .env (باید اولین import در testEnv.js باشد).
// دلیل: .env واقعی پروژه (NODE_ENV=development، BACKUP_ENCRYPTION_KEY، MFA_* و ...) نباید رفتار تست‌ها را عوض کند.
export const shellEnv = { ...process.env };

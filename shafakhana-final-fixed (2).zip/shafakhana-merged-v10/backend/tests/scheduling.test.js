import { test, describe, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
// همین نکته: utils/backup.js هم db.js را import می‌کند

import { buildBackupCron, previousScheduledTime } from "../utils/backup.js";
import { buildIceServers } from "../utils/iceServers.js";

after(closePool);

describe("زمان‌بندی پشتیبان‌گیری خودکار", () => {
  test("buildBackupCron برای هر تناوب عبارت درست می‌سازد", () => {
    assert.equal(buildBackupCron({ frequency: "daily", time: "03:00" }), "0 3 * * *");
    assert.equal(buildBackupCron({ frequency: "weekly", time: "22:30" }), "30 22 * * 5");
    assert.equal(buildBackupCron({ frequency: "every6h", time: "00:15" }), "15 */6 * * *");
    assert.equal(buildBackupCron({ frequency: "every12h", time: "00:45" }), "45 */12 * * *");
  });

  test("previousScheduledTime برای روزانه، موعد امروز یا دیروز را برمی‌گرداند", () => {
    const now = new Date(2026, 8, 25, 10, 0); // امروز ساعت ۱۰:۰۰
    const before = previousScheduledTime(now, { frequency: "daily", time: "03:00" });
    assert.equal(before.getDate(), 25); // موعد ۰۳:۰۰ امروز از الان گذشته
    const after = previousScheduledTime(now, { frequency: "daily", time: "23:00" });
    assert.equal(after.getDate(), 24); // موعد ۲۳:۰۰ امروز هنوز نرسیده، پس موعد قبلی دیروز است
  });

  test("previousScheduledTime برای هفتگی، آخرین جمعه را برمی‌گرداند", () => {
    const now = new Date(2026, 8, 29, 10, 0); // سه‌شنبه ۲۹ سپتامبر — آخرین جمعه باید ۲۵ سپتامبر باشد
    const prev = previousScheduledTime(now, { frequency: "weekly", time: "03:00" });
    assert.equal(prev.getDay(), 5, "روز هفته باید جمعه (۵) باشد");
    assert.ok(prev <= now);
  });

  test("previousScheduledTime برای every6h، نزدیک‌ترین مضرب ۶ ساعت را برمی‌گرداند", () => {
    const now = new Date(2026, 8, 25, 13, 40);
    const prev = previousScheduledTime(now, { frequency: "every6h", time: "00:15" });
    assert.equal(prev.getHours(), 12);
    assert.equal(prev.getMinutes(), 15);
  });
});

describe("سرورهای ICE (STUN/TURN)", () => {
  test("بدون TURN_URLS فقط STUN برمی‌گردد", () => {
    const servers = buildIceServers({ id: 1 }, {});
    assert.equal(servers.length, 1);
    assert.ok(servers[0].urls[0].startsWith("stun:"));
  });

  test("با TURN_SECRET، رمز موقت با username حاوی زمان انقضا ساخته می‌شود", () => {
    const env = { TURN_URLS: "turn:example.com:3478", TURN_SECRET: "s3cr3t" };
    const servers = buildIceServers({ id: 42 }, env);
    assert.equal(servers.length, 2);
    const turn = servers[1];
    assert.ok(turn.username.endsWith(":42"));
    assert.ok(turn.credential.length > 0);
    // خودِ رمز اصلی هرگز نباید در خروجی ظاهر شود
    assert.ok(!JSON.stringify(turn).includes("s3cr3t"));
  });

  test("با TURN_USERNAME/TURN_CREDENTIAL ساده هم کار می‌کند", () => {
    const env = { TURN_URLS: "turn:example.com:3478", TURN_USERNAME: "u1", TURN_CREDENTIAL: "c1" };
    const servers = buildIceServers({ id: 1 }, env);
    assert.equal(servers[1].username, "u1");
    assert.equal(servers[1].credential, "c1");
  });

  test("چند آدرس STUN/TURN با کاما پشتیبانی می‌شود", () => {
    const env = { STUN_URLS: "stun:a.com,stun:b.com" };
    const servers = buildIceServers({ id: 1 }, env);
    assert.deepEqual(servers[0].urls, ["stun:a.com", "stun:b.com"]);
  });
});

import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";
import db from "../db.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// پنل داکتر «نسخه و سوابق طبی»: فهرست فقط نسخه‌های خودش، ثبت چنددارویی، قفل ویرایش پس از تکمیل
describe("پنل داکتر — نسخه‌ها", () => {
  let doc1; let doc2; let patient; let patientId; let groupId; let firstId;

  before(async () => {
    doc1 = await createTestDoctor();
    doc2 = await createTestDoctor();
    patient = await makeSession("user");
    patientId = await createTestPatient(patient.id, "بیمار داکتر");
    await addAppointment(patientId, doc1.id, "confirmed");
    groupId = `dg-${Date.now()}`;
  });

  test("ثبت دو دارو در یک نسخه با تعداد و توضیحات هر دارو", async () => {
    const meds = [
      { medicationName: "آموکسی‌سیلین", dosage: "500mg", quantity: "21 عدد", frequency: "هر ۸ ساعت", duration: "۷ روز", medicineNotes: "بعد از غذا" },
      { medicationName: "استامینوفن", dosage: "500mg", quantity: "10 عدد", duration: "۳ روز" },
    ];
    for (const m of meds) {
      const res = await api("POST", "/api/medical-records/prescriptions", {
        token: doc1.token, body: { patientId, diagnosis: "عفونت", groupId, ...m },
      });
      assert.equal(res.status, 201, JSON.stringify(res.body));
      if (!firstId) firstId = res.body.prescription?.id ?? res.body.item?.id;
    }
    const [[{ n }]] = await db.query("SELECT COUNT(*) AS n FROM prescriptions WHERE groupId = ?", [groupId]);
    assert.equal(n, 2);
    const [[row]] = await db.query("SELECT quantity, medicineNotes FROM prescriptions WHERE groupId = ? ORDER BY id LIMIT 1", [groupId]);
    assert.equal(row.quantity, "21 عدد");
    assert.equal(row.medicineNotes, "بعد از غذا");
  });

  test("فهرست داکتر فقط نسخه‌های خودش را می‌دهد؛ doctorId در query تأثیری ندارد", async () => {
    const mine = await api("GET", "/api/doctors/me/prescriptions", { token: doc1.token });
    assert.equal(mine.status, 200, JSON.stringify(mine.body));
    const row = mine.body.prescriptions.find((p) => p.groupId === groupId);
    assert.ok(row);
    assert.equal(row.itemCount, 2);
    const other = await api("GET", `/api/doctors/me/prescriptions?doctorId=${doc1.id}`, { token: doc2.token });
    assert.equal(other.status, 200);
    assert.ok(!other.body.prescriptions.some((p) => p.groupId === groupId));
    const stats = await api("GET", "/api/doctors/me/prescriptions/stats", { token: doc1.token });
    assert.equal(stats.status, 200);
    assert.ok(Number(stats.body.stats.total) >= 1);
  });

  test("فیلتر patientId فقط در محدوده‌ی نسخه‌های خودِ داکتر کار می‌کند", async () => {
    const res = await api("GET", `/api/doctors/me/prescriptions?patientId=${patientId}`, { token: doc1.token });
    assert.ok(res.body.prescriptions.every((p) => p.patientId === patientId));
    const foreign = await api("GET", `/api/doctors/me/prescriptions?patientId=${patientId}`, { token: doc2.token });
    assert.equal(foreign.body.prescriptions.length, 0);
  });

  test("داکتر دیگر نمی‌تواند نسخه را ویرایش کند", async () => {
    const [[r]] = await db.query("SELECT id FROM prescriptions WHERE groupId = ? ORDER BY id LIMIT 1", [groupId]);
    const res = await api("PUT", `/api/medical-records/prescriptions/${r.id}`, { token: doc2.token, body: { dosage: "هک" } });
    assert.ok([403, 404].includes(res.status), `status=${res.status}`);
  });

  test("ویرایش تا وقتی نسخه در حال اجراست مجاز است و پس از تکمیل ۴۰۹ می‌دهد", async () => {
    const [[r]] = await db.query("SELECT id FROM prescriptions WHERE groupId = ? ORDER BY id LIMIT 1", [groupId]);
    const ok = await api("PUT", `/api/medical-records/prescriptions/${r.id}`, { token: doc1.token, body: { dosage: "1000mg", quantity: "30 عدد" } });
    assert.equal(ok.status, 200, JSON.stringify(ok.body));
    await db.query("UPDATE prescriptions SET status = 'completed' WHERE groupId = ?", [groupId]);
    const locked = await api("PUT", `/api/medical-records/prescriptions/${r.id}`, { token: doc1.token, body: { dosage: "2000mg" } });
    assert.equal(locked.status, 409);
    const add = await api("POST", "/api/medical-records/prescriptions", { token: doc1.token, body: { patientId, medicationName: "جدید", groupId } });
    assert.equal(add.status, 409);
    const [[after]] = await db.query("SELECT dosage FROM prescriptions WHERE id = ?", [r.id]);
    assert.equal(after.dosage, "1000mg");
  });

  test("بیمار به مسیرهای داکتر دسترسی ندارد", async () => {
    assert.equal((await api("GET", "/api/doctors/me/prescriptions", { token: patient.token })).status, 403);
    assert.equal((await api("GET", "/api/doctors/me/prescriptions/stats", { token: patient.token })).status, 403);
  });
});

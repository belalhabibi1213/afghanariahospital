import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, upload, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// راه‌انداز مشترک: یک بیمار + یک داکتر با نوبتی به وضعیت دلخواه
async function setupPair(status) {
  const patientSession = await makeSession("user");
  const patientId = await createTestPatient(patientSession.id, "بیمار چت");
  const doctor = await createTestDoctor();
  const apptId = status ? await addAppointment(patientId, doctor.id, status) : null;
  return { patientSession, patientId, doctor, apptId };
}

describe("رگرسیون کامل: چت/تماس قبل از تایید نوبت (همان باگِ گزارش‌شده)", () => {
  test("نوبت pending: بیمار نمی‌تواند مکالمه با داکتر را شروع کند", async () => {
    const { patientSession, doctor } = await setupPair("pending");
    const res = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.code, "APPOINTMENT_NOT_CONFIRMED");
  });

  test("نوبت لغوشده یا ردشده هم مکالمه نمی‌سازد", async () => {
    for (const status of ["cancelled", "rejected"]) {
      const { patientSession, doctor } = await setupPair(status);
      const res = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
      assert.equal(res.status, 403, `status=${status}`);
    }
  });

  test("نوبت confirmed (هنوز انجام‌نشده): مکالمه ساخته نمی‌شود", async () => {
    const { patientSession, doctor } = await setupPair("confirmed");
    const res = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    assert.equal(res.body.code, "APPOINTMENT_NOT_CONFIRMED");
  });

  test("نوبت completed (انجام‌شده): مکالمه با موفقیت ساخته می‌شود", async () => {
    const { patientSession, doctor } = await setupPair("completed");
    const res = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.ok(res.body.conversation.id);
  });

  test("داکتر هم از سمت خودش نمی‌تواند با بیمارِ نوبتِ تاییدنشده مکالمه شروع کند", async () => {
    const { patientId, doctor } = await setupPair("pending");
    const res = await api("POST", "/api/chat/conversations", { token: doctor.token, body: { patientId } });
    assert.equal(res.status, 403);
    assert.equal(res.body.code, "APPOINTMENT_NOT_CONFIRMED");
  });

  test("حتی اگر مکالمه از قبل ساخته شده باشد، بعد از لغو نوبت دیگر نمی‌توان پیام فرستاد", async () => {
    const { patientSession, patientId, doctor, apptId } = await setupPair("completed");
    const start = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
    assert.equal(start.status, 200);
    const convId = start.body.conversation.id;

    const before1 = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "سلام داکتر" } });
    assert.equal(before1.status, 201, JSON.stringify(before1.body));

    // ادمین/داکتر بعداً نوبت را لغو می‌کند
    const admin = await makeSession("admin");
    const cancelRes = await api("PUT", `/api/admin/appointments/${apptId}/status`, { token: admin.token, body: { status: "cancelled" } });
    assert.equal(cancelRes.status, 200);

    const afterCancel = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "بعد از لغو" } });
    assert.equal(afterCancel.status, 403);
    assert.equal(afterCancel.body.code, "APPOINTMENT_NOT_CONFIRMED");

    // ولی خواندن تاریخچه‌ی قبلی همچنان باز است (طبق طراحی عمدی ensureActiveRelationship)
    const history = await api("GET", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token });
    assert.equal(history.status, 200);
    assert.ok(history.body.messages.some((m) => m.content === "سلام داکتر"));
  });

  test("ارسال پیوست و پیام صوتی هم قبل از تایید مسدود است", async () => {
    const { patientSession, patientId, doctor } = await setupPair("completed");
    const start = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
    const convId = start.body.conversation.id;

    const admin = await makeSession("admin");
    // نوبت را به pending برگردان تا رابطه‌ی فعال قطع شود (شبیه‌سازی برگشت وضعیت)
    const db = (await import("../db.js")).default;
    await db.query("UPDATE appointments SET status = 'pending' WHERE patientId = ? AND doctorId = ?", [patientId, doctor.id]);

    // بدون فایل واقعی، میان‌افزار multer پیش از رسیدن به کنترلر با ۴۰۰ رد می‌کند؛ نکته‌ی
    // اصلی این است که در هیچ حالتی (چه ۴۰۰ میان‌افزار، چه ۴۰۳ کنترلر) درخواست موفق نمی‌شود
    const attach = await api("POST", `/api/chat/conversations/${convId}/attachments`, { token: patientSession.token, body: {} });
    assert.ok([400, 403].includes(attach.status), `status=${attach.status}`);

    const voice = await api("POST", `/api/chat/conversations/${convId}/voice`, { token: patientSession.token, body: {} });
    assert.ok([400, 403].includes(voice.status), `status=${voice.status}`);
    void admin;
  });
});

describe("عملکرد عادی چت (بعد از تایید نوبت)", () => {
  async function readyConversation() {
    const { patientSession, doctor } = await setupPair("completed");
    const start = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
    return { patientSession, doctor, convId: start.body.conversation.id };
  }

  test("پیام خالی رد می‌شود", async () => {
    const { patientSession, convId } = await readyConversation();
    const res = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "   " } });
    assert.equal(res.status, 400);
  });

  test("پیام خیلی طولانی (بیش از ۴۰۰۰ کاراکتر) رد می‌شود", async () => {
    const { patientSession, convId } = await readyConversation();
    const res = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "ا".repeat(4001) } });
    assert.equal(res.status, 400);
  });

  test("ویرایش پیام توسط فرستنده کار می‌کند", async () => {
    const { patientSession, convId } = await readyConversation();
    const sent = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "پیام اول" } });
    const edited = await api("PUT", `/api/chat/conversations/${convId}/messages/${sent.body.data.id}`, { token: patientSession.token, body: { content: "پیام ویرایش‌شده" } });
    assert.equal(edited.status, 200);
    assert.equal(edited.body.data.content, "پیام ویرایش‌شده");
  });

  test("داکتر نمی‌تواند پیام بیمار را ویرایش یا حذف کند", async () => {
    const { patientSession, doctor, convId } = await readyConversation();
    const sent = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "پیام بیمار" } });
    const editAttempt = await api("PUT", `/api/chat/conversations/${convId}/messages/${sent.body.data.id}`, { token: doctor.token, body: { content: "دستکاری" } });
    assert.equal(editAttempt.status, 403);
    const deleteAttempt = await api("DELETE", `/api/chat/conversations/${convId}/messages/${sent.body.data.id}`, { token: doctor.token });
    assert.equal(deleteAttempt.status, 403);
  });

  test("حذف نرم پیام: بعد از حذف، محتوا پاک می‌شود", async () => {
    const { patientSession, convId } = await readyConversation();
    const sent = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "پاک می‌شود" } });
    const del = await api("DELETE", `/api/chat/conversations/${convId}/messages/${sent.body.data.id}`, { token: patientSession.token });
    assert.equal(del.status, 200);
    assert.ok(del.body.data.isDeleted);
  });

  test("واکنش ایموجی مجاز ثبت می‌شود، ایموجی نامجاز رد می‌شود", async () => {
    const { patientSession, doctor, convId } = await readyConversation();
    const sent = await api("POST", `/api/chat/conversations/${convId}/messages`, { token: patientSession.token, body: { content: "سلام" } });
    const ok = await api("POST", `/api/chat/conversations/${convId}/messages/${sent.body.data.id}/reactions`, { token: doctor.token, body: { emoji: "👍" } });
    assert.equal(ok.status, 200, JSON.stringify(ok.body));
    const bad = await api("POST", `/api/chat/conversations/${convId}/messages/${sent.body.data.id}/reactions`, { token: doctor.token, body: { emoji: "🐍" } });
    assert.equal(bad.status, 400);
  });

  test("پیوست تصویر با امضای واقعی PNG بعد از تایید نوبت با موفقیت ارسال می‌شود", async () => {
    const { patientSession, convId } = await readyConversation();
    // ۸ بایت امضای رسمی PNG + کمی داده‌ی بی‌معنی بعدش، تا isValidImageSignature قبول کند
    const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(32, 1)]);
    const res = await upload("POST", `/api/chat/conversations/${convId}/attachments`, {
      token: patientSession.token,
      fields: { content: "" },
      files: [{ field: "file", filename: "test.png", type: "image/png", content: png }],
    });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    assert.ok(res.body.data.attachmentFileType, JSON.stringify(res.body.data));
    assert.equal(res.body.data.attachmentOriginalName, "test.png");
    assert.equal(res.body.data.attachmentFileName, undefined, "نام واقعی فایل روی دیسک نباید به کلاینت نشت کند");
  });

  test("پیوست با محتوای جعلی (پسوند jpg ولی امضای واقعی نداشته) رد می‌شود", async () => {
    const { patientSession, convId } = await readyConversation();
    const fake = Buffer.from("this is not really an image, just text pretending to be one");
    const res = await upload("POST", `/api/chat/conversations/${convId}/attachments`, {
      token: patientSession.token,
      fields: {},
      files: [{ field: "file", filename: "fake.jpg", type: "image/jpeg", content: fake }],
    });
    assert.equal(res.status, 400);
  });


  test("طرف سوم (بیمار دیگر) به مکالمه دسترسی ندارد (IDOR)", async () => {
    const { convId } = await readyConversation();
    const outsider = await makeSession("user");
    const res = await api("GET", `/api/chat/conversations/${convId}/messages`, { token: outsider.token });
    assert.equal(res.status, 403);
  });

  test("داکتر دیگر (بدون رابطه) به مکالمه دسترسی ندارد", async () => {
    const { convId } = await readyConversation();
    const outsider = await createTestDoctor();
    const res = await api("GET", `/api/chat/conversations/${convId}/messages`, { token: outsider.token });
    assert.equal(res.status, 403);
  });

  test("مکالمه‌ی ناموجود ۴۰۴", async () => {
    const patientSession = await makeSession("user");
    const res = await api("GET", "/api/chat/conversations/99999999/messages", { token: patientSession.token });
    assert.equal(res.status, 404);
  });

  test("شروع دوباره‌ی مکالمه با همان داکتر، مکالمه‌ی قبلی را برمی‌گرداند نه یک رکورد تازه", async () => {
    const { patientSession, doctor, convId } = await readyConversation();
    const again = await api("POST", "/api/chat/conversations", { token: patientSession.token, body: { doctorId: doctor.id } });
    assert.equal(again.status, 200);
    assert.equal(again.body.conversation.id, convId);
  });
});

import { test, describe, after } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";

import db from "../db.js";
import {
  createUser, findByEmail, findById,
  registerFailedLogin, resetFailedLoginAttempts,
  updatePassword, updatePasswordAndRequireChange,
} from "../models/User.js";

after(closePool);

let counter = 0;
async function makeUser() {
  counter += 1;
  return createUser({ fullName: `کاربر امنیت ${counter}`, email: `sec-test-${Date.now()}-${counter}@example.com`, password: "Abcd1234" });
}

describe("قفل موقت حساب پس از تلاش‌های ناموفق", () => {
  test("زیر آستانه، حساب قفل نمی‌شود", async () => {
    const u = await makeUser();
    await registerFailedLogin(u.id, 5, 15);
    await registerFailedLogin(u.id, 5, 15);
    const fresh = await findByEmail(u.email);
    assert.equal(fresh.failedLoginAttempts, 2);
    assert.equal(fresh.lockedUntil, null);
  });

  test("رسیدن به آستانه، حساب را قفل می‌کند و شمارنده را صفر می‌کند", async () => {
    const u = await makeUser();
    for (let i = 0; i < 5; i += 1) await registerFailedLogin(u.id, 5, 15);
    const fresh = await findByEmail(u.email);
    assert.equal(fresh.failedLoginAttempts, 0);
    assert.ok(fresh.lockedUntil, "lockedUntil باید مقدار داشته باشد");
    assert.ok(new Date(fresh.lockedUntil) > new Date(), "زمان قفل باید در آینده باشد");
  });

  test("ورود موفق (resetFailedLoginAttempts) قفل و شمارنده را پاک می‌کند", async () => {
    const u = await makeUser();
    for (let i = 0; i < 5; i += 1) await registerFailedLogin(u.id, 5, 15);
    await resetFailedLoginAttempts(u.id);
    const fresh = await findByEmail(u.email);
    assert.equal(fresh.failedLoginAttempts, 0);
    assert.equal(fresh.lockedUntil, null);
  });

  test("آستانه‌ی قابل تنظیم رعایت می‌شود (مثلاً ۳ به‌جای ۵)", async () => {
    const u = await makeUser();
    await registerFailedLogin(u.id, 3, 15);
    await registerFailedLogin(u.id, 3, 15);
    let fresh = await findByEmail(u.email);
    assert.equal(fresh.lockedUntil, null, "با آستانه‌ی ۳، بعد از ۲ تلاش هنوز نباید قفل شود");
    await registerFailedLogin(u.id, 3, 15);
    fresh = await findByEmail(u.email);
    assert.ok(fresh.lockedUntil, "با آستانه‌ی ۳، تلاش سوم باید قفل کند");
  });
});

describe("الزام تغییر رمز عبور موقت (mustChangePassword)", () => {
  test("رمز موقتِ ادمین‌ساز، پرچم mustChangePassword را فعال می‌کند", async () => {
    const u = await makeUser();
    await updatePasswordAndRequireChange(u.id, "TempPass123");
    const fresh = await findById(u.id);
    assert.equal(fresh.mustChangePassword, 1);
  });

  test("تغییر رمز توسط خودِ کاربر (updatePassword)، پرچم را پاک می‌کند", async () => {
    const u = await makeUser();
    await updatePasswordAndRequireChange(u.id, "TempPass123");
    let fresh = await findById(u.id);
    assert.equal(fresh.mustChangePassword, 1);

    await updatePassword(u.id, "NewOwnPass123");
    fresh = await findById(u.id);
    assert.equal(fresh.mustChangePassword, 0);
  });

  test("رمز عبور واقعاً عوض شده و رمز قبلی دیگر کار نمی‌کند", async () => {
    const u = await makeUser();
    await updatePasswordAndRequireChange(u.id, "TempPass123");
    const raw = await findByEmail(u.email);
    const bcrypt = (await import("bcryptjs")).default;
    assert.equal(await bcrypt.compare("TempPass123", raw.password), true);
    assert.equal(await bcrypt.compare("Abcd1234", raw.password), false);
  });
});

import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient, addAppointment } from "./testApp.js";
import db from "../db.js";
import { createPrescription } from "../models/Prescription.js";
import { createRecord } from "../models/MedicalRecord.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// ممیزی امنیتی «نسخه و سوابق طبی»: هر تست یک حمله‌ی واقعی را امتحان می‌کند و رفتار امن را انتظار دارد.

function futureDate(days = 3) {
  const d = new Date(Date.now() + days * 86400000);
  return d.toISOString().slice(0, 10);
}

describe("Patient Ownership — ربودن پرونده‌ی بیمار از مسیر نوبت‌گیری (Broken Access Control)", () => {
  test("نوبت‌گیری با ایمیل قربانی، مالکیت پرونده‌ی او را به مهاجم منتقل نمی‌کند", async () => {
    const victim = await makeSession("user");
    const attacker = await makeSession("user");
    const doctor = await createTestDoctor();
    const victimPatientId = await createTestPatient(victim.id, "قربانی");
    await db.query("UPDATE patients SET email = ? WHERE id = ?", [victim.email, victimPatientId]);
    const rx = await createPrescription({ patientId: victimPatientId, doctorId: doctor.id, diagnosis: "خصوصی", medicationName: "داروی محرمانه" });

    const res = await api("POST", "/api/appointments", {
      token: attacker.token,
      body: {
        fullName: "مهاجم", phone: "0700000000", email: victim.email, department: "تست",
        doctorId: doctor.id, appointmentDate: futureDate(4), appointmentTime: "10:00",
      },
    });
    assert.ok([200, 201, 400, 409].includes(res.status), `status=${res.status} ${JSON.stringify(res.body)}`);

    const [[row]] = await db.query("SELECT userId FROM patients WHERE id = ?", [victimPatientId]);
    assert.equal(row.userId, victim.id, "مالکیت پرونده‌ی قربانی نباید تغییر کند");
    const stolen = await api("GET", "/api/users/prescription-list", { token: attacker.token });
    assert.ok(!stolen.body.prescriptions?.some((p) => p.id === rx.id));
    const emr = await api("GET", "/api/users/emr", { token: attacker.token });
    assert.ok(!emr.body.prescriptions?.some((p) => p.id === rx.id));
  });

  test("مهمانِ بدون ورود نمی‌تواند نوبت بگیرد؛ نام و تلفن پرونده‌ی بیمار با ایمیل او تغییر نمی‌کند", async () => {
    const victim = await makeSession("user");
    const doctor = await createTestDoctor();
    const pid = await createTestPatient(victim.id, "بیمار اصلی");
    await db.query("UPDATE patients SET email = ?, fullName = 'نام اصلی', phone = '0799999999' WHERE id = ?", [victim.email, pid]);
    const booked = await api("POST", "/api/appointments", {
      body: { fullName: "نام جعلی", phone: "0711111111", email: victim.email, department: "تست", doctorId: doctor.id, appointmentDate: futureDate(5), appointmentTime: "11:00" },
    });
    assert.equal(booked.status, 401, "نوبت‌گیری باید ورود را الزامی کند");
    const [[row]] = await db.query("SELECT fullName, phone, userId FROM patients WHERE id = ?", [pid]);
    assert.equal(row.fullName, "نام اصلی");
    assert.equal(row.phone, "0799999999");
    assert.equal(row.userId, victim.id);
  });
});

describe("Doctor Ownership/Permission — فقط بیماران مجاز", () => {
  let docA; let docB; let patient; let patientId; let apptA; let rxA; let recA;

  before(async () => {
    docA = await createTestDoctor();
    docB = await createTestDoctor();
    patient = await makeSession("user");
    patientId = await createTestPatient(patient.id, "بیمار مجوز");
    apptA = await addAppointment(patientId, docA.id, "confirmed");
    rxA = await createPrescription({ patientId, doctorId: docA.id, appointmentId: apptA, medicationName: "داروی الف", groupId: `ea-${Date.now()}` });
    recA = await createRecord({ patientId, doctorId: docA.id, appointmentId: apptA, symptoms: "x" });
  });

  test("IDOR روی نسخه‌های هر نوبت: داکتر بدون رابطه ۴۰۳ می‌گیرد", async () => {
    const res = await api("GET", `/api/medical-records/appointments/${apptA}/prescriptions`, { token: docB.token });
    assert.equal(res.status, 403, JSON.stringify(res.body));
    const own = await api("GET", `/api/medical-records/appointments/${apptA}/prescriptions`, { token: docA.token });
    assert.equal(own.status, 200);
  });

  test("بیمار به مسیرهای داکتر/ادمین دسترسی ندارد (نسخه‌های نوبت، PDF، پرونده‌ی بیمار)", async () => {
    for (const path of [
      `/api/medical-records/appointments/${apptA}/prescriptions`,
      `/api/medical-records/prescriptions/${rxA.id}/pdf`,
      `/api/medical-records/patient/${patientId}`,
    ]) {
      const res = await api("GET", path, { token: patient.token });
      assert.equal(res.status, 403, path);
    }
  });

  test("شمارش شناسه‌ها ممکن نیست: بیمار موجود-غیرمجاز و بیمار ناموجود پاسخ یکسان ۴۰۳ دارند", async () => {
    const existing = await api("GET", `/api/medical-records/patient/${patientId}`, { token: docB.token });
    const missing = await api("GET", "/api/medical-records/patient/987654321", { token: docB.token });
    assert.equal(existing.status, 403);
    assert.equal(missing.status, 403);
    assert.deepEqual(existing.body, missing.body);
    const create = await api("POST", "/api/medical-records/prescriptions", { token: docB.token, body: { patientId: 987654321, medicationName: "x" } });
    assert.equal(create.status, 403);
  });

  test("نوبت در انتظار/لغوشده/ردشده دسترسی بالینی نمی‌دهد (فقط confirmed/completed)", async () => {
    for (const status of ["pending", "cancelled", "rejected"]) {
      const d = await createTestDoctor();
      await addAppointment(patientId, d.id, status, { dayOffset: 20 + Math.floor(Math.random() * 50) });
      const read = await api("GET", `/api/medical-records/patient/${patientId}`, { token: d.token });
      assert.equal(read.status, 403, `read ${status}`);
      const write = await api("POST", "/api/medical-records/prescriptions", { token: d.token, body: { patientId, medicationName: "x" } });
      assert.equal(write.status, 403, `write ${status}`);
    }
    const ok = await createTestDoctor();
    await addAppointment(patientId, ok.id, "completed", { dayOffset: 90 });
    assert.equal((await api("GET", `/api/medical-records/patient/${patientId}`, { token: ok.token })).status, 200);
  });

  test("نوبت دیگرِ داکتر یا ویزیت بیمار دیگر را نمی‌شود به نسخه وصل کرد (ID در body)", async () => {
    const otherPatientUser = await makeSession("user");
    const otherPatient = await createTestPatient(otherPatientUser.id, "بیمار دیگر");
    const otherRecord = await createRecord({ patientId: otherPatient, doctorId: docA.id, symptoms: "مال دیگری" });
    const docC = await createTestDoctor();
    const apptC = await addAppointment(patientId, docC.id, "confirmed", { dayOffset: 7, time: "10:00:00" });

    const foreignRecord = await api("POST", "/api/medical-records/prescriptions", {
      token: docA.token, body: { patientId, recordId: otherRecord.id, medicationName: "x" },
    });
    assert.equal(foreignRecord.status, 400, JSON.stringify(foreignRecord.body));
    const foreignAppt = await api("POST", "/api/medical-records/prescriptions", {
      token: docA.token, body: { patientId, appointmentId: apptC, medicationName: "x" },
    });
    assert.ok([400, 403].includes(foreignAppt.status), `status=${foreignAppt.status}`);
    const good = await api("POST", "/api/medical-records/prescriptions", {
      token: docA.token, body: { patientId, appointmentId: apptA, recordId: recA.id, medicationName: "مجاز" },
    });
    assert.equal(good.status, 201, JSON.stringify(good.body));
  });

  test("Mass assignment: doctorId/status/patientId در body نادیده گرفته می‌شوند", async () => {
    const res = await api("POST", "/api/medical-records/prescriptions", {
      token: docA.token, body: { patientId, doctorId: docB.id, status: "completed", medicationName: "تزریق" },
    });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    const id = res.body.item.id;
    const [[row]] = await db.query("SELECT doctorId, status FROM prescriptions WHERE id = ?", [id]);
    assert.equal(row.doctorId, docA.id);
    assert.equal(row.status, "active");

    const upd = await api("PUT", `/api/medical-records/prescriptions/${id}`, {
      token: docA.token, body: { dosage: "1", patientId: 1, doctorId: docB.id, status: "cancelled" },
    });
    assert.equal(upd.status, 200);
    const [[after]] = await db.query("SELECT doctorId, patientId, status FROM prescriptions WHERE id = ?", [id]);
    assert.equal(after.doctorId, docA.id);
    assert.equal(after.patientId, patientId);
    assert.equal(after.status, "active");
  });

  test("داکتر دیگر نمی‌تواند نسخه را ببیند، ویرایش، حذف یا PDF بگیرد", async () => {
    for (const [method, path] of [
      ["GET", `/api/medical-records/prescriptions/${rxA.id}/pdf`],
      ["PUT", `/api/medical-records/prescriptions/${rxA.id}`],
      ["DELETE", `/api/medical-records/prescriptions/${rxA.id}`],
    ]) {
      const res = await api(method, path, { token: docB.token, body: method === "PUT" ? { dosage: "x" } : undefined });
      assert.equal(res.status, 403, `${method} ${path}`);
    }
  });

  test("فهرست‌های داکتر (/me/patients) برای نوبت‌های تأییدنشده اطلاعات بالینی لو نمی‌دهند", async () => {
    const d = await createTestDoctor();
    await addAppointment(patientId, d.id, "pending", { dayOffset: 30 });
    const res = await api("GET", "/api/doctors/me/patients", { token: d.token });
    assert.equal(res.status, 200);
    const row = res.body.patients.find((p) => p.patientId === patientId);
    assert.ok(row, "ردیف نوبت باید دیده شود");
    assert.equal(row.prescriptionCount, null);
    assert.equal(row.recordCount, null);
  });
});

describe("Admin / Role — محدودیت نقش و نوشتن بالینی", () => {
  test("ادمین نسخه‌ها را می‌بیند و وضعیت را تغییر می‌دهد، اما نسخه نمی‌نویسد/ویرایش نمی‌کند/حذف نمی‌کند", async () => {
    const admin = await makeSession("admin");
    const doctor = await createTestDoctor();
    const u = await makeSession("user");
    const pid = await createTestPatient(u.id, "بیمار ادمین");
    const rx = await createPrescription({ patientId: pid, doctorId: doctor.id, medicationName: "الف", groupId: `ad-${Date.now()}` });

    assert.equal((await api("GET", "/api/admin/prescriptions", { token: admin.token })).status, 200);
    assert.equal((await api("GET", `/api/admin/patients/${pid}/full-profile`, { token: admin.token })).status, 200);
    assert.equal((await api("GET", `/api/medical-records/patient/${pid}`, { token: admin.token })).status, 200);
    assert.equal((await api("GET", `/api/medical-records/prescriptions/${rx.id}/pdf`, { token: admin.token })).status, 200);
    assert.equal((await api("PUT", `/api/admin/prescriptions/${rx.id}/status`, { token: admin.token, body: { status: "completed" } })).status, 200);

    for (const [method, path, body] of [
      ["POST", "/api/medical-records/prescriptions", { patientId: pid, medicationName: "x" }],
      ["PUT", `/api/medical-records/prescriptions/${rx.id}`, { dosage: "x" }],
      ["DELETE", `/api/medical-records/prescriptions/${rx.id}`, undefined],
      ["POST", "/api/medical-records/diagnoses", { patientId: pid, title: "x" }],
      ["POST", "/api/medical-records/encounters", { patientId: pid }],
    ]) {
      const res = await api(method, path, { token: admin.token, body });
      assert.equal(res.status, 403, `${method} ${path}`);
    }
  });

  test("داکتر و بیمار به مسیرهای ادمین دسترسی ندارند", async () => {
    const doctor = await createTestDoctor();
    const patient = await makeSession("user");
    for (const token of [doctor.token, patient.token]) {
      for (const path of ["/api/admin/prescriptions", "/api/admin/prescriptions/stats", "/api/admin/patients/1/full-profile"]) {
        assert.equal((await api("GET", path, { token })).status, 403, path);
      }
      assert.equal((await api("PUT", "/api/admin/prescriptions/1/status", { token, body: { status: "completed" } })).status, 403);
    }
  });
});

describe("JWT Authorization", () => {
  test("تغییر نقش در دیتابیس فوراً روی توکن قدیمی اثر می‌گذارد (نه تا ۷ روز بعد)", async () => {
    const doctor = await createTestDoctor();
    const u = await makeSession("user");
    const pid = await createTestPatient(u.id, "بیمار نقش");
    await addAppointment(pid, doctor.id, "confirmed", { dayOffset: 11 });
    assert.equal((await api("GET", `/api/medical-records/patient/${pid}`, { token: doctor.token })).status, 200);
    await db.query("UPDATE users SET role = 'user' WHERE id = ?", [doctor.userId]);
    assert.equal((await api("GET", `/api/medical-records/patient/${pid}`, { token: doctor.token })).status, 403);

    const admin = await makeSession("admin");
    assert.equal((await api("GET", "/api/admin/prescriptions", { token: admin.token })).status, 200);
    await db.query("UPDATE users SET role = 'user' WHERE id = ?", [admin.id]);
    assert.equal((await api("GET", "/api/admin/prescriptions", { token: admin.token })).status, 403);
  });

  test("حساب غیرفعال‌شده فوراً قطع می‌شود", async () => {
    const u = await makeSession("user");
    assert.equal((await api("GET", "/api/users/prescription-list", { token: u.token })).status, 200);
    await db.query("UPDATE users SET isActive = 0 WHERE id = ?", [u.id]);
    assert.equal((await api("GET", "/api/users/prescription-list", { token: u.token })).status, 403);
  });
});

describe("ورودی‌های ناسالم و نشت اطلاعات", () => {
  test("شناسه‌های غیرعددی/آرایه‌ای ۵۰۰ نمی‌دهند", async () => {
    const u = await makeSession("user");
    const doctor = await createTestDoctor();
    for (const path of ["/api/users/prescriptions/abc/detail", "/api/users/prescriptions/1%20OR%201=1/detail", "/api/users/prescriptions/abc/pdf"]) {
      const res = await api("GET", path, { token: u.token });
      assert.ok(res.status < 500, `${path} → ${res.status}`);
    }
    const arr = await api("POST", "/api/medical-records/prescriptions", { token: doctor.token, body: { patientId: [1, 2], medicationName: "x" } });
    assert.ok(arr.status >= 400 && arr.status < 500, `array patientId → ${arr.status}`);
    const sqli = await api("GET", "/api/users/prescription-list?q=%27%20OR%201%3D1%20--&status=%27", { token: u.token });
    assert.equal(sqli.status, 200);
    assert.equal(sqli.body.prescriptions.length, 0);
  });

  test("جستجوی عمومی هیچ داده‌ی بالینی برنمی‌گرداند", async () => {
    const doctor = await createTestDoctor();
    const u = await makeSession("user");
    const pid = await createTestPatient(u.id, "بیمار جستجو");
    await createPrescription({ patientId: pid, doctorId: doctor.id, diagnosis: "تشخیصمخفیXYZ", medicationName: "داروی‌مخفیXYZ" });
    const res = await api("GET", "/api/search?q=XYZ");
    assert.equal(res.status, 200);
    // خودِ عبارت جستجو در پاسخ تکرار می‌شود؛ فقط «نتایج» نباید چیزی از نسخه داشته باشند
    const { query, q, ...results } = res.body;
    assert.ok(!JSON.stringify(results).includes("XYZ"), JSON.stringify(results).slice(0, 300));
  });
});

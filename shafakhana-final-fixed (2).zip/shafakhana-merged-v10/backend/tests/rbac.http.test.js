import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor } from "./testApp.js";

// ماتریس دسترسیِ نقش‌ها: برای هر مسیر مشخص می‌کنیم کدام نقش‌ها مجازند.
//  - بدون توکن  → همیشه ۴۰۱ (مگر مسیر عمومی)
//  - نقش غیرمجاز → همیشه ۴۰۳ و هرگز به کنترلر نمی‌رسد (پس مسیرهای مخرب هم امن تست می‌شوند)
//  - نقش مجاز    → نباید ۴۰۱/۴۰۳ بگیرد (فقط برای GET های بی‌خطر بررسی می‌شود تا داده‌ای تغییر نکند)
const ALL = ["user", "doctor", "admin", "superadmin"];
const ADMINS = ["admin", "superadmin"];

const ROUTES = [
  // ---- پنل ادمین (admin + superadmin)
  ["GET", "/api/admin/patients", ADMINS],
  ["GET", "/api/admin/patients/export", ADMINS],
  ["DELETE", "/api/admin/patients/bulk", ADMINS],
  ["GET", "/api/admin/patients/1", ADMINS],
  ["PUT", "/api/admin/patients/1", ADMINS],
  ["PUT", "/api/admin/patients/1/status", ADMINS],
  ["POST", "/api/admin/patients/1/reset-password", ADMINS],
  ["DELETE", "/api/admin/patients/1", ADMINS],
  ["GET", "/api/admin/doctors", ADMINS],
  ["POST", "/api/admin/doctors", ADMINS],
  ["DELETE", "/api/admin/doctors/1", ADMINS],
  ["POST", "/api/admin/doctors/1/account", ADMINS],
  ["GET", "/api/admin/appointments", ADMINS],
  ["PUT", "/api/admin/appointments/1/status", ADMINS],
  ["DELETE", "/api/admin/appointments/1", ADMINS],
  ["GET", "/api/admin/departments", ADMINS],
  ["GET", "/api/admin/schedules", ADMINS],
  ["GET", "/api/admin/news", ADMINS],
  ["POST", "/api/admin/news", ADMINS],
  ["DELETE", "/api/admin/news/1", ADMINS],
  ["GET", "/api/admin/comments", ADMINS],
  ["GET", "/api/admin/contacts", ADMINS],
  ["GET", "/api/admin/reports", ADMINS],
  ["GET", "/api/admin/file-transfers", ADMINS],
  // ---- سوپرادمین
  ["GET", "/api/superadmin/admins", ["superadmin"]],
  ["POST", "/api/superadmin/admins", ["superadmin"]],
  ["DELETE", "/api/superadmin/admins/1", ["superadmin"]],
  ["GET", "/api/superadmin/users", ["superadmin"]],
  ["PUT", "/api/superadmin/users/1/role", ["superadmin"]],
  ["GET", "/api/superadmin/settings", ["superadmin"]],
  ["PUT", "/api/superadmin/settings", ["superadmin"]],
  ["GET", "/api/superadmin/activity-logs", ["superadmin"]],
  ["GET", "/api/superadmin/audit-logs", ["superadmin"]],
  ["GET", "/api/superadmin/permissions", ["superadmin"]],
  ["GET", "/api/superadmin/database-overview", ["superadmin"]],
  ["GET", "/api/superadmin/sessions", ["superadmin"]],
  ["DELETE", "/api/superadmin/sessions/1", ["superadmin"]],
  ["GET", "/api/superadmin/system-health", ["superadmin"]],
  ["GET", "/api/superadmin/backups", ["superadmin"]],
  ["POST", "/api/superadmin/backups", ["superadmin"]],
  ["POST", "/api/superadmin/backups/folders", ["superadmin"]],
  ["PUT", "/api/superadmin/backups/folders/f-00000000", ["superadmin"]],
  ["POST", "/api/superadmin/backups/folders/f-00000000/activate", ["superadmin"]],
  ["DELETE", "/api/superadmin/backups/folders/f-00000000", ["superadmin"]],
  ["POST", "/api/superadmin/backups/x.sql/restore", ["superadmin"]],
  ["DELETE", "/api/superadmin/backups/x.sql", ["superadmin"]],
  // ---- صورت‌حساب
  ["GET", "/api/billing/invoices", ADMINS],
  ["POST", "/api/billing/invoices", ADMINS],
  ["GET", "/api/billing/invoices/1", ADMINS],
  ["PUT", "/api/billing/invoices/1/cancel", ADMINS],
  ["PUT", "/api/billing/invoices/1/approve", ADMINS],
  ["DELETE", "/api/billing/invoices/1", ADMINS],
  ["POST", "/api/billing/invoices/1/payments", ADMINS],
  ["GET", "/api/billing/patients/1/invoices", ADMINS],
  // ---- گزارش‌ها
  ["GET", "/api/reports/appointments", ADMINS],
  ["GET", "/api/reports/patients", ADMINS],
  ["GET", "/api/reports/doctors", ADMINS],
  ["GET", "/api/reports/revenue", ADMINS],
  // ---- نسخه و سوابق طبی (پنل ادمین)
  ["GET", "/api/admin/prescriptions", ADMINS],
  ["GET", "/api/admin/prescriptions/stats", ADMINS],
  ["PUT", "/api/admin/prescriptions/99999999/status", ADMINS],
  // ---- پرونده‌ی صحی (داکتر + ادمین‌ها)
  ["GET", "/api/medical-records/patient/99999999", ["doctor", "admin", "superadmin"]],
  ["POST", "/api/medical-records/encounters", ["doctor"]],
  ["POST", "/api/medical-records/diagnoses", ["doctor"]],
  ["POST", "/api/medical-records/prescriptions", ["doctor"]],
  // بیمار (نقش user) هیچ‌کدام از عملیات نوشتن روی پرونده‌ی پزشکی را ندارد: ویرایش/حذف هم ۴۰۳ می‌گیرد
  ["PUT", "/api/medical-records/prescriptions/1", ["doctor"]],
  ["DELETE", "/api/medical-records/prescriptions/1", ["doctor"]],
  ["PUT", "/api/medical-records/diagnoses/1", ["doctor"]],
  ["DELETE", "/api/medical-records/diagnoses/1", ["doctor"]],
  ["PUT", "/api/medical-records/encounters/1", ["doctor"]],
  ["PUT", "/api/medical-records/allergies/1", ["doctor"]],
  ["PUT", "/api/medical-records/lab-results/1", ["doctor"]],
  ["PUT", "/api/medical-records/radiology-reports/1", ["doctor"]],
  ["POST", "/api/medical-records/allergies", ["doctor"]],
  ["POST", "/api/medical-records/lab-results", ["doctor"]],
  ["POST", "/api/medical-records/radiology-reports", ["doctor"]],
  ["DELETE", "/api/medical-records/lab-results/1", ["doctor"]],
  // ---- چت (فقط بیمار و داکتر)
  ["GET", "/api/chat/conversations", ["user", "doctor"]],
  ["POST", "/api/chat/conversations", ["user", "doctor"]],
  // ---- پنل داکتر
  ["GET", "/api/doctors/me/appointments", ["doctor"]],
  ["GET", "/api/doctors/me/patients", ["doctor"]],
  ["GET", "/api/doctors/me/prescriptions", ["doctor"]],
  ["GET", "/api/doctors/me/prescriptions/stats", ["doctor"]],
  ["GET", "/api/doctors/me/invoices", ["doctor"]],
  ["GET", "/api/doctors/me/schedules", ["doctor"]],
  ["GET", "/api/doctors/me/file-transfers", ["doctor"]],
  ["DELETE", "/api/doctors/me/file-transfers/1", ["doctor"]],
  // ---- دپارتمان‌ها: خواندن عمومی، نوشتن فقط ادمین
  ["POST", "/api/departments", ADMINS],
  ["PUT", "/api/departments/1", ADMINS],
  ["DELETE", "/api/departments/1", ADMINS],
];

// مسیرهای «فقط با ورود»، بدون محدودیت نقش
const AUTH_ONLY = [
  ["GET", "/api/users/profile"],
  ["GET", "/api/users/appointments"],
  ["GET", "/api/users/invoices"],
  ["GET", "/api/users/prescriptions"],
  ["GET", "/api/users/prescription-list"],
  ["GET", "/api/users/prescriptions/1/detail"],
  ["GET", "/api/users/lab-results"],
  ["GET", "/api/users/notifications"],
  ["GET", "/api/users/emr"],
  ["GET", "/api/appointments/mine"],
  ["GET", "/api/auth/me"],
];

// مسیرهای عمومی (بدون توکن نباید ۴۰۱ بدهند)
const PUBLIC = [
  ["GET", "/"],
  ["GET", "/api/departments"],
  ["GET", "/api/doctors"],
  ["GET", "/api/news"],
  ["GET", "/api/settings/public"],
  ["GET", "/api/search?q=test"],
];

const sessions = {};

before(async () => {
  await startServer();
  for (const role of ALL) sessions[role] = await makeSession(role);
  // داکتر مجاز باید «پروفایل داکتری» وصل‌شده به حسابش داشته باشد (مسیرهای داکتر بدون آن ۴۰۳ می‌دهند)
  sessions.doctor = await createTestDoctor();
});
after(async () => {
  await stopServer();
  await closePool();
});

describe("بدون توکن: ۴۰۱ برای همه‌ی مسیرهای محافظت‌شده", () => {
  for (const [method, path] of [...ROUTES, ...AUTH_ONLY]) {
    test(`${method} ${path}`, async () => {
      const res = await api(method, path, { body: method === "GET" || method === "DELETE" ? undefined : {} });
      assert.equal(res.status, 401);
    });
  }
});

describe("نقش غیرمجاز: ۴۰۳ و هرگز اجرای کنترلر", () => {
  for (const [method, path, allowed] of ROUTES) {
    for (const role of ALL.filter((r) => !allowed.includes(r))) {
      test(`${role} ← ${method} ${path}`, async () => {
        const res = await api(method, path, {
          token: sessions[role].token,
          body: method === "GET" || method === "DELETE" ? undefined : {},
        });
        assert.equal(res.status, 403, `نقش ${role} نباید اجازه داشته باشد`);
        assert.equal(res.body.code, "ACCESS_DENIED");
      });
    }
  }
});

describe("نقش مجاز به مسیر می‌رسد (فقط GET های بی‌خطر)", () => {
  for (const [method, path, allowed] of ROUTES.filter((r) => r[0] === "GET")) {
    for (const role of allowed) {
      test(`${role} ← ${method} ${path}`, async () => {
        const res = await api(method, path, { token: sessions[role].token });
        // ۴۰۳ با کد ACCESS_DENIED یعنی «نقش» رد شده؛ ۴۰۳ کنترلر (بدون این کد) یعنی نقش پذیرفته شد اما
        // مالکیت/رابطه‌ی داکتر-بیمار برقرار نیست (مثلاً بیمار ناموجود برای داکتر عمداً ۴۰۳ یکسان می‌دهد)
        const roleDenied = res.status === 401 || (res.status === 403 && res.body?.code === "ACCESS_DENIED");
        assert.ok(!roleDenied, `نقش مجاز ${role} به ${path} رد شد (${res.status})`);
      });
    }
  }
});

describe("مسیرهای فقط-با-ورود برای همه‌ی نقش‌ها باز است", () => {
  for (const [method, path] of AUTH_ONLY) {
    test(`${method} ${path}`, async () => {
      for (const role of ALL) {
        const res = await api(method, path, { token: sessions[role].token });
        assert.ok(![401, 403].includes(res.status), `${role} → ${res.status}`);
      }
    });
  }
});

describe("مسیرهای عمومی بدون توکن کار می‌کنند", () => {
  for (const [method, path] of PUBLIC) {
    test(`${method} ${path}`, async () => {
      const res = await api(method, path);
      assert.equal(res.status, 200);
    });
  }
});

describe("مسیر ناموجود و ورودی خراب", () => {
  test("مسیر ناموجود ۴۰۴ با JSON می‌دهد", async () => {
    const res = await api("GET", "/api/does-not-exist");
    assert.equal(res.status, 404);
    assert.ok(res.body && res.body.message);
  });

  test("JSON خراب ۴۰۰ می‌دهد و اطلاعات داخلی نشت نمی‌کند", async () => {
    const res = await api("POST", "/api/auth/login", { rawBody: "{bad json", contentType: "application/json" });
    assert.ok([400, 500].includes(res.status));
    const text = res.raw.toString("utf8");
    assert.ok(!text.includes("node_modules"), "stack trace نباید نشت کند");
    assert.ok(!/at\s+\S+\s+\(/.test(text), "stack trace نباید نشت کند");
  });
});

describe("حساب داکتر بدون پروفایل داکتری", () => {
  test("به داده‌های داکتر دسترسی ندارد (۴۰۳ با پیام مشخص)", async () => {
    const orphan = await makeSession("doctor");
    for (const path of ["/api/chat/conversations", "/api/medical-records/patient/1", "/api/doctors/me/patients"]) {
      const res = await api("GET", path, { token: orphan.token });
      // بعضی مسیرها ۴۰۳ و مسیر «بیماران من» ۴۰۴ می‌دهد؛ مهم این است که هیچ‌کدام ۲۰۰ نشوند
      assert.ok([403, 404].includes(res.status), `${path} → ${res.status}`);
    }
  });
});

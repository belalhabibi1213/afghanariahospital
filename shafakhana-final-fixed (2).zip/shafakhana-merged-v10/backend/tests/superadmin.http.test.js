import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor } from "./testApp.js";

import db from "../db.js";
import jwt from "jsonwebtoken";
import { JWT_SECRET } from "../utils/env.js";

let superadmin;

before(async () => {
  await startServer();
  superadmin = await makeSession("superadmin");
});
after(async () => {
  await stopServer();
  await closePool();
});

describe("مدیریت نقش کاربران (PUT /api/superadmin/users/:id/role)", () => {
  test("تغییر نقش user → admin موفق است", async () => {
    const u = await makeSession("user");
    const res = await api("PUT", `/api/superadmin/users/${u.id}/role`, { token: superadmin.token, body: { role: "admin" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const [[row]] = await db.query("SELECT role FROM users WHERE id = ?", [u.id]);
    assert.equal(row.role, "admin");
  });

  test("نمی‌شود نقش superadmin تخصیص داد", async () => {
    const u = await makeSession("user");
    const res = await api("PUT", `/api/superadmin/users/${u.id}/role`, { token: superadmin.token, body: { role: "superadmin" } });
    assert.equal(res.status, 400);
    const [[row]] = await db.query("SELECT role FROM users WHERE id = ?", [u.id]);
    assert.equal(row.role, "user");
  });

  test("نمی‌شود نقشِ یک سوپرادمین دیگر را تغییر داد", async () => {
    const otherSuper = await makeSession("superadmin");
    const res = await api("PUT", `/api/superadmin/users/${otherSuper.id}/role`, { token: superadmin.token, body: { role: "admin" } });
    assert.equal(res.status, 403);
    const [[row]] = await db.query("SELECT role FROM users WHERE id = ?", [otherSuper.id]);
    assert.equal(row.role, "superadmin");
  });

  test("سوپرادمین نمی‌تواند نقش خودش را عوض کند", async () => {
    const res = await api("PUT", `/api/superadmin/users/${superadmin.id}/role`, { token: superadmin.token, body: { role: "admin" } });
    assert.equal(res.status, 400);
  });

  test("نمی‌شود مستقیماً نقش doctor داد (باید از مسیر ساخت حساب داکتر انجام شود)", async () => {
    const u = await makeSession("user");
    const res = await api("PUT", `/api/superadmin/users/${u.id}/role`, { token: superadmin.token, body: { role: "doctor" } });
    assert.equal(res.status, 400);
  });

  test("نقشِ نامعتبر/ناموجود رد می‌شود", async () => {
    const u = await makeSession("user");
    assert.equal((await api("PUT", `/api/superadmin/users/${u.id}/role`, { token: superadmin.token, body: { role: "hacker" } })).status, 400);
    assert.equal((await api("PUT", "/api/superadmin/users/99999999/role", { token: superadmin.token, body: { role: "admin" } })).status, 404);
  });

  test("ادمین معمولی اجازه‌ی تغییر نقش ندارد", async () => {
    const admin = await makeSession("admin");
    const u = await makeSession("user");
    const res = await api("PUT", `/api/superadmin/users/${u.id}/role`, { token: admin.token, body: { role: "admin" } });
    assert.equal(res.status, 403);
  });
});

describe("ساخت/ویرایش/حذف حساب ادمین", () => {
  test("ساخت حساب ادمین موفق است و می‌تواند وارد شود", async () => {
    const email = `newadmin${Date.now()}@test.local`;
    const res = await api("POST", "/api/superadmin/admins", { token: superadmin.token, body: { fullName: "ادمین تازه", email, password: "Abcd1234" } });
    assert.equal(res.status, 201, JSON.stringify(res.body));
    const login = await api("POST", "/api/auth/login", { body: { email, password: "Abcd1234" } });
    assert.equal(login.status, 200);
    assert.equal(login.body.user.role, "admin");
  });

  test("ایمیل تکراری در ساخت ادمین رد می‌شود", async () => {
    const admin = await makeSession("admin");
    const res = await api("POST", "/api/superadmin/admins", { token: superadmin.token, body: { fullName: "تکراری", email: admin.email, password: "Abcd1234" } });
    assert.equal(res.status, 409);
  });

  test("رگرسیون: نمی‌شود از طریق مسیر «حذف ادمین» یک بیمار/داکتر/سوپرادمین دیگر را حذف کرد", async () => {
    const patient = await makeSession("user");
    const doctor = await createTestDoctor();
    const otherSuper = await makeSession("superadmin");

    // توجه: createTestDoctor().id شناسه‌ی جدول doctors است، نه users؛ برای مسیرهای مبتنی بر «کاربر»
    // باید doctor.userId استفاده شود (وگرنه ممکن است با شناسه‌ی یک ادمین واقعی برخورد کند و آن را حذف کند)
    const doctorUser = { id: doctor.userId, role: "doctor" };
    for (const victim of [patient, doctorUser, otherSuper]) {
      const res = await api("DELETE", `/api/superadmin/admins/${victim.id}`, { token: superadmin.token });
      assert.equal(res.status, 400, `role=${victim.role}`);
      const [[row]] = await db.query("SELECT id FROM users WHERE id = ?", [victim.id]);
      assert.ok(row, `کاربر با نقش ${victim.role} نباید حذف شده باشد`);
    }
  });

  test("رگرسیون: نمی‌شود از طریق مسیر «ویرایش ادمین» وضعیتِ بیمار/داکتر را تغییر داد", async () => {
    const patient = await makeSession("user");
    const res = await api("PUT", `/api/superadmin/admins/${patient.id}`, { token: superadmin.token, body: { isActive: 0 } });
    assert.equal(res.status, 400);
    const [[row]] = await db.query("SELECT isActive FROM users WHERE id = ?", [patient.id]);
    assert.equal(row.isActive, 1, "حساب بیمار نباید غیرفعال شده باشد");
  });

  test("حذف واقعیِ یک حساب ادمین معتبر کار می‌کند", async () => {
    const admin = await makeSession("admin");
    const res = await api("DELETE", `/api/superadmin/admins/${admin.id}`, { token: superadmin.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const [[row]] = await db.query("SELECT id FROM users WHERE id = ?", [admin.id]);
    assert.ok(!row);
  });

  test("سوپرادمین نمی‌تواند حساب خودش را حذف کند", async () => {
    const res = await api("DELETE", `/api/superadmin/admins/${superadmin.id}`, { token: superadmin.token });
    assert.equal(res.status, 400);
  });

  test("حذف ادمینِ ناموجود ۴۰۴", async () => {
    assert.equal((await api("DELETE", "/api/superadmin/admins/99999999", { token: superadmin.token })).status, 404);
  });
});

describe("تنظیمات سیستم", () => {
  test("مقدار نامعتبر رد می‌شود و ذخیره نمی‌شود", async () => {
    const before1 = await api("GET", "/api/superadmin/settings", { token: superadmin.token });
    const res = await api("PUT", "/api/superadmin/settings", { token: superadmin.token, body: { appointmentSlotCapacity: "not-a-number" } });
    assert.equal(res.status, 400);
    const after1 = await api("GET", "/api/superadmin/settings", { token: superadmin.token });
    assert.deepEqual(after1.body.settings.appointmentSlotCapacity, before1.body.settings.appointmentSlotCapacity);
  });

  test("مقدار معتبر ذخیره و بلافاصله قابل خواندن است", async () => {
    const res = await api("PUT", "/api/superadmin/settings", { token: superadmin.token, body: { appointmentSlotCapacity: "7" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const after1 = await api("GET", "/api/superadmin/settings", { token: superadmin.token });
    assert.equal(String(after1.body.settings.appointmentSlotCapacity), "7");
  });

  test("کلیدهای داخلیِ پشتیبان‌گیری به فرم نمی‌رسند و ذخیره‌ی کل فرم خطا نمی‌دهد (رگرسیون)", async () => {
    // پشتیبان‌گیری کلیدهای داخلی خودش را در همین جدول می‌نویسد؛ این‌ها نباید به فرم تنظیمات برسند
    await db.query("INSERT INTO settings (`key`, value) VALUES ('backupLastError', '') ON DUPLICATE KEY UPDATE value = ''");
    const got = await api("GET", "/api/superadmin/settings", { token: superadmin.token });
    assert.equal(got.status, 200);
    assert.equal("backupLastError" in got.body.settings, false);
    const { logoUrl, ...form } = got.body.settings;
    const res = await api("PUT", "/api/superadmin/settings", { token: superadmin.token, body: { ...form, appointmentSlotCapacity: "9" } });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    assert.equal(String(res.body.settings.appointmentSlotCapacity), "9");
  });

  test("ارسال کلید ناشناخته همچنان رد می‌شود", async () => {
    const res = await api("PUT", "/api/superadmin/settings", { token: superadmin.token, body: { notARealSetting: "x" } });
    assert.equal(res.status, 400);
  });
});

describe("مدیریت نشست‌ها", () => {
  test("نشست کاربر دیگر خاتمه می‌یابد و توکن او فوراً بی‌اثر می‌شود", async () => {
    const u = await makeSession("user");
    const [[row]] = await db.query(
      "SELECT id FROM user_sessions WHERE tokenId = ?",
      [jwt.decode(u.token).jti]
    );
    assert.ok(row, "نشست باید در دیتابیس ثبت شده باشد");
    const res = await api("DELETE", `/api/superadmin/sessions/${row.id}`, { token: superadmin.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const check = await api("GET", "/api/auth/me", { token: u.token });
    assert.equal(check.status, 401);
  });

  test("سوپرادمین نمی‌تواند نشست جاری خودش را از این مسیر خاتمه دهد", async () => {
    const payload = jwt.verify(superadmin.token, JWT_SECRET);
    const [[row]] = await db.query("SELECT id FROM user_sessions WHERE tokenId = ?", [payload.jti]);
    if (row) {
      const res = await api("DELETE", `/api/superadmin/sessions/${row.id}`, { token: superadmin.token });
      assert.equal(res.status, 400);
    }
  });

  test("نشست ناموجود ۴۰۴", async () => {
    assert.equal((await api("DELETE", "/api/superadmin/sessions/99999999", { token: superadmin.token })).status, 404);
  });
});

describe("خروجی CSV لاگ فعالیت‌ها: ضد تزریق فرمول", () => {
  test("نام کاربر یا User-Agent شبیه فرمول در CSV با ' خنثی می‌شود", async () => {
    const sa = await makeSession("superadmin");
    const marker = `CSVTEST${Date.now()}`;
    await db.query(
      "INSERT INTO activity_logs (userId, userName, role, action, details, ipAddress, userAgent) VALUES (?, ?, 'user', ?, ?, '1.2.3.4', ?)",
      [sa.id, `=HYPERLINK("http://evil/${marker}","click")`, marker, `+cmd|' /C calc'!A0 ${marker}`, "@SUM(1+1)*cmd"]
    );
    const res = await api("GET", `/api/superadmin/activity-logs/export?search=${marker}`, { token: sa.token });
    assert.equal(res.status, 200);
    const csv = res.raw.toString("utf8");
    assert.ok(csv.includes(marker), "ردیف تستی باید در خروجی باشد");
    assert.ok(csv.includes(`"'=HYPERLINK(`), "نام کاربر باید با ' خنثی شده باشد");
    assert.ok(csv.includes(`"'+cmd|`), "جزئیات باید با ' خنثی شده باشد");
    assert.ok(csv.includes(`"'@SUM(`), "User-Agent باید با ' خنثی شده باشد");
    // هیچ سلولی نباید مستقیماً با کاراکتر فرمول‌ساز شروع شود
    const cells = csv.split(/\r?\n/).filter((l) => l.includes(marker)).join(",").split(/","/);
    for (const c of cells) assert.doesNotMatch(c.replace(/^"/, ""), /^[=+\-@]/, `سلول خطرناک: ${c}`);
  });
});

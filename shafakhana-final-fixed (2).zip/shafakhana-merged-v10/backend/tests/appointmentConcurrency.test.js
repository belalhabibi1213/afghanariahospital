import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";

import db from "../db.js";
import { createAppointment, countActiveAppointmentsForSlot } from "../models/Appointment.js";
import { findOrCreatePatient } from "../models/Patient.js";

after(closePool);

let doctorId;
const patientIds = [];
const REQUESTS = 15;

before(async () => {
  await db.query("INSERT INTO departments (name) VALUES ('تست هم‌زمانی')").catch(() => {});
  const [doc] = await db.query(
    "INSERT INTO doctors (doctorCode, fullName, department) VALUES (?, 'داکتر هم‌زمانی', 'تست هم‌زمانی')",
    [`CONC-${Date.now()}`]
  );
  doctorId = doc.insertId;
  for (let i = 0; i < REQUESTS; i += 1) {
    const p = await findOrCreatePatient({ fullName: `بیمار هم‌زمان ${i}`, phone: `07022${String(i).padStart(5, "0")}` });
    patientIds.push(p.id);
  }
});

describe("رزرو هم‌زمان (Deadlock نباید به کاربر خطای ۵۰۰ بدهد)", () => {
  // این تست را قبلاً ER_LOCK_DEADLOCK به‌طور تصادفی رد می‌کرد؛ حالا باید همیشه یک نتیجه‌ی قطعی بدهد
  for (let round = 1; round <= 3; round += 1) {
    test(`دور ${round}: ${REQUESTS} درخواست هم‌زمان برای ظرفیت ۵ → دقیقاً ۵ موفق، بقیه SLOT_FULL، هیچ خطایی`, async () => {
      const date = `2027-02-${String(10 + round).padStart(2, "0")}`;
      const time = "10:00:00";
      const capacity = 5;

      const settled = await Promise.allSettled(
        patientIds.map((patientId) =>
          createAppointment({ patientId, doctorId, department: "تست هم‌زمانی", appointmentDate: date, appointmentTime: time, capacity })
        )
      );

      const rejected = settled.filter((r) => r.status === "rejected");
      assert.equal(rejected.length, 0, `هیچ درخواستی نباید با خطا تمام شود: ${rejected.map((r) => r.reason?.code).join(",")}`);

      const values = settled.map((r) => r.value);
      assert.equal(values.filter((v) => v.id).length, capacity, "دقیقاً به اندازه‌ی ظرفیت باید رزرو موفق باشد");
      assert.equal(values.filter((v) => v.error === "SLOT_FULL").length, REQUESTS - capacity);

      const count = await countActiveAppointmentsForSlot({ doctorId, appointmentDate: date, appointmentTime: time });
      assert.equal(count, capacity, "ظرفیت هرگز نباید بیش از حد پر شود");
    });
  }
});

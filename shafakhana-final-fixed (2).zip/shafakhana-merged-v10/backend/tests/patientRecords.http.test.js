import { test, describe, after, before } from "node:test";
import assert from "node:assert/strict";
import { closePool } from "./testEnv.js";
import { startServer, stopServer, api, makeSession, createTestDoctor, createTestPatient } from "./testApp.js";
import db from "../db.js";
import { createPrescription } from "../models/Prescription.js";

before(startServer);
after(async () => {
  await stopServer();
  await closePool();
});

// پنل بیمار «نسخه و سوابق طبی»: فقط‌خواندنی و فقط داده‌های خودِ بیمار (جلوگیری از IDOR)
describe("پنل بیمار — مالکیت نسخه‌ها و فقط‌خواندنی بودن", () => {
  let a; let b; let doctor; let rxA; let rxA2; let rxB; let groupId;

  before(async () => {
    a = await makeSession("user");
    b = await makeSession("user");
    const patientA = await createTestPatient(a.id, "بیمار الف");
    const patientB = await createTestPatient(b.id, "بیمار ب");
    doctor = await createTestDoctor();
    groupId = `grp-${Date.now()}`;
    rxA = await createPrescription({
      patientId: patientA, doctorId: doctor.id, diagnosis: "عفونت", medicationName: "آموکسی‌سیلین",
      dosage: "500mg", quantity: "21 عدد", frequency: "هر ۸ ساعت", duration: "۷ روز", medicineNotes: "بعد از غذا",
      instructions: "آب فراوان", notes: "پیگیری", groupId,
    });
    rxA2 = await createPrescription({
      patientId: patientA, doctorId: doctor.id, diagnosis: "عفونت", medicationName: "استامینوفن",
      dosage: "500mg", quantity: "10 عدد", duration: "۳ روز", groupId,
    });
    rxB = await createPrescription({
      patientId: patientB, doctorId: doctor.id, diagnosis: "سرماخوردگی", medicationName: "ویتامین C", groupId: `grp-b-${Date.now()}`,
    });
  });

  test("بدون توکن ۴۰۱", async () => {
    assert.equal((await api("GET", "/api/users/prescription-list")).status, 401);
    assert.equal((await api("GET", `/api/users/prescriptions/${rxA.id}/detail`)).status, 401);
  });

  test("فهرست: یک ردیف برای هر نسخه با تعداد دارو، و فقط نسخه‌های خودِ بیمار", async () => {
    const res = await api("GET", "/api/users/prescription-list", { token: a.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const mine = res.body.prescriptions.find((p) => p.id === rxA.id);
    assert.ok(mine);
    assert.equal(mine.itemCount, 2);
    assert.equal(mine.status, "active");
    assert.equal(mine.doctorName, doctor.fullName ?? mine.doctorName);
    assert.ok(!res.body.prescriptions.some((p) => p.id === rxB.id));
    // شناسه‌های داخلی بیمار/داکتر به کلاینت نمی‌رسد
    assert.equal(mine.patientId, undefined);
    assert.equal(mine.doctorId, undefined);
    assert.equal(mine.patientName, undefined);
  });

  test("دست‌کاری query (patientId / patientUserId / doctorId) فهرست را به بیمار دیگر باز نمی‌کند", async () => {
    const [[pa]] = await db.query("SELECT id FROM patients WHERE userId = ?", [a.id]);
    const res = await api("GET", `/api/users/prescription-list?patientId=${pa.id}&patientUserId=${a.id}&doctorId=${doctor.id}`, { token: b.token });
    assert.equal(res.status, 200);
    assert.ok(!res.body.prescriptions.some((p) => p.id === rxA.id));
    assert.ok(res.body.prescriptions.every((p) => p.id !== rxA.id && p.id !== rxA2.id));
  });

  test("جزئیات: همه‌ی داروهای نسخه با دوز، تعداد، مدت، نحوه مصرف و توضیحات", async () => {
    const res = await api("GET", `/api/users/prescriptions/${rxA.id}/detail`, { token: a.token });
    assert.equal(res.status, 200, JSON.stringify(res.body));
    const rx = res.body.prescription;
    assert.equal(rx.medicines.length, 2);
    assert.equal(rx.diagnosis, "عفونت");
    assert.equal(rx.medicines[0].quantity, "21 عدد");
    assert.equal(rx.medicines[0].frequency, "هر ۸ ساعت");
    assert.equal(rx.medicines[0].medicineNotes, "بعد از غذا");
    assert.equal(rx.notes, "پیگیری");
    // دسترسی با شناسه‌ی داروی دوم همان نسخه هم همان نسخه را می‌دهد
    const res2 = await api("GET", `/api/users/prescriptions/${rxA2.id}/detail`, { token: a.token });
    assert.equal(res2.body.prescription.medicines.length, 2);
  });

  test("IDOR: بیمار دیگر با همان شناسه ۴۰۴ می‌گیرد، یکسان با نسخه‌ی ناموجود (نه ۴۰۳/۲۰۰)", async () => {
    const stolen = await api("GET", `/api/users/prescriptions/${rxA.id}/detail`, { token: b.token });
    const missing = await api("GET", "/api/users/prescriptions/987654321/detail", { token: b.token });
    assert.equal(stolen.status, 404);
    assert.equal(missing.status, 404);
    assert.deepEqual(stolen.body, missing.body);
    const pdf = await api("GET", `/api/users/prescriptions/${rxA.id}/pdf`, { token: b.token });
    assert.equal(pdf.status, 404);
  });

  test("نسخه‌های قبلی: نسخه‌ی تکمیل‌شده/لغوشده فقط در فیلتر past می‌آید", async () => {
    await db.query("UPDATE prescriptions SET status = 'completed' WHERE groupId = ?", [groupId]);
    const active = await api("GET", "/api/users/prescription-list?status=active", { token: a.token });
    const past = await api("GET", "/api/users/prescription-list?status=past", { token: a.token });
    assert.ok(!active.body.prescriptions.some((p) => p.id === rxA.id));
    const found = past.body.prescriptions.find((p) => p.id === rxA.id);
    assert.ok(found);
    assert.equal(found.status, "completed");
  });

  test("بیمار هیچ عملیات نوشتنی ندارد: ساخت، ویرایش، حذف نسخه و تغییر تشخیص ۴۰۳", async () => {
    const attempts = [
      ["POST", "/api/medical-records/prescriptions", { patientId: 1, medicationName: "x" }],
      ["PUT", `/api/medical-records/prescriptions/${rxA.id}`, { medicationName: "هک" }],
      ["DELETE", `/api/medical-records/prescriptions/${rxA.id}`, undefined],
      ["PUT", "/api/medical-records/diagnoses/1", { title: "x" }],
      ["POST", "/api/medical-records/diagnoses", { patientId: 1, title: "x" }],
      ["PUT", "/api/medical-records/allergies/1", { allergen: "x" }],
      ["PUT", "/api/medical-records/lab-results/1", { testName: "x" }],
      ["PUT", "/api/medical-records/radiology-reports/1", { examType: "x" }],
      ["PUT", "/api/medical-records/encounters/1", { symptoms: "x" }],
    ];
    for (const [method, path, body] of attempts) {
      const res = await api(method, path, { token: a.token, body });
      assert.equal(res.status, 403, `${method} ${path} → ${res.status}`);
    }
    // نسخه دست‌نخورده مانده است
    const [[row]] = await db.query("SELECT medicationName FROM prescriptions WHERE id = ?", [rxA.id]);
    assert.equal(row.medicationName, "آموکسی‌سیلین");
  });

  test("بیمار نمی‌تواند پرونده‌ی کامل بیمار دیگر را از مسیر داکتر بخواند", async () => {
    const [[pb]] = await db.query("SELECT id FROM patients WHERE userId = ?", [b.id]);
    const res = await api("GET", `/api/medical-records/patient/${pb.id}`, { token: a.token });
    assert.equal(res.status, 403);
  });
});

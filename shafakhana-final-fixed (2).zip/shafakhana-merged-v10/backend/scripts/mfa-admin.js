// مدیریت MFA مستقیم روی دیتابیس (بدون نیاز به ورود). اجرا از پوشه‌ی backend:
//   node scripts/mfa-admin.js status                      وضعیت MFA همه‌ی کاربران به‌تفکیک نقش
//   node scripts/mfa-admin.js reset  <ایمیل>              MFA یک کاربر را پاک می‌کند (گوشی/کد بازیابی گم شده)
//   node scripts/mfa-admin.js reset-role <نقش|all>        MFA همه‌ی کاربران یک نقش را پاک می‌کند
//                                                          نقش‌ها: superadmin | admin | doctor | all
// خاموش/روشن کردن کلی بدون پاک‌شدن چیزی: در .env مقدار MFA_ENABLED=false (یا true) بگذارید و بک‌اند را ری‌استارت کنید.
import "../loadEnv.js";
import db from "../db.js";
import { MFA_ENABLED, MFA_REQUIRED_ROLES } from "../utils/env.js";

const RESET_SQL = `UPDATE users SET mfaEnabled = 0, mfaSecretEnc = NULL, mfaPendingSecretEnc = NULL,
                          mfaRecoveryHashes = NULL, mfaLastStep = NULL`;
const [cmd, arg] = process.argv.slice(2);

async function main() {
  if (cmd === "status") {
    console.log(`MFA_ENABLED=${MFA_ENABLED}  |  نقش‌های اجباری: ${[...MFA_REQUIRED_ROLES].join(", ") || "هیچ"}`);
    const [rows] = await db.query(
      "SELECT role, COUNT(*) AS total, SUM(mfaEnabled = 1) AS withMfa FROM users GROUP BY role ORDER BY role"
    );
    console.table(rows.map((r) => ({ role: r.role, کاربران: Number(r.total), "با MFA": Number(r.withMfa) })));
  } else if (cmd === "reset" && arg) {
    const [r] = await db.query(`${RESET_SQL} WHERE email = ?`, [arg.toLowerCase()]);
    console.log(r.affectedRows ? `✅ MFA کاربر ${arg} پاک شد.` : `❌ کاربری با ایمیل ${arg} پیدا نشد.`);
  } else if (cmd === "reset-role" && arg) {
    const [r] = arg === "all" ? await db.query(RESET_SQL) : await db.query(`${RESET_SQL} WHERE role = ?`, [arg]);
    console.log(`✅ MFA ${r.affectedRows} کاربر پاک شد (${arg}).`);
  } else {
    console.log("دستور نامعتبر. نمونه‌ها:\n  node scripts/mfa-admin.js status\n  node scripts/mfa-admin.js reset user@example.com\n  node scripts/mfa-admin.js reset-role doctor");
    process.exitCode = 1;
  }
  console.log("ℹ️  بک‌اند را ری‌استارت کنید تا کش احرازهویت تازه شود.");
}

main().catch((e) => { console.error("خطا:", e.message); process.exitCode = 1; }).finally(() => process.exit());

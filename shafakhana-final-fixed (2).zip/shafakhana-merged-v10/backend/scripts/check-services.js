// بررسی سریع ایمیل (SMTP) و هوش مصنوعی — اجرا:  node scripts/check-services.js [ایمیل-گیرنده-برای-تست]
// خطای واقعی هر سرویس را با توضیح فارسی چاپ می‌کند.
import "../loadEnv.js";
import nodemailer from "nodemailer";
import { isAiConfigured, pingAi } from "../utils/aiProviders.js";

const to = process.argv[2];

console.log("— بررسی هوش مصنوعی —");
if (!isAiConfigured()) {
  console.log("❌ AI_API_KEY در .env تنظیم نشده است.");
} else {
  try {
    const reply = await pingAi();
    console.log(`✅ هوش مصنوعی پاسخ داد: «${reply.slice(0, 60)}»`);
  } catch (err) {
    console.log(`❌ ناموفق (status=${err.status || "-"}): ${err.message}`);
    if ([400, 401, 403].includes(err.status)) console.log("   کلید نامعتبر/محدودشده است؛ یک کلید تازه از https://aistudio.google.com/apikey بسازید.");
    if (err.status === 404) console.log("   مدل پیدا نشد؛ AI_MODEL را در .env خالی بگذارید یا gemini-2.5-flash بگذارید.");
    if (err.status === 429) console.log("   سهمیه‌ی رایگان تمام شده؛ چند دقیقه بعد دوباره امتحان کنید.");
    if (!err.status) console.log("   اینترنت/فایروال سرور به generativelanguage.googleapis.com اجازه نمی‌دهد؟");
  }
}

console.log("\n— بررسی ایمیل (SMTP) —");
const { SMTP_HOST, SMTP_PORT, SMTP_SECURE, SMTP_USER, SMTP_FROM } = process.env;
const pass = process.env.SMTP_PASS?.replace(/\s+/g, "");
if (!SMTP_HOST || !SMTP_USER || !pass) {
  console.log("❌ SMTP_HOST / SMTP_USER / SMTP_PASS کامل نیست.");
} else {
  const transporter = nodemailer.createTransport({ host: SMTP_HOST, port: Number(SMTP_PORT || 587), secure: SMTP_SECURE === "true", auth: { user: SMTP_USER, pass } });
  try {
    await transporter.verify();
    console.log(`✅ ورود به ${SMTP_HOST} با ${SMTP_USER} موفق بود.`);
    if (to) {
      await transporter.sendMail({ from: SMTP_FROM || SMTP_USER, to, subject: "تست ایمیل شفاخانه", text: "اگر این پیام را می‌بینید، ارسال ایمیل درست کار می‌کند. کد تست: 123456" });
      console.log(`✅ ایمیل تست به ${to} فرستاده شد (پوشه‌ی Spam را هم ببینید).`);
    } else {
      console.log("   (برای ارسال ایمیل تست، آدرس را بدهید: node scripts/check-services.js you@gmail.com)");
    }
  } catch (err) {
    console.log(`❌ ناموفق: ${err.code || ""} ${err.message}`);
    if (err.code === "EAUTH") console.log("   رمز ۱۶ رقمی (App Password) اشتباه است یا برای همین حساب ساخته نشده؛ تأیید دو مرحله‌ای را هم چک کنید.");
    if (err.code === "ESOCKET" || err.code === "ETIMEDOUT" || err.code === "ECONNECTION") console.log("   اینترنت/فایروال پورت 587 را بسته است.");
  }
}
process.exit(0);

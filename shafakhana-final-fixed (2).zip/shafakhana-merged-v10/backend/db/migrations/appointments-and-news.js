export async function migrateAppointmentsAndNews(pool, DB_NAME) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS appointments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NOT NULL,
      department VARCHAR(100) NOT NULL,
      appointmentDate DATE NOT NULL,
      appointmentTime TIME NOT NULL,
      notes TEXT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ستون reminderSentAt: زمان ارسال یادآوری نوبت به بیمار (NULL = هنوز یادآوری ارسال نشده).
  // از ارسال دوباره‌ی یادآوری برای یک نوبت جلوگیری می‌کند.
  const [reminderCol] = await pool.query("SHOW COLUMNS FROM appointments LIKE 'reminderSentAt'");
  if (reminderCol.length === 0) {
    await pool.query("ALTER TABLE appointments ADD COLUMN reminderSentAt TIMESTAMP NULL DEFAULT NULL");
  }

  // ارتقای دیتابیس‌های قدیمی: قبلاً یک محدودیت یکتای سطح دیتابیس (uq_appointments_active_slot)
  // اجازه‌ی فقط «یک» نوبت فعال به‌ازای هر (داکتر، تاریخ، ساعت) را می‌داد. حالا که ظرفیت هر
  // ساعت قابل‌تنظیم است (چند بیمار می‌توانند همان ساعت را رزرو کنند — تنظیمات سیستم →
  // ظرفیت هر نوبت)، این محدودیت باید حذف شود؛ کنترل «بیشتر از ظرفیت رزرو نشود» اکنون در
  // سطح تراکنش با قفل ردیف (SELECT ... FOR UPDATE) در models/Appointment.js انجام می‌شود، نه
  // با یک محدودیت یکتای ثابت روی ۱ نوبت. نصب‌های تازه هرگز این ستون/محدودیت را نمی‌سازند.
  const [oldUniqueKeyRows] = await pool.query(
    `SELECT DISTINCT INDEX_NAME FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'appointments' AND INDEX_NAME = 'uq_appointments_active_slot'`,
    [DB_NAME]
  );
  if (oldUniqueKeyRows.length > 0) {
    await pool.query("ALTER TABLE appointments DROP INDEX uq_appointments_active_slot");
  }
  const [oldActiveSlotKeyColRows] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'appointments' AND COLUMN_NAME = 'activeSlotKey'`,
    [DB_NAME]
  );
  if (oldActiveSlotKeyColRows.length > 0) {
    await pool.query("ALTER TABLE appointments DROP COLUMN activeSlotKey");
  }

  // سابقه‌ی کامل تغییرات وضعیت هر نوبت (برای تاریخچه/آدیت — الزام شماره ۸)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS appointment_status_history (
      id INT AUTO_INCREMENT PRIMARY KEY,
      appointmentId INT NOT NULL,
      oldStatus VARCHAR(20) NULL,
      newStatus VARCHAR(20) NOT NULL,
      changedByUserId INT NULL,
      changedByRole VARCHAR(20) NULL,
      note VARCHAR(255) NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (appointmentId) REFERENCES appointments(id) ON DELETE CASCADE,
      FOREIGN KEY (changedByUserId) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS news (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      excerpt TEXT NOT NULL,
      content TEXT NULL,
      tag VARCHAR(100) NOT NULL,
      author VARCHAR(150) NULL,
      status ENUM('draft','published') NOT NULL DEFAULT 'published',
      imageUrl VARCHAR(500) NULL,
      publishedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب دیتابیس‌های قبلی: افزودن ستون‌های ماژول «مدیریت اخبار» ادمین
  // (محتوای کامل، نویسنده، وضعیت انتشار/پیش‌نویس، تاریخ آخرین ویرایش) بدون از دست رفتن اخبار موجود.
  // اخبار موجود همگی status = 'published' می‌گیرند تا هیچ خبری از صفحه عمومی ناپدید نشود.
  const [newsColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'news'`,
    [DB_NAME]
  );
  const existingNewsColumns = new Set(newsColumns.map((c) => c.COLUMN_NAME));
  // ترجمه‌ی انگلیسی عنوان/خلاصه/متن خبر (اختیاری) — در صورت خالی بودن، سایت متن دری را نشان می‌دهد
  if (!existingNewsColumns.has("titleEn")) {
    await pool.query("ALTER TABLE news ADD COLUMN titleEn VARCHAR(255) NULL");
  }
  if (!existingNewsColumns.has("excerptEn")) {
    await pool.query("ALTER TABLE news ADD COLUMN excerptEn TEXT NULL");
  }
  if (!existingNewsColumns.has("contentEn")) {
    await pool.query("ALTER TABLE news ADD COLUMN contentEn TEXT NULL");
  }
  if (!existingNewsColumns.has("content")) {
    await pool.query("ALTER TABLE news ADD COLUMN content TEXT NULL");
  }
  if (!existingNewsColumns.has("author")) {
    await pool.query("ALTER TABLE news ADD COLUMN author VARCHAR(150) NULL");
  }
  if (!existingNewsColumns.has("status")) {
    await pool.query("ALTER TABLE news ADD COLUMN status ENUM('draft','published') NOT NULL DEFAULT 'published'");
  }
  if (!existingNewsColumns.has("updatedAt")) {
    await pool.query(
      "ALTER TABLE news ADD COLUMN updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    );
  }

  // ارتقای غیرمخرب دیتابیس‌های قبلی: ستون‌های ماژول‌های جدید اخبار
  // (زمان‌بندی انتشار، سنجاق‌کردن خبر مهم، برچسب‌ها، شمارش بازدید برای آمار داشبورد)
  if (!existingNewsColumns.has("scheduledAt")) {
    await pool.query("ALTER TABLE news ADD COLUMN scheduledAt DATETIME NULL");
  }
  if (!existingNewsColumns.has("isPinned")) {
    await pool.query("ALTER TABLE news ADD COLUMN isPinned TINYINT(1) NOT NULL DEFAULT 0");
  }
  if (!existingNewsColumns.has("tags")) {
    await pool.query("ALTER TABLE news ADD COLUMN tags VARCHAR(500) NULL");
  }
  if (!existingNewsColumns.has("views")) {
    await pool.query("ALTER TABLE news ADD COLUMN views INT NOT NULL DEFAULT 0");
  }

  // ارتقای غیرمخرب: فیلدهای SEO اختصاصی هر خبر (عنوان/توضیح متا برای موتورهای جستجو
  // و اشتراک‌گذاری در شبکه‌های اجتماعی). اگر خالی باشند، فرانت‌اند از title/excerpt
  // خودِ خبر به‌عنوان جایگزین پیش‌فرض استفاده می‌کند.
  if (!existingNewsColumns.has("metaTitle")) {
    await pool.query("ALTER TABLE news ADD COLUMN metaTitle VARCHAR(255) NULL");
  }
  if (!existingNewsColumns.has("metaDescription")) {
    await pool.query("ALTER TABLE news ADD COLUMN metaDescription VARCHAR(500) NULL");
  }

  // ستون status از قبل ENUM('draft','published') است؛ برای «زمان‌بندی انتشار» باید مقدار
  // 'scheduled' هم به همان ENUM اضافه شود. تغییر ENUM با ADD یک مقدار جدید هیچ داده‌ی
  // موجودی را از دست نمی‌دهد (مقادیر فعلی 'draft'/'published' دست‌نخورده باقی می‌مانند).
  const [statusColumnInfo] = await pool.query(
    `SELECT COLUMN_TYPE FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'news' AND COLUMN_NAME = 'status'`,
    [DB_NAME]
  );
  const statusColumnType = statusColumnInfo[0]?.COLUMN_TYPE || "";
  if (statusColumnType && !statusColumnType.includes("'scheduled'")) {
    await pool.query(
      "ALTER TABLE news MODIFY COLUMN status ENUM('draft','published','scheduled') NOT NULL DEFAULT 'draft'"
    );
  }

  // ارتقای غیرمخرب: ستون type روی news («خبر» یا «مقاله») — جستجوی سراسری هدر این دو را
  // به‌عنوان دو دسته‌ی جدا نمایش می‌دهد. همه‌ی خبرهای موجود به‌صورت پیش‌فرض 'news' می‌مانند
  // (هیچ رکورد قدیمی تغییر معنایی نمی‌کند)؛ مقالات صحی جدید با type='article' درج می‌شوند.
  if (!existingNewsColumns.has("type")) {
    await pool.query(
      "ALTER TABLE news ADD COLUMN type ENUM('news','article') NOT NULL DEFAULT 'news' AFTER tag"
    );
    console.log("📚 ستون type (خبر/مقاله) به جدول news اضافه شد");
  }

  // ---------- گالری تصاویر خبر (News Gallery) ----------
  // هر خبر می‌تواند چند تصویر گالری (علاوه بر عکس شاخص) داشته باشد؛ رابطه یک‌به‌چند با
  // حذف آبشاری (وقتی خبر حذف می‌شود، ردیف‌های گالری آن هم خودکار حذف می‌شوند).
  await pool.query(`
    CREATE TABLE IF NOT EXISTS news_gallery (
      id INT AUTO_INCREMENT PRIMARY KEY,
      newsId INT NOT NULL,
      imageUrl VARCHAR(500) NOT NULL,
      sortOrder INT NOT NULL DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (newsId) REFERENCES news(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ---------- لایک‌های خبر (News Likes) ----------
  // هر کاربر واردشده فقط می‌تواند یک‌بار یک خبر را لایک کند (ایندکس یکتای newsId+userId).
  // حذف خبر یا حذف حساب کاربری به‌صورت آبشاری لایک‌های مرتبط را هم پاک می‌کند.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS news_likes (
      id INT AUTO_INCREMENT PRIMARY KEY,
      newsId INT NOT NULL,
      userId INT NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_news_likes_news_user (newsId, userId),
      FOREIGN KEY (newsId) REFERENCES news(id) ON DELETE CASCADE,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ---------- نظرات خبر (News Comments) ----------
  // نظرات کاربران واردشده با وضعیت پیش‌فرض 'pending' ثبت می‌شوند و فقط پس از تایید ادمین
  // ('approved') در صفحه عمومی خبر نمایش داده می‌شوند؛ ادمین می‌تواند رد ('rejected') یا حذف کند.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS news_comments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      newsId INT NOT NULL,
      userId INT NOT NULL,
      content TEXT NOT NULL,
      status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (newsId) REFERENCES news(id) ON DELETE CASCADE,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب «مرکز مدیریت نظرات»: امتیاز اختیاری (۱ تا ۵) که کاربر هنگام ثبت نظر می‌دهد، پاسخ
  // ادمین، یادداشت داخلی تیم مدیریت، و حذف نرم (deletedAt). نظرهای قبلی بدون تغییر می‌مانند
  // (rating/reply/note خالی، deletedAt = NULL).
  const [commentColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'news_comments'`,
    [DB_NAME]
  );
  const existingCommentColumns = new Set(commentColumns.map((c) => c.COLUMN_NAME));
  const commentColumnDefs = [
    ["rating", "TINYINT NULL"],
    ["adminReply", "TEXT NULL"],
    ["adminReplyAt", "TIMESTAMP NULL DEFAULT NULL"],
    ["internalNote", "TEXT NULL"],
    ["deletedAt", "TIMESTAMP NULL DEFAULT NULL"],
  ];
  for (const [name, def] of commentColumnDefs) {
    if (!existingCommentColumns.has(name)) {
      await pool.query(`ALTER TABLE news_comments ADD COLUMN ${name} ${def}`);
      console.log(`💬 ستون ${name} به جدول news_comments اضافه شد`);
    }
  }

  // ---------- بازدیدهای خبر (News Views) — شمارنده‌ی بازدید بدون تکرار ----------
  // models/NewsView.js از این جدول برای جلوگیری از شمارش بازدید تکراری همان بازدیدکننده
  // (کاربر واردشده یا مهمان) در یک بازه‌ی زمانی کوتاه استفاده می‌کند. viewerKey برای کاربر
  // واردشده = "user:<id>"، برای مهمان = هش IP+User-Agent (بدون ذخیره‌ی IP خام).
  await pool.query(`
    CREATE TABLE IF NOT EXISTS news_views (
      id INT AUTO_INCREMENT PRIMARY KEY,
      newsId INT NOT NULL,
      viewerKey VARCHAR(64) NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (newsId) REFERENCES news(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);
}

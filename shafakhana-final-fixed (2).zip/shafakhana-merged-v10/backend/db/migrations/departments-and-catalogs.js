import { ensureIndex } from "../helpers.js";

export async function migrateDepartmentsAndCatalogs(pool, DB_NAME) {
  // ---------- بخش‌ها (Department Management) ----------
  // ستون‌های پایه‌ی قبلی (name/description) حفظ شده‌اند؛ ستون‌های زیر برای پنل
  // «مدیریت بخش‌ها»ی ادمین (آیکون/رنگ‌بندی کارت، ترتیب نمایش، وضعیت، نمایش در
  // سایت و سئو) اضافه شده‌اند. جدول برای نصب‌های تازه با تمام ستون‌ها ساخته
  // می‌شود؛ برای دیتابیس‌های قدیمی، ارتقای غیرمخرب در ادامه انجام می‌شود.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS departments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL UNIQUE,
      description TEXT NULL,
      icon VARCHAR(255) NULL,
      coverImage VARCHAR(255) NULL,
      iconType ENUM('upload','lucide') NOT NULL DEFAULT 'lucide',
      iconColor VARCHAR(20) NULL,
      iconBackground VARCHAR(20) NULL,
      cardBackground VARCHAR(20) NULL,
      textColor VARCHAR(20) NULL,
      slug VARCHAR(150) NULL,
      displayOrder INT NOT NULL DEFAULT 0,
      status ENUM('active','inactive') NOT NULL DEFAULT 'active',
      showOnWebsite TINYINT(1) NOT NULL DEFAULT 1,
      seoTitle VARCHAR(200) NULL,
      seoDescription VARCHAR(300) NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_departments_slug (slug)
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب دیتابیس‌های قدیمی: افزودن ستون‌های جدید بدون پاک کردن بخش‌های
  // موجود؛ دقیقاً همان الگوی استفاده‌شده برای invoices.approvalStatus بالاتر.
  const [departmentColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'departments'`,
    [DB_NAME]
  );
  const existingDepartmentColumns = new Set(departmentColumns.map((c) => c.COLUMN_NAME));

  // ترجمه‌ی انگلیسی نام/توضیحات بخش (اختیاری) — سایت عمومی در زبان انگلیسی از آن‌ها استفاده
  // می‌کند و اگر خالی باشند به متن دری برمی‌گردد.
  if (!existingDepartmentColumns.has("nameEn")) {
    await pool.query("ALTER TABLE departments ADD COLUMN nameEn VARCHAR(100) NULL");
  }
  if (!existingDepartmentColumns.has("descriptionEn")) {
    await pool.query("ALTER TABLE departments ADD COLUMN descriptionEn TEXT NULL");
  }
  if (!existingDepartmentColumns.has("icon")) {
    await pool.query("ALTER TABLE departments ADD COLUMN icon VARCHAR(255) NULL");
  }
  // عکس کاور کارت بخش در سایت عمومی («بخش‌های تخصصی ما») — اختیاری؛ اگر خالی باشد سایت از
  // عکس پیش‌فرض تخصص یا طرح گرادیانی استفاده می‌کند.
  if (!existingDepartmentColumns.has("coverImage")) {
    await pool.query("ALTER TABLE departments ADD COLUMN coverImage VARCHAR(255) NULL");
  }
  if (!existingDepartmentColumns.has("iconType")) {
    await pool.query("ALTER TABLE departments ADD COLUMN iconType ENUM('upload','lucide') NOT NULL DEFAULT 'lucide'");
  }
  if (!existingDepartmentColumns.has("iconColor")) {
    await pool.query("ALTER TABLE departments ADD COLUMN iconColor VARCHAR(20) NULL");
  }
  if (!existingDepartmentColumns.has("iconBackground")) {
    await pool.query("ALTER TABLE departments ADD COLUMN iconBackground VARCHAR(20) NULL");
  }
  if (!existingDepartmentColumns.has("cardBackground")) {
    await pool.query("ALTER TABLE departments ADD COLUMN cardBackground VARCHAR(20) NULL");
  }
  if (!existingDepartmentColumns.has("textColor")) {
    await pool.query("ALTER TABLE departments ADD COLUMN textColor VARCHAR(20) NULL");
  }
  if (!existingDepartmentColumns.has("slug")) {
    await pool.query("ALTER TABLE departments ADD COLUMN slug VARCHAR(150) NULL");
  }
  if (!existingDepartmentColumns.has("displayOrder")) {
    await pool.query("ALTER TABLE departments ADD COLUMN displayOrder INT NOT NULL DEFAULT 0");
  }
  if (!existingDepartmentColumns.has("status")) {
    await pool.query("ALTER TABLE departments ADD COLUMN status ENUM('active','inactive') NOT NULL DEFAULT 'active'");
  }
  if (!existingDepartmentColumns.has("showOnWebsite")) {
    await pool.query("ALTER TABLE departments ADD COLUMN showOnWebsite TINYINT(1) NOT NULL DEFAULT 1");
  }
  if (!existingDepartmentColumns.has("seoTitle")) {
    await pool.query("ALTER TABLE departments ADD COLUMN seoTitle VARCHAR(200) NULL");
  }
  if (!existingDepartmentColumns.has("seoDescription")) {
    await pool.query("ALTER TABLE departments ADD COLUMN seoDescription VARCHAR(300) NULL");
  }
  if (!existingDepartmentColumns.has("updatedAt")) {
    await pool.query("ALTER TABLE departments ADD COLUMN updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
  }

  // بخش‌های قدیمی‌ای که از قبل در دیتابیس بودند slug ندارند؛ برای این‌که بلافاصله
  // قابل استفاده باشند (مثلاً لینک‌دهی در سایت)، از روی name یک slug یکتا ساخته
  // می‌شود. این فقط یک‌بار و فقط برای ردیف‌های بدون slug اجرا می‌شود.
  const [departmentsMissingSlug] = await pool.query(
    "SELECT id, name FROM departments WHERE slug IS NULL OR slug = ''"
  );
  for (const dept of departmentsMissingSlug) {
    const base = String(dept.name)
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9\u0600-\u06ff]+/g, "-")
      .replace(/^-+|-+$/g, "") || "department";
    let candidate = base;
    let suffix = 1;
    // اطمینان از یکتا بودن slug در برابر بخش‌های دیگر (چه از قبل دارای slug، چه در همین حلقه ساخته‌شده)
    while (true) {
      const [clash] = await pool.query(
        "SELECT id FROM departments WHERE slug = ? AND id != ?",
        [candidate, dept.id]
      );
      if (clash.length === 0) break;
      suffix += 1;
      candidate = `${base}-${suffix}`;
    }
    await pool.query("UPDATE departments SET slug = ? WHERE id = ?", [candidate, dept.id]);
  }

  // ایندکس یکتا روی slug: برای نصب‌های تازه از طریق UNIQUE KEY داخل CREATE TABLE
  // اعمال شده؛ برای دیتابیس‌های قدیمی (که ستون slug تازه با ALTER اضافه و پر شد)
  // اینجا اضافه می‌شود تا از تکراری شدن slug جلوگیری شود.
  const [slugUniqueIndex] = await pool.query(
    `SELECT COUNT(*) AS count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'departments' AND INDEX_NAME = 'uq_departments_slug'`,
    [DB_NAME]
  );
  if (slugUniqueIndex[0].count === 0) {
    await pool.query("ALTER TABLE departments ADD UNIQUE KEY uq_departments_slug (slug)");
  }

  // ایندکس‌های جستجو/مرتب‌سازی برای پنل مدیریت بخش‌ها و صفحه‌ی عمومی «خدمات ما»
  await ensureIndex(pool, DB_NAME, "departments", "idx_departments_displayOrder", "displayOrder");
  await ensureIndex(pool, DB_NAME, "departments", "idx_departments_status", "status");

  // ---------- جدول‌های مرجع «جستجوی سراسری» هدر (خدمات/تخصص‌ها/ادویه) ----------
  // این سه جدول فقط خواندنی و کاتالوگ‌محورند (مثل departments)؛ فعلاً هیچ پنل مدیریتی
  // برای CRUD روی آن‌ها اضافه نشده — فقط GET /api/search از آن‌ها می‌خواند.

  await pool.query(`
    CREATE TABLE IF NOT EXISTS services (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      description TEXT NULL,
      department VARCHAR(100) NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS specialties (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL UNIQUE,
      description TEXT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS medicines (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      genericName VARCHAR(150) NULL,
      description TEXT NULL,
      requiresPrescription TINYINT(1) NOT NULL DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS schedules (
      id INT AUTO_INCREMENT PRIMARY KEY,
      doctorId INT NOT NULL,
      dayOfWeek VARCHAR(20) NOT NULL,
      startTime TIME NOT NULL,
      endTime TIME NOT NULL,
      breakStart TIME NULL,
      breakEnd TIME NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب دیتابیس‌های قدیمی: افزودن ستون‌های breakStart/breakEnd روی
  // schedules (تعریف زمان استراحت داکتر در برنامه کاری — الزام شماره ۳)
  const [scheduleColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'schedules'`,
    [DB_NAME]
  );
  const existingScheduleColumns = new Set(scheduleColumns.map((c) => c.COLUMN_NAME));
  if (!existingScheduleColumns.has("breakStart")) {
    await pool.query("ALTER TABLE schedules ADD COLUMN breakStart TIME NULL");
  }
  if (!existingScheduleColumns.has("breakEnd")) {
    await pool.query("ALTER TABLE schedules ADD COLUMN breakEnd TIME NULL");
  }
}

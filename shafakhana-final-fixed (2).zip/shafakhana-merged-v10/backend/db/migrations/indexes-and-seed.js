import { ensureIndex, ensureFullTextIndex } from "../helpers.js";

const DOCTOR_SEED = [
  ["DR-1001", "داکتر عزیزالرحمن امیری", "قلب و عروق", 15, "men", 32, 4.9, "شنبه، یکشنبه، سه‌شنبه", null],
  ["DR-1002", "داکتره پرسیلا طاهری", "اطفال", 10, "women", 68, 4.8, "یکشنبه تا پنجشنبه", null],
  ["DR-1003", "داکتره مریم صادقی", "زنان و زایمان", 12, "women", 44, 4.7, "شنبه تا سه‌شنبه", null],
  ["DR-1004", "داکتر محسن فروتن", "ارتوپیدی", 9, "men", 22, 4.6, "دوشنبه، چهارشنبه، پنجشنبه", null],
  ["DR-1005", "داکتره فرزانه کریمی", "دندان", 7, "women", 21, 4.8, "همه روزه", null],
  ["DR-1006", "داکتر توریالی سبحانی", "داخله", 18, "men", 54, 4.9, "شنبه تا چهارشنبه", null],
  ["DR-1007", "داکتره لیلا احمدی", "قلب و عروق", 11, "women", 60, 4.7, "یکشنبه، سه‌شنبه، پنجشنبه", null],
  ["DR-1008", "داکتر بشیر نظری", "اطفال", 8, "men", 63, 4.6, "شنبه، دوشنبه، چهارشنبه", null],
];

const NEWS_SEED = [
  ["۵ نشانه که باید به داکتر قلب مراجعه کنید", "درد قفسه سینه همیشه جدی نیست، اما این نشانه‌ها را نباید نادیده گرفت...", "قلب و عروق", "https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800"],
  ["تغذیه سالم برای کودکان در فصل تابستان", "چند نکته ساده برای اینکه فرزندتان در گرمای تابستان سالم و پرانرژی بماند...", "اطفال", "https://images.pexels.com/photos/8460035/pexels-photo-8460035.jpeg?auto=compress&cs=tinysrgb&w=800"],
  ["چرا معاینه دوره‌ای چشم مهم است؟", "بسیاری از مشکلات چشمی در مراحل اول علامتی ندارند؛ معاینه منظم را جدی بگیرید...", "چشم", "https://images.pexels.com/photos/5452193/pexels-photo-5452193.jpeg?auto=compress&cs=tinysrgb&w=1200"],
  ["ورزش و سلامت مفاصل: از کجا شروع کنیم؟", "راهنمای ساده برای شروع فعالیت بدنی بدون آسیب به زانو و کمر...", "ارتوپیدی", "https://images.pexels.com/photos/12955896/pexels-photo-12955896.jpeg?auto=compress&cs=tinysrgb&w=800"],
  ["استرس و تاثیر آن بر مغز و اعصاب", "چگونه استرس روزمره را مدیریت کنیم تا به سلامت ذهنی ما آسیب نزند...", "اعصاب", "https://images.pexels.com/photos/5452190/pexels-photo-5452190.jpeg?auto=compress&cs=tinysrgb&w=1200"],
  ["مراقبت از دندان‌ها؛ عادت‌های روزانه ضروری", "چند عادت ساده که می‌تواند از پوسیدگی دندان جلوگیری کند...", "دندان", "https://images.pexels.com/photos/4269698/pexels-photo-4269698.jpeg?auto=compress&cs=tinysrgb&w=800"],
];

// ---------- داده‌های نمونه‌ی جدول‌های تازه (برای «جستجوی سراسری» هدر) ----------
// این چهار آرایه فقط یک‌بار (اگر جدول مربوطه خالی باشد) درج می‌شوند — دقیقاً مثل
// DOCTOR_SEED/NEWS_SEED بالا — تا دسته‌های خدمات/تخصص‌ها/ادویه/مقالات در جستجوی
// سراسری از همان ابتدا نتیجه‌ی واقعی داشته باشند، نه یک دسته‌ی همیشه خالی.

// خدمات شفاخانه (services)
const SERVICE_SEED = [
  ["معاینات عمومی و چکاپ", "چکاپ کامل و معاینه‌ی اولیه توسط داکتران عمومی، هر روز از ساعت ۸ صبح تا ۴ عصر.", "داخله"],
  ["تصویربرداری (سی‌تی‌اسکن و اشعه ایکس)", "خدمات رادیولوژی برای تشخیص دقیق‌تر بیماری‌ها.", null],
  ["آزمایشگاه تشخیص طبی", "انجام انواع آزمایش‌های خون، ادرار و میکروبیولوژی با نتیجه‌ی سریع.", null],
  ["جراحی‌های عمومی و تخصصی", "اتاق عمل مجهز برای جراحی‌های کوچک و بزرگ زیر نظر جراحان مجرب.", null],
  ["فزیوتراپی و توانبخشی", "برنامه‌های درمانی فردی برای بازتوانی پس از آسیب یا جراحی.", "ارتوپیدی"],
  ["نوبت‌دهی و مشاوره آنلاین", "رزرو نوبت با داکتر دلخواه از طریق سایت، بدون نیاز به حضور فیزیکی.", null],
];

// تخصص‌های بالینی (specialties) — فهرست مرجع تخصص‌ها، مستقل از بخش‌های اداری شفاخانه (departments)
const SPECIALTY_SEED = [
  ["قلب و عروق", "تشخیص و درمان بیماری‌های قلبی و فشار خون"],
  ["اطفال", "مراقبت صحی کودکان از تولد تا نوجوانی"],
  ["زنان و زایمان", "مراقبت پیش و پس از زایمان و سلامت باروری"],
  ["ارتوپیدی", "درمان آسیب‌های استخوان، مفصل و عضلات"],
  ["دندان", "خدمات دندان‌پزشکی عمومی و تخصصی"],
  ["داخله", "تشخیص و درمان بیماری‌های عمومی داخلی"],
  ["چشم", "معاینه و درمان بیماری‌های چشم"],
  ["اعصاب", "تشخیص و درمان بیماری‌های مغز و اعصاب"],
];

// ادویه (medicines) — فهرست مرجع ادویه‌های رایج، فقط برای نمایش در جستجو (بدون فروش/انبارداری)
const MEDICINE_SEED = [
  ["پاراستامول", "Paracetamol", "تسکین‌دهنده‌ی درد و تب خفیف تا متوسط", 0],
  ["آموکسی‌سیلین", "Amoxicillin", "آنتی‌بیوتیک برای درمان عفونت‌های باکتریایی", 1],
  ["ایبوپروفن", "Ibuprofen", "ضدالتهاب و مسکن درد", 0],
  ["متفورمین", "Metformin", "کنترل قند خون در دیابت نوع ۲", 1],
  ["اومپرازول", "Omeprazole", "کاهش اسید معده و درمان زخم گوارشی", 0],
  ["قطره ویتامین D اطفال", "Vitamin D3", "مکمل غذایی برای رشد استخوان کودکان", 0],
];

// مقالات صحی (از همان جدول news، با type='article' — نگاه کنید به ارتقای ستون type در initDb)
const ARTICLE_SEED = [
  ["۷ نکته برای مراقبت از سلامت قلب", "چند عادت ساده روزانه که خطر بیماری‌های قلبی را کاهش می‌دهد...", "قلب و عروق"],
  ["چگونه در فصل سرما از اطفال مراقبت کنیم", "راهنمای ساده برای پیشگیری از سرماخوردگی و آنفلوانزا در کودکان...", "اطفال"],
  ["اهمیت تغذیه‌ی متعادل در دوران بارداری", "چه غذاهایی برای مادر و جنین در دوران بارداری ضروری‌اند...", "زنان و زایمان"],
];

  // ---------- ایندکس‌های جستجو (برای سریع‌تر شدن جستجوی پیشرفته) ----------
  // این تابع فقط در صورتی که ایندکس از قبل وجود نداشته باشد آن را می‌سازد،
  // بنابراین اجرای دوباره initDb روی دیتابیس‌های قبلی بدون خطا و بدون از دست رفتن داده انجام می‌شود.
export async function migrateIndexesAndSeedData(pool, DB_NAME) {
  await ensureIndex(pool, DB_NAME, "patients", "idx_patients_fullName", "fullName");
  await ensureIndex(pool, DB_NAME, "patients", "idx_patients_phone", "phone");
  await ensureIndex(pool, DB_NAME, "patients", "idx_patients_email", "email");
  await ensureIndex(pool, DB_NAME, "doctors", "idx_doctors_department", "department");
  await ensureIndex(pool, DB_NAME, "doctors", "idx_doctors_fullName", "fullName");
  await ensureIndex(pool, DB_NAME, "appointments", "idx_appointments_status", "status");
  await ensureIndex(pool, DB_NAME, "appointments", "idx_appointments_date", "appointmentDate");
  await ensureIndex(pool, DB_NAME, "appointments", "idx_appointments_date_status", "appointmentDate, status");
  await ensureIndex(pool, DB_NAME, "appointments", "idx_appointments_doctor_date_time", "doctorId, appointmentDate, appointmentTime");
  await ensureIndex(pool, DB_NAME, "appointment_status_history", "idx_history_appointmentId", "appointmentId");
  await ensureIndex(pool, DB_NAME, "diagnoses", "idx_diagnoses_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "prescriptions", "idx_prescriptions_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "prescriptions", "idx_prescriptions_appointmentId", "appointmentId");
  await ensureIndex(pool, DB_NAME, "allergies", "idx_allergies_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "lab_results", "idx_lab_results_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "radiology_reports", "idx_radiology_reports_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "file_transfers", "idx_file_transfers_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "file_transfers", "idx_file_transfers_doctorId", "doctorId");
  await ensureIndex(pool, DB_NAME, "file_transfers", "idx_file_transfers_createdAt", "createdAt");
  await ensureIndex(pool, DB_NAME, "chat_conversations", "idx_chat_conversations_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "chat_conversations", "idx_chat_conversations_doctorId", "doctorId");
  await ensureIndex(pool, DB_NAME, "chat_messages", "idx_chat_messages_conversationId", "conversationId");
  await ensureIndex(pool, DB_NAME, "chat_messages", "idx_chat_messages_conversationId_isRead", "conversationId, isRead");
  await ensureIndex(pool, DB_NAME, "chat_messages", "idx_chat_messages_createdAt", "createdAt");
  await ensureIndex(pool, DB_NAME, "chat_message_reactions", "idx_chat_message_reactions_messageId", "messageId");
  await ensureIndex(pool, DB_NAME, "invoices", "idx_invoices_patientId", "patientId");
  await ensureIndex(pool, DB_NAME, "invoices", "idx_invoices_status", "status");
  await ensureIndex(pool, DB_NAME, "invoices", "idx_invoices_issueDate", "issueDate");
  await ensureIndex(pool, DB_NAME, "invoices", "idx_invoices_approvalStatus", "approvalStatus");
  await ensureIndex(pool, DB_NAME, "invoice_items", "idx_invoice_items_invoiceId", "invoiceId");
  await ensureIndex(pool, DB_NAME, "payments", "idx_payments_invoiceId", "invoiceId");
  await ensureIndex(pool, DB_NAME, "news", "idx_news_status", "status");
  await ensureIndex(pool, DB_NAME, "news", "idx_news_isPinned", "isPinned");
  await ensureIndex(pool, DB_NAME, "news", "idx_news_scheduledAt", "scheduledAt");
  await ensureIndex(pool, DB_NAME, "news", "idx_news_type", "type");
  await ensureIndex(pool, DB_NAME, "news_gallery", "idx_news_gallery_newsId", "newsId");
  await ensureIndex(pool, DB_NAME, "news_likes", "idx_news_likes_newsId", "newsId");
  await ensureIndex(pool, DB_NAME, "news_comments", "idx_news_comments_newsId", "newsId");
  await ensureIndex(pool, DB_NAME, "news_comments", "idx_news_comments_status", "status");
  // «مرکز مدیریت نظرات» ادمین: فیلتر وضعیت + مرتب‌سازی/بازه‌ی تاریخ و فیلتر خبر روی هزاران نظر
  await ensureIndex(pool, DB_NAME, "news_comments", "idx_news_comments_status_createdAt", "status, createdAt");
  await ensureIndex(pool, DB_NAME, "news_comments", "idx_news_comments_createdAt", "createdAt");
  await ensureIndex(pool, DB_NAME, "news_comments", "idx_news_comments_newsId_status", "newsId, status");
  await ensureIndex(pool, DB_NAME, "news_comments", "idx_news_comments_deletedAt_status_createdAt", "deletedAt, status, createdAt");
  await ensureIndex(pool, DB_NAME, "user_sessions", "idx_user_sessions_userId", "userId");
  await ensureIndex(pool, DB_NAME, "user_sessions", "idx_user_sessions_revokedAt", "revokedAt");
  await ensureIndex(pool, DB_NAME, "user_sessions", "idx_user_sessions_expiresAt", "expiresAt");

  // ---------- ایندکس‌های تمام‌متنی (FULLTEXT) — موتور «جستجوی سراسری» هدر ----------
  await ensureFullTextIndex(pool, DB_NAME, "doctors", "ft_doctors_search", "fullName, department, bio");
  await ensureFullTextIndex(pool, DB_NAME, "departments", "ft_departments_search", "name, description");
  await ensureFullTextIndex(pool, DB_NAME, "services", "ft_services_search", "name, description");
  await ensureFullTextIndex(pool, DB_NAME, "specialties", "ft_specialties_search", "name, description");
  await ensureFullTextIndex(pool, DB_NAME, "medicines", "ft_medicines_search", "name, genericName, description");
  await ensureFullTextIndex(pool, DB_NAME, "news", "ft_news_search", "title, excerpt, tag");



  const bcrypt = (await import("bcryptjs")).default;
  const { generateTempPassword } = await import("../../utils/passwordPolicy.js");

  // نکته‌ی امنیتی مهم: قبلاً این سه حساب با رمزهای عبور ثابت و شناخته‌شده در خودِ کد
  // ساخته می‌شدند (مثلاً SuperAdmin@123)؛ یعنی هر کسی که این پروژه را می‌دید همان رمزها
  // را هم می‌دید. حالا هر بار که این حساب‌ها روی یک دیتابیس کاملاً خالی برای اولین بار
  // ساخته می‌شوند، هرکدام یک رمز تصادفی و یکتا می‌گیرند، فقط همین یک‌بار در کنسول سرور
  // چاپ می‌شود، و mustChangePassword فعال می‌شود تا در همان اولین ورود، کاربر مجبور به
  // تعیین رمز خودش شود. رمز تصادفی هرگز در کد یا لاگ فایل ذخیره نمی‌ماند.
  function printOnce(label, email, password) {
    console.log(
      `\n🔐 ${label}\n   ایمیل: ${email}\n   رمز عبور موقت: ${password}\n` +
      `   ⚠️  این رمز فقط همین یک‌بار اینجا نمایش داده می‌شود؛ همین حالا یادداشت کنید.\n` +
      `   در اولین ورود، سیستم شما را مجبور به تعیین رمز جدید می‌کند.\n`
    );
  }

  // امنیتی: در production هیچ حساب پیش‌فرض/آزمایشی ساخته نمی‌شود (رمز تصادفی هم در لاگ‌های pm2/systemd
  // می‌ماند). مدیر کل را با «node db/createSuperAdmin.js <email> <password>» بسازید. برای محیط‌های غیر
  // production (توسعه/تست) رفتار قبلی حفظ شده است؛ با SEED_DEFAULT_ACCOUNTS=false هم می‌توان خاموشش کرد.
  const seedAccountsAllowed =
    process.env.NODE_ENV !== "production" && (process.env.SEED_DEFAULT_ACCOUNTS || "").toLowerCase() !== "false";
  if (!seedAccountsAllowed) {
    const [[{ superCount }]] = await pool.query("SELECT COUNT(*) AS superCount FROM users WHERE role = 'superadmin'");
    if (superCount === 0) {
      console.warn(
        "⚠️  هیچ حساب مدیر کل وجود ندارد و ساخت حساب پیش‌فرض غیرفعال است. یکی بسازید:\n" +
        "    node db/createSuperAdmin.js <email> <password(حداقل ۱۲ کاراکتر)> [\"نام کامل\"]"
      );
    }
  }

  const [userRows] = await pool.query("SELECT COUNT(*) AS count FROM users");
  if (seedAccountsAllowed && userRows[0].count === 0) {
    const tempPassword = generateTempPassword();
    const hashed = bcrypt.hashSync(tempPassword, 10);
    await pool.query(
      "INSERT INTO users (fullName, email, password, isVerified, mustChangePassword) VALUES (?, ?, ?, 1, 1)",
      ["کاربر آزمایشی", "test@shafakhana.af", hashed]
    );
    printOnce("👤 کاربر آزمایشی ساخته شد", "test@shafakhana.af", tempPassword);
  }

  // کاربر آزمایشی قدیمی هم نقش 'user' می‌گیرد (چون ستون role تازه اضافه شده پیش‌فرض user است)

  const [adminRows] = await pool.query("SELECT COUNT(*) AS count FROM users WHERE role = 'superadmin'");
  if (seedAccountsAllowed && adminRows[0].count === 0) {
    const superTempPassword = generateTempPassword();
    const superHashed = bcrypt.hashSync(superTempPassword, 10);
    await pool.query(
      "INSERT INTO users (fullName, email, password, role, isVerified, mustChangePassword) VALUES (?, ?, ?, 'superadmin', 1, 1)",
      ["مدیر کل سیستم", "superadmin@shafakhana.af", superHashed]
    );
    printOnce("👑 حساب مدیر کل (Super Admin) ساخته شد", "superadmin@shafakhana.af", superTempPassword);

    const adminTempPassword = generateTempPassword();
    const adminHashed = bcrypt.hashSync(adminTempPassword, 10);
    await pool.query(
      "INSERT INTO users (fullName, email, password, role, isVerified, mustChangePassword) VALUES (?, ?, ?, 'admin', 1, 1)",
      ["مدیر شفاخانه", "admin@shafakhana.af", adminHashed]
    );
    printOnce("🛡️ حساب ادمین (Admin) ساخته شد", "admin@shafakhana.af", adminTempPassword);
  }

  const [deptRows] = await pool.query("SELECT COUNT(*) AS count FROM departments");
  if (deptRows[0].count === 0) {
    const defaultDepartments = [
      "قلب و عروق", "اطفال", "زنان و زایمان", "ارتوپیدی", "دندان", "داخله", "چشم", "اعصاب",
    ];
    for (const name of defaultDepartments) {
      await pool.query("INSERT INTO departments (name) VALUES (?)", [name]);
    }
    console.log("🏥 بخش‌های پیش‌فرض شفاخانه ساخته شد");
  }

  await pool.query(
    "INSERT INTO settings (`key`, value) VALUES ('hospitalName', 'شفاخانه افغان آریا') ON DUPLICATE KEY UPDATE `key` = `key`"
  );
  await pool.query(
    "INSERT INTO settings (`key`, value) VALUES ('maintenanceMode', 'off') ON DUPLICATE KEY UPDATE `key` = `key`"
  );

  const [doctorRows] = await pool.query("SELECT COUNT(*) AS count FROM doctors");
  if (doctorRows[0].count === 0) {
    for (const d of DOCTOR_SEED) {
      await pool.query(
        "INSERT INTO doctors (doctorCode, fullName, department, yearsExperience, gender, photoId, rating, workDays, photoUrl) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
        d
      );
    }
    console.log("🩺 ۸ داکتر نمونه در دیتابیس ساخته شد");
  }

  const [newsRows] = await pool.query("SELECT COUNT(*) AS count FROM news");
  if (newsRows[0].count === 0) {
    for (const n of NEWS_SEED) {
      await pool.query(
        "INSERT INTO news (title, excerpt, tag, imageUrl) VALUES (?, ?, ?, ?)",
        n
      );
    }
    console.log("📰 ۶ خبر نمونه در دیتابیس ساخته شد");
  }

  // ---------- داده‌های نمونه‌ی جدول‌های تازه‌ی «جستجوی سراسری» ----------
  const [serviceRows] = await pool.query("SELECT COUNT(*) AS count FROM services");
  if (serviceRows[0].count === 0) {
    for (const s of SERVICE_SEED) {
      await pool.query("INSERT INTO services (name, description, department) VALUES (?, ?, ?)", s);
    }
    console.log("🩺 خدمات نمونه‌ی شفاخانه در دیتابیس ساخته شد");
  }

  const [specialtyRows] = await pool.query("SELECT COUNT(*) AS count FROM specialties");
  if (specialtyRows[0].count === 0) {
    for (const s of SPECIALTY_SEED) {
      await pool.query("INSERT IGNORE INTO specialties (name, description) VALUES (?, ?)", s);
    }
    console.log("🏷️ تخصص‌های نمونه در دیتابیس ساخته شد");
  }

  const [medicineRows] = await pool.query("SELECT COUNT(*) AS count FROM medicines");
  if (medicineRows[0].count === 0) {
    for (const m of MEDICINE_SEED) {
      await pool.query(
        "INSERT INTO medicines (name, genericName, description, requiresPrescription) VALUES (?, ?, ?, ?)",
        m
      );
    }
    console.log("💊 ادویه‌های نمونه در دیتابیس ساخته شد");
  }

  // مقالات صحی (type='article') جدا از اخبار رسمی (type='news') شمرده و درج می‌شوند
  const [articleRows] = await pool.query("SELECT COUNT(*) AS count FROM news WHERE type = 'article'");
  if (articleRows[0].count === 0) {
    for (const a of ARTICLE_SEED) {
      await pool.query(
        "INSERT INTO news (title, excerpt, tag, type) VALUES (?, ?, ?, 'article')",
        a
      );
    }
    console.log("📄 مقالات صحی نمونه در دیتابیس ساخته شد");
  }

  // اصلاح عکس اشتباه خبر «دندان» در دیتابیس‌هایی که قبلاً ساخته شده‌اند
  // (عکس قبلی در واقع تصویر یک گوشی طبی بود، نه دندان)
  await pool.query(
    "UPDATE news SET imageUrl = ? WHERE tag = ? AND imageUrl = ?",
    [
      "https://images.pexels.com/photos/4269698/pexels-photo-4269698.jpeg?auto=compress&cs=tinysrgb&w=800",
      "دندان",
      "https://images.pexels.com/photos/40568/pexels-photo-40568.jpeg?auto=compress&cs=tinysrgb&w=800",
    ]
  );
}

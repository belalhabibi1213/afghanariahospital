export async function migrateUsersDoctorsPatients(pool, DB_NAME) {
  // ---------- جدول‌ها ----------

  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      fullName VARCHAR(150) NOT NULL,
      email VARCHAR(150) NOT NULL UNIQUE,
      password VARCHAR(255) NOT NULL,
      role ENUM('user','admin','superadmin') NOT NULL DEFAULT 'user',
      phone VARCHAR(30) NULL,
      isActive TINYINT(1) NOT NULL DEFAULT 1,
      isVerified TINYINT(1) NOT NULL DEFAULT 0,
      verificationCodeHash VARCHAR(255) NULL,
      verificationExpires DATETIME NULL,
      resetCodeHash VARCHAR(255) NULL,
      resetExpires DATETIME NULL,
      photoUrl VARCHAR(255) NULL,
      themePreference VARCHAR(10) NOT NULL DEFAULT 'light',
      palettePreference VARCHAR(20) NOT NULL DEFAULT 'teal',
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب دیتابیس‌های قدیمی: اگر جدول users از قبل بدون ستون‌های
  // تایید ایمیل ساخته شده، این ستون‌ها را بدون پاک کردن داده‌ی موجود اضافه می‌کند
  const [userColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users'`,
    [DB_NAME]
  );
  const existingColumns = new Set(userColumns.map((c) => c.COLUMN_NAME));

  if (!existingColumns.has("isVerified")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN isVerified TINYINT(1) NOT NULL DEFAULT 0"
    );
    // کاربرانی که قبل از افزودن این قابلیت ثبت‌نام کرده‌اند، تایید‌شده در نظر گرفته می‌شوند
    await pool.query("UPDATE users SET isVerified = 1");
  }
  if (!existingColumns.has("verificationCodeHash")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN verificationCodeHash VARCHAR(255) NULL"
    );
  }
  if (!existingColumns.has("verificationExpires")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN verificationExpires DATETIME NULL"
    );
  }

  // ---------- ارتقای RBAC: افزودن ستون‌های role / phone / isActive ----------
  if (!existingColumns.has("role")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN role ENUM('user','admin','superadmin','doctor') NOT NULL DEFAULT 'user'"
    );
  } else {
    // ارتقای غیرمخرب: افزودن نقش 'doctor' به لیست مقادیر مجاز ستون role
    // (برای حساب‌های کاربری داکترانی که باید بتوانند نوبت‌ها را تایید/رد کنند)
    const [roleColumnInfo] = await pool.query(
      `SELECT COLUMN_TYPE FROM information_schema.COLUMNS
       WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users' AND COLUMN_NAME = 'role'`,
      [DB_NAME]
    );
    if (roleColumnInfo[0] && !roleColumnInfo[0].COLUMN_TYPE.includes("'doctor'")) {
      await pool.query(
        "ALTER TABLE users MODIFY COLUMN role ENUM('user','admin','superadmin','doctor') NOT NULL DEFAULT 'user'"
      );
    }
  }
  if (!existingColumns.has("phone")) {
    await pool.query("ALTER TABLE users ADD COLUMN phone VARCHAR(30) NULL");
  }
  if (!existingColumns.has("isActive")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN isActive TINYINT(1) NOT NULL DEFAULT 1"
    );
  }

  // ---------- امنیت ورود: قفل موقت حساب + الزام تغییر رمز عبور ----------
  // failedLoginAttempts/lockedUntil: بعد از چند تلاش ناموفق پیاپی برای یک حساب مشخص (نه فقط
  // برای یک IP)، همان حساب موقتاً قفل می‌شود — حتی اگر مهاجم IP خودش را عوض کند. آستانه و
  // مدت قفل از «تنظیمات سیستم» قابل تغییرند (loginMaxFailedAttempts, loginLockoutMinutes).
  // mustChangePassword: حساب‌های پیش‌فرض (Super Admin/Admin که خودکار ساخته می‌شوند) با یک
  // رمز تصادفی ساخته می‌شوند و این پرچم فعال می‌شود؛ بعد از اولین ورود، کاربر مجبور به
  // تعیین رمز خودش می‌شود (مثل هر رمز موقتی که ادمین برای کسی می‌سازد).
  if (!existingColumns.has("failedLoginAttempts")) {
    await pool.query("ALTER TABLE users ADD COLUMN failedLoginAttempts INT NOT NULL DEFAULT 0");
  }
  if (!existingColumns.has("lockedUntil")) {
    await pool.query("ALTER TABLE users ADD COLUMN lockedUntil TIMESTAMP NULL DEFAULT NULL");
  }
  if (!existingColumns.has("mustChangePassword")) {
    await pool.query("ALTER TABLE users ADD COLUMN mustChangePassword TINYINT(1) NOT NULL DEFAULT 0");
  }

  // ---------- ارتقا: فراموشی رمز عبور (Forgot / Reset Password) ----------
  if (!existingColumns.has("resetCodeHash")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN resetCodeHash VARCHAR(255) NULL"
    );
  }
  if (!existingColumns.has("resetExpires")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN resetExpires DATETIME NULL"
    );
  }

  // ---------- امنیت کد یک‌بارمصرف (OTP): شمارنده‌ی تلاش اشتباه برای «هر حساب» ----------
  // کد ۶ رقمی فقط ۱٬۰۰۰٬۰۰۰ حالت دارد؛ محدودیت نرخ بر اساس IP به‌تنهایی جلوی حمله‌ی توزیع‌شده را
  // نمی‌گیرد. با این دو ستون، بعد از چند حدس اشتباه روی یک حساب، همان کد باطل می‌شود.
  if (!existingColumns.has("verificationAttempts")) {
    await pool.query("ALTER TABLE users ADD COLUMN verificationAttempts INT NOT NULL DEFAULT 0");
  }
  if (!existingColumns.has("resetAttempts")) {
    await pool.query("ALTER TABLE users ADD COLUMN resetAttempts INT NOT NULL DEFAULT 0");
  }

  // ---------- ارتقا: عکس پروفایل کاربر ----------
  if (!existingColumns.has("photoUrl")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN photoUrl VARCHAR(255) NULL"
    );
  }

  // ---------- ارتقای غیرمخرب: فیلدهای گسترده‌ی پروفایل بیمار («ویرایش اطلاعات شخصی») ----------
  // findById/updateProfile (models/User.js) و صفحه‌ی «ویرایش پروفایل» پنل بیمار از ابتدا
  // فرض کرده بودند این ستون‌ها روی جدول users وجود دارند، اما هیچ‌جا ساخته نشده بودند —
  // دقیقاً همان الگوی باگ gender/dateOfBirth روی جدول patients در بالا (نگاه کنید به توضیح
  // آن بخش)، با این تفاوت که این‌جا باعث خطای "Unknown column" روی خودِ GET/PUT پروفایل
  // می‌شد (نه فقط تب «بیماران من»). همه‌ی ستون‌های زیر nullable هستند تا هیچ داده‌ی
  // موجودی از دست نرود؛ کاربران فعلی مقدار خالی (NULL) خواهند داشت.
  if (!existingColumns.has("dateOfBirth")) {
    await pool.query("ALTER TABLE users ADD COLUMN dateOfBirth DATE NULL");
  }
  if (!existingColumns.has("gender")) {
    await pool.query("ALTER TABLE users ADD COLUMN gender ENUM('male','female','other') NULL");
  }
  if (!existingColumns.has("bloodGroup")) {
    await pool.query("ALTER TABLE users ADD COLUMN bloodGroup ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NULL");
  }
  if (!existingColumns.has("address")) {
    await pool.query("ALTER TABLE users ADD COLUMN address VARCHAR(255) NULL");
  }
  if (!existingColumns.has("emergencyContactName")) {
    await pool.query("ALTER TABLE users ADD COLUMN emergencyContactName VARCHAR(150) NULL");
  }
  if (!existingColumns.has("emergencyContactRelationship")) {
    await pool.query("ALTER TABLE users ADD COLUMN emergencyContactRelationship VARCHAR(50) NULL");
  }
  if (!existingColumns.has("emergencyContactPhone")) {
    await pool.query("ALTER TABLE users ADD COLUMN emergencyContactPhone VARCHAR(30) NULL");
  }
  if (!existingColumns.has("allergies")) {
    await pool.query("ALTER TABLE users ADD COLUMN allergies VARCHAR(500) NULL");
  }
  if (!existingColumns.has("chronicDiseases")) {
    await pool.query("ALTER TABLE users ADD COLUMN chronicDiseases VARCHAR(500) NULL");
  }
  if (!existingColumns.has("drugAllergies")) {
    await pool.query("ALTER TABLE users ADD COLUMN drugAllergies VARCHAR(500) NULL");
  }
  if (!existingColumns.has("height")) {
    await pool.query("ALTER TABLE users ADD COLUMN height DECIMAL(5,2) NULL");
  }
  if (!existingColumns.has("weight")) {
    await pool.query("ALTER TABLE users ADD COLUMN weight DECIMAL(5,2) NULL");
  }

  // ---------- ارتقای غیرمخرب: حالت روشن/تاریک (Dark/Light Mode) ----------
  // ترجیح تم هر کاربر (فقط برای کاربران واردشده معنا دارد؛ برای مهمان در
  // localStorage مرورگر نگه‌داری می‌شود). پیش‌فرض همیشه 'light' است.
  if (!existingColumns.has("themePreference")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN themePreference VARCHAR(10) NOT NULL DEFAULT 'light'"
    );
  }

  // ---------- ارتقای غیرمخرب: پالت رنگی انتخاب‌شده توسط کاربر ----------
  // شناسه‌ی پالت (teal, ocean, violet, ...) برای هر کاربر؛ تا بعد از ورود از هر
  // دستگاهی همان رنگ‌بندی بازیابی شود. اعتبارسنجی مقدار در controller انجام می‌شود.
  if (!existingColumns.has("palettePreference")) {
    await pool.query(
      "ALTER TABLE users ADD COLUMN palettePreference VARCHAR(20) NOT NULL DEFAULT 'teal'"
    );
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS doctors (
      id INT AUTO_INCREMENT PRIMARY KEY,
      doctorCode VARCHAR(20) NOT NULL,
      fullName VARCHAR(150) NOT NULL,
      department VARCHAR(100) NOT NULL,
      yearsExperience INT NOT NULL DEFAULT 0,
      gender VARCHAR(10) NOT NULL DEFAULT 'men',
      photoId INT NOT NULL DEFAULT 1,
      rating DECIMAL(2,1) NOT NULL DEFAULT 4.5,
      workDays VARCHAR(150) NOT NULL DEFAULT 'شنبه تا چهارشنبه',
      photoUrl VARCHAR(255) NULL,
      bio TEXT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uniq_doctor_code (doctorCode)
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب: ستون userId روی جدول doctors (اتصال پروفایل داکتر به حساب کاربری‌اش
  // با نقش 'doctor' — تا داکتر بتواند وارد شود و نوبت‌های خودش را تایید/رد کند)
  const [doctorColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'doctors'`,
    [DB_NAME]
  );
  const existingDoctorColumns = new Set(doctorColumns.map((c) => c.COLUMN_NAME));
  if (!existingDoctorColumns.has("userId")) {
    await pool.query("ALTER TABLE doctors ADD COLUMN userId INT NULL UNIQUE");
    await pool.query(
      "ALTER TABLE doctors ADD CONSTRAINT fk_doctors_userId FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL"
    );
  }

  // ارتقای غیرمخرب: افزودن شناسه یکتای داکتر (doctorCode) برای دیتابیس‌های نسخه قبلی.
  // ابتدا ستون به‌صورت nullable اضافه می‌شود، برای داکترهای موجود مقداردهی خودکار
  // می‌شود (مثل DR-0001) و در نهایت محدودیت NOT NULL + UNIQUE اعمال می‌شود، تا هیچ
  // داکتر موجودی بدون شناسه نماند و داده‌ای از دست نرود.
  if (!existingDoctorColumns.has("doctorCode")) {
    await pool.query("ALTER TABLE doctors ADD COLUMN doctorCode VARCHAR(20) NULL");
    const [existingDoctorRows] = await pool.query("SELECT id FROM doctors ORDER BY id");
    for (const row of existingDoctorRows) {
      const generatedCode = `DR-${String(row.id).padStart(4, "0")}`;
      await pool.query("UPDATE doctors SET doctorCode = ? WHERE id = ?", [generatedCode, row.id]);
    }
    await pool.query("ALTER TABLE doctors MODIFY COLUMN doctorCode VARCHAR(20) NOT NULL");
    await pool.query("ALTER TABLE doctors ADD UNIQUE KEY uniq_doctor_code (doctorCode)");
    console.log("🆔 ستون شناسه یکتای داکتر (doctorCode) اضافه و برای داکترهای موجود مقداردهی شد");
  }

  // ارتقای غیرمخرب: ستون signatureUrl روی doctors (امضای دیجیتال داکتر که در PDF نسخه
  // چاپ می‌شود). این ستون در database_full.sql تعریف شده و models/Prescription.js
  // (getPrescriptionById و توابع مشابه) همیشه d.signatureUrl را در SELECT می‌خوانند؛
  // نبودش باعث خطای «Unknown column 'd.signatureUrl'» و شکست ثبت/ویرایش نسخه می‌شد.
  if (!existingDoctorColumns.has("signatureUrl")) {
    await pool.query("ALTER TABLE doctors ADD COLUMN signatureUrl VARCHAR(255) NULL");
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS patients (
      id INT AUTO_INCREMENT PRIMARY KEY,
      userId INT NULL,
      fullName VARCHAR(150) NOT NULL,
      phone VARCHAR(30) NOT NULL,
      email VARCHAR(150) NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  // ستون publicCode: کد یکتای عمومی هر بیمار (مثل AAH-000123) — روی کارت بیمار چاپ و
  // به‌صورت QR درج می‌شود تا پذیرش بتواند با اسکن، پرونده‌ی بیمار را سریع پیدا کند.
  const [patientCodeCol] = await pool.query("SHOW COLUMNS FROM patients LIKE 'publicCode'");
  if (patientCodeCol.length === 0) {
    await pool.query("ALTER TABLE patients ADD COLUMN publicCode VARCHAR(20) NULL");
    await pool.query("ALTER TABLE patients ADD UNIQUE INDEX uq_patients_publicCode (publicCode)");
  }
  // بیماران قبلی که کد ندارند، بر اساس همان id خودشان کدگذاری می‌شوند (پایدار و بدون برخورد)
  await pool.query(
    "UPDATE patients SET publicCode = CONCAT('AAH-', LPAD(id, 6, '0')) WHERE publicCode IS NULL"
  );

  // ارتقای غیرمخرب: ستون‌های gender و dateOfBirth روی patients. این دو ستون توسط
  // searchDoctorPatients (ماژول «بیماران من» در پنل داکتر) برای نمایش جنسیت/سن بیمار
  // استفاده می‌شوند، اما قبلاً هرگز به جدول patients اضافه نشده بودند — همین موضوع باعث
  // خطای "Unknown column 'p.gender'" و در نتیجه خطای سرور در تب «بیماران من» می‌شد.
  // هر دو ستون nullable هستند تا هیچ داده‌ی موجودی از دست نرود؛ بیماران فعلی مقدار
  // خالی (NULL) خواهند داشت و در فرانت‌اند به‌صورت «—» نمایش داده می‌شوند.
  const [patientColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'patients'`,
    [DB_NAME]
  );
  const existingPatientColumns = new Set(patientColumns.map((c) => c.COLUMN_NAME));
  if (!existingPatientColumns.has("gender")) {
    await pool.query("ALTER TABLE patients ADD COLUMN gender ENUM('male','female') NULL");
  }
  if (!existingPatientColumns.has("dateOfBirth")) {
    await pool.query("ALTER TABLE patients ADD COLUMN dateOfBirth DATE NULL");
  }
}

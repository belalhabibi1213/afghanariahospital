// جدول‌های ذخیره‌ی محتوای عکس‌های عمومی آپلودشده (داکتر، آیکون بخش، خبر/گالری، پروفایل، لوگو).
// دلیل وجود: با جایگزین شدن پوشه‌ی پروژه، پوشه‌ی backend/uploads خالی می‌شد و عکس‌ها از بین
// می‌رفتند. حالا خود عکس هم داخل دیتابیس نگه‌داری می‌شود (جزئیات در utils/uploadStore.js).
//
// هر عکس به تکه‌های کوچک (۲۵۶ کیلوبایت) تقسیم و در uploaded_file_chunks ذخیره می‌شود. دلیل:
// MySQL/MariaDB (مثلاً XAMPP قدیمی با max_allowed_packet=1M) اجازه‌ی نوشتن/ساختن یک مقدار
// بزرگ‌تر از آن حد را نمی‌دهد و عکس‌های ۱ تا ۲ مگابایتی با خطا ذخیره نمی‌شدند.
export async function migrateUploadedFiles(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS uploaded_files (
      path VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
      mimeType VARCHAR(100) NOT NULL,
      size INT UNSIGNED NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);
  await pool.query(`
    CREATE TABLE IF NOT EXISTS uploaded_file_chunks (
      path VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
      seq INT UNSIGNED NOT NULL,
      data MEDIUMBLOB NOT NULL,
      PRIMARY KEY (path, seq),
      FOREIGN KEY (path) REFERENCES uploaded_files(path) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);
}

export async function migrateCommunications(pool, DB_NAME) {
  // ---------- ماژول «انتقال معلومات بیمار» (Patient Information Transfer) ----------
  // جایگزین بخش «امضای دیجیتال» در پنل داکتر: داکتر می‌تواند فایل/سند صحی (PDF، اکسل، ورد،
  // JPG/PNG) برای بیمارانِ خودش ارسال کند؛ بیمار فقط فایل‌های خودش را می‌بیند/دانلود می‌کند.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS file_transfers (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NOT NULL,
      fileName VARCHAR(255) NOT NULL,
      originalName VARCHAR(255) NOT NULL,
      fileType VARCHAR(150) NOT NULL,
      fileSize INT NOT NULL,
      note TEXT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ---------- ماژول «گفتگوی خصوصی بیمار ↔ داکتر» (Private Patient–Doctor Chat) ----------
  // هر مکالمه بین یک بیمار و یک داکتر مشخص است (یکتا: هر جفت بیمار/داکتر فقط یک مکالمه
  // دارد). فقط پیام‌های متنی پشتیبانی می‌شود، بدون آپلود فایل. دسترسی به هر مکالمه در
  // سطح کنترلر بررسی می‌شود: بیمار فقط مکالمه‌های خودش، داکتر فقط مکالمه‌های بیمارانِ خودش.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS chat_conversations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uniq_chat_conversation_patient_doctor (patientId, doctorId),
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS chat_messages (
      id INT AUTO_INCREMENT PRIMARY KEY,
      conversationId INT NOT NULL,
      senderUserId INT NOT NULL,
      senderRole VARCHAR(20) NOT NULL,
      content TEXT NOT NULL,
      isRead TINYINT(1) NOT NULL DEFAULT 0,
      isDelivered TINYINT(1) NOT NULL DEFAULT 0,
      isEdited TINYINT(1) NOT NULL DEFAULT 0,
      editedAt TIMESTAMP NULL,
      isDeleted TINYINT(1) NOT NULL DEFAULT 0,
      deletedAt TIMESTAMP NULL,
      attachmentFileName VARCHAR(255) NULL,
      attachmentOriginalName VARCHAR(255) NULL,
      attachmentFileType VARCHAR(150) NULL,
      attachmentFileSize INT NULL,
      attachmentDurationSeconds INT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (conversationId) REFERENCES chat_conversations(id) ON DELETE CASCADE,
      FOREIGN KEY (senderUserId) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب: ستون‌های ویرایش/حذف نرم (soft-delete) پیام‌های چت — برای دیتابیس‌هایی
  // که پیش از این جدول chat_messages را بدون این ستون‌ها ساخته‌اند. متن پیامِ حذف‌شده در
  // دیتابیس نگه داشته می‌شود (برای گزارش/ممیزی) اما هرگز در پاسخ API به کلاینت فرستاده
  // نمی‌شود؛ به‌جای آن فرانت‌اند پیام «این پیام حذف شده است» را نمایش می‌دهد.
  const [chatMessageColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'chat_messages'`,
    [DB_NAME]
  );
  const existingChatMessageColumns = new Set(chatMessageColumns.map((c) => c.COLUMN_NAME));
  // ارتقای غیرمخرب: وضعیت «تحویل شد» پیام چت (بین ارسال‌شده و خوانده‌شده) — برای
  // دیتابیس‌هایی که پیش از این جدول chat_messages را بدون این ستون ساخته‌اند.
  if (!existingChatMessageColumns.has("isDelivered")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN isDelivered TINYINT(1) NOT NULL DEFAULT 0");
  }
  if (!existingChatMessageColumns.has("isEdited")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN isEdited TINYINT(1) NOT NULL DEFAULT 0");
  }
  if (!existingChatMessageColumns.has("editedAt")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN editedAt TIMESTAMP NULL");
  }
  if (!existingChatMessageColumns.has("isDeleted")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN isDeleted TINYINT(1) NOT NULL DEFAULT 0");
  }
  if (!existingChatMessageColumns.has("deletedAt")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN deletedAt TIMESTAMP NULL");
  }
  // پیوست عکس/سند پیام چت (یک فایل به‌ازای هر پیام) — نام فایل روی دیسک تصادفی است
  // (attachmentFileName)، نام اصلی/نوع/حجم برای نمایش در UI جداگانه نگه‌داری می‌شود
  if (!existingChatMessageColumns.has("attachmentFileName")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN attachmentFileName VARCHAR(255) NULL");
  }
  if (!existingChatMessageColumns.has("attachmentOriginalName")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN attachmentOriginalName VARCHAR(255) NULL");
  }
  if (!existingChatMessageColumns.has("attachmentFileType")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN attachmentFileType VARCHAR(150) NULL");
  }
  if (!existingChatMessageColumns.has("attachmentFileSize")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN attachmentFileSize INT NULL");
  }
  // مدت‌زمانِ پیام صوتی (به ثانیه) — فقط برای پیام صوتی پر می‌شود (attachmentFileType با
  // پیشوند audio/)؛ برای عکس/سند همیشه NULL باقی می‌ماند. صرفاً برای نمایشِ سریعِ مدت‌زمان
  // در پخش‌کننده استفاده می‌شود، بدون نیاز به بازکردن/دیکد فایل صوتی در فرانت‌اند.
  if (!existingChatMessageColumns.has("attachmentDurationSeconds")) {
    await pool.query("ALTER TABLE chat_messages ADD COLUMN attachmentDurationSeconds INT NULL");
  }

  // ---------- واکنش‌های ایموجی روی پیام‌های چت (Message Reactions) ----------
  // هر کاربر حداکثر یک واکنش فعال روی هر پیام دارد (UNIQUE KEY روی messageId+userId)؛
  // زدن دوباره‌ی همان ایموجی در سطح کنترلر واکنش را حذف می‌کند و زدن ایموجی دیگر آن را
  // جایگزین می‌کند (نه یک ردیف اضافه) — دقیقاً رفتار «افزودن/حذف/تغییر واکنش» خواسته‌شده.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS chat_message_reactions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      messageId INT NOT NULL,
      userId INT NOT NULL,
      emoji VARCHAR(16) NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uniq_chat_message_reaction_user (messageId, userId),
      FOREIGN KEY (messageId) REFERENCES chat_messages(id) ON DELETE CASCADE,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS notifications (
      id INT AUTO_INCREMENT PRIMARY KEY,
      userId INT NOT NULL,
      title VARCHAR(150) NOT NULL,
      message TEXT NOT NULL,
      type VARCHAR(30) NOT NULL DEFAULT 'general',
      relatedId INT NULL,
      isRead TINYINT(1) NOT NULL DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS activity_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      userId INT NULL,
      userName VARCHAR(150) NULL,
      role VARCHAR(20) NULL,
      action VARCHAR(255) NOT NULL,
      details TEXT NULL,
      ipAddress VARCHAR(45) NULL,
      userAgent VARCHAR(255) NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب دیتابیس‌های قدیمی: اگر جدول activity_logs از قبل بدون ستون‌های
  // آدرس IP و مرورگر ساخته شده، این ستون‌ها را بدون پاک کردن لاگ‌های موجود اضافه می‌کند
  const [activityLogColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'activity_logs'`,
    [DB_NAME]
  );
  const existingActivityLogColumns = new Set(activityLogColumns.map((c) => c.COLUMN_NAME));

  if (!existingActivityLogColumns.has("ipAddress")) {
    await pool.query("ALTER TABLE activity_logs ADD COLUMN ipAddress VARCHAR(45) NULL");
  }
  if (!existingActivityLogColumns.has("userAgent")) {
    await pool.query("ALTER TABLE activity_logs ADD COLUMN userAgent VARCHAR(255) NULL");
  }

  // پاک‌سازی یک‌باره: اعلان «نظر جدید در انتظار تایید» دیگر برای سوپرادمین فرستاده نمی‌شود (بررسی نظرات
  // کار ادمین است)؛ اعلان‌های قدیمیِ آن که برای سوپرادمین‌ها ثبت شده بود حذف می‌شود. فقط همین اعلان
  // (نوع news_comment با همین عنوان) و فقط برای کاربران با نقش superadmin؛ با شناسه‌ی ۱۰۰ در
  // _migrations ثبت می‌شود تا فقط یک بار اجرا شود.
  const [doneRows] = await pool.query("SELECT id FROM _migrations WHERE id = 100");
  if (doneRows.length === 0) {
    await pool.query(
      `DELETE n FROM notifications n
       JOIN users u ON u.id = n.userId
       WHERE u.role = 'superadmin' AND n.type = 'news_comment' AND n.title = 'نظر جدید در انتظار تایید'`
    );
    await pool.query("INSERT INTO _migrations (id) VALUES (100)");
  }
}

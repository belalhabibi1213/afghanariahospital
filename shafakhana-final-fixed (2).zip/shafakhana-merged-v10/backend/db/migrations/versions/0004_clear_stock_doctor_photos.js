// عکس‌های آماده/نمونه‌ی داکتران (فایل‌های داخل پوشه‌ی /doctors پروژه یا لینک‌های بیرونی) حذف می‌شوند؛
// فقط عکس‌هایی که خود ادمین آپلود کرده (/uploads/doctors/...) باقی می‌مانند.
export async function up(pool) {
  await pool.query(
    "UPDATE doctors SET photoUrl = NULL WHERE photoUrl IS NOT NULL AND photoUrl NOT LIKE '/uploads/doctors/%'"
  );
}

export async function down() {
  // برگشت‌ناپذیر عمداً: عکس‌های نمونه دیگر استفاده نمی‌شوند.
}

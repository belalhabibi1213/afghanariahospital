// احراز هویت دومرحله‌ای (MFA / TOTP) — ستون‌های جدول users.
// راز TOTP رمزنگاری‌شده (AES-256-GCM)، کدهای بازیابی فقط هش، و mfaLastStep ضد replay است.
const COLUMNS = [
  ["mfaEnabled", "TINYINT(1) NOT NULL DEFAULT 0"],
  ["mfaSecretEnc", "VARCHAR(255) NULL"],
  ["mfaPendingSecretEnc", "VARCHAR(255) NULL"],
  ["mfaRecoveryHashes", "TEXT NULL"],
  ["mfaLastStep", "BIGINT NULL"],
];

export async function up(pool, dbName) {
  const [rows] = await pool.query(
    "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'users'",
    [dbName]
  );
  const existing = new Set(rows.map((r) => r.COLUMN_NAME));
  for (const [name, ddl] of COLUMNS) {
    if (!existing.has(name)) await pool.query(`ALTER TABLE users ADD COLUMN ${name} ${ddl}`);
  }
}

export async function down(pool) {
  for (const [name] of [...COLUMNS].reverse()) {
    await pool.query(`ALTER TABLE users DROP COLUMN IF EXISTS ${name}`);
  }
}

// محتوای قابل‌ویرایش سایت توسط ادمین (مثل بخش «معرفی» صفحه‌ی اصلی) — جدول key/value با مقدار JSON.
// عمداً جدا از جدول settings است تا در «تنظیمات سیستم» سوپرادمین قاطی نشود.
export async function up(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS site_content (
      \`key\` VARCHAR(100) PRIMARY KEY,
      value MEDIUMTEXT NULL,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);
}

export async function down(pool) {
  await pool.query("DROP TABLE IF EXISTS site_content");
}

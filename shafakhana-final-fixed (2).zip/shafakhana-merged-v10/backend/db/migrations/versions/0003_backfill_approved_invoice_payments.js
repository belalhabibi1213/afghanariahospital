// فاکتورهای قبلاً تاییدشده مبلغ پرداخت‌شده (invoices.paidAmount) داشتند ولی هیچ ردیفی در جدول payments
// نداشتند؛ چون «گزارش درآمد» از payments می‌خواند، این فاکتورها در گزارش (و خروجی PDF/Excel) دیده نمی‌شدند.
// این مهاجرت برای هر فاکتور، اختلاف paidAmount و جمع پرداخت‌های ثبت‌شده را به‌صورت یک پرداخت نقدی
// (در تاریخ تایید) اضافه می‌کند. چند بار اجرا شود هم تکراری نمی‌سازد (بعد از اجرا اختلاف صفر است).
export async function up(pool) {
  await pool.query(`
    INSERT INTO payments (invoiceId, amount, method, paidAt, reference, notes, receivedByUserId)
    SELECT i.id,
           ROUND(i.paidAmount - COALESCE(p.total, 0), 2),
           'cash',
           COALESCE(i.approvedAt, i.createdAt),
           NULL,
           'ثبت خودکار (هم‌ترازسازی پرداخت‌های قدیمی)',
           i.approvedByUserId
    FROM invoices i
    LEFT JOIN (SELECT invoiceId, SUM(amount) AS total FROM payments GROUP BY invoiceId) p ON p.invoiceId = i.id
    WHERE i.status <> 'cancelled' AND i.paidAmount - COALESCE(p.total, 0) > 0.005
  `);
}

export async function down() {
  // برگشت‌ناپذیر عمداً: رکوردهای مالی حذف نمی‌شوند.
}

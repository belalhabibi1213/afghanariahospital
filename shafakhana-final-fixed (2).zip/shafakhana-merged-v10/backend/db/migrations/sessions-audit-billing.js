import { ensureIndex } from "../helpers.js";

export async function migrateSessionsAuditBilling(pool, DB_NAME) {
  // ---------- نشست‌ها و دستگاه‌های فعال (Sessions & Devices — فقط برای Super Admin) ----------
  // هر بار کاربر با موفقیت وارد می‌شود (login/verifyEmail)، یک ردیف اینجا ثبت می‌شود.
  // tokenId همان claim یکتای jti داخل JWT است؛ requireAuth (middleware/auth.js) با هر
  // درخواست این ردیف را بررسی می‌کند و اگر revokedAt پر شده باشد (یعنی Super Admin آن
  // نشست را خاتمه داده)، دسترسی فوراً قطع می‌شود — حتی اگر خودِ JWT هنوز منقضی نشده باشد.
  // توکن‌های صادرشده پیش از افزودن این قابلیت فاقد jti هستند و بدون تغییر رفتار قبلی
  // (بدون بررسی نشست) کار می‌کنند تا هیچ کاربر واردشده‌ای از سیستم بیرون انداخته نشود.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS user_sessions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      userId INT NOT NULL,
      tokenId VARCHAR(64) NOT NULL,
      userName VARCHAR(150) NULL,
      role VARCHAR(20) NULL,
      ipAddress VARCHAR(45) NULL,
      userAgent VARCHAR(255) NULL,
      loginAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      lastActivityAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      expiresAt DATETIME NULL,
      revokedAt DATETIME NULL,
      revokedByUserId INT NULL,
      UNIQUE KEY uq_user_sessions_tokenId (tokenId),
      FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (revokedByUserId) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  // ---------- سیستم حسابرسی (Audit Trail) — ثبت تغییرات مهم دیتابیس با مقدار قبلی/جدید ----------
  // این جدول از activity_logs جداست: activity_logs یک لاگ متنیِ کلی از فعالیت‌هاست،
  // در حالی که audit_logs به‌صورت ساخت‌یافته (JSON) مقدار قبل/بعد هر تغییر را نگه می‌دارد
  // و فقط برای Super Admin در دسترس است.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      tableName VARCHAR(100) NOT NULL,
      recordId VARCHAR(50) NULL,
      action ENUM('INSERT','UPDATE','DELETE') NOT NULL,
      oldValues JSON NULL,
      newValues JSON NULL,
      changedFields TEXT NULL,
      userId INT NULL,
      userName VARCHAR(150) NULL,
      userRole VARCHAR(20) NULL,
      ipAddress VARCHAR(45) NULL,
      userAgent VARCHAR(255) NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  // ایندکس‌های جستجو روی جدول حسابرسی
  await ensureIndex(pool, DB_NAME, "audit_logs", "idx_audit_logs_tableName", "tableName");
  await ensureIndex(pool, DB_NAME, "audit_logs", "idx_audit_logs_recordId", "recordId");
  await ensureIndex(pool, DB_NAME, "audit_logs", "idx_audit_logs_userId", "userId");
  await ensureIndex(pool, DB_NAME, "audit_logs", "idx_audit_logs_action", "action");
  await ensureIndex(pool, DB_NAME, "audit_logs", "idx_audit_logs_createdAt", "createdAt");
  // ایندکس‌های ترکیبی برای فیلتر «نقش/جدول + مرتب‌سازی بر اساس تاریخ» در صفحه‌ی لاگ حسابرسی
  await ensureIndex(pool, DB_NAME, "audit_logs", "idx_audit_logs_userRole_createdAt", "userRole, createdAt");
  await ensureIndex(pool, DB_NAME, "audit_logs", "idx_audit_logs_tableName_createdAt", "tableName, createdAt");

  // ایندکس‌های جدول activity_logs (قبلاً هیچ ایندکسی نداشت؛ هر کوئری صفحه‌ی «لاگ فعالیت»
  // شامل ORDER BY createdAt و COUNT(*) کل جدول را می‌خواند و با رشد جدول کند می‌شد)
  await ensureIndex(pool, DB_NAME, "activity_logs", "idx_activity_logs_createdAt", "createdAt");
  await ensureIndex(pool, DB_NAME, "activity_logs", "idx_activity_logs_role_createdAt", "role, createdAt");
  await ensureIndex(pool, DB_NAME, "activity_logs", "idx_activity_logs_userId", "userId");

  // جلوگیری از دستکاری لاگ‌های حسابرسی (الزام شماره ۴): این دو Trigger در سطح خودِ
  // دیتابیس، هرگونه UPDATE یا DELETE روی audit_logs را رد می‌کنند — حتی اگر کسی
  // مستقیماً از phpMyAdmin یا یک کوئری خام تلاش کند رکوردی را تغییر/حذف کند.
  // فقط INSERT (ثبت لاگ جدید) مجاز است.
  const [triggerRows] = await pool.query(
    `SELECT TRIGGER_NAME FROM information_schema.TRIGGERS
     WHERE TRIGGER_SCHEMA = ? AND TRIGGER_NAME IN ('trg_audit_logs_no_update', 'trg_audit_logs_no_delete')`,
    [DB_NAME]
  );
  const existingTriggers = new Set(triggerRows.map((t) => t.TRIGGER_NAME));

  if (!existingTriggers.has("trg_audit_logs_no_update")) {
    await pool.query(`
      CREATE TRIGGER trg_audit_logs_no_update
      BEFORE UPDATE ON audit_logs
      FOR EACH ROW
      BEGIN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ثبت‌های حسابرسی غیرقابل ویرایش هستند (Audit logs are immutable)';
      END
    `);
    console.log("🔒 Trigger جلوگیری از ویرایش audit_logs ساخته شد");
  }

  if (!existingTriggers.has("trg_audit_logs_no_delete")) {
    await pool.query(`
      CREATE TRIGGER trg_audit_logs_no_delete
      BEFORE DELETE ON audit_logs
      FOR EACH ROW
      BEGIN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ثبت‌های حسابرسی غیرقابل حذف هستند (Audit logs cannot be deleted)';
      END
    `);
    console.log("🔒 Trigger جلوگیری از حذف audit_logs ساخته شد");
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS settings (
      \`key\` VARCHAR(100) PRIMARY KEY,
      value TEXT NULL,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS contacts (
      id INT AUTO_INCREMENT PRIMARY KEY,
      fullName VARCHAR(150) NOT NULL,
      phone VARCHAR(30) NULL,
      email VARCHAR(150) NULL,
      message TEXT NOT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب دیتابیس‌های قبلی: ستون «وضعیت» (خوانده‌شده/نخوانده) برای ماژول
  // «مدیریت پیام‌های تماس با ما» در داشبورد ادمین. پیام‌های قبلی همگی status = 'unread'
  // می‌گیرند (رفتار پیش‌فرض ستون) تا هیچ پیامی از دست نرود.
  const [contactColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'contacts'`,
    [DB_NAME]
  );
  const existingContactColumns = new Set(contactColumns.map((c) => c.COLUMN_NAME));
  if (!existingContactColumns.has("status")) {
    await pool.query(
      "ALTER TABLE contacts ADD COLUMN status ENUM('unread','read') NOT NULL DEFAULT 'unread'"
    );
  }

  // ارتقای غیرمخرب برای «صندوق پیام‌ها» (Inbox) در داشبورد ادمین: نوع پیام، موضوع، مهم‌بودن و
  // پاسخ‌داده‌شدن. وضعیت خوانده‌شدن همچنان همان ستون status است (تکرار نشده)؛ «مهم» و «پاسخ‌داده‌شده»
  // دو پرچم مستقل‌اند چون با خوانده/نخوانده هم‌زمان معنی دارند. پیام‌های قبلی: type='other'،
  // subject خالی، و هر دو پرچم صفر — هیچ داده‌ای از بین نمی‌رود.
  if (!existingContactColumns.has("type")) {
    await pool.query(
      "ALTER TABLE contacts ADD COLUMN type ENUM('suggestion','criticism','complaint','question','other') NOT NULL DEFAULT 'other'"
    );
  }
  if (!existingContactColumns.has("subject")) {
    await pool.query("ALTER TABLE contacts ADD COLUMN subject VARCHAR(200) NULL");
  }
  if (!existingContactColumns.has("isImportant")) {
    await pool.query("ALTER TABLE contacts ADD COLUMN isImportant TINYINT(1) NOT NULL DEFAULT 0");
  }
  if (!existingContactColumns.has("isAnswered")) {
    await pool.query("ALTER TABLE contacts ADD COLUMN isAnswered TINYINT(1) NOT NULL DEFAULT 0");
  }
  // ایندکس‌ها برای صفحه‌بندی/فیلتر سمت سرور روی هزاران پیام
  await ensureIndex(pool, DB_NAME, "contacts", "idx_contacts_createdAt", "createdAt");
  await ensureIndex(pool, DB_NAME, "contacts", "idx_contacts_status", "status, createdAt");
  await ensureIndex(pool, DB_NAME, "contacts", "idx_contacts_type", "type");

  // ---------- ماژول صورت‌حساب و فاکتور (Billing & Invoice Management) ----------
  await pool.query(`
    CREATE TABLE IF NOT EXISTS invoices (
      id INT AUTO_INCREMENT PRIMARY KEY,
      invoiceNumber VARCHAR(30) NOT NULL,
      patientId INT NOT NULL,
      doctorId INT NULL,
      appointmentId INT NULL,
      issueDate DATE NOT NULL,
      dueDate DATE NULL,
      subtotal DECIMAL(10,2) NOT NULL DEFAULT 0,
      discount DECIMAL(10,2) NOT NULL DEFAULT 0,
      tax DECIMAL(10,2) NOT NULL DEFAULT 0,
      totalAmount DECIMAL(10,2) NOT NULL DEFAULT 0,
      paidAmount DECIMAL(10,2) NOT NULL DEFAULT 0,
      status VARCHAR(20) NOT NULL DEFAULT 'unpaid',
      notes TEXT NULL,
      createdByUserId INT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_invoices_invoiceNumber (invoiceNumber),
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE SET NULL,
      FOREIGN KEY (appointmentId) REFERENCES appointments(id) ON DELETE SET NULL,
      FOREIGN KEY (createdByUserId) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب: گردش کار تایید فاکتور (Invoice Approval Workflow) — وضعیت تایید
  // جدا از وضعیت پرداخت (status) نگه‌داری می‌شود تا منطق محاسبه‌ی خودکار وضعیت پرداخت
  // (computeStatus در models/Invoice.js) دست‌نخورده بماند؛ فقط ادمین/سوپرادمین می‌تواند
  // فاکتور را تایید کند (RBAC روی سطح روتر در routes/billing.js اعمال شده است).
  const [invoiceColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'invoices'`,
    [DB_NAME]
  );
  const existingInvoiceColumns = new Set(invoiceColumns.map((c) => c.COLUMN_NAME));
  if (!existingInvoiceColumns.has("approvalStatus")) {
    await pool.query(
      "ALTER TABLE invoices ADD COLUMN approvalStatus ENUM('pending','approved') NOT NULL DEFAULT 'pending'"
    );
  }
  if (!existingInvoiceColumns.has("approvedByUserId")) {
    await pool.query("ALTER TABLE invoices ADD COLUMN approvedByUserId INT NULL");
    await pool.query(
      "ALTER TABLE invoices ADD CONSTRAINT fk_invoices_approvedByUserId FOREIGN KEY (approvedByUserId) REFERENCES users(id) ON DELETE SET NULL"
    );
  }
  if (!existingInvoiceColumns.has("approvedAt")) {
    await pool.query("ALTER TABLE invoices ADD COLUMN approvedAt DATETIME NULL");
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS invoice_items (
      id INT AUTO_INCREMENT PRIMARY KEY,
      invoiceId INT NOT NULL,
      description VARCHAR(255) NOT NULL,
      quantity DECIMAL(10,2) NOT NULL DEFAULT 1,
      unitPrice DECIMAL(10,2) NOT NULL DEFAULT 0,
      amount DECIMAL(10,2) NOT NULL DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS payments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      invoiceId INT NOT NULL,
      amount DECIMAL(10,2) NOT NULL,
      method VARCHAR(20) NOT NULL DEFAULT 'cash',
      paidAt DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      reference VARCHAR(100) NULL,
      receivedByUserId INT NULL,
      notes TEXT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE,
      FOREIGN KEY (receivedByUserId) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);
}

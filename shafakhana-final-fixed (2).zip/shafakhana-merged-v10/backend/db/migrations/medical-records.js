export async function migrateMedicalRecords(pool, DB_NAME) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS medical_records (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NULL,
      appointmentId INT NULL,
      diagnosis TEXT NULL,
      prescription TEXT NULL,
      notes TEXT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب: ستون updatedAt روی medical_records (تا داکتر بتواند رکورد را ویرایش کند
  // و زمان آخرین ویرایش هم ثبت شود)
  const [medicalRecordColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'medical_records'`,
    [DB_NAME]
  );
  if (!medicalRecordColumns.some((c) => c.COLUMN_NAME === "updatedAt")) {
    await pool.query(
      "ALTER TABLE medical_records ADD COLUMN updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    );
  }

  // ارتقای غیرمخرب: ستون‌های ویزیت بالینی روی medical_records (visitDate, symptoms,
  // bloodPressure, temperature, height, weight, labResults, treatment). این ستون‌ها در
  // models/MedicalRecord.js (createRecord/updateRecord) و در فرم «پرونده صحی» سمت داکتر
  // استفاده می‌شوند و در database_full.sql هم تعریف شده‌اند، اما در ساخت اولیه‌ی جدول در همین
  // فایل (بالا) وجود نداشتند؛ نبودشان باعث خطای MySQL «Unknown column ... in field list»
  // و در نتیجه خطای ۵۰۰ هنگام ثبت/ویرایش پرونده صحی توسط داکتر می‌شد.
  const missingMedicalRecordColumns = [
    { name: "visitDate", ddl: "DATE NOT NULL DEFAULT (CURRENT_DATE)" },
    { name: "symptoms", ddl: "TEXT NULL" },
    { name: "bloodPressure", ddl: "VARCHAR(20) NULL" },
    { name: "temperature", ddl: "VARCHAR(20) NULL" },
    { name: "height", ddl: "VARCHAR(20) NULL" },
    { name: "weight", ddl: "VARCHAR(20) NULL" },
    { name: "labResults", ddl: "TEXT NULL" },
    { name: "treatment", ddl: "TEXT NULL" },
  ];
  for (const col of missingMedicalRecordColumns) {
    if (!medicalRecordColumns.some((c) => c.COLUMN_NAME === col.name)) {
      await pool.query(`ALTER TABLE medical_records ADD COLUMN ${col.name} ${col.ddl}`);
    }
  }

  // ارتقای غیرمخرب برای فرم «افزودن پرونده صحی» (پنل داکتر → بیماران من): ستون‌های جدید روی همان
  // جدول ویزیت‌ها (medical_records) اضافه می‌شوند — جدول موازی ساخته نمی‌شود. «تشخیص نهایی» همان
  // ستون موجود diagnosis و «علائم و شرح حال فعلی» همان symptoms است. رکوردهای قدیمی: status='registered'
  // (مثل رفتار قبلی برای بیمار قابل‌مشاهده)، بقیه‌ی ستون‌ها NULL — هیچ داده‌ای از بین نمی‌رود.
  const newEncounterColumns = [
    { name: "status", ddl: "ENUM('draft','registered') NOT NULL DEFAULT 'registered'" }, // draft = پیش‌نویس (فقط برای داکتر)
    { name: "visitReason", ddl: "VARCHAR(500) NULL" }, // دلیل اصلی مراجعه
    { name: "chiefComplaint", ddl: "TEXT NULL" }, // شکایت اصلی
    { name: "pulse", ddl: "VARCHAR(20) NULL" },
    { name: "respiratoryRate", ddl: "VARCHAR(20) NULL" },
    { name: "spo2", ddl: "VARCHAR(20) NULL" },
    { name: "generalCondition", ddl: "VARCHAR(100) NULL" }, // وضعیت عمومی مریض
    { name: "examFindings", ddl: "TEXT NULL" }, // یافته‌های معاینه
    { name: "systemsReview", ddl: "TEXT NULL" }, // JSON: سیستم‌های مورد بررسی {key:{abnormal:boolean,note:string}}
    { name: "abnormalFindings", ddl: "TEXT NULL" },
    { name: "examNotes", ddl: "TEXT NULL" }, // سایر توضیحات پزشکی (فقط داکتر)
    { name: "primaryDiagnosis", ddl: "VARCHAR(500) NULL" }, // تشخیص اولیه (تشخیص نهایی = ستون diagnosis)
    { name: "diagnosisNotes", ddl: "TEXT NULL" },
    { name: "recommendations", ddl: "TEXT NULL" }, // JSON: توصیه‌ها/مراقبت/رژیم/استراحت/آزمایش/سایر (بدون نسخه دارویی)
    { name: "followUpRequired", ddl: "TINYINT(1) NOT NULL DEFAULT 0" },
    { name: "followUpDate", ddl: "DATE NULL" },
    { name: "followUpStatus", ddl: "VARCHAR(20) NULL" }, // pending | scheduled | completed | cancelled
    { name: "followUpNotes", ddl: "TEXT NULL" },
    { name: "sentToPatientAt", ddl: "DATETIME NULL" }, // زمان ارسال گزارش به بیمار (NULL = ارسال نشده)
    { name: "sentNote", ddl: "TEXT NULL" }, // توضیح کوتاه داکتر همراه پرونده
  ];
  for (const col of newEncounterColumns) {
    if (!medicalRecordColumns.some((c) => c.COLUMN_NAME === col.name)) {
      await pool.query(`ALTER TABLE medical_records ADD COLUMN ${col.name} ${col.ddl}`);
    }
  }
  const [mrIndexes] = await pool.query(
    `SELECT INDEX_NAME FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'medical_records' AND INDEX_NAME = 'idx_medical_records_patient_status'`,
    [DB_NAME]
  );
  if (mrIndexes.length === 0) {
    await pool.query("ALTER TABLE medical_records ADD INDEX idx_medical_records_patient_status (patientId, status)");
  }

  // تصاویر پزشکی و اسناد/فایل‌های هر پرونده صحی — قبلاً هیچ ساختاری برای آپلود چندفایلی متصل به ویزیت نبود
  // (lab_results فقط یک گزارش و radiology_reports فقط یک imageUrl متنی دارد). فایل‌ها در پوشه‌ی خصوصی
  // ذخیره می‌شوند و فقط از مسیرهای احرازهویت‌شده قابل‌دسترسی‌اند.
  await pool.query(`
    CREATE TABLE IF NOT EXISTS medical_record_files (
      id INT AUTO_INCREMENT PRIMARY KEY,
      recordId INT NOT NULL,
      patientId INT NOT NULL,
      doctorId INT NULL,
      kind ENUM('image','document') NOT NULL,
      category VARCHAR(30) NOT NULL DEFAULT 'other',
      title VARCHAR(150) NOT NULL,
      fileDate DATE NULL,
      description TEXT NULL,
      originalName VARCHAR(255) NOT NULL,
      storedName VARCHAR(100) NOT NULL,
      mimeType VARCHAR(100) NOT NULL,
      sizeBytes INT NOT NULL DEFAULT 0,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_mrf_record (recordId),
      INDEX idx_mrf_patient (patientId),
      FOREIGN KEY (recordId) REFERENCES medical_records(id) ON DELETE CASCADE,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  // ---------- پرونده الکترونیک صحی (EMR) — جدول‌های تخصصی ----------
  // هرکدام از این جدول‌ها به یک بیمار (patientId) و در صورت وجود به یک داکتر (doctorId)
  // و یک ویزیت/رکورد کلی (recordId از medical_records) متصل می‌شوند.

  await pool.query(`
    CREATE TABLE IF NOT EXISTS diagnoses (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NULL,
      recordId INT NULL,
      title VARCHAR(255) NOT NULL,
      description TEXT NULL,
      icdCode VARCHAR(20) NULL,
      status ENUM('active','resolved') NOT NULL DEFAULT 'active',
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE SET NULL,
      FOREIGN KEY (recordId) REFERENCES medical_records(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS prescriptions (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NULL,
      recordId INT NULL,
      appointmentId INT NULL,
      medicationName VARCHAR(150) NOT NULL,
      dosage VARCHAR(100) NULL,
      frequency VARCHAR(100) NULL,
      duration VARCHAR(100) NULL,
      instructions TEXT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE SET NULL,
      FOREIGN KEY (recordId) REFERENCES medical_records(id) ON DELETE SET NULL,
      FOREIGN KEY (appointmentId) REFERENCES appointments(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب: ستون appointmentId روی prescriptions (اتصال مستقیم نسخه به نوبت مربوطه —
  // برای دیتابیس‌هایی که پیش از این جدول prescriptions را بدون این ستون ساخته‌اند)
  const [prescriptionColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'prescriptions'`,
    [DB_NAME]
  );
  if (!prescriptionColumns.some((c) => c.COLUMN_NAME === "appointmentId")) {
    await pool.query("ALTER TABLE prescriptions ADD COLUMN appointmentId INT NULL");
    await pool.query(
      "ALTER TABLE prescriptions ADD CONSTRAINT fk_prescriptions_appointmentId FOREIGN KEY (appointmentId) REFERENCES appointments(id) ON DELETE SET NULL"
    );
  }

  // ارتقای غیرمخرب: ستون‌های diagnosis/followUpDate/notes روی prescriptions. این ستون‌ها
  // در models/Prescription.js (createPrescription/updatePrescription) و در فرم «نسخه‌ها»
  // سمت داکتر استفاده می‌شوند و در database_full.sql هم تعریف شده‌اند، اما در ساخت اولیه‌ی جدول
  // در همین فایل (بالا) وجود نداشتند؛ نبودشان باعث خطای MySQL «Unknown column ... in field
  // list» و در نتیجه خطای ۵۰۰ هنگام ثبت/ویرایش نسخه توسط داکتر می‌شد.
  const missingPrescriptionColumns = [
    { name: "diagnosis", ddl: "TEXT NULL" },
    { name: "followUpDate", ddl: "DATE NULL" },
    { name: "notes", ddl: "TEXT NULL" },
    // شناسه‌ی گروه نسخه: وقتی داکتر چند دارو را در یک بار «ثبت نسخه» می‌نویسد، همه‌ی رکوردها
    // groupId یکسان می‌گیرند تا PDF نسخه همه‌ی داروهای آن را یک‌جا چاپ کند
    { name: "groupId", ddl: "VARCHAR(36) NULL" },
    // وضعیت نسخه (پنل ادمین «نسخه و سوابق طبی»): active = در حال اجرا، completed = تکمیل‌شده،
    // cancelled = لغوشده. نسخه‌های قبلی به‌صورت پیش‌فرض «در حال اجرا» می‌شوند و هیچ داده‌ای حذف نمی‌شود.
    { name: "status", ddl: "VARCHAR(20) NOT NULL DEFAULT 'active'" },
    // پنل داکتر «نسخه و سوابق طبی»: تعداد (مثلاً ۲۰ عدد) و توضیحاتِ مخصوص هر دارو.
    // «دستورالعمل/یادداشت» قبلی مشترک کل نسخه است و دست‌نخورده می‌ماند.
    { name: "quantity", ddl: "VARCHAR(50) NULL" },
    { name: "medicineNotes", ddl: "VARCHAR(500) NULL" },
  ];
  for (const col of missingPrescriptionColumns) {
    if (!prescriptionColumns.some((c) => c.COLUMN_NAME === col.name)) {
      await pool.query(`ALTER TABLE prescriptions ADD COLUMN ${col.name} ${col.ddl}`);
    }
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS allergies (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NULL,
      allergen VARCHAR(150) NOT NULL,
      reaction VARCHAR(255) NULL,
      severity ENUM('mild','moderate','severe') NOT NULL DEFAULT 'mild',
      notes TEXT NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS lab_results (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NULL,
      recordId INT NULL,
      testName VARCHAR(150) NOT NULL,
      result TEXT NULL,
      unit VARCHAR(50) NULL,
      referenceRange VARCHAR(100) NULL,
      status ENUM('pending','completed') NOT NULL DEFAULT 'completed',
      testDate DATE NULL,
      reportUrl VARCHAR(255) NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE SET NULL,
      FOREIGN KEY (recordId) REFERENCES medical_records(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);

  // ارتقای غیرمخرب: ستون reportUrl روی lab_results (برای دیتابیس‌هایی که پیش از این
  // جدول lab_results را بدون این ستون ساخته‌اند — الزام «آپلود گزارش آزمایشگاهی»)
  const [labResultColumns] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = 'lab_results'`,
    [DB_NAME]
  );
  if (!labResultColumns.some((c) => c.COLUMN_NAME === "reportUrl")) {
    await pool.query("ALTER TABLE lab_results ADD COLUMN reportUrl VARCHAR(255) NULL");
  }

  await pool.query(`
    CREATE TABLE IF NOT EXISTS radiology_reports (
      id INT AUTO_INCREMENT PRIMARY KEY,
      patientId INT NOT NULL,
      doctorId INT NULL,
      recordId INT NULL,
      examType VARCHAR(150) NOT NULL,
      findings TEXT NULL,
      impression TEXT NULL,
      imageUrl VARCHAR(255) NULL,
      examDate DATE NULL,
      createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (patientId) REFERENCES patients(id) ON DELETE CASCADE,
      FOREIGN KEY (doctorId) REFERENCES doctors(id) ON DELETE SET NULL,
      FOREIGN KEY (recordId) REFERENCES medical_records(id) ON DELETE SET NULL
    ) ENGINE=InnoDB
  `);
}

// ساخت/به‌روزرسانی حساب سوپرادمین — اجرا: node db/createSuperAdmin.js <email> <password> ["نام کامل"]
// حساب دائمی است (بدون اجبار تغییر رمز). اگر ایمیل از قبل وجود داشته باشد، نقش به superadmin ارتقا می‌یابد و رمز عوض می‌شود.
import "../loadEnv.js";
import bcrypt from "bcryptjs";
import pool from "../db.js";

const [email, password, fullName = "مدیر کل سیستم"] = process.argv.slice(2);
if (!email || !password || password.length < 12) {
  console.error("استفاده: node db/createSuperAdmin.js <email> <password(حداقل ۱۲ کاراکتر)> [نام]");
  process.exit(1);
}
const hash = bcrypt.hashSync(password, Number(process.env.BCRYPT_SALT_ROUNDS) || 12);
const [rows] = await pool.query("SELECT id FROM users WHERE email = ?", [email]);
if (rows.length) {
  await pool.query(
    "UPDATE users SET password = ?, role = 'superadmin', isVerified = 1, isActive = 1, mustChangePassword = 0, failedLoginAttempts = 0 WHERE id = ?",
    [hash, rows[0].id]
  );
  console.log("✅ حساب موجود به سوپرادمین ارتقا یافت:", email);
} else {
  await pool.query(
    "INSERT INTO users (fullName, email, password, role, isVerified, mustChangePassword) VALUES (?, ?, ?, 'superadmin', 1, 0)",
    [fullName, email, hash]
  );
  console.log("✅ سوپرادمین جدید ساخته شد:", email);
}
process.exit(0);

// ---------- مهاجرت‌های نسخه‌دار دیتابیس ----------
// مهاجرت‌های قدیمیِ «ایدمپوتنت» (db/migrations/*.js) همچنان هنگام راه‌اندازی اجرا می‌شوند و پایه‌ی
// ساختارند. هر تغییر ساختاریِ جدید باید به‌صورت یک فایل شماره‌دار در db/migrations/versions/ بیاید:
//     0002_add_something.js   →   export async function up(pool, dbName) {...}
//                                 export async function down(pool, dbName) {...}   // اختیاری
// اجراکننده: ترتیب عددی، ثبت در جدول schema_migrations همراه checksum، قفل سراسری (GET_LOCK) برای
// جلوگیری از اجرای هم‌زمان در چند instance، و خطا اگر فایلِ قبلاً اجراشده بعداً تغییر کرده باشد.
import fs from "fs";
import fsp from "fs/promises";
import path from "path";
import crypto from "crypto";
import { fileURLToPath, pathToFileURL } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const DEFAULT_DIR = path.join(__dirname, "migrations", "versions");
const FILE_PATTERN = /^(\d{4})_([a-z0-9_]+)\.js$/;
const LOCK_NAME = "shafakhana_schema_migrations";

export const checksumOf = (content) => crypto.createHash("sha256").update(content).digest("hex");

export async function listMigrationFiles(dir = DEFAULT_DIR) {
  if (!fs.existsSync(dir)) return [];
  const names = (await fsp.readdir(dir)).filter((n) => FILE_PATTERN.test(n)).sort();
  const versions = new Set();
  const out = [];
  for (const file of names) {
    const [, version, name] = file.match(FILE_PATTERN);
    if (versions.has(version)) throw new Error(`شماره‌ی مهاجرت تکراری است: ${version}`);
    versions.add(version);
    const content = await fsp.readFile(path.join(dir, file), "utf8");
    out.push({ version, name, file, path: path.join(dir, file), checksum: checksumOf(content) });
  }
  return out;
}

async function ensureTable(pool) {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version VARCHAR(10) PRIMARY KEY,
      name VARCHAR(190) NOT NULL,
      checksum CHAR(64) NOT NULL,
      appliedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);
}

export async function getStatus(pool, { dir = DEFAULT_DIR } = {}) {
  await ensureTable(pool);
  const files = await listMigrationFiles(dir);
  const [rows] = await pool.query("SELECT version, checksum FROM schema_migrations");
  const applied = new Map(rows.map((r) => [r.version, r.checksum]));
  return files.map((f) => ({
    ...f,
    state: !applied.has(f.version) ? "pending" : applied.get(f.version) === f.checksum ? "applied" : "modified",
  }));
}

async function withLock(pool, fn) {
  const conn = await pool.getConnection();
  try {
    const [[{ got }]] = await conn.query("SELECT GET_LOCK(?, 60) AS got", [LOCK_NAME]);
    if (got !== 1) throw new Error("قفل مهاجرت‌ها در ۶۰ ثانیه آزاد نشد (instance دیگری در حال مهاجرت است)");
    try {
      return await fn();
    } finally {
      await conn.query("SELECT RELEASE_LOCK(?)", [LOCK_NAME]).catch(() => {});
    }
  } finally {
    conn.release();
  }
}

export async function runMigrations(pool, dbName, { dir = DEFAULT_DIR, log = console.log } = {}) {
  return withLock(pool, async () => {
    const status = await getStatus(pool, { dir });
    const modified = status.filter((s) => s.state === "modified");
    if (modified.length) {
      throw new Error(`مهاجرت اجراشده تغییر کرده است (باید فایل جدید بسازید، نه ویرایش قدیمی): ${modified.map((m) => m.file).join(", ")}`);
    }
    const ran = [];
    for (const m of status.filter((s) => s.state === "pending")) {
      const mod = await import(pathToFileURL(m.path).href);
      if (typeof mod.up !== "function") throw new Error(`مهاجرت ${m.file} تابع up ندارد`);
      log(`⬆️  مهاجرت ${m.version}_${m.name}`);
      await mod.up(pool, dbName);
      await pool.query("INSERT INTO schema_migrations (version, name, checksum) VALUES (?, ?, ?)", [m.version, m.name, m.checksum]);
      ran.push(m.version);
    }
    return ran;
  });
}

// آخرین مهاجرتِ اجراشده را (در صورت داشتن down) برمی‌گرداند
export async function rollbackLast(pool, dbName, { dir = DEFAULT_DIR, log = console.log } = {}) {
  return withLock(pool, async () => {
    await ensureTable(pool);
    const [rows] = await pool.query("SELECT version FROM schema_migrations ORDER BY version DESC LIMIT 1");
    if (!rows[0]) return null;
    const files = await listMigrationFiles(dir);
    const m = files.find((f) => f.version === rows[0].version);
    if (!m) throw new Error(`فایل مهاجرت ${rows[0].version} پیدا نشد`);
    const mod = await import(pathToFileURL(m.path).href);
    if (typeof mod.down !== "function") throw new Error(`مهاجرت ${m.file} تابع down ندارد`);
    log(`⬇️  بازگردانی ${m.version}_${m.name}`);
    await mod.down(pool, dbName);
    await pool.query("DELETE FROM schema_migrations WHERE version = ?", [m.version]);
    return m.version;
  });
}

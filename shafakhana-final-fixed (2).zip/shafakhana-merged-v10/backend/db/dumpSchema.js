// تولید «اسکیمای فعلی» از روی دیتابیس واقعی (فقط ساختار، بدون داده):  node db/dumpSchema.js > schema.sql
// به‌جای نگه‌داشتن دستی database_full.sql که با مهاجرت‌ها ناهماهنگ می‌شود، این فایل را از دیتابیسِ
// مهاجرت‌شده بسازید. (راه‌اندازی عادی پروژه به هیچ‌کدام نیاز ندارد؛ db.js خودش اسکیما را می‌سازد.)
import "../loadEnv.js";
import mysql from "mysql2/promise";
import { getPool } from "../db.js";

const pool = await getPool();
try {
  const [tables] = await pool.query("SELECT TABLE_NAME AS name FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME");
  console.log(`-- اسکیمای تولیدشده در ${new Date().toISOString()} — فقط ساختار\nSET FOREIGN_KEY_CHECKS = 0;\n`);
  for (const { name } of tables) {
    const [[row]] = await pool.query(`SHOW CREATE TABLE ${mysql.escapeId(name)}`);
    console.log(`DROP TABLE IF EXISTS ${mysql.escapeId(name)};\n${row["Create Table"]};\n`);
  }
  console.log("SET FOREIGN_KEY_CHECKS = 1;");
} finally {
  await pool.end();
}

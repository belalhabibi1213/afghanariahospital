// توابع کمکی مشترک بین فایل‌های مهاجرت (migrations) دیتابیس.
//
// این دو تابع فقط در صورتی ایندکس را می‌سازند که از قبل وجود نداشته باشد، بنابراین اجرای
// دوباره‌ی initDb روی دیتابیس‌های قبلی بدون خطا و بدون از دست رفتن داده انجام می‌شود. قبلاً این
// دو تابع درون خودِ initDb (با closure روی pool/DB_NAME) تعریف شده بودند؛ چون حالا چند فایل
// مهاجرت جداگانه به آن‌ها نیاز دارند، pool و DB_NAME به‌صورت صریح پاس داده می‌شوند.

export async function ensureIndex(pool, DB_NAME, table, indexName, columns) {
  const [rows] = await pool.query(
    `SELECT COUNT(*) AS count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?`,
    [DB_NAME, table, indexName]
  );
  if (rows[0].count === 0) {
    await pool.query(`ALTER TABLE \`${table}\` ADD INDEX \`${indexName}\` (${columns})`);
    console.log(`⚡ ایندکس ${indexName} روی جدول ${table} ساخته شد (بهینه‌سازی جستجو)`);
  }
}

// نسخه‌ی FULLTEXT همان تابع بالا — مخصوص ستون‌های متنی (VARCHAR/TEXT) که «جستجوی سراسری»
// هدر (GET /api/search) روی آن‌ها MATCH...AGAINST اجرا می‌کند؛ بدون این ایندکس، هر جستجو
// معادل یک full table scan با LIKE '%...%' روی هر جدول می‌بود.
export async function ensureFullTextIndex(pool, DB_NAME, table, indexName, columns) {
  const [rows] = await pool.query(
    `SELECT COUNT(*) AS count FROM information_schema.STATISTICS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND INDEX_NAME = ?`,
    [DB_NAME, table, indexName]
  );
  if (rows[0].count === 0) {
    await pool.query(`ALTER TABLE \`${table}\` ADD FULLTEXT INDEX \`${indexName}\` (${columns})`);
    console.log(`🔎 ایندکس تمام‌متنی ${indexName} روی جدول ${table} ساخته شد (بهینه‌سازی جستجوی سراسری)`);
  }
}

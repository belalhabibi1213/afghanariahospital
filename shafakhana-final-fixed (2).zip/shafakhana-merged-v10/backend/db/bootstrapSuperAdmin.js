// ساخت مدیر کل اولیه از متغیرهای محیطی — برای هاست‌هایی که شل ندارند (مثل Render رایگان).
// فقط وقتی کار می‌کند که BOOTSTRAP_SUPERADMIN_EMAIL و BOOTSTRAP_SUPERADMIN_PASSWORD (حداقل ۱۲ کاراکتر) تنظیم باشند
// و هیچ سوپرادمینی در دیتابیس وجود نداشته باشد. بعد از اولین ورود موفق، این دو متغیر را حتماً از تنظیمات حذف کنید.
import bcrypt from "bcryptjs";
import { getPool } from "../db.js";

export async function bootstrapSuperAdminFromEnv() {
  const email = (process.env.BOOTSTRAP_SUPERADMIN_EMAIL || "").trim().toLowerCase();
  const password = process.env.BOOTSTRAP_SUPERADMIN_PASSWORD || "";
  const fullName = (process.env.BOOTSTRAP_SUPERADMIN_NAME || "مدیر کل سیستم").trim();
  if (!email && !password) return;
  if (!email || password.length < 12) {
    console.warn("⚠️  BOOTSTRAP_SUPERADMIN: ایمیل لازم است و رمز باید حداقل ۱۲ کاراکتر باشد؛ مدیر کل ساخته نشد.");
    return;
  }
  const pool = await getPool();
  const [existing] = await pool.query("SELECT id FROM users WHERE role = 'superadmin' LIMIT 1");
  if (existing.length) {
    console.log("ℹ️  مدیر کل از قبل وجود دارد؛ BOOTSTRAP_SUPERADMIN_* نادیده گرفته شد (می‌توانید این متغیرها را حذف کنید).");
    return;
  }
  const hash = bcrypt.hashSync(password, Number(process.env.BCRYPT_SALT_ROUNDS) || 12);
  const [byEmail] = await pool.query("SELECT id FROM users WHERE email = ?", [email]);
  if (byEmail.length) {
    await pool.query(
      "UPDATE users SET password = ?, role = 'superadmin', isVerified = 1, isActive = 1, mustChangePassword = 0, failedLoginAttempts = 0 WHERE id = ?",
      [hash, byEmail[0].id]
    );
  } else {
    await pool.query(
      "INSERT INTO users (fullName, email, password, role, isVerified, mustChangePassword) VALUES (?, ?, ?, 'superadmin', 1, 0)",
      [fullName, email, hash]
    );
  }
  console.log(`✅ مدیر کل اولیه ساخته شد: ${email} — اکنون BOOTSTRAP_SUPERADMIN_* را از تنظیمات حذف کنید.`);
}

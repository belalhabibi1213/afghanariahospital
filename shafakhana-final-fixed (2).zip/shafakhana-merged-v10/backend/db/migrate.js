// استفاده:  node db/migrate.js [status|up|down]     (npm run migrate -- status)
import "../loadEnv.js";
import { getPool } from "../db.js";
import { getStatus, runMigrations, rollbackLast } from "./migrator.js";

const cmd = process.argv[2] || "status";
const dbName = process.env.DB_NAME || "shafakhana";
const pool = await getPool();
try {
  if (cmd === "status") {
    for (const s of await getStatus(pool)) console.log(`${s.state.padEnd(9)} ${s.file}`);
  } else if (cmd === "up") {
    console.log("اجرا شد:", (await runMigrations(pool, dbName)).join(", ") || "مورد جدیدی نبود");
  } else if (cmd === "down") {
    console.log("بازگردانده شد:", (await rollbackLast(pool, dbName)) || "چیزی برای بازگرداندن نبود");
  } else {
    console.error("دستور نامعتبر. از status | up | down استفاده کنید.");
    process.exitCode = 1;
  }
} finally {
  await pool.end();
}

// بازه‌های زمانی آماده برای فیلتر «تاریخ» (امروز / این هفته / این ماه) در پنل داکتر.
// «امروز» بر اساس منطقه‌ی زمانی تنظیمات سیستم محاسبه می‌شود (نه ساعت سرور)، مثل بقیه‌ی سیستم.
// هفته از «شنبه» شروع می‌شود و تا «جمعه» ادامه دارد (هفته‌ی کاری افغانستان).
import { nowInTimeZone } from "../models/Schedule.js";
import { gregorianToJalali, jalaliToGregorian, jalaliMonthLength, toISODate } from "./jalali.js";

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

export function isIsoDate(value) {
  if (typeof value !== "string" || !ISO_DATE.test(value)) return false;
  const [y, m, d] = value.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

function toIso(dt) {
  return dt.toISOString().slice(0, 10);
}

function parseIso(iso) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d));
}

// { today, weekFrom, weekTo, monthFrom, monthTo } — همه YYYY-MM-DD
export function currentPeriods(timeZone) {
  const today = nowInTimeZone(timeZone).date;
  const t = parseIso(today);
  // getUTCDay: یکشنبه=۰ ... جمعه=۵، شنبه=۶  →  فاصله تا شنبه‌ی گذشته
  const sinceSaturday = (t.getUTCDay() + 1) % 7;
  const weekStart = new Date(t.getTime() - sinceSaturday * 86400000);
  const weekEnd = new Date(weekStart.getTime() + 6 * 86400000);
  // «این ماه» = ماه هجری شمسی جاری (از ۱ تا آخرین روز همان ماه شمسی)، نه ماه میلادی
  const j = gregorianToJalali(t.getUTCFullYear(), t.getUTCMonth() + 1, t.getUTCDate());
  const mFrom = jalaliToGregorian(j.jy, j.jm, 1);
  const mTo = jalaliToGregorian(j.jy, j.jm, jalaliMonthLength(j.jy, j.jm));
  return {
    today,
    weekFrom: toIso(weekStart),
    weekTo: toIso(weekEnd),
    monthFrom: toISODate(mFrom.gy, mFrom.gm, mFrom.gd),
    monthTo: toISODate(mTo.gy, mTo.gm, mTo.gd),
  };
}

// تبدیل پارامترهای کوئری (range / from / to) به { dateFrom, dateTo } معتبر.
// مقدار نامعتبر نادیده گرفته می‌شود (بدون خطا) تا فیلتر خراب، کل لیست را خالی نکند.
export function resolveDateRange({ range, from, to } = {}, timeZone) {
  const p = currentPeriods(timeZone);
  if (range === "today") return { dateFrom: p.today, dateTo: p.today };
  if (range === "week") return { dateFrom: p.weekFrom, dateTo: p.weekTo };
  if (range === "month") return { dateFrom: p.monthFrom, dateTo: p.monthTo };
  return {
    dateFrom: isIsoDate(from) ? from : undefined,
    dateTo: isIsoDate(to) ? to : undefined,
  };
}

// «%» و «_» و «\» داخل عبارت جستجو باید به‌صورت متن عادی جستجو شوند، نه الگوی LIKE
export function escapeLike(term) {
  return String(term).replace(/[\\%_]/g, (c) => `\\${c}`);
}

import crypto from "crypto";

// سیاست رمز عبور مشترک — منبع واحد قوانین رمز عبور برای تمام مسیرهای مرتبط:
// ثبت‌نام کاربر (authController.register)، ساخت حساب ادمین (superadminController.createAdmin)،
// ساخت حساب داکتر (adminController.createDoctorAccount)، بازیابی رمز عبور
// (authController.resetPassword) و تغییر رمز عبور (userController.changePassword).
// معادل فرانت‌اند این فایل: frontend/src/utils/passwordPolicy.js — هر تغییری در این
// قوانین باید در هر دو سمت اعمال شود تا پیام‌های اعتبارسنجی frontend/backend هم‌خوان بمانند.
//
// قانون فعلی (تعمداً ساده نگه داشته شده): فقط حداقل طول ۸ کاراکتر الزامی است.
// حداکثر طول ۷۲ (حد bcrypt)، و رمزهای بسیار رایج رد می‌شوند. حروف بزرگ/کوچک/عدد/کاراکتر خاص هیچ‌کدام اجباری نیستند (اما مجازند).
// فقط حروف انگلیسی، اعداد و کاراکترهای خاص مجاز مجاز هستند؛ حروف فارسی/عربی/یونیکد
// سایر زبان‌ها و فاصله رد می‌شوند.

const MIN_PASSWORD_LENGTH = 8;

// فقط این کاراکترها مجاز هستند: حروف انگلیسی (A-Z, a-z)، اعداد (0-9) و
// کاراکترهای خاص رایج: @ # $ % & * ! _ - + و چند کاراکتر خاص دیگر
// (بدون فاصله، بدون حروف فارسی/عربی/یونیکد سایر زبان‌ها، بدون ایموجی)
const ALLOWED_CHARS_REGEX = /^[A-Za-z0-9!@#$%^&*()_+\-=?.,]*$/;


// رمزهای بسیار رایج (حدس‌زدنی در چند ثانیه) رد می‌شوند؛ فهرست عمداً کوتاه و دقیق است.
const COMMON_PASSWORDS = new Set([
  "12345678", "123456789", "1234567890", "11111111", "00000000", "12341234", "87654321",
  "password", "password1", "password123", "passw0rd", "qwerty123", "qwertyuiop", "1q2w3e4r",
  "iloveyou", "abc12345", "admin123", "admin1234", "welcome1", "letmein123",
]);
// bcrypt فقط ۷۲ بایت اول رمز را در نظر می‌گیرد؛ رمز بلندتر بی‌صدا بریده می‌شد و امنیت کاذب می‌داد.
const MAX_PASSWORD_LENGTH = 72;
const COMMON_PASSWORD_MESSAGE = "این رمز عبور بسیار رایج و قابل حدس است؛ رمز دیگری انتخاب کنید.";
const TOO_LONG_PASSWORD_MESSAGE = "رمز عبور نباید بیشتر از ۷۲ کاراکتر باشد.";

export const PASSWORD_POLICY_MESSAGE =
  "رمز عبور باید حداقل ۸ کاراکتر باشد و فقط از حروف انگلیسی، اعداد و کاراکترهای مجاز استفاده کند.";

/**
 * رمز عبور را طبق سیاست بالا بررسی می‌کند.
 * @param {unknown} password
 * @returns {string|null} پیام خطا در صورت نامعتبر بودن، یا null در صورت معتبر بودن
 */
export function getPasswordPolicyError(password) {
  if (typeof password !== "string" || password.length === 0) {
    return "رمز عبور الزامی است";
  }
  if (password.length < MIN_PASSWORD_LENGTH || !ALLOWED_CHARS_REGEX.test(password)) {
    return PASSWORD_POLICY_MESSAGE;
  }
  if (password.length > MAX_PASSWORD_LENGTH) return TOO_LONG_PASSWORD_MESSAGE;
  if (COMMON_PASSWORDS.has(password.toLowerCase())) return COMMON_PASSWORD_MESSAGE;
  return null;
}

export function isStrongPassword(password) {
  return getPasswordPolicyError(password) === null;
}

// ---------- تولید رمز عبور موقت (Reset Password توسط ادمین) ----------
// برای مواردی که ادمین به‌جای کاربر یک رمز عبور موقت می‌سازد (مثلاً بازنشانی رمز
// عبور بیمار)، رمزی تصادفی و امن تولید می‌کند که همیشه در سیاست بالا (getPasswordPolicyError)
// معتبر باشد. کاراکترهای مشابه/گیج‌کننده (I, O, l, 0, 1) عمداً حذف شده‌اند تا اگر
// ادمین رمز را تلفنی یا حضوری به بیمار اطلاع دهد، اشتباه خوانده نشود.

const TEMP_UPPER = "ABCDEFGHJKLMNPQRSTUVWXYZ";
const TEMP_LOWER = "abcdefghijkmnpqrstuvwxyz";
const TEMP_DIGITS = "23456789";
const TEMP_SPECIAL = "!@#$%^&*_-";
const TEMP_ALL = TEMP_UPPER + TEMP_LOWER + TEMP_DIGITS + TEMP_SPECIAL;

function randomFrom(charset) {
  return charset[crypto.randomInt(charset.length)];
}

export function generateTempPassword(length = 12) {
  const chars = [randomFrom(TEMP_UPPER), randomFrom(TEMP_LOWER), randomFrom(TEMP_DIGITS), randomFrom(TEMP_SPECIAL)];
  while (chars.length < length) chars.push(randomFrom(TEMP_ALL));
  // به‌هم‌ریختن ترتیب (Fisher-Yates) تا ۴ کاراکتر تضمین‌شده‌ی اول همیشه در جای ثابت نباشند
  for (let i = chars.length - 1; i > 0; i--) {
    const j = crypto.randomInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  return chars.join("");
}

import nodemailer from "nodemailer";
import { getAllSettings } from "../models/Settings.js";

import { formatJalaliDate } from "./jalali.js";
// مقادیر خام .env را trim می‌کنیم و از App Password فاصله‌ها را حذف می‌کنیم؛ چون شایع‌ترین
// دلیل واقعی «کد به ایمیل نمی‌رسد» این است که App Password گوگل با همان فاصله‌هایی که خودِ
// گوگل برای خوانایی نشان می‌دهد (مثلاً "abcd efgh ijkl mnop") در .env کپی می‌شود، یا در انتهای
// مقدار یک فاصله/خط‌جدید اضافه از کپی‌پیست باقی می‌ماند — هر دو باعث خطای EAUTH می‌شوند.
const SMTP_HOST = process.env.SMTP_HOST?.trim();
const SMTP_PORT = process.env.SMTP_PORT?.trim();
const SMTP_SECURE = process.env.SMTP_SECURE?.trim();
const SMTP_USER = process.env.SMTP_USER?.trim();
const SMTP_PASS = process.env.SMTP_PASS?.replace(/\s+/g, "");
const SMTP_FROM = process.env.SMTP_FROM?.trim();

// آدرس فرستنده: SMTP_FROM می‌تواند فقط ایمیل یا به شکل «نام <ایمیل>» باشد؛ همیشه فقط خودِ آدرس ایمیل استفاده می‌شود
// (قبلاً مقدار «نام <ایمیل>» داخل <...> تکرار می‌شد و هدر From نامعتبر می‌شد و گوگل ایمیل را رد می‌کرد).
function senderAddress() {
  const raw = SMTP_FROM || SMTP_USER || "";
  const m = raw.match(/<([^>]+)>/);
  return (m ? m[1] : raw).replace(/^["'\s]+|["'\s]+$/g, "");
}

let transporter = null;

// ارسال ایمیل از طریق API وب (HTTPS) به‌جای SMTP — برای هاست‌هایی که پورت‌های SMTP را می‌بندند (مثل Render رایگان).
// با تنظیم BREVO_API_KEY فعال می‌شود (SMTP_FROM باید یک فرستنده‌ی تأییدشده در حساب Brevo باشد).
// بقیه‌ی کد (sendMail و قالب‌ها) بدون تغییر می‌ماند، چون این یک «ترنسپورت» سفارشی nodemailer است.
function parseAddress(value) {
  const raw = typeof value === "string" ? value : value?.address ? `${value.name || ""} <${value.address}>` : "";
  const m = raw.match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/);
  return m ? { name: m[1].trim() || undefined, email: m[2].trim() } : { email: raw.trim() };
}

function createBrevoTransport(apiKey) {
  return {
    name: "brevo-api",
    version: "1.0.0",
    send(mail, callback) {
      const d = mail.data || {};
      const toList = (Array.isArray(d.to) ? d.to : [d.to]).filter(Boolean).map((t) => ({ email: parseAddress(t).email }));
      fetch("https://api.brevo.com/v3/smtp/email", {
        method: "POST",
        headers: { "api-key": apiKey, "content-type": "application/json", accept: "application/json" },
        body: JSON.stringify({ sender: parseAddress(d.from), to: toList, subject: d.subject, htmlContent: d.html, textContent: d.text }),
        signal: AbortSignal.timeout(20000),
      })
        .then(async (res) => {
          if (res.ok) return callback(null, { messageId: (await res.json().catch(() => ({}))).messageId });
          callback(new Error(`Brevo API ${res.status}: ${(await res.text().catch(() => "")).slice(0, 200)}`));
        })
        .catch((err) => callback(err));
    },
  };
}

if (process.env.BREVO_API_KEY?.trim()) {
  transporter = nodemailer.createTransport(createBrevoTransport(process.env.BREVO_API_KEY.trim()));
  console.log("✉️  ارسال ایمیل از طریق Brevo API (HTTPS) فعال است.");
} else if (SMTP_HOST && SMTP_USER && SMTP_PASS) {
  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT || 587),
    secure: SMTP_SECURE === "true",
    auth: { user: SMTP_USER, pass: SMTP_PASS },
    // اگر اینترنت/فایروال سرور پورت SMTP را ببندد، ثبت‌نام ده‌ها ثانیه منتظر نماند
    connectionTimeout: 15000,
    greetingTimeout: 15000,
    socketTimeout: 30000,
  });
}

// بررسی صحت ایمیل/پسورد گوگل (یا هر SMTP دیگری) هنگام بالا آمدن سرور.
// این تابع واقعاً به سرور گوگل وصل می‌شود و لاگین را امتحان می‌کند، بدون ارسال ایمیل.
export async function verifyMailer() {
  if (!transporter) {
    console.warn(
      "⚠️  SMTP تنظیم نشده است (SMTP_HOST / SMTP_USER / SMTP_PASS را در .env پر کنید). فعلاً کد تایید فقط در همین کنسول چاپ می‌شود."
    );
    return false;
  }

  try {
    await transporter.verify();
    console.log(`✅ اتصال به ${SMTP_HOST} با کاربر ${SMTP_USER} تایید شد؛ ایمیل کد تایید ارسال خواهد شد.`);
    return true;
  } catch (err) {
    console.error("❌ اتصال به سرور SMTP ناموفق بود؛ ایمیل کد تایید ارسال نخواهد شد.");
    if (err.code === "EAUTH") {
      console.error(
        "   دلیل: ایمیل یا پسورد اشتباه است. اگر از Gmail استفاده می‌کنید، SMTP_PASS باید یک «App Password» ۱۶ کاراکتری باشد" +
          " (از حساب گوگل > Security > 2-Step Verification > App passwords ساخته می‌شود)، نه رمز عبور معمولی جیمیل."
      );
    } else {
      console.error("   جزئیات:", err.message);
    }
    return false;
  }
}

// تنظیمات ایمیل (تنظیمات سیستم -> Super Admin) را می‌خواند. اگر دیتابیس در دسترس نبود،
// با مقادیر پیش‌فرض ادامه می‌دهد تا ارسال ایمیل هرگز به‌خاطر این کوئری کمکی متوقف نشود.
async function getEmailSettings() {
  try {
    const settings = await getAllSettings();
    return {
      fromName: settings.emailFromName || "شفاخانه افغان آریا",
      enabled: settings.emailNotificationsEnabled !== "off",
    };
  } catch {
    return { fromName: "شفاخانه افغان آریا", enabled: true };
  }
}

// ارسال ایمیل حاوی کد تایید. اگر SMTP تنظیم نشده یا ارسال با خطا مواجه شود
// (مثلاً پسورد گوگل اشتباه)، به‌جای انداختن استثنا به بیرون، کد را در کنسول
// چاپ می‌کند و وضعیت واقعی ارسال را برمی‌گرداند تا کنترلر بتواند پیام درستی به کاربر بدهد.
export async function sendVerificationEmail({ to, fullName, code }) {
  const { fromName, enabled } = await getEmailSettings();
  const subject = `کد تایید ایمیل - ${fromName}`;
  const text = `${fullName} عزیز،\n\nکد تایید ایمیل شما: ${code}\n\nاین کد تا ${process.env.OTP_EXPIRES_MINUTES || 15} دقیقه دیگر معتبر است.\nاگر این درخواست را شما نداده‌اید، این ایمیل را نادیده بگیرید.`;
  const html = `
    <div style="font-family:sans-serif;direction:rtl;text-align:right">
      <p>${fullName} عزیز،</p>
      <p>کد تایید ایمیل شما:</p>
      <p style="font-size:28px;font-weight:bold;letter-spacing:6px">${code}</p>
      <p>این کد تا ${process.env.OTP_EXPIRES_MINUTES || 15} دقیقه دیگر معتبر است.</p>
      <p>اگر این درخواست را شما نداده‌اید، این ایمیل را نادیده بگیرید.</p>
    </div>`;

  if (!enabled) {
    console.warn(`⚠️  ارسال ایمیل توسط مدیر کل غیرفعال شده است. کد تایید برای ${to}: ${code}`);
    return { delivered: false, reason: "DISABLED_BY_ADMIN" };
  }

  if (!transporter) {
    console.warn(
      `⚠️  SMTP تنظیم نشده است. کد تایید برای ${to} در کنسول نمایش داده می‌شود (فقط برای محیط توسعه): ${code}`
    );
    return { delivered: false, reason: "SMTP_NOT_CONFIGURED" };
  }

  try {
    await transporter.sendMail({
      from: `"${fromName}" <${senderAddress()}>`,
      to,
      subject,
      text,
      html,
    });
    return { delivered: true };
  } catch (err) {
    console.error(`❌ ارسال ایمیل به ${to} ناموفق بود.`);
    if (err.code === "EAUTH") {
      console.error(
        "   دلیل: احراز هویت گوگل رد شد. ایمیل و App Password را در .env دوباره بررسی کنید."
      );
    } else {
      console.error("   جزئیات:", err.message);
    }
    console.warn(`   کد تایید (فقط برای دیباگ، چون ایمیل ارسال نشد): ${code}`);
    return { delivered: false, reason: "SEND_FAILED", error: err.message };
  }
}

// ارسال ایمیل حاوی کد بازیابی رمز عبور (فراموشی رمز عبور)
export async function sendPasswordResetEmail({ to, fullName, code }) {
  const { fromName, enabled } = await getEmailSettings();
  const subject = `بازیابی رمز عبور - ${fromName}`;
  const text = `${fullName} عزیز،\n\nکد بازیابی رمز عبور شما: ${code}\n\nاین کد تا ${process.env.OTP_EXPIRES_MINUTES || 15} دقیقه دیگر معتبر است.\nاگر این درخواست را شما نداده‌اید، این ایمیل را نادیده بگیرید و رمز عبور شما تغییر نخواهد کرد.`;
  const html = `
    <div style="font-family:sans-serif;direction:rtl;text-align:right">
      <p>${fullName} عزیز،</p>
      <p>برای بازیابی رمز عبور، از کد زیر استفاده کنید:</p>
      <p style="font-size:28px;font-weight:bold;letter-spacing:6px">${code}</p>
      <p>این کد تا ${process.env.OTP_EXPIRES_MINUTES || 15} دقیقه دیگر معتبر است.</p>
      <p>اگر این درخواست را شما نداده‌اید، این ایمیل را نادیده بگیرید؛ رمز عبور شما تغییر نخواهد کرد.</p>
    </div>`;

  if (!enabled) {
    console.warn(`⚠️  ارسال ایمیل توسط مدیر کل غیرفعال شده است. کد بازیابی رمز عبور برای ${to}: ${code}`);
    return { delivered: false, reason: "DISABLED_BY_ADMIN" };
  }

  if (!transporter) {
    console.warn(
      `⚠️  SMTP تنظیم نشده است. کد بازیابی رمز عبور برای ${to} در کنسول نمایش داده می‌شود (فقط برای محیط توسعه): ${code}`
    );
    return { delivered: false, reason: "SMTP_NOT_CONFIGURED" };
  }

  try {
    await transporter.sendMail({
      from: `"${fromName}" <${senderAddress()}>`,
      to,
      subject,
      text,
      html,
    });
    return { delivered: true };
  } catch (err) {
    console.error(`❌ ارسال ایمیل بازیابی رمز عبور به ${to} ناموفق بود.`);
    if (err.code === "EAUTH") {
      console.error(
        "   دلیل: احراز هویت گوگل رد شد. ایمیل و App Password را در .env دوباره بررسی کنید."
      );
    } else {
      console.error("   جزئیات:", err.message);
    }
    console.warn(`   کد بازیابی (فقط برای دیباگ، چون ایمیل ارسال نشد): ${code}`);
    return { delivered: false, reason: "SEND_FAILED", error: err.message };
  }
}

// ارسال ایمیل حاوی رمز عبور موقت — برای «بازنشانی رمز عبور» توسط ادمین از پنل مدیریت
// بیماران (برخلاف sendPasswordResetEmail که یک کدِ یک‌بارمصرف برای فرم فراموشی رمز
// عبور خودِ کاربر می‌فرستد، این تابع رمز عبور جدیدِ واقعی را که ادمین ساخته اطلاع می‌دهد).
export async function sendTempPasswordEmail({ to, fullName, tempPassword }) {
  const { fromName, enabled } = await getEmailSettings();
  const subject = `بازنشانی رمز عبور توسط مدیر - ${fromName}`;
  const text = `${fullName} عزیز،\n\nرمز عبور حساب شما توسط مدیریت بازنشانی شد. رمز عبور موقت جدید شما:\n${tempPassword}\n\nپیشنهاد می‌شود پس از ورود، رمز عبور خود را از بخش پروفایل تغییر دهید.`;
  const html = `
    <div style="font-family:sans-serif;direction:rtl;text-align:right">
      <p>${fullName} عزیز،</p>
      <p>رمز عبور حساب شما توسط مدیریت بازنشانی شد. رمز عبور موقت جدید شما:</p>
      <p style="font-size:22px;font-weight:bold;letter-spacing:2px">${tempPassword}</p>
      <p>پیشنهاد می‌شود پس از ورود، رمز عبور خود را از بخش پروفایل تغییر دهید.</p>
    </div>`;

  if (!enabled) {
    console.warn(`⚠️  ارسال ایمیل توسط مدیر کل غیرفعال شده است. رمز عبور موقت برای ${to}: ${tempPassword}`);
    return { delivered: false, reason: "DISABLED_BY_ADMIN" };
  }

  if (!transporter) {
    console.warn(`⚠️  SMTP تنظیم نشده است. رمز عبور موقت برای ${to} در کنسول نمایش داده می‌شود (فقط برای محیط توسعه): ${tempPassword}`);
    return { delivered: false, reason: "SMTP_NOT_CONFIGURED" };
  }

  try {
    await transporter.sendMail({
      from: `"${fromName}" <${senderAddress()}>`,
      to,
      subject,
      text,
      html,
    });
    return { delivered: true };
  } catch (err) {
    console.error(`❌ ارسال ایمیل رمز عبور موقت به ${to} ناموفق بود.`);
    if (err.code === "EAUTH") {
      console.error("   دلیل: احراز هویت گوگل رد شد. ایمیل و App Password را در .env دوباره بررسی کنید.");
    } else {
      console.error("   جزئیات:", err.message);
    }
    return { delivered: false, reason: "SEND_FAILED", error: err.message };
  }
}

// ایمیل یادآوری نوبت. مانند بقیه‌ی ایمیل‌ها: اگر ارسال ایمیل توسط مدیر غیرفعال یا SMTP تنظیم
// نشده باشد یا ارسال با خطا مواجه شود، فقط نتیجه برگردانده می‌شود و هرگز استثنا پرتاب نمی‌شود.
export async function sendAppointmentReminderEmail({ to, fullName, doctorName, appointmentDate, appointmentTime }) {
  const { fromName, enabled } = await getEmailSettings();
  if (!enabled) return { delivered: false, reason: "DISABLED_BY_ADMIN" };
  if (!transporter) return { delivered: false, reason: "SMTP_NOT_CONFIGURED" };

  const subject = `یادآوری نوبت - ${fromName}`;
  const text = `${fullName} عزیز،\n\nیادآوری: نوبت شما نزد ${doctorName} در تاریخ ${formatJalaliDate(appointmentDate, { month: "long" })} ساعت ${appointmentTime} است.\nلطفاً به‌موقع مراجعه کنید. اگر نمی‌توانید بیایید، نوبت را از داشبورد خود لغو کنید تا بیمار دیگری از آن استفاده کند.`;
  const html = `
    <div style="font-family:sans-serif;direction:rtl;text-align:right">
      <p>${fullName} عزیز،</p>
      <p>یادآوری: نوبت شما نزد <b>${doctorName}</b> در تاریخ <b>${formatJalaliDate(appointmentDate, { month: "long" })}</b> ساعت <b>${appointmentTime}</b> است.</p>
      <p>لطفاً به‌موقع مراجعه کنید. اگر نمی‌توانید بیایید، نوبت را از داشبورد خود لغو کنید تا بیمار دیگری از آن استفاده کند.</p>
    </div>`;

  try {
    await transporter.sendMail({ from: `"${fromName}" <${senderAddress()}>`, to, subject, text, html });
    return { delivered: true };
  } catch (err) {
    console.error(`❌ ارسال ایمیل یادآوری نوبت به ${to} ناموفق بود:`, err.message);
    return { delivered: false, reason: "SEND_FAILED", error: err.message };
  }
}

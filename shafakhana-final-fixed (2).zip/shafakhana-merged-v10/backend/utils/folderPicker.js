// باز کردن پنجره‌ی انتخاب پوشه‌ی خودِ سیستم‌عامل (Windows / macOS / Linux)
//
// سرور Node همان کامپیوتری است که داشبورد روی آن باز شده (مثلاً XAMPP محلی)، پس می‌توانیم
// پنجره‌ی استاندارد «Browse For Folder» ویندوز را باز کنیم؛ کاربر درایو (C:، D:، ...) را انتخاب می‌کند
// و با دکمه‌ی «Make New Folder» همان‌جا پوشه‌ی جدید می‌سازد. مسیر انتخاب‌شده به‌صورت متن برمی‌گردد.
//
// نکته‌ی امنیتی: هیچ ورودی کاربری وارد دستور نمی‌شود (متن‌ها ثابت‌اند) و دستور با -EncodedCommand
// اجرا می‌شود، پس امکان تزریق دستور (Command Injection) وجود ندارد.

import { spawn } from "child_process";

const PICK_TIMEOUT_MS = 5 * 60 * 1000; // اگر کاربر پنجره را رها کرد، بعد از ۵ دقیقه بسته می‌شود

const TITLE = "پوشه‌ی ذخیره‌ی بکاپ را انتخاب کنید (برای ساخت پوشه‌ی جدید «Make New Folder» را بزنید)";

function pickerError(code, message) {
  const err = new Error(message);
  err.code = code;
  return err;
}

// اسکریپت PowerShell: پنجره‌ی انتخاب پوشه از «This PC» شروع می‌شود تا همه‌ی درایوها دیده شوند.
// فرم نامرئیِ TopMost به‌عنوان owner استفاده می‌شود تا پنجره جلوی مرورگر بیاید، نه پشت آن.
const WINDOWS_SCRIPT = `
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()
$owner = New-Object System.Windows.Forms.Form
$owner.TopMost = $true
$owner.ShowInTaskbar = $false
$dialog = New-Object System.Windows.Forms.FolderBrowserDialog
$dialog.Description = '${TITLE}'
$dialog.ShowNewFolderButton = $true
$dialog.RootFolder = [System.Environment+SpecialFolder]::MyComputer
$result = $dialog.ShowDialog($owner)
if ($result -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $dialog.SelectedPath }
$owner.Dispose()
`;

function runCommand(command, args, { timeoutMs = PICK_TIMEOUT_MS } = {}) {
  return new Promise((resolve, reject) => {
    let child;
    try {
      child = spawn(command, args, { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
    } catch (err) {
      reject(err);
      return;
    }
    const out = [];
    const errOut = [];
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      child.kill();
    }, timeoutMs);
    child.stdout.on("data", (d) => out.push(d));
    child.stderr.on("data", (d) => errOut.push(d));
    child.on("error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
    child.on("close", (code) => {
      clearTimeout(timer);
      resolve({
        code,
        timedOut,
        stdout: Buffer.concat(out).toString("utf8").trim(),
        stderr: Buffer.concat(errOut).toString("utf8").trim(),
      });
    });
  });
}

// خروجی: مسیر مطلق انتخاب‌شده، یا null اگر کاربر پنجره را بست/لغو کرد.
// خطا: PICKER_UNAVAILABLE (روی این سیستم پنجره‌ی انتخاب پوشه قابل‌اجرا نیست)
export async function pickFolderDialog() {
  let result;
  try {
    if (process.platform === "win32") {
      const encoded = Buffer.from(WINDOWS_SCRIPT, "utf16le").toString("base64");
      result = await runCommand("powershell.exe", [
        "-NoProfile", "-NonInteractive", "-STA", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded,
      ]);
    } else if (process.platform === "darwin") {
      result = await runCommand("osascript", ["-e", 'POSIX path of (choose folder with prompt "پوشه‌ی ذخیره‌ی بکاپ را انتخاب کنید")']);
    } else {
      result = await runCommand("zenity", ["--file-selection", "--directory", "--title=پوشه‌ی ذخیره‌ی بکاپ را انتخاب کنید"]);
    }
  } catch (err) {
    if (err && err.code === "ENOENT") {
      throw pickerError("PICKER_UNAVAILABLE", "ابزار باز کردن پنجره‌ی انتخاب پوشه روی این سیستم پیدا نشد");
    }
    throw pickerError("PICKER_UNAVAILABLE", "باز کردن پنجره‌ی انتخاب پوشه ممکن نشد");
  }

  if (result.timedOut) return null;
  if (result.code !== 0 && !result.stdout) {
    // macOS: لغو توسط کاربر با کد ۱ و پیام «User canceled»؛ zenity: لغو با کد ۱ و خروجی خالی
    if (result.code === 1) return null;
    throw pickerError("PICKER_UNAVAILABLE", "باز کردن پنجره‌ی انتخاب پوشه ناموفق بود");
  }
  const picked = result.stdout.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).pop();
  return picked || null;
}

import crypto from "crypto";

// ---------- محدودیت تلاش ورود برای ایمیل‌های «ناموجود» ----------
// برای حساب‌های واقعی، شمارنده و قفل در جدول users نگه‌داری می‌شود (registerFailedLogin). اگر برای ایمیل
// ناموجود هیچ قفلی اعمال نشود، مهاجم می‌تواند با دیدنِ «قفل شدن» (۴۲۳) پس از چند تلاش، وجود ایمیل را
// تشخیص دهد (user enumeration). این ماژول برای ایمیل‌های ناموجود دقیقاً همان رفتار قفل را شبیه‌سازی
// می‌کند تا پاسخ‌ها از بیرون قابل تمایز نباشند. حافظه‌ی محدود و فقط داخل فرایند است (در حد یک سد
// ضدشناسایی؛ حفاظت اصلی brute-force همچنان authLimiter و قفل حساب‌های واقعی است).

const MAX_ENTRIES = 10_000;
const entries = new Map(); // کلید: هش ایمیل → { count, lockedUntil, touchedAt }

const keyOf = (email) => crypto.createHash("sha256").update(String(email || "").toLowerCase()).digest("hex");

function evictIfNeeded() {
  if (entries.size < MAX_ENTRIES) return;
  const now = Date.now();
  for (const [k, v] of entries) {
    if (v.lockedUntil < now && now - v.touchedAt > 60 * 60 * 1000) entries.delete(k);
  }
  while (entries.size >= MAX_ENTRIES) entries.delete(entries.keys().next().value); // قدیمی‌ترین
}

// اگر ایمیل (ناموجود) در حال حاضر «قفل» باشد، تعداد دقیقه‌ی باقیمانده را برمی‌گرداند، وگرنه 0
export function unknownEmailLockMinutes(email) {
  const e = entries.get(keyOf(email));
  if (!e || e.lockedUntil <= Date.now()) return 0;
  return Math.max(1, Math.ceil((e.lockedUntil - Date.now()) / 60000));
}

export function registerUnknownEmailFailure(email, maxAttempts, lockoutMinutes) {
  evictIfNeeded();
  const k = keyOf(email);
  const now = Date.now();
  const e = entries.get(k) || { count: 0, lockedUntil: 0, touchedAt: now };
  e.touchedAt = now;
  e.count += 1;
  if (e.count >= maxAttempts) {
    e.count = 0;
    e.lockedUntil = now + lockoutMinutes * 60 * 1000;
  }
  entries.set(k, e);
}

export function _resetUnknownEmailThrottleForTests() {
  entries.clear();
}

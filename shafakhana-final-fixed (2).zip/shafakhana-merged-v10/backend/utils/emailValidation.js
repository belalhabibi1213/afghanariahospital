// اعتبارسنجی مشترک ایمیل برای «ثبت‌نام» — این ماژول مرجع نهایی امنیتی (Authoritative)
// است و پیش از ارسال کد تایید ۶ رقمی به ایمیل، فرمت و (در صورت امکان فنی) وجود واقعی
// دامنه‌ی آن را بررسی می‌کند. معادل فرانت‌اند این فایل: frontend/src/utils/emailValidation.js
// — چون مرورگر امکان انجام DNS lookup را ندارد، آن نسخه فقط بررسی فرمت را انجام می‌دهد
// و فقط برای تجربه‌ی کاربری فوری استفاده می‌شود؛ همیشه همین فایل (بک‌اند) تصمیم نهایی می‌گیرد.
//
// توجه مهم: حتی بررسی DNS/MX هم اثبات «وجود واقعی صندوق پستی» یا «مالکیت ایمیل» نیست —
// فقط نشان می‌دهد دامنه‌ی واردشده به‌طور فنی می‌تواند ایمیل دریافت کند. مالکیت واقعی ایمیل
// فقط و فقط از طریق همان کد ۶ رقمی که به آدرس ارسال می‌شود اثبات می‌شود
// (authController.verifyEmail) — این ماژول هرگز چنین ادعایی نمی‌کند و از هیچ سرویس
// نامطمئن «بررسی وجود ایمیل» (Gmail-existence API) استفاده نمی‌کند.

import dns from "node:dns";

let dnsResolveMx = dns.promises.resolveMx.bind(dns.promises);
let dnsResolve4 = dns.promises.resolve4.bind(dns.promises);
let dnsResolve6 = dns.promises.resolve6.bind(dns.promises);

// فقط برای تست‌ها: تست‌های خودکار نباید به اینترنت/DNS واقعی وابسته باشند (در CI یا محیط بدون شبکه
// همه‌ی دامنه‌ها ENOTFOUND می‌شوند و ثبت‌نام‌های معتبر رد می‌شد). ارسال undefined برای هر کلید، resolver واقعی را برمی‌گرداند.
export function __setDnsResolversForTests({ resolveMx, resolve4, resolve6 } = {}) {
  dnsResolveMx = resolveMx || dns.promises.resolveMx.bind(dns.promises);
  dnsResolve4 = resolve4 || dns.promises.resolve4.bind(dns.promises);
  dnsResolve6 = resolve6 || dns.promises.resolve6.bind(dns.promises);
}

// پیام خطای یکسان برای هر نوع ایمیل نامعتبر (فرمت غلط، دامنه‌ی Gmail نامعتبر، اشتباه
// تایپی رایج، دامنه‌ای که واقعاً وجود ندارد و ...) — طبق تصمیم محصول، بدون افشای جزئیات
// دقیق دلیل رد شدن.
export const EMAIL_INVALID_MESSAGE = "ایمیل وارد شده معتبر نیست. لطفاً ایمیل خود را بررسی کنید.";

// فرمت کلی یک ایمیل معتبر: local-part@domain.tld — فقط کاراکترهای انگلیسی/عدد/چند
// نماد رایج در local-part، و دامنه‌ای با حداقل یک نقطه و TLD حروفی معتبر.
// (چون کلاس‌های کاراکتر زیر فقط ASCII هستند، هر حرف فارسی/عربی/یونیکد دیگر خودبه‌خود رد می‌شود)
const EMAIL_FORMAT_REGEX =
  /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,24}$/;

// دو نقطه‌ی پیاپی (در local-part یا دامنه) در هیچ ایمیل واقعی مجاز نیست
const CONSECUTIVE_DOTS_REGEX = /\.\./;

// دامنه‌ی رسمی Gmail — طبق تصمیم محصول، فقط دامنه‌ی دقیقاً «gmail.com» جیمیل در نظر
// گرفته می‌شود (نه هر دامنه‌ی مشابه/جایگزین) و قوانین رسمی Gmail روی نام کاربری فقط
// برای همین دامنه‌ی دقیق اعمال می‌شود.
const GMAIL_DOMAIN = "gmail.com";

// نام کاربری Gmail: ۶ تا ۳۰ کاراکتر، فقط حروف/عدد/نقطه، نمی‌تواند با نقطه شروع/پایان یابد
const GMAIL_LOCAL_PART_REGEX = /^[a-zA-Z0-9](?:[a-zA-Z0-9.]{4,28})[a-zA-Z0-9]$/;

// دامنه‌های رایج با اشتباه تایپی شناخته‌شده (Gmail/Yahoo/Hotmail/Outlook) — کاربر به‌احتمال
// زیاد قصد نوشتن دامنه‌ی درست را داشته اما اشتباه تایپ کرده؛ به‌جای پذیرفتن سکوت‌آمیز، رد می‌شود
const KNOWN_TYPO_DOMAINS = new Set([
  // Gmail
  "gmial.com", "gmal.com", "gamil.com", "gmai.com", "gmaill.com", "gmailcom",
  "gmail.co", "gmail.cm", "gmail.con", "gnail.com", "gmail.comm", "gmil.com",
  // Yahoo
  "yahooo.com", "yaho.com", "yahoo.co", "yahoo.con", "yaoo.com", "yahoocom",
  // Hotmail / Outlook
  "hotmial.com", "hotnail.com", "hotmail.co", "hotmal.com", "hotmai.com", "hotmailcom",
  "outlok.com", "outllook.com", "outlook.co", "outlok.co", "outlookcom",
]);

/**
 * فرمت ایمیل را طبق قوانین بالا بررسی می‌کند (فقط فرمت — نه مالکیت واقعی).
 * @param {unknown} email
 * @returns {boolean}
 */
export function isEmailFormatValid(email) {
  if (typeof email !== "string") return false;
  const trimmed = email.trim();
  if (!trimmed) return false;

  if (!EMAIL_FORMAT_REGEX.test(trimmed)) return false;
  if (CONSECUTIVE_DOTS_REGEX.test(trimmed)) return false;

  const atIndex = trimmed.lastIndexOf("@");
  const localPart = trimmed.slice(0, atIndex);
  const domain = trimmed.slice(atIndex + 1).toLowerCase();

  if (KNOWN_TYPO_DOMAINS.has(domain)) return false;

  if (domain === GMAIL_DOMAIN && !GMAIL_LOCAL_PART_REGEX.test(localPart)) {
    return false;
  }

  return true;
}

/**
 * @param {unknown} email
 * @returns {string|null} پیام خطا در صورت نامعتبر بودن، یا null در صورت معتبر بودن
 */
export function getEmailValidationError(email) {
  return isEmailFormatValid(email) ? null : EMAIL_INVALID_MESSAGE;
}

/**
 * بررسی می‌کند که دامنه‌ی ایمیل واقعاً بتواند ایمیل دریافت کند (رکورد MX دارد، یا در
 * نبود MX حداقل یک رکورد A/AAAA دارد — طبق RFC 5321 به‌عنوان جایگزین قابل قبول).
 * این فقط یک بررسی فنی DNS در سطح دامنه است، نه بررسی وجود صندوق پستی/مالکیت.
 *
 * در صورت بروز خطای DNS «موقت» (شبکه/تایم‌اوت/سرور DNS در دسترس نیست) به‌جای رد کردن
 * کاربر واقعی به‌خاطر یک مشکل زیرساختی موقت، این تابع true برمی‌گرداند (fail-open) —
 * فقط زمانی که DNS با قطعیت می‌گوید دامنه اصلاً وجود ندارد یا هیچ رکورد پستی/آدرسی
 * ندارد (ENOTFOUND / ENODATA)، false برمی‌گردد.
 *
 * @param {string} domain
 * @returns {Promise<boolean>}
 */
export async function hasDeliverableDnsRecords(domain) {
  try {
    const mxRecords = await dnsResolveMx(domain);
    if (mxRecords && mxRecords.length > 0) return true;
    // دامنه پیدا شد ولی هیچ رکورد MX نداشت — طبق fallback بررسی رکورد A/AAAA
  } catch (err) {
    if (err && (err.code === "ENOTFOUND" || err.code === "ENODATA")) {
      // برای دامنه‌های ENOTFOUND/ENODATA در MX، همچنان فرصت fallback به A/AAAA داده می‌شود
    } else {
      // خطای فنی/موقت DNS (مثلاً SERVFAIL، تایم‌اوت، عدم دسترسی به resolver) —
      // نمی‌توان با قطعیت گفت دامنه نامعتبر است، پس مسدود نمی‌کنیم.
      return true;
    }
  }

  try {
    const aRecords = await dnsResolve4(domain);
    if (aRecords && aRecords.length > 0) return true;
  } catch (err) {
    if (!(err && (err.code === "ENOTFOUND" || err.code === "ENODATA"))) {
      return true;
    }
  }

  try {
    const aaaaRecords = await dnsResolve6(domain);
    if (aaaaRecords && aaaaRecords.length > 0) return true;
  } catch (err) {
    if (!(err && (err.code === "ENOTFOUND" || err.code === "ENODATA"))) {
      return true;
    }
  }

  return false;
}

/**
 * بررسی کامل ایمیل برای مسیر ثبت‌نام: ابتدا فرمت (سریع، سینک)، سپس در صورت معتبر بودن
 * فرمت، بررسی فنی DNS دامنه (در صورت امکان). هر دو بررسی از همان پیام خطای یکسان
 * استفاده می‌کنند تا هیچ جزئیاتی درباره‌ی دلیل دقیق رد شدن افشا نشود.
 *
 * توجه: این تابع هرگز ادعا نمی‌کند ایمیل «وجود دارد» یا متعلق به کاربر است — فقط فرمت
 * و قابلیت فنی دریافت ایمیل توسط دامنه را بررسی می‌کند. اثبات مالکیت واقعی همچنان فقط
 * با کد تایید ۶ رقمی انجام می‌شود.
 *
 * @param {unknown} email
 * @returns {Promise<string|null>} پیام خطا در صورت نامعتبر بودن، یا null در صورت معتبر بودن
 */
export async function getEmailValidationErrorAsync(email) {
  const formatError = getEmailValidationError(email);
  if (formatError) return formatError;

  const trimmed = String(email).trim();
  const domain = trimmed.slice(trimmed.lastIndexOf("@") + 1).toLowerCase();

  const deliverable = await hasDeliverableDnsRecords(domain);
  if (!deliverable) return EMAIL_INVALID_MESSAGE;

  return null;
}

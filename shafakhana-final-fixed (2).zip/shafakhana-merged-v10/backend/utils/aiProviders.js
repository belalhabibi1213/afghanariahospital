// اتصال به سرویس هوش مصنوعی — طوری نوشته شده که ارائه‌دهنده فقط با .env عوض شود (بدون تغییر کد):
//   AI_PROVIDER=gemini  (پیش‌فرض؛ Google Gemini)  — هم کلید AI Studio (شروع با AIza) و هم کلید
//                        Vertex express (شروع با AQ.) پشتیبانی می‌شود؛ نوع کلید خودکار تشخیص داده می‌شود.
//   AI_PROVIDER=openai  (هر سرویس سازگار با OpenAI: Groq، OpenRouter، Ollama و ...) → AI_BASE_URL و AI_MODEL
// اگر مدل انتخابی در دسترس نباشد (حذف/بازنشسته شده)، مدل‌های جایگزین به‌ترتیب امتحان می‌شوند.
// کلید API فقط در بک‌اند (AI_API_KEY) نگه‌داری می‌شود و هرگز به مرورگر نمی‌رسد.

const PROVIDER = (process.env.AI_PROVIDER || "gemini").trim().toLowerCase();
const API_KEY = (process.env.AI_API_KEY || "").trim().replace(/^["']|["']$/g, "").replace(/^\.(?=AQ\.|AIza)/, "");
const TIMEOUT_MS = Number(process.env.AI_TIMEOUT_MS) || 25000;

// مدل‌های Gemini مرتب عوض و بازنشسته می‌شوند (مثلاً «gemini-2.5-flash-lite برای کاربران جدید در دسترس نیست»).
// پس: ۱) اگر AI_MODEL در .env داده شده اول همان، ۲) نام‌های «latest» که همیشه به مدل فعلی اشاره می‌کنند،
// ۳) مدل‌های واقعاً در دسترس همین کلید از ListModels (جدیدترین flash، بعد flash-lite). مدلِ موفق حافظه می‌شود.
const STATIC_FALLBACKS = ["gemini-flash-latest", "gemini-flash-lite-latest"];
// Vertex express نام‌های «-latest» را نمی‌شناسد و ListModels هم ندارد؛ باید نام واقعی مدل داده شود.
// (همین نبودنِ نام معتبر باعث می‌شد با کلید «AQ.» و AI_MODEL خالی هیچ مدلی کار نکند.)
const VERTEX_FALLBACKS = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-2.5-flash-lite", "gemini-2.0-flash-lite"];
const IS_VERTEX_KEY = API_KEY.startsWith("AQ.");
const DEFAULT_MODEL = { gemini: "", openai: "llama-3.3-70b-versatile" };
const MODEL = process.env.AI_MODEL?.trim() || DEFAULT_MODEL[PROVIDER] || "";
const OPENAI_BASE = (process.env.AI_BASE_URL?.trim() || "https://api.groq.com/openai/v1").replace(/\/+$/, "");

export function isAiConfigured() {
  return Boolean(API_KEY);
}

async function postJson(url, headers, body) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...headers },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) {
      const err = new Error(data?.error?.message || `AI provider error ${res.status}`);
      err.status = res.status;
      err.providerStatus = data?.error?.status;
      throw err;
    }
    return data;
  } catch (err) {
    if (err.name === "AbortError") {
      const e = new Error("AI request timed out");
      e.status = 504;
      throw e;
    }
    // «fetch failed» یعنی اصلاً به سرور نرسیده‌ایم (DNS/فیلتر/فایروال/VPN)؛ علت واقعی در err.cause است
    if (err instanceof TypeError && err.message === "fetch failed") {
      const c = err.cause || {};
      const e = new Error(`network error: ${c.code || c.name || "unknown"} ${c.message || ""} (${new URL(url).host})`.trim());
      e.network = true;
      throw e;
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

// کلید Vertex express با «AQ.» شروع می‌شود و روی aiplatform.googleapis.com کار می‌کند؛ کلید AI Studio روی generativelanguage
function geminiUrls(model) {
  const studio = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  const vertex = `https://aiplatform.googleapis.com/v1/publishers/google/models/${encodeURIComponent(model)}:generateContent`;
  return API_KEY.startsWith("AQ.") ? [vertex, studio] : [studio, vertex];
}

// «تفکر» مدل‌های جدید Gemini پاسخ را کند می‌کند؛ برای چت ساده کمترین سطح تفکر خواسته می‌شود.
// اگر مدل/کلید این تنظیم را نپذیرد (خطای 400)، یک‌بار بدون آن تکرار و برای دفعات بعد حافظه می‌شود.
let thinkingTweak = "budget"; // budget | level | none
function thinkingConfig() {
  if (thinkingTweak === "budget") return { thinkingBudget: 0 };
  if (thinkingTweak === "level") return { thinkingLevel: "minimal" };
  return undefined;
}

async function geminiOnce(url, args) {
  for (;;) {
    try {
      return await geminiRequest(url, args);
    } catch (err) {
      // هر خطای 400 (نه فقط پیام‌های حاوی «think»): Vertex متن مبهم «invalid argument» می‌دهد
      if (err.status === 400 && thinkingTweak !== "none") {
        thinkingTweak = thinkingTweak === "budget" ? "level" : "none";
        continue;
      }
      throw err;
    }
  }
}

// Gemini/Vertex سخت‌گیرند: گفتگو باید با نقش «user» شروع شود و نقش‌ها پشت‌سرهم تکراری نباشند
// (پیام خوش‌آمدگویی دستیار در ابتدای تاریخچه، یا دو پیام پیاپی کاربر بعد از یک خطا، خطای 400
// «Request contains an invalid argument» می‌داد). اینجا تاریخچه قبل از ارسال نرمال می‌شود.
function normalizeTurns(messages) {
  const out = [];
  for (const m of messages) {
    const role = m.role === "assistant" ? "model" : "user";
    const text = String(m.content || "").trim();
    if (!text) continue;
    if (!out.length && role === "model") continue; // حذف شروع با نقش model
    if (out.length && out[out.length - 1].role === role) out[out.length - 1].parts[0].text += `\n${text}`;
    else out.push({ role, parts: [{ text }] });
  }
  return out;
}

async function geminiRequest(url, { system, messages }) {
  const tc = thinkingConfig();
  const data = await postJson(
    url,
    { "x-goog-api-key": API_KEY },
    {
      systemInstruction: { parts: [{ text: system }] },
      contents: normalizeTurns(messages),
      generationConfig: { temperature: 0.3, maxOutputTokens: 900, ...(tc ? { thinkingConfig: tc } : {}) },
    }
  );
  const parts = data?.candidates?.[0]?.content?.parts;
  // مدل‌های «thinking» ممکن است بخش‌های فکر (thought) هم برگردانند؛ فقط متن پاسخ نگه داشته می‌شود
  const text = Array.isArray(parts) ? parts.filter((p) => !p.thought).map((p) => p.text || "").join("").trim() : "";
  if (!text) {
    const reason = data?.promptFeedback?.blockReason || data?.candidates?.[0]?.finishReason || "empty";
    const err = new Error(`Gemini returned no text (${reason})`);
    err.status = 502;
    throw err;
  }
  return text;
}

// فهرست مدل‌هایی که این کلید واقعاً می‌تواند استفاده کند (فقط AI Studio)، مرتب‌شده: جدیدترین flash، بعد flash-lite
let discovered = { at: 0, models: [] };
async function discoverModels() {
  if (Date.now() - discovered.at < 6 * 3600 * 1000) return discovered.models;
  try {
    const res = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", {
      headers: { "x-goog-api-key": API_KEY },
      signal: AbortSignal.timeout(10000),
    });
    const data = await res.json().catch(() => null);
    const names = (data?.models || [])
      .filter((m) => (m.supportedGenerationMethods || []).includes("generateContent"))
      .map((m) => String(m.name).replace(/^models\//, ""))
      .filter((n) => /^gemini-[\d.]+-flash/.test(n) && !/(tts|image|embedding|live|audio|robotics|computer|thinking|exp|preview)/.test(n));
    const version = (n) => parseFloat(n.match(/^gemini-([\d.]+)/)[1]);
    const rank = (n) => (/lite/.test(n) ? 1 : 0);
    names.sort((a, b) => rank(a) - rank(b) || version(b) - version(a));
    discovered = { at: Date.now(), models: names.slice(0, 5) };
  } catch {
    discovered = { at: Date.now() - 5 * 3600 * 1000, models: [] }; // یک ساعت بعد دوباره تلاش
  }
  return discovered.models;
}

let working = null; // { model, url } آخرین ترکیب موفق

async function generateGemini(args) {
  if (working) {
    try {
      return await geminiOnce(working.url, args);
    } catch (err) {
      working = null;
      if (err.status === 429) throw err;
    }
  }

  const tried = new Set();
  let lastErr;
  const attempt = async (model) => {
    if (!model || tried.has(model)) return null;
    tried.add(model);
    for (const url of geminiUrls(model)) {
      try {
        const text = await geminiOnce(url, args);
        working = { model, url };
        return text;
      } catch (err) {
        lastErr = err;
        if (err.status === 429) throw err; // سهمیه؛ تغییر مدل کمکی نمی‌کند
      }
    }
    return null;
  };

  const candidates = IS_VERTEX_KEY ? [MODEL, ...VERTEX_FALLBACKS, ...STATIC_FALLBACKS] : [MODEL, ...STATIC_FALLBACKS];
  for (const model of candidates) {
    const text = await attempt(model);
    if (text) return text;
  }
  for (const model of await discoverModels()) {
    const text = await attempt(model);
    if (text) return text;
  }
  throw lastErr || new Error("No Gemini model available");
}

// messages: [{ role: "user" | "assistant", content }]
export async function generateReply({ system, messages }) {
  if (!API_KEY) {
    const err = new Error("AI not configured");
    err.code = "AI_NOT_CONFIGURED";
    throw err;
  }

  if (PROVIDER === "openai") {
    const data = await postJson(
      `${OPENAI_BASE}/chat/completions`,
      { Authorization: `Bearer ${API_KEY}` },
      { model: MODEL, temperature: 0.3, max_tokens: 700, messages: [{ role: "system", content: system }, ...messages] }
    );
    return String(data?.choices?.[0]?.message?.content || "").trim();
  }

  return generateGemini({ system, messages });
}

// برای بررسی راه‌اندازی (scripts/check-services.js و لاگ شروع سرور)
export async function pingAi() {
  return generateReply({ system: "Reply with one short word.", messages: [{ role: "user", content: "ping" }] });
}

// فهرست سرورهای ICE (STUN/TURN) برای تماس صوتی/تصویری (WebRTC)
//
// فقط STUN برای بیمارانی که پشت NAT سخت‌گیر یا اینترنت موبایل هستند کافی نیست و تماس برقرار
// نمی‌شود؛ برای آن‌ها یک سرور TURN لازم است (مثلاً coturn). تنظیمات در backend/.env:
//   STUN_URLS=stun:stun.l.google.com:19302            (پیش‌فرض؛ چند آدرس با ویرگول)
//   TURN_URLS=turn:turn.example.com:3478,turns:turn.example.com:5349
//   حالت ۱ (پیشنهادی، coturn با use-auth-secret): TURN_SECRET=رمز-مشترک-با-coturn
//   حالت ۲ (ساده): TURN_USERNAME=... و TURN_CREDENTIAL=...
//   TURN_CREDENTIAL_TTL_SECONDS=43200                   (عمر اعتبار موقت در حالت ۱؛ پیش‌فرض ۱۲ ساعت)
// اگر TURN_URLS تنظیم نشده باشد فقط STUN برگردانده می‌شود (رفتار قبلی).

import crypto from "crypto";

const DEFAULT_STUN = "stun:stun.l.google.com:19302";

function splitList(value) {
  return String(value || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export function buildIceServers(user, env = process.env) {
  const stunUrls = splitList(env.STUN_URLS);
  const servers = [{ urls: stunUrls.length ? stunUrls : [DEFAULT_STUN] }];

  const turnUrls = splitList(env.TURN_URLS);
  if (turnUrls.length === 0) return servers;

  const secret = (env.TURN_SECRET || "").trim();
  if (secret) {
    // رمز موقت به‌سبک coturn (--use-auth-secret): username = "زمان انقضا:شناسه کاربر"،
    // credential = base64(HMAC-SHA1(secret, username)). رمز اصلی هرگز به مرورگر نمی‌رسد.
    const ttl = Number(env.TURN_CREDENTIAL_TTL_SECONDS) > 0 ? Number(env.TURN_CREDENTIAL_TTL_SECONDS) : 12 * 3600;
    const username = `${Math.floor(Date.now() / 1000) + ttl}:${user && user.id ? user.id : "guest"}`;
    const credential = crypto.createHmac("sha1", secret).update(username).digest("base64");
    servers.push({ urls: turnUrls, username, credential });
  } else if (env.TURN_USERNAME && env.TURN_CREDENTIAL) {
    servers.push({ urls: turnUrls, username: env.TURN_USERNAME, credential: env.TURN_CREDENTIAL });
  }
  return servers;
}

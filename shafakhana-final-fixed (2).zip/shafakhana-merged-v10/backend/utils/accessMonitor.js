import { logger } from "./logger.js";

// ---------- تشخیص دسترسی غیرعادی به پرونده‌های بیماران ----------
// کارمندی که در بازه‌ی کوتاه به پرونده‌ی «تعداد زیادی بیمارِ متفاوت» سر می‌زند (اسکن دسته‌جمعی، حساب
// لو رفته یا سوءاستفاده‌ی داخلی) شناسایی می‌شود. هر بار که کاربر پرونده‌ای را می‌بیند، trackPatientRecordAccess
// صدا زده می‌شود. وقتی تعداد بیماران «متمایز» در پنجره از سقف گذشت: لاگ هشدار (event=emr.anomaly)، ثبت در
// لاگ فعالیت و اعلان داخلی برای همه‌ی مدیران کل — حداکثر یک‌بار در هر بازه‌ی خنک‌سازی برای هر کاربر.
// تنظیم: EMR_ALERT_THRESHOLD (پیش‌فرض ۳۰)، EMR_ALERT_WINDOW_MIN (۱۰)، EMR_ALERT_COOLDOWN_MIN (۶۰).
const num = (v, d) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : d);
const cfg = () => ({
  threshold: num(process.env.EMR_ALERT_THRESHOLD, 30),
  windowMs: num(process.env.EMR_ALERT_WINDOW_MIN, 10) * 60_000,
  cooldownMs: num(process.env.EMR_ALERT_COOLDOWN_MIN, 60) * 60_000,
});

const hits = new Map(); // userId → Map(patientId → زمان آخرین مشاهده)
const lastAlert = new Map(); // userId → زمان آخرین هشدار

// pure + قابل‌تست: true برمی‌گرداند اگر این دسترسی باید هشدار تولید کند
export function recordAccess(userId, patientId, now = Date.now(), config = cfg()) {
  if (!userId || !patientId) return false;
  let m = hits.get(userId);
  if (!m) hits.set(userId, (m = new Map()));
  m.set(String(patientId), now);
  for (const [p, t] of m) if (now - t > config.windowMs) m.delete(p);
  if (m.size < config.threshold) return false;
  const last = lastAlert.get(userId);
  if (last !== undefined && now - last < config.cooldownMs) return false;
  lastAlert.set(userId, now);
  return true;
}

export function _resetAccessMonitorForTests() { hits.clear(); lastAlert.clear(); }

// هرگز نباید درخواست اصلی را مختل کند
export async function trackPatientRecordAccess(req, patientId) {
  try {
    const user = req.user;
    if (!user || user.role === "user") return;
    const config = cfg();
    if (!recordAccess(user.id, patientId, Date.now(), config)) return;

    const details = `userId=${user.id} role=${user.role} distinctPatients>=${config.threshold} windowMin=${config.windowMs / 60000}`;
    logger.warn({ event: "emr.anomaly", userId: user.id, role: user.role, threshold: config.threshold, windowMin: config.windowMs / 60000, reqId: req.id }, "دسترسی غیرعادی به پرونده‌های بیماران");

    // وابستگی‌ها داینامیک import می‌شوند تا ماژول (و تست‌های بدون DB) به دیتابیس وابسته نشود
    const [{ logActivity }, { createNotification }, db] = await Promise.all([
      import("../models/ActivityLog.js"),
      import("../models/Notification.js"),
      import("../db.js").then((m) => m.default),
    ]);
    await logActivity({ req, userId: user.id, userName: user.email, role: user.role, action: "هشدار امنیتی: دسترسی غیرعادی به پرونده‌ها", details });
    const [admins] = await db.query("SELECT id FROM users WHERE role = 'superadmin' AND isActive = 1");
    await Promise.all(
      admins.map((a) =>
        createNotification({
          userId: a.id,
          title: "هشدار امنیتی: دسترسی غیرعادی به پرونده‌ها",
          message: `کاربر ${user.email} (${user.role}) در مدت کوتاه به پرونده‌ی ${config.threshold} بیمار یا بیشتر دسترسی داشته است. لاگ فعالیت را بررسی کنید.`,
          type: "security_alert",
        })
      )
    );
  } catch (err) {
    logger.error({ err }, "خطا در پایش دسترسی به پرونده‌ها");
  }
}

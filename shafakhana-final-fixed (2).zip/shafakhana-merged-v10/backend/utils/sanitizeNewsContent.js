// پاک‌سازی HTML متن کامل خبر (ویرایشگر متن غنی پنل ادمین) قبل از ذخیره در دیتابیس.
// چون این محتوا بعداً در صفحه‌ی عمومی «ادامه مطلب» با dangerouslySetInnerHTML نمایش داده
// می‌شود، باید هر تگ/ویژگی خطرناک (اسکریپت، event handler مثل onerror، iframe و...) حذف
// شود تا از حملات XSS ذخیره‌شده (Stored XSS) جلوگیری شود — حتی اگر فرض بر این باشد که
// فقط نقش‌های admin/superadmin این فرم را پر می‌کنند.
import sanitizeHtml from "sanitize-html";

const ALLOWED_TAGS = [
  "p", "br", "strong", "b", "em", "i", "u", "s", "strike",
  "h2", "h3", "h4", "ul", "ol", "li", "a", "blockquote", "span",
];

export function sanitizeNewsContent(html) {
  if (!html) return html;
  return sanitizeHtml(html, {
    allowedTags: ALLOWED_TAGS,
    allowedAttributes: {
      a: ["href", "target", "rel"],
      span: [],
    },
    allowedSchemes: ["http", "https", "mailto"],
    transformTags: {
      a: sanitizeHtml.simpleTransform("a", { rel: "noopener noreferrer", target: "_blank" }),
    },
    // تگ‌های غیرمجاز کاملاً حذف می‌شوند اما متن داخلشان باقی می‌ماند (مثلاً یک <div> بی‌خطر)
    nonTextTags: ["script", "style", "iframe", "object", "embed"],
  }).trim();
}

// پاک‌سازی متن نظرات کاربران روی اخبار: برخلاف متن کامل خبر (که ویرایشگر متن غنی ادمین
// تولید می‌کند)، نظرات هیچ تگ HTML ای مجاز ندارند — همه‌ی تگ‌ها کاملاً حذف می‌شوند و فقط
// متن ساده باقی می‌ماند. این هم از XSS ذخیره‌شده جلوگیری می‌کند و هم لینک‌های اسپم/تبلیغاتی
// قالب‌بندی‌شده با HTML را بی‌اثر می‌کند.
export function sanitizeCommentText(text) {
  if (!text) return text;
  return sanitizeHtml(text, {
    allowedTags: [],
    allowedAttributes: {},
  }).trim();
}

import crypto from "crypto";

const OTP_EXPIRES_MINUTES = Number(process.env.OTP_EXPIRES_MINUTES || 15);

// یک کد ۶ رقمی امن با crypto.randomInt تولید می‌کند
export function generateOtp() {
  return String(crypto.randomInt(100000, 1000000)); // همیشه ۶ رقم
}

// کد را قبل از ذخیره در دیتابیس هش می‌کند (خود کد هرگز خام ذخیره نمی‌شود)
export function hashOtp(code) {
  return crypto.createHash("sha256").update(String(code)).digest("hex");
}

// زمان انقضای کد را برمی‌گرداند (Date)
export function getOtpExpiry() {
  return new Date(Date.now() + OTP_EXPIRES_MINUTES * 60 * 1000);
}

// حداکثر تعداد حدس اشتباه برای «هر کد»؛ بعد از آن همان کد باطل می‌شود و باید کد جدید گرفت.
// (کد ۶ رقمی فقط ۱٬۰۰۰٬۰۰۰ حالت دارد؛ محدودیت نرخ بر اساس IP به‌تنهایی کافی نیست.)
const parsedMaxAttempts = Number(process.env.OTP_MAX_ATTEMPTS);
export const OTP_MAX_ATTEMPTS = Number.isInteger(parsedMaxAttempts) && parsedMaxAttempts > 0 ? parsedMaxAttempts : 5;

// مقایسه‌ی زمان‌ثابت (timing-safe) هش کد واردشده با هش ذخیره‌شده
export function otpMatches(code, storedHash) {
  if (typeof storedHash !== "string" || !storedHash) return false;
  const a = Buffer.from(hashOtp(code), "utf8");
  const b = Buffer.from(storedHash, "utf8");
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export { OTP_EXPIRES_MINUTES };

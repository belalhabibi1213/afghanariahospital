import PDFDocument from "pdfkit";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { shapeRtl } from "./rtlText.js";
import { getAllSettings } from "../models/Settings.js";
import { LOGO_DIR, SIGNATURES_DIR } from "../middleware/upload.js";

// خروجی PDF رسمی و قابل‌چاپ (A4، راست‌به‌چپ) برای یک نسخه‌ی طبی — هم برای بیمار و هم داکتر.
// ساختار: سربرگ (لوگو + نام شفاخانه) ← ردیف عنوان (شماره نسخه | «نسخه طبی» | تاریخ) ← کارت داکتر/مریض ←
// تشخیص ← جدول Rx (نام دارو، دوز، تعداد، مدت مصرف، نحوه مصرف، توضیحات) ← دستورالعمل/پیگیری/توضیحات داکتر ←
// امضا و مهر داکتر ← پاورقی (آدرس، تلفن، شماره صفحه). همه‌ی داده‌ها از رکورد(های) واقعی نسخه، جدول بیمار/داکتر
// و تنظیمات سیستم می‌آیند؛ هیچ مقدار پزشکی یا هویتی Hard-code نشده است. فیلدی که در دیتابیس خالی باشد
// (سن، جنسیت، تخصص، امضا، ...) چاپ نمی‌شود و جایش خالی نمی‌ماند.
// امضا: اگر داکتر تصویر امضا آپلود کرده باشد (doctors.signatureUrl) روی نسخه چاپ می‌شود؛ در غیر این صورت
// کادر خالی برای امضا و مهر دستی می‌ماند.

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FONT_REGULAR = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Medium.ttf");
const FONT_BOLD = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Bold.ttf");

// آدرس پیش‌فرض شفاخانه — فقط وقتی استفاده می‌شود که در تنظیمات سیستم (hospitalAddress) آدرسی ثبت نشده باشد
const DEFAULT_ADDRESS = "هرات، جاده قوماندانی";
// نام انگلیسی فقط برای نام پیش‌فرض شفاخانه معتبر است؛ اگر ادمین نام را عوض کرده باشد، چاپ نمی‌شود
const DEFAULT_HOSPITAL_NAME = "شفاخانه افغان آریا";
const HOSPITAL_NAME_EN = "Afghan Arya Hospital";

const COLOR = {
  primary: "#0d47a1",
  primaryDark: "#0a3a82",
  accent: "#1976d2",
  soft: "#eaf2fb",
  softer: "#f5f9fe",
  border: "#c5d8ee",
  text: "#0f172a",
  muted: "#64748b",
  white: "#ffffff",
  danger: "#b3261e",
};

const GENDER_LABEL = { male: "مرد", female: "زن" };

function pad2(n) {
  return String(n).padStart(2, "0");
}

// تاریخ به قالب YYYY-MM-DD؛ هم رشته (ISO/MySQL) و هم Date را درست می‌خواند
function fmtDate(value) {
  if (!value) return "—";
  if (typeof value === "string" && /^\d{4}-\d{2}-\d{2}/.test(value)) return value.slice(0, 10);
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return String(value).slice(0, 10);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

// تاریخ هجری شمسی (YYYY/MM/DD) از روی همان تاریخ میلادیِ واقعیِ دیتابیس — همان تقویمی که در پنل‌ها
// (toLocaleDateString("fa-IR")) نمایش داده می‌شود. اگر Intl در دسترس نبود، null برمی‌گرداند.
const JALALI_FORMAT = (() => {
  try {
    return new Intl.DateTimeFormat("en-US-u-ca-persian-nu-latn", { year: "numeric", month: "2-digit", day: "2-digit", timeZone: "UTC" });
  } catch {
    return null;
  }
})();
function fmtJalali(value) {
  const iso = fmtDate(value);
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso);
  if (!m || !JALALI_FORMAT) return null;
  try {
    const parts = Object.fromEntries(
      JALALI_FORMAT.formatToParts(new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]), 12))).map((p) => [p.type, p.value])
    );
    return `${parts.year}/${parts.month}/${parts.day}`;
  } catch {
    return null;
  }
}

// سن به سال در تاریخِ صدور نسخه (نه امروز) — فقط اگر تاریخ تولد معتبر در دیتابیس باشد
function ageAt(dateOfBirth, atDate) {
  const dob = fmtDate(dateOfBirth);
  const at = fmtDate(atDate);
  const a = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dob);
  const b = /^(\d{4})-(\d{2})-(\d{2})$/.exec(at);
  if (!a || !b) return null;
  let age = Number(b[1]) - Number(a[1]);
  if (Number(b[2]) < Number(a[2]) || (Number(b[2]) === Number(a[2]) && Number(b[3]) < Number(a[3]))) age -= 1;
  return age >= 0 && age < 150 ? age : null;
}

function resolveFilePath(dir, fileUrl) {
  if (!dir || !fileUrl) return null;
  const filePath = path.join(dir, path.basename(fileUrl));
  return fs.existsSync(filePath) ? filePath : null;
}

// سطح‌های فشردگی چیدمان. ابتدا با سطح ۰ (راحت‌ترین خوانایی) چیدمان می‌شود؛ اگر محتوا در یک ورق A4 جا نشد،
// خودکار سطح بعدی (فاصله‌ها و اندازه‌ی فونت کمی کوچک‌تر) امتحان می‌شود تا حداقل ۸ دارو در یک ورق جا شود.
// فقط اگر حتی فشرده‌ترین سطح هم کافی نبود، همان سطح ۰ در چند صفحه چاپ می‌شود.
const LEVELS = [
  { headerH: 96, logoBox: 62, nameSize: 23, pillH: 44, pillFont: 16, afterHeader: 14, afterTitle: 14, cardBase: 26, cardRowH: 33, labelFont: 8.5, valueFont: 11.5, valueDy: 13,
    diagFont: 11, diagLH: 17, diagBase: 30, afterBlock: 12, rxFont: 24, rxAdv: 26, thH: 34, cell: 10.5, note: 9.5, lineH: 16, rowPad: 14,
    secFont: 10.5, secLH: 17, secTitleH: 22, secPad: 16, secGap: 8, sigBox: 38, sigTitleH: 18, footerH: 62 },
  { headerH: 84, logoBox: 54, nameSize: 21, pillH: 40, pillFont: 15, afterHeader: 12, afterTitle: 10, cardBase: 24, cardRowH: 30, labelFont: 8, valueFont: 11, valueDy: 12,
    diagFont: 10.5, diagLH: 15, diagBase: 28, afterBlock: 10, rxFont: 20, rxAdv: 22, thH: 30, cell: 10, note: 9, lineH: 14, rowPad: 10,
    secFont: 10, secLH: 15, secTitleH: 20, secPad: 12, secGap: 6, sigBox: 34, sigTitleH: 16, footerH: 58 },
  { headerH: 72, logoBox: 48, nameSize: 19, pillH: 36, pillFont: 14, afterHeader: 10, afterTitle: 8, cardBase: 22, cardRowH: 27, labelFont: 7.5, valueFont: 10.5, valueDy: 11,
    diagFont: 10, diagLH: 14, diagBase: 25, afterBlock: 8, rxFont: 17, rxAdv: 19, thH: 27, cell: 9.5, note: 8.5, lineH: 13, rowPad: 8,
    secFont: 9.5, secLH: 14, secTitleH: 18, secPad: 10, secGap: 5, sigBox: 30, sigTitleH: 15, footerH: 54 },
  { headerH: 62, logoBox: 42, nameSize: 17, pillH: 32, pillFont: 13, afterHeader: 8, afterTitle: 6, cardBase: 20, cardRowH: 24, labelFont: 7, valueFont: 10, valueDy: 10,
    diagFont: 9.5, diagLH: 13, diagBase: 22, afterBlock: 6, rxFont: 15, rxAdv: 17, thH: 25, cell: 9, note: 8, lineH: 12, rowPad: 6,
    secFont: 9, secLH: 12.5, secTitleH: 16, secPad: 8, secGap: 4, sigBox: 26, sigTitleH: 14, footerH: 50 },
];

// prescription: خروجی getPrescriptionById / getPrescriptionByIdForPatientUser
// items: همه‌ی داروهای همین نسخه (چند دارو با groupId یکسان)؛ اگر داده نشود فقط همین یک دارو چاپ می‌شود.
// options.settings: فقط برای تست؛ اگر داده نشود از دیتابیس خوانده می‌شود.
export async function sendPrescriptionPdf(res, prescription, items = [prescription], options = {}) {
  const medicines = [...(items && items.length ? items : [prescription])].sort((a, b) => a.id - b.id);
  const first = medicines[0];
  const shared = (field) => prescription[field] || medicines.find((m) => m[field])?.[field] || null;
  const diagnosis = shared("diagnosis");
  const instructions = shared("instructions");
  const followUpDate = shared("followUpDate");
  const notes = shared("notes");
  const status = prescription.status || first.status || "active";

  // شماره نسخه = شناسه‌ی اولین داروی همان نسخه (همان شماره‌ای که در فهرست‌های پنل نمایش داده می‌شود)
  const rxNumber = `RX-${String(first.id).padStart(6, "0")}`;
  const issuedAt = first.createdAt || prescription.createdAt;
  const issuedJalali = fmtJalali(issuedAt);
  const issuedGregorian = fmtDate(issuedAt);

  const settings = options.settings || (await getAllSettings());
  const hospitalName = settings.hospitalName || DEFAULT_HOSPITAL_NAME;
  const address = settings.hospitalAddress || DEFAULT_ADDRESS;
  const phone = settings.hospitalPhone || "";
  const email = settings.hospitalEmail || "";
  const logoPath = resolveFilePath(LOGO_DIR, settings.logoUrl);
  const signaturePath = resolveFilePath(SIGNATURES_DIR, prescription.doctorSignatureUrl || first.doctorSignatureUrl);

  // یک بار کل نسخه با تنظیمات سطح T چیدمان می‌شود. سند هنوز به res وصل نیست؛ تعداد صفحه‌ها بررسی می‌شود
  // و فقط سندِ انتخاب‌شده با finish() پاورقی می‌گیرد و ارسال می‌شود.
  function build(T) {
    const doc = new PDFDocument({
      size: "A4",
      margins: { top: 0, left: 36, right: 36, bottom: 0 },
      bufferPages: true,
      info: {
        Title: `نسخه طبی ${rxNumber}`,
        Author: hospitalName,
        Subject: `نسخه طبی ${prescription.patientName || ""}`.trim(),
        Creator: hospitalName,
      },
    });
    doc.registerFont("fa", FONT_REGULAR);
    doc.registerFont("fa-bold", FONT_BOLD);

    const PW = doc.page.width;
    const PH = doc.page.height;
    const L = 36;
    const R = PW - 36; // لبه‌ی راست محتوا
    const W = R - L;
    const FOOTER_H = T.footerH;
    const CONTENT_BOTTOM = PH - FOOTER_H - 8;

    // ---------- ابزارهای رسم متن راست‌به‌چپ ----------
    const measure = (text, font, size) => {
      doc.font(font).fontSize(size);
      return doc.widthOfString(shapeRtl(text));
    };

    // شکستن خط دستی (بدون تکیه بر wrap خودکار pdfkit که با متن راست‌به‌چپ ترتیب کلمات را خراب می‌کند)
    function wrapLines(text, maxWidth, font, size) {
      const lines = [];
      String(text ?? "")
        .split(/\r?\n/)
        .forEach((para) => {
          const words = para.split(/\s+/).filter(Boolean);
          if (!words.length) {
            lines.push("");
            return;
          }
          let line = "";
          for (const w of words) {
            const test = line ? `${line} ${w}` : w;
            if (line && measure(test, font, size) > maxWidth) {
              lines.push(line);
              line = w;
            } else {
              line = test;
            }
          }
          if (line) lines.push(line);
        });
      return lines;
    }

    // رسم یک خط متن در بازه‌ی [xRight - width, xRight]
    function drawText(text, { xRight, y, width, font = "fa", size = 10, color = COLOR.text, align = "right" }) {
      doc.font(font).fontSize(size).fillColor(color);
      doc.text(shapeRtl(text), xRight - width, y, { width, align, lineBreak: false });
    }

    // اگر متن از عرض بیرون می‌زند، اندازه‌ی فونت کمی کوچک می‌شود
    function fitSize(text, width, font, size, min = 8) {
      let s = size;
      while (s > min && measure(text, font, s) > width) s -= 0.5;
      return s;
    }

    // ---------- سربرگ ----------
    function drawFullHeader() {
      const h = T.headerH;
      doc.rect(0, 0, PW, h).fill(COLOR.primary);
      doc.rect(0, h, PW, 4).fill(COLOR.accent);

      let textRight = R;
      if (logoPath) {
        try {
          const box = T.logoBox;
          const bx = R - box;
          const by = (h - box) / 2;
          doc.roundedRect(bx, by, box, box, 10).fill(COLOR.white);
          doc.image(logoPath, bx + 5, by + 5, { fit: [box - 10, box - 10], align: "center", valign: "center" });
          textRight = bx - 14;
        } catch {
          // اگر لوگو خراب بود (یا فرمت پشتیبانی‌نشده)، بدون آن ادامه می‌دهیم
        }
      }
      const tw = textRight - L;
      const showEn = hospitalName === DEFAULT_HOSPITAL_NAME;
      const nameSize = fitSize(hospitalName, tw, "fa-bold", T.nameSize, 14);
      const blockH = nameSize + (showEn ? 8 + 12 : 0);
      const nameY = (h - blockH) / 2 - 3;
      drawText(hospitalName, { xRight: textRight, y: nameY, width: tw, font: "fa-bold", size: nameSize, color: COLOR.white });
      if (showEn) {
        drawText(HOSPITAL_NAME_EN, { xRight: textRight, y: nameY + nameSize + 8, width: tw, font: "fa", size: 12, color: "#cfe3fa" });
      }
      return h + 4;
    }

    function drawCompactHeader() {
      const h = 36;
      doc.rect(0, 0, PW, h).fill(COLOR.primary);
      doc.rect(0, h, PW, 3).fill(COLOR.accent);
      drawText(hospitalName, { xRight: R, y: 10, width: W / 2, font: "fa-bold", size: 12, color: COLOR.white });
      const sub = `نسخه طبی ${rxNumber} (ادامه) — ${prescription.patientName || ""}`.trim();
      drawText(sub, { xRight: L + W / 2 - 10, y: 12, width: W / 2 - 10, font: "fa", size: 9, color: "#cfe3fa", align: "left" });
      return h + 3;
    }

    let y = drawFullHeader() + T.afterHeader;

    // ---------- ردیف عنوان: شماره نسخه | «نسخه طبی» | تاریخ ----------
    {
      const pillW = 188;
      const pillH = T.pillH;
      const px = (PW - pillW) / 2;
      const sideW = px - L - 12;

      doc.roundedRect(px, y, pillW, pillH, pillH / 2).fill(COLOR.primary);
      drawText("نسخه طبی", { xRight: px + pillW, y: y + pillH * 0.13, width: pillW, font: "fa-bold", size: T.pillFont, color: COLOR.white, align: "center" });
      drawText("Prescription", { xRight: px + pillW, y: y + pillH * 0.6, width: pillW, font: "fa", size: 9, color: "#cfe3fa", align: "center" });

      // سمت راست: شماره نسخه
      drawText("شماره نسخه (Rx No)", { xRight: R, y: y + 2, width: sideW, font: "fa", size: 8.5, color: COLOR.muted });
      drawText(rxNumber, { xRight: R, y: y + 15, width: sideW, font: "fa-bold", size: pillH >= 40 ? 15 : 13.5, color: COLOR.primary });
      // سمت چپ: تاریخ نسخه (هجری شمسی)
      const mainDate = issuedJalali || issuedGregorian;
      drawText("تاریخ نسخه (Date)", { xRight: L + sideW, y: y + 2, width: sideW, font: "fa", size: 8.5, color: COLOR.muted, align: "left" });
      drawText(mainDate, { xRight: L + sideW, y: y + 15, width: sideW, font: "fa-bold", size: pillH >= 40 ? 13 : 12, color: COLOR.text, align: "left" });
      y += pillH + T.afterTitle;
    }

    // ---------- کارت اطلاعات داکتر و مریض ----------
    {
      const field = (label, value, xRight, colWidth, fy) => {
        drawText(label, { xRight, y: fy, width: colWidth, font: "fa", size: T.labelFont, color: COLOR.muted });
        const v = String(value || "—");
        const s = fitSize(v, colWidth, "fa-bold", T.valueFont, 8);
        drawText(v, { xRight, y: fy + T.valueDy, width: colWidth, font: "fa-bold", size: s, color: COLOR.text });
      };

      // فقط فیلدهایی که واقعاً در دیتابیس مقدار دارند
      const age = ageAt(prescription.patientDateOfBirth, issuedAt);
      const ageGender = [age !== null ? `${age} سال` : null, GENDER_LABEL[prescription.patientGender] || null].filter(Boolean).join("  —  ");
      const doctorRows = [
        ["نام داکتر (Doctor Name)", prescription.doctorName],
        prescription.doctorDepartment ? ["تخصص / بخش (Specialty)", prescription.doctorDepartment] : null,
        ["شناسه داکتر (Doctor ID)", prescription.doctorCode || (prescription.doctorId ? `#${prescription.doctorId}` : null)],
      ].filter(Boolean);
      const patientRows = [
        ["نام مریض (Patient Name)", prescription.patientName],
        ageGender ? ["سن و جنسیت (Age / Gender)", ageGender] : null,
        ["شناسه مریض (Patient ID)", prescription.patientCode || (prescription.patientId ? `#${prescription.patientId}` : null)],
      ].filter(Boolean);

      const rowH = T.cardRowH;
      const rows = Math.max(doctorRows.length, patientRows.length);
      // عنوان ستون در y+titleOff؛ اولین فیلد ۱۸ واحد پایین‌تر (فاصله‌ی ثابت در همه‌ی سطح‌های فشردگی)
      const titleOff = Math.round(T.cardBase * 0.3);
      const fieldStart = titleOff + 18;
      const cardH = fieldStart + rows * rowH;
      doc.roundedRect(L, y, W, cardH, 8).fillAndStroke(COLOR.softer, COLOR.border);
      const mid = L + W / 2;
      doc.moveTo(mid, y + 10).lineTo(mid, y + cardH - 10).strokeColor(COLOR.border).lineWidth(1).stroke();

      const colW = W / 2 - 34;
      const rightCol = R - 16;
      const leftCol = mid - 16;
      drawText("اطلاعات داکتر", { xRight: rightCol, y: y + titleOff, width: colW, font: "fa-bold", size: 9, color: COLOR.primary });
      doctorRows.forEach(([label, value], i) => field(label, value, rightCol, colW, y + fieldStart + i * rowH));
      drawText("اطلاعات مریض", { xRight: leftCol, y: y + titleOff, width: colW, font: "fa-bold", size: 9, color: COLOR.primary });
      patientRows.forEach(([label, value], i) => field(label, value, leftCol, colW, y + fieldStart + i * rowH));
      y += cardH + T.afterBlock;
    }

    // ---------- کادر تشخیص ----------
    if (diagnosis) {
      const innerW = W - 32;
      const lines = wrapLines(diagnosis, innerW, "fa-bold", T.diagFont);
      const boxH = T.diagBase + lines.length * T.diagLH - 4;
      doc.roundedRect(L, y, W, boxH, 8).fillAndStroke(COLOR.soft, COLOR.border);
      doc.rect(R - 4, y + 6, 4, boxH - 12).fill(COLOR.primary);
      drawText("تشخیص (Diagnosis)", { xRight: R - 16, y: y + 6, width: innerW, font: "fa", size: T.labelFont, color: COLOR.muted });
      lines.forEach((ln, i) => drawText(ln, { xRight: R - 16, y: y + 8 + T.labelFont + 6 + i * T.diagLH, width: innerW, font: "fa-bold", size: T.diagFont }));
      y += boxH + T.afterBlock;
    }

    // ---------- جدول Rx ----------
    // ستون‌های اختیاری (تعداد، نحوه مصرف، توضیحات) فقط وقتی حداقل یک دارو مقدار دارد چاپ می‌شوند
    const hasQuantity = medicines.some((m) => m.quantity);
    const hasUsage = medicines.some((m) => m.frequency);
    const hasNotes = medicines.some((m) => m.medicineNotes);
    const cols = [
      { key: "idx", fa: "#", en: "", width: 30, align: "center" },
      { key: "medicationName", fa: "نام دارو", en: "Medicine", width: 0, align: "right" },
      { key: "dosage", fa: "دوز", en: "Dosage", width: 66, align: "center" },
      ...(hasQuantity ? [{ key: "quantity", fa: "تعداد", en: "Qty", width: 54, align: "center" }] : []),
      { key: "duration", fa: "مدت مصرف", en: "Duration", width: 72, align: "center" },
      ...(hasUsage ? [{ key: "frequency", fa: "نحوه مصرف", en: "Usage", width: 92, align: "right" }] : []),
      ...(hasNotes ? [{ key: "medicineNotes", fa: "توضیحات", en: "Notes", width: 108, align: "right" }] : []),
    ];
    cols[1].width = W - cols.reduce((sum, c) => sum + c.width, 0);
    // موقعیت ستون‌ها از راست به چپ
    let cursor = R;
    cols.forEach((c) => {
      c.xRight = cursor;
      cursor -= c.width;
    });

    const NEW_PAGE_TOP = () => {
      doc.addPage();
      return drawCompactHeader() + 16;
    };

    function drawTableHeader() {
      const h = T.thH;
      doc.rect(L, y, W, h).fillAndStroke(COLOR.soft, COLOR.border);
      cols.forEach((c) => {
        if (c.key !== "idx") doc.moveTo(c.xRight - c.width, y).lineTo(c.xRight - c.width, y + h).strokeColor(COLOR.border).lineWidth(0.8).stroke();
        const pad = 8;
        const cw = c.width - pad * 2;
        const faY = c.en ? y + h * 0.15 : y + (h - 12) / 2;
        drawText(c.fa, { xRight: c.xRight - pad, y: faY, width: cw, font: "fa-bold", size: fitSize(c.fa, cw, "fa-bold", 9.5, 7.5), color: COLOR.primary, align: c.align });
        if (c.en) drawText(`(${c.en})`, { xRight: c.xRight - pad, y: y + h * 0.15 + 13, width: cw, font: "fa", size: fitSize(`(${c.en})`, cw, "fa", 7.5, 6), color: COLOR.muted, align: c.align });
      });
      y += h;
    }

    // عنوان Rx
    doc.font("fa-bold").fontSize(T.rxFont).fillColor(COLOR.primary).text("Rx", R - 60, y - 2, { width: 60, align: "right", lineBreak: false });
    y += T.rxAdv;
    drawTableHeader();

    const cellFont = "fa";
    const lineH = T.lineH;
    medicines.forEach((med, index) => {
      const cells = cols.map((c) => {
        const raw = c.key === "idx" ? String(index + 1) : med[c.key];
        const value = raw === null || raw === undefined || raw === "" ? "—" : String(raw);
        const size = c.key === "medicineNotes" ? T.note : T.cell;
        // ستون شماره‌ی ردیف باریک است؛ حاشیه‌ی کمتر تا «10» و بالاتر در دو خط شکسته نشود
        return { c, size, lines: wrapLines(value, c.width - (c.key === "idx" ? 6 : 16), cellFont, size) };
      });
      const rowH = Math.max(...cells.map((x) => x.lines.length * lineH)) + T.rowPad;
      if (y + rowH > CONTENT_BOTTOM) {
        y = NEW_PAGE_TOP();
        drawTableHeader();
      }
      doc.rect(L, y, W, rowH).fillAndStroke(index % 2 ? COLOR.softer : COLOR.white, COLOR.border);
      cells.forEach(({ c, lines, size }) => {
        if (c.key !== "idx") doc.moveTo(c.xRight - c.width, y).lineTo(c.xRight - c.width, y + rowH).strokeColor(COLOR.border).lineWidth(0.8).stroke();
        lines.forEach((ln, i) =>
          drawText(ln, {
            xRight: c.xRight - (c.key === "idx" ? 3 : 8),
            y: y + T.rowPad / 2 + i * lineH,
            width: c.width - (c.key === "idx" ? 6 : 16),
            font: c.key === "medicationName" ? "fa-bold" : cellFont,
            size,
            color: c.key === "medicineNotes" ? COLOR.muted : COLOR.text,
            align: c.align,
          })
        );
      });
      y += rowH;
    });
    y += T.afterBlock;

    // ---------- بخش متنی با عنوان (دستورالعمل / توضیحات داکتر) با شکستن صفحه‌ی امن ----------
    function textSection(faTitle, enTitle, text) {
      const innerW = W - 32;
      const lh = T.secLH;
      const lines = wrapLines(text, innerW, "fa", T.secFont);
      const titleH = T.secTitleH;
      let i = 0;
      let firstChunk = true;
      while (i < lines.length) {
        const headH = firstChunk ? titleH : 0;
        let avail = Math.floor((CONTENT_BOTTOM - y - headH - T.secPad) / lh);
        if (avail < 1) {
          y = NEW_PAGE_TOP();
          avail = Math.floor((CONTENT_BOTTOM - y - headH - T.secPad) / lh);
        }
        const chunk = lines.slice(i, i + avail);
        const boxH = headH + chunk.length * lh + T.secPad;
        doc.roundedRect(L, y, W, boxH, 8).fillAndStroke(COLOR.softer, COLOR.border);
        doc.rect(R - 4, y + 6, 4, boxH - 12).fill(COLOR.primary);
        if (firstChunk) {
          drawText(`${faTitle} (${enTitle})`, { xRight: R - 16, y: y + 5, width: innerW, font: "fa-bold", size: Math.min(10, T.secFont), color: COLOR.primary });
        }
        chunk.forEach((ln, k) => drawText(ln, { xRight: R - 16, y: y + T.secPad / 2 + headH + k * lh, width: innerW, size: T.secFont }));
        y += boxH + T.secGap;
        i += chunk.length;
        firstChunk = false;
      }
    }

    if (instructions) textSection("دستورالعمل", "Instructions", instructions);
    if (notes) textSection("توضیحات داکتر", "Doctor's Notes", notes);

    // ---------- امضا و مهر داکتر (راست) + تاریخ پیگیری (چپ، در صورت وجود) ----------
    {
      const sigW = 250;
      const boxH = T.sigBox;
      const titleH = T.sigTitleH;
      const nameLine = [prescription.doctorName, prescription.doctorDepartment].filter(Boolean).join("  —  ");
      const sigH = titleH + boxH + (nameLine ? 20 : 4);
      // پایین صفحه‌ی آخر نگه داشته می‌شود؛ فقط اگر واقعاً جا نباشد به صفحه‌ی بعد می‌رود
      let sy = Math.max(y + 2, CONTENT_BOTTOM - sigH);
      if (sy + sigH > CONTENT_BOTTOM) {
        sy = NEW_PAGE_TOP();
      }
      const sx = R - sigW;
      const titleText = "امضا و مهر داکتر (Doctor Signature & Stamp)";
      drawText(titleText, { xRight: R, y: sy, width: sigW, font: "fa-bold", size: fitSize(titleText, sigW, "fa-bold", 10.5, 8), color: COLOR.primary, align: "center" });

      const by = sy + titleH;
      let signed = false;
      if (signaturePath) {
        try {
          doc.image(signaturePath, sx + 8, by + 3, { fit: [sigW - 16, boxH - 6], align: "center", valign: "center" });
          doc.moveTo(sx, by + boxH).lineTo(R, by + boxH).strokeColor(COLOR.border).lineWidth(1).stroke();
          signed = true;
        } catch {
          // فرمت پشتیبانی‌نشده یا فایل خراب: به کادر خالی برای امضای دستی برمی‌گردیم
        }
      }
      if (!signed) {
        doc.roundedRect(sx, by, sigW, boxH, 6).dash(3, { space: 3 }).strokeColor(COLOR.border).lineWidth(1).stroke().undash();
      }
      if (nameLine) {
        drawText(nameLine, { xRight: R, y: by + boxH + 5, width: sigW, font: "fa-bold", size: fitSize(nameLine, sigW, "fa-bold", 9.5, 7.5), color: COLOR.text, align: "center" });
      }

      if (followUpDate) {
        const fw = W - sigW - 20;
        const jal = fmtJalali(followUpDate);
        doc.roundedRect(L, by, fw, boxH, 8).fillAndStroke(COLOR.softer, COLOR.border);
        doc.rect(L + fw - 4, by + 6, 4, boxH - 12).fill(COLOR.primary);
        const ty = by + Math.max(3, (boxH - 30) / 2);
        drawText("تاریخ پیگیری (Follow-up)", { xRight: L + fw - 14, y: ty, width: fw - 24, font: "fa", size: 8, color: COLOR.muted });
        drawText(jal || fmtDate(followUpDate), { xRight: L + fw - 14, y: ty + 12, width: fw - 24, font: "fa-bold", size: 11.5, color: COLOR.text });
      }
    }

    const pageCount = doc.bufferedPageRange().count;

    // ---------- پاورقی و مهر وضعیت روی همه‌ی صفحه‌ها؛ سپس پایان سند ----------
    function finish() {
      const range = doc.bufferedPageRange();
      for (let p = 0; p < range.count; p++) {
        doc.switchToPage(range.start + p);

        // نسخه‌ی لغوشده: مهر مورب کمرنگ روی صفحه تا مثل نسخه‌ی معتبر استفاده نشود (وضعیت واقعی ثبت‌شده در دیتابیس)
        if (status === "cancelled") {
          doc.save();
          doc.opacity(0.16);
          doc.rotate(-28, { origin: [PW / 2, PH / 2] });
          const bw = 300;
          const bh = 84;
          doc.roundedRect(PW / 2 - bw / 2, PH / 2 - bh / 2, bw, bh, 12).lineWidth(4).strokeColor(COLOR.danger).stroke();
          drawText("لغو شده", { xRight: PW / 2 + bw / 2, y: PH / 2 - 30, width: bw, font: "fa-bold", size: 44, color: COLOR.danger, align: "center" });
          doc.restore();
        }

        const fy = PH - FOOTER_H;
        doc.rect(0, fy, PW, FOOTER_H).fill(COLOR.primary);
        doc.rect(0, fy - 3, PW, 3).fill(COLOR.accent);

        const contact = [`آدرس: ${address}`, phone ? `تلفن: ${phone}` : null, email ? `ایمیل: ${email}` : null].filter(Boolean).join("     |     ");
        drawText(contact, { xRight: R, y: fy + FOOTER_H * 0.14, width: W, font: "fa", size: 9.5, color: COLOR.white, align: "center" });
        drawText(`این نسخه به صورت الکترونیکی از سامانه ${hospitalName} صادر شده است.`, {
          xRight: R, y: fy + FOOTER_H * 0.42, width: W, font: "fa", size: 8.5, color: "#cfe3fa", align: "center",
        });
        drawText(`شماره نسخه: ${rxNumber}     |     تاریخ صدور: ${fmtJalali(new Date()) || fmtDate(new Date())}`, { xRight: R, y: fy + FOOTER_H * 0.7, width: W / 2, font: "fa", size: 8, color: "#cfe3fa", align: "right" });
        drawText(`صفحه ${p + 1} از ${range.count}`, { xRight: L + W / 2, y: fy + FOOTER_H * 0.7, width: W / 2, font: "fa", size: 8, color: "#cfe3fa", align: "left" });
      }
      doc.end();
    }

    return { doc, pageCount, finish };
  }

  // فشرده‌ترین سطحی که کل نسخه را در «یک» ورق جا بدهد؛ اگر هیچ سطحی کافی نبود، سطح ۰ در چند صفحه
  let built = null;
  for (const level of LEVELS) {
    const attempt = build(level);
    if (attempt.pageCount === 1) {
      built = attempt;
      break;
    }
  }
  if (!built) built = build(LEVELS[0]);

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="prescription-${rxNumber}.pdf"`);
  // سند صحی حساس: نباید در کش مرورگر/پروکسی ذخیره شود
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Content-Type-Options", "nosniff");
  built.doc.pipe(res);
  built.finish();
}

// کارت بیمار (با QR) — یک کارت کوچک چاپی حاوی نام، کد بیمار و QR همان کد، برای اینکه
// پذیرش با اسکن آن به‌سرعت پرونده‌ی بیمار را باز کند، بدون تایپ نام/جستجوی دستی.
// از همان فونت فارسی pdfkit که در utils/patientInfoPdf.js استفاده شده پیروی می‌کند.

import PDFDocument from "pdfkit";
import QRCode from "qrcode";
import path from "path";
import { fileURLToPath } from "url";
import { shapeRtl } from "./rtlText.js";
import { getAllSettings } from "../models/Settings.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FONT_REGULAR = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Medium.ttf");
const FONT_BOLD = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Bold.ttf");

// patient: حداقل باید id, fullName, publicCode را داشته باشد (خروجی getPatientDetailById کافی است)
export async function sendPatientCardPdf(res, patient) {
  const settings = await getAllSettings();
  const hospitalName = settings.hospitalName || "شفاخانه افغان آریا";

  // QR فقط کد را حمل می‌کند (نه اطلاعات شخصی) — پذیرش با اسکن، کد را در فرم جستجو وارد می‌کند
  const qrDataUrl = await QRCode.toDataURL(patient.publicCode, { margin: 1, width: 300 });
  const qrBuffer = Buffer.from(qrDataUrl.split(",")[1], "base64");

  // اندازه‌ی کارت: نزدیک به یک کارت شناسایی (85 × 54 میلی‌متر ≈ 241 × 153 نقطه)
  const doc = new PDFDocument({ size: [241, 153], margin: 12 });
  doc.registerFont("fa", FONT_REGULAR);
  doc.registerFont("fa-bold", FONT_BOLD);

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="patient-card-${patient.id}.pdf"`);
  doc.pipe(res);

  const rightEdge = doc.page.width - doc.page.margins.right;
  const usableWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;

  doc.font("fa-bold").fontSize(11).text(shapeRtl(hospitalName), doc.page.margins.left, doc.page.margins.top, {
    width: usableWidth,
    align: "right",
  });

  const qrSize = 70;
  const qrY = doc.y + 6;
  doc.image(qrBuffer, rightEdge - qrSize, qrY, { width: qrSize, height: qrSize });

  const textWidth = usableWidth - qrSize - 10;
  let textY = qrY;
  doc.font("fa-bold").fontSize(12).text(shapeRtl(patient.fullName || "—"), doc.page.margins.left, textY, {
    width: textWidth,
    align: "right",
  });
  textY = doc.y + 6;
  doc.font("fa").fontSize(9).text(shapeRtl("کد بیمار"), doc.page.margins.left, textY, { width: textWidth, align: "right" });
  textY = doc.y + 1;
  doc.font("fa-bold").fontSize(13).text(patient.publicCode || "—", doc.page.margins.left, textY, {
    width: textWidth,
    align: "right",
  });

  doc
    .font("fa")
    .fontSize(7)
    .fillColor("#666666")
    .text(
      shapeRtl("این کارت را در مراجعات بعدی همراه داشته باشید"),
      doc.page.margins.left,
      doc.page.height - doc.page.margins.bottom - 12,
      { width: usableWidth, align: "center" }
    );

  doc.end();
}

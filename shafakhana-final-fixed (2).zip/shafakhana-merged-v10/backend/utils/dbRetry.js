// تلاش دوباره‌ی یک تراکنش وقتی دیتابیس آن را به‌خاطر بن‌بست (Deadlock) یا انتظار بیش‌ازحد قفل
// قربانی کرده است. این خطاها «موقتی و قابل تکرار» هستند: دیتابیس عمداً یکی از تراکنش‌های
// هم‌زمان را رها می‌کند تا بقیه پیش بروند؛ اجرای دوباره‌ی همان تراکنش معمولاً موفق می‌شود.
// بدون این تلاش دوباره، یک رزرو کاملاً قانونی با خطای ۵۰۰ به کاربر برمی‌گشت.
const RETRYABLE_CODES = new Set(["ER_LOCK_DEADLOCK", "ER_LOCK_WAIT_TIMEOUT"]);
const RETRYABLE_ERRNO = new Set([1213, 1205]);

export function isRetryableTxError(err) {
  return !!err && (RETRYABLE_CODES.has(err.code) || RETRYABLE_ERRNO.has(err.errno));
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * @param {() => Promise<T>} fn  کل تراکنش (باید خودش اتصال بگیرد، شروع/commit/rollback کند و آزاد کند)
 * @param {{retries?: number, baseDelayMs?: number}} options
 */
export async function withTxRetry(fn, { retries = 4, baseDelayMs = 25 } = {}) {
  for (let attempt = 0; ; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (!isRetryableTxError(err) || attempt >= retries) throw err;
      // تأخیر تصادفی (jitter) تا تراکنش‌های رقیب دوباره دقیقاً هم‌زمان برخورد نکنند
      await sleep(baseDelayMs * (attempt + 1) + Math.floor(Math.random() * baseDelayMs * 2));
    }
  }
}

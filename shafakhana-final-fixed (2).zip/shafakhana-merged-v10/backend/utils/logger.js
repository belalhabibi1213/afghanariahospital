import util from "util";

// ---------- لاگ ساخت‌یافته (JSON) ----------
// بدون وابستگی خارجی؛ API ساده‌ی سازگار با pino:  logger.info({ userId }, "پیام")  /  logger.child({ reqId })
// - production (یا LOG_FORMAT=json): هر لاگ یک خط JSON روی stdout/stderr (قابل جمع‌آوری با Loki/ELK/Datadog)
// - توسعه: خروجی خوانا.  سطح با LOG_LEVEL (debug|info|warn|error، پیش‌فرض info).
// - فیلدهای حساس (رمز، توکن، کوکی، کد OTP، راز MFA و ...) خودکار «[REDACTED]» می‌شوند.
const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
const REDACT_KEY = /pass(word)?|token|authorization|cookie|secret|otp|code(hash)?$|csrf|recovery|apikey|api_key/i;

const threshold = LEVELS[(process.env.LOG_LEVEL || "info").toLowerCase()] ?? LEVELS.info;
export const JSON_MODE = (process.env.LOG_FORMAT || (process.env.NODE_ENV === "production" ? "json" : "pretty")).toLowerCase() === "json";

export function redact(value, depth = 0) {
  if (value == null || depth > 5) return value;
  if (value instanceof Error) return { name: value.name, message: value.message, code: value.code, stack: value.stack };
  if (Array.isArray(value)) return value.slice(0, 50).map((v) => redact(v, depth + 1));
  if (typeof value === "object") {
    const out = {};
    for (const [k, v] of Object.entries(value)) out[k] = REDACT_KEY.test(k) ? "[REDACTED]" : redact(v, depth + 1);
    return out;
  }
  return value;
}

let write = (stream, line) => stream.write(line + "\n");
export function _setWriterForTests(fn) { write = (_s, line) => fn(line); }

function emit(level, bindings, a, b) {
  if (LEVELS[level] < threshold) return;
  let fields = {};
  let msg = "";
  if (a && typeof a === "object") { fields = redact(a); msg = typeof b === "string" ? b : ""; }
  else { msg = typeof a === "string" ? a : util.format(a); }
  const record = { level, time: new Date().toISOString(), ...redact(bindings), ...fields, msg };
  const stream = LEVELS[level] >= LEVELS.warn ? process.stderr : process.stdout;
  if (JSON_MODE) return write(stream, JSON.stringify(record));
  const { level: _l, time, msg: _m, ...rest } = record;
  const extra = Object.keys(rest).length ? " " + util.inspect(rest, { breakLength: Infinity, depth: 4 }) : "";
  write(stream, `${time} ${level.toUpperCase()} ${msg}${extra}`);
}

function make(bindings = {}) {
  return {
    debug: (a, b) => emit("debug", bindings, a, b),
    info: (a, b) => emit("info", bindings, a, b),
    warn: (a, b) => emit("warn", bindings, a, b),
    error: (a, b) => emit("error", bindings, a, b),
    child: (extra) => make({ ...bindings, ...extra }),
  };
}

export const logger = make();

// console.log/warn/error را (در حالت JSON) به logger هدایت می‌کند تا حدود ۴۵ فایلی که هنوز از console
// استفاده می‌کنند بدون ویرایش، خروجی ساخت‌یافته (و redact شده) بدهند.
let bridged = false;
export function bridgeConsole() {
  if (bridged || !JSON_MODE) return;
  bridged = true;
  const fmt = (args) => {
    const err = args.find((x) => x instanceof Error);
    return { msg: args.map((x) => (x instanceof Error ? x.message : typeof x === "string" ? x : util.inspect(x, { depth: 3 }))).join(" "), ...(err ? { err } : {}) };
  };
  console.log = (...a) => { const { msg, err } = fmt(a); logger.info(err ? { err } : {}, msg); };
  console.info = console.log;
  console.warn = (...a) => { const { msg, err } = fmt(a); logger.warn(err ? { err } : {}, msg); };
  console.error = (...a) => { const { msg, err } = fmt(a); logger.error(err ? { err } : {}, msg); };
}

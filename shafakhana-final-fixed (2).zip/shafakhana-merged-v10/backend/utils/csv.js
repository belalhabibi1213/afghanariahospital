// ساخت امن سلول CSV.
//
// ۱) نقل‌قول: " به "" تبدیل و کل مقدار داخل "..." قرار می‌گیرد.
// ۲) جلوگیری از «تزریق فرمول» (CSV/Formula Injection): اگر متنِ سلول با = + - @ یا Tab/CR شروع
//    شود، Excel و LibreOffice آن را فرمول فرض می‌کنند و مثلاً =HYPERLINK(...) یا =cmd|'/C calc'!A0
//    اجرا می‌شود. فیلدهایی مثل نام کاربر و User-Agent را کاربر کنترل می‌کند و سوپرادمین فایل را
//    در Excel باز می‌کند؛ پس به ابتدای چنین متنی یک ' (آپاستروف) اضافه می‌شود تا همیشه «متن» باشد.
//    فقط مقدارهای «متنی» اصلاح می‌شوند؛ عددِ واقعی (مثلاً ‎-5) دست‌نخورده می‌ماند.
const FORMULA_START = /^[=+\-@\t\r]/;

export function escapeCsvCell(value) {
  let str = value === null || value === undefined ? "" : String(value);
  if (typeof value === "string" && FORMULA_START.test(str)) {
    str = `'${str}`;
  }
  return `"${str.replace(/"/g, '""')}"`;
}

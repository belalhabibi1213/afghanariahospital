import crypto from "crypto";

// ---------- رمزنگاری فایل‌های پشتیبان (AES-256-GCM) ----------
// بکاپ شامل همه‌ی داده‌های پزشکی، هش رمزها و راز MFA است؛ بدون رمزنگاری، هر کسی که به دیسک/volume
// یا کپی بکاپ برسد همه‌چیز را می‌خواند. با تنظیم BACKUP_ENCRYPTION_KEY (یک رمز طولانی و تصادفی، ≥ ۳۲
// نویسه) همه‌ی بکاپ‌های جدید رمزنگاری می‌شوند (پسوند .sql.enc). فایل‌های قدیمی (.sql ساده) همچنان
// قابل بازیابی‌اند.
//
// قالب فایل:  "SFBK1\0" (۶ بایت) | salt (۱۶) | iv (۱۲) | ciphertext | authTag (۱۶)
// کلید هر فایل با scrypt از رمز و salt تصادفی همان فایل مشتق می‌شود (کلید یکسان بین فایل‌ها تکرار نمی‌شود).
// اگر کلید را گم کنید، بکاپ‌های رمزنگاری‌شده غیرقابل بازیابی‌اند؛ آن را جدا از سرور نگه دارید.

export const MAGIC = Buffer.from("SFBK1\0", "latin1");
const SALT_LEN = 16;
const IV_LEN = 12;
const TAG_LEN = 16;
export const MIN_ENCRYPTED_SIZE = MAGIC.length + SALT_LEN + IV_LEN + TAG_LEN;
const MIN_KEY_LENGTH = 32;

function configuredKey() {
  const key = process.env.BACKUP_ENCRYPTION_KEY;
  return typeof key === "string" && key.length > 0 ? key : null;
}

export function isBackupEncryptionEnabled() {
  const key = configuredKey();
  if (key && key.length < MIN_KEY_LENGTH) {
    console.warn(`⚠️  BACKUP_ENCRYPTION_KEY کوتاه است (حداقل ${MIN_KEY_LENGTH} نویسه توصیه می‌شود)؛ یک رمز تصادفی بلند بگذارید.`);
  }
  return !!key;
}

function deriveKey(passphrase, salt) {
  return crypto.scryptSync(passphrase, salt, 32, { N: 2 ** 15, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });
}

export function looksEncrypted(buf) {
  return Buffer.isBuffer(buf) && buf.length >= MAGIC.length && buf.subarray(0, MAGIC.length).equals(MAGIC);
}

export function encryptBackup(plainBuffer) {
  const key = configuredKey();
  if (!key) throw Object.assign(new Error("BACKUP_ENCRYPTION_KEY تنظیم نشده است"), { code: "BACKUP_KEY_MISSING" });
  const salt = crypto.randomBytes(SALT_LEN);
  const iv = crypto.randomBytes(IV_LEN);
  const cipher = crypto.createCipheriv("aes-256-gcm", deriveKey(key, salt), iv);
  cipher.setAAD(MAGIC);
  const ct = Buffer.concat([cipher.update(plainBuffer), cipher.final()]);
  return Buffer.concat([MAGIC, salt, iv, ct, cipher.getAuthTag()]);
}

// خطا: BACKUP_KEY_MISSING (کلید تنظیم نیست) | BACKUP_DECRYPT_FAILED (کلید اشتباه یا فایل دست‌کاری/خراب)
export function decryptBackup(encBuffer) {
  const key = configuredKey();
  if (!key) throw Object.assign(new Error("برای بازیابی این بکاپ رمزنگاری‌شده، BACKUP_ENCRYPTION_KEY لازم است"), { code: "BACKUP_KEY_MISSING" });
  if (!looksEncrypted(encBuffer) || encBuffer.length < MIN_ENCRYPTED_SIZE) {
    throw Object.assign(new Error("قالب فایل بکاپ رمزنگاری‌شده نامعتبر است"), { code: "BACKUP_DECRYPT_FAILED" });
  }
  let off = MAGIC.length;
  const salt = encBuffer.subarray(off, (off += SALT_LEN));
  const iv = encBuffer.subarray(off, (off += IV_LEN));
  const tag = encBuffer.subarray(encBuffer.length - TAG_LEN);
  const ct = encBuffer.subarray(off, encBuffer.length - TAG_LEN);
  try {
    const decipher = crypto.createDecipheriv("aes-256-gcm", deriveKey(key, salt), iv);
    decipher.setAAD(MAGIC);
    decipher.setAuthTag(tag);
    return Buffer.concat([decipher.update(ct), decipher.final()]);
  } catch {
    throw Object.assign(new Error("رمزگشایی بکاپ ناموفق بود (کلید اشتباه است یا فایل دست‌کاری شده)"), { code: "BACKUP_DECRYPT_FAILED" });
  }
}

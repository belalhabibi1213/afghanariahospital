// یادآوری خودکار نوبت به بیمار
//
// هر ۱۰ دقیقه، نوبت‌های «تایید شده»‌ای که تا appointmentReminderHours ساعت دیگر (پیش‌فرض ۲۴)
// شروع می‌شوند و هنوز یادآوری برایشان ارسال نشده، پیدا می‌شوند و برای بیمار:
//   • یک اعلان درون‌برنامه‌ای (اگر بیمار حساب کاربری دارد)
//   • یک ایمیل (اگر ایمیل بیمار ثبت شده و ارسال ایمیل فعال است)
// ارسال می‌شود. هر نوبت فقط یک‌بار یادآوری می‌گیرد (ستون appointments.reminderSentAt).
// چون شرط «نوبت تا X ساعت دیگر» است، اگر سرور مدتی خاموش بوده باشد یادآوری‌های عقب‌افتاده
// در اولین اجرای بعدی (تا قبل از شروع نوبت) ارسال می‌شوند.
// مقدار تنظیم ۰ = یادآوری غیرفعال.

import cron from "node-cron";
import db from "../db.js";
import { getAllSettings } from "../models/Settings.js";
import { createNotification } from "../models/Notification.js";
import { sendAppointmentReminderEmail } from "./mailer.js";

const BATCH_LIMIT = 200;
let running = false;

export async function sendDueAppointmentReminders() {
  const settings = await getAllSettings();
  const hours = Math.floor(Number(settings.appointmentReminderHours));
  if (!Number.isFinite(hours) || hours <= 0) return { skipped: true, sent: 0 };

  const [rows] = await db.query(
    `SELECT a.id,
            DATE_FORMAT(a.appointmentDate, '%Y-%m-%d') AS dateStr,
            TIME_FORMAT(a.appointmentTime, '%H:%i') AS timeStr,
            d.fullName AS doctorName,
            p.fullName AS patientName, p.email AS patientEmail, p.userId AS patientUserId
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     WHERE a.status = 'confirmed'
       AND a.reminderSentAt IS NULL
       AND TIMESTAMP(a.appointmentDate, a.appointmentTime) > NOW()
       AND TIMESTAMP(a.appointmentDate, a.appointmentTime) <= NOW() + INTERVAL ${hours} HOUR
     ORDER BY a.appointmentDate, a.appointmentTime
     LIMIT ${BATCH_LIMIT}`
  );

  let sent = 0;
  for (const row of rows) {
    // «رزرو» کردن نوبت پیش از ارسال: اگر دو اجرا هم‌زمان شوند، فقط یکی موفق می‌شود
    const [claim] = await db.query(
      "UPDATE appointments SET reminderSentAt = NOW() WHERE id = ? AND reminderSentAt IS NULL",
      [row.id]
    );
    if (claim.affectedRows !== 1) continue;

    try {
      if (row.patientUserId) {
        await createNotification({
          userId: row.patientUserId,
          title: "یادآوری نوبت",
          message: `یادآوری: نوبت شما نزد ${row.doctorName} در تاریخ ${row.dateStr} ساعت ${row.timeStr} است. اگر نمی‌توانید بیایید، لطفاً نوبت را لغو کنید.`,
          type: "appointment",
          relatedId: row.id,
        });
      }
      if (row.patientEmail) {
        await sendAppointmentReminderEmail({
          to: row.patientEmail,
          fullName: row.patientName,
          doctorName: row.doctorName,
          appointmentDate: row.dateStr,
          appointmentTime: row.timeStr,
        });
      }
      sent += 1;
    } catch (err) {
      console.error(`خطا در ارسال یادآوری نوبت ${row.id}:`, err.message);
    }
  }
  return { skipped: false, sent };
}

async function run() {
  if (running) return;
  running = true;
  try {
    const result = await sendDueAppointmentReminders();
    if (result.sent > 0) console.log(`🔔 یادآوری نوبت برای ${result.sent} بیمار ارسال شد`);
  } catch (err) {
    console.error("❌ خطا در ارسال یادآوری‌های نوبت:", err.message);
  } finally {
    running = false;
  }
}

export function initAppointmentReminderScheduler() {
  cron.schedule("*/10 * * * *", run);
  const startupRun = setTimeout(run, 90 * 1000);
  startupRun.unref?.();
  console.log("🔔 یادآوری خودکار نوبت‌ها فعال شد (بررسی هر ۱۰ دقیقه؛ مدت از «تنظیمات سیستم» قابل تغییر است)");
}

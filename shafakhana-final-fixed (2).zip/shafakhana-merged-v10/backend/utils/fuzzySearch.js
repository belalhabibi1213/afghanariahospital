// موتور رتبه‌بندی/تطبیق فازی جستجوی سراسری — لایه‌ی درون-برنامه‌ای (in-app) که روی
// نتایج خام SQL (LIKE) اجرا می‌شود تا سه چیزی را فراهم کند که خودِ MySQL
// (بدون افزونه‌های اضافی) به‌خوبی پشتیبانی نمی‌کند:
//   ۱) جستجوی جزئی واقعی (substring در هر جای کلمه، نه فقط پیشوند)
//   ۲) تحمل غلط‌ املایی (fuzzy / typo-tolerant) با فاصله‌ی ویرایشی محدود (Levenshtein)
//   ۳) امتیازدهی/رتبه‌بندی بر اساس میزان تطابق + محدوده‌های دقیق برای هایلایت متن
//
// نکته‌ی مهم درباره‌ی هم‌ترازی ایندکس‌ها: normalizeText فقط تبدیل‌های «یک‌حرف
// به‌یک‌حرف» (کوچک‌سازی حروف لاتین + یکسان‌سازی چند حرف عربی/دری پرتکرار) انجام
// می‌دهد و هیچ کاراکتری حذف/اضافه نمی‌کند؛ بنابراین طول رشته و اندیس‌های به‌دست‌آمده
// دقیقاً روی متن اصلی (غیرنرمال‌شده) هم معتبر می‌مانند و می‌توان مستقیماً برای
// هایلایت‌کردن در فرانت‌اند استفاده‌شان کرد.

// یکسان‌سازی کاراکترهای عربی/دری که کاربران معمولاً به‌جای هم تایپ می‌کنند
// (کیبورد عربی در برابر دری) — هر جایگزینی دقیقاً یک کاراکتر با یک کاراکتر است.
const CHAR_MAP = {
  // --- «ی» در کیبوردهای عربی/پشتو/اردو ---
  "\u064A": "\u06CC", // ي (عربی) -> ی
  "\u0649": "\u06CC", // ى (الف مقصوره) -> ی
  "\u06D0": "\u06CC", // ې (پشتو) -> ی
  "\u06CD": "\u06CC", // ۍ (پشتو) -> ی
  "\u0626": "\u06CC", // ئ -> ی
  "\u06D2": "\u06CC", // ے (اردو) -> ی
  // --- «ک» و «گ» ---
  "\u0643": "\u06A9", // ك (عربی) -> ک
  "\u06AA": "\u06A9", // ڪ -> ک
  "\u06AB": "\u06AF", // ګ (پشتو) -> گ
  // --- «ه» ---
  "\u0629": "\u0647", // ة -> ه
  "\u06C0": "\u0647", // ۀ -> ه
  "\u06C1": "\u0647", // ہ -> ه
  "\u06BE": "\u0647", // ھ -> ه
  "\u06D5": "\u0647", // ە -> ه
  // --- «و» و «ا» ---
  "\u0624": "\u0648", // ؤ -> و
  "\u0623": "\u0627", // أ -> ا
  "\u0625": "\u0627", // إ -> ا
  "\u0671": "\u0627", // ٱ -> ا
  // --- حروف ویژه‌ی پشتو به نزدیک‌ترین حرف دری (تا با هر کیبورد پیدا شود) ---
  "\u0689": "\u062F", // ډ -> د
  "\u0693": "\u0631", // ړ -> ر
  "\u0691": "\u0631", // ڑ -> ر
  "\u067C": "\u062A", // ټ -> ت
  "\u06BC": "\u0646", // ڼ -> ن
  "\u06BA": "\u0646", // ں -> ن
  "\u069A": "\u0634", // ښ -> ش
  "\u0696": "\u0698", // ږ -> ژ
  "\u0681": "\u062C", // ځ -> ج
  "\u0685": "\u0686", // څ -> چ
  // --- جداکننده‌ها ---
  "\u200C": " ", // نیم‌فاصله -> فاصله
  "\u200D": " ",
  "\u0640": " ", // کشیده (ـ)
  // --- ارقام فارسی/عربی -> لاتین ---
  "\u06F0": "0", "\u06F1": "1", "\u06F2": "2", "\u06F3": "3", "\u06F4": "4",
  "\u06F5": "5", "\u06F6": "6", "\u06F7": "7", "\u06F8": "8", "\u06F9": "9",
  "\u0660": "0", "\u0661": "1", "\u0662": "2", "\u0663": "3", "\u0664": "4",
  "\u0665": "5", "\u0666": "6", "\u0667": "7", "\u0668": "8", "\u0669": "9",
};

const CHAR_MAP_RE = new RegExp(`[${Object.keys(CHAR_MAP).join("")}]`, "g");

export function normalizeText(value) {
  if (value === null || value === undefined) return "";
  return String(value).toLowerCase().replace(CHAR_MAP_RE, (ch) => CHAR_MAP[ch] ?? ch);
}

// نسخه‌ی مخصوص عبارت جستجوی کاربر: علاوه بر نرمال‌سازی بالا، اعراب (فتحه/کسره/...)
// و حرف‌های کنترلی جهت‌نما (RLM/LRM/BOM) را هم حذف می‌کند — کاربر ممکن است با کیبورد
// پشتو/عربی اعراب بزند یا متن را از جای دیگر کپی کند. چون فقط روی «عبارت» اعمال
// می‌شود، هم‌ترازی اندیس‌های متن اصلی (برای هایلایت) به هم نمی‌خورد.
export function normalizeQuery(value) {
  return normalizeText(value)
    .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

// نسخه‌های مختلف یک عبارت برای شرط LIKE در SQL — دیتابیس ممکن است متن را با «ي/ك»
// عربی یا «ی/ک» فارسی ذخیره کرده باشد؛ هر دو شکل را امتحان می‌کنیم.
export function queryVariants(raw) {
  const clean = String(raw)
    .replace(/[\u200E\u200F\u202A-\u202E\u2066-\u2069\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  const norm = normalizeQuery(clean);
  const arabic = norm.replace(/\u06CC/g, "\u064A").replace(/\u06A9/g, "\u0643");
  return [...new Set([clean, norm, arabic].filter(Boolean))];
}

// فاصله‌ی ویرایشی لِوِنشتاین با برش زودهنگام (bounded) — اگر فاصله از maxDist
// بیشتر شود، بدون ادامه‌ی محاسبه -1 برمی‌گرداند. برای رشته‌های کوتاه (عنوان‌ها/نام‌ها)
// که این تابع روی آن‌ها اجرا می‌شود، هزینه‌ی محاسباتی ناچیز است.
function levenshteinBounded(a, b, maxDist) {
  const al = a.length;
  const bl = b.length;
  if (Math.abs(al - bl) > maxDist) return -1;
  if (al === 0) return bl <= maxDist ? bl : -1;
  if (bl === 0) return al <= maxDist ? al : -1;

  let prev = new Array(bl + 1);
  for (let j = 0; j <= bl; j++) prev[j] = j;

  for (let i = 1; i <= al; i++) {
    const curr = new Array(bl + 1);
    curr[0] = i;
    let rowMin = curr[0];
    for (let j = 1; j <= bl; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
      if (curr[j] < rowMin) rowMin = curr[j];
    }
    if (rowMin > maxDist) return -1; // هیچ سلولی در این ردیف نمی‌تواند به جواب قابل‌قبول برسد
    prev = curr;
  }
  return prev[bl] <= maxDist ? prev[bl] : -1;
}

// حداکثر تعداد غلط‌املایی قابل‌تحمل، متناسب با طول کلمه‌ی جستجو (مشابه رویکرد
// معمول موتورهای جستجوی typo-tolerant: کلمه‌ی کوتاه‌تر = تحمل کمتر تا نویز کم بماند)
function typoThreshold(len) {
  if (len < 4) return 0; // کلمات خیلی کوتاه فقط با تطابق دقیق/جزئی بررسی می‌شوند
  if (len <= 7) return 1;
  return 2;
}

const WORD_BOUNDARY_RE = /[^\p{L}\p{N}]/u;

// تطبیق یک عبارت (term) روی یک متن؛ ابتدا substring دقیق (پوشش‌دهنده‌ی جستجوی
// جزئی)، در صورت نبود، جستجوی فازی با پنجره‌ی لغزان + فاصله‌ی ویرایشی (پوشش‌دهنده‌ی
// تحمل غلط‌املایی). خروجی: امتیاز خام (بدون وزن) و محدوده‌ی [start,end) برای هایلایت.
function matchSingleTerm(normText, normTerm) {
  const qLen = normTerm.length;
  if (qLen === 0 || normText.length === 0) return { score: 0, range: null };

  const idx = normText.indexOf(normTerm);
  if (idx !== -1) {
    const atWordStart = idx === 0 || WORD_BOUNDARY_RE.test(normText[idx - 1]);
    const isWholeField = normText.length === qLen;
    const base = isWholeField ? 100 : atWordStart ? 92 : 78;
    return { score: base, range: [idx, idx + qLen] };
  }

  const maxDist = typoThreshold(qLen);
  if (maxDist === 0) return { score: 0, range: null };

  let best = null;
  const minWin = Math.max(1, qLen - 2);
  const maxWin = Math.min(normText.length, qLen + 2);
  for (let winLen = minWin; winLen <= maxWin; winLen++) {
    for (let start = 0; start + winLen <= normText.length; start++) {
      const window = normText.slice(start, start + winLen);
      const dist = levenshteinBounded(normTerm, window, maxDist);
      if (dist !== -1 && (!best || dist < best.dist)) {
        best = { dist, start, winLen };
        if (dist === 0) break;
      }
    }
    if (best && best.dist === 0) break;
  }

  if (!best || best.dist > maxDist) return { score: 0, range: null };
  const scaled = 1 - best.dist / (maxDist + 1);
  const base = Math.max(30, Math.round(60 * scaled)); // همیشه کمتر از تطابق substring
  return { score: base, range: [best.start, best.start + best.winLen] };
}

function mergeRanges(ranges) {
  if (ranges.length === 0) return [];
  const sorted = [...ranges].sort((a, b) => a[0] - b[0]);
  const merged = [sorted[0].slice()];
  for (let i = 1; i < sorted.length; i++) {
    const last = merged[merged.length - 1];
    const [start, end] = sorted[i];
    if (start <= last[1]) {
      last[1] = Math.max(last[1], end);
    } else {
      merged.push([start, end]);
    }
  }
  return merged;
}

// تطبیق یک فیلد کامل (مثلاً fullName یا description) روی عبارت جستجو (که می‌تواند
// چندکلمه‌ای باشد)؛ برای عبارات چندکلمه‌ای، ابتدا کل عبارت را به‌صورت یکجا امتحان
// می‌کند، سپس در صورت نبود تطابق کامل، هر کلمه را جداگانه روی متن تطبیق می‌دهد و
// امتیاز/محدوده‌ها را ترکیب می‌کند (کلمات یافت‌نشده امتیاز را کاهش می‌دهند، نه صفر می‌کنند).
function matchField(text, rawQuery, weight) {
  if (!text) return { score: 0, ranges: [] };
  const normText = normalizeText(text);
  const normQuery = normalizeQuery(rawQuery);
  if (!normQuery) return { score: 0, ranges: [] };

  const whole = matchSingleTerm(normText, normQuery);
  if (whole.score > 0) {
    return { score: whole.score * weight, ranges: [whole.range] };
  }

  const tokens = normQuery.split(/\s+/).filter(Boolean);
  if (tokens.length <= 1) return { score: 0, ranges: [] };

  const perToken = tokens.map((t) => matchSingleTerm(normText, t));
  const matchedTokens = perToken.filter((r) => r.score > 0);
  if (matchedTokens.length === 0) return { score: 0, ranges: [] };

  // میانگین روی تعداد کل کلمات (نه فقط کلمات یافت‌شده) تا عبارتی که همه‌ی
  // کلماتش پیدا شده رتبه‌ی بالاتری از عبارتی با کلمات ناقص بگیرد.
  const avgScore = matchedTokens.reduce((sum, r) => sum + r.score, 0) / tokens.length;
  const ranges = mergeRanges(matchedTokens.map((r) => r.range));
  return { score: avgScore * weight, ranges };
}

// امتیازدهی کامل یک ردیف بر اساس چند فیلد وزن‌دار. fieldConfigs: آرایه‌ای از
// { key, weight, out } که out نام فیلد خروجی (title/subtitle/...) برای هایلایت
// است، یا null اگر فیلد فقط برای جستجو استفاده می‌شود ولی در خروجی نمایش داده نمی‌شود.
export function scoreRow(row, fieldConfigs, rawQuery) {
  let total = 0;
  const highlights = {};
  for (const { key, weight, out } of fieldConfigs) {
    const { score, ranges } = matchField(row[key], rawQuery, weight);
    total += score;
    if (out && ranges.length > 0) highlights[out] = ranges;
  }
  return { score: total, highlights };
}

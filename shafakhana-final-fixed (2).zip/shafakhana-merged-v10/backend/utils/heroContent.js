import crypto from "crypto";

// اعتبارسنجی/پاک‌سازی ورودی «مدیریت بخش اصلی (Hero)» — بدون وابستگی به دیتابیس تا جداگانه قابل‌تست باشد.
const LANGS = ["fa", "ps", "en"];
const MAX_STATS = 6;
const MAX_PULSE = 4;

const LIMITS = { eyebrow: 120, titlePart: 80, lead: 600, button: 60, link: 300, statValue: 24, statLabel: 60 };

// آدرس دکمه: لنگر داخل صفحه (#doctors)، مسیر داخلی (/login) یا http(s) — هرگز javascript: و مانند آن
const LINK_RE = /^(#[A-Za-z0-9_-]{1,60}|\/(?!\/)[^\s]{0,250}|https?:\/\/[^\s]{1,280})$/;

function cleanLangObject(raw, max, label, errors) {
  const out = {};
  const src = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {};
  for (const lang of LANGS) {
    const v = src[lang] === null || src[lang] === undefined ? "" : String(src[lang]).trim();
    if (v.length > max) errors.push(`${label} (${lang}) نباید بیشتر از ${max} کاراکتر باشد`);
    out[lang] = v;
  }
  return out;
}

const hasAny = (obj) => LANGS.some((l) => obj[l]);

function cleanLink(raw, label, errors) {
  const link = raw === null || raw === undefined ? "" : String(raw).trim();
  if (!link) {
    errors.push(`${label} لازم است`);
    return "";
  }
  if (link.length > LIMITS.link || !LINK_RE.test(link)) {
    errors.push(`${label} نامعتبر است (فقط #بخش، /مسیر یا https://… مجاز است)`);
  }
  return link;
}

function cleanItems(rawList, max, label, errors) {
  const raw = Array.isArray(rawList) ? rawList : [];
  if (raw.length > max) errors.push(`حداکثر ${max} مورد برای «${label}» مجاز است`);
  const seen = new Set();
  return raw.slice(0, max).map((it, i) => {
    let id = typeof it?.id === "string" && /^[A-Za-z0-9_-]{1,40}$/.test(it.id) ? it.id : "";
    if (!id || seen.has(id)) id = crypto.randomBytes(6).toString("hex");
    seen.add(id);
    const value = cleanLangObject(it?.value, LIMITS.statValue, `مقدار ${label} ${i + 1}`, errors);
    const lbl = cleanLangObject(it?.label, LIMITS.statLabel, `عنوان ${label} ${i + 1}`, errors);
    if (!hasAny(value)) errors.push(`مقدار ${label} ${i + 1} حداقل در یک زبان لازم است`);
    if (!hasAny(lbl)) errors.push(`عنوان ${label} ${i + 1} حداقل در یک زبان لازم است`);
    return { id, value, label: lbl };
  });
}

// ورودی PUT را اعتبارسنجی/پاک‌سازی می‌کند؛ آدرس عکس هرگز از این ورودی پذیرفته نمی‌شود
// (فقط از مسیر آپلود فایل تغییر می‌کند)
export function sanitizeHeroInput(body, imageUrl = "") {
  const errors = [];
  const eyebrow = cleanLangObject(body?.eyebrow, LIMITS.eyebrow, "برچسب بالای تیتر", errors);
  const titleBefore = cleanLangObject(body?.titleBefore, LIMITS.titlePart, "تیتر (بخش اول)", errors);
  const titleAccent = cleanLangObject(body?.titleAccent, LIMITS.titlePart, "تیتر (کلمه‌ی رنگی)", errors);
  const titleAfter = cleanLangObject(body?.titleAfter, LIMITS.titlePart, "تیتر (بخش آخر)", errors);
  const lead = cleanLangObject(body?.lead, LIMITS.lead, "متن توضیح", errors);
  if (!hasAny(titleBefore) && !hasAny(titleAccent) && !hasAny(titleAfter)) {
    errors.push("تیتر اصلی حداقل در یک زبان لازم است");
  }

  const primaryText = cleanLangObject(body?.primaryButton?.text, LIMITS.button, "متن دکمه‌ی اصلی", errors);
  const primaryLink = cleanLink(body?.primaryButton?.link, "آدرس دکمه‌ی اصلی", errors);
  const secondaryText = cleanLangObject(body?.secondaryButton?.text, LIMITS.button, "متن دکمه‌ی دوم", errors);
  const secondaryLink = cleanLink(body?.secondaryButton?.link, "آدرس دکمه‌ی دوم", errors);

  const stats = cleanItems(body?.stats, MAX_STATS, "آمار", errors);
  const pulse = cleanItems(body?.pulse, MAX_PULSE, "کارت", errors);

  return {
    errors,
    value: {
      imageUrl,
      eyebrowVisible: body?.eyebrowVisible !== false,
      eyebrow,
      titleBefore, titleAccent, titleAfter,
      lead,
      primaryButton: { text: primaryText, link: primaryLink },
      secondaryVisible: body?.secondaryVisible !== false,
      secondaryButton: { text: secondaryText, link: secondaryLink },
      statsVisible: body?.statsVisible !== false,
      stats,
      pulseVisible: body?.pulseVisible !== false,
      pulse,
    },
  };
}


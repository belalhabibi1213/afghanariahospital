import crypto from "crypto";
import { JWT_SECRET, IS_PRODUCTION } from "./env.js";

// ---------- کوکی احراز هویت (httpOnly) + توکن CSRF ----------
// توکن JWT دیگر در JSON پاسخ برنمی‌گردد و در localStorage ذخیره نمی‌شود؛ سرور آن را در یک
// کوکی HttpOnly می‌گذارد که جاوااسکریپت صفحه (و در نتیجه XSS) نمی‌تواند بخواند.
// چون مرورگر کوکی را خودکار می‌فرستد، حمله‌ی CSRF ممکن می‌شود؛ برای همین هر درخواست تغییردهنده
// (POST/PUT/PATCH/DELETE) باید هدر X-CSRF-Token هم داشته باشد (middleware/csrf.js).
// توکن CSRF مقدار HMAC وابسته به نشست (jti) است، پس بدون‌حالت (stateless) و برای هر نشست یکتاست.

export const AUTH_COOKIE_NAME = "shafakhana_token";
export const CSRF_HEADER = "x-csrf-token";
export const SESSION_COOKIE_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // هم‌راستا با expiresIn توکن (۷ روز)

// COOKIE_SAMESITE: lax (پیش‌فرض، وقتی فرانت‌اند و بک‌اند هم‌سایت‌اند، مثلاً app.example.com و api.example.com)،
// strict، یا none (فقط وقتی فرانت‌اند روی یک سایت کاملاً جدا مثل دامنه‌ی Vercel است؛ نیازمند HTTPS است).
function resolveSameSite() {
  const raw = (process.env.COOKIE_SAMESITE || "lax").trim().toLowerCase();
  return ["lax", "strict", "none"].includes(raw) ? raw : "lax";
}

const SAME_SITE = resolveSameSite();
// SameSite=None بدون Secure توسط مرورگرها رد می‌شود؛ در production هم همیشه Secure است.
const SECURE = IS_PRODUCTION || SAME_SITE === "none" || (process.env.COOKIE_SECURE || "").toLowerCase() === "true";
const COOKIE_DOMAIN = (process.env.COOKIE_DOMAIN || "").trim() || undefined;

function cookieOptions() {
  return {
    httpOnly: true,
    secure: SECURE,
    sameSite: SAME_SITE,
    path: "/",
    domain: COOKIE_DOMAIN,
  };
}

export function setAuthCookie(res, token) {
  res.cookie(AUTH_COOKIE_NAME, token, { ...cookieOptions(), maxAge: SESSION_COOKIE_MAX_AGE_MS });
}

export function clearAuthCookie(res) {
  res.clearCookie(AUTH_COOKIE_NAME, cookieOptions());
}

// تجزیه‌ی ساده‌ی هدر Cookie (بدون وابستگی اضافه)
export function parseCookies(header) {
  const out = {};
  if (!header || typeof header !== "string") return out;
  for (const part of header.split(";")) {
    const idx = part.indexOf("=");
    if (idx < 0) continue;
    const key = part.slice(0, idx).trim();
    if (!key || key in out) continue;
    let value = part.slice(idx + 1).trim();
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    try {
      out[key] = decodeURIComponent(value);
    } catch {
      out[key] = value;
    }
  }
  return out;
}

// توکن را از هدر Authorization (کلاینت‌های API/تست) یا کوکی (مرورگر) می‌خواند.
// source مشخص می‌کند توکن از کجا آمده: فقط توکنِ «cookie» در برابر CSRF آسیب‌پذیر است.
export function getTokenFromRequest(req) {
  const header = req.headers?.authorization;
  if (header && header.startsWith("Bearer ")) {
    return { token: header.slice(7).trim(), source: "header" };
  }
  const cookies = parseCookies(req.headers?.cookie);
  if (cookies[AUTH_COOKIE_NAME]) {
    return { token: cookies[AUTH_COOKIE_NAME], source: "cookie" };
  }
  return { token: null, source: null };
}

// توکن CSRF مخصوص یک نشست: HMAC(JWT_SECRET, jti). برای توکن‌های قدیمی بدون jti از id کاربر استفاده می‌شود.
export function csrfTokenFor(payload) {
  const binding = payload?.jti ? `jti:${payload.jti}` : `uid:${payload?.id}`;
  return crypto.createHmac("sha256", JWT_SECRET).update(`csrf:${binding}`).digest("hex");
}

export function safeEqual(a, b) {
  const bufA = Buffer.from(String(a || ""));
  const bufB = Buffer.from(String(b || ""));
  if (bufA.length !== bufB.length) return false;
  return crypto.timingSafeEqual(bufA, bufB);
}

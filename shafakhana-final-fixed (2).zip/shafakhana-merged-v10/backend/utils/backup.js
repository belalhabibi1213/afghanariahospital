// ماژول پشتیبان‌گیری و بازیابی دیتابیس (Database Backup & Restore)
//
// این ماژول به‌صورت خالص با mysql2 (بدون وابستگی به باینری خارجی مثل mysqldump/mysql.exe)
// پیاده‌سازی شده تا روی هر محیطی (از جمله XAMPP روی ویندوز که معمولاً مسیر آن‌ها در PATH
// سیستم نیست) بدون تنظیمات اضافه کار کند.
//
// فایل‌های پشتیبان در یک پوشه‌ی خصوصی (private-uploads/backups) ذخیره می‌شوند — دقیقاً مثل
// گزارش‌های آزمایشگاهی در middleware/upload.js — که از مسیر استاتیک عمومی app.use("/uploads", ...)
// در server.js قابل‌دسترسی نیست و فقط از طریق کنترلرهای احرازهویت‌شده (superadmin) قابل خواندن است.

import fs from "fs";
import fsp from "fs/promises";
import path from "path";
import crypto from "crypto";
import mysql from "mysql2/promise";
import { fileURLToPath } from "url";
import cron from "node-cron";
import { getPool } from "../db.js";
import { getAllSettings, setSetting } from "../models/Settings.js";
import { isBackupEncryptionEnabled, encryptBackup, decryptBackup, looksEncrypted, MIN_ENCRYPTED_SIZE, MAGIC as ENC_MAGIC } from "./backupCrypto.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// پوشه‌ی خصوصی نگهداری فایل‌های پشتیبان — هرگز به‌صورت استاتیک سرو نمی‌شود.
// BACKUP_STORAGE_DIR (اختیاری) فقط برای جابه‌جایی مسیر ذخیره‌سازی (مثلاً دیسک جدا یا تست‌ها) است.
export const BACKUPS_DIR = process.env.BACKUP_STORAGE_DIR
  ? path.resolve(process.env.BACKUP_STORAGE_DIR)
  : path.join(__dirname, "..", "private-uploads", "backups");
fs.mkdirSync(BACKUPS_DIR, { recursive: true });

// ریشه‌ی پروژه (برای نمایش مسیر نسبی پوشه‌ها در داشبورد، بدون افشای مسیر مطلق سرور)
const PROJECT_ROOT = path.join(__dirname, "..", "..");

const DB_NAME = process.env.DB_NAME || "shafakhana";

// نام فایل‌ها کاملاً کنترل‌شده و پیش‌بینی‌پذیر تولید می‌شوند (نه از ورودی کاربر)؛ این الگو
// هم برای تولید نام استفاده می‌شود و هم برای اعتبارسنجی هر نامی که از کاربر (پارامتر مسیر)
// می‌رسد — دقیقاً همان روش «فهرست سفید/whitelist» استفاده‌شده در middleware/upload.js برای
// جلوگیری از Path Traversal (../../) یا دسترسی به فایل‌های دیگر روی دیسک.
const BACKUP_TYPES = ["manual", "scheduled", "pre-restore"];
const FILENAME_PATTERN = /^backup-(manual|scheduled|pre-restore)-\d{8}-\d{6}-[0-9a-f]{8}\.sql(\.enc)?$/;

// ---------- پوشه‌های پشتیبان ----------
// «پوشه‌ی پیش‌فرض» همان ریشه‌ی BACKUPS_DIR است تا همه‌ی پشتیبان‌های قبلی بدون جابه‌جایی/تغییر
// سر جای خود بمانند. هر پوشه‌ی ساخته‌شده توسط سوپرادمین یک زیرپوشه با شناسه‌ی تصادفی و
// کنترل‌شده (f-xxxxxxxx) است؛ نام نمایشی و توضیحات در فایل .folder.json داخل همان پوشه ذخیره
// می‌شود. به همین دلیل هیچ نام یا مسیری از کاربر هرگز وارد مسیر فایل‌سیستم نمی‌شود (بدون
// امکان Path Traversal) و تغییر نام پوشه فقط یک تغییر در متادیتاست، نه جابه‌جایی فایل‌ها.
export const DEFAULT_FOLDER_ID = "default";
const DEFAULT_FOLDER_NAME = "پوشه پیش‌فرض";
const FOLDER_ID_PATTERN = /^f-[0-9a-f]{8}$/;
// «پوشه‌ی انتخاب‌شده روی کامپیوتر»: مسیر دلخواهی که سوپرادمین با پنجره‌ی انتخاب پوشه‌ی سیستم‌عامل
// (مثلاً D:\Backups) تعیین می‌کند. شناسه‌ی آن ثابت (custom) است و مسیر واقعی فقط در تنظیمات سرور
// (backupCustomDir) نگهداری می‌شود؛ هیچ مسیری از پارامتر درخواست وارد فایل‌سیستم نمی‌شود.
export const CUSTOM_FOLDER_ID = "custom";
const CUSTOM_DIR_SETTING = "backupCustomDir";
const CUSTOM_FOLDER_NAME = "پوشه‌ی انتخاب‌شده روی کامپیوتر";
// مسیر عمومی فایل‌های آپلود (app.use("/uploads")) — پشتیبان دیتابیس هرگز نباید داخل آن ذخیره شود
const PUBLIC_UPLOADS_DIR = path.join(__dirname, "..", "uploads");
let customDir = null; // کش حافظه‌ای مسیر مطلق پوشه‌ی انتخاب‌شده (توسط loadCustomBackupDir/getActiveFolderId همگام می‌شود)
const FOLDER_META_FILE = ".folder.json";
const TEMP_FILE_PATTERN = /^\.tmp-[0-9a-f]{8}\.part$/;
const ACTIVE_FOLDER_SETTING = "backupActiveFolder";
const LAST_ERROR_SETTING = "backupLastError";
const MAX_FOLDERS = 50;
const FOLDER_NAME_MIN = 2;
const FOLDER_NAME_MAX = 50;
const FOLDER_DESC_MAX = 200;

function backupError(code, message) {
  const err = new Error(message);
  err.code = code;
  return err;
}

export function isValidFolderId(folderId) {
  return folderId === DEFAULT_FOLDER_ID || folderId === CUSTOM_FOLDER_ID || (typeof folderId === "string" && FOLDER_ID_PATTERN.test(folderId));
}

// مسیر مطلق پوشه — فقط برای شناسه‌ی معتبر (default یا f-xxxxxxxx) ساخته می‌شود
function folderDir(folderId) {
  if (!isValidFolderId(folderId)) throw backupError("INVALID_FOLDER", "شناسه‌ی پوشه نامعتبر است");
  const root = path.resolve(BACKUPS_DIR);
  if (folderId === DEFAULT_FOLDER_ID) return root;
  if (folderId === CUSTOM_FOLDER_ID) {
    if (!customDir) throw backupError("INVALID_FOLDER", "هنوز پوشه‌ای روی کامپیوتر انتخاب نشده است");
    return customDir;
  }
  const dir = path.resolve(root, folderId);
  // دفاع در عمق: حتی اگر الگوی بالا دور زده شود، پوشه باید مستقیماً زیرمجموعه‌ی ریشه باشد
  if (path.dirname(dir) !== root) throw backupError("INVALID_FOLDER", "شناسه‌ی پوشه نامعتبر است");
  return dir;
}

// مسیر نسبی قابل‌نمایش در داشبورد (مثلاً backend/private-uploads/backups/f-1a2b3c4d)
function displayPath(folderId) {
  if (folderId === CUSTOM_FOLDER_ID) return folderDir(folderId); // مسیری که خود کاربر انتخاب کرده؛ مسیر کامل نمایش داده می‌شود
  return path.relative(PROJECT_ROOT, folderDir(folderId)).split(path.sep).join("/");
}

function listFolderIdsSync() {
  let entries = [];
  try {
    entries = fs.readdirSync(BACKUPS_DIR, { withFileTypes: true });
  } catch {
    entries = [];
  }
  const ids = entries.filter((e) => e.isDirectory() && FOLDER_ID_PATTERN.test(e.name)).map((e) => e.name);
  return [DEFAULT_FOLDER_ID, ...ids, ...(customDir ? [CUSTOM_FOLDER_ID] : [])];
}

// تاریخ/ساعت با منطقه‌ی زمانی تنظیم‌شده‌ی سیستم (تنظیمات ← timezone) برای نام فایل
function formatStamp(date, timeZone) {
  const make = (tz) =>
    new Intl.DateTimeFormat("en-GB", {
      timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit", hourCycle: "h23",
    }).formatToParts(date);
  let parts;
  try {
    parts = make(timeZone || undefined);
  } catch {
    parts = make(undefined); // منطقه‌ی زمانی نامعتبر → زمان سرور
  }
  const get = (t) => parts.find((p) => p.type === t).value;
  return `${get("year")}${get("month")}${get("day")}-${get("hour")}${get("minute")}${get("second")}`;
}

function buildFilename(type = "manual", timeZone, encrypted = false) {
  const safeType = BACKUP_TYPES.includes(type) ? type : "manual";
  const stamp = formatStamp(new Date(), timeZone);
  const rand = crypto.randomBytes(4).toString("hex");
  return `backup-${safeType}-${stamp}-${rand}.sql${encrypted ? ".enc" : ""}`;
}

// نسخه‌ی دوم بکاپ (اختیاری) روی یک مسیر «خارج از سرور» (دیسک/NFS/volume متصل به S3 یا rclone و ...).
// فقط فایل «رمزنگاری‌شده» کپی می‌شود؛ بکاپ ساده هرگز به مقصد بیرونی نمی‌رود. شکست کپی، خودِ بکاپ را
// ناموفق نمی‌کند ولی در lastError ثبت و لاگ می‌شود.
async function copyOffsite(filePath, filename, encrypted) {
  const dest = (process.env.BACKUP_OFFSITE_DIR || "").trim();
  if (!dest) return null;
  if (!encrypted) {
    console.warn("⚠️  BACKUP_OFFSITE_DIR تنظیم است ولی بکاپ رمزنگاری نشده؛ برای امنیت، کپی بیرونی انجام نشد (BACKUP_ENCRYPTION_KEY را تنظیم کنید).");
    return null;
  }
  try {
    await fsp.mkdir(dest, { recursive: true, mode: 0o700 });
    const target = path.join(path.resolve(dest), filename);
    const tmp = `${target}.part`;
    await fsp.copyFile(filePath, tmp);
    await fsp.chmod(tmp, 0o600).catch(() => {});
    await fsp.rename(tmp, target);
    return target;
  } catch (err) {
    console.error("⚠️  کپی بکاپ به BACKUP_OFFSITE_DIR ناموفق بود:", err.message);
    await setSetting(LAST_ERROR_SETTING, "کپی بکاپ به مقصد بیرونی ناموفق بود").catch(() => {});
    return null;
  }
}

// محتوای متنی SQL یک فایل بکاپ را برمی‌گرداند؛ رمزنگاری‌شده‌ها را (پیش از هر تغییری در دیتابیس) رمزگشایی
// و صحت (GCM) را بررسی می‌کند.
async function readBackupSql(filePath) {
  const raw = await fsp.readFile(filePath);
  if (looksEncrypted(raw)) {
    try {
      return decryptBackup(raw).toString("utf8");
    } catch (err) {
      throw backupError(err.code === "BACKUP_KEY_MISSING" ? "BACKUP_KEY_MISSING" : "INVALID_BACKUP_CONTENT", err.message);
    }
  }
  return raw.toString("utf8");
}

function validatePlainSql(sql) {
  const head = sql.slice(0, HEADER_READ_BYTES);
  if (!head.includes(BACKUP_HEADER_SIGNATURE) || !head.includes(`دیتابیس: ${DB_NAME}`)) {
    return { ok: false, message: "این فایل، پشتیبان معتبر سیستم شفاخانه نیست یا محتوای آن دست‌کاری شده است" };
  }
  if (!sql.slice(-FOOTER_READ_BYTES).trimEnd().endsWith(BACKUP_FOOTER)) {
    return { ok: false, message: "فایل پشتیبان ناقص است (انتهای فایل کامل نیست) و قابل بازیابی نیست" };
  }
  return { ok: true };
}

export function isValidBackupFilename(filename) {
  return typeof filename === "string" && FILENAME_PATTERN.test(filename);
}

// مسیر امن فایل را برمی‌گرداند؛ در صورت نامعتبر بودن نام یا نبودن فایل، خطای دارای کد
// مشخص پرتاب می‌کند تا کنترلر بتواند پاسخ HTTP مناسب (404/400) بدهد.
// folderId اختیاری است: اگر داده شود فقط همان پوشه جستجو می‌شود، وگرنه (برای سازگاری با
// فراخوانی‌های قبلی) در همه‌ی پوشه‌ها — نام فایل‌ها به‌خاطر بخش تصادفی یکتا هستند.
export function getBackupFilePath(filename, folderId) {
  if (!isValidBackupFilename(filename)) {
    throw backupError("INVALID_FILENAME", "نام فایل پشتیبان نامعتبر است");
  }
  const candidates = folderId ? [folderId] : listFolderIdsSync();
  for (const id of candidates) {
    const dir = folderDir(id); // برای شناسه‌ی نامعتبر INVALID_FOLDER پرتاب می‌کند
    const resolvedFile = path.resolve(dir, filename);
    // بررسی دفاع در عمق (defense in depth): حتی اگر الگوی بالا به هر دلیلی دور زده شود،
    // مسیر نهایی حتماً باید داخل همان پوشه‌ی پشتیبان باقی بماند
    if (!resolvedFile.startsWith(dir + path.sep)) {
      throw backupError("INVALID_FILENAME", "مسیر فایل نامعتبر است");
    }
    if (fs.existsSync(resolvedFile)) return resolvedFile;
  }
  throw backupError("ENOENT", "فایل پشتیبان یافت نشد");
}

async function getTableNames(pool) {
  const [rows] = await pool.query(
    `SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_TYPE = 'BASE TABLE' ORDER BY TABLE_NAME`,
    [DB_NAME]
  );
  return rows.map((r) => r.TABLE_NAME);
}

// ستون‌های GENERATED (مثل activeSlotKey در appointments) باید از لیست INSERT کنار گذاشته
// شوند چون مقدار آن‌ها را MySQL خودش بعد از CREATE TABLE محاسبه می‌کند و نمی‌توان مستقیم
// در آن‌ها مقدار نوشت
async function getGeneratedColumns(pool, table) {
  const [rows] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND EXTRA LIKE '%GENERATED%'`,
    [DB_NAME, table]
  );
  return new Set(rows.map((r) => r.COLUMN_NAME));
}

// ستون‌های JSON (مثل audit_logs.oldValues/newValues) را mysql2 به‌صورت شیء/آرایه برمی‌گرداند و
// mysql.escape روی شیء، عبارت نادرست «`key` = 'value'» می‌سازد که بازیابی را خراب می‌کند؛
// پس اشیاء/آرایه‌ها پیش از escape به رشته‌ی JSON تبدیل می‌شوند (Date و Buffer دست‌نخورده می‌مانند)
function serializeValue(value) {
  if (value !== null && typeof value === "object" && !(value instanceof Date) && !Buffer.isBuffer(value)) {
    return JSON.stringify(value);
  }
  return value;
}

async function dumpTable(pool, table) {
  const [createRows] = await pool.query(`SHOW CREATE TABLE ${mysql.escapeId(table)}`);
  const createSql = createRows[0]["Create Table"];

  let sql = `\n-- ----------------------------\n-- جدول: ${table}\n-- ----------------------------\nDROP TABLE IF EXISTS ${mysql.escapeId(table)};\n${createSql};\n`;

  const generatedColumns = await getGeneratedColumns(pool, table);
  const [rows] = await pool.query(`SELECT * FROM ${mysql.escapeId(table)}`);

  if (rows.length > 0) {
    const columns = Object.keys(rows[0]).filter((c) => !generatedColumns.has(c));
    const columnList = columns.map((c) => mysql.escapeId(c)).join(", ");

    // دسته‌بندی INSERT ها: حداکثر ۲۰۰ ردیف و حداکثر حدود ۷۰۰ هزار کاراکتر در هر دستور. محدودیت حجم
    // لازم است چون ردیف‌های جدول عکس‌ها (uploaded_file_chunks) بزرگ‌اند و یک INSERT خیلی حجیم از
    // max_allowed_packet در MySQL/XAMPP (گاهی فقط ۱ مگابایت) بیشتر می‌شد و بازیابی شکست می‌خورد.
    const BATCH_SIZE = 200;
    const BATCH_MAX_CHARS = 700_000;
    let batch = [];
    let batchChars = 0;
    const flush = () => {
      if (batch.length === 0) return;
      sql += `INSERT INTO ${mysql.escapeId(table)} (${columnList}) VALUES\n${batch.join(",\n")};\n`;
      batch = [];
      batchChars = 0;
    };
    for (const row of rows) {
      const rowSql = `(${columns.map((c) => mysql.escape(serializeValue(row[c]))).join(", ")})`;
      if (batch.length > 0 && (batch.length >= BATCH_SIZE || batchChars + rowSql.length > BATCH_MAX_CHARS)) flush();
      batch.push(rowSql);
      batchChars += rowSql.length;
    }
    flush();
  }

  return sql;
}

// ---------- مدیریت پوشه‌ها ----------
function creationDate(st) {
  return st.birthtimeMs > 0 ? st.birthtime : st.mtime;
}

// پوشه باید وجود داشته باشد و قابل نوشتن باشد؛ در غیر این صورت هیچ فایلی نوشته (و هیچ فایل
// قبلی‌ای دست‌کاری) نمی‌شود و خطای واضح برمی‌گردد
async function checkFolderWritable(folderId) {
  const dir = folderDir(folderId);
  if (folderId === DEFAULT_FOLDER_ID) await fsp.mkdir(dir, { recursive: true }).catch(() => {});
  let st;
  try {
    st = await fsp.stat(dir);
  } catch {
    return { ok: false, code: "FOLDER_NOT_FOUND", message: "پوشه‌ی انتخاب‌شده برای ذخیره‌ی پشتیبان وجود ندارد" };
  }
  if (!st.isDirectory()) {
    return { ok: false, code: "FOLDER_NOT_FOUND", message: "پوشه‌ی انتخاب‌شده برای ذخیره‌ی پشتیبان وجود ندارد" };
  }
  try {
    await fsp.access(dir, fs.constants.W_OK);
  } catch {
    return { ok: false, code: "FOLDER_UNAVAILABLE", message: "پوشه‌ی انتخاب‌شده قابل نوشتن نیست؛ مجوز دسترسی پوشه را بررسی کنید" };
  }
  return { ok: true, dir };
}

async function readFolderMeta(folderId) {
  if (folderId === DEFAULT_FOLDER_ID) return { name: DEFAULT_FOLDER_NAME, description: "", createdAt: null };
  if (folderId === CUSTOM_FOLDER_ID) {
    const base = customDir ? path.basename(customDir) : "";
    return { name: base ? `${CUSTOM_FOLDER_NAME}: ${base}` : CUSTOM_FOLDER_NAME, description: "", createdAt: null };
  }
  try {
    const raw = JSON.parse(await fsp.readFile(path.join(folderDir(folderId), FOLDER_META_FILE), "utf8"));
    return {
      name: typeof raw.name === "string" && raw.name.trim() ? raw.name.trim().slice(0, 100) : folderId,
      description: typeof raw.description === "string" ? raw.description.slice(0, FOLDER_DESC_MAX) : "",
      createdAt: typeof raw.createdAt === "string" ? raw.createdAt : null,
    };
  } catch {
    return { name: folderId, description: "", createdAt: null };
  }
}

// نوشتن اتمیک (فایل موقت + rename) تا قطع شدن ناگهانی، متادیتا را نیمه‌کاره رها نکند
async function writeFolderMeta(folderId, meta) {
  const dir = folderDir(folderId);
  const tmp = path.join(dir, `.tmp-${crypto.randomBytes(4).toString("hex")}.part`);
  const payload = JSON.stringify({ name: meta.name, description: meta.description, createdAt: meta.createdAt }, null, 2);
  try {
    await fsp.writeFile(tmp, payload, { encoding: "utf8", mode: 0o600, flag: "wx" });
    await fsp.rename(tmp, path.join(dir, FOLDER_META_FILE));
  } catch (err) {
    await fsp.unlink(tmp).catch(() => {});
    throw err;
  }
}

function normalizeFolderName(raw) {
  if (typeof raw !== "string") throw backupError("FOLDER_NAME_INVALID", "نام پوشه الزامی است");
  const name = raw.normalize("NFC").replace(/\s+/g, " ").trim();
  const length = Array.from(name).length;
  if (length < FOLDER_NAME_MIN || length > FOLDER_NAME_MAX) {
    throw backupError("FOLDER_NAME_INVALID", `نام پوشه باید بین ${FOLDER_NAME_MIN} تا ${FOLDER_NAME_MAX} کاراکتر باشد`);
  }
  if (/[\u0000-\u001f\u007f<>]/.test(name)) {
    throw backupError("FOLDER_NAME_INVALID", "نام پوشه شامل کاراکتر غیرمجاز است");
  }
  return name;
}

function normalizeFolderDescription(raw) {
  if (raw === undefined || raw === null) return "";
  if (typeof raw !== "string") throw backupError("FOLDER_NAME_INVALID", "توضیحات پوشه نامعتبر است");
  const text = raw.normalize("NFC").replace(/\s+/g, " ").trim();
  if (Array.from(text).length > FOLDER_DESC_MAX) {
    throw backupError("FOLDER_NAME_INVALID", `توضیحات پوشه نباید بیشتر از ${FOLDER_DESC_MAX} کاراکتر باشد`);
  }
  if (/[\u0000-\u001f\u007f<>]/.test(text)) {
    throw backupError("FOLDER_NAME_INVALID", "توضیحات پوشه شامل کاراکتر غیرمجاز است");
  }
  return text;
}

async function assertFolderNameAvailable(name, excludeId) {
  const key = name.toLocaleLowerCase();
  for (const id of listFolderIdsSync()) {
    if (id === excludeId) continue;
    const meta = await readFolderMeta(id);
    if (meta.name.toLocaleLowerCase() === key) {
      throw backupError("FOLDER_NAME_EXISTS", "پوشه‌ای با این نام قبلاً ایجاد شده است");
    }
  }
}

// پوشه‌ی مقصد فعلی؛ در تنظیمات دیتابیس (جدول settings) ذخیره می‌شود و با راه‌اندازی مجدد سرور حفظ می‌شود.
// کلید backupActiveFolder عمداً در SETTINGS_FIELDS نیست، پس از مسیر عمومی PUT /settings قابل تغییر نیست.
export async function getActiveFolderId() {
  const settings = await getAllSettings();
  syncCustomDir(settings);
  const id = settings[ACTIVE_FOLDER_SETTING];
  if (id === CUSTOM_FOLDER_ID && !customDir) return DEFAULT_FOLDER_ID;
  return isValidFolderId(id) ? id : DEFAULT_FOLDER_ID;
}

async function buildFolderSummary(folderId, activeId) {
  const [meta, backups, access] = await Promise.all([
    readFolderMeta(folderId),
    readFolderBackups(folderId),
    checkFolderWritable(folderId),
  ]);
  let totalSize = 0;
  backups.forEach((b) => { totalSize += b.size; });
  // «آخرین بکاپ موفق»: جدیدترین فایلی که کامل و سالم است (فایل خالی/ناقص موفق حساب نمی‌شود)
  let last = null;
  const newestFirst = [...backups].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  for (const b of newestFirst) {
    const check = await inspectBackupFile(path.join(folderDir(folderId), b.filename)).catch(() => ({ ok: false }));
    if (check.ok) { last = new Date(b.createdAt); break; }
  }
  return {
    id: folderId,
    name: meta.name,
    description: meta.description,
    createdAt: meta.createdAt,
    isDefault: folderId === DEFAULT_FOLDER_ID,
    isActive: folderId === activeId,
    count: backups.length,
    totalSize,
    lastBackupAt: last,
    path: displayPath(folderId),
    writable: access.ok,
  };
}

export async function listFolders() {
  const activeId = await getActiveFolderId();
  const folders = await Promise.all(listFolderIdsSync().map((id) => buildFolderSummary(id, activeId)));
  return folders.sort((a, b) => {
    if (a.isDefault !== b.isDefault) return a.isDefault ? -1 : 1;
    return a.name.localeCompare(b.name, "fa");
  });
}

// نمای کلی برای داشبورد: پوشه‌ها + وضعیت پوشه‌ی فعال (آیا هنوز وجود دارد و قابل نوشتن است؟)
export async function getFoldersOverview() {
  const activeFolderId = await getActiveFolderId();
  const folders = await listFolders();
  const active = folders.find((f) => f.id === activeFolderId);
  let activeFolderMessage = "";
  if (!active) activeFolderMessage = "پوشه‌ی فعال بکاپ پیدا نشد؛ لطفاً یک پوشه‌ی دیگر را فعال کنید.";
  else if (!active.writable) activeFolderMessage = "پوشه‌ی فعال بکاپ قابل نوشتن نیست؛ مجوز دسترسی آن را بررسی یا پوشه‌ی دیگری را فعال کنید.";
  return { folders, activeFolderId, activeFolderAvailable: !activeFolderMessage, activeFolderMessage };
}

export async function createFolder({ name, description } = {}) {
  const cleanName = normalizeFolderName(name);
  const cleanDescription = normalizeFolderDescription(description);
  if (listFolderIdsSync().filter((id) => FOLDER_ID_PATTERN.test(id)).length >= MAX_FOLDERS) {
    throw backupError("FOLDER_LIMIT", `حداکثر ${MAX_FOLDERS} پوشه می‌توان ساخت`);
  }
  await assertFolderNameAvailable(cleanName, null);

  let id = null;
  for (let attempt = 0; attempt < 5 && !id; attempt += 1) {
    const candidate = `f-${crypto.randomBytes(4).toString("hex")}`;
    try {
      await fsp.mkdir(folderDir(candidate), { mode: 0o700 }); // غیرتکرارشونده: اگر وجود داشته باشد EEXIST
      id = candidate;
    } catch (err) {
      if (err.code !== "EEXIST") throw backupError("FOLDER_UNAVAILABLE", "ساخت پوشه روی دیسک ممکن نشد؛ مجوز دسترسی را بررسی کنید");
    }
  }
  if (!id) throw backupError("FOLDER_UNAVAILABLE", "ساخت پوشه ناموفق بود؛ دوباره تلاش کنید");

  try {
    await writeFolderMeta(id, { name: cleanName, description: cleanDescription, createdAt: new Date().toISOString() });
  } catch {
    await fsp.rmdir(folderDir(id)).catch(() => {});
    throw backupError("FOLDER_UNAVAILABLE", "ذخیره‌ی اطلاعات پوشه ممکن نشد؛ مجوز دسترسی را بررسی کنید");
  }
  return buildFolderSummary(id, await getActiveFolderId());
}

async function assertFolderExists(folderId) {
  const dir = folderDir(folderId);
  const st = await fsp.stat(dir).catch(() => null);
  if (!st || !st.isDirectory()) throw backupError("FOLDER_NOT_FOUND", "پوشه یافت نشد");
}

// تغییر نام/توضیحات پوشه — فقط متادیتا؛ هیچ فایل پشتیبانی جابه‌جا یا تغییر نام نمی‌دهد
export async function updateFolder(folderId, { name, description } = {}) {
  if (folderId === DEFAULT_FOLDER_ID) throw backupError("FOLDER_PROTECTED", "پوشه‌ی پیش‌فرض قابل ویرایش نیست");
  if (folderId === CUSTOM_FOLDER_ID) throw backupError("FOLDER_PROTECTED", "پوشه‌ی انتخاب‌شده روی کامپیوتر قابل ویرایش نیست؛ از «انتخاب پوشه» برای تغییر مسیر استفاده کنید");
  await assertFolderExists(folderId);
  const current = await readFolderMeta(folderId);
  const next = {
    name: name === undefined ? current.name : normalizeFolderName(name),
    description: description === undefined ? current.description : normalizeFolderDescription(description),
    createdAt: current.createdAt,
  };
  if (name !== undefined) await assertFolderNameAvailable(next.name, folderId);
  try {
    await writeFolderMeta(folderId, next);
  } catch {
    throw backupError("FOLDER_UNAVAILABLE", "ذخیره‌ی تغییرات پوشه ممکن نشد؛ مجوز دسترسی را بررسی کنید");
  }
  return buildFolderSummary(folderId, await getActiveFolderId());
}

// حذف پوشه — فقط پوشه‌ی کاملاً خالی و غیرفعال؛ هیچ‌وقت به‌صورت بازگشتی حذف نمی‌کند، پس
// پوشه‌ی دارای پشتیبان (یا هر فایل دیگر) هرگز به‌طور تصادفی از بین نمی‌رود
export async function deleteFolder(folderId) {
  if (folderId === DEFAULT_FOLDER_ID) throw backupError("FOLDER_PROTECTED", "پوشه‌ی پیش‌فرض قابل حذف نیست");
  if (folderId === CUSTOM_FOLDER_ID) throw backupError("FOLDER_PROTECTED", "پوشه‌ی انتخاب‌شده روی کامپیوتر از داخل برنامه حذف نمی‌شود");
  await assertFolderExists(folderId);
  if (folderId === (await getActiveFolderId())) {
    throw backupError("FOLDER_PROTECTED", "پوشه‌ی فعال قابل حذف نیست؛ ابتدا پوشه‌ی دیگری را فعال کنید");
  }
  const dir = folderDir(folderId);
  const entries = await fsp.readdir(dir);
  if (entries.some((e) => e !== FOLDER_META_FILE && !TEMP_FILE_PATTERN.test(e))) {
    throw backupError("FOLDER_NOT_EMPTY", "این پوشه شامل فایل پشتیبان است؛ برای حذف پوشه ابتدا پشتیبان‌های آن را حذف کنید");
  }
  try {
    for (const e of entries) await fsp.unlink(path.join(dir, e));
    await fsp.rmdir(dir); // غیربازگشتی: اگر چیزی اضافه شده باشد ENOTEMPTY می‌دهد
  } catch (err) {
    if (err.code === "ENOTEMPTY" || err.code === "EEXIST") {
      throw backupError("FOLDER_NOT_EMPTY", "این پوشه شامل فایل پشتیبان است؛ برای حذف پوشه ابتدا پشتیبان‌های آن را حذف کنید");
    }
    throw backupError("FOLDER_UNAVAILABLE", "حذف پوشه ممکن نشد؛ مجوز دسترسی را بررسی کنید");
  }
}

// ---------- پوشه‌ی انتخاب‌شده روی کامپیوتر ----------
function normalizeStoredCustomDir(value) {
  return typeof value === "string" && value && path.isAbsolute(value) && !value.includes("\0") ? path.resolve(value) : null;
}

// کش حافظه‌ای را با مقدار ذخیره‌شده در تنظیمات هم‌گام می‌کند (برای فراخوانی‌های همگام مثل folderDir)
function syncCustomDir(settings) {
  customDir = normalizeStoredCustomDir(settings && settings[CUSTOM_DIR_SETTING]);
}

export async function loadCustomBackupDir() {
  syncCustomDir(await getAllSettings());
  return customDir;
}

function samePathOrInside(child, parent) {
  const norm = (p) => (process.platform === "win32" ? p.toLowerCase() : p);
  const c = norm(child);
  const par = norm(parent);
  return c === par || c.startsWith(par.endsWith(path.sep) ? par : par + path.sep);
}

// مسیر انتخاب‌شده باید: مطلق، موجود، پوشه (نه فایل)، غیر از ریشه‌ی درایو، بیرون از پوشه‌ی عمومی
// uploads و واقعاً قابل نوشتن باشد (یک فایل موقتی ساخته و پاک می‌شود).
export async function validateCustomDir(rawPath) {
  if (typeof rawPath !== "string" || !rawPath.trim() || rawPath.length > 1024 || rawPath.includes("\0") || !path.isAbsolute(rawPath.trim())) {
    throw backupError("FOLDER_PATH_INVALID", "مسیر پوشه نامعتبر است");
  }
  let real;
  try {
    real = await fsp.realpath(path.resolve(rawPath.trim()));
    const st = await fsp.stat(real);
    if (!st.isDirectory()) throw new Error("not a directory");
  } catch {
    throw backupError("FOLDER_NOT_FOUND", "پوشه‌ی انتخاب‌شده وجود ندارد");
  }
  if (path.parse(real).root === real) {
    throw backupError("FOLDER_PATH_INVALID", "خودِ درایو قابل انتخاب نیست؛ داخل آن یک پوشه بسازید (مثلاً Shafakhana-Backups) و همان را انتخاب کنید");
  }
  if (samePathOrInside(real, path.resolve(PUBLIC_UPLOADS_DIR))) {
    throw backupError("FOLDER_PATH_INVALID", "این پوشه برای بکاپ مجاز نیست (داخل پوشه‌ی فایل‌های عمومی سایت است)");
  }
  const probe = path.join(real, `.tmp-${crypto.randomBytes(4).toString("hex")}.part`);
  try {
    await fsp.writeFile(probe, "", { flag: "wx", mode: 0o600 });
    await fsp.unlink(probe);
  } catch {
    await fsp.unlink(probe).catch(() => {});
    throw backupError("FOLDER_UNAVAILABLE", "در این پوشه اجازه‌ی نوشتن وجود ندارد؛ پوشه‌ی دیگری انتخاب کنید");
  }
  return real;
}

// مسیر پوشه‌ی انتخاب‌شده را ذخیره و آن را «پوشه‌ی فعال» می‌کند؛ بکاپ‌های دستی و خودکار از این به بعد
// همان‌جا نوشته می‌شوند. بکاپ‌های قبلی (در پوشه‌ی پیش‌فرض) هیچ تغییری نمی‌کنند.
export async function setCustomBackupDir(rawPath) {
  const dir = await validateCustomDir(rawPath);
  await setSetting(CUSTOM_DIR_SETTING, dir);
  customDir = dir;
  await setSetting(ACTIVE_FOLDER_SETTING, CUSTOM_FOLDER_ID);
  return buildFolderSummary(CUSTOM_FOLDER_ID, CUSTOM_FOLDER_ID);
}

// انتخاب پوشه‌ی مقصد برای بکاپ‌های بعدی — بکاپ‌های قبلی (در هر پوشه) هیچ تغییری نمی‌کنند
export async function setActiveFolder(folderId) {
  if (!isValidFolderId(folderId)) throw backupError("INVALID_FOLDER", "شناسه‌ی پوشه نامعتبر است");
  const access = await checkFolderWritable(folderId);
  if (!access.ok) throw backupError(access.code, access.message);
  await setSetting(ACTIVE_FOLDER_SETTING, folderId);
  return buildFolderSummary(folderId, folderId);
}

// ---------- تهیه پشتیبان ----------
// type: "manual" (دستی توسط سوپرادمین) | "scheduled" (زمان‌بندی‌شده خودکار) | "pre-restore" (پشتیبان ایمنی خودکار پیش از بازیابی)
// folderId: پوشه‌ی مقصد؛ اگر داده نشود «پوشه‌ی فعال» ذخیره‌شده در تنظیمات استفاده می‌شود.
// keepFilenames: فایل‌هایی که نگهداری خودکار (Retention) حق حذفشان را ندارد.
export async function createBackup({ triggeredBy = "manual", folderId, keepFilenames = [] } = {}) {
  const targetId = folderId || (await getActiveFolderId());
  // پیش از هر کاری (حتی دامپ دیتابیس) مقصد بررسی می‌شود تا در صورت نبودن/قابل‌نوشتن‌نبودن پوشه،
  // با خطای واضح متوقف شویم و هیچ فایل قبلی‌ای دست نخورد
  const access = await checkFolderWritable(targetId);
  if (!access.ok) throw backupError(access.code, access.message);

  const settings = await getAllSettings();
  const pool = await getPool();
  const tables = await getTableNames(pool);

  let sql = `-- شفاخانه افغان آریا — پشتیبان دیتابیس\n-- تاریخ تولید: ${new Date().toISOString()}\n-- نوع: ${triggeredBy}\n-- دیتابیس: ${DB_NAME}\n\nSET NAMES utf8mb4;\nSET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";\nSET FOREIGN_KEY_CHECKS = 0;\n`;

  for (const table of tables) {
    sql += await dumpTable(pool, table);
  }

  sql += `\n${BACKUP_FOOTER}\n`;

  const encrypted = isBackupEncryptionEnabled();
  const filename = buildFilename(triggeredBy, settings.timezone, encrypted);
  const filePath = path.join(access.dir, filename);
  const payload = encrypted ? encryptBackup(Buffer.from(sql, "utf8")) : Buffer.from(sql, "utf8");
  // ابتدا در فایل موقت (.part) نوشته و بعد rename می‌شود؛ پس فایلی که با نام نهایی (.sql) دیده
  // می‌شود همیشه کامل است و قطع شدن وسط نوشتن، فایل ناقصِ «معتبرنما» به جا نمی‌گذارد.
  // mode 0o600: فقط صاحب فایل (پروسه سرور) اجازه خواندن/نوشتن دارد
  const tmpPath = path.join(access.dir, `.tmp-${crypto.randomBytes(4).toString("hex")}.part`);
  try {
    await fsp.writeFile(tmpPath, payload, { mode: 0o600, flag: "wx" });
    await fsp.rename(tmpPath, filePath);
  } catch (err) {
    await fsp.unlink(tmpPath).catch(() => {});
    if (["ENOSPC", "EACCES", "EPERM", "EROFS", "EDQUOT", "ENOENT"].includes(err.code)) {
      throw backupError("FOLDER_UNAVAILABLE", "نوشتن فایل پشتیبان در پوشه‌ی انتخاب‌شده ممکن نشد (فضای دیسک یا مجوز دسترسی را بررسی کنید)");
    }
    throw err;
  }

  const stat = await fsp.stat(filePath);
  await copyOffsite(filePath, filename, encrypted);
  // بکاپ سالم (دستی یا خودکار) یعنی مقصد درست کار می‌کند؛ پس هشدار قرمز «آخرین بکاپ خودکار ناموفق بود»
  // دیگر معتبر نیست و پاک می‌شود (قبلاً فقط بکاپ خودکار موفق آن را پاک می‌کرد)
  await setSetting(LAST_ERROR_SETTING, "").catch(() => {});
  try {
    await enforceRetention(targetId, [filename, ...keepFilenames], settings);
  } catch (err) {
    console.error("⚠️  خطا در پاک‌سازی خودکار پشتیبان‌های قدیمی:", err.message);
  }

  return { filename, size: stat.size, createdAt: creationDate(stat), type: triggeredBy, tableCount: tables.length, folderId: targetId, encrypted };
}

// ---------- فهرست پشتیبان‌ها ----------
async function readFolderBackups(folderId, { withStatus = false } = {}) {
  const dir = folderDir(folderId);
  const files = await fsp.readdir(dir).catch(() => []);
  const items = await Promise.all(
    files
      .filter((f) => isValidBackupFilename(f))
      .map(async (filename) => {
        const filePath = path.join(dir, filename);
        const st = await fsp.stat(filePath).catch(() => null);
        if (!st || !st.isFile()) return null;
        const item = {
          filename,
          folderId,
          type: filename.match(FILENAME_PATTERN)[1],
          size: st.size,
          createdAt: creationDate(st),
          encrypted: filename.endsWith(".enc"),
        };
        if (withStatus) {
          const check = await inspectBackupFile(filePath).catch(() => ({ ok: false, message: "خواندن فایل ممکن نشد" }));
          item.status = check.ok ? "ok" : "corrupt";
          if (!check.ok) item.statusMessage = check.message;
        }
        return item;
      })
  );
  return items.filter(Boolean);
}

// folderId داده شود → فقط همان پوشه؛ وگرنه همه‌ی پوشه‌ها (برای آمار کلی/آخرین پشتیبان/وضعیت سلامت).
// withStatus: سلامت هر فایل (کامل یا ناقص) هم بررسی می‌شود.
export async function listBackups({ folderId, withStatus = false } = {}) {
  const ids = folderId ? [folderId] : listFolderIdsSync();
  const lists = await Promise.all(ids.map((id) => readFolderBackups(id, { withStatus })));
  return lists.flat().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// ---------- حذف پشتیبان ----------
export async function deleteBackup(filename, folderId) {
  const filePath = getBackupFilePath(filename, folderId);
  await fsp.unlink(filePath);
}

// ---------- نگهداری خودکار (Retention) ----------
// تعداد فایل‌های پشتیبان نگه‌داشته‌شده در «همان پوشه‌ای که پشتیبان جدید در آن نوشته شد» محدود
// می‌شود تا فضای دیسک به‌مرور پر نشود؛ قدیمی‌ترین فایل‌های اضافه بر حد مجازِ همان پوشه خودکار
// حذف می‌شوند. پوشه‌های دیگر (و بکاپ‌های قبلی بعد از تغییر پوشه‌ی فعال) هرگز لمس نمی‌شوند.
const STALE_TEMP_MS = 60 * 60 * 1000;

async function enforceRetention(folderId, keepFilenames = [], settings) {
  const dir = folderDir(folderId);
  const config = settings || (await getAllSettings());
  const retentionCount = Number(config.backupRetentionCount) > 0 ? Number(config.backupRetentionCount) : 14;

  // فایل‌های موقتِ رهاشده‌ی نوشتن‌های نیمه‌کاره
  const names = await fsp.readdir(dir).catch(() => []);
  for (const name of names.filter((n) => TEMP_FILE_PATTERN.test(n))) {
    const st = await fsp.stat(path.join(dir, name)).catch(() => null);
    if (st && Date.now() - st.mtimeMs > STALE_TEMP_MS) await fsp.unlink(path.join(dir, name)).catch(() => {});
  }

  const backups = await listBackups({ folderId });
  if (backups.length <= retentionCount) return;

  const keep = new Set(keepFilenames);
  const toDelete = backups.slice(retentionCount).filter((b) => !keep.has(b.filename));
  for (const b of toDelete) {
    await fsp.unlink(path.join(dir, b.filename)).catch(() => {});
  }
}

// ---------- اعتبارسنجی محتوای فایل پشتیبان ----------
// جدا از بررسی نام فایل (الگوی سفید/whitelist در getBackupFilePath که مسیر و پسوند را
// کنترل می‌کند)، این تابع خودِ محتوای فایل را هم به‌صورت سبک بررسی می‌کند تا از بازیابی
// یک فایل خالی، ناقص یا دست‌کاری‌شده (که می‌تواند دیتابیس را در وضعیت خراب رها کند)
// جلوگیری شود. فقط ابتدا و انتهای فایل خوانده می‌شود (نه کل آن) چون فایل‌های پشتیبان می‌توانند حجیم باشند.
const BACKUP_HEADER_SIGNATURE = "شفاخانه افغان آریا — پشتیبان دیتابیس";
const BACKUP_FOOTER = "SET FOREIGN_KEY_CHECKS = 1;";
const HEADER_READ_BYTES = 4096;
const FOOTER_READ_BYTES = 512;

async function inspectBackupFile(filePath) {
  const stat = await fsp.stat(filePath);
  if (!stat.size) {
    return { ok: false, size: 0, message: "فایل پشتیبان خالی است و قابل بازیابی نیست" };
  }

  // فایل رمزنگاری‌شده: محتوایش بدون کلید خوانا نیست؛ فقط امضا و حداقل اندازه بررسی می‌شود. صحت کامل
  // (برچسب GCM) و سرآیند/پایان SQL هنگام بازیابی و «پیش از هر تغییری در دیتابیس» بررسی می‌شود.
  if (filePath.endsWith(".enc")) {
    const probe = Buffer.alloc(ENC_MAGIC.length);
    const fh = await fsp.open(filePath, "r");
    try { await fh.read(probe, 0, probe.length, 0); } finally { await fh.close(); }
    if (stat.size < MIN_ENCRYPTED_SIZE || !probe.equals(ENC_MAGIC)) {
      return { ok: false, size: stat.size, message: "فایل پشتیبان رمزنگاری‌شده نامعتبر یا ناقص است" };
    }
    return { ok: true, size: stat.size };
  }

  const handle = await fsp.open(filePath, "r");
  let header = "";
  let tail = "";
  try {
    const head = Buffer.alloc(Math.min(HEADER_READ_BYTES, stat.size));
    await handle.read(head, 0, head.length, 0);
    header = head.toString("utf8");

    const tailLength = Math.min(FOOTER_READ_BYTES, stat.size);
    const end = Buffer.alloc(tailLength);
    await handle.read(end, 0, tailLength, stat.size - tailLength);
    tail = end.toString("utf8");
  } finally {
    await handle.close();
  }

  // فقط فایل‌هایی که واقعاً توسط همین ماژول (createBackup) برای همین دیتابیس تولید شده‌اند
  // معتبر شناخته می‌شوند — از بازیابی تصادفیِ فایل SQL نامرتبط یا دست‌کاری‌شده جلوگیری می‌کند
  if (!header.includes(BACKUP_HEADER_SIGNATURE) || !header.includes(`دیتابیس: ${DB_NAME}`)) {
    return { ok: false, size: stat.size, message: "این فایل، پشتیبان معتبر سیستم شفاخانه نیست یا محتوای آن دست‌کاری شده است" };
  }
  // createBackup همیشه فایل را با همین خط پایانی می‌نویسد؛ نبودن آن یعنی فایل ناقص/بریده‌شده است
  if (!tail.trimEnd().endsWith(BACKUP_FOOTER)) {
    return { ok: false, size: stat.size, message: "فایل پشتیبان ناقص است (انتهای فایل کامل نیست) و قابل بازیابی نیست" };
  }
  return { ok: true, size: stat.size };
}

export async function validateBackupFile(filename, folderId) {
  // نام/مسیر نامعتبر یا نبودن فایل روی دیسک همین‌جا با کد INVALID_FILENAME/ENOENT رد می‌شود
  const filePath = getBackupFilePath(filename, folderId);
  const check = await inspectBackupFile(filePath);
  if (!check.ok) throw backupError("INVALID_BACKUP_CONTENT", check.message);
  return { filePath, size: check.size };
}

// فایل پشتیبان را به دستورهای SQL جدا می‌کند (جداکننده‌ی «;» فقط خارج از رشته/نام ستون/کامنت).
// لازم است چون ارسال کل فایل در یک کوئری از max_allowed_packet بزرگ‌تر می‌شد؛ حالا هر دستور
// جداگانه (و کوچک) اجرا می‌شود.
export function splitSqlStatements(sql) {
  const out = [];
  let start = 0;
  let quote = null;
  for (let i = 0; i < sql.length; i += 1) {
    const ch = sql[i];
    if (quote) {
      if (ch === "\\" && quote !== "`") i += 1;
      else if (ch === quote) quote = null;
      continue;
    }
    if (ch === "'" || ch === '"' || ch === "`") quote = ch;
    else if (ch === "-" && sql[i + 1] === "-" && (i === 0 || sql[i - 1] === "\n")) {
      const nl = sql.indexOf("\n", i);
      i = nl === -1 ? sql.length : nl;
    } else if (ch === ";") {
      const stmt = sql.slice(start, i).trim();
      if (stmt) out.push(stmt);
      start = i + 1;
    }
  }
  const rest = sql.slice(start).trim();
  if (rest) out.push(rest);
  return out;
}

// ---------- بازیابی از پشتیبان ----------
// پیش از اجرای بازیابی (که مخرب است و داده‌های فعلی را جایگزین می‌کند)، ابتدا محتوای فایل
// اعتبارسنجی می‌شود (validateBackupFile) و سپس یک پشتیبان ایمنی خودکار از وضعیت فعلی
// دیتابیس (در پوشه‌ی فعال) گرفته می‌شود تا در صورت اشتباه، امکان بازگشت وجود داشته باشد.
// فایل در حال بازیابی از حذف خودکار نگهداری (Retention) همان پشتیبان ایمنی مستثنا می‌شود.
//
// اجرای دستورات SQL چندگانه (چند INSERT/CREATE پشت‌سرهم) با یک اتصال جداگانه و یک‌بارمصرف
// انجام می‌شود که فقط برای همین عملیات multipleStatements فعال دارد — عمداً pool اصلی
// برنامه (که همه‌ی کوئری‌های پارامتری‌شده‌ی کاربران را اجرا می‌کند) دست‌نخورده باقی می‌ماند
// تا امنیت کلی برنامه در برابر تزریق SQL کاهش پیدا نکند.
export async function restoreBackup(filename, folderId) {
  const { filePath } = await validateBackupFile(filename, folderId);

  // ابتدا (قبل از هر تغییری) فایل خوانده/رمزگشایی و کاملاً اعتبارسنجی می‌شود: کلید اشتباه یا فایل
  // دست‌کاری‌شده نباید حتی به مرحله‌ی «بکاپ ایمنی» یا اجرای SQL برسد.
  const sql = await readBackupSql(filePath);
  const plainCheck = validatePlainSql(sql);
  if (!plainCheck.ok) throw backupError("INVALID_BACKUP_CONTENT", plainCheck.message);

  await createBackup({ triggeredBy: "pre-restore", keepFilenames: [filename] });

  const connection = await mysql.createConnection({
    host: process.env.DB_HOST || "localhost",
    port: process.env.DB_PORT || 3306,
    user: process.env.DB_USER || "root",
    password: process.env.DB_PASSWORD || "",
    database: DB_NAME,
    charset: "utf8mb4",
    multipleStatements: true,
  });

  try {
    for (const statement of splitSqlStatements(sql)) {
      await connection.query(statement);
    }
  } finally {
    await connection.end();
  }
}

// ---------- زمان‌بندی پشتیبان‌گیری خودکار ----------
// تنظیمات (فعال/غیرفعال، تناوب، ساعت، تعداد نگهداری) از «تنظیمات سیستم» در دیتابیس خوانده می‌شوند
// و Super Admin آن‌ها را از داشبورد ← پشتیبان‌گیری تغییر می‌دهد؛ با هر تغییر، زمان‌بند بدون
// نیاز به ری‌استارت سرور دوباره ساخته می‌شود (applyBackupSchedule).
//
// چون سرور گاهی (مثلاً روی سیستم شخصی/XAMPP) در ساعت زمان‌بندی خاموش یا در حالت Sleep است و
// cron آن اجرا را از دست می‌دهد، علاوه بر cron یک «بررسی جبرانی» هم هست: هنگام راه‌اندازی و بعد
// هر ۳۰ دقیقه چک می‌شود که آیا آخرین پشتیبان خودکار قدیمی‌تر از آخرین موعد برنامه است؛ اگر بود،
// همان لحظه پشتیبان گرفته می‌شود.
const CATCH_UP_INTERVAL_MS = 30 * 60 * 1000;
const STARTUP_DELAY_MS = 60 * 1000;

let scheduledTask = null;
let catchUpTimer = null;
let startupTimer = null;
let scheduledBackupRunning = false;

function parseTime(time) {
  const [h, m] = String(time || "03:00").split(":").map(Number);
  return { hour: Number.isFinite(h) ? h : 3, minute: Number.isFinite(m) ? m : 0 };
}

// عبارت cron مربوط به تنظیمات (به وقت سرور — مثل زمان‌بندی قبلی)
export function buildBackupCron({ frequency, time }) {
  const { hour, minute } = parseTime(time);
  switch (frequency) {
    case "every6h": return `${minute} */6 * * *`;
    case "every12h": return `${minute} */12 * * *`;
    case "weekly": return `${minute} ${hour} * * 5`; // جمعه‌ها (روز تعطیل و کم‌ترافیک)
    default: return `${minute} ${hour} * * *`;
  }
}

// آخرین موعدی که طبق برنامه باید پشتیبان گرفته می‌شد (و از «الان» گذشته است)
export function previousScheduledTime(now, { frequency, time }) {
  const { hour, minute } = parseTime(time);
  const d = new Date(now);
  if (frequency === "every6h" || frequency === "every12h") {
    const step = frequency === "every6h" ? 6 : 12;
    d.setMinutes(minute, 0, 0);
    d.setHours(Math.floor(d.getHours() / step) * step);
    if (d > now) d.setHours(d.getHours() - step);
    return d;
  }
  d.setHours(hour, minute, 0, 0);
  if (frequency === "weekly") {
    d.setDate(d.getDate() - ((d.getDay() - 5 + 7) % 7));
    if (d > now) d.setDate(d.getDate() - 7);
    return d;
  }
  if (d > now) d.setDate(d.getDate() - 1);
  return d;
}

async function getLastScheduledBackupAt() {
  const backups = await listBackups(); // از قبل بر اساس جدیدترین مرتب شده است
  const last = backups.find((b) => b.type === "scheduled");
  return last ? new Date(last.createdAt) : null;
}

async function runScheduledBackup() {
  if (scheduledBackupRunning) return; // جلوگیری از اجرای هم‌زمان دو پشتیبان
  scheduledBackupRunning = true;
  try {
    const result = await createBackup({ triggeredBy: "scheduled" });
    console.log(`🗄️  پشتیبان‌گیری خودکار دیتابیس با موفقیت انجام شد: ${result.filename} (پوشه: ${result.folderId})`);
    await setSetting(LAST_ERROR_SETTING, "").catch(() => {});
  } catch (err) {
    console.error("❌ خطا در پشتیبان‌گیری خودکار دیتابیس:", err.message);
    // آخرین خطا برای نمایش در داشبورد نگه‌داری می‌شود (بکاپ‌های قبلی هیچ تغییری نمی‌کنند)
    await setSetting(LAST_ERROR_SETTING, JSON.stringify({ at: new Date().toISOString(), message: err.message })).catch(() => {});
  } finally {
    scheduledBackupRunning = false;
  }
}

// اگر موعد برنامه گذشته ولی پشتیبان خودکاری بعد از آن ساخته نشده، همین حالا می‌سازد
export async function runBackupIfOverdue() {
  try {
    const settings = await getAllSettings();
    if (settings.backupAutoEnabled !== "on") return;
    const due = previousScheduledTime(new Date(), { frequency: settings.backupAutoFrequency, time: settings.backupAutoTime });
    const last = await getLastScheduledBackupAt();
    if (!last || last < due) {
      console.log("⏱️  موعد پشتیبان‌گیری خودکار گذشته بود (سرور خاموش/در حالت Sleep بوده)؛ پشتیبان همین حالا گرفته می‌شود");
      await runScheduledBackup();
    }
  } catch (err) {
    console.error("❌ خطا در بررسی پشتیبان‌گیری خودکار:", err.message);
  }
}

// زمان‌بند را بر اساس تنظیمات فعلی (دوباره) می‌سازد؛ هم هنگام راه‌اندازی و هم پس از هر تغییر تنظیمات صدا زده می‌شود
export async function applyBackupSchedule() {
  stopBackupScheduler();
  const settings = await getAllSettings();

  if (settings.backupAutoEnabled !== "on") {
    console.log("⏸️  پشتیبان‌گیری خودکار دیتابیس غیرفعال است (از داشبورد ← پشتیبان‌گیری قابل‌فعال‌سازی است)");
    return;
  }

  const cronExpr = buildBackupCron({ frequency: settings.backupAutoFrequency, time: settings.backupAutoTime });
  scheduledTask = cron.schedule(cronExpr, () => {
    runScheduledBackup();
  });
  catchUpTimer = setInterval(runBackupIfOverdue, CATCH_UP_INTERVAL_MS);
  catchUpTimer.unref?.();

  console.log(`⏰ پشتیبان‌گیری خودکار دیتابیس فعال شد (زمان‌بندی cron: ${cronExpr}، نگهداری: ${settings.backupRetentionCount} فایل)`);
}

export async function initBackupScheduler() {
  try {
    await loadCustomBackupDir();
    await applyBackupSchedule();
  } catch (err) {
    console.error("❌ خطا در راه‌اندازی پشتیبان‌گیری خودکار:", err.message);
    return;
  }
  startupTimer = setTimeout(runBackupIfOverdue, STARTUP_DELAY_MS);
  startupTimer.unref?.();
}

export function stopBackupScheduler() {
  if (scheduledTask) {
    scheduledTask.stop();
    scheduledTask = null;
  }
  if (catchUpTimer) {
    clearInterval(catchUpTimer);
    catchUpTimer = null;
  }
}

// وضعیت برای نمایش در داشبورد: تنظیمات فعلی + آخرین پشتیبان خودکار + اجرای بعدی
export async function getBackupScheduleStatus() {
  const settings = await getAllSettings();
  const enabled = settings.backupAutoEnabled === "on";
  const lastScheduledAt = await getLastScheduledBackupAt();
  let nextRunAt = null;
  if (enabled && scheduledTask && typeof scheduledTask.getNextRun === "function") {
    try {
      nextRunAt = scheduledTask.getNextRun() || null;
    } catch {
      nextRunAt = null;
    }
  }
  let lastError = null;
  if (settings[LAST_ERROR_SETTING]) {
    try {
      const parsed = JSON.parse(settings[LAST_ERROR_SETTING]);
      if (parsed && typeof parsed.message === "string") lastError = { at: parsed.at || null, message: parsed.message };
    } catch {
      lastError = null;
    }
  }
  return {
    enabled,
    lastError,
    timezone: settings.timezone,
    frequency: settings.backupAutoFrequency,
    time: settings.backupAutoTime,
    retentionCount: Number(settings.backupRetentionCount),
    lastScheduledAt,
    nextRunAt,
  };
}

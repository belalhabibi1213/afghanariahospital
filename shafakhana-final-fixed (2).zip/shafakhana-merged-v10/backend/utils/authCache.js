// کش بسیار کوتاه‌مدتِ درون‌فرایندی برای کاربرِ احرازهویت‌شده و نشستش (middleware/auth.js).
// بدون کش، هر درخواست API دو کوئری (users + user_sessions) می‌زد. با TTL چند ثانیه‌ای،
// درخواست‌های پشت‌سرهم یک کاربر (مثلاً لود یک داشبورد با ۱۰ فراخوانی) فقط یک‌بار به DB می‌رسند.
//
// امنیت: ابطال فوری حفظ می‌شود چون همه‌ی نوشتن‌هایی که isActive/role/mustChangePassword/mfaEnabled
// یا نشست را عوض می‌کنند (models/User.js و models/Session.js) همین‌جا کش را باطل می‌کنند.
// تنها حالت تأخیر: تغییر مستقیم دیتابیس بیرون از این برنامه، یا اجرای چندفرایندی (pm2 cluster)
// که حداکثر به‌اندازه‌ی TTL (پیش‌فرض ۲ ثانیه) دیر می‌رسد. با AUTH_CACHE_TTL_MS=0 کاملاً خاموش می‌شود.
// در NODE_ENV=test پیش‌فرض خاموش است (تست‌ها مستقیم روی DB می‌نویسند)، مگر صراحتاً تنظیم شود.

function resolveTtl() {
  const raw = process.env.AUTH_CACHE_TTL_MS;
  if (raw !== undefined && raw !== "") {
    const n = Number(raw);
    return Number.isFinite(n) && n >= 0 ? Math.min(n, 30_000) : 0;
  }
  return process.env.NODE_ENV === "test" ? 0 : 2000;
}

const MAX_ENTRIES = 5000;
const users = new Map(); // id -> { value, at }
const sessions = new Map(); // jti -> { value, at }

function getFrom(map, key) {
  const ttl = resolveTtl();
  if (!ttl) return undefined;
  const hit = map.get(key);
  if (!hit) return undefined;
  if (Date.now() - hit.at > ttl) {
    map.delete(key);
    return undefined;
  }
  return hit.value;
}

function setIn(map, key, value) {
  if (!resolveTtl() || !value) return; // «ناموجود» هرگز کش نمی‌شود (نشست/کاربر تازه نباید معطل شود)
  if (map.size >= MAX_ENTRIES) map.clear();
  map.set(key, { value, at: Date.now() });
}

export const getCachedUser = (id) => getFrom(users, String(id));
export const setCachedUser = (id, value) => setIn(users, String(id), value);
export const invalidateUser = (id) => { users.delete(String(id)); };

export const getCachedSession = (jti) => getFrom(sessions, jti);
export const setCachedSession = (jti, value) => setIn(sessions, jti, value);
// شناسه‌ی نشست در بیشتر مسیرهای ابطال معلوم نیست؛ پس کل کش نشست‌ها پاک می‌شود (ارزان است)
export const invalidateAllSessions = () => { sessions.clear(); };

export function clearAuthCache() {
  users.clear();
  sessions.clear();
}

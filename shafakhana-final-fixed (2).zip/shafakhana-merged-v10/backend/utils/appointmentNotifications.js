import { createNotification } from "../models/Notification.js";
import { getAllUsers } from "../models/User.js";

import { formatJalaliDate } from "./jalali.js";
// پیام اعلان متناسب با وضعیت جدید نوبت (برای اطلاع‌رسانی درون‌برنامه‌ای به بیمار)
// این تنظیمات توسط ادمین/سوپرادمین (تایید/رد/تکمیل نوبت) استفاده می‌شود؛ داکتر دیگر وضعیت نوبت را تغییر نمی‌دهد
export const APPOINTMENT_STATUS_NOTIFICATIONS = {
  confirmed: {
    title: "نوبت تایید شد",
    message: (a) => `نوبت شما نزد ${a.doctorName} برای تاریخ ${formatJalaliDate(a.appointmentDate, { month: "long" })} تایید شد.`,
  },
  cancelled: {
    title: "نوبت لغو شد",
    message: (a) => `متاسفانه نوبت شما نزد ${a.doctorName} برای تاریخ ${formatJalaliDate(a.appointmentDate, { month: "long" })} لغو شد.`,
  },
  completed: {
    title: "نوبت انجام شد",
    message: (a) => `نوبت شما نزد ${a.doctorName} با موفقیت انجام شد.`,
  },
  pending: {
    title: "وضعیت نوبت به‌روزرسانی شد",
    message: (a) => `نوبت شما نزد ${a.doctorName} برای تاریخ ${formatJalaliDate(a.appointmentDate, { month: "long" })} به «در انتظار تایید» بازگشت.`,
  },
};

// در صورتی که نوبت متعلق به یک کاربر واردشده باشد (نه مهمان)، یک اعلان درون‌برنامه‌ای
// درباره‌ی تغییر وضعیت برایش ثبت می‌کند. هرگز نباید باعث شکست درخواست اصلی شود.
export async function notifyAppointmentStatusChange(existingAppointment, newStatus) {
  const notifConfig = APPOINTMENT_STATUS_NOTIFICATIONS[newStatus];
  if (!notifConfig || !existingAppointment || !existingAppointment.patientUserId) return null;

  return createNotification({
    userId: existingAppointment.patientUserId,
    title: notifConfig.title,
    message: notifConfig.message(existingAppointment),
    type: "appointment",
    relatedId: existingAppointment.id,
  });
}

// هنگام ثبت هر نوبت تازه، هم داکتر مربوطه (اگر حساب کاربری وصل‌شده‌ای داشته باشد
// — یعنی از طریق «اتصال حساب داکتر» به سیستم وارد شود) و هم همه‌ی ادمین‌ها را مطلع می‌کند
// (سوپرادمین شامل نمی‌شود) تا هرچه سریع‌تر در زنگوله‌ی اعلان‌شان ببینند و بتوانند نوبتِ
// «در انتظار تایید» را تایید یا رد کنند. اگر تنظیمات سیستم روی «تایید خودکار»
// باشد، پیام صرفاً اطلاع‌رسانی است (نیازی به کنش فوری نیست). هرگز نباید باعث
// شکست ثبت نوبت شود؛ خطاهایش فقط لاگ می‌شوند (createNotification هم همین رفتار را دارد).
export async function notifyStaffOfNewAppointment({
  appointmentId,
  doctor,
  patientName,
  appointmentDate,
  appointmentTime,
  isAutoConfirmed,
}) {
  try {
    const title = isAutoConfirmed ? "نوبت جدید (تایید خودکار)" : "نوبت جدید در انتظار تایید";
    const patientLabel = patientName ? `${patientName} ` : "";
    const message = isAutoConfirmed
      ? `نوبت جدید ${patientLabel}نزد ${doctor.fullName} برای تاریخ ${formatJalaliDate(appointmentDate, { month: "long" })} ساعت ${appointmentTime} ثبت و به‌صورت خودکار تایید شد.`
      : `نوبت جدید ${patientLabel}نزد ${doctor.fullName} برای تاریخ ${formatJalaliDate(appointmentDate, { month: "long" })} ساعت ${appointmentTime} ثبت شد و در انتظار تایید ادمین است.`;

    // مجموعه (Set) برای جلوگیری از اعلان تکراری، اگر داکتر خودش هم یکی از ادمین‌ها بود
    // فقط «داکتر» و «ادمین‌ها» اعلان نوبت می‌گیرند؛ سوپرادمین عمداً دریافت‌کننده نیست
    // (تب «نوبت‌ها» در داشبورد سوپرادمین وجود ندارد و کلیک روی اعلان او را به داشبورد ادمین می‌برد)
    const recipientUserIds = new Set();
    if (doctor && doctor.userId) recipientUserIds.add(doctor.userId);

    const admins = await getAllUsers({ role: "admin" });
    admins.forEach((u) => recipientUserIds.add(u.id));

    await Promise.all(
      [...recipientUserIds].map((userId) =>
        createNotification({
          userId,
          title,
          message,
          type: "appointment",
          relatedId: appointmentId,
        })
      )
    );
  } catch (err) {
    console.error("خطا در اطلاع‌رسانی نوبت جدید به داکتر/ادمین:", err.message);
  }
}

// وقتی «بیمار» نوبت خودش را لغو می‌کند، داکتر مربوطه و ادمین‌ها باخبر می‌شوند تا
// بدانند این ساعت آزاد شده است. مانند اعلان نوبت جدید، هرگز نباید باعث شکست درخواست اصلی شود.
export async function notifyStaffOfPatientCancellation({ appointmentId, doctor, patientName, appointmentDate, appointmentTime }) {
  try {
    const title = "لغو نوبت توسط بیمار";
    const patientLabel = patientName ? `${patientName} ` : "";
    const message = `${patientLabel}نوبت خود نزد ${doctor.fullName} برای تاریخ ${formatJalaliDate(appointmentDate, { month: "long" })} ساعت ${appointmentTime} را لغو کرد.`;

    // سوپرادمین عمداً اعلان لغو نوبت نمی‌گیرد (فقط داکتر و ادمین‌ها)
    const recipientUserIds = new Set();
    if (doctor && doctor.userId) recipientUserIds.add(doctor.userId);
    const admins = await getAllUsers({ role: "admin" });
    admins.forEach((u) => recipientUserIds.add(u.id));

    await Promise.all(
      [...recipientUserIds].map((userId) =>
        createNotification({ userId, title, message, type: "appointment", relatedId: appointmentId })
      )
    );
  } catch (err) {
    console.error("خطا در اطلاع‌رسانی لغو نوبت به داکتر/ادمین:", err.message);
  }
}

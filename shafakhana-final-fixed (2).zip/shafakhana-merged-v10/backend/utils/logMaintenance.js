// نگهداری و پاک‌سازی خودکار لاگ‌ها (Log Retention & Archiving)
//
// مشکل: جدول‌های activity_logs و audit_logs با هر عملیات یک ردیف جدید می‌گیرند و هرگز
// کوچک نمی‌شوند؛ با گذشت زمان فضای دیسک را پر و کوئری‌های صفحه‌ی لاگ‌ها را کند می‌کنند.
//
// راه‌حل (هر شب، پس از پشتیبان‌گیری):
//  ۱) «لاگ فعالیت»: ردیف‌های قدیمی‌تر از activityLogRetentionDays (پیش‌فرض ۹۰ روز) به‌صورت
//     دسته‌ای حذف می‌شوند.
//  ۲) «لاگ حسابرسی»: چون این جدول عمداً غیرقابل‌حذف است (Trigger های trg_audit_logs_no_*)،
//     ردیف‌های قدیمی‌تر از auditLogArchiveMonths (پیش‌فرض ۱۲ ماه) ابتدا در یک فایل فشرده‌ی
//     JSON Lines (.jsonl.gz) آرشیو می‌شوند، فایل بازخوانی و تعدادش تأیید می‌شود، و فقط
//     بعد از تأیید، ردیف‌ها از جدول اصلی برداشته می‌شوند. اگر هر مرحله‌ی آرشیو شکست بخورد،
//     هیچ ردیفی حذف نمی‌شود. خودِ این عملیات هم در لاگ‌ها ثبت می‌شود.
//
// فایل‌های آرشیو در private-uploads/log-archives ذخیره می‌شوند (مثل فایل‌های پشتیبان، از
// مسیر عمومی /uploads قابل‌دسترسی نیست).

import fs from "fs";
import fsp from "fs/promises";
import path from "path";
import zlib from "zlib";
import readline from "readline";
import crypto from "crypto";
import { once } from "events";
import { fileURLToPath } from "url";
import cron from "node-cron";
import db, { getPool } from "../db.js";
import { getAllSettings } from "../models/Settings.js";
import { logActivity } from "../models/ActivityLog.js";
import { recordAudit } from "../models/AuditLog.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const LOG_ARCHIVES_DIR = path.join(__dirname, "..", "private-uploads", "log-archives");
fs.mkdirSync(LOG_ARCHIVES_DIR, { recursive: true });

const DELETE_BATCH = 5000; // تعداد ردیف در هر حذف — تا قفل طولانی روی جدول ایجاد نشود
const EXPORT_BATCH = 2000; // تعداد ردیف در هر خواندن هنگام آرشیو (مصرف حافظه‌ی کم)
const PAUSE_MS = 200; // مکث کوتاه بین دسته‌ها تا به درخواست‌های کاربران فشار نیاید

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// همان Trigger ساخته‌شده در db.js — بعد از هر دسته‌ی حذف آرشیوشده دقیقاً همین بازسازی می‌شود
const CREATE_NO_DELETE_TRIGGER_SQL = `
  CREATE TRIGGER trg_audit_logs_no_delete
  BEFORE DELETE ON audit_logs
  FOR EACH ROW
  BEGIN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ثبت‌های حسابرسی غیرقابل حذف هستند (Audit logs cannot be deleted)';
  END
`;

// ---------- ۱) لاگ فعالیت: حذف دسته‌ای رکوردهای قدیمی ----------
export async function purgeOldActivityLogs() {
  const settings = await getAllSettings();
  const days = Math.floor(Number(settings.activityLogRetentionDays));
  if (!Number.isFinite(days) || days <= 0) return { skipped: true, deleted: 0 };

  let deleted = 0;
  for (;;) {
    const [result] = await db.query(
      `DELETE FROM activity_logs WHERE createdAt < (NOW() - INTERVAL ${days} DAY) LIMIT ${DELETE_BATCH}`
    );
    deleted += result.affectedRows;
    if (result.affectedRows < DELETE_BATCH) break;
    await sleep(PAUSE_MS);
  }

  if (deleted > 0) {
    await logActivity({
      userName: "system",
      role: "system",
      action: "پاک‌سازی خودکار لاگ فعالیت",
      details: `${deleted} رکورد قدیمی‌تر از ${days} روز حذف شد`,
    });
  }
  return { skipped: false, deleted };
}

// ---------- ۲) لاگ حسابرسی: آرشیو فشرده، تأیید، سپس حذف کنترل‌شده ----------
function buildArchiveFilename() {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
  return `audit-logs-archive-${stamp}-${crypto.randomBytes(4).toString("hex")}.jsonl.gz`;
}

// فایل آرشیو را دوباره می‌خواند و تعداد خطوط را می‌شمارد تا مطمئن شویم فایل سالم است
async function countArchiveLines(filePath) {
  const input = fs.createReadStream(filePath).pipe(zlib.createGunzip());
  const rl = readline.createInterface({ input, crlfDelay: Infinity });
  let lines = 0;
  for await (const line of rl) {
    if (line.trim()) {
      JSON.parse(line); // اگر خط خراب باشد همین‌جا خطا می‌دهد
      lines += 1;
    }
  }
  return lines;
}

// یک دسته ردیف را حذف می‌کند. چون audit_logs Trigger ضدحذف دارد، Trigger فقط برای همین
// یک دسته (کسری از ثانیه) برداشته و بلافاصله بازسازی می‌شود. اگر بازسازی هم به هر دلیلی
// شکست بخورد، db.js در اولین راه‌اندازی بعدی سرور آن را دوباره می‌سازد.
async function deleteArchivedBatch(connection, cutoff, maxId) {
  await connection.query("DROP TRIGGER IF EXISTS trg_audit_logs_no_delete");
  try {
    const [result] = await connection.query(
      `DELETE FROM audit_logs WHERE createdAt < ? AND id <= ? LIMIT ${DELETE_BATCH}`,
      [cutoff, maxId]
    );
    return result.affectedRows;
  } finally {
    let restored = false;
    for (let attempt = 1; attempt <= 3 && !restored; attempt += 1) {
      try {
        await connection.query(CREATE_NO_DELETE_TRIGGER_SQL);
        restored = true;
      } catch (err) {
        console.error(`❌ بازسازی Trigger حذف audit_logs ناموفق بود (تلاش ${attempt}/۳):`, err.message);
        await sleep(500);
      }
    }
  }
}

export async function archiveOldAuditLogs() {
  const settings = await getAllSettings();
  const months = Math.floor(Number(settings.auditLogArchiveMonths));
  if (!Number.isFinite(months) || months <= 0) return { skipped: true, archived: 0 };

  // مرز زمانی فقط یک‌بار و به‌صورت رشته محاسبه می‌شود تا آرشیو و حذف دقیقاً روی یک مجموعه انجام شوند
  const [[cutoffRow]] = await db.query(
    `SELECT DATE_FORMAT(NOW() - INTERVAL ${months} MONTH, '%Y-%m-%d %H:%i:%s') AS cutoff`
  );
  const cutoff = cutoffRow.cutoff;

  const [[pending]] = await db.query("SELECT COUNT(*) AS total FROM audit_logs WHERE createdAt < ?", [cutoff]);
  if (!pending.total) return { skipped: false, archived: 0 };

  // مرحله‌ی ۱: نوشتن ردیف‌های قدیمی در فایل فشرده (بدون حذف چیزی از دیتابیس)
  const filename = buildArchiveFilename();
  const filePath = path.join(LOG_ARCHIVES_DIR, filename);
  const output = fs.createWriteStream(filePath);
  const gzip = zlib.createGzip();
  gzip.pipe(output);

  let exported = 0;
  let lastId = 0;
  let firstId = null;
  try {
    for (;;) {
      const [rows] = await db.query(
        `SELECT * FROM audit_logs WHERE createdAt < ? AND id > ? ORDER BY id ASC LIMIT ${EXPORT_BATCH}`,
        [cutoff, lastId]
      );
      if (rows.length === 0) break;
      for (const row of rows) {
        if (!gzip.write(`${JSON.stringify(row)}\n`)) await once(gzip, "drain");
      }
      if (firstId === null) firstId = rows[0].id;
      lastId = rows[rows.length - 1].id;
      exported += rows.length;
    }
    gzip.end();
    await once(output, "finish");

    // مرحله‌ی ۲: تأیید سلامت فایل — فقط اگر تعداد خطوط دقیقاً برابر باشد اجازه‌ی حذف داده می‌شود
    const verified = await countArchiveLines(filePath);
    if (verified !== exported) {
      throw new Error(`تعداد ردیف‌های فایل آرشیو (${verified}) با تعداد خوانده‌شده (${exported}) برابر نیست`);
    }
  } catch (err) {
    gzip.destroy();
    output.destroy();
    await fsp.unlink(filePath).catch(() => {});
    throw err;
  }

  if (exported === 0) {
    await fsp.unlink(filePath).catch(() => {});
    return { skipped: false, archived: 0 };
  }

  // مرحله‌ی ۳: حذف کنترل‌شده‌ی همان ردیف‌ها از جدول اصلی
  const pool = await getPool();
  const connection = await pool.getConnection();
  let removed = 0;
  try {
    for (;;) {
      const affected = await deleteArchivedBatch(connection, cutoff, lastId);
      removed += affected;
      if (affected < DELETE_BATCH) break;
      await sleep(PAUSE_MS);
    }
  } finally {
    connection.release();
  }

  const details = {
    archiveFile: filename,
    records: removed,
    fromId: firstId,
    toId: lastId,
    olderThan: cutoff,
    retentionMonths: months,
  };
  await recordAudit({
    tableName: "audit_logs",
    recordId: null,
    action: "DELETE",
    oldValues: details,
    newValues: null,
    userName: "system",
    role: "system",
  });
  await logActivity({
    userName: "system",
    role: "system",
    action: "آرشیو خودکار لاگ حسابرسی",
    details: `${removed} رکورد قدیمی‌تر از ${months} ماه در فایل ${filename} آرشیو و از جدول اصلی برداشته شد`,
  });

  return { skipped: false, archived: removed, file: filename };
}

// ---------- اجرای هر دو مرحله + زمان‌بندی ----------
let running = false;

export async function runLogMaintenance() {
  if (running) return; // جلوگیری از اجرای هم‌زمان دو نوبت
  running = true;
  try {
    const activity = await purgeOldActivityLogs();
    if (activity.deleted > 0) {
      console.log(`🧹 پاک‌سازی لاگ فعالیت: ${activity.deleted} رکورد قدیمی حذف شد`);
    }
  } catch (err) {
    console.error("❌ خطا در پاک‌سازی خودکار لاگ فعالیت:", err.message);
  }

  try {
    const audit = await archiveOldAuditLogs();
    if (audit.archived > 0) {
      console.log(`🗃️  آرشیو لاگ حسابرسی: ${audit.archived} رکورد در ${audit.file} آرشیو شد`);
    }
  } catch (err) {
    console.error("❌ خطا در آرشیو خودکار لاگ حسابرسی (هیچ رکوردی حذف نشد):", err.message);
  } finally {
    running = false;
  }
}

let scheduledTask = null;

export function initLogMaintenanceScheduler() {
  const enabled = (process.env.LOG_MAINTENANCE_ENABLED || "true").toLowerCase() !== "false";
  if (!enabled) {
    console.log("⏸️  پاک‌سازی/آرشیو خودکار لاگ‌ها غیرفعال است (LOG_MAINTENANCE_ENABLED=false)");
    return;
  }

  const configured = process.env.LOG_MAINTENANCE_CRON_SCHEDULE;
  const cronExpr = configured && cron.validate(configured) ? configured : "0 4 * * *"; // پیش‌فرض: هر شب ساعت ۴ بامداد
  if (configured && !cron.validate(configured)) {
    console.warn(`⚠️  مقدار LOG_MAINTENANCE_CRON_SCHEDULE ("${configured}") نامعتبر است؛ از پیش‌فرض (هر شب ساعت ۴) استفاده می‌شود`);
  }

  scheduledTask = cron.schedule(cronExpr, () => {
    runLogMaintenance();
  });

  // اگر سرور (مثلاً روی سیستم شخصی/XAMPP) ساعت زمان‌بندی روشن نبوده، یک‌بار کمی بعد از
  // راه‌اندازی هم اجرا می‌شود؛ چون عملیات تکرارپذیر و بی‌خطر است (فقط ردیف‌های قدیمی را می‌برد)
  const startupRun = setTimeout(() => {
    runLogMaintenance();
  }, 60 * 1000);
  startupRun.unref?.();

  console.log(`⏰ پاک‌سازی/آرشیو خودکار لاگ‌ها فعال شد (زمان‌بندی cron: ${cronExpr})`);
}

export function stopLogMaintenanceScheduler() {
  if (scheduledTask) {
    scheduledTask.stop();
    scheduledTask = null;
  }
}

import printer from "pdfmake";
import ExcelJS from "exceljs";
import path from "path";
import { fileURLToPath } from "url";
import { shapeRtl } from "./rtlText.js";

import { formatJalaliDate } from "./jalali.js";
// این فایل منطق مشترک خروجی‌گیری PDF/Excel را برای هر چهار نوع گزارش
// (نوبت‌ها، بیماران، داکتران، درآمد) در یک‌جا نگه می‌دارد تا کد تکراری نشود
// (الزام شماره ۵: خروجی PDF و Excel).
//
// PDF با pdfmake ساخته می‌شود (به‌جای رسم دستی x/y با pdfkit) تا از جدول واقعی
// pdfmake (چیدمان خودکار ستون‌ها، تکرار خودکار سربرگ در هر صفحه، بدون هم‌پوشانی متن،
// شکستن خودکار متن طولانی) بهره ببریم. چون pdfmake به‌صورت پیش‌فرض بازچینی/شکل‌دهی
// راست‌به‌چپ فارسی را انجام نمی‌دهد، همان shapeRtl (شکل‌دهی حروف + بازچینی کلمات) که
// قبلاً برای pdfkit استفاده می‌شد اینجا هم به‌ازای هر خط بازچین‌شده اعمال می‌شود.

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const FONT_REGULAR = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Medium.ttf");
const FONT_BOLD = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Bold.ttf");

printer.setFonts({
  Vazirmatn: { normal: FONT_REGULAR, bold: FONT_BOLD, italics: FONT_REGULAR, bolditalics: FONT_BOLD },
});
printer.setLocalAccessPolicy(() => true);
printer.setUrlAccessPolicy(() => false);

const BRAND_COLOR = "#2f8f7e";
const BRAND_LIGHT = "#e6f4f1";
const BORDER_COLOR = "#cfe3df";

// from/to: ISO میلادی (YYYY-MM-DD) از API؛ در خروجی به شمسی نمایش داده می‌شوند
function formatDateRangeLabel(rawFrom, rawTo) {
  const from = rawFrom ? formatJalaliDate(rawFrom, { latin: true }) : "";
  const to = rawTo ? formatJalaliDate(rawTo, { latin: true }) : "";
  if (from && to) return `از ${from} تا ${to}`;
  if (from) return `از ${from}`;
  if (to) return `تا ${to}`;
  return "همه‌ی بازه‌ی زمانی";
}

// شکستن خودکار متن طولانی داخل یک سلول جدول pdfmake بر اساس عرض واقعی ستون (نقطه)،
// سپس اعمال shapeRtl روی هر خطِ شکسته‌شده به‌طور جداگانه (تا ترتیب کلمات/حروف هر خط
// به‌درستی راست‌به‌چپ نمایش داده شود و هم‌پوشانی/برهم‌ریختگی متن رخ ندهد).
function wrapCell(value, widthPt, fontSize, bold = false) {
  const str = String(value ?? "").trim();
  if (!str) return "";
  const avgCharWidth = fontSize * (bold ? 0.62 : 0.56);
  const usable = Math.max(20, widthPt - 10);
  const maxChars = Math.max(4, Math.floor(usable / avgCharWidth));

  const words = str.split(/\s+/);
  const lines = [];
  let current = [];
  let currentLen = 0;
  for (const w of words) {
    const wLen = w.length + 1;
    if (current.length && currentLen + wLen > maxChars) {
      lines.push(current);
      current = [];
      currentLen = 0;
    }
    current.push(w);
    currentLen += wLen;
  }
  if (current.length) lines.push(current);

  return lines.map((lineWords) => shapeRtl(lineWords.join(" "))).join("\n");
}

// ---------- خروجی Excel ----------
// columns: [{ header, key, width? }]
export async function sendExcelReport(res, { fileName, title, from, to, columns, rows, summaryLines = [] }) {
  const workbook = new ExcelJS.Workbook();
  workbook.creator = "شفاخانه افغان آریا";
  workbook.created = new Date();

  const sheet = workbook.addWorksheet("گزارش", { views: [{ rightToLeft: true }] });

  sheet.mergeCells(1, 1, 1, columns.length);
  sheet.getCell(1, 1).value = title;
  sheet.getCell(1, 1).font = { size: 14, bold: true, color: { argb: "FF1F2937" } };
  sheet.getCell(1, 1).alignment = { horizontal: "center", vertical: "middle" };
  sheet.getRow(1).height = 26;

  sheet.mergeCells(2, 1, 2, columns.length);
  sheet.getCell(2, 1).value = formatDateRangeLabel(from, to);
  sheet.getCell(2, 1).font = { italic: true, color: { argb: "FF666666" } };
  sheet.getCell(2, 1).alignment = { horizontal: "center", vertical: "middle" };

  let nextRow = 3;
  for (const line of summaryLines) {
    sheet.mergeCells(nextRow, 1, nextRow, columns.length);
    sheet.getCell(nextRow, 1).value = line;
    sheet.getCell(nextRow, 1).font = { bold: true, color: { argb: "FF1F2937" } };
    sheet.getCell(nextRow, 1).alignment = { horizontal: "center", vertical: "middle" };
    nextRow += 1;
  }
  nextRow += 1;

  const headerRowIndex = nextRow;
  const headerRow = sheet.getRow(headerRowIndex);
  headerRow.values = columns.map((c) => c.header);
  headerRow.height = 22;
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: "FF1F2937" } };
    cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFE6F4F1" } };
    cell.alignment = { horizontal: "right", vertical: "middle", wrapText: true };
    cell.border = {
      top: { style: "thin", color: { argb: "FFB9D8D2" } },
      bottom: { style: "thin", color: { argb: "FFB9D8D2" } },
      left: { style: "thin", color: { argb: "FFB9D8D2" } },
      right: { style: "thin", color: { argb: "FFB9D8D2" } },
    };
  });

  rows.forEach((row, rowIdx) => {
    const values = columns.map((c) => row[c.key] ?? "");
    const excelRow = sheet.addRow(values);
    excelRow.eachCell((cell) => {
      cell.alignment = { horizontal: "right", vertical: "middle", wrapText: true };
      cell.border = {
        top: { style: "thin", color: { argb: "FFE5E7EB" } },
        bottom: { style: "thin", color: { argb: "FFE5E7EB" } },
        left: { style: "thin", color: { argb: "FFE5E7EB" } },
        right: { style: "thin", color: { argb: "FFE5E7EB" } },
      };
      if (rowIdx % 2 === 1) {
        cell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FFF7FBFA" } };
      }
    });
  });

  // عرض ستون‌ها به‌صورت خودکار بر اساس طول واقعی محتوا (سربرگ و همه‌ی ردیف‌ها)
  // محاسبه می‌شود؛ عدد وزنیِ column.width (که برای PDF استفاده می‌شود) اینجا دخیل نیست.
  columns.forEach((c, idx) => {
    const headerLen = String(c.header ?? "").length;
    let maxLen = headerLen;
    rows.forEach((r) => {
      const len = String(r[c.key] ?? "").length;
      if (len > maxLen) maxLen = len;
    });
    sheet.getColumn(idx + 1).width = Math.min(48, Math.max(10, maxLen + 4));
  });

  sheet.views = [{ rightToLeft: true, state: "frozen", ySplit: headerRowIndex }];

  res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  res.setHeader("Content-Disposition", `attachment; filename="${fileName}.xlsx"`);
  await workbook.xlsx.write(res);
  res.end();
}

// ---------- خروجی PDF ----------
// columns: [{ header, key, width? }]
// ستون‌ها با ترتیب معکوس در جدول pdfmake قرار می‌گیرند (ستون اول آرایه = آخرین ستون
// فیزیکی/راست‌ترین) چون pdfmake همیشه ستون‌ها را از چپ به راست رسم می‌کند؛ این دقیقاً
// همان ترتیب راست‌به‌چپِ جدول «مدیریت بیماران» را در PDF بازتولید می‌کند.
export async function sendPdfReport(res, { fileName, title, from, to, columns, rows, summaryLines = [] }) {
  try {
    const pageWidth = 841.89; // A4 landscape width in pt
    const margin = 28;
    const cellPaddingLR = 12; // paddingLeft(6) + paddingRight(6) — pdfmake adds this ON TOP of column width
    const borderOverhead = columns.length * cellPaddingLR + (columns.length + 1) * 0.5;
    const usableWidth = pageWidth - margin * 2 - borderOverhead;
    const totalWeight = columns.reduce((sum, c) => sum + (c.width || 1), 0);
    const colWidthsPt = columns.map((c) => ((c.width || 1) / totalWeight) * usableWidth);

    const columnsRtl = [...columns].reverse();
    const colWidthsRtl = [...colWidthsPt].reverse();

    const headerCells = columnsRtl.map((c, idx) => ({
      text: wrapCell(c.header, colWidthsRtl[idx], 9.5, true),
      bold: true,
      alignment: "right",
      fillColor: BRAND_LIGHT,
      margin: [0, 2, 0, 2],
    }));

    const bodyRows = rows.map((row) =>
      columnsRtl.map((c, idx) => ({
        text: wrapCell(row[c.key], colWidthsRtl[idx], 9, false),
        alignment: "right",
        margin: [0, 1, 0, 1],
      }))
    );

    const docDefinition = {
      pageSize: "A4",
      pageOrientation: "landscape",
      pageMargins: [margin, margin, margin, 40],
      defaultStyle: { font: "Vazirmatn", fontSize: 9, alignment: "right" },
      content: [
        { text: shapeRtl(title), fontSize: 17, bold: true, alignment: "center", color: "#1f2937" },
        { text: shapeRtl(formatDateRangeLabel(from, to)), fontSize: 10, alignment: "center", color: "#666666", margin: [0, 3, 0, 0] },
        {
          canvas: [{ type: "line", x1: 0, y1: 0, x2: usableWidth, y2: 0, lineWidth: 1.5, lineColor: BRAND_COLOR }],
          margin: [0, 10, 0, 10],
        },
        ...(summaryLines.length
          ? [
              // هر خط خلاصه جداگانه و در تمام عرض صفحه، راست‌چین، زیر هم می‌آید. قبلاً همه‌ی خطوط کنار هم در
              // ستون‌های باریک (columns) بودند و pdfmake متنِ از قبل راست‌به‌چپ‌شده را خودش (چپ‌به‌راست)
              // می‌شکست؛ در نتیجه ترتیب کلمات به‌هم می‌ریخت و قوس «(» و «)» از هم جدا و جابه‌جا می‌شدند.
              // اینجا شکستن خط (در صورت نیاز) با wrapCell انجام می‌شود که هر خط را جدا shapeRtl می‌کند.
              {
                stack: summaryLines.map((line) => ({
                  text: wrapCell(line, usableWidth, 9.5, true),
                  fontSize: 9.5,
                  bold: true,
                  alignment: "right",
                  margin: [0, 0, 0, 4],
                })),
                margin: [0, 0, 0, 12],
              },
            ]
          : []),
        {
          table: {
            headerRows: 1,
            widths: colWidthsRtl,
            body: [headerCells, ...bodyRows],
          },
          layout: {
            hLineWidth: (i, node) => (i === 0 || i === 1 || i === node.table.body.length ? 1 : 0.5),
            vLineWidth: () => 0.5,
            hLineColor: () => BORDER_COLOR,
            vLineColor: () => BORDER_COLOR,
            paddingLeft: () => 6,
            paddingRight: () => 6,
            paddingTop: () => 4,
            paddingBottom: () => 4,
            fillColor: (rowIndex) => (rowIndex === 0 ? null : rowIndex % 2 === 0 ? "#f7fbfa" : null),
          },
        },
      ],
      footer: (currentPage, pageCount) => ({
        columns: [
          { text: shapeRtl("شفاخانه افغان آریا"), fontSize: 8, color: "#9ca3af", margin: [margin, 0, 0, 0] },
          { text: shapeRtl(`صفحه ${currentPage} از ${pageCount}`), fontSize: 8, color: "#9ca3af", alignment: "center" },
          { text: "", margin: [0, 0, margin, 0] },
        ],
        margin: [0, 10, 0, 0],
      }),
    };

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${fileName}.pdf"`);

    const pdfDoc = printer.createPdf(docDefinition);
    const buffer = await pdfDoc.getBuffer();
    res.end(buffer);
  } catch (err) {
    console.error(err);
    if (!res.headersSent) {
      res.status(500).json({ message: "خطای سرور در ساخت PDF" });
    }
  }
}

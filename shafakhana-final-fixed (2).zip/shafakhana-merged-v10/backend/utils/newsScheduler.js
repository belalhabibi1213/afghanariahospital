// زمان‌بندی خودکار انتشار اخبار (Scheduled Publishing)
//
// اخبار با وضعیت 'scheduled' به‌محض رسیدن scheduledAt، حتی بدون این کرون، در صفحه‌ی
// عمومی اخبار نمایش داده می‌شوند (رجوع کنید به شرط WHERE در models/News.js -> getAllNews).
// این کرون فقط برای «تمیز نگه‌داشتن» ستون status در پنل ادمین است — تا خبری که زمانش
// رسیده در جدول مدیریت هم به‌جای «زمان‌بندی‌شده» به‌عنوان «منتشرشده» دیده شود، دقیقاً
// مثل الگوی زمان‌بندی پشتیبان‌گیری خودکار در utils/backup.js.
import cron from "node-cron";
import { publishDueScheduledNews } from "../models/News.js";

let scheduledTask = null;

export function initNewsScheduler() {
  // هر یک دقیقه بررسی می‌شود؛ برای یک ماژول اخبار (نه سیستم معاملاتی) این فاصله کافی است
  scheduledTask = cron.schedule("* * * * *", async () => {
    try {
      const count = await publishDueScheduledNews();
      if (count > 0) {
        console.log(`📰 ${count} خبر زمان‌بندی‌شده به‌صورت خودکار منتشر شد`);
      }
    } catch (err) {
      console.error("❌ خطا در بررسی اخبار زمان‌بندی‌شده:", err.message);
    }
  });

  console.log("⏰ زمان‌بندی خودکار انتشار اخبار فعال شد (بررسی هر دقیقه)");
}

export function stopNewsScheduler() {
  if (scheduledTask) {
    scheduledTask.stop();
    scheduledTask = null;
  }
}

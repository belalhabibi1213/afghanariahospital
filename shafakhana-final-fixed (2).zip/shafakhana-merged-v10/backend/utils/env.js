// اعتبارسنجی و متمرکزسازی متغیرهای محیطی حساس امنیتی.
// پیش از این، مقدار پیش‌فرض ناامن JWT_SECRET در چند فایل مختلف تکرار شده بود؛ این‌جا فقط
// یک‌بار خوانده، اعتبارسنجی و export می‌شود تا بقیه‌ی پروژه از همین‌جا وارد کنند.
// نکته: این فایل باید بعد از اجرای «./loadEnv.js» (اولین import در server.js) بارگذاری شود.

export const NODE_ENV = process.env.NODE_ENV || "development";
export const IS_PRODUCTION = NODE_ENV === "production";

const INSECURE_DEFAULT_JWT_SECRET = "change_this_secret_key";
const MIN_SECRET_LENGTH = 32;

function resolveJwtSecret() {
  const secret = process.env.JWT_SECRET;
  const isWeak = !secret || secret === INSECURE_DEFAULT_JWT_SECRET || secret.length < MIN_SECRET_LENGTH;

  if (!isWeak) return secret;

  // کلید غایب/پیش‌فرض/کوتاه در «همه‌ی» محیط‌ها رد می‌شود (نه فقط production)؛ چون کلید پیش‌فرض شناخته‌شده است
  // و هر کسی می‌تواند با آن توکن معتبر جعل کند. تنها استثنا: توسعه‌ی محلی با فلگ صریح ALLOW_INSECURE_DEV=true
  // (در production این فلگ نادیده گرفته می‌شود).
  const allowInsecureDev = !IS_PRODUCTION && String(process.env.ALLOW_INSECURE_DEV || "").trim().toLowerCase() === "true";
  if (!allowInsecureDev) {
    console.error(
      "❌ خطای امنیتی حیاتی: JWT_SECRET تنظیم نشده یا مقدار پیش‌فرض/کوتاه (کمتر از ۳۲ کاراکتر) دارد.\n" +
        "   یک رشته تصادفی طولانی تنظیم کنید، مثلاً: node -e \"console.log(require('crypto').randomBytes(48).toString('hex'))\"\n" +
        "   (فقط برای توسعه‌ی محلی می‌توانید صراحتاً ALLOW_INSECURE_DEV=true بگذارید؛ در production کار نمی‌کند.)"
    );
    process.exit(1);
  }

  console.warn(
    "⚠️  هشدار امنیتی: با ALLOW_INSECURE_DEV=true از کلید JWT ناامن پیش‌فرض استفاده می‌شود. هرگز در محیط واقعی استفاده نکنید."
  );
  return secret || INSECURE_DEFAULT_JWT_SECRET;
}

export const JWT_SECRET = resolveJwtSecret();

// دامنه‌های مجاز برای CORS — لیستی جدا‌شده با کاما در متغیر محیطی CORS_ORIGIN، مثال:
// CORS_ORIGIN=http://localhost:5173,https://shafakhana.example.com
const DEFAULT_DEV_ORIGINS = ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:3000"];

const configuredOrigins = (process.env.CORS_ORIGIN || "")
  .split(",")
  .map((origin) => origin.trim())
  .filter(Boolean);

// Render آدرس عمومی سرویس را خودش در RENDER_EXTERNAL_URL می‌دهد؛ در استقرار تک‌سرویس (بک‌اند + فرانت
// روی یک آدرس) همین آدرس به‌طور خودکار مجاز می‌شود و نیازی به تنظیم دستی CORS_ORIGIN نیست.
if (process.env.RENDER_EXTERNAL_URL && !configuredOrigins.includes(process.env.RENDER_EXTERNAL_URL)) {
  configuredOrigins.push(process.env.RENDER_EXTERNAL_URL);
}

if (configuredOrigins.length === 0 && IS_PRODUCTION) {
  console.warn(
    "⚠️  هشدار: CORS_ORIGIN در محیط production تنظیم نشده است؛ تا زمانی که تنظیم نشود، هیچ دامنه‌ای اجازه‌ی دسترسی نخواهد داشت."
  );
}

// در توسعه، حتی اگر کاربر مقدار سفارشی برای CORS_ORIGIN در .env تنظیم کرده باشد، پورت‌های
// رایج توسعه‌ی محلی (localhost/127.0.0.1 روی 5173 و 3000) هم اضافه می‌شوند. علت: خیلی از
// کاربران فقط "http://localhost:5173" را در .env می‌گذارند، اما مرورگر گاهی فرانت‌اند را از
// طریق آدرس معادل "http://127.0.0.1:5173" باز می‌کند (مثلاً از تاریخچه یا لینک). از نظر مرورگر
// این دو origin کاملاً متفاوت‌اند، پس بدون این ادغام، درخواست‌ها با خطای CORS رد می‌شدند حتی
// وقتی فرانت‌اند و بک‌اند هر دو کاملاً درست و محلی اجرا می‌شوند. در production این ادغام انجام
// نمی‌شود؛ آنجا فقط دقیقاً همان دامنه(های) صراحتاً تنظیم‌شده مجازند.
export const CORS_ORIGINS = IS_PRODUCTION
  ? configuredOrigins
  : Array.from(new Set([...configuredOrigins, ...DEFAULT_DEV_ORIGINS]));

// تعداد دورهای هش bcrypt — عدد بالاتر یعنی امنیت بیشتر اما کمی کندتر؛ ۱۲ استاندارد رایج enterprise است
export const BCRYPT_SALT_ROUNDS = Number(process.env.BCRYPT_SALT_ROUNDS) || 12;

// تنظیم "trust proxy" اکسپرس — وقتی سرور پشت یک ریورس‌پروکسی (Nginx، Load Balancer و ...)
// اجرا می‌شود، اکسپرس باید بداند به هدر X-Forwarded-For اعتماد کند تا req.ip واقعی کاربر را
// برگرداند؛ در غیر این صورت هم express-rate-limit (که rate limit را بر اساس IP اعمال می‌کند)
// و هم لاگ فعالیت‌ها (که ipAddress واقعی کاربر را ثبت می‌کند) IP خودِ پروکسی را می‌بینند، نه کاربر.
// پیش‌فرض false است (اتصال مستقیم/بدون پروکسی)؛ در production پشت پروکسی باید صراحتاً در .env
// فعال شود. مقدار می‌تواند "true"، یک عدد (تعداد hop مورد اعتماد) یا خالی باشد.
function resolveTrustProxy() {
  const raw = (process.env.TRUST_PROXY || "").trim();
  if (!raw) return false;
  if (raw === "true") return true;
  if (raw === "false") return false;
  const asNumber = Number(raw);
  return Number.isFinite(asNumber) ? asNumber : raw;
}

export const TRUST_PROXY = resolveTrustProxy();

// نقش‌هایی که ورود آن‌ها بدون احراز هویت دومرحله‌ای (MFA/TOTP) مجاز نیست. حساب بدون MFA از این نقش‌ها
// بعد از ورود فقط به مسیرهای راه‌اندازی MFA دسترسی دارد (middleware/auth.js).
// پیش‌فرض: در production → admin,superadmin ؛ در توسعه/تست → هیچ‌کدام (تا جریان‌های موجود نشکنند).
// با MFA_REQUIRED_ROLES (جدا‌شده با کاما، مثلاً "admin,superadmin,doctor"؛ خالی = هیچ‌کدام) قابل تغییر است.
const rawMfaRoles = process.env.MFA_REQUIRED_ROLES;
export const MFA_REQUIRED_ROLES = new Set(
  (rawMfaRoles !== undefined ? rawMfaRoles : IS_PRODUCTION ? "admin,superadmin" : "")
    .split(",")
    .map((r) => r.trim())
    .filter(Boolean)
);
// کلید اصلی MFA: MFA_ENABLED=false → MFA برای همه (سوپرادمین، ادمین، داکتر و ...) کاملاً خاموش است:
// نه اجباری است و نه بعد از رمز کد خواسته می‌شود. رازها و کدهای بازیابی کاربران در دیتابیس دست‌نخورده می‌مانند،
// پس با MFA_ENABLED=true (و ری‌استارت) همه همان برنامه‌ی Authenticator قبلی را دوباره استفاده می‌کنند.
const rawMfaEnabled = String(process.env.MFA_ENABLED ?? "true").trim().toLowerCase();
export const MFA_ENABLED = !["false", "0", "off", "no"].includes(rawMfaEnabled);
export const isMfaRequiredForRole = (role) => MFA_ENABLED && MFA_REQUIRED_ROLES.has(role);

if (IS_PRODUCTION && !process.env.MFA_ENCRYPTION_KEY) {
  console.warn("⚠️  MFA_ENCRYPTION_KEY تنظیم نشده؛ راز MFA از JWT_SECRET مشتق می‌شود (تغییر JWT_SECRET رازها را نامعتبر می‌کند).");
}

// کلید جداگانه برای توکن کوتاه‌مدت «مرحله‌ی MFA»؛ با کلید نشست (JWT_SECRET) فرق دارد تا این توکن
// هرگز به‌جای توکن نشست (کوکی/Bearer) پذیرفته نشود و MFA دور زده نشود.
export const MFA_TOKEN_SECRET = `${JWT_SECRET}:mfa-login-step:v1`;

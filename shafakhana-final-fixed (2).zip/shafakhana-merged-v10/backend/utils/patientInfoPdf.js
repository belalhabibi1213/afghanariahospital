import PDFDocument from "pdfkit";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { shapeRtl } from "./rtlText.js";
import { getAllSettings } from "../models/Settings.js";
import { LOGO_DIR } from "../middleware/upload.js";

import { formatJalaliDate } from "./jalali.js";
// خروجی PDF معلومات یک بیمار — برای «مشاهده/چاپ/دانلود معلومات بیمار» در پنل مدیریت
// بیماران (Admin > مدیریت بیماران). همان الگوی pdfkit + فونت فارسی + shapeRtl را که
// در utils/prescriptionPdf.js و utils/reportExport.js استفاده شده تکرار می‌کند تا سبک
// بصری خروجی‌های PDF در کل برنامه یکسان بماند.

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// نکته: زیرمجموعه‌ی "arabic" بسته‌ی @fontsource فقط حروف فارسی/عربی را دارد و برخی
// نویسه‌های لاتین رایج در متن فارسی (مثل خط‌تیره «-» که در تاریخ/جداکننده‌ها استفاده
// می‌شود) در آن گلیف ندارند — روی PDF به‌صورت خالی/نامرئی افتاده می‌شود. به‌جای آن از
// بسته‌ی کامل "vazirmatn" (همان‌که در reportExport.js هم استفاده شده) استفاده می‌شود
// که هم حروف فارسی و هم علائم/حروف لاتین را در یک فونت واحد دارد.
const FONT_REGULAR = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Medium.ttf");
const FONT_BOLD = path.join(__dirname, "..", "node_modules", "vazirmatn", "fonts", "ttf", "Vazirmatn-Bold.ttf");

const GENDER_LABEL = { male: "مرد", female: "زن" };

// تاریخ هجری شمسی (YYYY/MM/DD)
function fmtDate(value) {
  return value ? formatJalaliDate(value, { latin: true }) : "—";
}

function resolveFilePath(dir, fileUrl) {
  if (!dir || !fileUrl) return null;
  const filePath = path.join(dir, path.basename(fileUrl));
  return fs.existsSync(filePath) ? filePath : null;
}

// patient: خروجی getPatientDetailById (شامل فیلدهای patients + در صورت وجود حساب
// کاربری، فیلدهای تکمیلی users + assignedDoctorName/lastVisitDate/totalAppointments)
export async function sendPatientInfoPdf(res, patient) {
  const settings = await getAllSettings();
  const hospitalName = settings.hospitalName || "شفاخانه افغان آریا";
  const contactLine = [settings.hospitalAddress, settings.hospitalPhone].filter(Boolean).join("   |   ");
  const logoPath = resolveFilePath(LOGO_DIR, settings.logoUrl);

  const doc = new PDFDocument({ margin: 42, size: "A4" });
  doc.registerFont("fa", FONT_REGULAR);
  doc.registerFont("fa-bold", FONT_BOLD);

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `attachment; filename="patient-${patient.id}.pdf"`);
  doc.pipe(res);

  const leftX = doc.page.margins.left;
  const usableWidth = doc.page.width - doc.page.margins.left - doc.page.margins.right;
  const rightEdge = doc.page.width - doc.page.margins.right;

  // ---------- سربرگ: لوگو + نام و اطلاعات تماس شفاخانه ----------
  const headerTop = doc.y;
  if (logoPath) {
    try {
      doc.image(logoPath, leftX, headerTop, { width: 54, height: 54, fit: [54, 54] });
    } catch {
      // اگر فایل لوگو خراب/غیرقابل‌خواندن بود، بدون لوگو ادامه می‌دهیم — نباید کل PDF را بشکند
    }
  }
  doc.font("fa-bold").fontSize(18).fillColor("#1f2937")
    .text(shapeRtl(hospitalName), leftX, headerTop + 4, { width: usableWidth, align: "center" });
  if (contactLine) {
    doc.font("fa").fontSize(9).fillColor("#6b7280")
      .text(shapeRtl(contactLine), leftX, doc.y + 2, { width: usableWidth, align: "center" });
  }
  doc.fillColor("#000000");
  doc.moveDown(0.8);
  doc.moveTo(leftX, doc.y).lineTo(rightEdge, doc.y).strokeColor("#2f8f7e").lineWidth(1.5).stroke();
  doc.moveDown(0.9);

  doc.font("fa-bold").fontSize(14).text(shapeRtl("معلومات بیمار — Patient Information"), leftX, doc.y, { width: usableWidth, align: "center" });
  doc.moveDown(1.1);

  // ---------- اطلاعات اصلی (چیدمان دو ستونه، راست‌به‌چپ) ----------
  const labelWidth = 150;
  const gap = 8;
  const valueWidth = usableWidth - labelWidth - gap;
  const valueX = leftX;
  const labelX = valueX + valueWidth + gap;
  const isActive = patient.userIsActive === undefined || patient.userIsActive === null ? true : !!patient.userIsActive;

  function sectionTitle(title) {
    doc.moveDown(0.3);
    doc.font("fa-bold").fontSize(12).fillColor("#1f2937").text(shapeRtl(title), leftX, doc.y, { width: usableWidth, align: "right" });
    doc.fillColor("#000000");
    doc.moveDown(0.4);
  }

  function infoRow(label, value) {
    const y = doc.y;
    doc.font("fa-bold").fontSize(10).fillColor("#374151")
      .text(shapeRtl(`${label}:`), labelX, y, { width: labelWidth, align: "right" });
    doc.font("fa").fontSize(10).fillColor("#000000")
      .text(shapeRtl(value || "—"), valueX, y, { width: valueWidth, align: "right" });
    doc.moveDown(0.55);
  }

  sectionTitle("اطلاعات هویتی و تماس");
  infoRow("شناسه بیمار (ID)", `#${patient.id}`);
  infoRow("نام کامل", patient.fullName);
  infoRow("شماره تماس", patient.phone);
  infoRow("ایمیل", patient.email);
  infoRow("جنسیت", GENDER_LABEL[patient.gender] || patient.gender);
  infoRow("تاریخ تولد", fmtDate(patient.dateOfBirth));
  if (patient.bloodGroup) infoRow("گروه خونی", patient.bloodGroup);
  if (patient.address) infoRow("آدرس", patient.address);
  infoRow("وضعیت حساب کاربری", patient.userId ? (isActive ? "فعال" : "غیرفعال") : "بدون حساب کاربری (مهمان)");

  doc.moveDown(0.2);
  doc.moveTo(leftX, doc.y).lineTo(rightEdge, doc.y).strokeColor("#e5e7eb").lineWidth(1).stroke();

  sectionTitle("سوابق درمانی خلاصه");
  infoRow("داکتر مسئول (آخرین نوبت)", patient.assignedDoctorName);
  infoRow("تاریخ آخرین مراجعه", fmtDate(patient.lastVisitDate));
  infoRow("تعداد کل نوبت‌ها", patient.totalAppointments !== undefined ? String(patient.totalAppointments) : "—");
  if (patient.allergies) infoRow("حساسیت‌ها", patient.allergies);
  if (patient.drugAllergies) infoRow("حساسیت دارویی", patient.drugAllergies);
  if (patient.chronicDiseases) infoRow("بیماری‌های مزمن", patient.chronicDiseases);

  if (patient.emergencyContactName || patient.emergencyContactPhone) {
    doc.moveDown(0.2);
    doc.moveTo(leftX, doc.y).lineTo(rightEdge, doc.y).strokeColor("#e5e7eb").lineWidth(1).stroke();
    sectionTitle("تماس اضطراری");
    infoRow("نام", patient.emergencyContactName);
    infoRow("نسبت", patient.emergencyContactRelationship);
    infoRow("شماره تماس", patient.emergencyContactPhone);
  }

  infoRow("تاریخ ثبت پرونده", fmtDate(patient.createdAt));

  // ---------- پاورقی: اصالت سند ----------
  doc.font("fa").fontSize(8).fillColor("#9ca3af").text(
    shapeRtl(`این سند به‌صورت الکترونیکی از سامانه‌ی ${hospitalName} صادر شده است — تاریخ صدور PDF: ${fmtDate(new Date())}`),
    leftX,
    doc.page.height - doc.page.margins.bottom - 14,
    { width: usableWidth, align: "center" }
  );

  doc.end();
}

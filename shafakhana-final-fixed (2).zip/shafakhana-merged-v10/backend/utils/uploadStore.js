// ذخیره‌ی دائمی عکس‌های عمومی (داکتر، آیکون بخش، عکس خبر/گالری، پروفایل، لوگو) داخل دیتابیس.
//
// مشکل قبلی: عکس‌ها فقط به‌صورت فایل داخل backend/uploads ذخیره می‌شدند و دیتابیس فقط «مسیر»
// آن‌ها را نگه می‌داشت. با جایگزین/منتقل کردن پوشه‌ی پروژه (یا ساخت زیپ جدید) پوشه‌ی uploads
// خالی می‌شد و عکس‌ها از بین می‌رفتند، در حالی که مسیرشان در دیتابیس باقی می‌ماند.
//
// راه‌حل: بعد از هر آپلودِ موفق، محتوای خود عکس هم داخل جدول uploaded_files ذخیره می‌شود.
// - آدرس عکس‌ها (مثلاً /uploads/doctors/abc.jpg) هیچ تغییری نمی‌کند.
// - اگر فایل روی دیسک نبود، همین‌جا از دیتابیس خوانده و دوباره روی دیسک ساخته می‌شود.
// - هنگام شروع سرور، عکس‌های موجود روی دیسک که هنوز در دیتابیس نیستند به آن اضافه می‌شوند.
// - فقط وقتی ادمین عکس را حذف/جایگزین کند، از دیتابیس هم پاک می‌شود.
//
// نکته: هر عکس به تکه‌های ۲۵۶ کیلوبایتی (جدول uploaded_file_chunks) و داخل یک تراکنش ذخیره
// می‌شود تا حتی اگر max_allowed_packet در MySQL/XAMPP کوچک (مثلاً ۱ مگابایت) باشد، عکس‌های
// تا ۲ مگابایت بدون خطا ذخیره شوند و در صورت خطا هیچ ردیف ناقصی باقی نماند.

import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import db, { getPool } from "../db.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
export const UPLOADS_ROOT = path.join(__dirname, "..", "uploads");

// فقط پوشه‌های عمومی. فایل‌های خصوصی (private-uploads) عمداً شامل این سازوکار نیستند.
export const PUBLIC_UPLOAD_DIRS = ["avatars", "doctors", "logo", "news", "departments", "about", "hero"];

const CHUNK_SIZE = 256 * 1024;
const CACHE_SECONDS = 60 * 60 * 24 * 30; // نام فایل‌ها تصادفی و تغییرناپذیرند

const MIME_BY_EXT = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
};

const SAFE_FILENAME = /^[A-Za-z0-9][A-Za-z0-9._-]*$/;

// مسیر مطلق روی دیسک → کلید دیتابیس مثل «doctors/abc.jpg»؛ برای هر مسیر غیرعمومی null
export function uploadKeyFromPath(absPath) {
  if (typeof absPath !== "string" || !absPath) return null;
  const resolved = path.resolve(absPath);
  const dir = path.basename(path.dirname(resolved));
  const parent = path.dirname(path.dirname(resolved));
  const filename = path.basename(resolved);
  if (parent !== path.resolve(UPLOADS_ROOT)) return null;
  if (!PUBLIC_UPLOAD_DIRS.includes(dir)) return null;
  if (!SAFE_FILENAME.test(filename)) return null;
  return `${dir}/${filename}`;
}

function mimeFromKey(key) {
  return MIME_BY_EXT[path.extname(key).toLowerCase()] || "application/octet-stream";
}

// ---------------------------------------------------------------------------
// نوشتن
// ---------------------------------------------------------------------------

async function writeBuffer(key, buffer) {
  const pool = await getPool();
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    // ردیف قبلی (در صورت وجود) همراه با تکه‌هایش (ON DELETE CASCADE) پاک و از نو ساخته می‌شود
    await conn.execute("DELETE FROM uploaded_files WHERE path = ?", [key]);
    await conn.execute("INSERT INTO uploaded_files (path, mimeType, size) VALUES (?, ?, ?)", [
      key,
      mimeFromKey(key),
      buffer.length,
    ]);
    // execute (پروتکل باینری) داده را خام می‌فرستد؛ با query، بافر به رشته‌ی hex تبدیل و دو برابر می‌شد
    for (let offset = 0, seq = 0; offset < buffer.length; offset += CHUNK_SIZE, seq += 1) {
      await conn.execute("INSERT INTO uploaded_file_chunks (path, seq, data) VALUES (?, ?, ?)", [
        key,
        seq,
        buffer.subarray(offset, offset + CHUNK_SIZE),
      ]);
    }
    await conn.commit();
  } catch (err) {
    try {
      await conn.rollback();
    } catch {
      // اتصال ممکن است خودش قطع شده باشد؛ خطای اصلی مهم‌تر است
    }
    throw err;
  } finally {
    conn.release();
  }
}

// محتوای فایلِ روی دیسک را در دیتابیس ذخیره می‌کند. برای مسیرهای غیرعمومی چیزی انجام نمی‌دهد.
// خطا را پرتاب می‌کند تا آپلودکننده بتواند درخواست را رد کند (به‌جای اینکه بی‌صدا ذخیره نشود).
export async function persistUploadedFile(absPath) {
  const key = uploadKeyFromPath(absPath);
  if (!key) return false;
  const buffer = await fs.promises.readFile(absPath);
  await writeBuffer(key, buffer);
  return true;
}

// ---------------------------------------------------------------------------
// خواندن
// ---------------------------------------------------------------------------

async function readBuffer(key) {
  const pool = await getPool();
  const [rows] = await pool.query("SELECT mimeType, size FROM uploaded_files WHERE path = ?", [key]);
  if (rows.length === 0) return null;
  const [chunks] = await pool.query("SELECT data FROM uploaded_file_chunks WHERE path = ? ORDER BY seq", [key]);
  const buffer = Buffer.concat(chunks.map((c) => c.data));
  // اگر تعداد بایت‌ها با اندازه‌ی ثبت‌شده نمی‌خواند، داده ناقص است و نباید سرو شود
  if (buffer.length !== rows[0].size) return null;
  return { mimeType: rows[0].mimeType, buffer };
}

// میان‌افزار: اگر فایلِ /uploads/... روی دیسک نبود (express.static ردش کرد)، از دیتابیس
// برمی‌گرداند و همان لحظه روی دیسک هم بازسازی می‌کند. باید بعد از express.static ثبت شود.
export async function serveUploadFromDb(req, res, next) {
  if (req.method !== "GET" && req.method !== "HEAD") return next();
  const match = /^\/([A-Za-z0-9_-]+)\/([^/]+)$/.exec(req.path);
  if (!match) return next();
  const [, dir, filename] = match;
  if (!PUBLIC_UPLOAD_DIRS.includes(dir) || !SAFE_FILENAME.test(filename)) return next();

  try {
    const found = await readBuffer(`${dir}/${filename}`);
    if (!found || found.buffer.length === 0) return next();

    const target = path.join(UPLOADS_ROOT, dir, filename);
    try {
      await fs.promises.mkdir(path.dirname(target), { recursive: true });
      await fs.promises.writeFile(target, found.buffer);
    } catch (err) {
      // بازسازی روی دیسک اختیاری است؛ پاسخ در هر صورت از دیتابیس داده می‌شود
      console.warn("⚠️ بازسازی فایل آپلودی روی دیسک ناموفق بود:", err.message);
    }

    res.set({
      "Content-Type": found.mimeType,
      "Content-Length": String(found.buffer.length),
      "Cache-Control": `public, max-age=${CACHE_SECONDS}, immutable`,
    });
    return res.status(200).end(req.method === "HEAD" ? undefined : found.buffer);
  } catch (err) {
    console.error("خطا در خواندن عکس از دیتابیس:", err.message);
    return next();
  }
}

// ---------------------------------------------------------------------------
// حذف (فقط وقتی ادمین/کاربر عکس را حذف یا جایگزین می‌کند)
// ---------------------------------------------------------------------------

// جایگزین fs.unlink برای فایل‌های عمومی: هم از دیسک پاک می‌کند هم از دیتابیس.
// برای سازگاری با الگوی قبلی (fs.unlink(..., () => {})) هرگز خطا پرتاب نمی‌کند.
export function removeUploadedFile(absPath) {
  fs.unlink(absPath, () => {});
  const key = uploadKeyFromPath(absPath);
  if (!key) return;
  db.query("DELETE FROM uploaded_files WHERE path = ?", [key]).catch((err) => {
    console.warn("⚠️ حذف عکس از دیتابیس ناموفق بود:", err.message);
  });
}

// ---------------------------------------------------------------------------
// همگام‌سازی هنگام شروع سرور: عکس‌های موجود روی دیسک که هنوز در دیتابیس نیستند
// ---------------------------------------------------------------------------

export async function syncUploadsToDb() {
  const pool = await getPool();
  const [existing] = await pool.query("SELECT path FROM uploaded_files");
  const known = new Set(existing.map((r) => r.path));
  let added = 0;

  for (const dir of PUBLIC_UPLOAD_DIRS) {
    let names = [];
    try {
      names = await fs.promises.readdir(path.join(UPLOADS_ROOT, dir));
    } catch {
      continue;
    }
    for (const name of names) {
      const key = `${dir}/${name}`;
      if (known.has(key) || !SAFE_FILENAME.test(name)) continue;
      const full = path.join(UPLOADS_ROOT, dir, name);
      try {
        const stat = await fs.promises.stat(full);
        if (!stat.isFile()) continue;
        await writeBuffer(key, await fs.promises.readFile(full));
        added += 1;
      } catch (err) {
        console.warn(`⚠️ ذخیره‌ی ${key} در دیتابیس ناموفق بود:`, err.message);
      }
    }
  }

  if (added > 0) console.log(`🖼️ ${added} عکس آپلودشده‌ی موجود روی دیسک در دیتابیس هم ذخیره شد`);
  return added;
}

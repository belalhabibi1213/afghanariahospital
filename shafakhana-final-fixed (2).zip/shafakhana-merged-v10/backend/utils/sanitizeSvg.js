// پاک‌سازی محتوای فایل‌های SVG آپلودشده برای آیکون بخش‌ها (Department Management).
// برخلاف PNG/JPG که فایل باینری خالص است، SVG یک فایل متنی/XML است و می‌تواند حاوی
// <script>، event handler (مثل onload=)، یا لینک به منابع خارجی باشد؛ بنابراین علاوه بر
// بررسی امضای باینری (magic number در middleware/upload.js)، محتوای آن هم با همان کتابخانه‌ی
// sanitize-html که برای پاک‌سازی محتوای خبر استفاده شده (utils/sanitizeNewsContent.js) پاک‌سازی
// می‌شود تا از XSS ذخیره‌شده جلوگیری شود، حتی اگر فایل فقط با <img src> نمایش داده شود.
import sanitizeHtml from "sanitize-html";

// تگ‌های استاندارد SVG که برای یک آیکون ساده لازم است؛ تگ‌های خطرناک/غیرضروری
// (script, foreignObject, iframe, animate*, style) عمداً در فهرست نیستند
const ALLOWED_SVG_TAGS = [
  "svg", "g", "path", "circle", "ellipse", "rect", "line", "polyline", "polygon",
  "text", "tspan", "defs", "clipPath", "mask", "linearGradient", "radialGradient",
  "stop", "symbol", "title", "desc",
];

const COMMON_ATTRS = [
  "id", "class", "fill", "fill-rule", "fill-opacity", "stroke", "stroke-width",
  "stroke-linecap", "stroke-linejoin", "stroke-dasharray", "stroke-opacity",
  "opacity", "transform", "clip-path", "clip-rule", "mask",
];

const ALLOWED_SVG_ATTRIBUTES = {
  svg: [...COMMON_ATTRS, "xmlns", "viewBox", "width", "height", "version"],
  g: COMMON_ATTRS,
  path: [...COMMON_ATTRS, "d"],
  circle: [...COMMON_ATTRS, "cx", "cy", "r"],
  ellipse: [...COMMON_ATTRS, "cx", "cy", "rx", "ry"],
  rect: [...COMMON_ATTRS, "x", "y", "width", "height", "rx", "ry"],
  line: [...COMMON_ATTRS, "x1", "y1", "x2", "y2"],
  polyline: [...COMMON_ATTRS, "points"],
  polygon: [...COMMON_ATTRS, "points"],
  text: [...COMMON_ATTRS, "x", "y", "dx", "dy", "text-anchor", "font-size", "font-family"],
  tspan: [...COMMON_ATTRS, "x", "y", "dx", "dy"],
  clipPath: [...COMMON_ATTRS, "clipPathUnits"],
  mask: [...COMMON_ATTRS, "maskUnits"],
  linearGradient: [...COMMON_ATTRS, "x1", "y1", "x2", "y2", "gradientUnits", "gradientTransform"],
  radialGradient: [...COMMON_ATTRS, "cx", "cy", "r", "fx", "fy", "gradientUnits", "gradientTransform"],
  stop: [...COMMON_ATTRS, "offset", "stop-color", "stop-opacity"],
  symbol: [...COMMON_ATTRS, "viewBox"],
};

// بررسی سطحی این‌که آیا محتوای متنی واقعاً یک SVG است (شروع با اعلان xml اختیاری و بعد <svg)؛
// این یک بررسی مکمل امضای باینری در middleware/upload.js است (برای فرمت‌های متنی، magic number معنا ندارد)
export function looksLikeSvg(content) {
  const trimmed = String(content || "").replace(/^\uFEFF/, "").trim();
  return /^(<\?xml[^>]*\?>\s*)?(<!--[\s\S]*?-->\s*)*<svg[\s>]/i.test(trimmed);
}

// خروجی: نسخه‌ی پاک‌سازی‌شده‌ی SVG، یا null اگر محتوا اصلاً یک SVG معتبر نبود
export function sanitizeSvgContent(content) {
  if (!looksLikeSvg(content)) return null;
  return sanitizeHtml(content, {
    allowedTags: ALLOWED_SVG_TAGS,
    allowedAttributes: ALLOWED_SVG_ATTRIBUTES,
    allowedSchemes: [],
    parser: { xmlMode: true },
    // اسکریپت/استایل/تگ‌های ناشناخته کاملاً حذف می‌شوند (حتی متن داخلشان)، نه فقط باز شدن تگ
    disallowedTagsMode: "discard",
    nonTextTags: ["script", "style", "foreignObject", "iframe", "animate", "animateTransform"],
  }).trim();
}

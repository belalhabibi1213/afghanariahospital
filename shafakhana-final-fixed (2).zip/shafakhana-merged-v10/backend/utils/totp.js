import crypto from "crypto";
import { JWT_SECRET } from "./env.js";

// ---------- احراز هویت دومرحله‌ای (TOTP، استاندارد RFC 6238) ----------
// بدون وابستگی خارجی: فقط ماژول crypto خود Node. سازگار با Google Authenticator، Microsoft
// Authenticator، Authy، 1Password و ... (SHA-1، ۶ رقم، گام ۳۰ ثانیه).

const BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
const STEP_SECONDS = 30;
const DIGITS = 6;
// پنجره‌ی پذیرش: ۲ گام قبل/بعد = حدود ±۶۰ ثانیه تحمل اختلاف ساعت (دوره‌ی کد باید ۳۰ ثانیه بماند؛
// برنامه‌های Authenticator دوره‌ی دیگری را قبول نمی‌کنند). با MFA_WINDOW در .env قابل تغییر است.
const WINDOW = Math.min(Math.max(parseInt(process.env.MFA_WINDOW, 10) || 2, 0), 4);

export const MFA_ISSUER = process.env.MFA_ISSUER || "Shafakhana";

export function base32Encode(buf) {
  let bits = 0;
  let value = 0;
  let out = "";
  for (const byte of buf) {
    value = (value << 8) | byte;
    bits += 8;
    while (bits >= 5) {
      out += BASE32_ALPHABET[(value >>> (bits - 5)) & 31];
      bits -= 5;
    }
  }
  if (bits > 0) out += BASE32_ALPHABET[(value << (5 - bits)) & 31];
  return out;
}

export function base32Decode(str) {
  const clean = String(str || "").toUpperCase().replace(/=+$/, "").replace(/\s+/g, "");
  let bits = 0;
  let value = 0;
  const out = [];
  for (const ch of clean) {
    const idx = BASE32_ALPHABET.indexOf(ch);
    if (idx === -1) throw new Error("Base32 نامعتبر");
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      out.push((value >>> (bits - 8)) & 255);
      bits -= 8;
    }
  }
  return Buffer.from(out);
}

// راز ۱۶۰ بیتی (۲۰ بایت) — اندازه‌ی توصیه‌شده‌ی RFC 4226
export function generateTotpSecret() {
  return base32Encode(crypto.randomBytes(20));
}

function hotp(secretBuf, counter) {
  const msg = Buffer.alloc(8);
  msg.writeBigUInt64BE(BigInt(counter));
  const hmac = crypto.createHmac("sha1", secretBuf).update(msg).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const bin =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  return String(bin % 10 ** DIGITS).padStart(DIGITS, "0");
}

export function totpAt(secretBase32, timeMs = Date.now()) {
  return hotp(base32Decode(secretBase32), Math.floor(timeMs / 1000 / STEP_SECONDS));
}

// کد را در پنجره‌ی ±۱ گام بررسی می‌کند. شماره‌ی گامِ منطبق را برمی‌گرداند (برای جلوگیری از
// استفاده‌ی مجدد همان کد: replay) یا null اگر نامعتبر بود. مقایسه‌ها زمان‌ثابت‌اند.
export function verifyTotp(secretBase32, code, timeMs = Date.now()) {
  const candidate = String(code || "").replace(/\s+/g, "");
  if (!/^\d{6}$/.test(candidate)) return null;
  const secretBuf = base32Decode(secretBase32);
  const current = Math.floor(timeMs / 1000 / STEP_SECONDS);
  let matched = null;
  for (let w = -WINDOW; w <= WINDOW; w++) {
    const expected = hotp(secretBuf, current + w);
    if (crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(candidate))) matched = current + w;
  }
  return matched;
}

export function buildOtpauthUrl({ secret, email }) {
  const label = encodeURIComponent(`${MFA_ISSUER}:${email}`);
  const params = new URLSearchParams({ secret, issuer: MFA_ISSUER, algorithm: "SHA1", digits: String(DIGITS), period: String(STEP_SECONDS) });
  return `otpauth://totp/${label}?${params.toString()}`;
}

// ---------- رمزنگاری راز TOTP در دیتابیس (AES-256-GCM) ----------
// کلید از MFA_ENCRYPTION_KEY (پیشنهادی، جدا از JWT_SECRET) یا در غیاب آن از JWT_SECRET مشتق می‌شود.
// اگر JWT_SECRET را عوض کنید و MFA_ENCRYPTION_KEY تنظیم نکرده باشید، رازهای ذخیره‌شده قابل خواندن
// نخواهند بود؛ برای همین تنظیم MFA_ENCRYPTION_KEY در production توصیه می‌شود.
let cachedKey = null;
function encryptionKey() {
  if (cachedKey) return cachedKey;
  const ikm = process.env.MFA_ENCRYPTION_KEY || JWT_SECRET;
  cachedKey = Buffer.from(crypto.hkdfSync("sha256", ikm, "shafakhana-mfa-salt", "mfa-secret-v1", 32));
  return cachedKey;
}

export function encryptSecret(plain) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", encryptionKey(), iv);
  const ct = Buffer.concat([cipher.update(String(plain), "utf8"), cipher.final()]);
  return `v1:${iv.toString("base64")}:${cipher.getAuthTag().toString("base64")}:${ct.toString("base64")}`;
}

export function decryptSecret(stored) {
  const [version, iv, tag, ct] = String(stored || "").split(":");
  if (version !== "v1" || !iv || !tag || !ct) throw new Error("قالب راز MFA نامعتبر است");
  const decipher = crypto.createDecipheriv("aes-256-gcm", encryptionKey(), Buffer.from(iv, "base64"));
  decipher.setAuthTag(Buffer.from(tag, "base64"));
  return Buffer.concat([decipher.update(Buffer.from(ct, "base64")), decipher.final()]).toString("utf8");
}

// ---------- کدهای بازیابی (یک‌بارمصرف) ----------
const RECOVERY_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // بدون کاراکترهای مبهم
export const RECOVERY_CODE_COUNT = 8;

export function generateRecoveryCodes(count = RECOVERY_CODE_COUNT) {
  const pick = () => RECOVERY_ALPHABET[crypto.randomInt(RECOVERY_ALPHABET.length)];
  return Array.from({ length: count }, () => {
    const raw = Array.from({ length: 10 }, pick).join("");
    return `${raw.slice(0, 5)}-${raw.slice(5)}`;
  });
}

export function normalizeRecoveryCode(code) {
  return String(code || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

export function hashRecoveryCode(code) {
  return crypto.createHash("sha256").update(normalizeRecoveryCode(code)).digest("hex");
}

export function looksLikeRecoveryCode(code) {
  return normalizeRecoveryCode(code).length === 10 && !/^\d{6}$/.test(String(code || "").replace(/\s+/g, ""));
}

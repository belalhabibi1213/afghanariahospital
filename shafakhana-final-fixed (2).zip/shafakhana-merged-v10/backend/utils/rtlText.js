import pkg from "arabic-persian-reshaper";

const { PersianShaper } = pkg;

// حروف فارسی/عربی — هم فرم‌های اصلی و هم فرم‌های نمایشی (Presentation Forms) که خروجی PersianShaper است.
// (نسخه‌ی قبلی فقط محدوده‌ی اصلی را می‌شناخت و روی متن شکل‌داده‌شده کار نمی‌کرد.)
const PERSIAN_RANGE = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF\u200C\u200F]/;
const LATIN_OR_DIGIT = /[A-Za-z0-9]/;

// قوس‌ها و علائم لاتین که در متن راست‌به‌چپ باید جابه‌جا و آینه‌ای شوند
const MIRROR = { "(": ")", ")": "(", "[": "]", "]": "[", "{": "}", "}": "{", "<": ">", ">": "<", "«": "»", "»": "«" };
const mirrorChars = (s) => s.replace(/[()[\]{}<>«»]/g, (c) => MIRROR[c]);
const flip = (s) => mirrorChars(s.split("").reverse().join(""));

// تکه‌های «چپ‌به‌راست» داخل یک کلمه‌ی فارسی: عدد (لاتین/فارسی/عربی) و حروف لاتین، با جداکننده‌ی میانی
// مثل «۳.۵»، «۵۰۰mg» یا «۱/۲». fontkit کل کلمه‌ی دارای حروف فارسی را راست‌به‌چپ می‌چیند و این تکه‌ها
// را هم برعکس می‌کرد («۲۱» ← «۱۲»، «۵۰۰mg» ← «gm۰۰۵»).
const LTR_RUN = /[0-9\u06F0-\u06F9\u0660-\u0669A-Za-z]+(?:[.,/:\-][0-9\u06F0-\u06F9\u0660-\u0669A-Za-z]+)*/g;
const reverseStr = (s) => s.split("").reverse().join("");
// جهت چیدمان هر «کلمه» در fontkit را اولین نویسه‌ی «قوی» تعیین می‌کند: اگر عربی/فارسی (حتی رقم فارسی)
// باشد کل کلمه برعکس چیده می‌شود، اگر حرف لاتین باشد هیچ برعکسی انجام نمی‌شود (ارقام ۰-۹ بی‌طرف‌اند).
const STRONG_RTL = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
const STRONG_LTR = /[A-Za-z]/;
const firstStrongIsRtl = (str) => {
  for (const ch of str) {
    if (STRONG_RTL.test(ch)) return true;
    if (STRONG_LTR.test(ch)) return false;
  }
  return true;
};
const toAsciiDigits = (s) =>
  s.replace(/[\u06F0-\u06F9]/g, (c) => String(c.charCodeAt(0) - 0x06f0))
    .replace(/[\u0660-\u0669]/g, (c) => String(c.charCodeAt(0) - 0x0660));

// هر تکه‌ی چپ‌به‌راست (عدد/لاتین) را از پیش برعکس می‌کنیم تا برعکس‌شدنِ fontkit آن را به ترتیب درست
// برگرداند؛ ترتیب خودِ تکه‌ها و حروف فارسی دست نمی‌خورد (آن‌ها را fontkit درست می‌چیند).
// استثنا: اگر بعد از برعکس‌کردن اولین نویسه‌ی قوی لاتین شود (مثل «۵۰۰mg» ← «gm۰۰۵»)، fontkit دیگر برعکس
// نمی‌کند و خروجی غلط می‌شود؛ در این حالت تکه‌ها بدون برعکس‌کردن و با ارقام لاتین نوشته می‌شوند («500mg»).
const preReverseLtrRuns = (word) => {
  if (!LTR_RUN.test(word)) { LTR_RUN.lastIndex = 0; return word; }
  LTR_RUN.lastIndex = 0;
  const reversed = word.replace(LTR_RUN, reverseStr);
  if (firstStrongIsRtl(reversed)) return reversed;
  return word.replace(LTR_RUN, toAsciiDigits);
};

const LEADING = /^[()[\]{}<>«»:;,.!?]+/;
const TRAILING = /[()[\]{}<>«»:;,.!?]+$/;

// pdfkit فقط چپ‌به‌راست رسم می‌کند؛ حروف هر «کلمه‌ی فارسی» را خودِ pdfkit/fontkit درست (راست‌به‌چپ)
// می‌چیند، پس اینجا فقط باید:
//  ۱) حروف را شکل بدهیم (چسبیدن حروف)،
//  ۲) ترتیب «کلمه‌ها/گروه‌ها» را برعکس کنیم،
//  ۳) گروه‌های انگلیسی/عددی را با ترتیب اصلی نگه داریم (مثل «Doctor Name»)،
//  ۴) قوس و علائم کنار هر کلمه/گروه را به سمت درست ببریم و آینه کنیم: «(Doctor Name):»
// نکته: حروف داخل کلمه‌ی فارسی هرگز دستی برعکس نمی‌شوند (باعث شکسته‌شدن حروف می‌شد).
export function shapeRtl(text) {
  const str = String(text ?? "");
  if (!PERSIAN_RANGE.test(str)) return str;
  const words = PersianShaper.convertArabic(str).split(" ");

  // نوع هر کلمه: P فارسی، L لاتین/عدد، N فقط علامت (مثل «—»)
  const types = words.map((w) => (PERSIAN_RANGE.test(w) ? "P" : LATIN_OR_DIGIT.test(w) ? "L" : "N"));
  for (let i = 0; i < words.length; i++) {
    if (types[i] !== "N") continue;
    let prev = i - 1;
    while (prev >= 0 && types[prev] === "N") prev--;
    let next = i + 1;
    while (next < words.length && types[next] === "N") next++;
    types[i] = prev >= 0 && next < words.length && types[prev] === "L" && types[next] === "L" ? "L" : "P";
  }

  // جابه‌جایی علائم اطراف یک تکه: علائم ابتدا به سمت راست و علائم انتها به سمت چپ می‌روند (با قوس آینه‌ای)
  const wrap = (chunk) => {
    const lead = (chunk.match(LEADING) || [""])[0];
    const rest = chunk.slice(lead.length);
    const trail = (rest.match(TRAILING) || [""])[0];
    const core = rest.slice(0, rest.length - trail.length);
    if (!core) return chunk;
    return flip(trail) + core + flip(lead);
  };

  const segments = [];
  const kinds = [];
  let i = 0;
  while (i < words.length) {
    if (types[i] === "L") {
      let j = i;
      while (j < words.length && types[j] === "L") j++;
      segments.push(wrap(words.slice(i, j).join(" ")));
      kinds.push("L");
      i = j;
    } else {
      // کلمه‌ی فارسی: خودِ fontkit ترتیب نویسه‌ها (و علائم چسبیده) را برعکس می‌کند ولی قوس را آینه نمی‌کند
      segments.push(types[i] === "P" ? preReverseLtrRuns(mirrorChars(words[i])) : words[i]);
      kinds.push(types[i]);
      i++;
    }
  }
  // fontkit فاصله‌ی بعد از یک کلمه‌ی فارسی را اگر بعدش گروه لاتین بیاید (و در انتهای رشته) می‌بلعد؛
  // در این موارد یک فاصله‌ی اضافه می‌گذاریم تا «نام داکتر (Doctor Name):» فشرده نشود.
  segments.reverse();
  kinds.reverse();
  let out = "";
  for (let k = 0; k < segments.length; k++) {
    out += segments[k];
    if (k < segments.length - 1) out += kinds[k] === "P" && kinds[k + 1] === "L" ? "  " : " ";
    else if (kinds[k] === "P") out += " ";
  }
  return out;
}

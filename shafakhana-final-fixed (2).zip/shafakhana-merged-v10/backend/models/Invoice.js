import db, { getPool } from "../db.js";
import { round2 } from "../utils/money.js";

// وضعیت فاکتور بر اساس مبلغ پرداخت‌شده نسبت به مبلغ کل محاسبه می‌شود؛
// 'cancelled' فقط با لغو صریح ادمین تنظیم می‌شود (نه به‌صورت خودکار)
export function computeStatus(totalAmount, paidAmount) {
  if (paidAmount <= 0) return "unpaid";
  if (paidAmount < totalAmount) return "partial";
  return "paid";
}

const SELECT_INVOICE = `
  SELECT i.*, p.fullName AS patientName, p.phone AS patientPhone, p.email AS patientEmail,
         d.fullName AS doctorName, d.department AS department,
         u.fullName AS createdByName,
         a.fullName AS approvedByName
  FROM invoices i
  JOIN patients p ON i.patientId = p.id
  LEFT JOIN doctors d ON i.doctorId = d.id
  LEFT JOIN users u ON i.createdByUserId = u.id
  LEFT JOIN users a ON i.approvedByUserId = a.id
`;

// شماره‌ی فاکتور بر اساس شناسه‌ی خودِ رکورد ساخته می‌شود (یکتا و بدون نیاز به شمارنده‌ی جدا)
function buildInvoiceNumber(id) {
  return `INV-${String(id).padStart(6, "0")}`;
}

// ثبت یک فاکتور جدید همراه با ردیف‌های آن، در یک تراکنش دیتابیسی (الزام شماره ۱: صدور فاکتور)
export async function createInvoice({ patientId, doctorId, appointmentId, issueDate, dueDate, discount, tax, notes, items, createdByUserId }) {
  const pool = await getPool();
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const subtotal = round2(items.reduce((sum, it) => sum + Number(it.quantity) * Number(it.unitPrice), 0));
    const safeDiscount = round2(discount || 0);
    const safeTax = round2(tax || 0);
    const totalAmount = Math.max(0, round2(subtotal - safeDiscount + safeTax));

    const [result] = await conn.query(
      `INSERT INTO invoices
         (invoiceNumber, patientId, doctorId, appointmentId, issueDate, dueDate, subtotal, discount, tax, totalAmount, paidAmount, status, notes, createdByUserId)
       VALUES ('', ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'unpaid', ?, ?)`,
      [patientId, doctorId || null, appointmentId || null, issueDate, dueDate || null, subtotal, safeDiscount, safeTax, totalAmount, notes || null, createdByUserId || null]
    );
    const invoiceId = result.insertId;
    await conn.query("UPDATE invoices SET invoiceNumber = ? WHERE id = ?", [buildInvoiceNumber(invoiceId), invoiceId]);

    for (const it of items) {
      const amount = round2(Number(it.quantity) * Number(it.unitPrice));
      await conn.query(
        "INSERT INTO invoice_items (invoiceId, description, quantity, unitPrice, amount) VALUES (?, ?, ?, ?, ?)",
        [invoiceId, it.description, it.quantity, it.unitPrice, amount]
      );
    }

    await conn.commit();
    return getInvoiceById(invoiceId);
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

export async function getInvoiceById(id) {
  const [rows] = await db.query(SELECT_INVOICE + " WHERE i.id = ?", [id]);
  if (!rows[0]) return null;
  const [items] = await db.query("SELECT * FROM invoice_items WHERE invoiceId = ? ORDER BY id ASC", [id]);
  const [payments] = await db.query(
    `SELECT pay.*, u.fullName AS receivedByName FROM payments pay
     LEFT JOIN users u ON pay.receivedByUserId = u.id
     WHERE pay.invoiceId = ? ORDER BY pay.paidAt ASC, pay.id ASC`,
    [id]
  );
  return { ...rows[0], items, payments };
}

// فهرست فاکتورها برای پنل ادمین/کارمند بخش صورت‌حساب (الزام شماره ۵: مشاهده‌ی سوابق صورت‌حساب)
// همراه با فیلتر بر اساس بیمار/وضعیت/بازه‌ی تاریخ و صفحه‌بندی
export async function searchInvoices({ patientId, doctorId, status, from, to, q, page = 1, limit = 20 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
  const offset = (safePage - 1) * safeLimit;

  const conditions = [];
  const params = [];
  if (patientId) {
    conditions.push("i.patientId = ?");
    params.push(patientId);
  }
  // فیلتر داکتر مرتبط با فاکتور (invoices.doctorId) — فقط فاکتورهایی که برای این
  // داکتر صادر شده‌اند (اختیاری، چون doctorId می‌تواند NULL باشد)
  const doctorIdNum = parseInt(doctorId, 10);
  if (Number.isInteger(doctorIdNum) && doctorIdNum > 0) {
    conditions.push("i.doctorId = ?");
    params.push(doctorIdNum);
  }
  // فیلتر بر اساس وضعیت یکپارچه (الزام «حذف ستون‌های تکراری وضعیت»): همان سه مقدار
  // نمایش داده‌شده در ستون واحد «وضعیت» — pending / approved / cancelled — نه دیگر
  // مقادیر داخلی وضعیت پرداخت (unpaid/partial/paid)
  if (status === "cancelled") {
    conditions.push("i.status = 'cancelled'");
  } else if (status === "approved") {
    conditions.push("i.approvalStatus = 'approved' AND i.status != 'cancelled'");
  } else if (status === "pending") {
    conditions.push("i.approvalStatus = 'pending' AND i.status != 'cancelled'");
  }
  if (from) {
    conditions.push("i.issueDate >= ?");
    params.push(from);
  }
  if (to) {
    conditions.push("i.issueDate <= ?");
    params.push(to);
  }
  // جستجوی متنی بر اساس شماره فاکتور، نام بیمار یا تاریخ صدور
  if (q && q.trim()) {
    const like = `%${q.trim()}%`;
    conditions.push("(i.invoiceNumber LIKE ? OR p.fullName LIKE ? OR CAST(i.issueDate AS CHAR) LIKE ?)");
    params.push(like, like, like);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `${SELECT_INVOICE} ${where} ORDER BY i.createdAt ASC, i.id ASC LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );
  const [countRows] = await db.query(`SELECT COUNT(*) AS count FROM invoices i ${where}`, params);

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

// سوابق صورت‌حساب یک بیمار مشخص (برای نمایش در پرونده‌ی بیمار در پنل ادمین)
export async function getInvoicesByPatientId(patientId) {
  const [rows] = await db.query(`${SELECT_INVOICE} WHERE i.patientId = ? ORDER BY i.createdAt ASC, i.id ASC`, [patientId]);
  return rows;
}

// سوابق صورت‌حساب خودِ بیمار واردشده (پنل کاربر — الزام شماره ۵)
export async function getInvoicesByPatientUser(userId) {
  const [rows] = await db.query(
    `${SELECT_INVOICE} JOIN patients pu ON pu.id = i.patientId WHERE pu.userId = ? ORDER BY i.createdAt ASC, i.id ASC`,
    [userId]
  );
  return rows;
}

// آیا این فاکتور متعلق به کاربر واردشده است؟ (برای بررسی مالکیت قبل از نمایش جزئیات/چاپ)
export async function isInvoiceOwnedByUser(invoiceId, userId) {
  const [rows] = await db.query(
    `SELECT i.id FROM invoices i JOIN patients p ON p.id = i.patientId WHERE i.id = ? AND p.userId = ?`,
    [invoiceId, userId]
  );
  return rows.length > 0;
}

// ---------- سوابق صورت‌حساب بیمارانِ خودِ داکتر (پنل داکتر) ----------
// یک فاکتور به داکتر تعلق دارد اگر: خودش doctorId فاکتور باشد، یا بیمار آن فاکتور
// حداقل یک نوبت با همین داکتر داشته باشد (همان تعریف «بیماران من» که در
// searchDoctorPatients/models/Patient.js استفاده شده — RBAC: هر داکتر فقط فاکتورهای
// بیماران خودش را می‌بیند، نه همه‌ی فاکتورهای شفاخانه).
export async function getInvoicesByDoctorId(doctorId) {
  const [rows] = await db.query(
    `${SELECT_INVOICE}
     WHERE i.doctorId = ?
        OR EXISTS (SELECT 1 FROM appointments a WHERE a.patientId = i.patientId AND a.doctorId = ?)
     ORDER BY i.createdAt ASC, i.id ASC`,
    [doctorId, doctorId]
  );
  return rows;
}

// آیا این فاکتور به یکی از بیماران خودِ این داکتر تعلق دارد؟ (برای بررسی مالکیت قبل از نمایش جزئیات/چاپ)
export async function isInvoiceAccessibleByDoctor(invoiceId, doctorId) {
  const [rows] = await db.query(
    `SELECT i.id FROM invoices i
     WHERE i.id = ?
       AND (
         i.doctorId = ?
         OR EXISTS (SELECT 1 FROM appointments a WHERE a.patientId = i.patientId AND a.doctorId = ?)
       )`,
    [invoiceId, doctorId, doctorId]
  );
  return rows.length > 0;
}

// لغو یک فاکتور (فقط وقتی هیچ پرداختی روی آن ثبت نشده باشد — تا سابقه‌ی مالی مخدوش نشود)
export async function cancelInvoice(id) {
  await db.query("UPDATE invoices SET status = 'cancelled' WHERE id = ?", [id]);
  return getInvoiceById(id);
}

// ---------- تایید فاکتور (Invoice Approval Workflow) ----------
// وضعیت تایید، زمان تایید و ادمینی که تایید کرده را ثبت می‌کند (فقط admin/superadmin —
// RBAC روی سطح روتر در routes/billing.js اعمال شده است). هم‌زمان با تایید، طبق الزام
// «Payment Update After Approval»، مبلغ پرداخت‌شده به‌صورت خودکار برابر مبلغ کل فاکتور
// تنظیم می‌شود و وضعیت پرداخت (status) با همان computeStatus موجود («paid») هماهنگ
// می‌ماند — همه در یک تراکنش با قفل ردیف (FOR UPDATE) تا با ثبت هم‌زمان یک پرداخت
// دستی تداخل نکند.
export async function approveInvoice(id, approvedByUserId) {
  const pool = await getPool();
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query("SELECT totalAmount, paidAmount FROM invoices WHERE id = ? FOR UPDATE", [id]);
    if (!rows[0]) {
      await conn.rollback();
      return null;
    }
    const totalAmount = Number(rows[0].totalAmount);
    const alreadyPaid = Number(rows[0].paidAmount) || 0;
    const newStatus = computeStatus(totalAmount, totalAmount); // = 'paid'
    // «گزارش درآمد» درآمد را از جدول payments می‌خواند، نه از invoices.paidAmount؛ پس باقی‌مانده‌ی
    // مبلغ فاکتور که با تایید به‌صورت خودکار پرداخت‌شده حساب می‌شود باید یک ردیف پرداخت هم داشته
    // باشد، وگرنه فاکتور تاییدشده در گزارش درآمد دیده نمی‌شود («برای این فیلتر نتیجه‌ای پیدا نشد»).
    const autoPaid = round2(totalAmount - alreadyPaid);
    if (autoPaid > 0) {
      await conn.query(
        `INSERT INTO payments (invoiceId, amount, method, paidAt, reference, notes, receivedByUserId)
         VALUES (?, ?, 'cash', NOW(), NULL, ?, ?)`,
        [id, autoPaid, "ثبت خودکار هنگام تایید فاکتور", approvedByUserId || null]
      );
    }
    await conn.query(
      `UPDATE invoices
       SET approvalStatus = 'approved', approvedByUserId = ?, approvedAt = NOW(),
           paidAmount = ?, status = ?
       WHERE id = ?`,
      [approvedByUserId, totalAmount, newStatus, id]
    );
    await conn.commit();
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
  return getInvoiceById(id);
}

// ---------- حذف کامل فاکتور (Delete Synchronization) ----------
// حذف امنِ یک فاکتور و تمام رکوردهای وابسته‌ی آن در یک تراکنش دیتابیسی، بدون باقی
// ماندن رکورد یتیم: ردیف‌های فاکتور (invoice_items) و پرداخت‌ها (payments) به‌خاطر
// ON DELETE CASCADE موجود روی این دو جدول به‌صورت خودکار حذف می‌شوند؛ اعلان‌های
// مرتبط (notifications با type='billing' و relatedId=فاکتور) جداگانه حذف می‌شوند
// چون آن جدول محدودیت کلید خارجی به invoices ندارد. حذف از هر سه پنل (ادمین/داکتر/
// بیمار) نتیجه‌ی همین حذف واحد از دیتابیس است، چون هر سه پنل فهرست فاکتورها را از
// همین جدول می‌خوانند.
export async function deleteInvoiceCascade(id) {
  const pool = await getPool();
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [rows] = await conn.query("SELECT id FROM invoices WHERE id = ? FOR UPDATE", [id]);
    if (!rows[0]) {
      await conn.rollback();
      return false;
    }
    await conn.query("DELETE FROM notifications WHERE type = 'billing' AND relatedId = ?", [id]);
    await conn.query("DELETE FROM invoices WHERE id = ?", [id]); // invoice_items و payments با CASCADE حذف می‌شوند
    await conn.commit();
    return true;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

import db from "../db.js";

// تصاویر پزشکی و اسناد متصل به یک پرونده صحی (ویزیت). فایل واقعی در پوشه‌ی خصوصی است؛ اینجا فقط متادیتا.
export async function createFile({
  recordId, patientId, doctorId, kind, category, title, fileDate, description, originalName, storedName, mimeType, sizeBytes,
}) {
  const [result] = await db.query(
    `INSERT INTO medical_record_files
       (recordId, patientId, doctorId, kind, category, title, fileDate, description, originalName, storedName, mimeType, sizeBytes)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [recordId, patientId, doctorId || null, kind, category || "other", title, fileDate || null, description || null,
      originalName, storedName, mimeType, sizeBytes || 0]
  );
  return getFileById(result.insertId);
}

export async function getFileById(id) {
  const [rows] = await db.query("SELECT * FROM medical_record_files WHERE id = ?", [id]);
  return rows[0] || null;
}

// storedName عمداً به کلاینت برگردانده نمی‌شود (نام تصادفی داخلی دیسک)
const PUBLIC_COLUMNS = "id, recordId, patientId, kind, category, title, DATE_FORMAT(fileDate, '%Y-%m-%d') AS fileDate, description, originalName, mimeType, sizeBytes, createdAt";

export async function getFilesByRecordId(recordId) {
  const [rows] = await db.query(
    `SELECT ${PUBLIC_COLUMNS} FROM medical_record_files WHERE recordId = ? ORDER BY id ASC`,
    [recordId]
  );
  return rows;
}

export async function countFilesByRecordId(recordId) {
  const [[row]] = await db.query("SELECT COUNT(*) AS c FROM medical_record_files WHERE recordId = ?", [recordId]);
  return Number(row.c) || 0;
}

export async function getStoredNamesByRecordId(recordId) {
  const [rows] = await db.query("SELECT storedName FROM medical_record_files WHERE recordId = ?", [recordId]);
  return rows.map((r) => r.storedName);
}

export async function deleteFile(id) {
  await db.query("DELETE FROM medical_record_files WHERE id = ?", [id]);
}

// فایل برای بیمار: فقط فایل خودش، فقط وقتی پرونده «ثبت‌شده» و «به بیمار ارسال‌شده» است
export async function getReleasedFileForPatientUser(id, userId) {
  const [rows] = await db.query(
    `SELECT f.* FROM medical_record_files f
     JOIN medical_records m ON f.recordId = m.id
     JOIN patients p ON f.patientId = p.id
     WHERE f.id = ? AND p.userId = ? AND m.status <> 'draft' AND m.sentToPatientAt IS NOT NULL`,
    [id, userId]
  );
  return rows[0] || null;
}

export async function getReleasedFilesByRecordId(recordId) {
  const [rows] = await db.query(
    `SELECT ${PUBLIC_COLUMNS} FROM medical_record_files WHERE recordId = ? ORDER BY id ASC`,
    [recordId]
  );
  return rows;
}

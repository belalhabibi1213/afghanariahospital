import db from "../db.js";

// حداکثر تعداد ردیف در خروجی هر گزارش (هم نمایش در صفحه و هم خروجی PDF/Excel) —
// از فشار بیش از حد روی سرور در دیتاست‌های خیلی بزرگ جلوگیری می‌کند
const MAX_ROWS = 3000;

function dateConditions(column, from, to, params, conditions) {
  if (from) {
    conditions.push(`${column} >= ?`);
    params.push(from);
  }
  if (to) {
    conditions.push(`${column} <= ?`);
    params.push(to);
  }
}

// نسخه‌ی مخصوص ستون‌های TIMESTAMP (createdAt/paidAt که ساعت هم دارند، نه فقط تاریخ):
// با DATE() کل روزِ «تا تاریخ» را شامل می‌شود، وگرنه رکوردهای بعد از نیمه‌شب همان روز
// به‌اشتباه از گزارش حذف می‌شدند
function dateOnlyConditions(column, from, to, params, conditions) {
  if (from) {
    conditions.push(`DATE(${column}) >= ?`);
    params.push(from);
  }
  if (to) {
    conditions.push(`DATE(${column}) <= ?`);
    params.push(to);
  }
}

// ---------- گزارش نوبت‌ها (الزام شماره ۱) ----------
// فیلتر بر اساس بازه‌ی تاریخ نوبت (appointmentDate)، وضعیت، داکتر و بخش
export async function getAppointmentReport({ from, to, status, doctorId, department } = {}) {
  const conditions = [];
  const params = [];
  dateConditions("a.appointmentDate", from, to, params, conditions);
  if (status) {
    conditions.push("a.status = ?");
    params.push(status);
  }
  if (doctorId) {
    conditions.push("a.doctorId = ?");
    params.push(doctorId);
  }
  if (department) {
    conditions.push("a.department = ?");
    params.push(department);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT a.id, a.appointmentDate, a.appointmentTime, a.status, a.department,
            p.fullName AS patientName, p.phone AS patientPhone,
            d.fullName AS doctorName
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     ${where}
     ORDER BY a.appointmentDate DESC, a.appointmentTime DESC
     LIMIT ${MAX_ROWS}`,
    params
  );

  const [byStatus] = await db.query(
    `SELECT a.status, COUNT(*) AS count
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     ${where}
     GROUP BY a.status`,
    params
  );

  const [byDepartment] = await db.query(
    `SELECT a.department, COUNT(*) AS count
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     ${where}
     GROUP BY a.department
     ORDER BY count DESC`,
    params
  );

  return {
    summary: { total: rows.length >= MAX_ROWS ? null : rows.length, byStatus, byDepartment },
    rows,
  };
}

// ---------- گزارش بیماران (الزام شماره ۲) ----------
// خلاصه‌ی کل بیماران + بیماران تازه‌ثبت‌شده در بازه، همراه با تعداد نوبت‌های هر بیمار
export async function getPatientReport({ from, to } = {}) {
  const conditions = [];
  const params = [];
  dateOnlyConditions("p.createdAt", from, to, params, conditions);
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT p.id, p.fullName, p.phone, p.email, p.createdAt,
            COUNT(a.id) AS appointmentCount,
            MAX(a.appointmentDate) AS lastAppointmentDate
     FROM patients p
     LEFT JOIN appointments a ON a.patientId = p.id
     ${where}
     GROUP BY p.id, p.fullName, p.phone, p.email, p.createdAt
     ORDER BY p.createdAt ASC, p.id ASC
     LIMIT ${MAX_ROWS}`,
    params
  );

  const [[{ totalPatients }]] = await db.query("SELECT COUNT(*) AS totalPatients FROM patients");
  const [[{ newPatients }]] = await db.query(
    `SELECT COUNT(*) AS newPatients FROM patients p ${where}`,
    params
  );

  return {
    summary: { totalPatients, newPatientsInRange: newPatients },
    rows,
  };
}

// ---------- گزارش داکتران (الزام شماره ۳) ----------
// عملکرد هر داکتر در بازه‌ی انتخاب‌شده: تعداد نوبت‌ها (به تفکیک وضعیت) + درآمد حاصل از فاکتورهای مرتبط
export async function getDoctorReport({ from, to } = {}) {
  const apptConditions = [];
  const apptParams = [];
  dateConditions("a.appointmentDate", from, to, apptParams, apptConditions);
  const apptWhere = apptConditions.length ? `AND ${apptConditions.join(" AND ")}` : "";

  const invConditions = [];
  const invParams = [];
  dateConditions("i.issueDate", from, to, invParams, invConditions);
  const invWhere = invConditions.length ? `AND ${invConditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT d.id, d.fullName, d.department,
            COUNT(DISTINCT a.id) AS totalAppointments,
            SUM(CASE WHEN a.status = 'completed' THEN 1 ELSE 0 END) AS completedAppointments,
            SUM(CASE WHEN a.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelledAppointments,
            SUM(CASE WHEN a.status = 'confirmed' THEN 1 ELSE 0 END) AS confirmedAppointments,
            SUM(CASE WHEN a.status = 'pending' THEN 1 ELSE 0 END) AS pendingAppointments,
            COALESCE((
              SELECT SUM(i.totalAmount) FROM invoices i
              WHERE i.doctorId = d.id AND i.status != 'cancelled' ${invWhere}
            ), 0) AS revenue,
            COALESCE((
              SELECT SUM(i.paidAmount) FROM invoices i
              WHERE i.doctorId = d.id AND i.status != 'cancelled' ${invWhere}
            ), 0) AS collectedRevenue
     FROM doctors d
     LEFT JOIN appointments a ON a.doctorId = d.id ${apptWhere}
     GROUP BY d.id, d.fullName, d.department
     ORDER BY totalAppointments DESC
     LIMIT ${MAX_ROWS}`,
    [...apptParams, ...invParams, ...invParams]
  );

  const summary = rows.reduce(
    (acc, r) => ({
      totalAppointments: acc.totalAppointments + Number(r.totalAppointments),
      totalRevenue: acc.totalRevenue + Number(r.revenue),
      totalCollected: acc.totalCollected + Number(r.collectedRevenue),
    }),
    { totalAppointments: 0, totalRevenue: 0, totalCollected: 0 }
  );

  return { summary, rows };
}

// ---------- گزارش درآمد (الزام شماره ۴) ----------
// درآمد واقعاً وصول‌شده (بر اساس پرداخت‌های ثبت‌شده در بازه) + خلاصه‌ی وضعیت فاکتورها
export async function getRevenueReport({ from, to } = {}) {
  const payConditions = [];
  const payParams = [];
  dateOnlyConditions("pay.paidAt", from, to, payParams, payConditions);
  const payWhere = payConditions.length ? `WHERE ${payConditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT pay.id, pay.amount, pay.method, pay.paidAt, pay.reference,
            i.invoiceNumber, i.status AS invoiceStatus,
            p.fullName AS patientName
     FROM payments pay
     JOIN invoices i ON pay.invoiceId = i.id
     JOIN patients p ON i.patientId = p.id
     ${payWhere}
     ORDER BY i.id ASC, pay.paidAt ASC, pay.id ASC
     LIMIT ${MAX_ROWS}`,
    payParams
  );

  const [[{ totalCollected }]] = await db.query(
    `SELECT COALESCE(SUM(pay.amount), 0) AS totalCollected FROM payments pay ${payWhere}`,
    payParams
  );

  const [byMethod] = await db.query(
    `SELECT pay.method, COALESCE(SUM(pay.amount), 0) AS total, COUNT(*) AS count
     FROM payments pay
     ${payWhere}
     GROUP BY pay.method
     ORDER BY total DESC`,
    payParams
  );

  const invConditions = [];
  const invParams = [];
  dateConditions("i.issueDate", from, to, invParams, invConditions);
  const invWhere = invConditions.length ? `WHERE ${invConditions.join(" AND ")}` : "";

  const [invoicesByStatus] = await db.query(
    `SELECT i.status, COUNT(*) AS count, COALESCE(SUM(i.totalAmount), 0) AS totalAmount
     FROM invoices i
     ${invWhere}
     GROUP BY i.status`,
    invParams
  );

  const [[{ totalOutstanding }]] = await db.query(
    `SELECT COALESCE(SUM(i.totalAmount - i.paidAmount), 0) AS totalOutstanding
     FROM invoices i
     WHERE i.status IN ('unpaid', 'partial')`
  );

  return {
    summary: { totalCollected, totalOutstanding, byMethod, invoicesByStatus },
    rows,
  };
}

import db, { getPool } from "../db.js";
import { withTxRetry } from "../utils/dbRetry.js";

// آیا این بیمار (بر اساس patientId یا حساب کاربری userId) همین الان یک نوبت فعال
// (pending/confirmed) برای همان داکتر + همان تاریخ + همان ساعت دارد؟
// ظرفیت ساعت (مثلاً ۱۰ بیمار) برای «بیماران مختلف» است؛ یک بیمار نباید بتواند چند بار
// همان ساعت را از همان داکتر بگیرد. نوبت‌های لغوشده/تکمیل‌شده/ردشده مانع نیستند.
// conn اختیاری است تا همین بررسی داخل تراکنشِ createAppointment هم اجرا شود.
export async function hasActiveAppointmentForPatientSlot({ patientId, userId, doctorId, appointmentDate, appointmentTime }, conn = db) {
  const [rows] = await conn.query(
    `SELECT a.id FROM appointments a
     JOIN patients p ON a.patientId = p.id
     WHERE a.doctorId = ? AND a.appointmentDate = ? AND a.appointmentTime = ?
       AND a.status IN ('pending', 'confirmed')
       AND (a.patientId <=> ? OR (? IS NOT NULL AND p.userId = ?))
     LIMIT 1`,
    [doctorId, appointmentDate, appointmentTime, patientId ?? null, userId ?? null, userId ?? null]
  );
  return rows.length > 0;
}

// status اختیاری است و فقط زمانی استفاده می‌شود که تنظیمات سیستم «تایید خودکار نوبت‌ها»
// را فعال کرده باشند؛ در غیر این‌صورت مقدار پیش‌فرض ستون ('pending') در دیتابیس اعمال می‌شود
// تا رفتار قبلی سیستم برای نصب‌های موجود بدون تغییر باقی بماند.
//
// capacity (اختیاری): اگر داده شود، ثبت نوبت داخل یک تراکنش دیتابیسی با قفل ردیف انجام
// می‌شود تا تعداد نوبت‌های فعال (pending/confirmed) همان (داکتر + تاریخ + ساعت) از این عدد
// بیشتر نشود — یعنی مثلاً اگر ظرفیت ۱۰ باشد، دقیقاً تا ۱۰ بیمار می‌توانند همان ساعت را
// رزرو کنند، نه بیشتر. این قفل (SELECT ... FOR UPDATE) به‌لطف ایندکس ترکیبی
// idx_appointments_doctor_date_time، حتی وقتی صفر ردیف برای آن ساعت موجود باشد، یک
// gap lock روی همان بازه می‌گیرد؛ یعنی چند درخواست کاملاً هم‌زمان برای همان ساعت به‌صورت
// صف‌شده (نه واقعاً موازی) پردازش می‌شوند و امکان رد شدن هم‌زمان همه از چک ظرفیت و ثبت
// بیش از حد مجاز وجود ندارد (محافظت واقعی در برابر Race Condition، نه فقط بررسی سطحی
// پیش از درخواست). اگر capacity داده نشود، رفتار قبلی (فقط INSERT ساده) حفظ می‌شود.
export async function createAppointment({ patientId, doctorId, department, appointmentDate, appointmentTime, notes, status, capacity, userId }) {
  if (capacity === undefined) {
    const [result] = await db.query(
      status
        ? `INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, notes, status)
           VALUES (?, ?, ?, ?, ?, ?, ?)`
        : `INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, notes)
           VALUES (?, ?, ?, ?, ?, ?)`,
      status
        ? [patientId, doctorId, department, appointmentDate, appointmentTime, notes || null, status]
        : [patientId, doctorId, department, appointmentDate, appointmentTime, notes || null]
    );
    return { id: result.insertId };
  }

  // کل تراکنش داخل withTxRetry اجرا می‌شود: اگر دیتابیس به‌خاطر بن‌بست (Deadlock) آن را قربانی کند،
  // با تأخیر تصادفی کوتاه تا چند بار دوباره تلاش می‌شود (نتیجه‌ی نهایی همان SLOT_FULL/ثبت موفق است).
  return withTxRetry(async () => {
    const pool = await getPool();
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();

      const [rows] = await conn.query(
        `SELECT id FROM appointments
         WHERE doctorId = ? AND appointmentDate = ? AND appointmentTime = ? AND status IN ('pending', 'confirmed')
         FOR UPDATE`,
        [doctorId, appointmentDate, appointmentTime]
      );
      // یک بیمار فقط یک نوبت فعال در هر ساعتِ هر داکتر — این بررسی داخل همان تراکنشِ قفل‌دار
      // است، پس حتی اگر یک بیمار ده بار پشت‌سرهم/هم‌زمان کلیک کند، فقط اولی ثبت می‌شود.
      if (await hasActiveAppointmentForPatientSlot({ patientId, userId, doctorId, appointmentDate, appointmentTime }, conn)) {
        await conn.rollback();
        return { error: "ALREADY_BOOKED" };
      }
      if (rows.length >= capacity) {
        await conn.rollback();
        return { error: "SLOT_FULL" };
      }

      const [result] = await conn.query(
        status
          ? `INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, notes, status)
             VALUES (?, ?, ?, ?, ?, ?, ?)`
          : `INSERT INTO appointments (patientId, doctorId, department, appointmentDate, appointmentTime, notes)
             VALUES (?, ?, ?, ?, ?, ?)`,
        status
          ? [patientId, doctorId, department, appointmentDate, appointmentTime, notes || null, status]
          : [patientId, doctorId, department, appointmentDate, appointmentTime, notes || null]
      );

      await conn.commit();
      return { id: result.insertId };
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  });
}

// تعداد نوبت‌های فعال (pending/confirmed) یک (داکتر + تاریخ + ساعت) مشخص — برای بررسی
// «ظرفیت پر شده یا نه» پیش از نمایش فرم به کاربر. این تابع فقط برای پیش‌نمایش سریع است؛
// محافظت واقعی و قطعی در برابر رزرو بیش از ظرفیت همیشه در createAppointment (با تراکنش
// و قفل ردیف) انجام می‌شود، نه اینجا.
export async function countActiveAppointmentsForSlot({ doctorId, appointmentDate, appointmentTime }) {
  const [rows] = await db.query(
    `SELECT COUNT(*) AS count FROM appointments
     WHERE doctorId = ? AND appointmentDate = ? AND appointmentTime = ? AND status IN ('pending', 'confirmed')`,
    [doctorId, appointmentDate, appointmentTime]
  );
  return Number(rows[0].count) || 0;
}

// شماره‌ی ملاقاتِ یک نوبت داخل «همان داکتر + تاریخ + ساعت»: نفر اول، دوم، سوم... بر اساس ترتیب ثبت.
// نوبت‌های لغوشده/ردشده شمرده نمی‌شوند.
export async function getAppointmentQueueNumber({ id, doctorId, appointmentDate, appointmentTime }) {
  const [rows] = await db.query(
    `SELECT COUNT(*) AS n FROM appointments
     WHERE doctorId = ? AND appointmentDate = ? AND appointmentTime = ?
       AND status NOT IN ('cancelled', 'rejected') AND id <= ?`,
    [doctorId, appointmentDate, appointmentTime, id]
  );
  return Number(rows[0].n) || 1;
}

// نوبت‌های یک کاربر واردشده، همراه با نام داکتر (JOIN با جدول‌های patients و doctors)
export async function getAppointmentsByUser(userId) {
  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     WHERE p.userId = ?
     ORDER BY a.createdAt ASC, a.id ASC`,
    [userId]
  );
  return rows;
}

// همه‌ی نوبت‌های یک بیمار مشخص، جدیدترین اول (برای پرونده‌ی کامل بیمار در پنل ادمین)
export async function getAppointmentsByPatientId(patientId) {
  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName, p.fullName AS patientName, p.phone AS patientPhone
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     WHERE a.patientId = ?
     ORDER BY a.id ASC`,
    [patientId]
  );
  return rows;
}

// نوبت‌های یک داکتر مشخص (برای پنل داکتر: تایید/رد نوبت‌های خودش)
export async function getAppointmentsByDoctor(doctorId, { status } = {}) {
  const conditions = ["a.doctorId = ?"];
  const params = [doctorId];
  if (status) {
    conditions.push("a.status = ?");
    params.push(status);
  }
  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName, p.fullName AS patientName, p.phone AS patientPhone
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     WHERE ${conditions.join(" AND ")}
     ORDER BY a.id ASC`,
    params
  );
  return rows;
}

// جلوگیری از دوبار رزرو شدن یک نوبت (همان داکتر + همان تاریخ + همان ساعت)
// فقط نوبت‌های فعال (در انتظار/تاییدشده) مانع نوبت جدید می‌شوند؛ نوبت‌های لغوشده/تکمیل‌شده مانع نیستند
export async function isSlotTaken({ doctorId, appointmentDate, appointmentTime, excludeAppointmentId } = {}) {
  const conditions = [
    "doctorId = ?",
    "appointmentDate = ?",
    "appointmentTime = ?",
    "status IN ('pending', 'confirmed')",
  ];
  const params = [doctorId, appointmentDate, appointmentTime];
  if (excludeAppointmentId) {
    conditions.push("id != ?");
    params.push(excludeAppointmentId);
  }
  const [rows] = await db.query(
    `SELECT id FROM appointments WHERE ${conditions.join(" AND ")} LIMIT 1`,
    params
  );
  return rows.length > 0;
}

export async function getAppointmentById(id) {
  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName, p.fullName AS patientName, p.phone AS patientPhone, p.userId AS patientUserId
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     WHERE a.id = ?`,
    [id]
  );
  return rows[0] || null;
}

export async function updateAppointmentStatus(id, status, { changedByUserId, changedByRole, note } = {}) {
  const before = await getAppointmentById(id);
  await db.query("UPDATE appointments SET status = ? WHERE id = ?", [status, id]);

  // ثبت این تغییر در تاریخچه‌ی نوبت (الزام: ذخیره‌ی کامل سابقه‌ی نوبت‌ها)
  // این کار هرگز نباید باعث شکست عملیات اصلی شود
  try {
    await db.query(
      `INSERT INTO appointment_status_history (appointmentId, oldStatus, newStatus, changedByUserId, changedByRole, note)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, before ? before.status : null, status, changedByUserId || null, changedByRole || null, note || null]
    );
  } catch (err) {
    console.error("خطا در ثبت تاریخچه‌ی وضعیت نوبت:", err.message);
  }

  return getAppointmentById(id);
}

// تاریخچه‌ی کامل تغییرات وضعیت یک نوبت (جدیدترین در ابتدا)
export async function getAppointmentStatusHistory(appointmentId) {
  const [rows] = await db.query(
    `SELECT h.*, u.fullName AS changedByName
     FROM appointment_status_history h
     LEFT JOIN users u ON h.changedByUserId = u.id
     WHERE h.appointmentId = ?
     ORDER BY h.createdAt DESC`,
    [appointmentId]
  );
  return rows;
}

export async function deleteAppointment(id) {
  await db.query("DELETE FROM appointments WHERE id = ?", [id]);
}

// آمار وضعیت نوبت‌ها (گروه‌بندی‌شده بر اساس status)؛ در صورت ارسال from/to (بر اساس
// appointmentDate)، فقط نوبت‌های همان بازه شمارش می‌شوند — پیش‌فرض (بدون from/to) دقیقاً
// همان رفتار قبلی (همه‌ی نوبت‌ها، بدون فیلتر) را حفظ می‌کند
export async function countAppointments({ from, to } = {}) {
  const conditions = [];
  const params = [];
  if (from) {
    conditions.push("appointmentDate >= ?");
    params.push(from);
  }
  if (to) {
    conditions.push("appointmentDate <= ?");
    params.push(to);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [rows] = await db.query(
    `SELECT status, COUNT(*) AS count FROM appointments ${where} GROUP BY status`,
    params
  );
  return rows;
}

// فیلتر پیشرفته نوبت‌ها: بر اساس وضعیت (status)، بازه تاریخ (dateFrom/dateTo)
// و جستجوی متنی روی نام بیمار/داکتر، همراه با صفحه‌بندی
export async function searchAppointments({ status, dateFrom, dateTo, department, doctorId, q, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const allowedStatuses = ["pending", "confirmed", "completed", "cancelled"];
  const conditions = [];
  const params = [];

  if (status && allowedStatuses.includes(status)) {
    conditions.push("a.status = ?");
    params.push(status);
  }

  if (dateFrom) {
    conditions.push("a.appointmentDate >= ?");
    params.push(dateFrom);
  }

  if (dateTo) {
    conditions.push("a.appointmentDate <= ?");
    params.push(dateTo);
  }

  // فیلتر بخش (department روی خودِ رکورد نوبت) — امکان محدود کردن فهرست به یک بخش مشخص
  if (department && department.trim()) {
    conditions.push("a.department = ?");
    params.push(department.trim());
  }

  const doctorIdNum = parseInt(doctorId, 10);
  if (Number.isInteger(doctorIdNum) && doctorIdNum > 0) {
    conditions.push("a.doctorId = ?");
    params.push(doctorIdNum);
  }

  if (q && q.trim()) {
    const like = `%${q.trim()}%`;
    conditions.push("(p.fullName LIKE ? OR d.fullName LIKE ? OR a.department LIKE ? OR p.phone LIKE ? OR CAST(a.appointmentDate AS CHAR) LIKE ?)");
    params.push(like, like, like, like, like);
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName, p.fullName AS patientName, p.phone AS patientPhone
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     ${where}
     ORDER BY a.id ASC
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );

  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     JOIN doctors d ON a.doctorId = d.id
     ${where}`,
    params
  );

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

export async function countAppointmentsThisMonth() {
  const [rows] = await db.query(
    `SELECT COUNT(*) AS count FROM appointments
     WHERE MONTH(createdAt) = MONTH(CURRENT_DATE()) AND YEAR(createdAt) = YEAR(CURRENT_DATE())`
  );
  return rows[0].count;
}

// مجموع تعداد کل نوبت‌ها (برای داشبورد آنالیتیکس)؛ در صورت ارسال from/to (بر اساس
// appointmentDate) فقط نوبت‌های همان بازه شمارش می‌شوند — پیش‌فرض بدون تغییر (همه‌ی نوبت‌ها)
export async function countAllAppointments({ from, to } = {}) {
  const conditions = [];
  const params = [];
  if (from) {
    conditions.push("appointmentDate >= ?");
    params.push(from);
  }
  if (to) {
    conditions.push("appointmentDate <= ?");
    params.push(to);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [rows] = await db.query(`SELECT COUNT(*) AS count FROM appointments ${where}`, params);
  return rows[0].count;
}

// تعداد نوبت‌های امروز (بر اساس تاریخ نوبت، نه تاریخ ثبت)
export async function countAppointmentsToday() {
  const [rows] = await db.query(
    "SELECT COUNT(*) AS count FROM appointments WHERE appointmentDate = CURDATE()"
  );
  return rows[0].count;
}

// آمار ماهانه نوبت‌ها (بر اساس تاریخ نوبت) — برای نمودار روند در داشبورد.
// حالت پیش‌فرض (بدون from/to): دقیقاً همان رفتار قبلی، N ماه اخیر از امروز.
// حالت بازه‌ی تاریخ (با from/to): به‌جای «N ماه اخیر»، فقط ماه‌های داخل همان بازه
// انتخاب‌شده توسط ادمین محاسبه و برگردانده می‌شود.
export async function getMonthlyAppointmentStats(months = 6, { from, to } = {}) {
  if (from || to) {
    const conditions = [];
    const params = [];
    if (from) {
      conditions.push("appointmentDate >= ?");
      params.push(from);
    }
    if (to) {
      conditions.push("appointmentDate <= ?");
      params.push(to);
    }
    const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
    const [rows] = await db.query(
      `SELECT DATE_FORMAT(appointmentDate, '%Y-%m') AS month, COUNT(*) AS count
       FROM appointments
       ${where}
       GROUP BY month
       ORDER BY month ASC`,
      params
    );
    return rows;
  }

  const [rows] = await db.query(
    `SELECT DATE_FORMAT(appointmentDate, '%Y-%m') AS month, COUNT(*) AS count
     FROM appointments
     WHERE appointmentDate >= DATE_SUB(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL ? MONTH)
     GROUP BY month
     ORDER BY month ASC`,
    [Math.max(0, months - 1)]
  );
  return rows;
}

// زمان‌بندی یک نوبت به‌صورت رشته + فاصله‌ی زمانی تا شروع آن (به دقیقه؛ منفی = گذشته).
// محاسبه در خود دیتابیس انجام می‌شود تا با NOW() و مقدار ذخیره‌شده‌ی نوبت هم‌منطقه‌ی زمانی باشد.
export async function getAppointmentTiming(id) {
  const [rows] = await db.query(
    `SELECT DATE_FORMAT(appointmentDate, '%Y-%m-%d') AS dateStr,
            TIME_FORMAT(appointmentTime, '%H:%i') AS timeStr,
            TIMESTAMPDIFF(MINUTE, NOW(), TIMESTAMP(appointmentDate, appointmentTime)) AS minutesUntil
     FROM appointments WHERE id = ?`,
    [id]
  );
  if (!rows[0]) return null;
  return { dateStr: rows[0].dateStr, timeStr: rows[0].timeStr, minutesUntil: Number(rows[0].minutesUntil) };
}

// ---------- پنل داکتر → «نوبت‌های من» (فهرست سروری با صفحه‌بندی/جستجو/فیلتر) ----------
// همه‌ی کوئری‌ها با a.doctorId = ? محدود می‌شوند (RBAC: داکتر فقط نوبت‌های خودش را می‌بیند) و
// به‌جای SELECT a.* فقط ستون‌های لازم جدول خوانده می‌شوند. یادداشت (notes) فقط در جزئیات می‌آید.

const DOCTOR_APPT_STATUSES = ["pending", "confirmed", "completed", "cancelled"];

export async function searchDoctorAppointments({
  doctorId, q, status, department, dateFrom, dateTo, sort = "newest", page = 1, limit = 20,
} = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
  const offset = (safePage - 1) * safeLimit;

  const conditions = ["a.doctorId = ?"];
  const params = [doctorId];

  if (status && DOCTOR_APPT_STATUSES.includes(status)) {
    conditions.push("a.status = ?");
    params.push(status);
  }
  if (department && String(department).trim()) {
    conditions.push("a.department = ?");
    params.push(String(department).trim());
  }
  if (dateFrom) {
    conditions.push("a.appointmentDate >= ?");
    params.push(dateFrom);
  }
  if (dateTo) {
    conditions.push("a.appointmentDate <= ?");
    params.push(dateTo);
  }

  const term = String(q || "").trim().slice(0, 100);
  if (term) {
    const like = `%${escapeLikeTerm(term)}%`;
    const clauses = ["p.fullName LIKE ?", "p.publicCode LIKE ?", "p.phone LIKE ?"];
    params.push(like, like, like);
    // شماره نوبت (id) — فقط وقتی عبارت کاملاً عددی است
    if (/^\d{1,10}$/.test(term)) {
      clauses.push("a.id = ?");
      params.push(Number(term));
    }
    conditions.push(`(${clauses.join(" OR ")})`);
  }

  const dir = sort === "oldest" ? "ASC" : "DESC";
  const where = `WHERE ${conditions.join(" AND ")}`;

  const [rows] = await db.query(
    `SELECT a.id, a.patientId, p.fullName AS patientName, p.publicCode AS patientCode, p.phone AS patientPhone,
            a.department, DATE_FORMAT(a.appointmentDate, '%Y-%m-%d') AS appointmentDate,
            TIME_FORMAT(a.appointmentTime, '%H:%i') AS appointmentTime, a.status
     FROM appointments a
     JOIN patients p ON p.id = a.patientId
     ${where}
     ORDER BY a.appointmentDate ${dir}, a.appointmentTime ${dir}, a.id ${dir}
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );

  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count
     FROM appointments a
     JOIN patients p ON p.id = a.patientId
     ${where}`,
    params
  );
  const total = Number(countRows[0].count) || 0;
  return { rows, total, page: safePage, limit: safeLimit, totalPages: Math.max(1, Math.ceil(total / safeLimit)) };
}

// کارت‌های آماری + فهرست بخش‌ها برای فیلتر — فقط دو کوئری تجمیعی، بدون خواندن ردیف‌های نوبت
export async function getDoctorAppointmentStats(doctorId) {
  const [rows] = await db.query(
    "SELECT status, COUNT(*) AS count FROM appointments WHERE doctorId = ? GROUP BY status",
    [doctorId]
  );
  const stats = { total: 0, pending: 0, confirmed: 0, completed: 0, cancelled: 0 };
  for (const r of rows) {
    const n = Number(r.count) || 0;
    stats.total += n;
    if (r.status in stats) stats[r.status] = n;
  }
  const [deptRows] = await db.query(
    "SELECT DISTINCT department FROM appointments WHERE doctorId = ? AND department <> '' ORDER BY department",
    [doctorId]
  );
  return { ...stats, departments: deptRows.map((r) => r.department) };
}

// جزئیات یک نوبت برای Drawer — فقط اگر متعلق به همین داکتر باشد (وگرنه null → ۴۰۴)
export async function getDoctorAppointmentDetail(doctorId, appointmentId) {
  const [rows] = await db.query(
    `SELECT a.id, a.patientId, p.fullName AS patientName, p.publicCode AS patientCode, p.phone AS patientPhone,
            p.email AS patientEmail, p.gender AS patientGender,
            TIMESTAMPDIFF(YEAR, p.dateOfBirth, CURDATE()) AS patientAge,
            d.fullName AS doctorName, a.department,
            DATE_FORMAT(a.appointmentDate, '%Y-%m-%d') AS appointmentDate,
            TIME_FORMAT(a.appointmentTime, '%H:%i') AS appointmentTime,
            a.status, a.notes, a.createdAt
     FROM appointments a
     JOIN patients p ON p.id = a.patientId
     JOIN doctors d ON d.id = a.doctorId
     WHERE a.id = ? AND a.doctorId = ?
     LIMIT 1`,
    [appointmentId, doctorId]
  );
  return rows[0] || null;
}

function escapeLikeTerm(term) {
  return String(term).replace(/[\\%_]/g, (c) => `\\${c}`);
}

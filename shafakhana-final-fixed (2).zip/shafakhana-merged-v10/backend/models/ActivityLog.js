import db from "../db.js";

// آدرس IP واقعی کاربر را استخراج می‌کند (پشت پراکسی/لودبالانسر هم درست کار می‌کند)
// و پیشوند IPv6-mapped (::ffff:) را برای خوانایی بهتر پاک می‌کند
export function getClientIp(req) {
  if (!req) return null;
  // امنیتی: هدر X-Forwarded-For را کلاینت می‌تواند جعل کند. req.ip فقط وقتی به این هدر اعتماد می‌کند
  // که TRUST_PROXY درست تنظیم شده باشد؛ در غیر این صورت IP واقعی اتصال (socket) برمی‌گردد.
  const raw = req.ip || req.socket?.remoteAddress || null;
  return raw ? raw.replace(/^::ffff:/, "") : null;
}

// نام و نسخه مرورگر/دستگاه کاربر را از هدر User-Agent می‌گیرد
export function getUserAgent(req) {
  if (!req) return null;
  return req.headers["user-agent"] || null;
}

// ثبت یک رویداد در لاگ فعالیت‌ها. اگر req داده شود، آدرس IP و مرورگر خودکار استخراج می‌شود.
// این تابع هرگز نباید باعث شکست درخواست اصلی شود، به همین دلیل خطاهایش فقط لاگ می‌شوند.
export async function logActivity({ req, userId, userName, role, action, details }) {
  try {
    await db.query(
      `INSERT INTO activity_logs (userId, userName, role, action, details, ipAddress, userAgent)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        userId || null,
        userName || null,
        role || null,
        action,
        details ? String(details) : null,
        getClientIp(req),
        getUserAgent(req),
      ]
    );
  } catch (err) {
    console.error("خطا در ثبت لاگ فعالیت:", err.message);
  }
}

// شرط‌های جستجو/فیلتر لاگ‌ها را از ورودی کوئری می‌سازد (برای جلوگیری از تکرار کد
// بین لیست صفحه‌بندی‌شده و خروجی CSV)
function buildLogFilters({ role, userId, search, dateFrom, dateTo } = {}) {
  const clauses = [];
  const params = [];

  if (role) {
    clauses.push("role = ?");
    params.push(role);
  }
  if (userId) {
    clauses.push("userId = ?");
    params.push(userId);
  }
  if (search) {
    clauses.push("(action LIKE ? OR details LIKE ? OR userName LIKE ? OR ipAddress LIKE ?)");
    const like = `%${search}%`;
    params.push(like, like, like, like);
  }
  if (dateFrom) {
    clauses.push("createdAt >= ?");
    params.push(`${dateFrom} 00:00:00`);
  }
  if (dateTo) {
    clauses.push("createdAt <= ?");
    params.push(`${dateTo} 23:59:59`);
  }

  return {
    where: clauses.length ? `WHERE ${clauses.join(" AND ")}` : "",
    params,
  };
}

// لاگ‌ها را با فیلتر و صفحه‌بندی برمی‌گرداند — برای پنل جست‌وجو/فیلتر مدیر کل
export async function getFilteredLogs({ role, userId, search, dateFrom, dateTo, limit = 50, offset = 0 } = {}) {
  const { where, params } = buildLogFilters({ role, userId, search, dateFrom, dateTo });
  const [rows] = await db.query(
    `SELECT * FROM activity_logs ${where} ORDER BY createdAt DESC LIMIT ? OFFSET ?`,
    [...params, Number(limit) || 50, Number(offset) || 0]
  );
  const [countRows] = await db.query(`SELECT COUNT(*) AS total FROM activity_logs ${where}`, params);
  return { logs: rows, total: countRows[0].total };
}

// همان فیلترهای بالا را بدون صفحه‌بندی برمی‌گرداند — برای خروجی گرفتن (Export) از کل نتایج فیلترشده
export async function getLogsForExport({ role, userId, search, dateFrom, dateTo, limit = 5000 } = {}) {
  const { where, params } = buildLogFilters({ role, userId, search, dateFrom, dateTo });
  const [rows] = await db.query(
    `SELECT * FROM activity_logs ${where} ORDER BY createdAt DESC LIMIT ?`,
    [...params, Number(limit) || 5000]
  );
  return rows;
}

// نگه‌داشته شده برای سازگاری با کدهای قبلی که فقط یک لیست ساده از آخرین لاگ‌ها می‌خواهند
export async function getAllLogs(limit = 200) {
  const [rows] = await db.query(
    "SELECT * FROM activity_logs ORDER BY createdAt DESC LIMIT ?",
    [Number(limit) || 200]
  );
  return rows;
}

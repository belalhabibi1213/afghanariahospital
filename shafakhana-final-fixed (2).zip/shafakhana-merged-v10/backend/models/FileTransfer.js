import db from "../db.js";

// ---------- انتقال معلومات بیمار (Patient Information Transfer) ----------
// این ماژول جایگزین بخش «امضای دیجیتال» در پنل داکتر شده است. هر ردیف این جدول
// یک فایل ارسالی از داکتر به بیمار را نشان می‌دهد (اسناد صحی/گزارش‌ها).
// فایل‌ها در یک پوشه‌ی خصوصی ذخیره می‌شوند (نه از /uploads عمومی) و فقط از طریق
// مسیرهای احرازهویت‌شده و بعد از بررسی مالکیت/نقش قابل‌دسترسی هستند.

export async function createFileTransfer({ patientId, doctorId, fileName, originalName, fileType, fileSize, note }) {
  const [result] = await db.query(
    `INSERT INTO file_transfers (patientId, doctorId, fileName, originalName, fileType, fileSize, note)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [patientId, doctorId, fileName, originalName, fileType, fileSize, note || null]
  );
  return getFileTransferById(result.insertId);
}

export async function getFileTransferById(id) {
  const [rows] = await db.query(
    `SELECT f.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM file_transfers f
     LEFT JOIN doctors d ON f.doctorId = d.id
     LEFT JOIN patients p ON f.patientId = p.id
     WHERE f.id = ?`,
    [id]
  );
  return rows[0] || null;
}

// فایل‌های ارسال‌شده توسط یک داکتر مشخص برای یک بیمار مشخص (پنل داکتر — تاریخچه‌ی ارسال)
export async function getFileTransfersByDoctorAndPatient(doctorId, patientId) {
  const [rows] = await db.query(
    `SELECT f.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM file_transfers f
     LEFT JOIN doctors d ON f.doctorId = d.id
     LEFT JOIN patients p ON f.patientId = p.id
     WHERE f.doctorId = ? AND f.patientId = ?
     ORDER BY f.createdAt ASC, f.id ASC`,
    [doctorId, patientId]
  );
  return rows;
}

// همه‌ی فایل‌های ارسال‌شده توسط یک داکتر (برای پنل داکتر)
export async function getFileTransfersByDoctor(doctorId) {
  const [rows] = await db.query(
    `SELECT f.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM file_transfers f
     LEFT JOIN doctors d ON f.doctorId = d.id
     LEFT JOIN patients p ON f.patientId = p.id
     WHERE f.doctorId = ?
     ORDER BY f.createdAt ASC, f.id ASC`,
    [doctorId]
  );
  return rows;
}

// همه‌ی فایل‌های دریافتی یک بیمار، بر اساس userId خودش (برای پنل بیمار — الزام دسترسی فقط به فایل‌های خودش)
export async function getFileTransfersByPatientUser(userId) {
  const [rows] = await db.query(
    `SELECT f.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM file_transfers f
     JOIN patients p ON f.patientId = p.id
     LEFT JOIN doctors d ON f.doctorId = d.id
     WHERE p.userId = ?
     ORDER BY f.createdAt ASC, f.id ASC`,
    [userId]
  );
  return rows;
}

// یک فایل مشخص، فقط اگر واقعاً متعلق به همین کاربر (بیمار) باشد — برای دانلود امن
export async function getFileTransferByIdForPatientUser(id, userId) {
  const [rows] = await db.query(
    `SELECT f.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM file_transfers f
     JOIN patients p ON f.patientId = p.id
     LEFT JOIN doctors d ON f.doctorId = d.id
     WHERE f.id = ? AND p.userId = ?`,
    [id, userId]
  );
  return rows[0] || null;
}

// حذف یک رکورد ارسال فایل (فقط پنل داکتر — RBAC مالکیت در کنترلر بررسی می‌شود)
export async function deleteFileTransferById(id) {
  await db.query(`DELETE FROM file_transfers WHERE id = ?`, [id]);
}

// بررسی می‌کند که آیا نام فایل (fileName) توسط رکورد دیگری هنوز استفاده می‌شود یا نه —
// پیش از حذف فایل فیزیکی از دیسک بعد از حذف یک رکورد، این تابع فراخوانی می‌شود تا
// اگر (به‌هر دلیلی) رکورد دیگری هنوز به همین فایل اشاره داشت، فایل روی دیسک باقی بماند.
export async function countFileTransfersByFileName(fileName, excludeId = null) {
  const [rows] = await db.query(
    `SELECT COUNT(*) AS count FROM file_transfers WHERE fileName = ? AND id != ?`,
    [fileName, excludeId || 0]
  );
  return rows[0].count;
}

// همه‌ی فایل‌های دریافتی یک بیمار مشخص (صرف‌نظر از این‌که کدام داکتر ارسال کرده)،
// برای نمایش در پرونده‌ی کامل بیمار در پنل ادمین (تب «فایل‌های دریافتی صحی»)
export async function getFileTransfersByPatientId(patientId) {
  const [rows] = await db.query(
    `SELECT f.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM file_transfers f
     LEFT JOIN doctors d ON f.doctorId = d.id
     LEFT JOIN patients p ON f.patientId = p.id
     WHERE f.patientId = ?
     ORDER BY f.createdAt ASC, f.id ASC`,
    [patientId]
  );
  return rows;
}

// ---------- توابع مخصوص Admin/Super Admin (مشاهده فقط — بدون امکان ویرایش) ----------
export async function getAllFileTransfers({ page = 1, limit = 20 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
  const offset = (safePage - 1) * safeLimit;

  const [rows] = await db.query(
    `SELECT f.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM file_transfers f
     LEFT JOIN doctors d ON f.doctorId = d.id
     LEFT JOIN patients p ON f.patientId = p.id
     ORDER BY f.createdAt ASC, f.id ASC
     LIMIT ? OFFSET ?`,
    [safeLimit, offset]
  );
  const [countRows] = await db.query("SELECT COUNT(*) AS count FROM file_transfers");

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

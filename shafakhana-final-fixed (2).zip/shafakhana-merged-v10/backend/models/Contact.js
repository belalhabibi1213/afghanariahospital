import db from "../db.js";

export const CONTACT_TYPES = ["suggestion", "criticism", "complaint", "question", "other"];

// type و subject اختیاری‌اند (فرم قدیمی هیچ‌کدام را نمی‌فرستد): type پیش‌فرض 'other' و subject خالی
export async function createContactMessage({ fullName, phone, email, message, type, subject }) {
  const safeType = CONTACT_TYPES.includes(type) ? type : "other";
  const safeSubject = subject ? String(subject).trim().slice(0, 200) || null : null;
  const [result] = await db.query(
    "INSERT INTO contacts (fullName, phone, email, message, type, subject) VALUES (?, ?, ?, ?, ?, ?)",
    [fullName, phone || null, email || null, message, safeType, safeSubject]
  );
  return { id: result.insertId, fullName, phone, email, message, type: safeType, subject: safeSubject };
}

export async function getAllContactMessages() {
  const [rows] = await db.query("SELECT * FROM contacts ORDER BY createdAt ASC, id ASC");
  return rows;
}

// ---------- مدیریت ادمین (پیام‌های تماس با ما) ----------

// فهرست صفحه‌بندی‌شده برای پنل ادمین (همه‌ی فیلترها و جستجو سمت دیتابیس‌اند؛ فقط ردیف‌های همین
// صفحه برمی‌گردد و متن پیام در لیست به یک «خلاصه» (preview) کوتاه می‌شود).
// فیلترها: status = new|unread|read|important|answered، type، q (نام/تلفن/ایمیل/موضوع/متن)،
// dateFrom/dateTo (بازه‌ی تاریخ ثبت پیام)، page و limit
function buildContactWhere({ status, type, q, dateFrom, dateTo } = {}) {
  const conditions = [];
  const params = [];
  if (status === "new" || status === "unread") conditions.push("status = 'unread'");
  else if (status === "read") conditions.push("status = 'read'");
  else if (status === "important") conditions.push("isImportant = 1");
  else if (status === "answered") conditions.push("isAnswered = 1");
  if (type && CONTACT_TYPES.includes(type)) {
    conditions.push("type = ?");
    params.push(type);
  }
  const term = (q || "").trim();
  if (term) {
    const like = `%${term}%`;
    conditions.push("(fullName LIKE ? OR phone LIKE ? OR email LIKE ? OR subject LIKE ? OR message LIKE ?)");
    params.push(like, like, like, like, like);
  }
  if (dateFrom) {
    conditions.push("createdAt >= ?");
    params.push(`${dateFrom} 00:00:00`);
  }
  if (dateTo) {
    conditions.push("createdAt < DATE_ADD(?, INTERVAL 1 DAY)");
    params.push(dateTo);
  }
  return { whereClause: conditions.length ? `WHERE ${conditions.join(" AND ")}` : "", params };
}

export async function getContactMessagesAdmin({ page = 1, limit = 20, ...filters } = {}) {
  const { whereClause, params } = buildContactWhere(filters);
  const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
  const safePage = Math.max(parseInt(page, 10) || 1, 1);

  const [[{ total }]] = await db.query(`SELECT COUNT(*) AS total FROM contacts ${whereClause}`, params);
  const [rows] = await db.query(
    `SELECT id, fullName, phone, email, subject, type, status, isImportant, isAnswered, createdAt,
            LEFT(message, 140) AS preview
     FROM contacts
     ${whereClause}
     ORDER BY createdAt ASC, id ASC
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, (safePage - 1) * safeLimit]
  );
  const totalNum = Number(total) || 0;
  return {
    messages: rows.map(normalizeContactRow),
    pagination: { page: safePage, limit: safeLimit, total: totalNum, totalPages: Math.max(Math.ceil(totalNum / safeLimit), 1) },
  };
}

// پرچم‌های TINYINT به boolean تبدیل می‌شوند تا فرانت‌اند با 0/1 درگیر نشود
export function normalizeContactRow(row) {
  if (!row) return row;
  return { ...row, isImportant: !!row.isImportant, isAnswered: !!row.isAnswered };
}

export async function getContactMessageById(id) {
  const [rows] = await db.query("SELECT * FROM contacts WHERE id = ?", [id]);
  return rows[0] ? normalizeContactRow(rows[0]) : null;
}

// آمار داشبورد (همه از دیتابیس): مجموع، جدید(نخوانده)، خوانده‌شده، مهم و پاسخ‌داده‌شده — یک کوئری
export async function getContactMessageStats() {
  const [[row]] = await db.query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(status = 'unread'), 0) AS unread,
            COALESCE(SUM(status = 'read'), 0) AS \`read\`,
            COALESCE(SUM(isImportant = 1), 0) AS important,
            COALESCE(SUM(isAnswered = 1), 0) AS answered
     FROM contacts`
  );
  const n = (v) => Number(v) || 0;
  return { total: n(row.total), unread: n(row.unread), read: n(row.read), important: n(row.important), answered: n(row.answered) };
}

export async function updateContactMessageStatus(id, status) {
  await db.query("UPDATE contacts SET status = ? WHERE id = ?", [status, id]);
  return getContactMessageById(id);
}

export async function deleteContactMessage(id) {
  await db.query("DELETE FROM contacts WHERE id = ?", [id]);
}

// تغییر پرچم‌های «مهم» و «پاسخ‌داده‌شده» (هر کدام که داده شود)
export async function updateContactMessageFlags(id, { isImportant, isAnswered }) {
  const sets = [];
  const params = [];
  if (typeof isImportant === "boolean") { sets.push("isImportant = ?"); params.push(isImportant ? 1 : 0); }
  if (typeof isAnswered === "boolean") { sets.push("isAnswered = ?"); params.push(isAnswered ? 1 : 0); }
  if (sets.length) await db.query(`UPDATE contacts SET ${sets.join(", ")} WHERE id = ?`, [...params, id]);
  return getContactMessageById(id);
}

// ---------- عملیات گروهی (انتخاب چندتایی در جدول) ----------
export async function getContactMessagesByIds(ids) {
  if (!ids.length) return [];
  const [rows] = await db.query(`SELECT * FROM contacts WHERE id IN (?)`, [ids]);
  return rows.map(normalizeContactRow);
}

// patch: { status } یا { isImportant } — فقط ستون‌های مجاز (whitelist) در SQL می‌روند
export async function bulkUpdateContactMessages(ids, patch) {
  const sets = [];
  const params = [];
  if (patch.status === "read" || patch.status === "unread") { sets.push("status = ?"); params.push(patch.status); }
  if (typeof patch.isImportant === "boolean") { sets.push("isImportant = ?"); params.push(patch.isImportant ? 1 : 0); }
  if (typeof patch.isAnswered === "boolean") { sets.push("isAnswered = ?"); params.push(patch.isAnswered ? 1 : 0); }
  if (!sets.length || !ids.length) return 0;
  const [result] = await db.query(`UPDATE contacts SET ${sets.join(", ")} WHERE id IN (?)`, [...params, ids]);
  return result.affectedRows;
}

export async function bulkDeleteContactMessages(ids) {
  if (!ids.length) return 0;
  const [result] = await db.query("DELETE FROM contacts WHERE id IN (?)", [ids]);
  return result.affectedRows;
}

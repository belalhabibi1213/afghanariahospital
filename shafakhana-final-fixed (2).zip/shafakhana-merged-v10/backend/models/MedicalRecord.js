import db from "../db.js";

// فیلدهای معاینه‌ی تخصصی فقط برای داکتر/ادمین‌اند؛ توصیه‌ها، پیگیری و توضیح ارسال هم تا قبل از «ارسال به بیمار»
// برای بیمار دیده نمی‌شوند. چون پرس‌وجوهای بیمار از SELECT m.* استفاده می‌کنند، این فیلدها اینجا حذف می‌شوند.
const PATIENT_HIDDEN_ALWAYS = ["examFindings", "systemsReview", "abnormalFindings", "examNotes", "generalCondition"];
const PATIENT_HIDDEN_UNTIL_SENT = ["recommendations", "followUpRequired", "followUpDate", "followUpStatus", "followUpNotes", "sentNote"];
export function sanitizeRecordForPatient(row) {
  if (!row) return row;
  const out = { ...row };
  PATIENT_HIDDEN_ALWAYS.forEach((k) => delete out[k]);
  out.released = !!row.sentToPatientAt;
  if (!out.released) PATIENT_HIDDEN_UNTIL_SENT.forEach((k) => delete out[k]);
  return out;
}

// پیش‌نویس‌ها (status='draft') هرگز برای بیمار دیده نمی‌شوند
export async function getRecordsByPatientUser(userId) {
  const [rows] = await db.query(
    `SELECT m.*, d.fullName AS doctorName
     FROM medical_records m
     JOIN patients p ON m.patientId = p.id
     LEFT JOIN doctors d ON m.doctorId = d.id
     WHERE p.userId = ? AND m.status <> 'draft'
     ORDER BY m.createdAt ASC, m.id ASC`,
    [userId]
  );
  return rows.map(sanitizeRecordForPatient);
}

// ستون‌های متنی/تاریخی جدید فرم «افزودن پرونده صحی» (همه اختیاری). لیست سفید = تنها ستون‌هایی که در SQL می‌روند.
const EXTRA_FIELDS = [
  "visitReason", "chiefComplaint", "pulse", "respiratoryRate", "spo2", "generalCondition", "examFindings",
  "systemsReview", "abnormalFindings", "examNotes", "primaryDiagnosis", "diagnosisNotes", "recommendations",
  "followUpDate", "followUpStatus", "followUpNotes",
];

export async function createRecord({
  patientId, doctorId, appointmentId, visitDate,
  symptoms, diagnosis, bloodPressure, temperature, height, weight, labResults, treatment,
  prescription, notes, status, followUpRequired, ...extra
}) {
  const cols = [
    "patientId", "doctorId", "appointmentId", "visitDate", "symptoms", "diagnosis", "bloodPressure", "temperature",
    "height", "weight", "labResults", "treatment", "prescription", "notes",
  ];
  const vals = [
    patientId, doctorId || null, appointmentId || null, visitDate || null,
    symptoms || null, diagnosis || null, bloodPressure || null, temperature || null,
    height || null, weight || null, labResults || null, treatment || null,
    prescription || null, notes || null,
  ];
  const marks = cols.map((c) => (c === "visitDate" ? "COALESCE(?, CURRENT_DATE)" : "?"));
  if (status === "draft" || status === "registered") { cols.push("status"); vals.push(status); marks.push("?"); }
  if (followUpRequired !== undefined) { cols.push("followUpRequired"); vals.push(followUpRequired ? 1 : 0); marks.push("?"); }
  for (const f of EXTRA_FIELDS) {
    if (extra[f] !== undefined && extra[f] !== null && extra[f] !== "") { cols.push(f); vals.push(extra[f]); marks.push("?"); }
  }
  const [result] = await db.query(
    `INSERT INTO medical_records (${cols.join(", ")}) VALUES (${marks.join(", ")})`,
    vals
  );
  return getRecordById(result.insertId);
}

export async function getRecordById(id) {
  const [rows] = await db.query(
    `SELECT m.*, d.fullName AS doctorName, p.fullName AS patientName
     FROM medical_records m
     LEFT JOIN doctors d ON m.doctorId = d.id
     JOIN patients p ON m.patientId = p.id
     WHERE m.id = ?`,
    [id]
  );
  return rows[0] || null;
}

// همه‌ی ویزیت‌های ثبت‌شده برای یک بیمار مشخص (برای پنل داکتر/ادمین)
export async function getRecordsByPatientId(patientId) {
  const [rows] = await db.query(
    `SELECT m.*, d.fullName AS doctorName
     FROM medical_records m
     LEFT JOIN doctors d ON m.doctorId = d.id
     WHERE m.patientId = ?
     ORDER BY m.createdAt ASC, m.id ASC`,
    [patientId]
  );
  return rows;
}

// ویرایش یک ویزیت/رکورد کلی توسط داکتر (الزام شماره ۷: اجازه‌ی به‌روزرسانی رکوردها)
export async function updateRecord(id, {
  visitDate, symptoms, diagnosis, bloodPressure, temperature, height, weight, labResults, treatment,
  prescription, notes, status, followUpRequired, ...extra
}) {
  const sets = [
    "visitDate = COALESCE(?, visitDate)", "symptoms = COALESCE(?, symptoms)", "diagnosis = COALESCE(?, diagnosis)",
    "bloodPressure = COALESCE(?, bloodPressure)", "temperature = COALESCE(?, temperature)", "height = COALESCE(?, height)",
    "weight = COALESCE(?, weight)", "labResults = COALESCE(?, labResults)", "treatment = COALESCE(?, treatment)",
    "prescription = COALESCE(?, prescription)", "notes = COALESCE(?, notes)",
  ];
  const vals = [
    visitDate ?? null, symptoms ?? null, diagnosis ?? null, bloodPressure ?? null,
    temperature ?? null, height ?? null, weight ?? null, labResults ?? null, treatment ?? null,
    prescription ?? null, notes ?? null,
  ];
  // رشته‌ی خالی ("") یعنی «پاک کن»؛ undefined یعنی «دست نزن» (همان قرارداد COALESCE قبلی)
  for (const f of EXTRA_FIELDS) {
    if (extra[f] !== undefined) { sets.push(`${f} = ?`); vals.push(extra[f] === "" ? null : extra[f]); }
  }
  if (status === "draft" || status === "registered") { sets.push("status = ?"); vals.push(status); }
  if (followUpRequired !== undefined) { sets.push("followUpRequired = ?"); vals.push(followUpRequired ? 1 : 0); }
  await db.query(`UPDATE medical_records SET ${sets.join(", ")} WHERE id = ?`, [...vals, id]);
  return getRecordById(id);
}

// ثبت ارسال گزارش به بیمار (زمان + توضیح کوتاه داکتر)
export async function markRecordSent(id, note) {
  await db.query("UPDATE medical_records SET sentToPatientAt = NOW(), sentNote = ? WHERE id = ?", [note || null, id]);
  return getRecordById(id);
}

export async function deleteRecord(id) {
  await db.query("DELETE FROM medical_records WHERE id = ?", [id]);
}

// خط زمانی سابقه صحی: ترکیب نسخه‌ها (prescriptions) و ویزیت‌ها/رکوردهای عمومی
// (medical_records) در یک فهرست واحد و زمانی‌مرتب‌شده، فقط برای بیمار خودش —
// همراه با جستجو، فیلتر بازه‌ی تاریخ و صفحه‌بندی (الزام‌های ۱، ۲، ۴، ۵ و ۶).
// نکته‌ی مهم (رفع اشکال اتصال): جدول prescriptions ستون diagnosis ندارد و
// جدول medical_records ستون treatment/visitDate ندارد؛ در نسخه‌ی قبلی همین
// کوئری به‌اشتباه به این ستون‌های ناموجود ارجاع می‌داد که باعث خطای
// «Unknown column» از MySQL و شکست کامل درخواست (۵۰۰) می‌شد. این نسخه فقط از
// ستون‌های واقعاً موجود در جدول‌ها (طبق db.js) استفاده می‌کند: برای هر نسخه،
// «تشخیص» از رکورد ویزیت مرتبط (در صورت وجود recordId) گرفته می‌شود؛ برای هر
// ویزیت، «تداوی» از همان ستون prescription (متن آزاد تداوی/نسخه‌ی ثبت‌شده
// توسط داکتر) خوانده می‌شود. ستون‌های دیگر (علائم/فشار خون/...) به این
// ماژول مربوط نیستند و دست‌نخورده باقی مانده‌اند.
// فیلتر «نوع» خط زمانی ← نوع رویدادهای داخل دیتابیس (whitelist؛ مقدار ناشناخته = همه)
// «سوابق طبی» = تشخیص‌ها + حساسیت‌های ثبت‌شده؛ «ویزیت» = رکورد ویزیت (medical_records)
const TIMELINE_TYPE_GROUPS = {
  encounter: ["encounter"],
  prescription: ["prescription"],
  lab: ["lab"],
  radiology: ["radiology"],
  appointment: ["appointment"],
  record: ["diagnosis", "allergy"],
};
// نام فارسیِ هر نوع رویداد — جستجوی «نسخه»/«ویزیت»/«نوبت»... باید رویدادهای همان نوع را هم پیدا کند،
// چون عنوانِ نمایشی (مثلاً «نوبت ملاقات») در دیتابیس ذخیره نشده و در فرانت‌اند ساخته می‌شود
const TIMELINE_TYPE_SEARCH_LABELS = {
  prescription: "نسخه دارو",
  encounter: "ویزیت داکتر",
  lab: "آزمایش",
  radiology: "رادیولوژی تصویربرداری",
  appointment: "نوبت ملاقات",
  diagnosis: "تشخیص سوابق طبی",
  allergy: "حساسیت سوابق طبی",
};
const ALL_TIMELINE_KINDS = ["encounter", "prescription", "lab", "radiology", "appointment", "diagnosis", "allergy"];

// هر زیرکوئری دقیقاً همین ستون‌ها را برمی‌گرداند (ترتیب مهم است — UNION):
// type, id, eventDate, eventTime, doctorName, department, title, description, status,
// itemCount, hasFile, diagnosis, treatment.
// مالکیت: همه‌ی زیرکوئری‌ها با JOIN patients و شرط p.userId = ? (شناسه‌ی کاربرِ توکن) محدود می‌شوند؛
// هیچ شناسه‌ی بیماری از کلاینت گرفته نمی‌شود. ساعت فقط وقتی برگردانده می‌شود که واقعاً ثبت شده
// باشد (برای آزمایش/رادیولوژی/ویزیت فقط اگر تاریخ رویداد با تاریخ ثبت رکورد یکی باشد) تا ساعتِ ساختگی نمایش داده نشود.
const TIMELINE_KIND_SQL = {
  prescription: `
    SELECT 'prescription' AS type, MIN(pr.id) AS id, DATE(MIN(pr.createdAt)) AS eventDate, TIME(MIN(pr.createdAt)) AS eventTime,
           MAX(d.fullName) AS doctorName, MAX(d.department) AS department, NULL AS title,
           GROUP_CONCAT(NULLIF(TRIM(pr.medicationName), '') ORDER BY pr.id SEPARATOR '، ') AS description,
           MAX(pr.status) AS status, COUNT(*) AS itemCount, 0 AS hasFile,
           COALESCE(MAX(pr.diagnosis), MAX(mr.diagnosis)) AS diagnosis,
           NULLIF(CONCAT_WS(' — ',
             GROUP_CONCAT(NULLIF(TRIM(CONCAT_WS(' ', pr.medicationName, pr.dosage)), '') ORDER BY pr.id SEPARATOR '، '),
             MAX(pr.instructions)), '') AS treatment
    FROM prescriptions pr
    JOIN patients p ON pr.patientId = p.id
    LEFT JOIN doctors d ON pr.doctorId = d.id
    LEFT JOIN medical_records mr ON pr.recordId = mr.id
    WHERE p.userId = ?
    GROUP BY pr.patientId, COALESCE(pr.groupId, CONCAT('single-', pr.id))`,
  encounter: `
    SELECT 'encounter' AS type, m.id AS id, m.visitDate AS eventDate,
           CASE WHEN DATE(m.createdAt) = m.visitDate THEN TIME(m.createdAt) END AS eventTime,
           d.fullName AS doctorName, d.department AS department, NULL AS title, m.symptoms AS description,
           NULL AS status, NULL AS itemCount, 0 AS hasFile, m.diagnosis AS diagnosis, m.prescription AS treatment
    FROM medical_records m
    JOIN patients p ON m.patientId = p.id
    LEFT JOIN doctors d ON m.doctorId = d.id
    WHERE p.userId = ? AND m.status <> 'draft'`,
  lab: `
    SELECT 'lab' AS type, l.id AS id, COALESCE(l.testDate, DATE(l.createdAt)) AS eventDate,
           CASE WHEN l.testDate IS NULL OR DATE(l.createdAt) = l.testDate THEN TIME(l.createdAt) END AS eventTime,
           d.fullName AS doctorName, d.department AS department, l.testName AS title,
           NULLIF(TRIM(CONCAT_WS(' ', l.result, l.unit)), '') AS description,
           l.status AS status, NULL AS itemCount, (l.reportUrl IS NOT NULL AND l.reportUrl <> '') AS hasFile,
           NULL AS diagnosis, NULL AS treatment
    FROM lab_results l
    JOIN patients p ON l.patientId = p.id
    LEFT JOIN doctors d ON l.doctorId = d.id
    WHERE p.userId = ? AND l.status = 'completed' AND NOT EXISTS (SELECT 1 FROM medical_records dr WHERE dr.id = l.recordId AND dr.status = 'draft')`,
  radiology: `
    SELECT 'radiology' AS type, r.id AS id, COALESCE(r.examDate, DATE(r.createdAt)) AS eventDate,
           CASE WHEN r.examDate IS NULL OR DATE(r.createdAt) = r.examDate THEN TIME(r.createdAt) END AS eventTime,
           d.fullName AS doctorName, d.department AS department, r.examType AS title,
           COALESCE(NULLIF(TRIM(r.impression), ''), NULLIF(TRIM(r.findings), '')) AS description,
           NULL AS status, NULL AS itemCount, 0 AS hasFile, NULL AS diagnosis, NULL AS treatment
    FROM radiology_reports r
    JOIN patients p ON r.patientId = p.id
    LEFT JOIN doctors d ON r.doctorId = d.id
    WHERE p.userId = ?`,
  appointment: `
    SELECT 'appointment' AS type, a.id AS id, a.appointmentDate AS eventDate, a.appointmentTime AS eventTime,
           d.fullName AS doctorName, a.department AS department, NULL AS title, a.notes AS description,
           a.status AS status, NULL AS itemCount, 0 AS hasFile, NULL AS diagnosis, NULL AS treatment
    FROM appointments a
    JOIN patients p ON a.patientId = p.id
    JOIN doctors d ON a.doctorId = d.id
    WHERE p.userId = ?`,
  diagnosis: `
    SELECT 'diagnosis' AS type, g.id AS id, DATE(g.createdAt) AS eventDate, TIME(g.createdAt) AS eventTime,
           d.fullName AS doctorName, d.department AS department, g.title AS title, g.description AS description,
           g.status AS status, NULL AS itemCount, 0 AS hasFile, g.title AS diagnosis, NULL AS treatment
    FROM diagnoses g
    JOIN patients p ON g.patientId = p.id
    LEFT JOIN doctors d ON g.doctorId = d.id
    WHERE p.userId = ?`,
  allergy: `
    SELECT 'allergy' AS type, al.id AS id, DATE(al.createdAt) AS eventDate, TIME(al.createdAt) AS eventTime,
           d.fullName AS doctorName, d.department AS department, al.allergen AS title, al.reaction AS description,
           al.severity AS status, NULL AS itemCount, 0 AS hasFile, NULL AS diagnosis, NULL AS treatment
    FROM allergies al
    JOIN patients p ON al.patientId = p.id
    LEFT JOIN doctors d ON al.doctorId = d.id
    WHERE p.userId = ?`,
};

export async function getMedicalHistoryTimelineForPatientUser({
  userId, q, type, dateFrom, dateTo, page = 1, limit = 10,
} = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  // فقط انواعِ درخواست‌شده در UNION می‌آیند (ناشناخته = همه) تا کوئری بی‌جهت جدول‌های دیگر را نخواند
  const kinds = TIMELINE_TYPE_GROUPS[type] || ALL_TIMELINE_KINDS;
  const unionSql = kinds.map((k) => TIMELINE_KIND_SQL[k]).join("\n    UNION ALL\n");
  const unionParams = kinds.map(() => userId);

  const conditions = [];
  const params = [];

  const term = (q || "").trim();
  if (term) {
    const like = `%${term}%`;
    const matchedTypes = Object.entries(TIMELINE_TYPE_SEARCH_LABELS)
      .filter(([, label]) => label.includes(term))
      .map(([k]) => k);
    const typeClause = matchedTypes.length ? ` OR type IN (${matchedTypes.map(() => "?").join(", ")})` : "";
    conditions.push(`(title LIKE ? OR description LIKE ? OR diagnosis LIKE ? OR treatment LIKE ? OR doctorName LIKE ? OR department LIKE ?${typeClause})`);
    params.push(like, like, like, like, like, like, ...matchedTypes);
  }
  if (dateFrom && /^\d{4}-\d{2}-\d{2}$/.test(dateFrom)) {
    conditions.push("eventDate >= ?");
    params.push(dateFrom);
  }
  if (dateTo && /^\d{4}-\d{2}-\d{2}$/.test(dateTo)) {
    conditions.push("eventDate <= ?");
    params.push(dateTo);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT type, id, DATE_FORMAT(eventDate, '%Y-%m-%d') AS eventDate, TIME_FORMAT(eventTime, '%H:%i') AS eventTime,
            doctorName, department, title, description, status, itemCount, hasFile, diagnosis, treatment
     FROM (${unionSql}) AS timeline
     ${where}
     ORDER BY timeline.eventDate DESC, timeline.eventTime DESC, timeline.id DESC
     LIMIT ? OFFSET ?`,
    [...unionParams, ...params, safeLimit, offset]
  );

  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count FROM (${unionSql}) AS timeline ${where}`,
    [...unionParams, ...params]
  );

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

// جزئیات یک رویداد خط زمانی (بارگذاری تنبل هنگام کلیک «مشاهده جزئیات»). نسخه‌ها از مسیر موجود
// /users/prescriptions/:id/detail می‌آیند، پس اینجا نیستند. مالکیت همیشه با p.userId = ? (کاربرِ توکن)
// بررسی می‌شود و فقط ستون‌های مشخص (نه SELECT *) برگردانده می‌شود. اگر رکورد مالِ دیگری باشد → null (۴۰۴).
const TIMELINE_DETAIL_SQL = {
  encounter: `SELECT m.id, DATE_FORMAT(m.visitDate, '%Y-%m-%d') AS visitDate, m.createdAt, m.symptoms, m.diagnosis, m.bloodPressure, m.temperature, m.height, m.weight,
                     m.treatment, m.prescription, m.notes, d.fullName AS doctorName, d.department AS department
              FROM medical_records m JOIN patients p ON m.patientId = p.id LEFT JOIN doctors d ON m.doctorId = d.id
              WHERE m.id = ? AND p.userId = ? AND m.status <> 'draft'`,
  lab: `SELECT l.id, l.testName, l.result, l.unit, l.referenceRange, l.status, DATE_FORMAT(l.testDate, '%Y-%m-%d') AS testDate, l.createdAt,
               (l.reportUrl IS NOT NULL AND l.reportUrl <> '') AS hasFile, d.fullName AS doctorName, d.department AS department
        FROM lab_results l JOIN patients p ON l.patientId = p.id LEFT JOIN doctors d ON l.doctorId = d.id
        WHERE l.id = ? AND p.userId = ? AND l.status = 'completed' AND NOT EXISTS (SELECT 1 FROM medical_records dr WHERE dr.id = l.recordId AND dr.status = 'draft')`,
  radiology: `SELECT r.id, r.examType, r.findings, r.impression, DATE_FORMAT(r.examDate, '%Y-%m-%d') AS examDate, r.createdAt, d.fullName AS doctorName, d.department AS department
              FROM radiology_reports r JOIN patients p ON r.patientId = p.id LEFT JOIN doctors d ON r.doctorId = d.id
              WHERE r.id = ? AND p.userId = ?`,
  appointment: `SELECT a.id, DATE_FORMAT(a.appointmentDate, '%Y-%m-%d') AS appointmentDate, TIME_FORMAT(a.appointmentTime, '%H:%i') AS appointmentTime, a.department, a.notes, a.status, d.fullName AS doctorName
                FROM appointments a JOIN patients p ON a.patientId = p.id JOIN doctors d ON a.doctorId = d.id
                WHERE a.id = ? AND p.userId = ?`,
  diagnosis: `SELECT g.id, g.title, g.description, g.icdCode, g.status, g.createdAt, d.fullName AS doctorName, d.department AS department
              FROM diagnoses g JOIN patients p ON g.patientId = p.id LEFT JOIN doctors d ON g.doctorId = d.id
              WHERE g.id = ? AND p.userId = ?`,
  allergy: `SELECT al.id, al.allergen, al.reaction, al.severity, al.notes, al.createdAt, d.fullName AS doctorName, d.department AS department
            FROM allergies al JOIN patients p ON al.patientId = p.id LEFT JOIN doctors d ON al.doctorId = d.id
            WHERE al.id = ? AND p.userId = ?`,
};

export async function getTimelineEventDetailForPatientUser({ type, id, userId } = {}) {
  const sql = Object.prototype.hasOwnProperty.call(TIMELINE_DETAIL_SQL, type) ? TIMELINE_DETAIL_SQL[type] : null;
  if (!sql) return null;
  const [rows] = await db.query(sql, [id, userId]);
  return rows[0] || null;
}

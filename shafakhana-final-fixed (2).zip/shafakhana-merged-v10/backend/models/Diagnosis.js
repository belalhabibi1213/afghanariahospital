import db from "../db.js";

export async function createDiagnosis({ patientId, doctorId, recordId, title, description, icdCode, status }) {
  const [result] = await db.query(
    `INSERT INTO diagnoses (patientId, doctorId, recordId, title, description, icdCode, status)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [patientId, doctorId || null, recordId || null, title, description || null, icdCode || null, status || "active"]
  );
  return getDiagnosisById(result.insertId);
}

export async function getDiagnosisById(id) {
  const [rows] = await db.query(
    `SELECT g.*, d.fullName AS doctorName
     FROM diagnoses g
     LEFT JOIN doctors d ON g.doctorId = d.id
     WHERE g.id = ?`,
    [id]
  );
  return rows[0] || null;
}

export async function getDiagnosesByPatientId(patientId) {
  const [rows] = await db.query(
    `SELECT g.*, d.fullName AS doctorName
     FROM diagnoses g
     LEFT JOIN doctors d ON g.doctorId = d.id
     WHERE g.patientId = ?
     ORDER BY g.createdAt ASC, g.id ASC`,
    [patientId]
  );
  return rows;
}

// همان لیست بالا، اما مستقیم از روی userId کاربر واردشده (برای «مشاهده رکوردهای خودم» — بیمار)
export async function getDiagnosesByPatientUser(userId) {
  const [rows] = await db.query(
    `SELECT g.*, d.fullName AS doctorName
     FROM diagnoses g
     JOIN patients p ON g.patientId = p.id
     LEFT JOIN doctors d ON g.doctorId = d.id
     WHERE p.userId = ?
     ORDER BY g.createdAt ASC, g.id ASC`,
    [userId]
  );
  return rows;
}

export async function updateDiagnosis(id, { title, description, icdCode, status }) {
  await db.query(
    `UPDATE diagnoses SET
       title = COALESCE(?, title),
       description = COALESCE(?, description),
       icdCode = COALESCE(?, icdCode),
       status = COALESCE(?, status)
     WHERE id = ?`,
    [title ?? null, description ?? null, icdCode ?? null, status ?? null, id]
  );
  return getDiagnosisById(id);
}

export async function deleteDiagnosis(id) {
  await db.query("DELETE FROM diagnoses WHERE id = ?", [id]);
}

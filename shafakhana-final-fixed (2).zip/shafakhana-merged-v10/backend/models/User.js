import db from "../db.js";
import bcrypt from "bcryptjs";
import { BCRYPT_SALT_ROUNDS } from "../utils/env.js";
import { revokeAllSessionsForUser } from "./Session.js";
import { invalidateUser, getCachedUser, setCachedUser } from "../utils/authCache.js";

export async function findByEmail(email) {
  const [rows] = await db.query("SELECT * FROM users WHERE email = ?", [email.toLowerCase()]);
  return rows[0] || null;
}

export async function findById(id) {
  const [rows] = await db.query(
    `SELECT id, fullName, email, role, phone, dateOfBirth, gender, bloodGroup, address,
            emergencyContactName, emergencyContactRelationship, emergencyContactPhone,
            allergies, chronicDiseases, drugAllergies, height, weight,
            photoUrl, isActive, isVerified, mustChangePassword, lockedUntil, createdAt
     FROM users WHERE id = ?`,
    [id]
  );
  return rows[0] || null;
}

// «شناسه بیمار» ستون جداگانه‌ای در دیتابیس ندارد؛ همیشه از روی id همان کاربر و به‌صورت
// خودکار ساخته می‌شود (مثلاً PT-000042) — همین‌طور همیشه یکتا، ثابت و غیرقابل‌ویرایش
// است، چون هیچ‌جا به‌عنوان یک فیلد قابل‌نوشتن ذخیره یا از ورودی کاربر خوانده نمی‌شود.
export function formatPatientId(userId) {
  return `PT-${String(userId).padStart(6, "0")}`;
}

// نسخه‌ی کش‌شده‌ی findByIdRaw فقط برای middleware/auth.js (ابطال: invalidateUser در نوشتن‌های پایین)
export async function findByIdRawCached(id) {
  const hit = getCachedUser(id);
  if (hit) return hit;
  const row = await findByIdRaw(id);
  setCachedUser(id, row);
  return row;
}

// برای بررسی داخلی (شامل رمز عبور هش‌شده) استفاده می‌شود، هرگز مستقیم به فرانت‌اند فرستاده نشود
export async function findByIdRaw(id) {
  const [rows] = await db.query("SELECT * FROM users WHERE id = ?", [id]);
  return rows[0] || null;
}

export async function createUser({ fullName, email, password, role = "user" }) {
  // bcrypt.hash (نسخه async) به‌جای hashSync استفاده می‌شود تا هش کردن رمز عبور (که برای
  // ۱۰+ دور نمک‌گذاری چند ده میلی‌ثانیه طول می‌کشد) رشته‌ی اصلی رویداد Node.js را برای کل
  // درخواست‌های هم‌زمان دیگر مسدود نکند — نکته‌ی مهم عملکرد/مقیاس‌پذیری روی مسیرهای پرترافیک
  const hashedPassword = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);
  const [result] = await db.query(
    "INSERT INTO users (fullName, email, password, role) VALUES (?, ?, ?, ?)",
    [fullName, email.toLowerCase(), hashedPassword, role]
  );
  return { id: result.insertId, fullName, email: email.toLowerCase(), role };
}

// ترجیح تم (روشن/تاریک) کاربر واردشده را ذخیره می‌کند — فقط دو مقدار مجاز است
// (اعتبارسنجی مقدار در controller انجام می‌شود، این تابع فقط ذخیره می‌کند)
export async function updateThemePreference(userId, theme) {
  await db.query("UPDATE users SET themePreference = ? WHERE id = ?", [theme, userId]);
}

// پالت رنگی کاربر واردشده را ذخیره می‌کند (اعتبارسنجی شناسه در controller انجام می‌شود)
export async function updatePalettePreference(userId, palette) {
  await db.query("UPDATE users SET palettePreference = ? WHERE id = ?", [palette, userId]);
}

// کد تایید (هش‌شده) و زمان انقضای آن را برای کاربر ذخیره می‌کند
export async function setVerificationCode(userId, codeHash, expiresAt) {
  await db.query(
    "UPDATE users SET verificationCodeHash = ?, verificationExpires = ?, verificationAttempts = 0 WHERE id = ?",
    [codeHash, expiresAt, userId]
  );
}

// حساب را تایید‌شده علامت می‌زند و کد تایید را پاک می‌کند
export async function markEmailVerified(userId) {
  await db.query(
    "UPDATE users SET isVerified = 1, verificationCodeHash = NULL, verificationExpires = NULL, verificationAttempts = 0 WHERE id = ?",
    [userId]
  );
}

export async function updateProfile(userId, {
  fullName, phone, dateOfBirth, gender, bloodGroup, address,
  emergencyContactName, emergencyContactRelationship, emergencyContactPhone,
  allergies, chronicDiseases, drugAllergies, height, weight,
}) {
  await db.query(
    `UPDATE users
     SET fullName = ?, phone = ?, dateOfBirth = ?, gender = ?, bloodGroup = ?, address = ?,
         emergencyContactName = ?, emergencyContactRelationship = ?, emergencyContactPhone = ?,
         allergies = ?, chronicDiseases = ?, drugAllergies = ?, height = ?, weight = ?
     WHERE id = ?`,
    [
      fullName, phone || null, dateOfBirth || null, gender || null, bloodGroup || null, address || null,
      emergencyContactName || null, emergencyContactRelationship || null, emergencyContactPhone || null,
      allergies || null, chronicDiseases || null, drugAllergies || null, height || null, weight || null,
      userId,
    ]
  );
  return findById(userId);
}

export async function updatePassword(userId, newPassword) {
  const hashed = await bcrypt.hash(newPassword, BCRYPT_SALT_ROUNDS);
  // هر تغییر رمز عبور توسط خودِ صاحب حساب (چه داوطلبانه، چه در پاسخ به الزام تغییر رمز
  // موقت/پیش‌فرض) پرچم mustChangePassword را هم پاک می‌کند — رمز تازه دیگر «موقت» نیست.
  await db.query("UPDATE users SET password = ?, mustChangePassword = 0 WHERE id = ?", [hashed, userId]);
  invalidateUser(userId);
}

// وقتی ادمین/سوپرادمین به‌جای کاربر یک رمز موقت می‌سازد (بازنشانی رمز عبور بیمار/داکتر/ادمین)،
// برخلاف updatePassword بالا، پرچم mustChangePassword فعال می‌شود تا صاحب حساب در اولین ورود
// مجبور به تعیین رمز خودش شود — دقیقاً همان رفتاری که برای حساب‌های پیش‌فرض ساخته‌شده در seed
// هم اعمال می‌شود (ببینید db/migrations/indexes-and-seed.js).
export async function updatePasswordAndRequireChange(userId, tempPassword) {
  const hashed = await bcrypt.hash(tempPassword, BCRYPT_SALT_ROUNDS);
  await db.query("UPDATE users SET password = ?, mustChangePassword = 1 WHERE id = ?", [hashed, userId]);
  invalidateUser(userId);
  // رمز توسط مدیر بازنشانی شده: نشست‌های قبلی (احتمالاً در دست دیگران) نباید معتبر بمانند
  await revokeAllSessionsForUser(userId);
}

// ---------- شمارنده‌ی حدس اشتباه کد یک‌بارمصرف (OTP) ----------
// روی هر حدس اشتباه صدا زده می‌شود. وقتی تعداد به سقف برسد، «همان کد» (هش و انقضا) پاک می‌شود
// و حدس‌های بعدی (حتی کد درست) رد می‌شوند تا کاربر کد جدید بگیرد. نکته: در MySQL/MariaDB
// انتساب‌های SET از چپ به راست اجرا می‌شوند؛ پس شرط پاک‌سازی (با مقدار قدیمی) قبل از افزایش می‌آید.
export async function registerFailedOtp(userId, kind, maxAttempts) {
  if (kind === "verification") {
    await db.query(
      `UPDATE users
       SET verificationCodeHash = IF(verificationAttempts + 1 >= ?, NULL, verificationCodeHash),
           verificationExpires = IF(verificationAttempts + 1 >= ?, NULL, verificationExpires),
           verificationAttempts = verificationAttempts + 1
       WHERE id = ?`,
      [maxAttempts, maxAttempts, userId]
    );
  } else if (kind === "reset") {
    await db.query(
      `UPDATE users
       SET resetCodeHash = IF(resetAttempts + 1 >= ?, NULL, resetCodeHash),
           resetExpires = IF(resetAttempts + 1 >= ?, NULL, resetExpires),
           resetAttempts = resetAttempts + 1
       WHERE id = ?`,
      [maxAttempts, maxAttempts, userId]
    );
  } else {
    throw new Error("نوع OTP نامعتبر است");
  }
}

// ---------- قفل موقت حساب پس از چند تلاش ناموفق پیاپی ----------
// روی هر تلاش ناموفق صدا زده می‌شود؛ اگر شمارنده به آستانه‌ی تنظیم‌شده برسد، حساب برای
// مدت مشخص قفل می‌شود. شمارنده فقط با یک ورود موفق (resetFailedLoginAttempts) صفر می‌شود،
// نه با گذشت زمان — قفل شدن موقت است، اما «هشدار» ناشی از تلاش‌های قبلی باقی می‌ماند.
export async function registerFailedLogin(userId, maxAttempts, lockoutMinutes) {
  const [rows] = await db.query("SELECT failedLoginAttempts FROM users WHERE id = ?", [userId]);
  if (!rows[0]) return;
  const attempts = rows[0].failedLoginAttempts + 1;
  if (attempts >= maxAttempts) {
    await db.query(
      "UPDATE users SET failedLoginAttempts = 0, lockedUntil = DATE_ADD(NOW(), INTERVAL ? MINUTE) WHERE id = ?",
      [lockoutMinutes, userId]
    );
  } else {
    await db.query("UPDATE users SET failedLoginAttempts = ? WHERE id = ?", [attempts, userId]);
  }
}

export async function resetFailedLoginAttempts(userId) {
  await db.query("UPDATE users SET failedLoginAttempts = 0, lockedUntil = NULL WHERE id = ?", [userId]);
}

// عکس پروفایل کاربر را به‌روزرسانی می‌کند و مسیر عکس قبلی را برمی‌گرداند
// (تا کنترلر بتواند فایل قدیمی را از روی دیسک پاک کند و فایل یتیم باقی نماند)
export async function updatePhoto(userId, photoUrl) {
  const [rows] = await db.query("SELECT photoUrl FROM users WHERE id = ?", [userId]);
  const previousPhotoUrl = rows[0] ? rows[0].photoUrl : null;
  await db.query("UPDATE users SET photoUrl = ? WHERE id = ?", [photoUrl, userId]);
  return { previousPhotoUrl, user: await findById(userId) };
}

// ---------- توابع مخصوص فراموشی رمز عبور (Forgot / Reset Password) ----------

// کد بازیابی رمز عبور (هش‌شده) و زمان انقضای آن را ذخیره می‌کند
export async function setResetCode(userId, codeHash, expiresAt) {
  await db.query(
    "UPDATE users SET resetCodeHash = ?, resetExpires = ?, resetAttempts = 0 WHERE id = ?",
    [codeHash, expiresAt, userId]
  );
}

// بعد از بازیابی موفق رمز عبور، کد را باطل (پاک) می‌کند تا دوباره قابل استفاده نباشد
export async function clearResetCode(userId) {
  await db.query(
    "UPDATE users SET resetCodeHash = NULL, resetExpires = NULL, resetAttempts = 0 WHERE id = ?",
    [userId]
  );
}

// ---------- توابع مخصوص Admin / Super Admin ----------

export async function getAllUsers({ role } = {}) {
  if (role) {
    const [rows] = await db.query(
      "SELECT id, fullName, email, role, phone, isActive, isVerified, createdAt FROM users WHERE role = ? ORDER BY createdAt ASC, id ASC",
      [role]
    );
    return rows;
  }
  const [rows] = await db.query(
    "SELECT id, fullName, email, role, phone, isActive, isVerified, createdAt FROM users ORDER BY createdAt ASC, id ASC"
  );
  return rows;
}

export async function createStaffUser({ fullName, email, password, role }) {
  const hashedPassword = await bcrypt.hash(password, BCRYPT_SALT_ROUNDS);
  const [result] = await db.query(
    "INSERT INTO users (fullName, email, password, role, isVerified) VALUES (?, ?, ?, ?, 1)",
    [fullName, email.toLowerCase(), hashedPassword, role]
  );
  return { id: result.insertId, fullName, email: email.toLowerCase(), role };
}

export async function updateUserRole(userId, role) {
  await db.query("UPDATE users SET role = ? WHERE id = ?", [role, userId]);
  invalidateUser(userId);
  return findById(userId);
}

export async function setUserActive(userId, isActive) {
  await db.query("UPDATE users SET isActive = ? WHERE id = ?", [isActive ? 1 : 0, userId]);
  invalidateUser(userId);
  return findById(userId);
}

export async function deleteUser(userId) {
  await db.query("DELETE FROM users WHERE id = ?", [userId]);
  invalidateUser(userId);
}

export async function countUsersByRole() {
  const [rows] = await db.query("SELECT role, COUNT(*) AS count FROM users GROUP BY role");
  return rows;
}

// ---------- احراز هویت دومرحله‌ای (MFA) ----------
export async function setMfaPendingSecret(userId, encryptedSecret) {
  await db.query("UPDATE users SET mfaPendingSecretEnc = ? WHERE id = ? AND mfaEnabled = 0", [encryptedSecret, userId]);
}

// فقط اگر هنوز راز در انتظاری وجود ندارد می‌نویسد (اتمیک). درخواست‌های هم‌زمان setup (مثلاً دوبار
// اجرای useEffect در StrictMode) همه یک راز واحد را می‌بینند، نه اینکه QR نمایش‌داده‌شده با راز ذخیره‌شده فرق کند.
export async function setMfaPendingSecretIfEmpty(userId, encryptedSecret) {
  await db.query(
    "UPDATE users SET mfaPendingSecretEnc = ? WHERE id = ? AND mfaEnabled = 0 AND mfaPendingSecretEnc IS NULL",
    [encryptedSecret, userId]
  );
}

export async function enableMfa(userId, encryptedSecret, recoveryHashes) {
  await db.query(
    `UPDATE users SET mfaEnabled = 1, mfaSecretEnc = ?, mfaPendingSecretEnc = NULL,
            mfaRecoveryHashes = ?, mfaLastStep = NULL WHERE id = ?`,
    [encryptedSecret, JSON.stringify(recoveryHashes), userId]
  );
  invalidateUser(userId);
}

export async function disableMfa(userId) {
  await db.query(
    `UPDATE users SET mfaEnabled = 0, mfaSecretEnc = NULL, mfaPendingSecretEnc = NULL,
            mfaRecoveryHashes = NULL, mfaLastStep = NULL WHERE id = ?`,
    [userId]
  );
  invalidateUser(userId);
}

// گام TOTP را «اتمیک» مصرف می‌کند: فقط اگر از آخرین گام مصرف‌شده جدیدتر باشد true برمی‌گرداند
export async function consumeMfaStep(userId, step) {
  const [res] = await db.query(
    "UPDATE users SET mfaLastStep = ? WHERE id = ? AND (mfaLastStep IS NULL OR mfaLastStep < ?)",
    [step, userId, step]
  );
  return res.affectedRows === 1;
}

// یک کد بازیابی را (compare-and-swap روی فهرست هش‌ها) مصرف می‌کند؛ true اگر معتبر بود
export async function consumeRecoveryCode(userId, codeHash) {
  const [rows] = await db.query("SELECT mfaRecoveryHashes FROM users WHERE id = ?", [userId]);
  const current = rows[0]?.mfaRecoveryHashes;
  if (!current) return false;
  let list;
  try { list = JSON.parse(current); } catch { return false; }
  if (!Array.isArray(list) || !list.includes(codeHash)) return false;
  const next = JSON.stringify(list.filter((h) => h !== codeHash));
  const [res] = await db.query(
    "UPDATE users SET mfaRecoveryHashes = ? WHERE id = ? AND mfaRecoveryHashes = ?",
    [next, userId, current]
  );
  return res.affectedRows === 1;
}

import db from "../db.js";

export async function createAllergy({ patientId, doctorId, allergen, reaction, severity, notes }) {
  const [result] = await db.query(
    `INSERT INTO allergies (patientId, doctorId, allergen, reaction, severity, notes)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [patientId, doctorId || null, allergen, reaction || null, severity || "mild", notes || null]
  );
  return getAllergyById(result.insertId);
}

export async function getAllergyById(id) {
  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName
     FROM allergies a
     LEFT JOIN doctors d ON a.doctorId = d.id
     WHERE a.id = ?`,
    [id]
  );
  return rows[0] || null;
}

export async function getAllergiesByPatientId(patientId) {
  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName
     FROM allergies a
     LEFT JOIN doctors d ON a.doctorId = d.id
     WHERE a.patientId = ?
     ORDER BY a.createdAt ASC, a.id ASC`,
    [patientId]
  );
  return rows;
}

export async function getAllergiesByPatientUser(userId) {
  const [rows] = await db.query(
    `SELECT a.*, d.fullName AS doctorName
     FROM allergies a
     JOIN patients p ON a.patientId = p.id
     LEFT JOIN doctors d ON a.doctorId = d.id
     WHERE p.userId = ?
     ORDER BY a.createdAt ASC, a.id ASC`,
    [userId]
  );
  return rows;
}

export async function updateAllergy(id, { allergen, reaction, severity, notes }) {
  await db.query(
    `UPDATE allergies SET
       allergen = COALESCE(?, allergen),
       reaction = COALESCE(?, reaction),
       severity = COALESCE(?, severity),
       notes = COALESCE(?, notes)
     WHERE id = ?`,
    [allergen ?? null, reaction ?? null, severity ?? null, notes ?? null, id]
  );
  return getAllergyById(id);
}

export async function deleteAllergy(id) {
  await db.query("DELETE FROM allergies WHERE id = ?", [id]);
}

import db from "../db.js";

// گزارش گفتگوهای دستیار هوش مصنوعی — برای بازبینی کیفیت توسط مدیر و سقف روزانه‌ی هر کاربر.
// جدول در اولین استفاده به‌صورت غیرمخرب ساخته می‌شود (CREATE TABLE IF NOT EXISTS).
let ready = null;
function ensureTable() {
  if (!ready) {
    ready = db
      .query(`
        CREATE TABLE IF NOT EXISTS ai_chat_logs (
          id INT AUTO_INCREMENT PRIMARY KEY,
          userId INT NOT NULL,
          lang VARCHAR(5) NOT NULL DEFAULT 'fa',
          question TEXT NOT NULL,
          answer TEXT NOT NULL,
          emergency TINYINT(1) NOT NULL DEFAULT 0,
          flagged TINYINT(1) NOT NULL DEFAULT 0,
          createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          INDEX idx_ai_user_date (userId, createdAt)
        ) ENGINE=InnoDB
      `)
      .then(async () => {
        // ارتقای غیرمخرب برای جدولی که در نسخه‌ی قبل (بدون ستون flagged) ساخته شده بود
        const [cols] = await db.query(
          "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'ai_chat_logs' AND COLUMN_NAME = 'flagged'"
        );
        if (cols.length === 0) {
          await db.query("ALTER TABLE ai_chat_logs ADD COLUMN flagged TINYINT(1) NOT NULL DEFAULT 0");
        }
      })
      .catch((err) => {
        ready = null;
        throw err;
      });
  }
  return ready;
}

export async function countTodayForUser(userId) {
  await ensureTable();
  const [rows] = await db.query(
    "SELECT COUNT(*) AS c FROM ai_chat_logs WHERE userId = ? AND createdAt >= CURDATE() AND emergency = 0",
    [userId]
  );
  return Number(rows[0]?.c || 0);
}

export async function logChat({ userId, lang, question, answer, emergency }) {
  await ensureTable();
  await db.query(
    "INSERT INTO ai_chat_logs (userId, lang, question, answer, emergency) VALUES (?, ?, ?, ?, ?)",
    [userId, lang, String(question).slice(0, 2000), String(answer).slice(0, 4000), emergency ? 1 : 0]
  );
}

// ---------- بخش ادمین: بازبینی گفتگوها ----------
function buildFilters({ q, kind, dateFrom, dateTo }) {
  const where = [];
  const params = [];
  if (q) {
    where.push("(l.question LIKE ? OR l.answer LIKE ? OR u.fullName LIKE ?)");
    const like = `%${String(q).replace(/[\\%_]/g, "\\$&")}%`;
    params.push(like, like, like);
  }
  if (kind === "emergency") where.push("l.emergency = 1");
  else if (kind === "flagged") where.push("l.flagged = 1");
  else if (kind === "normal") where.push("l.emergency = 0");
  if (dateFrom) { where.push("l.createdAt >= ?"); params.push(dateFrom); }
  if (dateTo) { where.push("l.createdAt < DATE_ADD(?, INTERVAL 1 DAY)"); params.push(dateTo); }
  return { clause: where.length ? `WHERE ${where.join(" AND ")}` : "", params };
}

export async function listChatLogs({ page = 1, limit = 20, ...filters }) {
  await ensureTable();
  const pg = Math.max(1, Number(page) || 1);
  const lim = Math.min(100, Math.max(1, Number(limit) || 20));
  const { clause, params } = buildFilters(filters);
  const [[{ total }]] = await db.query(
    `SELECT COUNT(*) AS total FROM ai_chat_logs l LEFT JOIN users u ON u.id = l.userId ${clause}`, params
  );
  const [rows] = await db.query(
    `SELECT l.id, l.userId, u.fullName AS userName, l.lang, l.question, l.answer, l.emergency, l.flagged, l.createdAt
     FROM ai_chat_logs l LEFT JOIN users u ON u.id = l.userId
     ${clause} ORDER BY l.createdAt DESC, l.id DESC LIMIT ? OFFSET ?`,
    [...params, lim, (pg - 1) * lim]
  );
  return { logs: rows, pagination: { page: pg, limit: lim, total: Number(total), totalPages: Math.max(1, Math.ceil(total / lim)) } };
}

export async function chatLogStats() {
  await ensureTable();
  const [[r]] = await db.query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(createdAt >= CURDATE()), 0) AS today,
            COALESCE(SUM(emergency = 1), 0) AS emergency,
            COALESCE(SUM(flagged = 1), 0) AS flagged
     FROM ai_chat_logs`
  );
  return { total: Number(r.total), today: Number(r.today), emergency: Number(r.emergency), flagged: Number(r.flagged) };
}

export async function setChatLogFlag(id, flagged) {
  await ensureTable();
  const [res] = await db.query("UPDATE ai_chat_logs SET flagged = ? WHERE id = ?", [flagged ? 1 : 0, id]);
  return res.affectedRows > 0;
}

export async function deleteChatLog(id) {
  await ensureTable();
  const [res] = await db.query("DELETE FROM ai_chat_logs WHERE id = ?", [id]);
  return res.affectedRows > 0;
}

// حذف گروهی: یا فهرست شناسه‌ها، یا «همه‌ی گفتگوهای مطابق فیلتر فعلی» (selectAll) — یک کوئری، نه حلقه.
export async function bulkDeleteChatLogs({ ids, selectAll, ...filters }) {
  await ensureTable();
  if (selectAll) {
    const { clause, params } = buildFilters(filters);
    const [res] = await db.query(
      `DELETE l FROM ai_chat_logs l LEFT JOIN users u ON u.id = l.userId ${clause}`, params
    );
    return res.affectedRows;
  }
  const clean = [...new Set((ids || []).map(Number).filter((n) => Number.isInteger(n) && n > 0))];
  if (clean.length === 0) return 0;
  const [res] = await db.query("DELETE FROM ai_chat_logs WHERE id IN (?)", [clean]);
  return res.affectedRows;
}

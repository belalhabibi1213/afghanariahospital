import db from "../db.js";

export async function createLabResult({ patientId, doctorId, recordId, testName, result, unit, referenceRange, status, testDate }) {
  const [insertResult] = await db.query(
    `INSERT INTO lab_results (patientId, doctorId, recordId, testName, result, unit, referenceRange, status, testDate)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      patientId,
      doctorId || null,
      recordId || null,
      testName,
      result || null,
      unit || null,
      referenceRange || null,
      status || "completed",
      testDate || null,
    ]
  );
  return getLabResultById(insertResult.insertId);
}

export async function getLabResultById(id) {
  const [rows] = await db.query(
    `SELECT l.*, d.fullName AS doctorName
     FROM lab_results l
     LEFT JOIN doctors d ON l.doctorId = d.id
     WHERE l.id = ?`,
    [id]
  );
  return rows[0] || null;
}

// همه‌ی آزمایش‌های یک بیمار (برای پنل داکتر/ادمین — شامل درخواست‌های در انتظار نیز می‌شود)
export async function getLabResultsByPatientId(patientId, { status } = {}) {
  const conditions = ["l.patientId = ?"];
  const params = [patientId];
  if (status) {
    conditions.push("l.status = ?");
    params.push(status);
  }
  const [rows] = await db.query(
    `SELECT l.*, d.fullName AS doctorName
     FROM lab_results l
     LEFT JOIN doctors d ON l.doctorId = d.id
     WHERE ${conditions.join(" AND ")}
     ORDER BY l.createdAt ASC, l.id ASC`,
    params
  );
  return rows;
}

// همه‌ی آزمایش‌های یک بیمار از روی userId خودش؛ با status اختیاری (بیمار فقط باید
// نتایج «تکمیل‌شده» را ببیند — الزام شماره ۵)
export async function getLabResultsByPatientUser(userId, { status } = {}) {
  // آزمایش‌های متصل به پیش‌نویس پرونده صحی هنوز برای بیمار دیده نمی‌شوند
  const conditions = ["p.userId = ?", "NOT EXISTS (SELECT 1 FROM medical_records dr WHERE dr.id = l.recordId AND dr.status = 'draft')"];
  const params = [userId];
  if (status) {
    conditions.push("l.status = ?");
    params.push(status);
  }
  const [rows] = await db.query(
    `SELECT l.*, d.fullName AS doctorName
     FROM lab_results l
     JOIN patients p ON l.patientId = p.id
     LEFT JOIN doctors d ON l.doctorId = d.id
     WHERE ${conditions.join(" AND ")}
     ORDER BY l.createdAt ASC, l.id ASC`,
    params
  );
  return rows;
}

// یک نتیجه‌ی مشخص، فقط اگر واقعاً متعلق به همین کاربر (بیمار) باشد — برای دانلود امن گزارش
export async function getLabResultByIdForPatientUser(id, userId) {
  const [rows] = await db.query(
    `SELECT l.*, d.fullName AS doctorName
     FROM lab_results l
     JOIN patients p ON l.patientId = p.id
     LEFT JOIN doctors d ON l.doctorId = d.id
     WHERE l.id = ? AND p.userId = ?
       AND NOT EXISTS (SELECT 1 FROM medical_records dr WHERE dr.id = l.recordId AND dr.status = 'draft')`,
    [id, userId]
  );
  return rows[0] || null;
}

export async function updateLabResult(id, { testName, result, unit, referenceRange, status, testDate }) {
  await db.query(
    `UPDATE lab_results SET
       testName = COALESCE(?, testName),
       result = COALESCE(?, result),
       unit = COALESCE(?, unit),
       referenceRange = COALESCE(?, referenceRange),
       status = COALESCE(?, status),
       testDate = COALESCE(?, testDate)
     WHERE id = ?`,
    [testName ?? null, result ?? null, unit ?? null, referenceRange ?? null, status ?? null, testDate ?? null, id]
  );
  return getLabResultById(id);
}

// اتصال فایل گزارش آپلودشده به یک نتیجه‌ی آزمایش مشخص
export async function setLabReportUrl(id, reportUrl) {
  await db.query("UPDATE lab_results SET reportUrl = ? WHERE id = ?", [reportUrl, id]);
  return getLabResultById(id);
}

export async function deleteLabResult(id) {
  await db.query("DELETE FROM lab_results WHERE id = ?", [id]);
}

// آزمایش‌های متصل به یک ویزیت/پرونده صحی مشخص (برای گزارش کامل پرونده)
export async function getLabResultsByRecordId(recordId, { onlyCompleted = false } = {}) {
  const [rows] = await db.query(
    `SELECT l.*, d.fullName AS doctorName
     FROM lab_results l
     LEFT JOIN doctors d ON l.doctorId = d.id
     WHERE l.recordId = ? ${onlyCompleted ? "AND l.status = 'completed'" : ""}
     ORDER BY l.id ASC`,
    [recordId]
  );
  return rows;
}

import db from "../db.js";

export async function createRadiologyReport({ patientId, doctorId, recordId, examType, findings, impression, imageUrl, examDate }) {
  const [result] = await db.query(
    `INSERT INTO radiology_reports (patientId, doctorId, recordId, examType, findings, impression, imageUrl, examDate)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [patientId, doctorId || null, recordId || null, examType, findings || null, impression || null, imageUrl || null, examDate || null]
  );
  return getRadiologyReportById(result.insertId);
}

export async function getRadiologyReportById(id) {
  const [rows] = await db.query(
    `SELECT r.*, d.fullName AS doctorName
     FROM radiology_reports r
     LEFT JOIN doctors d ON r.doctorId = d.id
     WHERE r.id = ?`,
    [id]
  );
  return rows[0] || null;
}

export async function getRadiologyReportsByPatientId(patientId) {
  const [rows] = await db.query(
    `SELECT r.*, d.fullName AS doctorName
     FROM radiology_reports r
     LEFT JOIN doctors d ON r.doctorId = d.id
     WHERE r.patientId = ?
     ORDER BY r.createdAt ASC, r.id ASC`,
    [patientId]
  );
  return rows;
}

export async function getRadiologyReportsByPatientUser(userId) {
  const [rows] = await db.query(
    `SELECT r.*, d.fullName AS doctorName
     FROM radiology_reports r
     JOIN patients p ON r.patientId = p.id
     LEFT JOIN doctors d ON r.doctorId = d.id
     WHERE p.userId = ?
     ORDER BY r.createdAt ASC, r.id ASC`,
    [userId]
  );
  return rows;
}

export async function updateRadiologyReport(id, { examType, findings, impression, imageUrl, examDate }) {
  await db.query(
    `UPDATE radiology_reports SET
       examType = COALESCE(?, examType),
       findings = COALESCE(?, findings),
       impression = COALESCE(?, impression),
       imageUrl = COALESCE(?, imageUrl),
       examDate = COALESCE(?, examDate)
     WHERE id = ?`,
    [examType ?? null, findings ?? null, impression ?? null, imageUrl ?? null, examDate ?? null, id]
  );
  return getRadiologyReportById(id);
}

export async function deleteRadiologyReport(id) {
  await db.query("DELETE FROM radiology_reports WHERE id = ?", [id]);
}

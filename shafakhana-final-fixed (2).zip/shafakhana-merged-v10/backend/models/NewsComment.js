import db from "../db.js";

// ---------- عمومی: نظرات تاییدشده‌ی یک خبر (برای نمایش زیر خبر) ----------
export async function getApprovedComments(newsId) {
  const [rows] = await db.query(
    `SELECT nc.id, nc.newsId, nc.content, nc.createdAt, nc.adminReply, nc.adminReplyAt, u.fullName AS authorName
     FROM news_comments nc
     JOIN users u ON u.id = nc.userId
     WHERE nc.newsId = ? AND nc.status = 'approved' AND nc.deletedAt IS NULL
     ORDER BY nc.createdAt DESC`,
    [newsId]
  );
  return rows;
}

export async function countApprovedComments(newsId) {
  const [[{ count }]] = await db.query(
    "SELECT COUNT(*) AS count FROM news_comments WHERE newsId = ? AND status = 'approved' AND deletedAt IS NULL",
    [newsId]
  );
  return Number(count) || 0;
}

// جلوگیری ساده از اسپم: آیا همین کاربر همین متن را همین الان (چند ثانیه‌ی اخیر) روی همین
// خبر ارسال کرده؟ جلوی ارسال تکراری با چند بار کلیک سریع روی دکمه‌ی ارسال را می‌گیرد.
export async function hasRecentDuplicateComment(newsId, userId, content) {
  const [rows] = await db.query(
    `SELECT id FROM news_comments
     WHERE newsId = ? AND userId = ? AND content = ? AND createdAt >= (NOW() - INTERVAL 60 SECOND)
     LIMIT 1`,
    [newsId, userId, content]
  );
  return rows.length > 0;
}

export async function createComment({ newsId, userId, content, rating = null }) {
  const [result] = await db.query(
    "INSERT INTO news_comments (newsId, userId, content, rating, status) VALUES (?, ?, ?, ?, 'pending')",
    [newsId, userId, content, rating]
  );
  return getCommentById(result.insertId);
}

// نظرهای حذف‌شده (حذف نرم) به‌صورت پیش‌فرض یافت نمی‌شوند؛ فقط بازگردانی/مشاهده با includeDeleted
export async function getCommentById(id, { includeDeleted = false } = {}) {
  const [rows] = await db.query(
    `SELECT nc.*, u.fullName AS authorName, n.title AS newsTitle
     FROM news_comments nc
     JOIN users u ON u.id = nc.userId
     JOIN news n ON n.id = nc.newsId
     WHERE nc.id = ? ${includeDeleted ? "" : "AND nc.deletedAt IS NULL"}`,
    [id]
  );
  return rows[0] || null;
}

// ---------- مدیریت ادمین ----------
// فهرست صفحه‌بندی‌شده‌ی نظرات برای «مرکز مدیریت نظرات» ادمین. همه‌ی فیلترها/جستجو/مرتب‌سازی
// سمت دیتابیس‌اند و فقط ردیف‌های همین صفحه برمی‌گردند؛ متن نظر در لیست به یک «خلاصه» (preview)
// کوتاه می‌شود و متن کامل از getCommentDetail (انتخاب یک نظر در پنل جزئیات) گرفته می‌شود.
// فیلترها: status (pending|approved|rejected|deleted)، newsId، rating (۱ تا ۵)، q (نام/ایمیل نویسنده،
// متن نظر، عنوان خبر)، dateFrom/dateTo.
// حذف «نرم» است: deletedAt پر می‌شود (نظر از سایت عمومی و آمار وضعیت‌ها خارج می‌شود ولی برای ادمین
// می‌ماند و قابل بازگردانی است). وضعیت نمایشی (status) برای ردیف حذف‌شده «deleted» است و
// وضعیت اصلی قبل از حذف در rawStatus می‌ماند.
export const COMMENT_STATUSES = ["pending", "approved", "rejected"];
export const COMMENT_SORTS = ["newest", "oldest", "pending_first", "highest", "lowest"];
const PREVIEW_LENGTH = 160;
const DISPLAY_STATUS = "IF(nc.deletedAt IS NULL, nc.status, 'deleted')";

// کاراکترهای ویژه‌ی LIKE (% _ \\) escape می‌شوند تا جستجوی «50%» یا «a_b» معنای خاص پیدا نکند
function escapeLike(term) {
  return term.replace(/[\\%_]/g, (ch) => "\\" + ch);
}

function buildCommentWhere({ status, newsId, rating, q, dateFrom, dateTo } = {}) {
  const conditions = [];
  const params = [];
  if (status === "deleted") {
    conditions.push("nc.deletedAt IS NOT NULL");
  } else if (status && COMMENT_STATUSES.includes(status)) {
    conditions.push("nc.status = ?", "nc.deletedAt IS NULL");
    params.push(status);
  }
  if (newsId) {
    conditions.push("nc.newsId = ?");
    params.push(newsId);
  }
  if (rating) {
    conditions.push("nc.rating = ?");
    params.push(rating);
  }
  const term = (q || "").trim().slice(0, 100);
  if (term) {
    const like = `%${escapeLike(term)}%`;
    conditions.push("(u.fullName LIKE ? OR u.email LIKE ? OR nc.content LIKE ? OR n.title LIKE ?)");
    params.push(like, like, like, like);
  }
  if (dateFrom) {
    conditions.push("nc.createdAt >= ?");
    params.push(`${dateFrom} 00:00:00`);
  }
  if (dateTo) {
    conditions.push("nc.createdAt < DATE_ADD(?, INTERVAL 1 DAY)");
    params.push(dateTo);
  }
  return { whereClause: conditions.length ? `WHERE ${conditions.join(" AND ")}` : "", params };
}

const COMMENT_ORDER = {
  newest: "nc.createdAt DESC, nc.id DESC",
  oldest: "nc.createdAt ASC, nc.id ASC",
  pending_first: "(nc.status = 'pending' AND nc.deletedAt IS NULL) DESC, nc.createdAt DESC, nc.id DESC",
  highest: "(nc.rating IS NULL) ASC, nc.rating DESC, nc.createdAt DESC, nc.id DESC",
  lowest: "(nc.rating IS NULL) ASC, nc.rating ASC, nc.createdAt DESC, nc.id DESC",
};

export async function getCommentsAdminPage({ page = 1, limit = 20, sort = "newest", ...filters } = {}) {
  const { whereClause, params } = buildCommentWhere(filters);
  const safeLimit = Math.min(Math.max(parseInt(limit, 10) || 20, 1), 100);
  const safePage = Math.max(parseInt(page, 10) || 1, 1);
  const orderBy = COMMENT_ORDER[sort] || COMMENT_ORDER.newest;

  // هر دو کوئری یک JOIN ثابت (بدون N+1) دارند
  const [[{ total }]] = await db.query(
    `SELECT COUNT(*) AS total
     FROM news_comments nc
     JOIN users u ON u.id = nc.userId
     JOIN news n ON n.id = nc.newsId
     ${whereClause}`,
    params
  );
  const [rows] = await db.query(
    `SELECT nc.id, nc.newsId, nc.userId, ${DISPLAY_STATUS} AS status, nc.status AS rawStatus, nc.rating, nc.createdAt,
            LEFT(nc.content, ${PREVIEW_LENGTH}) AS preview, CHAR_LENGTH(nc.content) AS contentLength,
            (nc.adminReply IS NOT NULL) AS hasReply,
            u.fullName AS authorName, u.email AS authorEmail, u.photoUrl AS authorPhotoUrl,
            n.title AS newsTitle
     FROM news_comments nc
     JOIN users u ON u.id = nc.userId
     JOIN news n ON n.id = nc.newsId
     ${whereClause}
     ORDER BY ${orderBy}
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, (safePage - 1) * safeLimit]
  );
  const totalNum = Number(total) || 0;
  return {
    comments: rows.map((r) => ({ ...r, hasReply: !!r.hasReply })),
    pagination: { page: safePage, limit: safeLimit, total: totalNum, totalPages: Math.max(Math.ceil(totalNum / safeLimit), 1) },
  };
}

// جزئیات کامل یک نظر برای پنل کناری (شامل نظر حذف‌شده)
export async function getCommentDetail(id) {
  const [rows] = await db.query(
    `SELECT nc.id, nc.newsId, nc.userId, nc.content, ${DISPLAY_STATUS} AS status, nc.status AS rawStatus, nc.rating,
            nc.adminReply, nc.adminReplyAt, nc.internalNote, nc.deletedAt, nc.createdAt, nc.updatedAt,
            u.fullName AS authorName, u.email AS authorEmail, u.photoUrl AS authorPhotoUrl,
            n.title AS newsTitle, n.status AS newsStatus, n.imageUrl AS newsImageUrl
     FROM news_comments nc
     JOIN users u ON u.id = nc.userId
     JOIN news n ON n.id = nc.newsId
     WHERE nc.id = ?`,
    [id]
  );
  return rows[0] || null;
}

// آمار کارت‌های بالای صفحه (همه از دیتابیس، در یک کوئری). total = همه‌ی نظرها (شامل حذف‌شده‌ها)؛
// سه وضعیت دیگر فقط نظرهای حذف‌نشده را می‌شمارند، پس pending + approved + rejected + deleted = total
export async function getCommentStats() {
  const [[row]] = await db.query(
    `SELECT COUNT(*) AS total,
            COALESCE(SUM(deletedAt IS NULL AND status = 'pending'), 0) AS pending,
            COALESCE(SUM(deletedAt IS NULL AND status = 'approved'), 0) AS approved,
            COALESCE(SUM(deletedAt IS NULL AND status = 'rejected'), 0) AS rejected,
            COALESCE(SUM(deletedAt IS NOT NULL), 0) AS deleted
     FROM news_comments`
  );
  const n = (v) => Number(v) || 0;
  return { total: n(row.total), pending: n(row.pending), approved: n(row.approved), rejected: n(row.rejected), deleted: n(row.deleted) };
}

// گزینه‌های فیلتر «خبر»: فقط خبرهایی که نظر دارند، به ترتیب آخرین نظر (سقف ۱۰۰ مورد) + تعداد نظرات
export async function getNewsOptionsWithComments({ q } = {}) {
  const term = (q || "").trim().slice(0, 100);
  const params = [];
  let where = "";
  if (term) {
    where = "WHERE n.title LIKE ?";
    params.push(`%${escapeLike(term)}%`);
  }
  const [rows] = await db.query(
    `SELECT n.id, n.title, COUNT(*) AS commentsCount
     FROM news_comments nc
     JOIN news n ON n.id = nc.newsId
     ${where}
     GROUP BY n.id, n.title
     ORDER BY MAX(nc.createdAt) DESC
     LIMIT 100`,
    params
  );
  return rows.map((r) => ({ ...r, commentsCount: Number(r.commentsCount) || 0 }));
}

// نظرهای حذف‌شده پیش‌فرض نادیده گرفته می‌شوند (تأیید/رد/حذف گروهی فقط روی نظرهای فعال)
export async function getCommentsByIds(ids, { includeDeleted = false } = {}) {
  if (!ids.length) return [];
  const [rows] = await db.query(
    `SELECT nc.*, u.fullName AS authorName, n.title AS newsTitle
     FROM news_comments nc
     JOIN users u ON u.id = nc.userId
     JOIN news n ON n.id = nc.newsId
     WHERE nc.id IN (?) ${includeDeleted ? "" : "AND nc.deletedAt IS NULL"}`,
    [ids]
  );
  return rows;
}

export async function bulkUpdateCommentStatus(ids, status) {
  if (!ids.length) return 0;
  const [result] = await db.query("UPDATE news_comments SET status = ? WHERE id IN (?) AND deletedAt IS NULL", [status, ids]);
  return result.affectedRows;
}

// حذف نرم گروهی: فقط deletedAt پر می‌شود؛ خبر و خودِ ردیف نظر باقی می‌ماند
export async function bulkDeleteComments(ids) {
  if (!ids.length) return 0;
  const [result] = await db.query("UPDATE news_comments SET deletedAt = NOW() WHERE id IN (?) AND deletedAt IS NULL", [ids]);
  return result.affectedRows;
}

// ویرایش فیلدهای مدیریتی: متن نظر، پاسخ ادمین (خالی = حذف پاسخ)، یادداشت داخلی (خالی = پاک)
export async function updateCommentFields(id, { content, adminReply, internalNote }) {
  const sets = [];
  const params = [];
  if (content !== undefined) {
    sets.push("content = ?");
    params.push(content);
  }
  if (adminReply !== undefined) {
    const reply = adminReply ? adminReply : null;
    sets.push("adminReply = ?", reply ? "adminReplyAt = NOW()" : "adminReplyAt = NULL");
    params.push(reply);
  }
  if (internalNote !== undefined) {
    sets.push("internalNote = ?");
    params.push(internalNote ? internalNote : null);
  }
  if (!sets.length) return;
  await db.query(`UPDATE news_comments SET ${sets.join(", ")} WHERE id = ?`, [...params, id]);
}

export async function restoreComment(id) {
  await db.query("UPDATE news_comments SET deletedAt = NULL WHERE id = ?", [id]);
}

export async function countPendingComments() {
  const [[{ count }]] = await db.query(
    "SELECT COUNT(*) AS count FROM news_comments WHERE status = 'pending' AND deletedAt IS NULL"
  );
  return Number(count) || 0;
}

export async function updateCommentStatus(id, status) {
  await db.query("UPDATE news_comments SET status = ? WHERE id = ?", [status, id]);
  return getCommentById(id);
}

// حذف نرم (Soft Delete): نظر از سایت عمومی برداشته می‌شود ولی در پنل ادمین (وضعیت «حذف شده») می‌ماند
export async function deleteComment(id) {
  await db.query("UPDATE news_comments SET deletedAt = NOW() WHERE id = ? AND deletedAt IS NULL", [id]);
}

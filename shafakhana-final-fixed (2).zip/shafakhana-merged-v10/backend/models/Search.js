import db from "../db.js";
import { scoreRow, queryVariants } from "../utils/fuzzySearch.js";

// مدل جستجوی سراسری — پشت GET /api/search؛ روی ۷ جدول (داکتران، بخش‌ها، خدمات،
// تخصص‌ها، اخبار، مقالات، ادویه) جستجو می‌کند.
//
// معماری (به‌روزشده برای پشتیبانی از جستجوی جزئی + فازی + رتبه‌بندی + هایلایت):
//   ۱) یک استعلام LIKE %term% روی ستون‌های قابل‌جستجوی هر جدول، «کاندیدهای» اولیه
//      را واکشی می‌کند (سقف بیشتر از سقف نهایی نتایج، تا فضای کافی برای رتبه‌بندی باشد).
//   ۲) اگر تعداد کاندیدها کم بود (یعنی احتمال غلط‌املایی در عبارت کاربر وجود دارد)،
//      یک استعلام دوم و گسترده‌تر بدون شرط LIKE واکشی می‌شود تا لایه‌ی تطبیق فازی
//      (utils/fuzzySearch.js) بتواند غلط‌های تایپی را هم پیدا کند — MySQL به‌تنهایی
//      (بدون افزونه‌ی جانبی) فاصله‌ی ویرایشی را پشتیبانی نمی‌کند، پس این بخش در
//      لایه‌ی برنامه (Node) انجام می‌شود.
//   ۳) نتایج دو مرحله با هم یکتاسازی (بر اساس id) و توسط scoreRow امتیازدهی می‌شوند؛
//      امتیاز صفر یعنی هیچ تطابق معناداری نبود و آن ردیف حذف می‌شود.
//   ۴) نتایج بر اساس امتیاز مرتب و به سقف نهایی (RESULT_LIMIT_PER_CATEGORY) بریده می‌شوند.
//
// امنیت: تمام مقادیر ورودی کاربر همیشه به‌صورت پارامتر (placeholder ?) به mysql2
// پاس داده می‌شوند، نه با concatenation در رشته‌ی SQL — در برابر SQL Injection محافظت‌شده است.

export const RESULT_LIMIT_PER_CATEGORY = 6;

// سقف کاندیدهای مرحله‌ی LIKE — بیشتر از سقف نهایی تا رتبه‌بندی فازی گزینه‌ی کافی داشته باشد.
const CANDIDATE_LIMIT = 30;

// سقف اسکن گسترده (fallback فازی) — فقط وقتی کاندیدهای LIKE کم باشند اجرا می‌شود.
const FUZZY_SCAN_LIMIT = 400;

// اجرای یک جستجوی کاندید-محور: مرحله‌ی LIKE + (در صورت نیاز) مرحله‌ی fallback فازی،
// سپس امتیازدهی/رتبه‌بندی/هایلایت با scoreRow. common helper که همه‌ی توابع
// searchXxx زیر از آن استفاده می‌کنند تا منطق تکرار نشود.
async function runSearch({ table, columns, likeColumns, fieldConfigs, buildOutput, extraWhere = "", extraParams = [], orderBy = "", term }) {
  const where = extraWhere ? `AND ${extraWhere}` : "";
  const selectCols = columns.join(", ");

  // چند شکل از عبارت (اصلی، نرمال‌شده‌ی دری، شکل عربی ي/ك) — تا مهم نباشد کاربر با
  // کیبورد دری/پشتو/عربی تایپ کرده یا داده‌ها با کدام شکل ذخیره شده‌اند.
  const likeValues = queryVariants(term).map((v) => `%${v.replace(/[\\%_]/g, "\\$&")}%`);
  const likeConditions = likeColumns
    .flatMap((c) => likeValues.map(() => `${c} LIKE ?`))
    .join(" OR ");

  const [candidateRows] = await db.query(
    `SELECT ${selectCols}
     FROM ${table}
     WHERE (${likeConditions}) ${where}
     ${orderBy}
     LIMIT ?`,
    [...likeColumns.flatMap(() => likeValues), ...extraParams, CANDIDATE_LIMIT]
  );

  const merged = new Map(candidateRows.map((row) => [row.id, row]));

  // اگر کاندیدهای دقیق/جزئی کافی نبودند، احتمال غلط‌املایی وجود دارد — یک اسکن
  // گسترده‌تر بدون فیلتر LIKE انجام بده تا لایه‌ی فازی بتواند تایپوها را هم بیابد.
  if (merged.size < RESULT_LIMIT_PER_CATEGORY) {
    const [fuzzyPoolRows] = await db.query(
      `SELECT ${selectCols}
       FROM ${table}
       WHERE 1=1 ${where}
       ${orderBy}
       LIMIT ?`,
      [...extraParams, FUZZY_SCAN_LIMIT]
    );
    for (const row of fuzzyPoolRows) {
      if (!merged.has(row.id)) merged.set(row.id, row);
    }
  }

  const ranked = [];
  for (const row of merged.values()) {
    const { score, highlights } = scoreRow(row, fieldConfigs, term);
    if (score <= 0) continue;
    ranked.push({ row, score, highlights });
  }

  // مرتب‌سازی نزولی بر اساس امتیاز؛ در تساوی امتیاز، ترتیب اصلی SQL (rating/name/تاریخ)
  // به‌صورت پایدار (stable sort) حفظ می‌شود چون Array.prototype.sort در Node پایدار است.
  ranked.sort((a, b) => b.score - a.score);

  return ranked.slice(0, RESULT_LIMIT_PER_CATEGORY).map(({ row, highlights }) => buildOutput(row, highlights));
}

function withHighlights(base, highlights) {
  if (highlights.title) base.titleHighlight = highlights.title;
  if (highlights.subtitle) base.subtitleHighlight = highlights.subtitle;
  return base;
}

async function searchDoctors(term) {
  return runSearch({
    table: "doctors",
    columns: ["id", "fullName", "department", "bio", "yearsExperience"],
    likeColumns: ["fullName", "department", "bio"],
    fieldConfigs: [
      { key: "fullName", weight: 3, out: "title" },
      { key: "department", weight: 1.6, out: "subtitle" },
      { key: "bio", weight: 0.6, out: null },
    ],
    orderBy: "ORDER BY rating DESC",
    term,
    buildOutput: (row, highlights) =>
      withHighlights(
        {
          id: row.id,
          title: row.fullName,
          subtitle: row.department,
          meta: `${row.yearsExperience} سال تجربه`,
        },
        highlights
      ),
  });
}

async function searchDepartments(term) {
  return runSearch({
    table: "departments",
    columns: ["id", "name", "description"],
    likeColumns: ["name", "description"],
    fieldConfigs: [
      { key: "name", weight: 3, out: "title" },
      { key: "description", weight: 1.6, out: "subtitle" },
    ],
    orderBy: "ORDER BY name ASC",
    term,
    buildOutput: (row, highlights) =>
      withHighlights({ id: row.id, title: row.name, subtitle: row.description, meta: null }, highlights),
  });
}

async function searchServices(term) {
  return runSearch({
    table: "services",
    columns: ["id", "name", "description", "department"],
    likeColumns: ["name", "description"],
    fieldConfigs: [
      { key: "name", weight: 3, out: "title" },
      { key: "description", weight: 1.6, out: "subtitle" },
    ],
    orderBy: "ORDER BY name ASC",
    term,
    buildOutput: (row, highlights) =>
      withHighlights({ id: row.id, title: row.name, subtitle: row.description, meta: row.department }, highlights),
  });
}

async function searchSpecialties(term) {
  return runSearch({
    table: "specialties",
    columns: ["id", "name", "description"],
    likeColumns: ["name", "description"],
    fieldConfigs: [
      { key: "name", weight: 3, out: "title" },
      { key: "description", weight: 1.6, out: "subtitle" },
    ],
    orderBy: "ORDER BY name ASC",
    term,
    buildOutput: (row, highlights) =>
      withHighlights({ id: row.id, title: row.name, subtitle: row.description, meta: null }, highlights),
  });
}

async function searchMedicines(term) {
  return runSearch({
    table: "medicines",
    columns: ["id", "name", "genericName", "description", "requiresPrescription"],
    likeColumns: ["name", "genericName", "description"],
    fieldConfigs: [
      { key: "name", weight: 3, out: "title" },
      { key: "genericName", weight: 1.2, out: null },
      { key: "description", weight: 1, out: "subtitle" },
    ],
    orderBy: "ORDER BY name ASC",
    term,
    buildOutput: (row, highlights) =>
      withHighlights(
        {
          id: row.id,
          title: row.name,
          subtitle: row.description,
          meta: row.requiresPrescription === 1 ? "نیازمند نسخه" : "بدون نسخه",
        },
        highlights
      ),
  });
}

// شرط قابل‌مشاهده‌بودن عمومی خبر/مقاله — دقیقاً همان قانونی که models/News.js -> getAllNews
// برای فهرست عمومی اخبار استفاده می‌کند، تا جستجو هرگز پیش‌نویس/زمان‌بندی‌نشده را لو ندهد.
const NEWS_VISIBLE_SQL =
  "(status = 'published' OR (status = 'scheduled' AND scheduledAt IS NOT NULL AND scheduledAt <= NOW()))";

async function searchNews(term) {
  return runSearch({
    table: "news",
    columns: ["id", "title", "excerpt", "tag"],
    likeColumns: ["title", "excerpt", "tag"],
    fieldConfigs: [
      { key: "title", weight: 3, out: "title" },
      { key: "excerpt", weight: 1.6, out: "subtitle" },
      { key: "tag", weight: 1, out: null },
    ],
    extraWhere: `type = 'news' AND ${NEWS_VISIBLE_SQL}`,
    orderBy: "ORDER BY publishedAt DESC",
    term,
    buildOutput: (row, highlights) =>
      withHighlights({ id: row.id, title: row.title, subtitle: row.excerpt, meta: row.tag }, highlights),
  });
}

async function searchArticles(term) {
  return runSearch({
    table: "news",
    columns: ["id", "title", "excerpt", "tag"],
    likeColumns: ["title", "excerpt", "tag"],
    fieldConfigs: [
      { key: "title", weight: 3, out: "title" },
      { key: "excerpt", weight: 1.6, out: "subtitle" },
      { key: "tag", weight: 1, out: null },
    ],
    extraWhere: `type = 'article' AND ${NEWS_VISIBLE_SQL}`,
    orderBy: "ORDER BY publishedAt DESC",
    term,
    buildOutput: (row, highlights) =>
      withHighlights({ id: row.id, title: row.title, subtitle: row.excerpt, meta: row.tag }, highlights),
  });
}

// ترتیب و متادیتای دسته‌ها — دقیقاً هماهنگ با SEARCH_CATEGORIES در فرانت‌اند
// (components/search/searchData.js) تا کلیدهای JSON هر دو سمت یکسان باشند.
const CATEGORY_RUNNERS = [
  { key: "doctors", run: searchDoctors },
  { key: "departments", run: searchDepartments },
  { key: "services", run: searchServices },
  { key: "specialties", run: searchSpecialties },
  { key: "news", run: searchNews },
  { key: "articles", run: searchArticles },
  { key: "medicines", run: searchMedicines },
];

// جستجوی سراسری روی هر ۷ دسته به‌صورت موازی (Promise.all) — همه‌ی کوئری‌ها روی
// pool کانکشن مشترک اجرا می‌شوند، پس همزمانی مشکلی ایجاد نمی‌کند.
// خروجی: { doctors: [...], departments: [...], services: [...], specialties: [...],
//          news: [...], articles: [...], medicines: [...] }
// هر آیتم می‌تواند فیلدهای اختیاری titleHighlight/subtitleHighlight داشته باشد:
// آرایه‌ای از بازه‌های [start, end) که باید در فرانت‌اند هایلایت شوند (نتیجه‌ی
// جستجوی جزئی یا فازی/تحمل غلط‌املایی).
export async function searchGlobal(rawTerm) {
  const term = rawTerm.trim();

  const results = await Promise.all(CATEGORY_RUNNERS.map(({ run }) => run(term)));

  return Object.fromEntries(CATEGORY_RUNNERS.map(({ key }, i) => [key, results[i]]));
}

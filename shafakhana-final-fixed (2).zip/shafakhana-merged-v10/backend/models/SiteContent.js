import db from "../db.js";

// ذخیره‌ی محتوای قابل‌ویرایش سایت (JSON) در جدول site_content
export async function getSiteContent(key) {
  const [rows] = await db.query("SELECT value FROM site_content WHERE `key` = ?", [key]);
  if (!rows.length || !rows[0].value) return null;
  try {
    return JSON.parse(rows[0].value);
  } catch {
    return null;
  }
}

export async function setSiteContent(key, value) {
  const json = JSON.stringify(value);
  await db.query(
    "INSERT INTO site_content (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?",
    [key, json, json]
  );
}

export async function deleteSiteContent(key) {
  await db.query("DELETE FROM site_content WHERE `key` = ?", [key]);
}

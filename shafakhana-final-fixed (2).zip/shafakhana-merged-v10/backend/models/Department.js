import db from "../db.js";

// مقادیر مجاز برای فیلدهای نوعی (Enum) — برای اعتبارسنجی سمت مدل، مستقل از
// اعتبارسنجی سطح کنترلر/روت که در گام بعدی اضافه می‌شود
export const ICON_TYPES = ["upload", "lucide"];
export const DEPARTMENT_STATUSES = ["active", "inactive"];

// ساخت slug یکتا از روی نام بخش (لاتین/فارسی-دری) — برای لینک‌دهی در سایت عمومی.
// اگر کاربر خودش slug مشخص کرده باشد همان استفاده می‌شود؛ در غیر این صورت از name
// ساخته می‌شود. با پسوند عددی در صورت تداخل با بخش دیگر، یکتا نگه داشته می‌شود.
function slugify(text) {
  return String(text || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

async function buildUniqueSlug(desiredSlugOrName, excludeId = null) {
  const base = slugify(desiredSlugOrName) || "department";
  let candidate = base;
  let suffix = 1;
  // eslint-disable-next-line no-constant-condition
  while (true) {
    const params = excludeId ? [candidate, excludeId] : [candidate];
    const query = excludeId
      ? "SELECT id FROM departments WHERE slug = ? AND id != ?"
      : "SELECT id FROM departments WHERE slug = ?";
    const [clash] = await db.query(query, params);
    if (clash.length === 0) return candidate;
    suffix += 1;
    candidate = `${base}-${suffix}`;
  }
}

// در حالت پیش‌فرض (بدون آرگومان) همه‌ی بخش‌ها را برمی‌گرداند — رفتار قبلی، برای پنل
// «مدیریت بخش‌ها»ی ادمین و سایر مصرف‌کننده‌های داخلی (انتخاب‌گر بخش در فرم داکتران و
// فیلتر گزارش‌ها) دست‌نخورده می‌ماند. با publicOnly=true فقط بخش‌های فعال و
// «نمایش در سایت اصلی»=۱ برمی‌گردند — برای بخش «خدمات ما»ی صفحه‌ی عمومی.
export async function getAllDepartments({ publicOnly = false } = {}) {
  const where = publicOnly ? "WHERE status = 'active' AND showOnWebsite = 1" : "";
  const [rows] = await db.query(
    `SELECT * FROM departments ${where} ORDER BY displayOrder ASC, name ASC`
  );
  return rows;
}

export async function getDepartmentById(id) {
  const [rows] = await db.query("SELECT * FROM departments WHERE id = ?", [id]);
  return rows[0] || null;
}

export async function getDepartmentBySlug(slug) {
  const [rows] = await db.query("SELECT * FROM departments WHERE slug = ?", [slug]);
  return rows[0] || null;
}

// ثبت بخش جدید همراه با همه‌ی فیلدهای مدیریتی (آیکون/رنگ‌بندی/ترتیب/وضعیت/سئو).
// فیلدهای اختیاری در صورت عدم ارسال، مقدار پیش‌فرض ستون دیتابیس را می‌گیرند
// (سازگار با فراخوانی‌های قدیمی که فقط name/description می‌فرستادند).
export async function createDepartment({
  name, nameEn, description, descriptionEn,
  icon, iconType, iconColor, iconBackground, cardBackground, textColor,
  slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
}) {
  const finalSlug = await buildUniqueSlug(slug || name);

  const [result] = await db.query(
    `INSERT INTO departments
       (name, nameEn, description, descriptionEn, icon, iconType, iconColor, iconBackground, cardBackground, textColor,
        slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      name,
      nameEn || null,
      description || null,
      descriptionEn || null,
      icon || null,
      ICON_TYPES.includes(iconType) ? iconType : "lucide",
      iconColor || null,
      iconBackground || null,
      cardBackground || null,
      textColor || null,
      finalSlug,
      Number.isFinite(Number(displayOrder)) ? Number(displayOrder) : 0,
      DEPARTMENT_STATUSES.includes(status) ? status : "active",
      showOnWebsite === false || showOnWebsite === 0 ? 0 : 1,
      seoTitle || null,
      seoDescription || null,
    ]
  );
  return getDepartmentById(result.insertId);
}

// به‌روزرسانی جزئی/کامل بخش — فقط فیلدهایی که واقعاً ارسال شده‌اند (undefined نیستند)
// تغییر می‌کنند؛ بقیه‌ی مقادیر موجود دست‌نخورده باقی می‌مانند (سازگار با فراخوانی‌های
// قدیمی که فقط name/description می‌فرستادند).
export async function updateDepartment(id, fields) {
  const existing = await getDepartmentById(id);
  if (!existing) return null;

  const {
    name, nameEn, description, descriptionEn,
    icon, coverImage, iconType, iconColor, iconBackground, cardBackground, textColor,
    slug, displayOrder, status, showOnWebsite, seoTitle, seoDescription,
  } = fields;

  const finalSlug = slug !== undefined
    ? await buildUniqueSlug(slug || name || existing.name, id)
    : existing.slug;

  await db.query(
    `UPDATE departments SET
       name = ?, nameEn = ?, description = ?, descriptionEn = ?, icon = ?, coverImage = ?, iconType = ?, iconColor = ?, iconBackground = ?,
       cardBackground = ?, textColor = ?, slug = ?, displayOrder = ?, status = ?, showOnWebsite = ?,
       seoTitle = ?, seoDescription = ?
     WHERE id = ?`,
    [
      name !== undefined ? name : existing.name,
      nameEn !== undefined ? (nameEn || null) : existing.nameEn,
      description !== undefined ? (description || null) : existing.description,
      descriptionEn !== undefined ? (descriptionEn || null) : existing.descriptionEn,
      icon !== undefined ? (icon || null) : existing.icon,
      // عکس کاور فقط از مسیرهای آپلود/حذف اختصاصی (admin/departments.js) تغییر می‌کند، نه از body فرم
      coverImage !== undefined ? (coverImage || null) : existing.coverImage,
      iconType !== undefined ? (ICON_TYPES.includes(iconType) ? iconType : existing.iconType) : existing.iconType,
      iconColor !== undefined ? (iconColor || null) : existing.iconColor,
      iconBackground !== undefined ? (iconBackground || null) : existing.iconBackground,
      cardBackground !== undefined ? (cardBackground || null) : existing.cardBackground,
      textColor !== undefined ? (textColor || null) : existing.textColor,
      finalSlug,
      displayOrder !== undefined ? (Number.isFinite(Number(displayOrder)) ? Number(displayOrder) : existing.displayOrder) : existing.displayOrder,
      status !== undefined ? (DEPARTMENT_STATUSES.includes(status) ? status : existing.status) : existing.status,
      showOnWebsite !== undefined ? (showOnWebsite === false || showOnWebsite === 0 ? 0 : 1) : existing.showOnWebsite,
      seoTitle !== undefined ? (seoTitle || null) : existing.seoTitle,
      seoDescription !== undefined ? (seoDescription || null) : existing.seoDescription,
      id,
    ]
  );
  return getDepartmentById(id);
}

export async function deleteDepartment(id) {
  await db.query("DELETE FROM departments WHERE id = ?", [id]);
}

// ستون‌های مجاز برای مرتب‌سازی در پنل «مدیریت بخش‌ها» — whitelist، برای جلوگیری از
// SQL Injection از طریق پارامتر sortBy (هرگز نام ستون مستقیماً از ورودی کاربر گرفته نمی‌شود)
const SORTABLE_COLUMNS = {
  name: "name",
  displayOrder: "displayOrder",
  status: "status",
  createdAt: "createdAt",
};

// جستجو + فیلتر وضعیت + مرتب‌سازی + صفحه‌بندی برای پنل مدیریت بخش‌ها (همان الگوی
// searchDoctors/searchPatients در Doctor.js/Patient.js؛ رفتار پیش‌فرض بدون پارامتر
// (getAllDepartments) برای سایر مصرف‌کننده‌ها — مثل انتخاب‌گر بخش در فرم داکتران و
// فیلتر گزارش‌ها — دست‌نخورده باقی می‌ماند).
export async function searchDepartments({ q, status, sortBy, sortOrder, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const conditions = [];
  const params = [];

  // جستجو روی نام/توضیحات/نامک بخش
  if (q && q.trim()) {
    const like = `%${q.trim()}%`;
    conditions.push("(name LIKE ? OR nameEn LIKE ? OR description LIKE ? OR slug LIKE ?)");
    params.push(like, like, like, like);
  }

  if (status && DEPARTMENT_STATUSES.includes(status)) {
    conditions.push("status = ?");
    params.push(status);
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const column = SORTABLE_COLUMNS[sortBy] || "displayOrder";
  const order = String(sortOrder).toUpperCase() === "DESC" ? "DESC" : "ASC";
  // ستون ثانویه‌ی name برای ترتیب پایدار/قابل‌پیش‌بینی وقتی مقادیر ستون اصلی برابرند
  const orderClause = column === "name" ? `name ${order}` : `${column} ${order}, name ASC`;

  const [rows] = await db.query(
    `SELECT * FROM departments ${where} ORDER BY ${orderClause} LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );
  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count FROM departments ${where}`,
    params
  );

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

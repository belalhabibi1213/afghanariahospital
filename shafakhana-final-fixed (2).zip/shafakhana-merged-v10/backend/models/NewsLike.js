import db from "../db.js";

// تعداد کل لایک‌های یک خبر — برای نمایش در صفحه عمومی «ادامه مطلب»
export async function countNewsLikes(newsId) {
  const [[{ count }]] = await db.query(
    "SELECT COUNT(*) AS count FROM news_likes WHERE newsId = ?",
    [newsId]
  );
  return Number(count) || 0;
}

// آیا این کاربر قبلاً همین خبر را لایک کرده؟ (برای نمایش وضعیت دکمه‌ی لایک به خودش)
export async function hasUserLikedNews(newsId, userId) {
  const [rows] = await db.query(
    "SELECT id FROM news_likes WHERE newsId = ? AND userId = ?",
    [newsId, userId]
  );
  return rows.length > 0;
}

// فهرست شناسه‌ی همه‌ی خبرهایی که یک کاربر لایک کرده — برای فهرست عمومی اخبار (صفحه‌ی
// اصلی) استفاده می‌شود تا وضعیت لایک هر کارت با یک پرس‌وجوی واحد (به‌جای N پرس‌وجو به
// ازای هر خبر) مشخص شود.
export async function getLikedNewsIdsByUser(userId) {
  const [rows] = await db.query("SELECT newsId FROM news_likes WHERE userId = ?", [userId]);
  return rows.map((r) => r.newsId);
}

// ثبت لایک — به لطف ایندکس یکتای (newsId, userId) حتی اگر هم‌زمان دوبار درخواست ارسال شود
// (مثلاً دو کلیک سریع)، هرگز بیش از یک ردیف لایک برای همان کاربر/خبر ذخیره نمی‌شود
export async function addNewsLike(newsId, userId) {
  await db.query(
    "INSERT IGNORE INTO news_likes (newsId, userId) VALUES (?, ?)",
    [newsId, userId]
  );
  return countNewsLikes(newsId);
}

// برداشتن لایک (Unlike)
export async function removeNewsLike(newsId, userId) {
  await db.query("DELETE FROM news_likes WHERE newsId = ? AND userId = ?", [newsId, userId]);
  return countNewsLikes(newsId);
}

import { getPool } from "../db.js";
import { computeStatus } from "./Invoice.js";
import { round2 } from "../utils/money.js";

export const PAYMENT_METHODS = ["cash", "card", "bank_transfer", "insurance", "other"];

// ثبت یک پرداخت روی فاکتور (الزام شماره ۲: ثبت پرداخت‌ها) و به‌روزرسانی خودکار
// مبلغ پرداخت‌شده و وضعیت فاکتور (الزام شماره ۳: نمایش وضعیت پرداخت) در یک تراکنش
// دیتابیسی با قفل ردیف (FOR UPDATE) تا پرداخت‌های هم‌زمان باعث ناهماهنگی نشوند.
export async function recordPayment(invoiceId, { amount, method, paidAt, reference, notes, receivedByUserId }) {
  const pool = await getPool();
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [invoiceRows] = await conn.query("SELECT * FROM invoices WHERE id = ? FOR UPDATE", [invoiceId]);
    const invoice = invoiceRows[0];
    if (!invoice) {
      await conn.rollback();
      return { error: "NOT_FOUND" };
    }
    if (invoice.status === "cancelled") {
      await conn.rollback();
      return { error: "INVOICE_CANCELLED" };
    }

    const currentPaid = Number(invoice.paidAmount);
    const total = Number(invoice.totalAmount);
    const newPaid = round2(currentPaid + Number(amount));
    if (newPaid > total + 0.01) {
      await conn.rollback();
      return { error: "OVERPAYMENT", remaining: round2(total - currentPaid) };
    }

    const [result] = await conn.query(
      `INSERT INTO payments (invoiceId, amount, method, paidAt, reference, notes, receivedByUserId)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [invoiceId, amount, method || "cash", paidAt || new Date(), reference || null, notes || null, receivedByUserId || null]
    );

    const newStatus = computeStatus(total, newPaid);
    await conn.query("UPDATE invoices SET paidAmount = ?, status = ? WHERE id = ?", [newPaid, newStatus, invoiceId]);

    await conn.commit();
    return { paymentId: result.insertId, paidAmount: newPaid, status: newStatus };
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    conn.release();
  }
}

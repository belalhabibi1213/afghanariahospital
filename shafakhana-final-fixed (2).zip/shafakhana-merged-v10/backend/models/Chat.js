import db from "../db.js";

// ---------- ماژول «گفتگوی خصوصی بیمار ↔ داکتر» ----------
// هر مکالمه بین یک جفت (بیمار، داکتر) یکتاست. پیام‌ها فقط متنی هستند.

// پیش‌نمایشِ «آخرین پیام» در فهرست مکالمه‌ها: اگر پیام متن دارد همان متن نشان داده
// می‌شود؛ اگر پیام صوتی است (بدون متن) به‌جای رشته‌ی خالی «🎤 پیام صوتی» نشان داده
// می‌شود؛ اگر پیوستِ دیگری (عکس/سند) بدون متن است «📎 پیوست» نشان داده می‌شود.
const LAST_MESSAGE_PREVIEW_SQL = `
  SELECT CASE
    WHEN m.content IS NOT NULL AND m.content != '' THEN m.content
    WHEN m.attachmentFileType LIKE 'audio/%' THEN '🎤 پیام صوتی'
    WHEN m.attachmentFileName IS NOT NULL THEN '📎 پیوست'
    ELSE m.content
  END
  FROM chat_messages m WHERE m.conversationId = c.id ORDER BY m.createdAt DESC LIMIT 1
`;

// مکالمه‌ی موجود بین این بیمار و داکتر را برمی‌گرداند، یا در صورت نبود، یک مکالمه‌ی
// جدید می‌سازد. از UNIQUE KEY (patientId, doctorId) برای جلوگیری از رکورد تکراری
// در شرایط همزمانی (race condition) استفاده می‌شود.
export async function getOrCreateConversation(patientId, doctorId) {
  const existing = await getConversationByPatientAndDoctor(patientId, doctorId);
  if (existing) return existing;

  try {
    const [result] = await db.query(
      "INSERT INTO chat_conversations (patientId, doctorId) VALUES (?, ?)",
      [patientId, doctorId]
    );
    return getConversationById(result.insertId);
  } catch (err) {
    // اگر هم‌زمان درخواست دیگری همین مکالمه را ساخته باشد (نقض UNIQUE KEY)،
    // به‌جای شکست، همان رکورد موجود را برمی‌گردانیم
    if (err.code === "ER_DUP_ENTRY") {
      return getConversationByPatientAndDoctor(patientId, doctorId);
    }
    throw err;
  }
}

export async function getConversationByPatientAndDoctor(patientId, doctorId) {
  const [rows] = await db.query(
    "SELECT * FROM chat_conversations WHERE patientId = ? AND doctorId = ? LIMIT 1",
    [patientId, doctorId]
  );
  return rows[0] || null;
}

export async function getConversationById(id) {
  const [rows] = await db.query(
    `SELECT c.*, p.fullName AS patientName, p.userId AS patientUserId, d.fullName AS doctorName, d.userId AS doctorUserId
     FROM chat_conversations c
     JOIN patients p ON c.patientId = p.id
     JOIN doctors d ON c.doctorId = d.id
     WHERE c.id = ?`,
    [id]
  );
  return rows[0] || null;
}

// فهرست مکالمه‌های یک بیمار (بر اساس patientId)، همراه با نام داکتر، آخرین پیام
// و تعداد پیام‌های خوانده‌نشده‌ی ارسالی توسط داکتر
export async function getConversationsForPatient(patientId) {
  const [rows] = await db.query(
    `SELECT c.*, d.fullName AS doctorName, d.photoUrl AS doctorPhotoUrl, d.department AS doctorDepartment,
       (${LAST_MESSAGE_PREVIEW_SQL}) AS lastMessage,
       (SELECT m.createdAt FROM chat_messages m WHERE m.conversationId = c.id ORDER BY m.createdAt DESC LIMIT 1) AS lastMessageAt,
       (SELECT COUNT(*) FROM chat_messages m WHERE m.conversationId = c.id AND m.senderRole != 'user' AND m.isRead = 0) AS unreadCount
     FROM chat_conversations c
     JOIN doctors d ON c.doctorId = d.id
     WHERE c.patientId = ?
     ORDER BY (lastMessageAt IS NULL), lastMessageAt DESC, c.createdAt DESC`,
    [patientId]
  );
  return rows;
}

// فهرست مکالمه‌های یک داکتر (بر اساس doctorId)، همراه با نام بیمار، آخرین پیام
// و تعداد پیام‌های خوانده‌نشده‌ی ارسالی توسط بیمار
export async function getConversationsForDoctor(doctorId) {
  const [rows] = await db.query(
    `SELECT c.*, p.fullName AS patientName, p.phone AS patientPhone,
       (${LAST_MESSAGE_PREVIEW_SQL}) AS lastMessage,
       (SELECT m.createdAt FROM chat_messages m WHERE m.conversationId = c.id ORDER BY m.createdAt DESC LIMIT 1) AS lastMessageAt,
       (SELECT COUNT(*) FROM chat_messages m WHERE m.conversationId = c.id AND m.senderRole = 'user' AND m.isRead = 0) AS unreadCount
     FROM chat_conversations c
     JOIN patients p ON c.patientId = p.id
     WHERE c.doctorId = ?
     ORDER BY (lastMessageAt IS NULL), lastMessageAt DESC, c.createdAt DESC`,
    [doctorId]
  );
  return rows;
}

// پیام‌های یک مکالمه، صفحه‌بندی‌شده (جدیدترین در انتها، مناسب نمایش در یک پنجره‌ی چت)
// viewerUserId برای محاسبه‌ی فیلد «mine» در خلاصه‌ی واکنش‌های هر پیام استفاده می‌شود
// (یعنی آیا خودِ کاربر واردشده روی آن پیام واکنش زده یا نه)
export async function getMessagesByConversation(conversationId, { page = 1, limit = 30, viewerUserId } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 30));
  const offset = (safePage - 1) * safeLimit;

  const [rows] = await db.query(
    `SELECT m.*, u.fullName AS senderName
     FROM chat_messages m
     LEFT JOIN users u ON m.senderUserId = u.id
     WHERE m.conversationId = ?
     ORDER BY m.createdAt DESC
     LIMIT ? OFFSET ?`,
    [conversationId, safeLimit, offset]
  );

  const [countRows] = await db.query(
    "SELECT COUNT(*) AS count FROM chat_messages WHERE conversationId = ?",
    [conversationId]
  );
  const total = countRows[0].count;

  const orderedRows = rows.reverse(); // ترتیب زمانی صعودی برای نمایش در چت
  const reactionsByMessageId = await getReactionsForMessages(
    orderedRows.map((r) => r.id),
    viewerUserId
  );
  const withReactions = orderedRows.map((row) => ({
    ...row,
    reactions: reactionsByMessageId.get(row.id) || [],
  }));

  return {
    rows: withReactions.map(maskDeletedMessage),
    total,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(total / safeLimit)),
  };
}

// متن پیام‌های حذف‌شده (soft-delete) هرگز نباید به کلاینت فرستاده شود؛ این تابع فقط
// یک بار، درست قبل از پاسخ API، محتوای واقعی را با null جایگزین می‌کند. خودِ رکورد در
// دیتابیس دست‌نخورده باقی می‌ماند (برای گزارش/ممیزی احتمالی در آینده). پیوست (عکس/سند)
// یک پیام حذف‌شده هم باید مخفی شود — وگرنه لینک دانلود همچنان قابل‌دسترسی می‌ماند.
export function maskDeletedMessage(row) {
  if (!row || !row.isDeleted) return row;
  return {
    ...row,
    content: null,
    attachmentFileName: null,
    attachmentOriginalName: null,
    attachmentFileType: null,
    attachmentFileSize: null,
    attachmentDurationSeconds: null,
  };
}

export async function createMessage({ conversationId, senderUserId, senderRole, content }) {
  const [result] = await db.query(
    `INSERT INTO chat_messages (conversationId, senderUserId, senderRole, content)
     VALUES (?, ?, ?, ?)`,
    [conversationId, senderUserId, senderRole, content]
  );
  // آخرین زمان فعالیت مکالمه را هم به‌روزرسانی می‌کند تا فهرست مکالمه‌ها بر این اساس مرتب شود
  await db.query("UPDATE chat_conversations SET updatedAt = CURRENT_TIMESTAMP WHERE id = ?", [conversationId]);

  const [rows] = await db.query(
    `SELECT m.*, u.fullName AS senderName FROM chat_messages m LEFT JOIN users u ON m.senderUserId = u.id WHERE m.id = ?`,
    [result.insertId]
  );
  // پیام تازه‌ساخته‌شده به‌طور قطعی هنوز هیچ واکنشی ندارد
  return { ...rows[0], reactions: [] };
}

// پیامی که همراه با یک پیوست (عکس یا سند) ارسال می‌شود؛ content می‌تواند خالی باشد
// (یعنی فقط فایل، بدون متن) — ستون content در دیتابیس NOT NULL است، پس رشته‌ی خالی
// به‌جای null ذخیره می‌شود. اطلاعات پیوست از قبل توسط میان‌افزار آپلود (multer) اعتبارسنجی
// و روی دیسک با نام تصادفی امن ذخیره شده‌اند (backend/middleware/upload.js)؛ این تابع فقط
// همان اطلاعات را در رکورد پیام ثبت می‌کند.
export async function createMessageWithAttachment({ conversationId, senderUserId, senderRole, content, attachment }) {
  const [result] = await db.query(
    `INSERT INTO chat_messages
       (conversationId, senderUserId, senderRole, content,
        attachmentFileName, attachmentOriginalName, attachmentFileType, attachmentFileSize,
        attachmentDurationSeconds)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      conversationId, senderUserId, senderRole, content || "",
      attachment.fileName, attachment.originalName, attachment.fileType, attachment.fileSize,
      // فقط پیام صوتی مقدار دارد؛ برای عکس/سند همیشه undefined → NULL ذخیره می‌شود
      attachment.durationSeconds != null ? Math.round(attachment.durationSeconds) : null,
    ]
  );
  await db.query("UPDATE chat_conversations SET updatedAt = CURRENT_TIMESTAMP WHERE id = ?", [conversationId]);

  const [rows] = await db.query(
    `SELECT m.*, u.fullName AS senderName FROM chat_messages m LEFT JOIN users u ON m.senderUserId = u.id WHERE m.id = ?`,
    [result.insertId]
  );
  return { ...rows[0], reactions: [] };
}

// یک پیام را با شناسه‌ی آن برمی‌گرداند (بدون پنهان‌کردن محتوا) — برای بررسی مالکیت/دسترسی
// در کنترلر پیش از ویرایش یا حذف استفاده می‌شود
export async function getMessageById(id) {
  const [rows] = await db.query(
    `SELECT m.*, u.fullName AS senderName FROM chat_messages m LEFT JOIN users u ON m.senderUserId = u.id WHERE m.id = ?`,
    [id]
  );
  return rows[0] || null;
}

// ویرایش متن یک پیام موجود توسط فرستنده‌ی همان پیام (مالکیت در سطح کنترلر بررسی می‌شود)
export async function updateMessageContent(id, content) {
  await db.query(
    "UPDATE chat_messages SET content = ?, isEdited = 1, editedAt = CURRENT_TIMESTAMP WHERE id = ?",
    [content, id]
  );
  const message = await getMessageById(id);
  return maskDeletedMessage(message);
}

// حذف نرم (soft-delete) یک پیام: رکورد و متن اصلی در دیتابیس باقی می‌ماند، فقط isDeleted
// ست می‌شود؛ محتوای پاسخ‌داده‌شده به کلاینت با null جایگزین می‌شود (maskDeletedMessage)
export async function softDeleteMessage(id) {
  await db.query(
    "UPDATE chat_messages SET isDeleted = 1, deletedAt = CURRENT_TIMESTAMP WHERE id = ?",
    [id]
  );
  const message = await getMessageById(id);
  return maskDeletedMessage(message);
}

// همه‌ی پیام‌های «طرف مقابل» را در یک مکالمه به‌عنوان خوانده‌شده علامت می‌زند
// (مثلاً وقتی بیمار مکالمه را باز می‌کند، پیام‌های داکتر خوانده‌شده در نظر گرفته می‌شوند)
// خواندنِ یک پیام یعنی حتماً پیش‌تر هم به دستگاه گیرنده رسیده (تحویل شده)، پس isDelivered
// هم همزمان ست می‌شود — بدون این کار وضعیتِ نمایشی می‌توانست «خوانده‌شده ولی تحویل‌نشده» شود.
export async function markConversationRead(conversationId, readerRole) {
  await db.query(
    "UPDATE chat_messages SET isRead = 1, isDelivered = 1 WHERE conversationId = ? AND senderRole != ? AND isRead = 0",
    [conversationId, readerRole]
  );
}

// همه‌ی پیام‌های «طرف مقابل» را در تمام مکالمه‌های یک کاربر (بیمار یا داکتر) به‌عنوان
// «تحویل‌شده» علامت می‌زند — بدون اینکه آن‌ها را خوانده‌شده کند. این تابع هر بار که
// فهرست مکالمه‌ها بارگذاری می‌شود (یعنی کلاینتِ گیرنده با سرور همگام شده و پیام تازه
// حداقل به برنامه‌اش رسیده) فراخوانی می‌شود؛ خواندنِ واقعی همچنان فقط با بازکردنِ خودِ
// مکالمه (markConversationRead) رخ می‌دهد. isDelivered یک‌طرفه است: هرگز به عقب برنمی‌گردد.
export async function markAllConversationsDelivered(viewerRole, viewerId) {
  if (viewerRole === "user") {
    await db.query(
      `UPDATE chat_messages m
       JOIN chat_conversations c ON m.conversationId = c.id
       SET m.isDelivered = 1
       WHERE c.patientId = ? AND m.senderRole != 'user' AND m.isDelivered = 0`,
      [viewerId]
    );
  } else if (viewerRole === "doctor") {
    await db.query(
      `UPDATE chat_messages m
       JOIN chat_conversations c ON m.conversationId = c.id
       SET m.isDelivered = 1
       WHERE c.doctorId = ? AND m.senderRole = 'user' AND m.isDelivered = 0`,
      [viewerId]
    );
  }
}

// ---------- واکنش‌های ایموجی روی پیام‌ها ----------
// هر کاربر حداکثر یک واکنش فعال روی هر پیام دارد (UNIQUE KEY messageId+userId در دیتابیس).
// زدن دوباره‌ی همان ایموجی، واکنش را حذف می‌کند؛ زدن ایموجی دیگر آن را جایگزین می‌کند.
export async function toggleMessageReaction({ messageId, userId, emoji }) {
  const [existingRows] = await db.query(
    "SELECT * FROM chat_message_reactions WHERE messageId = ? AND userId = ?",
    [messageId, userId]
  );
  const existing = existingRows[0] || null;

  if (existing && existing.emoji === emoji) {
    // همان ایموجی قبلی دوباره انتخاب شده: واکنش برداشته می‌شود (toggle off)
    await db.query("DELETE FROM chat_message_reactions WHERE id = ?", [existing.id]);
  } else if (existing) {
    // ایموجی دیگری انتخاب شده: واکنش قبلی جایگزین می‌شود (نه یک ردیف جدید)
    await db.query("UPDATE chat_message_reactions SET emoji = ? WHERE id = ?", [emoji, existing.id]);
  } else {
    // اولین واکنش این کاربر روی این پیام
    try {
      await db.query(
        "INSERT INTO chat_message_reactions (messageId, userId, emoji) VALUES (?, ?, ?)",
        [messageId, userId, emoji]
      );
    } catch (err) {
      // محافظت در برابر شرایط رقابتی (دو درخواست هم‌زمان از همان کاربر): در صورت نقض
      // UNIQUE KEY، به‌جای شکست، همان واکنش موجود را به‌روزرسانی می‌کند
      if (err.code === "ER_DUP_ENTRY") {
        await db.query(
          "UPDATE chat_message_reactions SET emoji = ? WHERE messageId = ? AND userId = ?",
          [emoji, messageId, userId]
        );
      } else {
        throw err;
      }
    }
  }

  return getReactionsForMessage(messageId, userId);
}

// خلاصه‌ی واکنش‌های یک پیام: تعداد هر نوع ایموجی + اینکه آیا کاربر واردشده خودش
// روی آن واکنش زده یا نه (mine) — برای نمایش زیر حباب پیام
export async function getReactionsForMessage(messageId, viewerUserId) {
  const [rows] = await db.query(
    "SELECT emoji, userId FROM chat_message_reactions WHERE messageId = ?",
    [messageId]
  );
  return summarizeReactions(rows, viewerUserId);
}

// همان خلاصه‌سازی بالا اما برای چند پیام هم‌زمان (یک کوئری واحد به‌جای N کوئری جدا،
// وقتی فهرست پیام‌های یک مکالمه بارگذاری می‌شود)
export async function getReactionsForMessages(messageIds, viewerUserId) {
  const result = new Map();
  if (!messageIds || messageIds.length === 0) return result;

  const [rows] = await db.query(
    "SELECT messageId, emoji, userId FROM chat_message_reactions WHERE messageId IN (?)",
    [messageIds]
  );

  const grouped = new Map();
  for (const row of rows) {
    if (!grouped.has(row.messageId)) grouped.set(row.messageId, []);
    grouped.get(row.messageId).push(row);
  }
  for (const id of messageIds) {
    result.set(id, summarizeReactions(grouped.get(id) || [], viewerUserId));
  }
  return result;
}

// ردیف‌های خام (emoji, userId) را به فهرست {emoji, count, mine} تبدیل می‌کند
function summarizeReactions(rows, viewerUserId) {
  const byEmoji = new Map();
  for (const row of rows) {
    if (!byEmoji.has(row.emoji)) byEmoji.set(row.emoji, { emoji: row.emoji, count: 0, mine: false });
    const entry = byEmoji.get(row.emoji);
    entry.count += 1;
    if (row.userId === viewerUserId) entry.mine = true;
  }
  return Array.from(byEmoji.values());
}

import db from "../db.js";

export async function createPrescription({ patientId, doctorId, recordId, appointmentId, diagnosis, medicationName, dosage, frequency, duration, quantity, medicineNotes, instructions, followUpDate, notes, groupId }) {
  const [result] = await db.query(
    `INSERT INTO prescriptions (patientId, doctorId, recordId, appointmentId, diagnosis, medicationName, dosage, frequency, duration, quantity, medicineNotes, instructions, followUpDate, notes, groupId)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      patientId,
      doctorId || null,
      recordId || null,
      appointmentId || null,
      diagnosis || null,
      medicationName,
      dosage || null,
      frequency || null,
      duration || null,
      quantity || null,
      medicineNotes || null,
      instructions || null,
      followUpDate || null,
      notes || null,
      groupId || null,
    ]
  );
  return getPrescriptionById(result.insertId);
}

// همه‌ی داروهای یک «نسخه» (چند دارو که در یک بار ثبت نوشته شده‌اند) برای چاپ PDF.
// فقط رکوردهای همان بیمار و همان داکتر با groupId یکسان؛ نسخه‌های قدیمی بدون groupId فقط خودشان را برمی‌گردانند.
export async function getPrescriptionsByGroup(prescription) {
  if (!prescription.groupId) return [prescription];
  const [rows] = await db.query(
    `SELECT pr.*, d.fullName AS doctorName, d.doctorCode AS doctorCode, d.signatureUrl AS doctorSignatureUrl, d.department AS doctorDepartment,
            p.fullName AS patientName, p.gender AS patientGender, p.dateOfBirth AS patientDateOfBirth, p.publicCode AS patientCode
     FROM prescriptions pr
     LEFT JOIN doctors d ON pr.doctorId = d.id
     LEFT JOIN patients p ON pr.patientId = p.id
     WHERE pr.groupId = ? AND pr.patientId = ? AND (pr.doctorId <=> ?)
     ORDER BY pr.id ASC`,
    [prescription.groupId, prescription.patientId, prescription.doctorId ?? null]
  );
  return rows.length > 0 ? rows : [prescription];
}

export async function getPrescriptionById(id) {
  const [rows] = await db.query(
    `SELECT pr.*, d.fullName AS doctorName, d.doctorCode AS doctorCode, d.signatureUrl AS doctorSignatureUrl, d.department AS doctorDepartment,
            p.fullName AS patientName, p.gender AS patientGender, p.dateOfBirth AS patientDateOfBirth, p.publicCode AS patientCode,
            a.appointmentDate, a.appointmentTime, a.department
     FROM prescriptions pr
     LEFT JOIN doctors d ON pr.doctorId = d.id
     LEFT JOIN patients p ON pr.patientId = p.id
     LEFT JOIN appointments a ON pr.appointmentId = a.id
     WHERE pr.id = ?`,
    [id]
  );
  return rows[0] || null;
}

// همان رکورد بالا، اما فقط اگر واقعاً متعلق به همین بیمار واردشده باشد
// (برای دانلود PDF نسخه توسط خودِ بیمار — همان الگوی getLabResultByIdForPatientUser)
export async function getPrescriptionByIdForPatientUser(id, userId) {
  const [rows] = await db.query(
    `SELECT pr.*, d.fullName AS doctorName, d.doctorCode AS doctorCode, d.signatureUrl AS doctorSignatureUrl, d.department AS doctorDepartment,
            p.fullName AS patientName, p.gender AS patientGender, p.dateOfBirth AS patientDateOfBirth, p.publicCode AS patientCode,
            a.appointmentDate, a.appointmentTime, a.department
     FROM prescriptions pr
     JOIN patients p ON pr.patientId = p.id
     LEFT JOIN doctors d ON pr.doctorId = d.id
     LEFT JOIN appointments a ON pr.appointmentId = a.id
     WHERE pr.id = ? AND p.userId = ?`,
    [id, userId]
  );
  return rows[0] || null;
}

// همه‌ی نسخه‌های یک بیمار (تاریخچه‌ی کامل نسخه‌ها — الزام شماره ۴)
export async function getPrescriptionsByPatientId(patientId) {
  const [rows] = await db.query(
    `SELECT pr.*, d.fullName AS doctorName, a.appointmentDate, a.appointmentTime, a.department
     FROM prescriptions pr
     LEFT JOIN doctors d ON pr.doctorId = d.id
     LEFT JOIN appointments a ON pr.appointmentId = a.id
     WHERE pr.patientId = ?
     ORDER BY pr.createdAt ASC, pr.id ASC`,
    [patientId]
  );
  return rows;
}

export async function getPrescriptionsByPatientUser(userId) {
  const [rows] = await db.query(
    `SELECT pr.*, d.fullName AS doctorName, a.appointmentDate, a.appointmentTime, a.department
     FROM prescriptions pr
     JOIN patients p ON pr.patientId = p.id
     LEFT JOIN doctors d ON pr.doctorId = d.id
     LEFT JOIN appointments a ON pr.appointmentId = a.id
     WHERE p.userId = ?
     ORDER BY pr.createdAt ASC, pr.id ASC`,
    [userId]
  );
  return rows;
}

// همه‌ی داروهای ثبت‌شده برای یک نوبت مشخص — یعنی «نسخه»ی کامل آن ویزیت
// (ممکن است شامل چند دوا با دوز/مدت/دستور جداگانه باشد) — الزام شماره ۵: اتصال نسخه به نوبت
export async function getPrescriptionsByAppointmentId(appointmentId) {
  const [rows] = await db.query(
    `SELECT pr.*, d.fullName AS doctorName, p.fullName AS patientName, p.phone AS patientPhone,
            a.appointmentDate, a.appointmentTime, a.department
     FROM prescriptions pr
     JOIN patients p ON pr.patientId = p.id
     LEFT JOIN doctors d ON pr.doctorId = d.id
     LEFT JOIN appointments a ON pr.appointmentId = a.id
     WHERE pr.appointmentId = ?
     ORDER BY pr.createdAt ASC`,
    [appointmentId]
  );
  return rows;
}

// همان لیست بالا، اما فقط اگر آن نوبت واقعاً متعلق به کاربر واردشده باشد
// (برای مشاهده/چاپ نسخه توسط خودِ بیمار — الزام شماره ۳)
export async function getPrescriptionsByAppointmentForPatientUser(appointmentId, userId) {
  const [rows] = await db.query(
    `SELECT pr.*, d.fullName AS doctorName, p.fullName AS patientName,
            a.appointmentDate, a.appointmentTime, a.department
     FROM prescriptions pr
     JOIN patients p ON pr.patientId = p.id
     LEFT JOIN doctors d ON pr.doctorId = d.id
     LEFT JOIN appointments a ON pr.appointmentId = a.id
     WHERE pr.appointmentId = ? AND p.userId = ?
     ORDER BY pr.createdAt ASC`,
    [appointmentId, userId]
  );
  return rows;
}

export async function updatePrescription(id, { diagnosis, medicationName, dosage, frequency, duration, quantity, medicineNotes, instructions, followUpDate, notes, groupId }) {
  await db.query(
    `UPDATE prescriptions SET
       diagnosis = COALESCE(?, diagnosis),
       medicationName = COALESCE(?, medicationName),
       dosage = COALESCE(?, dosage),
       frequency = COALESCE(?, frequency),
       duration = COALESCE(?, duration),
       quantity = COALESCE(?, quantity),
       medicineNotes = COALESCE(?, medicineNotes),
       instructions = COALESCE(?, instructions),
       followUpDate = COALESCE(?, followUpDate),
       notes = COALESCE(?, notes),
       groupId = COALESCE(?, groupId)
     WHERE id = ?`,
    [
      diagnosis ?? null,
      medicationName ?? null,
      dosage ?? null,
      frequency ?? null,
      duration ?? null,
      quantity ?? null,
      medicineNotes ?? null,
      instructions ?? null,
      followUpDate ?? null,
      notes ?? null,
      groupId ?? null,
      id,
    ]
  );
  return getPrescriptionById(id);
}

export async function deletePrescription(id) {
  await db.query("DELETE FROM prescriptions WHERE id = ?", [id]);
}

// ===========================================================================
// پنل ادمین «نسخه و سوابق طبی» — فهرست/آمار/وضعیت نسخه‌ها
// ---------------------------------------------------------------------------
// هر «نسخه» در دیتابیس چند ردیف (هر دارو یک ردیف) با groupId مشترک است. این توابع،
// ردیف‌ها را با همان قاعده‌ی getPrescriptionsByGroup (بیمار + داکتر + groupId؛ ردیف‌های
// قدیمیِ بدون groupId هر کدام یک نسخه) به یک «نسخه» تبدیل می‌کنند. هیچ جدول یا ستون
// موجودی تغییر نمی‌کند؛ فقط ستون جدید status (migration غیرمخرب) خوانده/نوشته می‌شود.
// ===========================================================================

export const PRESCRIPTION_STATUSES = ["active", "completed", "cancelled"];

// شماره‌ی نسخه = RX- + شناسه‌ی اولین دارویِ آن نسخه (۶ رقمی). وضعیت هر نسخه = وضعیت اولین
// ردیف آن؛ تغییر وضعیت (setPrescriptionGroupStatus) همه‌ی ردیف‌های گروه را با هم به‌روز می‌کند.
const PRESCRIPTION_GROUPS_SQL = `
  SELECT MIN(pr.id) AS id,
         CONCAT('RX-', LPAD(MIN(pr.id), 6, '0')) AS rxNumber,
         pr.patientId,
         pr.doctorId,
         MIN(pr.createdAt) AS createdAt,
         COUNT(*) AS itemCount,
         SUBSTRING_INDEX(GROUP_CONCAT(pr.status ORDER BY pr.id SEPARATOR ','), ',', 1) AS status,
         GROUP_CONCAT(pr.medicationName ORDER BY pr.id SEPARATOR '، ') AS medicineNames,
         MAX(pr.diagnosis) AS diagnosis,
         MAX(pr.groupId) AS groupId,
         MAX(p.fullName) AS patientName,
         MAX(p.publicCode) AS patientCode,
         MAX(d.fullName) AS doctorName,
         MAX(d.doctorCode) AS doctorCode,
         MAX(d.department) AS doctorDepartment
  FROM prescriptions pr
  JOIN patients p ON pr.patientId = p.id
  LEFT JOIN doctors d ON pr.doctorId = d.id
  GROUP BY pr.patientId, pr.doctorId, COALESCE(pr.groupId, CONCAT('single-', pr.id))
`;

// ارقام فارسی/عربی را به لاتین تبدیل می‌کند تا جستجوی «شماره نسخه» با هر کیبوردی کار کند
function normalizeDigits(text) {
  return String(text)
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x0660));
}

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

export async function searchPrescriptionGroups({ q, status, doctorId, patientId, patientUserId, dateFrom, dateTo, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const conditions = [];
  const params = [];

  const term = normalizeDigits((q || "").trim());
  if (term) {
    const like = `%${term}%`;
    const isNumeric = /^\d+$/.test(term);
    conditions.push(
      isNumeric
        ? "(g.patientName LIKE ? OR g.doctorName LIKE ? OR g.rxNumber LIKE ? OR g.patientCode LIKE ? OR g.id = ?)"
        : "(g.patientName LIKE ? OR g.doctorName LIKE ? OR g.rxNumber LIKE ? OR g.patientCode LIKE ?)"
    );
    params.push(like, like, like, like);
    if (isNumeric) params.push(Number(term));
  }

  if (PRESCRIPTION_STATUSES.includes(status)) {
    conditions.push("g.status = ?");
    params.push(status);
  } else if (status === "past") {
    // «نسخه‌های قبلی» در پنل بیمار: هر نسخه‌ای که دیگر در حال اجرا نیست (تکمیل‌شده یا لغوشده)
    conditions.push("g.status <> 'active'");
  }

  const doctorIdNum = parseInt(doctorId, 10);
  if (Number.isInteger(doctorIdNum) && doctorIdNum > 0) {
    conditions.push("g.doctorId = ?");
    params.push(doctorIdNum);
  }

  // فیلتر بیمار (پنل داکتر) — پارامتر اختیاری است و برای پنل ادمین بی‌اثر می‌ماند
  const patientIdNum = parseInt(patientId, 10);
  if (Number.isInteger(patientIdNum) && patientIdNum > 0) {
    conditions.push("g.patientId = ?");
    params.push(patientIdNum);
  }

  // پنل بیمار: فقط نسخه‌های بیمارانی که به همین حساب کاربری وصل‌اند (مالکیت در SQL بررسی می‌شود).
  // این پارامتر هرگز از ورودی کلاینت گرفته نمی‌شود؛ کنترلر آن را از توکن (req.user.id) پر می‌کند.
  const patientUserIdNum = parseInt(patientUserId, 10);
  if (Number.isInteger(patientUserIdNum) && patientUserIdNum > 0) {
    conditions.push("g.patientId IN (SELECT id FROM patients WHERE userId = ?)");
    params.push(patientUserIdNum);
  }

  if (typeof dateFrom === "string" && ISO_DATE.test(dateFrom)) {
    conditions.push("DATE(g.createdAt) >= ?");
    params.push(dateFrom);
  }
  if (typeof dateTo === "string" && ISO_DATE.test(dateTo)) {
    conditions.push("DATE(g.createdAt) <= ?");
    params.push(dateTo);
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT g.* FROM (${PRESCRIPTION_GROUPS_SQL}) g ${where}
     ORDER BY g.createdAt ASC, g.id ASC LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );
  const [[{ total }]] = await db.query(
    `SELECT COUNT(*) AS total FROM (${PRESCRIPTION_GROUPS_SQL}) g ${where}`,
    params
  );

  return { rows, total, page: safePage, limit: safeLimit, totalPages: Math.max(1, Math.ceil(total / safeLimit)) };
}

// آمار کل نسخه‌ها (بدون وابستگی به فیلترهای جستجو) برای کارت‌های بالای صفحه
// پارامتر اختیاری doctorId: پنل داکتر فقط آمار نسخه‌های خودش را می‌گیرد؛ بدون آن (ادمین) آمار کل است
export async function getPrescriptionStats({ doctorId } = {}) {
  const doctorIdNum = parseInt(doctorId, 10);
  const scoped = Number.isInteger(doctorIdNum) && doctorIdNum > 0;
  const [rows] = await db.query(
    `SELECT g.status AS status, COUNT(*) AS count FROM (${PRESCRIPTION_GROUPS_SQL}) g ${scoped ? "WHERE g.doctorId = ?" : ""} GROUP BY g.status`,
    scoped ? [doctorIdNum] : []
  );
  const stats = { total: 0, active: 0, completed: 0, cancelled: 0 };
  for (const row of rows) {
    const count = Number(row.count) || 0;
    stats.total += count;
    if (row.status in stats) stats[row.status] += count;
  }
  return stats;
}

// وضعیت را برای همه‌ی داروهای همین نسخه (همان قاعده‌ی getPrescriptionsByGroup) تغییر می‌دهد
export async function setPrescriptionGroupStatus(prescription, status) {
  if (prescription.groupId) {
    await db.query(
      "UPDATE prescriptions SET status = ? WHERE groupId = ? AND patientId = ? AND (doctorId <=> ?)",
      [status, prescription.groupId, prescription.patientId, prescription.doctorId ?? null]
    );
  } else {
    await db.query("UPDATE prescriptions SET status = ? WHERE id = ?", [status, prescription.id]);
  }
  return getPrescriptionById(prescription.id);
}

// وضعیت نسخه‌ای که یک groupId مشخص دارد (برای قفل‌شدن ویرایش/افزودن دارو پس از «تکمیل» یا «لغو»).
// اگر هیچ رکوردی با این groupId نباشد null برمی‌گرداند.
export async function getGroupStatus(groupId, patientId) {
  if (!groupId) return null;
  const [rows] = await db.query(
    "SELECT status FROM prescriptions WHERE groupId = ? AND patientId = ? ORDER BY id ASC LIMIT 1",
    [groupId, patientId]
  );
  return rows[0] ? rows[0].status : null;
}

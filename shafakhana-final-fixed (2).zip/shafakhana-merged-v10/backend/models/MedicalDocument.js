import db from "../db.js";

// ===========================================================================
// فهرست یکپارچه‌ی «اسناد طبی» برای بخش «نسخه و سوابق طبی» (ادمین و داکتر)
// ---------------------------------------------------------------------------
// هیچ جدول یا ستون جدیدی ساخته نمی‌شود؛ این فایل فقط از جدول‌های موجود می‌خواند:
//   prescription → prescriptions (چند دارو با groupId مشترک = یک نسخه؛ همان قاعده‌ی Prescription.js)
//   record       → medical_records (سابقه‌ی صحی / ویزیت)
//   lab          → lab_results (نتیجه‌ی آزمایش)
//   imaging      → radiology_reports (تصویر پزشکی / رادیولوژی)
// همه‌ی جستجو، فیلتر، مرتب‌سازی و صفحه‌بندی در SQL انجام می‌شود (هرگز کل رکوردها بارگذاری نمی‌شوند).
//
// دامنه‌ی دسترسی (scope) را کنترلر تعیین می‌کند و هرگز از ورودی کلاینت نمی‌آید:
//   ادمین/سوپرادمین: scope = {}                      → همه‌ی اسناد (به‌جز پیش‌نویس‌های داکتر)
//   داکتر:           scope = { doctorId }            → فقط اسناد بیمارانی که نوبت «تأییدشده/انجام‌شده»
//                                                      با همین داکتر دارند (همان قاعده‌ی doctorHasConfirmedPatient)؛
//                                                      پیش‌نویس‌ها فقط اگر متعلق به خودش باشند.
// ===========================================================================

export const DOC_TYPES = ["prescription", "record", "lab", "imaging"];
export const DOC_STATUSES = ["active", "completed", "cancelled", "draft", "registered", "pending"];

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;
const SORT_COLUMNS = {
  date: "u.docDate",
  patient: "u.patientName",
  type: "u.docType",
  doctor: "u.doctorName",
  status: "u.status",
  number: "u.docNumber",
};

// ارقام فارسی/عربی → لاتین تا جستجو با هر کیبوردی کار کند
function normalizeDigits(text) {
  return String(text)
    .replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 0x0660));
}

// بخش مشترک شرط‌ها برای هر شاخه‌ی UNION. alias: نام جدول اصلی، dateCol: ستون تاریخ ثبت
function baseConditions(alias, dateCol, { scope, filters }) {
  const conds = [];
  const params = [];

  if (scope.doctorId) {
    // فقط بیماران مجازِ همین داکتر (نوبت تأییدشده/انجام‌شده)
    conds.push(
      `${alias}.patientId IN (SELECT a.patientId FROM appointments a WHERE a.doctorId = ? AND a.status IN ('confirmed','completed'))`
    );
    params.push(scope.doctorId);
  }

  const doctorIdNum = parseInt(filters.doctorId, 10);
  if (Number.isInteger(doctorIdNum) && doctorIdNum > 0) {
    conds.push(`${alias}.doctorId = ?`);
    params.push(doctorIdNum);
  }
  const patientIdNum = parseInt(filters.patientId, 10);
  if (Number.isInteger(patientIdNum) && patientIdNum > 0) {
    conds.push(`${alias}.patientId = ?`);
    params.push(patientIdNum);
  }
  if (typeof filters.dateFrom === "string" && ISO_DATE.test(filters.dateFrom)) {
    conds.push(`DATE(${alias}.${dateCol}) >= ?`);
    params.push(filters.dateFrom);
  }
  if (typeof filters.dateTo === "string" && ISO_DATE.test(filters.dateTo)) {
    conds.push(`DATE(${alias}.${dateCol}) <= ?`);
    params.push(filters.dateTo);
  }
  return { conds, params };
}

// هر شاخه یک SELECT با ستون‌های یکسان برمی‌گرداند
function branchSql(type, ctx) {
  const patientJoin = "JOIN patients p ON x.patientId = p.id";
  const doctorJoin = "LEFT JOIN doctors d ON x.doctorId = d.id";
  const common = `p.fullName AS patientName, p.publicCode AS patientCode, p.phone AS patientPhone, d.fullName AS doctorName`;

  if (type === "prescription") {
    const { conds, params } = baseConditions("x", "createdAt", ctx);
    // شرط‌ها روی ردیف‌های داروها اعمال می‌شوند؛ GROUP BY همان قاعده‌ی PRESCRIPTION_GROUPS_SQL است
    return {
      sql: `SELECT 'prescription' AS docType, MIN(x.id) AS id, x.patientId, x.doctorId,
                   MIN(x.createdAt) AS docDate,
                   SUBSTRING_INDEX(GROUP_CONCAT(x.status ORDER BY x.id SEPARATOR ','), ',', 1) AS status,
                   CONCAT('RX-', LPAD(MIN(x.id), 6, '0')) AS docNumber,
                   MAX(x.diagnosis) AS title,
                   MAX(p.fullName) AS patientName, MAX(p.publicCode) AS patientCode, MAX(p.phone) AS patientPhone,
                   MAX(d.fullName) AS doctorName, 1 AS hasFile
            FROM prescriptions x ${patientJoin} ${doctorJoin}
            ${conds.length ? `WHERE ${conds.join(" AND ")}` : ""}
            GROUP BY x.patientId, x.doctorId, COALESCE(x.groupId, CONCAT('single-', x.id))`,
      params,
    };
  }

  if (type === "record") {
    const { conds, params } = baseConditions("x", "createdAt", ctx);
    // پیش‌نویس فقط برای خودِ داکتر نویسنده قابل‌مشاهده است؛ ادمین هرگز پیش‌نویس نمی‌بیند
    if (ctx.scope.doctorId) {
      conds.push("(x.status <> 'draft' OR x.doctorId = ?)");
      params.push(ctx.scope.doctorId);
    } else {
      conds.push("x.status <> 'draft'");
    }
    return {
      sql: `SELECT 'record' AS docType, x.id, x.patientId, x.doctorId, x.createdAt AS docDate, x.status AS status,
                   CONCAT('MR-', LPAD(x.id, 6, '0')) AS docNumber,
                   COALESCE(NULLIF(x.diagnosis, ''), NULLIF(x.primaryDiagnosis, ''), NULLIF(x.visitReason, '')) AS title,
                   ${common}, 0 AS hasFile
            FROM medical_records x ${patientJoin} ${doctorJoin}
            WHERE ${conds.join(" AND ")}`,
      params,
    };
  }

  if (type === "lab") {
    const { conds, params } = baseConditions("x", "createdAt", ctx);
    return {
      sql: `SELECT 'lab' AS docType, x.id, x.patientId, x.doctorId, x.createdAt AS docDate, x.status AS status,
                   CONCAT('LAB-', LPAD(x.id, 6, '0')) AS docNumber, x.testName AS title,
                   ${common}, (x.reportUrl IS NOT NULL AND x.reportUrl <> '') AS hasFile
            FROM lab_results x ${patientJoin} ${doctorJoin}
            ${conds.length ? `WHERE ${conds.join(" AND ")}` : ""}`,
      params,
    };
  }

  // imaging — جدول radiology_reports ستون وضعیت ندارد؛ همه‌ی گزارش‌های موجود «ثبت‌شده» هستند
  const { conds, params } = baseConditions("x", "createdAt", ctx);
  return {
    sql: `SELECT 'imaging' AS docType, x.id, x.patientId, x.doctorId, x.createdAt AS docDate, 'registered' AS status,
                 CONCAT('IMG-', LPAD(x.id, 6, '0')) AS docNumber, x.examType AS title,
                 ${common}, 0 AS hasFile
          FROM radiology_reports x ${patientJoin} ${doctorJoin}
          ${conds.length ? `WHERE ${conds.join(" AND ")}` : ""}`,
    params,
  };
}

function buildUnion({ scope = {}, filters = {} } = {}) {
  const requested = DOC_TYPES.includes(filters.type) ? [filters.type] : DOC_TYPES;
  const parts = requested.map((t) => branchSql(t, { scope, filters }));
  return {
    sql: parts.map((p) => `(${p.sql})`).join(" UNION ALL "),
    params: parts.flatMap((p) => p.params),
  };
}

export async function searchMedicalDocuments({ scope = {}, q, type, status, doctorId, patientId, dateFrom, dateTo, sort, order, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const union = buildUnion({ scope, filters: { type, doctorId, patientId, dateFrom, dateTo } });

  const outer = [];
  const outerParams = [];

  const term = normalizeDigits((q || "").trim()).slice(0, 100);
  if (term) {
    const like = `%${term.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
    // «RX-123» / «lab 45» بدون صفرهای ابتدایی هم باید همان سند را پیدا کند
    const numberMatch = term.match(/^(RX|MR|LAB|IMG)[-\s]?(\d{1,10})$/i);
    const typeByPrefix = { RX: "prescription", MR: "record", LAB: "lab", IMG: "imaging" };
    const byNumber = numberMatch ? " OR (u.docType = ? AND u.id = ?)" : "";
    outer.push(
      `(u.patientName LIKE ? OR u.patientCode LIKE ? OR u.patientPhone LIKE ? OR u.docNumber LIKE ? OR u.doctorName LIKE ? OR u.title LIKE ?${byNumber})`
    );
    outerParams.push(like, like, like, like, like, like);
    if (numberMatch) outerParams.push(typeByPrefix[numberMatch[1].toUpperCase()], Number(numberMatch[2]));
  }
  if (DOC_STATUSES.includes(status)) {
    outer.push("u.status = ?");
    outerParams.push(status);
  }
  const where = outer.length ? `WHERE ${outer.join(" AND ")}` : "";

  const sortCol = SORT_COLUMNS[sort] || SORT_COLUMNS.date;
  const dir = String(order).toLowerCase() === "asc" ? "ASC" : "DESC";
  // ترتیب ثانویه‌ی ثابت تا صفحه‌بندی بین صفحه‌ها پایدار بماند
  const orderBy = `ORDER BY ${sortCol} ${dir}, u.docDate DESC, u.docType ASC, u.id DESC`;

  const [rows] = await db.query(
    `SELECT u.* FROM (${union.sql}) u ${where} ${orderBy} LIMIT ? OFFSET ?`,
    [...union.params, ...outerParams, safeLimit, offset]
  );
  const [[{ total }]] = await db.query(
    `SELECT COUNT(*) AS total FROM (${union.sql}) u ${where}`,
    [...union.params, ...outerParams]
  );

  return { rows, total: Number(total) || 0, page: safePage, limit: safeLimit, totalPages: Math.max(1, Math.ceil((Number(total) || 0) / safeLimit)) };
}

// ---------------------------------------------------------------------------
// فهرست «همه اسناد» برای پنل بیمار (نسخه + پرونده صحی) — جستجو، فیلتر نوع و صفحه‌بندی در SQL.
// مالکیت: patientUserId فقط از توکن می‌آید و همه‌ی شاخه‌ها روی p.userId = ? محدودند.
// پیش‌نویس پرونده‌های صحی هرگز به بیمار نمی‌رسد. هیچ شناسه‌ی داخلی بیمار/داکتر برگردانده نمی‌شود.
// ---------------------------------------------------------------------------
const MY_DOC_TYPES = ["prescription", "record"];

function myDocBranches(patientUserId) {
  return {
    prescription: {
      sql: `SELECT 'prescription' AS docType, MIN(x.id) AS id, MIN(x.createdAt) AS docDate,
                   SUBSTRING_INDEX(GROUP_CONCAT(x.status ORDER BY x.id SEPARATOR ','), ',', 1) AS status,
                   CONCAT('RX-', LPAD(MIN(x.id), 6, '0')) AS docNumber,
                   MAX(x.diagnosis) AS title, MAX(d.fullName) AS doctorName,
                   COUNT(*) AS itemCount, 0 AS released
            FROM prescriptions x
            JOIN patients p ON x.patientId = p.id
            LEFT JOIN doctors d ON x.doctorId = d.id
            WHERE p.userId = ?
            GROUP BY x.patientId, x.doctorId, COALESCE(x.groupId, CONCAT('single-', x.id))`,
      params: [patientUserId],
    },
    record: {
      sql: `SELECT 'record' AS docType, x.id AS id, COALESCE(x.visitDate, x.createdAt) AS docDate,
                   x.status AS status, CONCAT('MR-', LPAD(x.id, 6, '0')) AS docNumber,
                   COALESCE(NULLIF(x.diagnosis, ''), NULLIF(x.visitReason, '')) AS title, d.fullName AS doctorName,
                   0 AS itemCount, (x.sentToPatientAt IS NOT NULL) AS released
            FROM medical_records x
            JOIN patients p ON x.patientId = p.id
            LEFT JOIN doctors d ON x.doctorId = d.id
            WHERE p.userId = ? AND x.status <> 'draft'`,
      params: [patientUserId],
    },
  };
}

export async function searchMyDocuments({ patientUserId, q, type, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(50, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const branches = myDocBranches(patientUserId);
  const unionOf = (types) => ({
    sql: types.map((t) => `(${branches[t].sql})`).join(" UNION ALL "),
    params: types.flatMap((t) => branches[t].params),
  });

  const requested = MY_DOC_TYPES.includes(type) ? [type] : MY_DOC_TYPES;
  const union = unionOf(requested);

  const outer = [];
  const outerParams = [];
  const term = normalizeDigits((q || "").trim()).slice(0, 100);
  if (term) {
    const like = `%${term.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
    const numberMatch = term.match(/^(RX|MR)[-\s]?(\d{1,10})$/i);
    const byNumber = numberMatch ? " OR (u.docType = ? AND u.id = ?)" : "";
    outer.push(`(u.docNumber LIKE ? OR u.title LIKE ? OR u.doctorName LIKE ?${byNumber})`);
    outerParams.push(like, like, like);
    if (numberMatch) outerParams.push(numberMatch[1].toUpperCase() === "RX" ? "prescription" : "record", Number(numberMatch[2]));
  }
  const where = outer.length ? `WHERE ${outer.join(" AND ")}` : "";

  const [rows] = await db.query(
    `SELECT u.* FROM (${union.sql}) u ${where} ORDER BY u.docDate DESC, u.docType ASC, u.id DESC LIMIT ? OFFSET ?`,
    [...union.params, ...outerParams, safeLimit, offset]
  );
  const [[{ total }]] = await db.query(
    `SELECT COUNT(*) AS total FROM (${union.sql}) u ${where}`,
    [...union.params, ...outerParams]
  );

  // شمارنده‌ی تب‌ها: مستقل از جستجو و فیلتر نوع (کل اسناد خودِ بیمار)
  const all = unionOf(MY_DOC_TYPES);
  const [countRows] = await db.query(`SELECT u.docType AS docType, COUNT(*) AS n FROM (${all.sql}) u GROUP BY u.docType`, all.params);
  const counts = { prescription: 0, record: 0 };
  for (const r of countRows) counts[r.docType] = Number(r.n) || 0;

  const totalN = Number(total) || 0;
  return { rows, total: totalN, page: safePage, limit: safeLimit, totalPages: Math.max(1, Math.ceil(totalN / safeLimit)), counts };
}

// آمار کارت‌های بالای صفحه (مستقل از فیلترهای جستجو، ولی در همان دامنه‌ی دسترسی)
export async function getMedicalDocumentStats({ scope = {} } = {}) {
  const union = buildUnion({ scope, filters: {} });
  const [rows] = await db.query(
    `SELECT u.docType AS docType, COUNT(*) AS count FROM (${union.sql}) u GROUP BY u.docType`,
    union.params
  );
  const stats = { patients: 0, prescription: 0, record: 0, lab: 0, imaging: 0, total: 0 };
  for (const row of rows) {
    const n = Number(row.count) || 0;
    stats[row.docType] = n;
    stats.total += n;
  }

  if (scope.doctorId) {
    const [[row]] = await db.query(
      "SELECT COUNT(DISTINCT patientId) AS n FROM appointments WHERE doctorId = ? AND status IN ('confirmed','completed')",
      [scope.doctorId]
    );
    stats.patients = Number(row.n) || 0;
  } else {
    const [[row]] = await db.query("SELECT COUNT(*) AS n FROM patients");
    stats.patients = Number(row.n) || 0;
  }
  return stats;
}

// ---------------------------------------------------------------------------
// جزئیات یک سند. نتیجه شامل هیچ شناسه‌ی غیرضروری نیست؛ کنترلر پیش از فراخوانی
// مجوز بیمار را بررسی می‌کند (patientId سند را با getDocumentOwnerRef می‌گیرد).
// ---------------------------------------------------------------------------

async function getPatientCard(patientId) {
  const [rows] = await db.query(
    `SELECT id, fullName, phone, email, publicCode, gender, dateOfBirth FROM patients WHERE id = ?`,
    [patientId]
  );
  return rows[0] || null;
}

// فقط patientId/doctorId/status سند را می‌دهد تا کنترلر مجوز را بسنجد
export async function getDocumentOwnerRef(type, id) {
  const table = { prescription: "prescriptions", record: "medical_records", lab: "lab_results", imaging: "radiology_reports" }[type];
  if (!table) return null;
  const statusCol = type === "prescription" || type === "record" || type === "lab" ? ", status" : "";
  const [rows] = await db.query(`SELECT id, patientId, doctorId${statusCol} FROM ${table} WHERE id = ?`, [id]);
  return rows[0] || null;
}

export async function getMedicalDocumentDetail(type, id) {
  const ref = await getDocumentOwnerRef(type, id);
  if (!ref) return null;
  const patient = await getPatientCard(ref.patientId);

  if (type === "prescription") {
    const [firstRows] = await db.query(
      `SELECT pr.*, d.fullName AS doctorName, d.department AS doctorDepartment, d.doctorCode AS doctorCode
       FROM prescriptions pr LEFT JOIN doctors d ON pr.doctorId = d.id WHERE pr.id = ?`, [id]);
    const first = firstRows[0];
    const [items] = first.groupId
      ? await db.query(
          `SELECT id, medicationName, dosage, frequency, duration, quantity, medicineNotes FROM prescriptions
           WHERE groupId = ? AND patientId = ? AND (doctorId <=> ?) ORDER BY id ASC`,
          [first.groupId, first.patientId, first.doctorId ?? null]
        )
      : await db.query(
          `SELECT id, medicationName, dosage, frequency, duration, quantity, medicineNotes FROM prescriptions WHERE id = ?`, [id]);
    return {
      type, id: Number(id), docNumber: `RX-${String(items[0]?.id ?? id).padStart(6, "0")}`,
      status: first.status, createdAt: first.createdAt, patient,
      doctor: { id: first.doctorId, name: first.doctorName, department: first.doctorDepartment, code: first.doctorCode },
      diagnosis: first.diagnosis, instructions: first.instructions, notes: first.notes, followUpDate: first.followUpDate,
      items,
    };
  }

  if (type === "record") {
    const [recRows] = await db.query(
      `SELECT m.*, d.fullName AS doctorName, d.department AS doctorDepartment, d.doctorCode AS doctorCode
       FROM medical_records m LEFT JOIN doctors d ON m.doctorId = d.id WHERE m.id = ?`, [id]);
    const rec = recRows[0];
    const [files] = await db.query(
      `SELECT id, kind, title, category, fileDate, originalName, mimeType, sizeBytes FROM medical_record_files WHERE recordId = ? ORDER BY id ASC`,
      [id]
    );
    return {
      type, id: Number(id), docNumber: `MR-${String(id).padStart(6, "0")}`,
      status: rec.status, createdAt: rec.createdAt, patient,
      doctor: { id: rec.doctorId, name: rec.doctorName, department: rec.doctorDepartment, code: rec.doctorCode },
      visitDate: rec.visitDate, visitReason: rec.visitReason, chiefComplaint: rec.chiefComplaint, symptoms: rec.symptoms,
      vitals: { bloodPressure: rec.bloodPressure, pulse: rec.pulse, temperature: rec.temperature, respiratoryRate: rec.respiratoryRate, spo2: rec.spo2, height: rec.height, weight: rec.weight },
      examFindings: rec.examFindings, primaryDiagnosis: rec.primaryDiagnosis, diagnosis: rec.diagnosis, diagnosisNotes: rec.diagnosisNotes,
      treatment: rec.treatment, notes: rec.notes, followUpDate: rec.followUpDate,
      files,
    };
  }

  if (type === "lab") {
    const [[lab]] = await db.query(
      `SELECT l.*, d.fullName AS doctorName, d.department AS doctorDepartment, d.doctorCode AS doctorCode
       FROM lab_results l LEFT JOIN doctors d ON l.doctorId = d.id WHERE l.id = ?`, [id]);
    return {
      type, id: Number(id), docNumber: `LAB-${String(id).padStart(6, "0")}`,
      status: lab.status, createdAt: lab.createdAt, patient,
      doctor: { id: lab.doctorId, name: lab.doctorName, department: lab.doctorDepartment, code: lab.doctorCode },
      testName: lab.testName, result: lab.result, unit: lab.unit, referenceRange: lab.referenceRange, testDate: lab.testDate,
      hasReport: Boolean(lab.reportUrl),
    };
  }

  const [[img]] = await db.query(
    `SELECT r.*, d.fullName AS doctorName, d.department AS doctorDepartment, d.doctorCode AS doctorCode
     FROM radiology_reports r LEFT JOIN doctors d ON r.doctorId = d.id WHERE r.id = ?`, [id]);
  return {
    type, id: Number(id), docNumber: `IMG-${String(id).padStart(6, "0")}`,
    status: "registered", createdAt: img.createdAt, patient,
    doctor: { id: img.doctorId, name: img.doctorName, department: img.doctorDepartment, code: img.doctorCode },
    examType: img.examType, findings: img.findings, impression: img.impression, examDate: img.examDate,
  };
}

import db from "../db.js";
import { getClientIp, getUserAgent } from "./ActivityLog.js";

// فیلدهایی که هرگز نباید در لاگ حسابرسی ذخیره شوند (اطلاعات حساس/رمزها)،
// حتی اگر به‌اشتباه در oldValues/newValues فرستاده شده باشند — یک لایه‌ی محافظتی اضافه
const SENSITIVE_KEYS = new Set([
  "password", "passwordHash", "verificationCodeHash", "resetCodeHash",
]);

function sanitizeValues(values) {
  if (!values || typeof values !== "object") return values ?? null;
  const clean = {};
  for (const [key, value] of Object.entries(values)) {
    if (SENSITIVE_KEYS.has(key)) continue;
    clean[key] = value;
  }
  return clean;
}

// فهرست فیلدهایی که بین مقدار قبلی و جدید واقعاً تغییر کرده‌اند (برای UPDATE)
function diffFields(oldValues, newValues) {
  if (!oldValues || !newValues) return null;
  const keys = new Set([...Object.keys(oldValues), ...Object.keys(newValues)]);
  const changed = [];
  for (const key of keys) {
    const a = oldValues[key];
    const b = newValues[key];
    if (String(a ?? "") !== String(b ?? "")) changed.push(key);
  }
  return changed;
}

// ثبت یک رویداد حسابرسی (INSERT/UPDATE/DELETE) روی یک جدول مهم دیتابیس.
// این تابع هرگز نباید باعث شکست عملیات اصلی شود، به همین دلیل خطاهایش فقط لاگ می‌شوند
// (دقیقاً مثل logActivity در ActivityLog.js).
export async function recordAudit({
  req, tableName, recordId, action, oldValues = null, newValues = null,
  userId, userName, role,
}) {
  try {
    const cleanOld = sanitizeValues(oldValues);
    const cleanNew = sanitizeValues(newValues);
    const changedFields = action === "UPDATE" ? diffFields(cleanOld, cleanNew) : null;

    // اگر UPDATE ای هست ولی هیچ فیلدی واقعاً تغییر نکرده، باز هم رکورد ثبت می‌شود
    // (برای شفافیت کامل — شاید عملیات انجام شده ولی مقداری عوض نشده)
    await db.query(
      `INSERT INTO audit_logs
         (tableName, recordId, action, oldValues, newValues, changedFields, userId, userName, userRole, ipAddress, userAgent)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        tableName,
        recordId != null ? String(recordId) : null,
        action,
        cleanOld ? JSON.stringify(cleanOld) : null,
        cleanNew ? JSON.stringify(cleanNew) : null,
        changedFields ? JSON.stringify(changedFields) : null,
        userId || null,
        userName || null,
        role || null,
        getClientIp(req),
        getUserAgent(req),
      ]
    );
  } catch (err) {
    console.error("خطا در ثبت لاگ حسابرسی:", err.message);
  }
}

// شرط‌های جستجو/فیلتر لاگ‌های حسابرسی را از ورودی کوئری می‌سازد
function buildAuditFilters({ tableName, action, userId, role, recordId, search, dateFrom, dateTo } = {}) {
  const clauses = [];
  const params = [];

  if (tableName) {
    clauses.push("tableName = ?");
    params.push(tableName);
  }
  if (action) {
    clauses.push("action = ?");
    params.push(action);
  }
  if (userId) {
    clauses.push("userId = ?");
    params.push(userId);
  }
  if (role) {
    // فیلتر بر اساس نقش کاربری که عملیات را انجام داده (ستون موجود userRole) —
    // همان الگوی role در activity_logs، بدون نیاز به جدول یا ستون جدید
    clauses.push("userRole = ?");
    params.push(role);
  }
  if (recordId) {
    clauses.push("recordId = ?");
    params.push(String(recordId));
  }
  if (search) {
    clauses.push("(userName LIKE ? OR tableName LIKE ? OR oldValues LIKE ? OR newValues LIKE ? OR ipAddress LIKE ?)");
    const like = `%${search}%`;
    params.push(like, like, like, like, like);
  }
  if (dateFrom) {
    clauses.push("createdAt >= ?");
    params.push(`${dateFrom} 00:00:00`);
  }
  if (dateTo) {
    clauses.push("createdAt <= ?");
    params.push(`${dateTo} 23:59:59`);
  }

  return {
    where: clauses.length ? `WHERE ${clauses.join(" AND ")}` : "",
    params,
  };
}

// لاگ‌های حسابرسی را با فیلتر و صفحه‌بندی برمی‌گرداند — برای پنل Super Admin
export async function getFilteredAuditLogs({
  tableName, action, userId, role, recordId, search, dateFrom, dateTo, limit = 50, offset = 0,
} = {}) {
  const { where, params } = buildAuditFilters({ tableName, action, userId, role, recordId, search, dateFrom, dateTo });
  const [rows] = await db.query(
    `SELECT * FROM audit_logs ${where} ORDER BY createdAt DESC LIMIT ? OFFSET ?`,
    [...params, Number(limit) || 50, Number(offset) || 0]
  );
  const [countRows] = await db.query(`SELECT COUNT(*) AS total FROM audit_logs ${where}`, params);
  return { logs: rows, total: countRows[0].total };
}

// همان فیلترهای بالا را بدون صفحه‌بندی برمی‌گرداند — برای خروجی CSV
export async function getAuditLogsForExport({ tableName, action, userId, role, recordId, search, dateFrom, dateTo, limit = 5000 } = {}) {
  const { where, params } = buildAuditFilters({ tableName, action, userId, role, recordId, search, dateFrom, dateTo });
  const [rows] = await db.query(
    `SELECT * FROM audit_logs ${where} ORDER BY createdAt DESC LIMIT ?`,
    [...params, Number(limit) || 5000]
  );
  return rows;
}

// جزئیات یک رکورد مشخص از لاگ حسابرسی (برای نمایش کامل oldValues/newValues)
export async function getAuditLogById(id) {
  const [rows] = await db.query("SELECT * FROM audit_logs WHERE id = ?", [id]);
  return rows[0] || null;
}

// فهرست نام جدول‌هایی که تا الان لاگ حسابرسی برایشان ثبت شده (برای فیلتر کشویی در فرانت‌اند)
export async function getAuditedTableNames() {
  const [rows] = await db.query("SELECT DISTINCT tableName FROM audit_logs ORDER BY tableName");
  return rows.map((r) => r.tableName);
}

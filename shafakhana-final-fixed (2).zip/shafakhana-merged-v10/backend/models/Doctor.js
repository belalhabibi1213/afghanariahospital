import db from "../db.js";

export async function getAllDoctors() {
  const [rows] = await db.query("SELECT * FROM doctors ORDER BY department, fullName");
  return rows;
}

export async function getDoctorsByDepartment(department) {
  const [rows] = await db.query(
    "SELECT * FROM doctors WHERE department = ? ORDER BY fullName",
    [department]
  );
  return rows;
}

export async function getDoctorById(id) {
  const [rows] = await db.query("SELECT * FROM doctors WHERE id = ?", [id]);
  return rows[0] || null;
}

// جستجوی داکتر بر اساس شناسه یکتای داکتر (doctorCode) — برای بررسی تکراری‌نبودن
// هنگام افزودن/ویرایش داکتر استفاده می‌شود
export async function getDoctorByCode(doctorCode) {
  const [rows] = await db.query("SELECT * FROM doctors WHERE doctorCode = ?", [doctorCode]);
  return rows[0] || null;
}

// پروفایل داکتر متصل به یک حساب کاربری مشخص (برای پنل داکتر پس از ورود)
export async function getDoctorByUserId(userId) {
  const [rows] = await db.query("SELECT * FROM doctors WHERE userId = ?", [userId]);
  return rows[0] || null;
}

// اتصال یک پروفایل داکتر به یک حساب کاربری (نقش 'doctor') — توسط ادمین انجام می‌شود
export async function linkDoctorAccount(doctorId, userId) {
  await db.query("UPDATE doctors SET userId = ? WHERE id = ?", [userId, doctorId]);
  return getDoctorById(doctorId);
}

// آپلود/جایگزینی عکس داکتر — فقط ستون photoUrl را به‌روزرسانی می‌کند، بدون تغییر سایر اطلاعات
export async function updateDoctorPhoto(id, photoUrl) {
  await db.query("UPDATE doctors SET photoUrl = ? WHERE id = ?", [photoUrl, id]);
  return getDoctorById(id);
}

// آپلود/جایگزینی امضای دیجیتال داکتر — فقط ستون signatureUrl را به‌روزرسانی می‌کند
// (الزام شماره ۱ و ۴: آپلود و جایگزینی امضا)
export async function updateDoctorSignature(id, signatureUrl) {
  await db.query("UPDATE doctors SET signatureUrl = ? WHERE id = ?", [signatureUrl, id]);
  return getDoctorById(id);
}

// شناسه‌ی خودکار بعدی: بزرگ‌ترین عدد در شناسه‌های «DR-<عدد>» + ۱ (اگر هنوز داکتری نباشد: DR-1001).
// مثال: اگر آخرین داکتر DR-1009 باشد، داکتر بعدی DR-1010 می‌شود.
export async function getNextDoctorCode() {
  const [[row]] = await db.query(
    "SELECT MAX(CAST(SUBSTRING(doctorCode, 4) AS UNSIGNED)) AS maxNum FROM doctors WHERE doctorCode REGEXP '^DR-[0-9]+$'"
  );
  const next = (Number(row?.maxNum) || 1000) + 1;
  return `DR-${next}`;
}

// ---------- توابع مخصوص Admin ----------

export async function createDoctor({ doctorCode, fullName, department, yearsExperience, gender, rating, workDays, photoUrl, bio }) {
  const [result] = await db.query(
    `INSERT INTO doctors (doctorCode, fullName, department, yearsExperience, gender, rating, workDays, photoUrl, bio)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [doctorCode, fullName, department, yearsExperience || 0, gender || "men", rating || 4.5, workDays || "", photoUrl || null, bio || null]
  );
  return getDoctorById(result.insertId);
}

export async function updateDoctor(id, { doctorCode, fullName, department, yearsExperience, gender, rating, workDays, photoUrl, bio }) {
  await db.query(
    `UPDATE doctors SET doctorCode = ?, fullName = ?, department = ?, yearsExperience = ?, gender = ?, rating = ?, workDays = ?, photoUrl = ?, bio = ?
     WHERE id = ?`,
    [doctorCode, fullName, department, yearsExperience || 0, gender || "men", rating || 4.5, workDays || "", photoUrl || null, bio || null, id]
  );
  return getDoctorById(id);
}

export async function deleteDoctor(id) {
  await db.query("DELETE FROM doctors WHERE id = ?", [id]);
}

export async function countDoctors() {
  const [rows] = await db.query("SELECT COUNT(*) AS count FROM doctors");
  return rows[0].count;
}

// جستجوی پیشرفته داکتران: بر اساس بخش (department)، تخصص/نام (specialty/q)
// همراه با صفحه‌بندی. «specialty» روی نام بخش و بیوگرافی داکتر جستجو می‌شود
// چون این پروژه ستون جداگانه‌ای برای تخصص ندارد و department نقش آن را دارد.
export async function searchDoctors({ department, specialty, gender, q, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const conditions = [];
  const params = [];

  if (department && department.trim()) {
    conditions.push("department = ?");
    params.push(department.trim());
  }

  // فیلتر جنسیت داکتر (men/women) — همان مقادیر ذخیره‌شده در ستون gender جدول doctors
  if (gender === "men" || gender === "women") {
    conditions.push("gender = ?");
    params.push(gender);
  }

  // «specialty» هم روی بخش/بیوگرافی و هم روی نام و شناسه‌ی داکتر جستجو می‌شود، چون در
  // پنل مدیریت داکتران همین یک فیلد برای جستجوی «تخصص یا نام یا شناسه داکتر» استفاده می‌شود
  if (specialty && specialty.trim()) {
    const like = `%${specialty.trim()}%`;
    conditions.push("(department LIKE ? OR bio LIKE ? OR fullName LIKE ? OR doctorCode LIKE ?)");
    params.push(like, like, like, like);
  }

  if (q && q.trim()) {
    const like = `%${q.trim()}%`;
    conditions.push("(fullName LIKE ? OR department LIKE ? OR bio LIKE ? OR doctorCode LIKE ?)");
    params.push(like, like, like, like);
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  // ترتیب بر اساس شناسه‌ی داکتر (DR-1001، DR-1002، ...) به‌صورت عددی؛ بخش عددی بعد از «-»
  // جدا و به عدد تبدیل می‌شود تا ترتیب درست بماند (مثلاً DR-999 قبل از DR-1000).
  // این ترتیب در جستجو/فیلتر/صفحه‌بندی هم حفظ می‌شود
  const [rows] = await db.query(
    `SELECT * FROM doctors ${where} ORDER BY CAST(SUBSTRING_INDEX(doctorCode, '-', -1) AS UNSIGNED) ASC, doctorCode ASC, id ASC LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );
  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count FROM doctors ${where}`,
    params
  );

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

// فهرست داکتران برای خروجی Excel/PDF (پنل مدیریت داکتران) — همان فیلتر بخش/جستجوی
// جاری پنل (department/specialty) بدون صفحه‌بندی، مطابق همان الگوی getPatientsForExport
export async function getDoctorsForExport({ department, specialty } = {}) {
  const conditions = [];
  const params = [];

  if (department && department.trim()) {
    conditions.push("department = ?");
    params.push(department.trim());
  }
  if (specialty && specialty.trim()) {
    const like = `%${specialty.trim()}%`;
    conditions.push("(department LIKE ? OR bio LIKE ? OR fullName LIKE ? OR doctorCode LIKE ?)");
    params.push(like, like, like, like);
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [rows] = await db.query(`SELECT * FROM doctors ${where} ORDER BY CAST(SUBSTRING_INDEX(doctorCode, '-', -1) AS UNSIGNED) ASC, doctorCode ASC, id ASC`, params);
  return rows;
}

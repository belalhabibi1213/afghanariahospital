import db from "../db.js";

export async function getAllSchedules() {
  const [rows] = await db.query(
    `SELECT s.*, d.fullName AS doctorName, d.department
     FROM schedules s JOIN doctors d ON s.doctorId = d.id
     ORDER BY d.fullName, FIELD(s.dayOfWeek,'شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه')`
  );
  return rows;
}

export async function getSchedulesByDoctor(doctorId) {
  const [rows] = await db.query("SELECT * FROM schedules WHERE doctorId = ?", [doctorId]);
  return rows;
}

export async function createSchedule({ doctorId, dayOfWeek, startTime, endTime, breakStart, breakEnd }) {
  const [result] = await db.query(
    "INSERT INTO schedules (doctorId, dayOfWeek, startTime, endTime, breakStart, breakEnd) VALUES (?, ?, ?, ?, ?, ?)",
    [doctorId, dayOfWeek, startTime, endTime, breakStart || null, breakEnd || null]
  );
  return { id: result.insertId, doctorId, dayOfWeek, startTime, endTime, breakStart: breakStart || null, breakEnd: breakEnd || null };
}

export async function updateSchedule(id, { dayOfWeek, startTime, endTime, breakStart, breakEnd }) {
  await db.query(
    "UPDATE schedules SET dayOfWeek = ?, startTime = ?, endTime = ?, breakStart = ?, breakEnd = ? WHERE id = ?",
    [dayOfWeek, startTime, endTime, breakStart || null, breakEnd || null, id]
  );
  const [rows] = await db.query("SELECT * FROM schedules WHERE id = ?", [id]);
  return rows[0] || null;
}

export async function deleteSchedule(id) {
  await db.query("DELETE FROM schedules WHERE id = ?", [id]);
}

export async function getScheduleById(id) {
  const [rows] = await db.query("SELECT * FROM schedules WHERE id = ?", [id]);
  return rows[0] || null;
}

// آیا این بازه‌ی زمانی با یکی از برنامه‌های کاری موجودِ همان داکتر در همان روز
// همپوشانی دارد؟ (برای جلوگیری از ثبت دو بازه‌ی متداخل برای یک روز — پیش‌نیازِ
// «جلوگیری از دوبار رزرو» است، چون تولید ساعت‌های قابل‌رزرو بر پایه‌ی همین بازه‌هاست)
export async function hasOverlappingSchedule({ doctorId, dayOfWeek, startTime, endTime, excludeScheduleId }) {
  const conditions = ["doctorId = ?", "dayOfWeek = ?", "startTime < ?", "endTime > ?"];
  const params = [doctorId, dayOfWeek, endTime, startTime];
  if (excludeScheduleId) {
    conditions.push("id != ?");
    params.push(excludeScheduleId);
  }
  const [rows] = await db.query(
    `SELECT id FROM schedules WHERE ${conditions.join(" AND ")} LIMIT 1`,
    params
  );
  return rows.length > 0;
}

// نام روز هفته (به فارسی، مطابق مقادیر ستون dayOfWeek) بر اساس یک تاریخ میلادی
export const WEEKDAY_NAMES = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
function dayOfWeekFromDate(dateStr) {
  const d = new Date(`${dateStr}T00:00:00`);
  return WEEKDAY_NAMES[d.getDay()];
}

const SLOT_MINUTES = 30; // طول هر نوبت (دقیقه) — برای تولید فهرست ساعت‌های قابل‌رزرو

function addMinutes(time, minutes) {
  const [h, m] = time.split(":").map(Number);
  const total = h * 60 + m + minutes;
  const hh = String(Math.floor(total / 60) % 24).padStart(2, "0");
  const mm = String(total % 60).padStart(2, "0");
  return `${hh}:${mm}`;
}

const DEFAULT_TIMEZONE = "Asia/Kabul";

// تاریخ (YYYY-MM-DD) و ساعت (HH:MM) «همین الان» در منطقه‌ی زمانی تنظیمات سیستم (پیش‌فرض Asia/Kabul).
// از ساعت سرور/مرورگر استفاده نمی‌شود تا اگر سرور در منطقه‌ی دیگری بود، ساعت‌های امروز اشتباه حذف نشوند.
export function nowInTimeZone(timeZone) {
  const make = (tz) => new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  }).formatToParts(new Date());
  let parts;
  try { parts = make(timeZone || DEFAULT_TIMEZONE); } catch { parts = make(DEFAULT_TIMEZONE); }
  const get = (t) => parts.find((x) => x.type === t).value;
  return { date: `${get("year")}-${get("month")}-${get("day")}`, time: `${get("hour")}:${get("minute")}` };
}

// در‌دسترس بودن یک داکتر برای یک تاریخ مشخص: برنامه‌ی کاری آن روز را به بازه‌های
// ۳۰دقیقه‌ای تقسیم می‌کند. هر بازه تا سقف «capacity» بیمار می‌تواند رزرو شود (نه فقط
// یک بیمار)؛ برای هر ساعت، تعداد نوبت‌های فعال (pending/confirmed) موجود شمارش و با
// ظرفیت مقایسه می‌شود. capacity از تنظیمات سیستم (Super Admin → تنظیمات نوبت‌دهی →
// ظرفیت هر نوبت) می‌آید؛ پیش‌فرض ۱ برای سازگاری با فراخوانی‌های قدیمی‌تر که این مقدار
// را صریحاً پاس نمی‌دهند.
export async function getDoctorAvailability(doctorId, dateStr, capacity = 1, { timeZone } = {}) {
  const dayOfWeek = dayOfWeekFromDate(dateStr);

  const [scheduleRows] = await db.query(
    "SELECT startTime, endTime, breakStart, breakEnd FROM schedules WHERE doctorId = ? AND dayOfWeek = ?",
    [doctorId, dayOfWeek]
  );

  if (scheduleRows.length === 0) {
    return { date: dateStr, dayOfWeek, working: false, slots: [] };
  }

  const [bookedRows] = await db.query(
    `SELECT appointmentTime, COUNT(*) AS bookedCount FROM appointments
     WHERE doctorId = ? AND appointmentDate = ? AND status IN ('pending', 'confirmed')
     GROUP BY appointmentTime`,
    [doctorId, dateStr]
  );
  const bookedCounts = new Map(bookedRows.map((r) => [String(r.appointmentTime).slice(0, 5), Number(r.bookedCount)]));

  // اگر تاریخ انتخابی «امروز» باشد، ساعت‌هایی که شروعشان گذشته است اصلاً نمایش/رزرو نمی‌شوند؛
  // فقط ساعت‌های باقی‌مانده‌ی امروز (بعد از همین لحظه) قابل‌رزرو هستند.
  const now = nowInTimeZone(timeZone);
  const isToday = dateStr === now.date;

  const slots = [];
  for (const range of scheduleRows) {
    let current = String(range.startTime).slice(0, 5);
    const end = String(range.endTime).slice(0, 5);
    // زمان استراحت داکتر (در صورت تعریف‌شدن) — الزام شماره ۳: ساعت‌های داخل این
    // بازه هرگز به‌عنوان نوبتِ قابل‌رزرو نمایش داده نمی‌شوند
    const breakStart = range.breakStart ? String(range.breakStart).slice(0, 5) : null;
    const breakEnd = range.breakEnd ? String(range.breakEnd).slice(0, 5) : null;
    while (current < end) {
      const onBreak = breakStart && breakEnd && current >= breakStart && current < breakEnd;
      const alreadyPassed = isToday && current <= now.time;
      if (!onBreak && !alreadyPassed) {
        const bookedCount = bookedCounts.get(current) || 0;
        slots.push({
          time: current,
          available: bookedCount < capacity,
          remaining: Math.max(capacity - bookedCount, 0),
          capacity,
        });
      }
      const next = addMinutes(current, SLOT_MINUTES);
      // عبور از نیمه‌شب (مثلاً بازه‌ی شیفت شب تا ۲۳:۵۹): addMinutes به ۰۰:۰۰ برمی‌گردد و بدون این
      // بررسی حلقه بی‌نهایت می‌شد؛ بخش بعد از نیمه‌شب در برنامه‌ی روز بعد ثبت می‌شود
      if (next <= current) break;
      current = next;
    }
  }

  return { date: dateStr, dayOfWeek, working: true, slots };
}

import db from "../db.js";
import { getCachedSession, setCachedSession, invalidateAllSessions } from "../utils/authCache.js";

// ---------- مدل «نشست‌ها و دستگاه‌های فعال» ----------
// هر ردیف اینجا معادل یک ورود موفق (login/verifyEmail) با یک JWT مشخص است.
// tokenId همان claim یکتای jti داخل توکن است — نه خودِ توکن — تا هیچ‌وقت چیزی که
// بتوان با آن یک نشست را جعل کرد، در دیتابیس ذخیره نشود.

// یک نشست تازه (بلافاصله بعد از صدور JWT) ثبت می‌کند
export async function createSession({ userId, tokenId, userName, role, ipAddress, userAgent, expiresAt }) {
  await db.query(
    `INSERT INTO user_sessions (userId, tokenId, userName, role, ipAddress, userAgent, expiresAt)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    [userId, tokenId, userName || null, role || null, ipAddress || null, userAgent || null, expiresAt || null]
  );
}

// نسخه‌ی کش‌شده فقط برای middleware/auth.js؛ هر ابطال نشست (پایین) کل کش را پاک می‌کند
export async function findSessionByTokenIdCached(tokenId) {
  if (!tokenId) return null;
  const hit = getCachedSession(tokenId);
  if (hit) return hit;
  const row = await findSessionByTokenId(tokenId);
  setCachedSession(tokenId, row);
  return row;
}

// نشست متناظر یک jti را برمی‌گرداند (برای بررسی خاتمه‌یافته بودن در requireAuth)
export async function findSessionByTokenId(tokenId) {
  if (!tokenId) return null;
  const [rows] = await db.query("SELECT * FROM user_sessions WHERE tokenId = ?", [tokenId]);
  return rows[0] || null;
}

// زمان «آخرین فعالیت» نشست را به‌روزرسانی می‌کند — با هر درخواست معتبر کاربر صدا زده می‌شود
// «آخرین فعالیت» فقط برای نمایش است؛ نوشتن در دیتابیس به‌ازای هر درخواست بی‌دلیل بار می‌ساخت.
// حداکثر هر ۶۰ ثانیه یک‌بار (برای هر نشست) نوشته می‌شود. نقشه‌ی درون‌فرایندی و محدود است.
const TOUCH_INTERVAL_MS = 60_000;
const lastTouched = new Map();

export async function touchSession(tokenId) {
  if (!tokenId) return;
  const now = Date.now();
  const prev = lastTouched.get(tokenId);
  if (prev && now - prev < TOUCH_INTERVAL_MS) return;
  if (lastTouched.size > 5000) lastTouched.clear();
  lastTouched.set(tokenId, now);
  await db.query(
    "UPDATE user_sessions SET lastActivityAt = CURRENT_TIMESTAMP WHERE tokenId = ? AND revokedAt IS NULL",
    [tokenId]
  );
}

// فهرست نشست‌های «فعال» یعنی: هنوز خاتمه‌داده‌نشده (revokedAt خالی) و هنوز منقضی نشده
// (expiresAt در آینده یا نامشخص). برای پنل Super Admin — «نشست‌ها و دستگاه‌ها» استفاده می‌شود.
// عمداً هیچ‌کدام از فیلدهای password/tokenId/JWT در خروجی نیستند.
// نکته: tokenId عمداً در نتیجه هست (برای تشخیص «نشست جاری» در کنترلر) اما کنترلر
// موظف است پیش از فرستادن پاسخ به فرانت‌اند آن را حذف کند — هرگز نباید به کلاینت برسد.
export async function getActiveSessions() {
  const [rows] = await db.query(
    `SELECT id, userId, tokenId, userName, role, ipAddress, userAgent, loginAt, lastActivityAt, expiresAt
     FROM user_sessions
     WHERE revokedAt IS NULL AND (expiresAt IS NULL OR expiresAt > NOW())
     ORDER BY lastActivityAt DESC`
  );
  return rows;
}

// فهرست نشست‌های «غیرفعال» یعنی: یا با logout/خاتمه‌ی دستی پایان یافته‌اند (revokedAt پر است)
// یا زمان انقضایشان گذشته ولی هنوز revoke نشده‌اند (منقضی‌شده). برای بخش «نشست‌ها و
// دستگاه‌های غیرفعال» در پنل Super Admin استفاده می‌شود. مشابه getActiveSessions هیچ‌کدام
// از فیلدهای password/JWT در خروجی نیست؛ فقط tokenId عمداً برمی‌گردد تا کنترلر حذفش کند.
export async function getInactiveSessions() {
  const [rows] = await db.query(
    `SELECT id, userId, tokenId, userName, role, ipAddress, userAgent, loginAt, lastActivityAt,
            expiresAt, revokedAt, revokedByUserId
     FROM user_sessions
     WHERE revokedAt IS NOT NULL OR (expiresAt IS NOT NULL AND expiresAt <= NOW())
     ORDER BY COALESCE(revokedAt, expiresAt, lastActivityAt) DESC`
  );
  return rows;
}

// یک نشست را با شناسه‌ی داخلی (id ستون اصلی، نه tokenId) پیدا می‌کند — برای خاتمه‌دادن
export async function findSessionById(id) {
  const [rows] = await db.query("SELECT * FROM user_sessions WHERE id = ?", [id]);
  return rows[0] || null;
}

// نشست را خاتمه می‌دهد (revoke) — از این لحظه به بعد، درخواست‌های همراه با همان توکن رد می‌شوند
export async function revokeSessionById(id, revokedByUserId) {
  const [result] = await db.query(
    "UPDATE user_sessions SET revokedAt = CURRENT_TIMESTAMP, revokedByUserId = ? WHERE id = ? AND revokedAt IS NULL",
    [revokedByUserId || null, id]
  );
  invalidateAllSessions();
  return result.affectedRows > 0;
}

// خروج عادی کاربر (logout) هم نشست خودش را خاتمه می‌دهد — تا در فهرست «نشست‌های فعال» نماند
export async function revokeSessionByTokenId(tokenId, revokedByUserId) {
  if (!tokenId) return;
  await db.query(
    "UPDATE user_sessions SET revokedAt = CURRENT_TIMESTAMP, revokedByUserId = ? WHERE tokenId = ? AND revokedAt IS NULL",
    [revokedByUserId || null, tokenId]
  );
  invalidateAllSessions();
}

// همه‌ی نشست‌های فعال یک کاربر را خاتمه می‌دهد (مثلاً بعد از تغییر/بازیابی/بازنشانی رمز عبور)
// تا نشستِ دزدیده‌شده یا قدیمی با رمز قبلی تا ۷ روز معتبر نماند. با exceptTokenId می‌توان نشستِ
// فعلیِ خودِ کاربر را (هنگام «تغییر رمز» داوطلبانه) نگه داشت.
export async function revokeAllSessionsForUser(userId, { exceptTokenId = null, revokedByUserId = null } = {}) {
  if (!userId) return 0;
  const params = [revokedByUserId || null, userId];
  let sql = "UPDATE user_sessions SET revokedAt = CURRENT_TIMESTAMP, revokedByUserId = ? WHERE userId = ? AND revokedAt IS NULL";
  if (exceptTokenId) {
    sql += " AND tokenId <> ?";
    params.push(exceptTokenId);
  }
  const [result] = await db.query(sql, params);
  invalidateAllSessions();
  return result.affectedRows;
}

// آیا این کاربر قبلاً با «همین IP» ورود موفق داشته است؟ برای «قفل هوشمند»: وقتی حساب به‌خاطر تلاش‌های
// اشتباهِ یک مهاجم قفل می‌شود، صاحب حساب از IP/دستگاه آشنای خودش همچنان می‌تواند (با رمز درست) وارد شود.
export async function userHasSessionFromIp(userId, ipAddress) {
  if (!userId || !ipAddress) return false;
  const [rows] = await db.query(
    "SELECT 1 FROM user_sessions WHERE userId = ? AND ipAddress = ? LIMIT 1",
    [userId, ipAddress]
  );
  return rows.length > 0;
}

import db from "../db.js";

// اگر بیمار با همین ایمیل قبلاً ثبت شده باشد از همان رکورد استفاده می‌شود،
// در غیر این صورت یک رکورد جدید ساخته می‌شود.
export async function findOrCreatePatient({ fullName, phone, email, userId }) {
  // اولویت با تطبیق بر اساس userId است: اگر کاربر واردشده باشد، باید همیشه به
  // همان رکورد بیمارِ قبلیِ خودش وصل شود (حتی اگر این‌بار ایمیل وارد نکرده باشد)،
  // در غیر این صورت با هر نوبت‌گیریِ بدون ایمیل یک رکورد بیمار جدید و پراکنده
  // ساخته می‌شود و سوابق طبی/نوبت‌ها/فاکتورهای او بین چند patientId جدا می‌افتد.
  if (userId) {
    const [existingByUser] = await db.query(
      "SELECT * FROM patients WHERE userId = ? ORDER BY id ASC LIMIT 1",
      [userId]
    );
    if (existingByUser[0]) {
      await db.query(
        "UPDATE patients SET fullName = ?, phone = ?, email = COALESCE(?, email) WHERE id = ?",
        [fullName, phone, email || null, existingByUser[0].id]
      );
      return { ...existingByUser[0], fullName, phone, email: email || existingByUser[0].email };
    }
  }

  if (email) {
    const [existing] = await db.query(
      "SELECT * FROM patients WHERE email = ? ORDER BY (userId IS NULL) DESC, id ASC LIMIT 1",
      [email]
    );
    // امنیت: ایمیل را هر کسی می‌تواند در فرم نوبت‌گیری بنویسد، پس تطبیق با ایمیل هرگز نباید
    // پرونده‌ی بیمارِ دارای حساب کاربری را به شخص دیگر (یا مهمان) وصل کند یا نام/تلفنش را تغییر دهد؛
    // در غیر این صورت هر کسی با دانستن ایمیل قربانی می‌توانست مالک سوابق طبی او شود.
    // فقط رکوردهای «بدون مالک» (userId خالی، مثلاً بیمار مهمان قبلی) قابل تطبیق‌اند.
    if (existing[0] && existing[0].userId == null) {
      await db.query(
        "UPDATE patients SET fullName = ?, phone = ?, userId = COALESCE(?, userId) WHERE id = ?",
        [fullName, phone, userId || null, existing[0].id]
      );
      return { ...existing[0], fullName, phone };
    }
  }

  // کد عمومی (publicCode) از روی خودِ id ساخته می‌شود، نه با حدس زدن MAX(id)+1:
  // حدس زدنِ «کد بعدی» قبل از INSERT در ثبت‌نام‌های هم‌زمان باعث می‌شد چند بیمار همان
  // کد را بگیرند و یکی‌شان با خطای ۵۰۰ (ER_DUP_ENTRY روی ایندکس یکتای publicCode) شکست
  // بخورد. حالا ابتدا رکورد با publicCode=NULL (ایندکس یکتا چند NULL را می‌پذیرد) ساخته
  // می‌شود و سپس کد از id یکتای همان ردیف مشتق می‌شود — دقیقاً همان الگوی backfill در
  // db/migrations (AAH-000123) و همان روشی که شماره‌ی فاکتور (INV-xxxxxx) می‌سازد.
  const [result] = await db.query(
    "INSERT INTO patients (fullName, phone, email, userId, publicCode) VALUES (?, ?, ?, ?, NULL)",
    [fullName, phone, email || null, userId || null]
  );
  const publicCode = await assignPublicCode(result.insertId);
  return { id: result.insertId, fullName, phone, email, userId, publicCode };
}

// انتساب کد عمومی مبتنی بر id. اگر (به‌طور نظری) ردیفی قدیمی از قبل همان کد را داشت،
// با جابه‌جایی چند میلیون‌تایی (که همچنان با الگوی AAH-عدد سازگار است) کد دیگری می‌گیرد.
async function assignPublicCode(id) {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const code = `AAH-${String(id + attempt * 1000000).padStart(6, "0")}`;
    try {
      await db.query("UPDATE patients SET publicCode = ? WHERE id = ?", [code, id]);
      return code;
    } catch (err) {
      if (err.code === "ER_DUP_ENTRY" && attempt < 4) continue;
      throw err;
    }
  }
  return null;
}

export async function getPatientsByUser(userId) {
  const [rows] = await db.query("SELECT * FROM patients WHERE userId = ?", [userId]);
  return rows;
}

export async function getPatientById(id) {
  const [rows] = await db.query("SELECT * FROM patients WHERE id = ?", [id]);
  return rows[0] || null;
}

// آیا این بیمار حداقل یک نوبت با این داکتر دارد؟ — برای اطمینان از اینکه داکتر فقط
// می‌تواند برای بیمارانِ خودش (کسانی که با او نوبت گرفته‌اند) معلومات/فایل ارسال کند
export async function doctorHasPatient(doctorId, patientId) {
  const [rows] = await db.query(
    "SELECT 1 FROM appointments WHERE doctorId = ? AND patientId = ? LIMIT 1",
    [doctorId, patientId]
  );
  return rows.length > 0;
}

// نسخه‌ی سخت‌گیرانه‌تر doctorHasPatient — فقط نوبت «تایید شده» (confirmed) یا «انجام‌شده»
// (completed) رابطه‌ی معتبر محسوب می‌شود؛ نوبت «در انتظار تایید» (pending) یا لغو/رد‌شده
// (cancelled/rejected) کافی نیست. مخصوص مسیرهایی (چت و تماس صوتی/تصویری) که تا وقتی داکتر
// یا ادمین نوبت بیمار را تایید نکرده، نباید اجازه‌ی ارتباط مستقیم بین بیمار و داکتر را بدهند
// — قبلاً این مسیرها از doctorHasPatient (بدون فیلتر وضعیت) استفاده می‌کردند و همین باعث
// می‌شد بیمار بلافاصله بعد از ثبت نوبتِ هنوز تایید‌نشده بتواند با داکتر گفتگو/تماس کند.
export async function doctorHasConfirmedPatient(doctorId, patientId) {
  const [rows] = await db.query(
    "SELECT 1 FROM appointments WHERE doctorId = ? AND patientId = ? AND status IN ('confirmed', 'completed') LIMIT 1",
    [doctorId, patientId]
  );
  return rows.length > 0;
}

// فقط نوبت «انجام‌شده» (completed) — برای گفتگو و تماس بیمار↔داکتر. تأییدِ نوبت (confirmed) کافی
// نیست؛ بیمار فقط بعد از انجام واقعی ویزیت می‌تواند با داکتر ارتباط بگیرد.
export async function doctorHasCompletedPatient(doctorId, patientId) {
  const [rows] = await db.query(
    "SELECT 1 FROM appointments WHERE doctorId = ? AND patientId = ? AND status = 'completed' LIMIT 1",
    [doctorId, patientId]
  );
  return rows.length > 0;
}

// ---------- توابع مخصوص Admin ----------

// ستون‌های مشترک برای نمایش در جدول مدیریت بیماران (شناسه بیمار، عکس پروفایل،
// نام، تماس، ایمیل، داکتر مسئول، آخرین مراجعه، وضعیت حساب). عکس پروفایل و وضعیت
// حساب (فعال/غیرفعال) از رکورد کاربرِ لینک‌شده (در صورت وجود) گرفته می‌شود؛ داکتر
// مسئول و آخرین مراجعه از آخرین نوبتِ ثبت‌شده‌ی بیمار (بر اساس تاریخ/ساعت) استخراج
// می‌شود. بیمارانی که بدون حساب کاربری (به‌صورت مهمان) نوبت گرفته‌اند نیز پشتیبانی
// می‌شوند (LEFT JOIN)؛ برای این‌ها وضعیت پیش‌فرض «فعال» در نظر گرفته می‌شود، چون
// حساب کاربری‌ای برای غیرفعال شدن ندارند.
const PATIENT_LIST_SELECT = `
  SELECT
    p.*,
    u.photoUrl AS userPhotoUrl,
    u.isActive AS userIsActive,
    (
      SELECT a.appointmentDate
      FROM appointments a
      WHERE a.patientId = p.id
      ORDER BY a.id ASC
      LIMIT 1
    ) AS lastVisitDate,
    (
      SELECT d.fullName
      FROM appointments a
      JOIN doctors d ON d.id = a.doctorId
      WHERE a.patientId = p.id
      ORDER BY a.id ASC
      LIMIT 1
    ) AS assignedDoctorName
  FROM patients p
  LEFT JOIN users u ON u.id = p.userId
`;

// جزئیات کامل یک بیمار برای پنل Admin (مشاهده/چاپ/دانلود PDF معلومات بیمار).
// برخلاف getPatientById (که فقط ستون‌های جدول patients را می‌دهد)، این تابع در صورت
// وجود حساب کاربری لینک‌شده (userId)، فیلدهای تکمیلی پروفایل (آدرس، گروه خونی، تماس
// اضطراری، حساسیت‌ها و ...) را هم از جدول users می‌آورد، به‌علاوه‌ی داکتر مسئول/آخرین
// مراجعه/تعداد کل نوبت‌ها — همان الگوی PATIENT_LIST_SELECT بالا با فیلدهای بیشتر.
// جستجوی بیمار با کد عمومی (اسکن QR کارت بیمار در پذیرش) — دقیقاً همان خروجیِ
// getPatientDetailById را برمی‌گرداند تا در همان فرم پروفایل بیمار قابل‌نمایش باشد
export async function getPatientDetailByPublicCode(code) {
  const [rows] = await db.query("SELECT id FROM patients WHERE publicCode = ?", [String(code || "").trim().toUpperCase()]);
  if (!rows[0]) return null;
  return getPatientDetailById(rows[0].id);
}

export async function getPatientDetailById(id) {
  const [rows] = await db.query(
    `SELECT
      p.*,
      u.photoUrl AS userPhotoUrl,
      u.isActive AS userIsActive,
      u.isVerified AS userIsVerified,
      u.bloodGroup, u.address,
      u.emergencyContactName, u.emergencyContactRelationship, u.emergencyContactPhone,
      u.allergies, u.chronicDiseases, u.drugAllergies, u.height, u.weight,
      u.createdAt AS userCreatedAt,
      (
        SELECT a.appointmentDate
        FROM appointments a
        WHERE a.patientId = p.id
        ORDER BY a.id ASC
        LIMIT 1
      ) AS lastVisitDate,
      (
        SELECT d.fullName
        FROM appointments a
        JOIN doctors d ON d.id = a.doctorId
        WHERE a.patientId = p.id
        ORDER BY a.id ASC
        LIMIT 1
      ) AS assignedDoctorName,
      (SELECT COUNT(*) FROM appointments a WHERE a.patientId = p.id) AS totalAppointments
    FROM patients p
    LEFT JOIN users u ON u.id = p.userId
    WHERE p.id = ?`,
    [id]
  );
  return rows[0] || null;
}

export async function updatePatient(id, { fullName, phone, email }) {
  await db.query("UPDATE patients SET fullName = ?, phone = ?, email = ? WHERE id = ?", [fullName, phone, email || null, id]);
  const [rows] = await db.query("SELECT * FROM patients WHERE id = ?", [id]);
  return rows[0] || null;
}

export async function deletePatient(id) {
  await db.query("DELETE FROM patients WHERE id = ?", [id]);
}

// چند بیمار مشخص با شناسه (برای بررسی وجود/گرفتن مقادیر قبل از حذف دسته‌جمعی، پیش از audit log)
export async function getPatientsByIds(ids) {
  if (!Array.isArray(ids) || ids.length === 0) return [];
  const [rows] = await db.query(
    `SELECT * FROM patients WHERE id IN (${ids.map(() => "?").join(",")})`,
    ids
  );
  return rows;
}

// حذف دسته‌جمعی چند بیمار با شناسه (دکمه‌ی «حذف گروهی» در پنل مدیریت بیماران)
export async function deletePatientsByIds(ids) {
  if (!Array.isArray(ids) || ids.length === 0) return 0;
  const [result] = await db.query(
    `DELETE FROM patients WHERE id IN (${ids.map(() => "?").join(",")})`,
    ids
  );
  return result.affectedRows;
}

// فهرست بیماران برای خروجی Excel/PDF (بدون صفحه‌بندی) — یا بر اساس همان جستجوی جاری
// پنل (q)، یا فقط ردیف‌های انتخاب‌شده‌ی کاربر (ids)، یا در نبود هر دو، همه‌ی بیماران.
// از همان منطق فیلتر searchPatients پیروی می‌کند تا خروجی دقیقاً با آنچه ادمین
// روی صفحه می‌بیند هماهنگ باشد.
export async function getPatientsForExport({ q, ids } = {}) {
  const conditions = [];
  const params = [];

  if (Array.isArray(ids) && ids.length > 0) {
    conditions.push(`p.id IN (${ids.map(() => "?").join(",")})`);
    params.push(...ids);
  } else {
    const term = (q || "").trim();
    if (term) {
      const like = `%${term}%`;
      const isNumeric = /^\d+$/.test(term);
      conditions.push(
        isNumeric
          ? "(p.fullName LIKE ? OR p.phone LIKE ? OR p.email LIKE ? OR p.id = ?)"
          : "(p.fullName LIKE ? OR p.phone LIKE ? OR p.email LIKE ?)"
      );
      params.push(like, like, like);
      if (isNumeric) params.push(Number(term));
    }
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
  const [rows] = await db.query(`${PATIENT_LIST_SELECT} ${where} ORDER BY p.createdAt ASC, p.id ASC`, params);
  return rows;
}

export async function countPatients() {
  const [rows] = await db.query("SELECT COUNT(*) AS count FROM patients");
  return rows[0].count;
}

// آمار خلاصه‌ی بیماران برای کارت‌های بالای صفحه‌ی «مدیریت بیماران» — فقط یک کوئری تجمیعی
// (بدون خواندن ردیف‌ها). تعریف وضعیت‌ها دقیقاً همان فیلتر status در searchPatients است:
// active = حساب فعال، inactive = حساب غیرفعال، guest = بیمار بدون حساب کاربری
export async function getPatientStats() {
  const [rows] = await db.query(
    `SELECT
       COUNT(*) AS total,
       COALESCE(SUM(p.userId IS NOT NULL AND u.isActive = 1), 0) AS active,
       COALESCE(SUM(p.userId IS NOT NULL AND u.isActive = 0), 0) AS inactive,
       COALESCE(SUM(p.userId IS NULL), 0) AS guest
     FROM patients p
     LEFT JOIN users u ON u.id = p.userId`
  );
  const r = rows[0] || {};
  return {
    total: Number(r.total) || 0,
    active: Number(r.active) || 0,
    inactive: Number(r.inactive) || 0,
    guest: Number(r.guest) || 0,
  };
}

// ---------- توابع مخصوص پنل داکتر ----------

// بیمارانی که با داکتر واردشده نوبت دارند (یک ردیف برای هر نوبت، همراه با سن/جنسیت
// محاسبه‌شده از پروفایل بیمار) — همراه با جستجو (فقط بر اساس نام بیمار) و صفحه‌بندی
export async function searchDoctorPatients({ doctorId, q, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const conditions = ["a.doctorId = ?"];
  const params = [doctorId];

  const term = (q || "").trim();
  if (term) {
    const like = `%${term}%`;
    conditions.push("p.fullName LIKE ?");
    params.push(like);
  }

  const where = `WHERE ${conditions.join(" AND ")}`;

  const [rows] = await db.query(
    `SELECT
       p.id AS patientId,
       p.fullName AS patientName,
       p.gender,
       TIMESTAMPDIFF(YEAR, p.dateOfBirth, CURDATE()) AS age,
       a.id AS appointmentId,
       a.doctorId AS doctorId,
       a.appointmentDate,
       a.appointmentTime,
       a.status AS appointmentStatus,
       -- خلاصه‌ی سوابق ثبت‌شده‌ی بیمار برای دسترسی سریع در فهرست (نسخه‌های چنددارویی یک نسخه حساب می‌شوند)
       -- فقط برای نوبت تأییدشده/انجام‌شده؛ برای نوبت معلق/لغوشده NULL است تا اطلاعات بالینی لو نرود
       CASE WHEN a.status IN ('confirmed', 'completed') THEN (SELECT COUNT(DISTINCT COALESCE(pr.groupId, CONCAT('single-', pr.id))) FROM prescriptions pr WHERE pr.patientId = p.id) END AS prescriptionCount,
       CASE WHEN a.status IN ('confirmed', 'completed') THEN (SELECT DATE(MAX(pr.createdAt)) FROM prescriptions pr WHERE pr.patientId = p.id) END AS lastPrescriptionDate,
       CASE WHEN a.status IN ('confirmed', 'completed') THEN (SELECT COUNT(*) FROM medical_records mr WHERE mr.patientId = p.id AND mr.status <> 'draft') END AS recordCount,
       CASE WHEN a.status IN ('confirmed', 'completed') THEN (SELECT MAX(mr.visitDate) FROM medical_records mr WHERE mr.patientId = p.id AND mr.status <> 'draft') END AS lastRecordDate
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     ${where}
     ORDER BY a.id ASC
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );

  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count
     FROM appointments a
     JOIN patients p ON a.patientId = p.id
     ${where}`,
    params
  );

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

// ---------- پنل داکتر → «بیماران من» (یک ردیف برای هر «بیمار»، سروری) ----------
// برخلاف searchDoctorPatients (یک ردیف برای هر نوبت؛ مصرف‌کننده‌های قدیمی مثل چت/نسخه/انتقال فایل
// به آن وابسته‌اند و دست‌نخورده ماند)، این تابع بیماران یکتا را برمی‌گرداند. همه‌ی شرط‌های فیلتر روی
// جدول تجمیعیِ «نوبت‌های همین داکتر» (GROUP BY patientId) و سپس join با patients اعمال می‌شود؛
// پس هزاران نوبت هرگز به Node نمی‌آیند و فقط یک صفحه (حداکثر ۱۰۰ ردیف) خوانده می‌شود.
// وضعیت «فعال» = بیمار حداقل یک نوبت غیرلغوشده با این داکتر دارد؛ «غیرفعال» = همه‌ی نوبت‌هایش لغو شده.
// «آخرین مراجعه» = تاریخ آخرین نوبت غیرلغوشده.
export async function searchMyPatients({
  doctorId, q, gender, department, status, dateFrom, dateTo, sort = "newest", page = 1, limit = 20,
} = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 20));
  const offset = (safePage - 1) * safeLimit;

  const having = [];
  const havingParams = [];
  if (department && String(department).trim()) {
    having.push("SUM(a.department = ?) > 0");
    havingParams.push(String(department).trim());
  }
  if (status === "active") having.push("SUM(a.status <> 'cancelled') > 0");
  else if (status === "inactive") having.push("SUM(a.status <> 'cancelled') = 0");
  if (dateFrom) {
    having.push("MAX(CASE WHEN a.status <> 'cancelled' THEN a.appointmentDate END) >= ?");
    havingParams.push(dateFrom);
  }
  if (dateTo) {
    having.push("MAX(CASE WHEN a.status <> 'cancelled' THEN a.appointmentDate END) <= ?");
    havingParams.push(dateTo);
  }

  const agg = `
    SELECT a.patientId,
           MAX(CASE WHEN a.status <> 'cancelled' THEN a.appointmentDate END) AS lastVisitDate,
           COUNT(*) AS appointmentCount,
           SUM(a.status <> 'cancelled') AS liveCount,
           SUM(a.status IN ('confirmed', 'completed')) AS confirmedCount
    FROM appointments a
    WHERE a.doctorId = ?
    GROUP BY a.patientId
    ${having.length ? `HAVING ${having.join(" AND ")}` : ""}`;

  const conditions = [];
  const params = [doctorId, ...havingParams];
  if (gender === "male" || gender === "female") {
    conditions.push("p.gender = ?");
    params.push(gender);
  }
  const term = String(q || "").trim().slice(0, 100);
  if (term) {
    const like = `%${term.replace(/[\\%_]/g, (c) => `\\${c}`)}%`;
    const clauses = ["p.fullName LIKE ?", "p.phone LIKE ?", "p.email LIKE ?", "p.publicCode LIKE ?"];
    params.push(like, like, like, like);
    if (/^\d{1,10}$/.test(term)) {
      clauses.push("p.id = ?");
      params.push(Number(term));
    }
    conditions.push(`(${clauses.join(" OR ")})`);
  }
  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  let orderBy = "ag.lastVisitDate IS NULL, ag.lastVisitDate DESC, p.id DESC";
  if (sort === "oldest") orderBy = "ag.lastVisitDate IS NULL, ag.lastVisitDate ASC, p.id ASC";
  else if (sort === "name") orderBy = "p.fullName ASC, p.id ASC";

  const [rows] = await db.query(
    `SELECT p.id AS patientId, p.publicCode AS patientCode, p.fullName AS patientName, p.gender,
            TIMESTAMPDIFF(YEAR, p.dateOfBirth, CURDATE()) AS age, p.phone,
            DATE_FORMAT(ag.lastVisitDate, '%Y-%m-%d') AS lastVisitDate,
            ag.appointmentCount, ag.confirmedCount, (ag.liveCount > 0) AS isActive
     FROM (${agg}) ag
     JOIN patients p ON p.id = ag.patientId
     ${where}
     ORDER BY ${orderBy}
     LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );

  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count FROM (${agg}) ag JOIN patients p ON p.id = ag.patientId ${where}`,
    params
  );

  // بخش آخرین نوبت هر بیمارِ همین صفحه — فقط یک کوئری برای کل صفحه (بدون N+1)
  if (rows.length > 0) {
    const ids = rows.map((r) => r.patientId);
    const [deptRows] = await db.query(
      `SELECT patientId, department FROM appointments
       WHERE doctorId = ? AND patientId IN (?)
       ORDER BY appointmentDate DESC, appointmentTime DESC, id DESC`,
      [doctorId, ids]
    );
    const latest = new Map();
    for (const d of deptRows) if (!latest.has(d.patientId)) latest.set(d.patientId, d.department);
    for (const r of rows) {
      r.department = latest.get(r.patientId) || null;
      r.isActive = Boolean(Number(r.isActive));
      r.appointmentCount = Number(r.appointmentCount) || 0;
      r.hasConfirmed = Number(r.confirmedCount) > 0;
      delete r.confirmedCount;
    }
  }

  const total = Number(countRows[0].count) || 0;
  return { rows, total, page: safePage, limit: safeLimit, totalPages: Math.max(1, Math.ceil(total / safeLimit)) };
}

// کارت‌های آماری «بیماران من» + فهرست بخش‌ها برای فیلتر. today/weekFrom/weekTo از منطقه‌ی زمانی
// سیستم می‌آیند. «مراجعه امروز» = بیماران یکتا با نوبت غیرلغوشده‌ی امروز؛ «مراجعه این هفته» = تعداد نوبت‌های غیرلغوشده‌ی هفته.
export async function getMyPatientStats(doctorId, { today, weekFrom, weekTo }) {
  const [rows] = await db.query(
    `SELECT COUNT(DISTINCT patientId) AS total,
            COUNT(DISTINCT CASE WHEN status <> 'cancelled' THEN patientId END) AS active,
            COUNT(DISTINCT CASE WHEN status <> 'cancelled' AND appointmentDate = ? THEN patientId END) AS today,
            COALESCE(SUM(status <> 'cancelled' AND appointmentDate BETWEEN ? AND ?), 0) AS week
     FROM appointments WHERE doctorId = ?`,
    [today, weekFrom, weekTo, doctorId]
  );
  const [deptRows] = await db.query(
    "SELECT DISTINCT department FROM appointments WHERE doctorId = ? AND department <> '' ORDER BY department",
    [doctorId]
  );
  const r = rows[0] || {};
  return {
    total: Number(r.total) || 0,
    active: Number(r.active) || 0,
    today: Number(r.today) || 0,
    week: Number(r.week) || 0,
    departments: deptRows.map((d) => d.department),
  };
}

// جزئیات یک بیمار برای Drawer — فقط اگر با همین داکتر حداقل یک نوبت دارد (وگرنه null → ۴۰۴).
// ایمیل/تاریخ تولد/آدرس و خلاصه‌ی سوابق، مثل شمارنده‌های فهرست قدیمی، فقط وقتی برگردانده می‌شود که
// حداقل یک نوبت «تایید شده/انجام‌شده» وجود داشته باشد؛ برای بیمارِ فقط‌معلق/لغوشده null است.
export async function getMyPatientDetail(doctorId, patientId) {
  const [rows] = await db.query(
    `SELECT p.id AS patientId, p.publicCode AS patientCode, p.fullName AS patientName, p.gender,
            TIMESTAMPDIFF(YEAR, p.dateOfBirth, CURDATE()) AS age,
            DATE_FORMAT(p.dateOfBirth, '%Y-%m-%d') AS dateOfBirth,
            p.phone, p.email, u.address
     FROM patients p
     LEFT JOIN users u ON u.id = p.userId
     WHERE p.id = ? AND EXISTS (SELECT 1 FROM appointments x WHERE x.patientId = p.id AND x.doctorId = ?)
     LIMIT 1`,
    [patientId, doctorId]
  );
  const patient = rows[0];
  if (!patient) return null;

  const [appts] = await db.query(
    `SELECT a.id, a.department, DATE_FORMAT(a.appointmentDate, '%Y-%m-%d') AS appointmentDate,
            TIME_FORMAT(a.appointmentTime, '%H:%i') AS appointmentTime, a.status
     FROM appointments a
     WHERE a.doctorId = ? AND a.patientId = ?
     ORDER BY a.appointmentDate DESC, a.appointmentTime DESC, a.id DESC
     LIMIT 50`,
    [doctorId, patientId]
  );
  const hasConfirmed = appts.some((a) => a.status === "confirmed" || a.status === "completed");

  let summary = null;
  if (hasConfirmed) {
    const [[rx]] = await db.query(
      `SELECT COUNT(DISTINCT COALESCE(groupId, CONCAT('single-', id))) AS count, DATE(MAX(createdAt)) AS lastDate
       FROM prescriptions WHERE patientId = ?`,
      [patientId]
    );
    const [[rec]] = await db.query(
      `SELECT COUNT(*) AS count, DATE_FORMAT(MAX(visitDate), '%Y-%m-%d') AS lastDate
       FROM medical_records WHERE patientId = ? AND status <> 'draft'`,
      [patientId]
    );
    summary = {
      prescriptionCount: Number(rx.count) || 0,
      lastPrescriptionDate: rx.lastDate ? String(rx.lastDate).slice(0, 10) : null,
      recordCount: Number(rec.count) || 0,
      lastRecordDate: rec.lastDate || null,
    };
  } else {
    patient.email = null;
    patient.dateOfBirth = null;
    patient.address = null;
  }

  const live = appts.filter((a) => a.status !== "cancelled");
  return {
    ...patient,
    hasConfirmed,
    isActive: live.length > 0,
    department: appts[0] ? appts[0].department : null,
    lastVisitDate: live[0] ? live[0].appointmentDate : null,
    appointments: appts,
    summary,
  };
}

// جستجوی پیشرفته بیماران: بر اساس نام، شماره تماس، ایمیل یا شناسه (ID)
// همراه با صفحه‌بندی (pagination) برای بهینه بودن روی دیتاست‌های بزرگ
// فیلترهای اضافی: status (وضعیت حساب: active/inactive/guest)، gender (male/female)،
// doctorId (فقط بیمارانی که حداقل یک نوبت با این داکتر دارند) — همه اختیاری و در کنار
// جستجوی متنی موجود (q) قابل استفاده هستند.
export async function searchPatients({ q, status, gender, doctorId, createdFrom, createdTo, page = 1, limit = 10 } = {}) {
  const safePage = Math.max(1, parseInt(page, 10) || 1);
  const safeLimit = Math.min(100, Math.max(1, parseInt(limit, 10) || 10));
  const offset = (safePage - 1) * safeLimit;

  const conditions = [];
  const params = [];

  const term = (q || "").trim();
  if (term) {
    const like = `%${term}%`;
    const isNumeric = /^\d+$/.test(term);
    conditions.push(
      isNumeric
        ? "(p.fullName LIKE ? OR p.phone LIKE ? OR p.email LIKE ? OR p.publicCode LIKE ? OR p.id = ?)"
        : "(p.fullName LIKE ? OR p.phone LIKE ? OR p.email LIKE ? OR p.publicCode LIKE ?)"
    );
    params.push(like, like, like, like);
    if (isNumeric) params.push(Number(term));
  }

  if (status === "active") {
    conditions.push("(p.userId IS NOT NULL AND u.isActive = 1)");
  } else if (status === "inactive") {
    conditions.push("(p.userId IS NOT NULL AND u.isActive = 0)");
  } else if (status === "guest") {
    conditions.push("p.userId IS NULL");
  }

  if (gender === "male" || gender === "female") {
    conditions.push("p.gender = ?");
    params.push(gender);
  }

  const doctorIdNum = parseInt(doctorId, 10);
  if (Number.isInteger(doctorIdNum) && doctorIdNum > 0) {
    conditions.push("EXISTS (SELECT 1 FROM appointments da WHERE da.patientId = p.id AND da.doctorId = ?)");
    params.push(doctorIdNum);
  }

  // بازه‌ی تاریخ ثبت پرونده (createdAt) — فقط قالب YYYY-MM-DD پذیرفته می‌شود و مقدار
  // همیشه به‌صورت پارامتر (؟) به کوئری داده می‌شود، نه الحاق رشته
  const isoDate = /^\d{4}-\d{2}-\d{2}$/;
  if (typeof createdFrom === "string" && isoDate.test(createdFrom)) {
    conditions.push("DATE(p.createdAt) >= ?");
    params.push(createdFrom);
  }
  if (typeof createdTo === "string" && isoDate.test(createdTo)) {
    conditions.push("DATE(p.createdAt) <= ?");
    params.push(createdTo);
  }

  const where = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";

  const [rows] = await db.query(
    `${PATIENT_LIST_SELECT} ${where} ORDER BY p.createdAt ASC, p.id ASC LIMIT ? OFFSET ?`,
    [...params, safeLimit, offset]
  );
  // نکته‌ی مهم: WHERE بالا ممکن است به u.isActive ارجاع بدهد (فیلتر وضعیت حساب)،
  // پس این کوئری شمارش هم باید دقیقاً همان LEFT JOIN کوئری اصلی (PATIENT_LIST_SELECT)
  // را داشته باشد؛ وگرنه با خطای «Unknown column 'u.isActive'» شکست می‌خورد.
  const [countRows] = await db.query(
    `SELECT COUNT(*) AS count FROM patients p LEFT JOIN users u ON u.id = p.userId ${where}`,
    params
  );

  return {
    rows,
    total: countRows[0].count,
    page: safePage,
    limit: safeLimit,
    totalPages: Math.max(1, Math.ceil(countRows[0].count / safeLimit)),
  };
}

import db from "../db.js";

const PHONE_REGEX = /^0\d{9}$/; // شماره تماس افغانستان: با صفر شروع و ۱۰ رقم
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const enumValidator = (allowed) => (value) =>
  allowed.includes(value) ? true : `مقدار باید یکی از این موارد باشد: ${allowed.join("، ")}`;

// شناسه‌ی منطقه‌ی زمانی معتبر IANA است یا نه (بدون نیاز به فهرست ثابت/کتابخانه‌ی جانبی)
function isValidTimezone(value) {
  try {
    Intl.DateTimeFormat(undefined, { timeZone: value });
    return true;
  } catch {
    return false;
  }
}

// تعریف ساخت‌یافته‌ی «ماژول تنظیمات سیستم» — هر کلید یک گروه، مقدار پیش‌فرض و
// اعتبارسنج مشخص دارد. این تعریف هم برای پرکردن مقادیر پیش‌فرض (getAllSettings)
// و هم برای اعتبارسنجی ورودی (validateSettingsInput) استفاده می‌شود.
// توجه: logoUrl عمداً اینجا نیست — لوگو فقط از طریق آپلود فایل (نه متن دلخواه) تغییر می‌کند.
export const SETTINGS_FIELDS = {
  // ۱) اطلاعات شفاخانه
  hospitalName: {
    group: "hospital",
    default: "شفاخانه افغان آریا",
    validate: (v) => (v.trim().length >= 2 && v.trim().length <= 150) || "نام شفاخانه باید بین ۲ تا ۱۵۰ کاراکتر باشد",
  },
  hospitalAddress: {
    group: "hospital",
    default: "",
    validate: (v) => v.length <= 300 || "آدرس نباید بیشتر از ۳۰۰ کاراکتر باشد",
  },
  hospitalPhone: {
    group: "hospital",
    default: "",
    validate: (v) => v === "" || PHONE_REGEX.test(v) || "شماره تماس معتبر نیست (مثال: 07XXXXXXXX)",
  },
  hospitalEmail: {
    group: "hospital",
    default: "",
    validate: (v) => v === "" || EMAIL_REGEX.test(v) || "ایمیل معتبر نیست",
  },
  hospitalDescription: {
    group: "hospital",
    default: "",
    validate: (v) => v.length <= 500 || "توضیحات نباید بیشتر از ۵۰۰ کاراکتر باشد",
  },

  // ۳) تنظیمات ایمیل (اتصال SMTP همچنان در .env است؛ این‌ها تنظیمات نمایش/فعال‌سازی ارسال هستند)
  emailFromName: {
    group: "email",
    default: "شفاخانه افغان آریا",
    validate: (v) => v.length <= 100 || "نام فرستنده نباید بیشتر از ۱۰۰ کاراکتر باشد",
  },
  emailNotificationsEnabled: {
    group: "email",
    default: "on",
    validate: enumValidator(["on", "off"]),
  },

  // ۴) تنظیمات اعلان‌ها (اعلان‌های داخل‌سیستمی زنگوله)
  inAppNotificationsEnabled: {
    group: "notifications",
    default: "on",
    validate: enumValidator(["on", "off"]),
  },

  // ۸) تنظیمات نوبت‌دهی (appointment settings)
  // appointmentBookingWindowDays: حداکثر تعداد روزهایی که بیمار می‌تواند از امروز به بعد نوبت رزرو کند.
  // مقدار ۰ به معنای «بدون محدودیت» است (رفتار پیش‌فرض/قبلی سیستم حفظ می‌شود).
  appointmentBookingWindowDays: {
    group: "appointment",
    default: "0",
    validate: (v) => {
      if (v === "") return true;
      if (!/^\d{1,4}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return (n >= 0 && n <= 365) || "بازه‌ی زمانی رزرو باید بین ۰ (بدون محدودیت) تا ۳۶۵ روز باشد";
    },
  },
  // appointmentApprovalMode: manual = نوبت‌های جدید در وضعیت «در انتظار تایید» ثبت می‌شوند (پیش‌فرض/رفتار قبلی)
  // auto = نوبت‌های جدید بلافاصله «تایید شده» ثبت می‌شوند
  appointmentApprovalMode: {
    group: "appointment",
    default: "manual",
    validate: enumValidator(["manual", "auto"]),
  },
  // appointmentSlotCapacity: حداکثر تعداد بیمارانی که می‌توانند یک ساعتِ مشخص از یک داکتر را
  // هم‌زمان رزرو کنند (پیش‌فرض ۱۰). قبلاً هر ساعت فقط برای یک بیمار قابل‌رزرو بود؛ این مقدار
  // آن محدودیت را قابل‌تنظیم می‌کند تا مثلاً ساعت ۹ بتواند تا ۱۰ بیمار را بپذیرد.
  appointmentSlotCapacity: {
    group: "appointment",
    default: "10",
    validate: (v) => {
      if (!/^\d{1,3}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return (n >= 1 && n <= 200) || "ظرفیت هر ساعت باید بین ۱ تا ۲۰۰ بیمار باشد";
    },
  },
  // appointmentCancelMinHours: بیمار تا چند ساعت قبل از زمان نوبت می‌تواند نوبتش را لغو کند (پیش‌فرض ۲).
  // مقدار ۰ = تا لحظه‌ی شروع نوبت هر زمان مجاز است.
  appointmentCancelMinHours: {
    group: "appointment",
    default: "2",
    validate: (v) => {
      if (!/^\d{1,3}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return (n >= 0 && n <= 720) || "مقدار باید بین ۰ تا ۷۲۰ ساعت باشد";
    },
  },
  // appointmentReminderHours: یادآوری نوبت (اعلان درون‌برنامه‌ای + ایمیل در صورت وجود) چند ساعت
  // قبل از نوبت‌های «تایید شده» برای بیمار ارسال شود (پیش‌فرض ۲۴). مقدار ۰ = یادآوری غیرفعال.
  appointmentReminderHours: {
    group: "appointment",
    default: "24",
    validate: (v) => {
      if (!/^\d{1,3}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return (n >= 0 && n <= 168) || "مقدار باید بین ۰ (غیرفعال) تا ۱۶۸ ساعت باشد";
    },
  },

  // ۱۱) امنیت ورود (قفل موقت حساب پس از تلاش‌های ناموفق پیاپی)
  loginMaxFailedAttempts: {
    group: "security",
    default: "5",
    validate: (v) => {
      if (!/^\d{1,2}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return (n >= 3 && n <= 20) || "تعداد تلاش مجاز باید بین ۳ تا ۲۰ باشد";
    },
  },
  loginLockoutMinutes: {
    group: "security",
    default: "15",
    validate: (v) => {
      if (!/^\d{1,4}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return (n >= 1 && n <= 1440) || "مدت قفل باید بین ۱ تا ۱۴۴۰ دقیقه (۲۴ ساعت) باشد";
    },
  },

  // ۹) نگهداری لاگ‌ها (Log Retention) — جلوگیری از رشد بی‌پایان جدول‌ها و افت سرعت
  // activityLogRetentionDays: لاگ فعالیت‌های قدیمی‌تر از این تعداد روز هر شب خودکار حذف می‌شوند.
  // مقدار ۰ = هرگز حذف نشود.
  activityLogRetentionDays: {
    group: "logs",
    default: "90",
    validate: (v) => {
      if (!/^\d{1,4}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return n === 0 || (n >= 7 && n <= 3650) || "مقدار باید ۰ (بدون حذف) یا بین ۷ تا ۳۶۵۰ روز باشد";
    },
  },
  // auditLogArchiveMonths: لاگ‌های حسابرسی قدیمی‌تر از این تعداد ماه هر شب ابتدا در یک فایل
  // فشرده‌ی آرشیو ذخیره و سپس از جدول اصلی برداشته می‌شوند (حذف بدون آرشیو انجام نمی‌شود).
  // مقدار ۰ = آرشیو غیرفعال.
  auditLogArchiveMonths: {
    group: "logs",
    default: "12",
    validate: (v) => {
      if (!/^\d{1,3}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return n === 0 || (n >= 3 && n <= 120) || "مقدار باید ۰ (بدون آرشیو) یا بین ۳ تا ۱۲۰ ماه باشد";
    },
  },

  // ۱۰) پشتیبان‌گیری خودکار دیتابیس (Automatic Backup)
  // پیش‌فرض‌ها از متغیرهای .env قدیمی گرفته می‌شوند تا نصب‌های موجود رفتارشان تغییر نکند؛
  // از این پس مقدار ذخیره‌شده در «تنظیمات» (داشبورد ← پشتیبان‌گیری) ملاک است.
  backupAutoEnabled: {
    group: "backup",
    default: (process.env.BACKUP_AUTO_ENABLED || "true").toLowerCase() === "false" ? "off" : "on",
    validate: enumValidator(["on", "off"]),
  },
  // daily = هر روز، every12h = هر ۱۲ ساعت، every6h = هر ۶ ساعت، weekly = هفتگی (جمعه‌ها)
  backupAutoFrequency: {
    group: "backup",
    default: "daily",
    validate: enumValidator(["daily", "every12h", "every6h", "weekly"]),
  },
  // ساعت اجرا (به وقت سرور) برای روزانه/هفتگی؛ برای هر ۶/۱۲ ساعت فقط «دقیقه» استفاده می‌شود
  backupAutoTime: {
    group: "backup",
    default: "03:00",
    validate: (v) => /^([01]\d|2[0-3]):[0-5]\d$/.test(v) || "ساعت باید به شکل HH:MM باشد (مثلاً 03:00)",
  },
  // حداکثر تعداد فایل پشتیبان نگه‌داشته‌شده؛ قدیمی‌ترین‌ها خودکار حذف می‌شوند
  backupRetentionCount: {
    group: "backup",
    default: Number(process.env.BACKUP_RETENTION_COUNT) > 0 ? String(Number(process.env.BACKUP_RETENTION_COUNT)) : "14",
    validate: (v) => {
      if (!/^\d{1,3}$/.test(v)) return "این مقدار باید یک عدد صحیح باشد";
      const n = Number(v);
      return (n >= 1 && n <= 200) || "تعداد فایل‌های نگه‌داشته‌شده باید بین ۱ تا ۲۰۰ باشد";
    },
  },

  // ۵) تنظیمات زبان
  defaultLanguage: {
    group: "language",
    default: "fa",
    validate: enumValidator(["fa", "ps", "en"]),
  },

  // ۶) تنظیمات ظاهر (تم)
  theme: {
    group: "theme",
    default: "light",
    validate: enumValidator(["dark", "light", "auto"]),
  },

  // ۷) تنظیمات منطقه‌ی زمانی
  timezone: {
    group: "timezone",
    default: "Asia/Kabul",
    validate: (v) => isValidTimezone(v) || "منطقه‌ی زمانی معتبر نیست",
  },

  // تنظیمات کلی سیستم (از قبل موجود بود، برای سازگاری با نسخه‌ی قبلی حفظ شده)
  maintenanceMode: {
    group: "system",
    default: "off",
    validate: enumValidator(["on", "off"]),
  },
};

// همه‌ی تنظیمات ذخیره‌شده را برمی‌گرداند و مقادیر گمشده را با پیش‌فرض هر کلید پر می‌کند
// تا فرانت‌اند/مصرف‌کننده‌ها همیشه یک شیء کامل دریافت کنند، حتی برای نصب تازه بدون رکورد در جدول.
export async function getAllSettings() {
  const [rows] = await db.query("SELECT * FROM settings");
  const result = {};
  Object.entries(SETTINGS_FIELDS).forEach(([key, field]) => { result[key] = field.default; });
  result.logoUrl = "";
  rows.forEach((r) => { result[r.key] = r.value; });
  return result;
}

// فقط تنظیماتی که Super Admin می‌تواند ببیند/ویرایش کند (SETTINGS_FIELDS + logoUrl).
// جدول settings کلیدهای داخلیِ ماژول‌های دیگر را هم نگه می‌دارد (مثلاً backupActiveFolder،
// backupCustomDir، backupLastError) که نباید به فرم تنظیمات برسند؛ قبلاً همین کلیدها به
// فرم می‌رسیدند، با ذخیره دوباره‌ی کل فرم به سرور برمی‌گشتند و رد می‌شدند («برخی مقادیر
// ارسالی معتبر نیستند») و هیچ تغییری ذخیره نمی‌شد.
export async function getEditableSettings() {
  const all = await getAllSettings();
  const out = {};
  for (const key of [...Object.keys(SETTINGS_FIELDS), "logoUrl"]) out[key] = all[key];
  return out;
}

export async function setSetting(key, value) {
  await db.query(
    "INSERT INTO settings (`key`, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?",
    [key, value, value]
  );
  return { key, value };
}

// ورودی PUT /superadmin/settings را نسبت به SETTINGS_FIELDS اعتبارسنجی می‌کند:
// کلیدهای ناشناخته (مثل تلاش برای تغییر دستی logoUrl از این مسیر) و مقادیر نامعتبر رد می‌شوند.
// خروجی: { sanitized, errors } — sanitized فقط شامل کلیدهای معتبرِ آماده‌ی ذخیره است.
export function validateSettingsInput(body) {
  const sanitized = {};
  const errors = {};

  for (const [key, rawValue] of Object.entries(body || {})) {
    const field = SETTINGS_FIELDS[key];
    if (!field) {
      errors[key] = "این کلید تنظیمات معتبر/قابل‌تغییر نیست";
      continue;
    }
    const value = rawValue === null || rawValue === undefined ? "" : String(rawValue).trim();
    const validationResult = field.validate(value);
    if (validationResult !== true) {
      errors[key] = validationResult;
      continue;
    }
    sanitized[key] = value;
  }

  return { sanitized, errors };
}

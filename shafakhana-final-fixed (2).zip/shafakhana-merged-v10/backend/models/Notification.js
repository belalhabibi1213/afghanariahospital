import db from "../db.js";
import { getAllSettings } from "./Settings.js";

// یک اعلان جدید برای کاربر می‌سازد (مثلاً هنگام ثبت/تایید/رد/لغو نوبت)
// این تابع هرگز نباید باعث شکست درخواست اصلی شود، به همین دلیل خطاهایش فقط لاگ می‌شوند.
export async function createNotification({ userId, title, message, type = "general", relatedId = null }) {
  if (!userId) return null; // بدون کاربر واردشده (مثلاً نوبت مهمان)، اعلانی ساخته نمی‌شود
  try {
    // اگر مدیر کل اعلان‌های داخل‌سیستمی را از تنظیمات سیستم غیرفعال کرده باشد، چیزی ثبت نمی‌شود
    const settings = await getAllSettings().catch(() => ({}));
    if (settings.inAppNotificationsEnabled === "off") return null;

    const [result] = await db.query(
      `INSERT INTO notifications (userId, title, message, type, relatedId)
       VALUES (?, ?, ?, ?, ?)`,
      [userId, title, message, type, relatedId]
    );
    return { id: result.insertId, userId, title, message, type, relatedId, isRead: 0 };
  } catch (err) {
    console.error("خطا در ثبت اعلان:", err.message);
    return null;
  }
}

// یک اعلان مشخص را برمی‌گرداند، فقط اگر متعلق به همان کاربر باشد (برای دیپ‌لینکینگ)
export async function getNotificationById(id, userId) {
  const [rows] = await db.query(
    "SELECT * FROM notifications WHERE id = ? AND userId = ?",
    [id, userId]
  );
  return rows[0] || null;
}

// لیست اعلان‌های یک کاربر (جدیدترین در ابتدا)
export async function getNotificationsByUser(userId, { limit = 30, unreadOnly = false } = {}) {
  const unreadClause = unreadOnly ? "AND isRead = 0" : "";
  const [rows] = await db.query(
    `SELECT * FROM notifications WHERE userId = ? ${unreadClause} ORDER BY createdAt DESC LIMIT ?`,
    [userId, Number(limit) || 30]
  );
  return rows;
}

// تعداد اعلان‌های خوانده‌نشده — برای نمایش نشان (badge) روی آیکون زنگوله
export async function getUnreadCount(userId) {
  const [rows] = await db.query(
    "SELECT COUNT(*) AS count FROM notifications WHERE userId = ? AND isRead = 0",
    [userId]
  );
  return rows[0].count;
}

// یک اعلان مشخص را خوانده‌شده علامت می‌زند (فقط اگر متعلق به همان کاربر باشد)
export async function markAsRead(id, userId) {
  await db.query("UPDATE notifications SET isRead = 1 WHERE id = ? AND userId = ?", [id, userId]);
}

// همه‌ی اعلان‌های کاربر را خوانده‌شده علامت می‌زند
export async function markAllAsRead(userId) {
  await db.query("UPDATE notifications SET isRead = 1 WHERE userId = ? AND isRead = 0", [userId]);
}

// حذف اعلان‌های مرتبط با یک رکورد مشخص (مثلاً هنگام حذف فاکتور — الزام «حذف
// همگام‌سازی‌شده»: هیچ اعلان یتیمی برای فاکتور حذف‌شده باقی نماند)
export async function deleteNotificationsByRelated(type, relatedId, conn = db) {
  await conn.query("DELETE FROM notifications WHERE type = ? AND relatedId = ?", [type, relatedId]);
}

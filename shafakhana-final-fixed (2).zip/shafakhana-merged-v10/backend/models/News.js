import db from "../db.js";

// تبدیل رشته‌ی ذخیره‌شده در ستون tags (جدا شده با کاما) به آرایه‌ی تمیز برای پاسخ API
function withTagsArray(row) {
  if (!row) return row;
  const tagsArray = (row.tags || "")
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
  return { ...row, tags: tagsArray };
}

// ---------- عمومی (فقط اخبار منتشرشده + اخبار زمان‌بندی‌شده‌ای که زمانشان رسیده) ----------
// خبرهای سنجاق‌شده (isPinned) همیشه بالاتر از بقیه نمایش داده می‌شوند، سپس بر اساس
// جدیدترین تاریخ انتشار. شرط status='scheduled' AND scheduledAt<=NOW() تضمین می‌کند که
// خبر زمان‌بندی‌شده حتی اگر کرون هنوز آن را به 'published' تغییر نداده، سر وقت نمایش داده شود.
// likesCount و commentsCount (فقط نظرات تاییدشده) با دو زیرپرس‌وجوی سبک محاسبه می‌شوند تا
// کارت‌های فهرست عمومی اخبار (صفحه‌ی اصلی) بتوانند تعداد لایک/نظر را بدون درخواست جداگانه
// به ازای هر خبر نمایش دهند — مشابه همان شمارنده‌هایی که صفحه‌ی «ادامه مطلب» قبلاً داشت.
export async function getAllNews() {
  const [rows] = await db.query(
    `SELECT n.*,
            (SELECT COUNT(*) FROM news_likes nl WHERE nl.newsId = n.id) AS likesCount,
            (SELECT COUNT(*) FROM news_comments nc WHERE nc.newsId = n.id AND nc.status = 'approved' AND nc.deletedAt IS NULL) AS commentsCount
     FROM news n
     WHERE n.status = 'published' OR (n.status = 'scheduled' AND n.scheduledAt IS NOT NULL AND n.scheduledAt <= NOW())
     ORDER BY n.isPinned DESC, n.publishedAt DESC`
  );
  return rows.map(withTagsArray);
}

// ---------- مدیریت ادمین (همه وضعیت‌ها: پیش‌نویس، زمان‌بندی‌شده و منتشرشده) ----------
export async function getAllNewsAdmin() {
  const [rows] = await db.query(
    "SELECT * FROM news ORDER BY isPinned DESC, updatedAt DESC, publishedAt DESC"
  );
  return rows.map(withTagsArray);
}

export async function getNewsById(id) {
  const [rows] = await db.query("SELECT * FROM news WHERE id = ?", [id]);
  return withTagsArray(rows[0]) || null;
}

// وقتی خبری برای انتشار «زمان‌بندی» می‌شود، publishedAt به‌جای لحظه‌ی ثبت (اکنون)،
// همان زمان زمان‌بندی‌شده ذخیره می‌شود؛ این‌طور ترتیب نمایش و تاریخ نمایش‌داده‌شده
// همیشه درست است، چه خبر همین الان منتشر شود چه کرون بعداً آن را فعال کند.
function resolvePublishedAt(status, scheduledAt) {
  if (status === "scheduled" && scheduledAt) return scheduledAt;
  return null; // null یعنی از مقدار پیش‌فرض CURRENT_TIMESTAMP دیتابیس استفاده شود
}

export async function createNews({ title, titleEn, excerpt, excerptEn, content, contentEn, tag, tags, author, status, imageUrl, scheduledAt, isPinned, metaTitle, metaDescription }) {
  const effectiveStatus = status || "draft";
  const publishedAtOverride = resolvePublishedAt(effectiveStatus, scheduledAt);

  const [result] = await db.query(
    `INSERT INTO news (title, titleEn, excerpt, excerptEn, content, contentEn, tag, tags, author, status, imageUrl, scheduledAt, isPinned, publishedAt, metaTitle, metaDescription)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, COALESCE(?, CURRENT_TIMESTAMP), ?, ?)`,
    [
      title,
      titleEn || null,
      excerpt,
      excerptEn || null,
      content || null,
      contentEn || null,
      tag,
      tags || null,
      author || null,
      effectiveStatus,
      imageUrl || null,
      effectiveStatus === "scheduled" ? scheduledAt || null : null,
      isPinned ? 1 : 0,
      publishedAtOverride,
      metaTitle || null,
      metaDescription || null,
    ]
  );
  return getNewsById(result.insertId);
}

export async function updateNews(id, { title, titleEn, excerpt, excerptEn, content, contentEn, tag, tags, author, status, scheduledAt, isPinned, metaTitle, metaDescription }) {
  const publishedAtOverride = resolvePublishedAt(status, scheduledAt);

  await db.query(
    `UPDATE news
     SET title = ?, titleEn = ?, excerpt = ?, excerptEn = ?, content = ?, contentEn = ?, tag = ?, tags = ?, author = ?, status = ?,
         scheduledAt = ?, isPinned = ?, publishedAt = COALESCE(?, publishedAt),
         metaTitle = ?, metaDescription = ?
     WHERE id = ?`,
    [
      title,
      titleEn || null,
      excerpt,
      excerptEn || null,
      content || null,
      contentEn || null,
      tag,
      tags || null,
      author || null,
      status,
      status === "scheduled" ? scheduledAt || null : null,
      isPinned ? 1 : 0,
      publishedAtOverride,
      metaTitle || null,
      metaDescription || null,
      id,
    ]
  );
  return getNewsById(id);
}

export async function updateNewsStatus(id, status) {
  await db.query("UPDATE news SET status = ? WHERE id = ?", [status, id]);
  return getNewsById(id);
}

// سنجاق‌کردن/برداشتن سنجاق یک خبر مهم — عملیات سریع، مستقل از فرم ویرایش کامل
export async function updateNewsPin(id, isPinned) {
  await db.query("UPDATE news SET isPinned = ? WHERE id = ?", [isPinned ? 1 : 0, id]);
  return getNewsById(id);
}

export async function updateNewsImage(id, imageUrl) {
  await db.query("UPDATE news SET imageUrl = ? WHERE id = ?", [imageUrl, id]);
  return getNewsById(id);
}

// شمارش بازدید — هر بار که صفحه‌ی عمومی «ادامه مطلب» یک خبر منتشرشده باز می‌شود افزایش می‌یابد
// (برای ویجت «آمار داشبورد» و شناسایی محبوب‌ترین اخبار در پنل ادمین استفاده می‌شود)
export async function incrementNewsViews(id) {
  await db.query("UPDATE news SET views = views + 1 WHERE id = ?", [id]);
}

export async function deleteNews(id) {
  await db.query("DELETE FROM news WHERE id = ?", [id]);
}

// ---------- آمار برای پنل ادمین (Dashboard Statistics) ----------
export async function getNewsStats() {
  const [[totals]] = await db.query(
    `SELECT
       COUNT(*) AS total,
       SUM(status = 'published') AS published,
       SUM(status = 'draft') AS draft,
       SUM(status = 'scheduled') AS scheduled,
       SUM(isPinned = 1) AS pinned,
       COALESCE(SUM(views), 0) AS totalViews
     FROM news`
  );
  const [mostViewed] = await db.query(
    "SELECT id, title, views FROM news ORDER BY views DESC, publishedAt DESC LIMIT 5"
  );
  return {
    total: Number(totals.total) || 0,
    published: Number(totals.published) || 0,
    draft: Number(totals.draft) || 0,
    scheduled: Number(totals.scheduled) || 0,
    pinned: Number(totals.pinned) || 0,
    totalViews: Number(totals.totalViews) || 0,
    mostViewed,
  };
}

// اخباری که موعد زمان‌بندی‌شان رسیده اما هنوز به‌صورت خودکار (توسط کرون) به 'published'
// تغییر نکرده‌اند؛ توسط backend/utils/newsScheduler.js فراخوانی می‌شود.
export async function publishDueScheduledNews() {
  const [result] = await db.query(
    "UPDATE news SET status = 'published' WHERE status = 'scheduled' AND scheduledAt IS NOT NULL AND scheduledAt <= NOW()"
  );
  return result.affectedRows || 0;
}

// ---------- «اخبار مرتبط» و «آخرین اخبار» برای صفحه‌ی «ادامه مطلب» ----------
// بهینه‌سازی عملکرد: قبلاً فرانت‌اند برای ساختن این دو بخش، کل فهرست اخبار منتشرشده
// (همراه با content کامل هر خبر) را جداگانه دریافت می‌کرد. این تابع فقط ستون‌های لازم
// برای نمایش کارت خبر را با LIMIT مستقیماً از دیتابیس می‌گیرد، هم درخواست اضافی فرانت‌اند
// را حذف می‌کند و هم حجم پاسخ سرور را به‌شدت کاهش می‌دهد.
const NEWS_CARD_COLUMNS = "id, title, titleEn, excerpt, excerptEn, tag, imageUrl, isPinned, publishedAt";

export async function getRelatedAndLatestNews(id, tag, { relatedLimit = 4, latestLimit = 5 } = {}) {
  const visibleClause = "(status = 'published' OR (status = 'scheduled' AND scheduledAt IS NOT NULL AND scheduledAt <= NOW()))";

  const [related, latest] = await Promise.all([
    db.query(
      `SELECT ${NEWS_CARD_COLUMNS} FROM news
       WHERE id != ? AND tag = ? AND ${visibleClause}
       ORDER BY publishedAt DESC LIMIT ?`,
      [id, tag, relatedLimit]
    ),
    db.query(
      `SELECT ${NEWS_CARD_COLUMNS} FROM news
       WHERE id != ? AND ${visibleClause}
       ORDER BY publishedAt DESC LIMIT ?`,
      [id, latestLimit]
    ),
  ]);

  return { related: related[0], latest: latest[0] };
}

// ---------- گالری تصاویر خبر (News Gallery) ----------
export async function getNewsGallery(newsId) {
  const [rows] = await db.query(
    "SELECT id, newsId, imageUrl, sortOrder, createdAt FROM news_gallery WHERE newsId = ? ORDER BY sortOrder ASC, id ASC",
    [newsId]
  );
  return rows;
}

export async function addNewsGalleryImages(newsId, imageUrls) {
  if (!imageUrls || imageUrls.length === 0) return getNewsGallery(newsId);

  const [[{ maxOrder }]] = await db.query(
    "SELECT COALESCE(MAX(sortOrder), -1) AS maxOrder FROM news_gallery WHERE newsId = ?",
    [newsId]
  );

  let nextOrder = maxOrder + 1;
  for (const imageUrl of imageUrls) {
    await db.query(
      "INSERT INTO news_gallery (newsId, imageUrl, sortOrder) VALUES (?, ?, ?)",
      [newsId, imageUrl, nextOrder]
    );
    nextOrder += 1;
  }
  return getNewsGallery(newsId);
}

export async function getGalleryImageById(galleryId) {
  const [rows] = await db.query("SELECT * FROM news_gallery WHERE id = ?", [galleryId]);
  return rows[0] || null;
}

export async function deleteNewsGalleryImage(galleryId) {
  await db.query("DELETE FROM news_gallery WHERE id = ?", [galleryId]);
}

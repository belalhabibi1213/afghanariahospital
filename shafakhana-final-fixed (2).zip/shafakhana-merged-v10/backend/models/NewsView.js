import crypto from "crypto";
import db from "../db.js";
import { incrementNewsViews } from "./News.js";

// اگر همان بازدیدکننده (کاربر واردشده یا مهمان) در همین بازه‌ی زمانی همین خبر را
// دیده باشد، بازدید دوباره شمارش نمی‌شود — رفرش‌کردن مکرر صفحه یا خزنده‌های ساده
// نباید آمار بازدید را مصنوعی بالا ببرند.
const DEDUPE_WINDOW_MINUTES = 30;

// شناسه‌ی یکتای بازدیدکننده: برای کاربر واردشده بر اساس userId (پایدار روی همه‌ی
// دستگاه‌ها)، برای مهمان بر اساس هش IP + User-Agent (بدون ذخیره‌ی IP خام در جدول).
export function buildViewerKey({ userId, ip, userAgent }) {
  if (userId) return `user:${userId}`;
  const raw = `${ip || "unknown"}::${userAgent || "unknown"}`;
  const hash = crypto.createHash("sha256").update(raw).digest("hex").slice(0, 40);
  return `guest:${hash}`;
}

async function hasRecentView(newsId, viewerKey) {
  const [rows] = await db.query(
    `SELECT id FROM news_views
     WHERE newsId = ? AND viewerKey = ? AND createdAt >= (NOW() - INTERVAL ? MINUTE)
     LIMIT 1`,
    [newsId, viewerKey, DEDUPE_WINDOW_MINUTES]
  );
  return rows.length > 0;
}

// بازدید یک خبر را ثبت می‌کند و در صورتی که بازدیدکننده در بازه‌ی اخیر همین خبر را
// ندیده باشد، شمارنده‌ی views را هم افزایش می‌دهد. همیشه true/false برمی‌گرداند که
// آیا این بازدید واقعاً شمارش شد یا خیر (برای لاگ/دیباگ در صورت نیاز).
export async function registerNewsView(newsId, viewerKey) {
  try {
    const alreadyCounted = await hasRecentView(newsId, viewerKey);
    if (alreadyCounted) return false;

    await db.query("INSERT INTO news_views (newsId, viewerKey) VALUES (?, ?)", [newsId, viewerKey]);
    await incrementNewsViews(newsId);
    return true;
  } catch (err) {
    // ثبت بازدید هرگز نباید باعث شکست نمایش خبر شود
    console.error("خطا در ثبت بازدید خبر:", err.message);
    return false;
  }
}

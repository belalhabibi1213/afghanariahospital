// پیکربندی ESLint بک‌اند (Flat config) — بدون وابستگی اضافه: فقط قوانینِ مربوط به خطاهای واقعی
// (متغیر تعریف‌نشده، import تکراری، کد غیرقابل‌دسترس، دام‌های امنیتی مثل eval) تا بتوان بدون
// تغییر lockfile با `npx eslint@9` اجرا کرد. با `npm run lint` اجرا می‌شود.
const nodeGlobals = {
  process: "readonly", console: "readonly", Buffer: "readonly", URL: "readonly", URLSearchParams: "readonly",
  setTimeout: "readonly", clearTimeout: "readonly", setInterval: "readonly", clearInterval: "readonly",
  setImmediate: "readonly", queueMicrotask: "readonly", fetch: "readonly", AbortController: "readonly", AbortSignal: "readonly",
  FormData: "readonly", Blob: "readonly", TextEncoder: "readonly", TextDecoder: "readonly", structuredClone: "readonly", globalThis: "readonly",
};

export default [
  { ignores: ["node_modules/**", "uploads/**", "private-uploads/**"] },
  {
    files: ["**/*.js"],
    languageOptions: { ecmaVersion: "latest", sourceType: "module", globals: nodeGlobals },
    linterOptions: { reportUnusedDisableDirectives: "warn" },
    rules: {
      "no-undef": "error",
      "no-unreachable": "error",
      "no-dupe-keys": "error",
      "no-dupe-args": "error",
      "no-duplicate-case": "error",
      "no-redeclare": "error",
      "no-const-assign": "error",
      "no-func-assign": "error",
      "no-import-assign": "error",
      "no-self-assign": "error",
      "no-unsafe-finally": "error",
      "no-unsafe-negation": "error",
      "no-prototype-builtins": "warn",
      "no-empty": ["warn", { allowEmptyCatch: true }],
      "no-unused-vars": ["warn", { args: "none", caughtErrors: "none", varsIgnorePattern: "^_" }],
      "no-eval": "error",
      "no-implied-eval": "error",
      "no-new-func": "error",
      "eqeqeq": ["warn", "smart"],
    },
  },
];

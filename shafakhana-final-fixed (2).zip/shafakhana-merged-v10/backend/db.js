// اتصال به دیتابیس MySQL (سازگار با XAMPP)
// قبل از اجرای سرور، مطمئن شوید:
// ۱. XAMPP باز است و Apache + MySQL را Start کرده‌اید
// ۲. فایل .env را از روی .env.example ساخته‌اید
//
// نکته: نیازی نیست حتماً database_full.sql را دستی ایمپورت کنید — این فایل خودش
// در صورت نبود دیتابیس/جدول‌ها، آن‌ها را می‌سازد (شامل کاربر آزمایشی، ۸ داکتر
// و ۶ خبر نمونه).

import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const config = {
  // «localhost» در Node 17+ ابتدا به IPv6 (::1) تبدیل می‌شود، ولی MySQL/MariaDB در XAMPP معمولاً فقط روی IPv4
  // گوش می‌دهد؛ نتیجه‌اش خطای «connect ETIMEDOUT» است. پس localhost را صریحاً به 127.0.0.1 تبدیل می‌کنیم.
  host: (process.env.DB_HOST || "127.0.0.1").trim().toLowerCase() === "localhost" ? "127.0.0.1" : process.env.DB_HOST.trim(),
  port: Number(process.env.DB_PORT) || 3306,
  connectTimeout: 8000,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "", // در XAMPP پیش‌فرض رمز عبور خالی است
  charset: "utf8mb4",
  // ستون‌های DATE (مثل appointmentDate و dateOfBirth) را به‌صورت رشته‌ی «YYYY-MM-DD» برمی‌گرداند،
  // نه شیء Date. در حالت پیش‌فرض mysql2 آن را «نیمه‌شبِ محلی» می‌سازد و هنگام تبدیل به JSON
  // (UTC) در منطقه‌های زمانی جلوتر از UTC (مثل افغانستان +۴:۳۰) یک روز عقب می‌افتد
  // (مثلاً نوبت ۱۸ میزان در پنل ادمین ۱۷ میزان نمایش داده می‌شد).
  // DATETIME/TIMESTAMP (مثل createdAt) بدون تغییر باقی می‌مانند.
  dateStrings: ["DATE"],
};

// اتصال امن (SSL/TLS) به دیتابیس ابری مثل Aiven: DB_SSL=true. اگر گواهی CA سرویس را در DB_SSL_CA (متن PEM،
// خط‌های جدید را می‌توان به‌صورت \n نوشت) بدهید، گواهی کامل تأیید می‌شود؛ بدون آن فقط رمزنگاری انجام می‌شود
// (گواهی تأیید نمی‌شود) که برای تست قابل قبول است ولی برای production توصیه نمی‌شود.
if (String(process.env.DB_SSL || "").trim().toLowerCase() === "true") {
  const ca = (process.env.DB_SSL_CA || "").replace(/\\n/g, "\n").trim();
  config.ssl = ca ? { ca, rejectUnauthorized: true } : { rejectUnauthorized: false };
  if (!ca) console.warn("⚠️  DB_SSL=true ولی DB_SSL_CA تنظیم نشده؛ ارتباط رمزنگاری می‌شود اما گواهی سرور تأیید نمی‌شود.");
}

const DB_NAME = process.env.DB_NAME || "shafakhana";

let pool;

import { migrateUsersDoctorsPatients } from "./db/migrations/core-users.js";
import { migrateAppointmentsAndNews } from "./db/migrations/appointments-and-news.js";
import { migrateDepartmentsAndCatalogs } from "./db/migrations/departments-and-catalogs.js";
import { migrateMedicalRecords } from "./db/migrations/medical-records.js";
import { migrateCommunications } from "./db/migrations/communications.js";
import { migrateSessionsAuditBilling } from "./db/migrations/sessions-audit-billing.js";
import { migrateIndexesAndSeedData } from "./db/migrations/indexes-and-seed.js";
import { migrateUploadedFiles } from "./db/migrations/uploaded-files.js";
import { runMigrations } from "./db/migrator.js";

// ساخت/ارتقای ساختار دیتابیس قبلاً همگی داخل همین فایل (نزدیک به ۱۵۰۰ خط) بود؛ برای
// نگهداری آسان‌تر، هر بخش (کاربران/داکتران/بیماران، نوبت‌ها/اخبار، بخش‌ها/کاتالوگ‌ها،
// پرونده صحی، ارتباطات/چت، نشست‌ها/حسابرسی/فاکتور، ایندکس‌ها/داده‌ی نمونه) به فایل جداگانه‌ی
// خودش در db/migrations/ منتقل شد. ترتیب فراخوانی زیر دقیقاً همان ترتیب اجرای قبلی است — مهم
// است، چون جدول‌های بعدی با FOREIGN KEY به جدول‌های قبلی وابسته‌اند.
async function initDb() {
  // مرحله ۱: اتصال بدون انتخاب دیتابیس خاص، برای ساخت آن در صورت نبودش
  const bootstrapConnection = await mysql.createConnection(config);
  await bootstrapConnection.query(
    `CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`
  );
  await bootstrapConnection.end();

  // مرحله ۲: ساخت pool اصلی روی همان دیتابیس
  // connectionLimit از طریق DB_CONNECTION_LIMIT در .env قابل تنظیم است تا در محیط‌های
  // production با بار بیشتر (چند نمونه از سرور، ترافیک بالاتر) بدون تغییر کد قابل مقیاس‌گذاری باشد.
  pool = mysql.createPool({
    ...config,
    database: DB_NAME,
    waitForConnections: true,
    connectionLimit: Number(process.env.DB_CONNECTION_LIMIT) || 10,
    queueLimit: 0,
  });

  // ---------- ارتقای خودکار دیتابیس‌های نسخه قبلی ----------
  // اگر این پروژه قبلاً یکبار اجرا شده و دیتابیس با ساختار قدیمی (بدون rating/workDays
  // یا بدون patientId/doctorId) ساخته شده، این بخش جدول‌های ناسازگار را از نو می‌سازد
  // تا خطای "column not found" یا کار نکردن بخش داکتران/نوبت‌دهی رخ ندهد.

  await pool.query(`
    CREATE TABLE IF NOT EXISTS _migrations (
      id INT PRIMARY KEY,
      appliedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB
  `);

  const [migRows] = await pool.query("SELECT COUNT(*) AS count FROM _migrations WHERE id >= 3");
  if (migRows[0].count === 0) {
    // جدول‌های نسخه قدیمی را (در صورت وجود) پاک می‌کنیم تا با ساختار جدید جایگزین شوند.
    // نکته: چک محدودیت‌های Foreign Key را موقتاً خاموش می‌کنیم، چون ممکن است جدول‌هایی
    // مثل prescriptions/invoices/call_sessions که به appointments وصل‌اند از قبل ساخته
    // شده باشند (مثلاً وقتی database_full.sql دستی در phpMyAdmin ایمپورت شده) و بدون این کار
    // DROP TABLE با خطای "Cannot delete or update a parent row" (ER_ROW_IS_REFERENCED_2) مواجه می‌شود.
    await pool.query("SET FOREIGN_KEY_CHECKS = 0");
    await pool.query("DROP TABLE IF EXISTS appointments");
    await pool.query("DROP TABLE IF EXISTS doctors");
    await pool.query("SET FOREIGN_KEY_CHECKS = 1");
    await pool.query("INSERT INTO _migrations (id) VALUES (3)");
    console.log("🔄 دیتابیس به ساختار جدید (عکس‌های واقعی داکتران) ارتقا یافت");
  }

  await migrateUsersDoctorsPatients(pool, DB_NAME);
  await migrateAppointmentsAndNews(pool, DB_NAME);
  await migrateDepartmentsAndCatalogs(pool, DB_NAME);
  await migrateMedicalRecords(pool, DB_NAME);
  await migrateCommunications(pool, DB_NAME);
  await migrateSessionsAuditBilling(pool, DB_NAME);
  await migrateIndexesAndSeedData(pool, DB_NAME);
  await migrateUploadedFiles(pool);
  // مهاجرت‌های نسخه‌دار (db/migrations/versions) — هر تغییر ساختاریِ جدید اینجا می‌آید
  await runMigrations(pool, DB_NAME);

  console.log(`✅ اتصال به دیتابیس MySQL برقرار شد (دیتابیس: ${DB_NAME}) و جدول‌ها آماده‌اند`);
}


const readyPromise = initDb();

// این catch جداگانه فقط برای لاگ کردن خطا در کنسول است؛ باعث نمی‌شود Node به‌خاطر
// "unhandled promise rejection" کرش کند. خودِ readyPromise هنگام await در
// getPool() هنوز خطای واقعی را برمی‌گرداند تا کنترلرها بتوانند مدیریتش کنند.
readyPromise.catch((err) => {
  console.error("❌ خطا در اتصال به دیتابیس MySQL:", err.message || err.code);
  console.error(`   آدرس: ${config.host}:${config.port} | کاربر: ${config.user} | دیتابیس: ${DB_NAME}`);
  if (err.code === "ETIMEDOUT" || err.code === "ECONNREFUSED") {
    console.error("   → MySQL روی این آدرس/پورت پاسخ نمی‌دهد: در XAMPP دکمه‌ی Start کنار MySQL را بزنید (سبز شود)،");
    console.error("     و پورت نمایش‌داده‌شده کنار MySQL در XAMPP را با DB_PORT در backend/.env یکی کنید (گاهی 3307 است).");
  } else if (err.code === "ER_ACCESS_DENIED_ERROR") {
    console.error("   → نام کاربری/رمز اشتباه است: DB_USER و DB_PASSWORD را در backend/.env بررسی کنید (در XAMPP رمز root پیش‌فرض خالی است).");
  }
});

export async function getPool() {
  await readyPromise;
  return pool;
}

export default {
  async query(sql, params) {
    const p = await getPool();
    return p.query(sql, params);
  },
};

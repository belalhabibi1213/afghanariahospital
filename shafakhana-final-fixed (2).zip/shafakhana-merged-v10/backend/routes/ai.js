import express from "express";
import { requireAuth, authorize } from "../middleware/auth.js";
import { aiLimiter } from "../middleware/rateLimiters.js";
import { chat } from "../controllers/aiController.js";

const router = express.Router();

// POST /api/ai/chat — دستیار هوشمند: فقط بیمار واردشده (نقش user)
router.post("/chat", requireAuth, authorize("user"), aiLimiter, chat);

export default router;

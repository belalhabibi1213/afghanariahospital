import express from "express";
import multer from "multer";
import { requireAuth, authorize } from "../middleware/auth.js";
import { uploadLogo as uploadLogoMiddleware, verifyImageContent } from "../middleware/upload.js";
import {
  listAdmins, createAdmin, editAdmin, deleteAdmin,
  deleteDoctorAccount,
  listAllUsers, changeUserRole,
  getSettings, updateSettings, uploadLogo, removeLogo,
  activityLogs, exportActivityLogs, permissionsMatrix, databaseOverview,
  auditLogs, exportAuditLogs, auditLogDetail,
  listBackupsHandler, createBackupHandler, downloadBackupHandler, restoreBackupHandler, deleteBackupHandler,
  createBackupFolderHandler, pickBackupFolderHandler, updateBackupFolderHandler, activateBackupFolderHandler, deleteBackupFolderHandler,
  listSessions, listInactiveSessions, terminateSession,
  systemHealth,
} from "../controllers/superadminController.js";

const router = express.Router();

// این مسیرها فقط برای super admin باز است
router.use(requireAuth, authorize("superadmin"));

// خطاهای multer (فرمت نامعتبر، حجم بیش از حد و ...) را به پیام فارسی قابل‌فهم تبدیل می‌کند
// (همان الگوی استفاده‌شده برای آپلود عکس داکتر در routes/admin.js)
function handleLogoUpload(req, res, next) {
  uploadLogoMiddleware.single("logo")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم لوگو نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود لوگو ناموفق بود" });
  });
}

// مدیریت حساب‌های ادمین
router.get("/admins", listAdmins);
router.post("/admins", createAdmin);
router.put("/admins/:id", editAdmin);
router.delete("/admins/:id", deleteAdmin);

// حذف حساب داشبورد داکتر — فقط Super Admin (طبق router.use بالا). فقط حساب ورود (users)
// حذف می‌شود؛ پروفایل داکتر و سوابق او دست‌نخورده باقی می‌ماند.
router.delete("/doctors/:id/account", deleteDoctorAccount);

// تخصیص/تغییر نقش کاربران
router.get("/users", listAllUsers);
router.put("/users/:id/role", changeUserRole);

// تنظیمات سیستم
router.get("/settings", getSettings);
router.put("/settings", updateSettings);
router.post("/settings/logo", handleLogoUpload, verifyImageContent, uploadLogo);
router.delete("/settings/logo", removeLogo);

// لاگ فعالیت‌ها — جست‌وجو/فیلتر/صفحه‌بندی، و خروجی CSV
// (فقط قابل خواندن است؛ هیچ مسیر ویرایش یا حذفی برای لاگ‌ها وجود ندارد تا از دستکاری آن‌ها جلوگیری شود)
router.get("/activity-logs", activityLogs);
router.get("/activity-logs/export", exportActivityLogs);

// سیستم حسابرسی (Audit Trail) — ثبت ساخت‌یافته‌ی مقدار قبل/بعد هر تغییر مهم دیتابیس.
// فقط Super Admin به این مسیرها دسترسی دارد (طبق router.use بالا) و فقط خواندنی هستند؛
// هیچ مسیر PUT/DELETE ای تعریف نشده و در سطح دیتابیس هم Trigger از ویرایش/حذف جلوگیری می‌کند.
router.get("/audit-logs", auditLogs);
router.get("/audit-logs/export", exportAuditLogs);
router.get("/audit-logs/:id", auditLogDetail);

// ماتریس مجوزها
router.get("/permissions", permissionsMatrix);

// نمای کلی مدیریت دیتابیس
router.get("/database-overview", databaseOverview);

// نشست‌ها و دستگاه‌های فعال (Sessions & Devices) — فقط Super Admin (طبق router.use بالا)
// نکته: مسیر «/sessions/inactive» باید پیش از «/sessions/:id» ثبت شود، وگرنه اکسپرس
// «inactive» را به‌عنوان مقدار پارامتر :id در نظر می‌گیرد.
router.get("/sessions/inactive", listInactiveSessions);
router.get("/sessions", listSessions);
router.delete("/sessions/:id", terminateSession);

// سلامت سیستم (System Health) — وضعیت زنده‌ی API، دیتابیس، سرور، ذخیره‌سازی و پشتیبان‌گیری.
// فقط Super Admin به این مسیر دسترسی دارد (طبق router.use بالا)
router.get("/system-health", systemHealth);

// پشتیبان‌گیری و بازیابی دیتابیس (Database Backup & Restore) — فقط برای super admin
router.get("/backups", listBackupsHandler);
router.post("/backups", createBackupHandler);
// مدیریت پوشه‌های پشتیبان (ایجاد / ویرایش / انتخاب پوشه‌ی فعال / حذف پوشه‌ی خالی)
router.post("/backups/folders/pick", pickBackupFolderHandler); // باز کردن پنجره‌ی انتخاب پوشه‌ی کامپیوتر
router.post("/backups/folders", createBackupFolderHandler);
router.put("/backups/folders/:folderId", updateBackupFolderHandler);
router.post("/backups/folders/:folderId/activate", activateBackupFolderHandler);
router.delete("/backups/folders/:folderId", deleteBackupFolderHandler);
router.get("/backups/:filename/download", downloadBackupHandler);
router.post("/backups/:filename/restore", restoreBackupHandler);
router.delete("/backups/:filename", deleteBackupHandler);

export default router;

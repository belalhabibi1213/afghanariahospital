import express from "express";
import {
  listDepartments, getDepartment, addDepartment, editDepartment, removeDepartment,
} from "../controllers/departmentController.js";
import { requireAuth, authorize } from "../middleware/auth.js";
import { createDepartmentValidation, updateDepartmentValidation } from "../middleware/formValidators.js";

const router = express.Router();

// فهرست/جزئیات بخش‌ها عمداً بدون احراز هویت هستند (مثل /api/news) — هم برای پنل
// «مدیریت بخش‌ها»ی ادمین و هم برای بخش «خدمات ما»ی سایت اصلی استفاده می‌شوند.
router.get("/", listDepartments);
router.get("/:id", getDepartment);

// افزودن/ویرایش/حذف بخش فقط برای ادمین/سوپرادمین (Admin Dashboard > Department Management)
router.post("/", requireAuth, authorize("admin", "superadmin"), createDepartmentValidation, addDepartment);
router.put("/:id", requireAuth, authorize("admin", "superadmin"), updateDepartmentValidation, editDepartment);
router.delete("/:id", requireAuth, authorize("admin", "superadmin"), removeDepartment);

export default router;

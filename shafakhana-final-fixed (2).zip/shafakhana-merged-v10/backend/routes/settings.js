import express from "express";
import { getPublicSettings } from "../controllers/settingsController.js";
import { getAboutPublic } from "../controllers/aboutController.js";
import { getHeroPublic } from "../controllers/heroController.js";

const router = express.Router();

// عمومی و بدون نیاز به ورود — برخلاف routes/superadmin.js/settings که فقط Super Admin
// می‌بیند. صفحه‌ی اصلی سایت (هدر/فوتر/تماس با ما و ...) و صفحه‌ی داشبورد از این
// مسیر برای نمایش آخرین مقادیر ذخیره‌شده در «تنظیمات سیستم» استفاده می‌کنند.
router.get("/public", getPublicSettings);
// محتوای بخش «معرفی» صفحه‌ی اصلی که ادمین ویرایش کرده (null = متن/عکس پیش‌فرض)
router.get("/about", getAboutPublic);
// محتوای بخش اصلی (Hero) صفحه‌ی اصلی که ادمین ویرایش کرده (null = متن/عکس پیش‌فرض)
router.get("/hero", getHeroPublic);

export default router;

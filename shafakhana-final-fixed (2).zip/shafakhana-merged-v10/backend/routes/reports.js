import express from "express";
import { appointmentReport, patientReport, doctorReport, revenueReport } from "../controllers/reportController.js";
import { requireAuth, authorize } from "../middleware/auth.js";
import { reportFilterValidation, appointmentReportFilterValidation } from "../middleware/formValidators.js";

const router = express.Router();

// سیستم گزارش‌گیری فقط برای ادمین/سوپرادمین در دسترس است
router.use(requireAuth, authorize("admin", "superadmin"));

// هر مسیر format=json (پیش‌فرض)، format=pdf یا format=excel را پشتیبانی می‌کند
// (الزام شماره ۵: خروجی PDF و Excel) و با from/to بر اساس تاریخ فیلتر می‌شود (الزام شماره ۶)
router.get("/appointments", appointmentReportFilterValidation, appointmentReport); // الزام ۱
router.get("/patients", reportFilterValidation, patientReport);                    // الزام ۲
router.get("/doctors", reportFilterValidation, doctorReport);                      // الزام ۳
router.get("/revenue", reportFilterValidation, revenueReport);                     // الزام ۴

export default router;

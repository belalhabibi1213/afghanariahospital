import express from "express";
import { submitContact } from "../controllers/contactController.js";
import { contactLimiter } from "../middleware/rateLimiters.js";
import { contactValidation } from "../middleware/formValidators.js";

const router = express.Router();

router.post("/", contactLimiter, contactValidation, submitContact);

export default router;

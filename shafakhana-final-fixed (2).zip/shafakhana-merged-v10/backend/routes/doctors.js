import express from "express";
import multer from "multer";
import {
  listDoctors, doctorAvailability, myDoctorAppointments, updateMyAppointmentStatus,
  myDoctorSchedules,
  myDoctorAppointmentsList, myDoctorAppointmentStats, myDoctorAppointmentDetail,
  myDoctorPatientsList, myDoctorPatientStats, myDoctorPatientDetail,
  myDoctorPatients, uploadMySignature, downloadMySignature,
} from "../controllers/doctorController.js";
import {
  sendFilesToPatient, myDoctorFileTransfers, downloadFileTransferForDoctor, deleteFileTransferForDoctor,
} from "../controllers/fileTransferController.js";
import { myDoctorInvoices, myDoctorInvoiceDetail } from "../controllers/billingController.js";
import { listMyPrescriptions, myPrescriptionStats } from "../controllers/doctorPrescriptionController.js";
import { listMedicalDocuments, medicalDocumentStats, medicalDocumentDetail } from "../controllers/medicalDocumentController.js";
import { requireAuth, authorize } from "../middleware/auth.js";
import { requireNumericParams } from "../middleware/params.js";
import { uploadSignature, verifyImageContent, uploadFileTransfer, verifyFileTransferContent } from "../middleware/upload.js";
import { fileTransferLimiter } from "../middleware/rateLimiters.js";

const router = express.Router();

// همان الگوی مدیریت خطای multer که برای آپلود عکس پروفایل/داکتر استفاده شده (routes/users.js، routes/admin.js)
function handleSignatureUpload(req, res, next) {
  uploadSignature.single("signature")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم عکس امضا نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود امضا ناموفق بود" });
  });
}

// مدیریت خطای multer برای آپلود چند فایل ماژول «انتقال معلومات بیمار»
function handleFileTransferUpload(req, res, next) {
  uploadFileTransfer.array("files", 5)(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم هر فایل نباید بیشتر از ۱۵ مگابایت باشد" });
    }
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_COUNT") {
      return res.status(400).json({ message: "حداکثر ۵ فایل را می‌توانید هم‌زمان ارسال کنید" });
    }
    return res.status(400).json({ message: err.message || "آپلود فایل ناموفق بود" });
  });
}

router.get("/", listDoctors);

// در‌دسترس بودن یک داکتر برای یک تاریخ مشخص — مسیر عمومی (برای فورمه‌ی گرفتن نوبت)
router.get("/:id/availability", doctorAvailability);

// پنل داکتر: مشاهده‌ی نوبت‌های خودش (فقط خواندنی) — فقط برای حساب‌های با نقش 'doctor'
router.get("/me/appointments", requireAuth, authorize("doctor"), myDoctorAppointments);
// فهرست سروری (صفحه‌بندی/جستجو/فیلتر)، آمار و جزئیات — صفحه‌ی «نوبت‌های من». مسیرهای ثابت قبل از :id می‌آیند.
router.get("/me/appointments/list", requireAuth, authorize("doctor"), myDoctorAppointmentsList);
router.get("/me/appointments/stats", requireAuth, authorize("doctor"), myDoctorAppointmentStats);
router.get("/me/appointments/:id", requireAuth, authorize("doctor"), requireNumericParams("id"), myDoctorAppointmentDetail);

// پنل داکتر: فهرست بیمارانی که با او نوبت دارند (جستجو + صفحه‌بندی) — فقط برای نقش 'doctor'
router.get("/me/patients", requireAuth, authorize("doctor"), myDoctorPatients);
// فهرست سروریِ بیماران یکتا، آمار و جزئیات — صفحه‌ی «بیماران من»
router.get("/me/patients/list", requireAuth, authorize("doctor"), myDoctorPatientsList);
router.get("/me/patients/stats", requireAuth, authorize("doctor"), myDoctorPatientStats);
router.get("/me/patients/:id", requireAuth, authorize("doctor"), requireNumericParams("id"), myDoctorPatientDetail);

// پنل داکتر «نسخه و سوابق طبی»: فهرست/آمار نسخه‌هایی که خودِ داکتر نوشته — فقط برای نقش 'doctor'
// (شناسه‌ی داکتر از توکن گرفته می‌شود). ثبت/ویرایش/حذف/PDF نسخه از مسیرهای موجود
// /api/medical-records/prescriptions انجام می‌شود که مالکیت را در کنترلر بررسی می‌کنند.
router.get("/me/prescriptions", requireAuth, authorize("doctor"), listMyPrescriptions);
router.get("/me/prescriptions/stats", requireAuth, authorize("doctor"), myPrescriptionStats);
// فهرست یکپارچه‌ی اسناد طبی بیماران مجازِ داکتر (نسخه / سابقه صحی / آزمایش / تصویر پزشکی) — فقط خواندنی
router.get("/me/medical-documents/stats", requireAuth, authorize("doctor"), medicalDocumentStats);
router.get("/me/medical-documents", requireAuth, authorize("doctor"), listMedicalDocuments);
router.get("/me/medical-documents/:type/:id", requireAuth, authorize("doctor"), requireNumericParams("id"), medicalDocumentDetail);
// تایید/رد/تکمیل نوبت دیگر برای داکتر مجاز نیست (فقط ادمین: PUT /api/admin/appointments/:id/status) —
// این مسیر همیشه ۴۰۳ می‌دهد (برای نقش‌های غیر داکتر هم authorize همان ۴۰۳ را می‌دهد).
router.put("/me/appointments/:id/status", requireAuth, authorize("doctor"), updateMyAppointmentStatus);

// پنل داکتر: «صورت‌حساب و فاکتورها» — فقط فاکتورهای بیمارانی که با او نوبت دارند
// (یا فاکتورهایی که مستقیماً به نام او صادر شده‌اند)؛ فقط خواندنی — صدور/ویرایش
// فاکتور و ثبت پرداخت همچنان منحصراً از طریق پنل Admin/Super Admin است
// (نگاه کنید به routes/billing.js).
router.get("/me/invoices", requireAuth, authorize("doctor"), myDoctorInvoices);
router.get("/me/invoices/:id", requireAuth, authorize("doctor"), myDoctorInvoiceDetail);

// پنل داکتر: مشاهده‌ی برنامه کاری خودش — فقط خواندنی (RBAC).
// ایجاد/ویرایش/حذف برنامه کاری فقط از طریق پنل Admin/Super Admin مجاز است
// (نگاه کنید به POST/PUT/DELETE /api/admin/schedules در routes/admin.js).
router.get("/me/schedules", requireAuth, authorize("doctor"), myDoctorSchedules);

// امضای دیجیتال داکتر (برای چاپ خودکار روی PDF نسخه‌ها) — بخش UI پنل داکتر با ماژول
// «انتقال معلومات بیمار» جایگزین شده، اما این مسیرها همچنان توسط prescriptionPdf.js استفاده
// می‌شوند و برای حفظ سازگاری با قابلیت موجود (چاپ نسخه با امضا) دست‌نخورده باقی مانده‌اند.
router.get("/me/signature", requireAuth, authorize("doctor"), downloadMySignature);
router.post("/me/signature", requireAuth, authorize("doctor"), handleSignatureUpload, verifyImageContent, uploadMySignature);

// پنل داکتر: ماژول «انتقال معلومات بیمار» — ارسال فایل/سند صحی برای یک بیمار مشخص
// (فقط بیمارانی که با این داکتر نوبت دارند)، مشاهده‌ی تاریخچه‌ی ارسالی‌ها و دانلود امن
router.post(
  "/me/file-transfers",
  requireAuth,
  authorize("doctor"),
  fileTransferLimiter,
  handleFileTransferUpload,
  verifyFileTransferContent,
  sendFilesToPatient
);
router.get("/me/file-transfers", requireAuth, authorize("doctor"), fileTransferLimiter, myDoctorFileTransfers);
router.get("/me/file-transfers/:id/download", requireAuth, authorize("doctor"), fileTransferLimiter, downloadFileTransferForDoctor);
// حذف یک فایل ارسالی — فقط داکتر و فقط برای فایل‌هایی که خودش ارسال کرده (RBAC در کنترلر)
router.delete("/me/file-transfers/:id", requireAuth, authorize("doctor"), fileTransferLimiter, deleteFileTransferForDoctor);

export default router;

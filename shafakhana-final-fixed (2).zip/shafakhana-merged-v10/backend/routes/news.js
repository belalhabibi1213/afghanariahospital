import express from "express";
import { listNews, getNewsArticle, toggleNewsLike, addNewsComment } from "../controllers/newsController.js";
import { requireAuth, optionalAuth } from "../middleware/auth.js";
import { newsCommentValidation } from "../middleware/formValidators.js";
import { commentLimiter } from "../middleware/rateLimiters.js";

const router = express.Router();

router.get("/", optionalAuth, listNews);
// optionalAuth: کاربر مهمان هم خبر را می‌بیند، اما اگر واردشده باشد وضعیت لایک خودش هم برمی‌گردد
router.get("/:id", optionalAuth, getNewsArticle);

// لایک/برداشتن لایک و ثبت نظر فقط برای کاربر واردشده مجاز است (requireAuth)
router.post("/:id/like", requireAuth, toggleNewsLike);
router.post("/:id/comments", requireAuth, commentLimiter, newsCommentValidation, addNewsComment);

export default router;

import express from "express";
import rateLimit from "express-rate-limit";
import db from "../db.js";

const router = express.Router();

// سبک و عمومی برای مانیتورینگ/Load Balancer/Docker. هیچ جزئیات داخلی (نسخه، پیکربندی، خطا) برنمی‌گرداند.
const healthLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => res.status(429).json({ status: "rate_limited" }),
});
router.use(healthLimiter);

// زنده بودن فرایند (liveness) — به دیتابیس وابسته نیست
router.get("/", (req, res) => res.status(200).json({ status: "ok" }));

// آمادگی (readiness) — اتصال دیتابیس را واقعاً با یک کوئری ساده می‌سنجد
router.get("/ready", async (req, res) => {
  try {
    await db.query("SELECT 1");
    return res.status(200).json({ status: "ready" });
  } catch {
    return res.status(503).json({ status: "unavailable" });
  }
});

export default router;

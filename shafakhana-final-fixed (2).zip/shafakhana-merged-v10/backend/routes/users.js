import express from "express";
import multer from "multer";
import { requireNumericParams } from "../middleware/params.js";
import { requireAuth } from "../middleware/auth.js";
import { uploadAvatar, verifyImageContent } from "../middleware/upload.js";
import { authLimiter } from "../middleware/rateLimiters.js";
import {
  getProfile,
  editProfile,
  changePassword,
  uploadPhoto,
  updateTheme,
  appointmentHistory,
  medicalRecords,
  listNotifications,
  unreadNotificationsCount,
  readNotification,
  readAllNotifications,
  resolveNotificationTarget,
} from "../controllers/userController.js";
import {
  getMyEmr, getMyMedicalHistoryTimeline, getMyTimelineEventDetail, getMyPrescriptions, getMyPrescriptionList, getMyPrescriptionDetail, getMyPrescriptionForAppointment, downloadMyPrescriptionPdf, getMyLabResults, downloadMyLabReport,
} from "../controllers/medicalRecordController.js";
import { listMyHealthRecords, getMyHealthRecord, downloadMyHealthRecordFile } from "../controllers/healthRecordController.js";
import { listMyDocuments } from "../controllers/medicalDocumentController.js";
import { myInvoices, myInvoiceDetail } from "../controllers/billingController.js";
import { getMyFileTransfers, downloadMyFileTransfer } from "../controllers/fileTransferController.js";

const router = express.Router();

// خطاهای multer (فرمت نامعتبر، حجم بیش از حد و ...) را به پیام فارسی قابل‌فهم تبدیل می‌کند
function handlePhotoUpload(req, res, next) {
  uploadAvatar.single("photo")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم عکس نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود عکس ناموفق بود" });
  });
}

// همه‌ی این مسیرها فقط نیاز به ورود دارند (هر سه نقش: user, admin, superadmin می‌توانند
// از پروفایل و رمز عبور خودشان استفاده کنند)
router.get("/profile", requireAuth, getProfile);
router.put("/profile", requireAuth, editProfile);
router.post("/photo", requireAuth, handlePhotoUpload, verifyImageContent, uploadPhoto);
router.put("/change-password", requireAuth, authLimiter, changePassword);
// ترجیح تم (روشن/تاریک) — فقط کاربر واردشده می‌تواند تم خودش را تغییر دهد
router.put("/theme", requireAuth, updateTheme);
router.get("/appointments", requireAuth, appointmentHistory);
router.get("/medical-records", requireAuth, medicalRecords);
router.get("/emr", requireAuth, getMyEmr);
router.get("/medical-history", requireAuth, getMyMedicalHistoryTimeline);
// «پرونده‌های صحی من» — گزارش‌های ثبت‌شده/ارسال‌شده‌ی داکتر؛ فقط‌خواندنی و فقط پرونده‌های خودِ بیمار (پیش‌نویس‌ها هرگز)
router.get("/health-records", requireAuth, listMyHealthRecords);
router.get("/health-records/files/:fileId", requireAuth, requireNumericParams("fileId"), downloadMyHealthRecordFile);
router.get("/health-records/:id", requireAuth, requireNumericParams("id"), getMyHealthRecord);
// جزئیات یک رویداد خط زمانی (ویزیت/آزمایش/رادیولوژی/نوبت/تشخیص/حساسیت) — مالکیت از روی توکن؛ نسخه‌ها از /prescriptions/:id/detail
router.get("/medical-history/:type/:id", requireAuth, requireNumericParams("id"), getMyTimelineEventDetail);
router.get("/prescriptions", requireAuth, getMyPrescriptions);
// پنل بیمار «نسخه و سوابق طبی»: فهرست گروه‌بندی‌شده و جزئیات یک نسخه — فقط خواندنی و فقط نسخه‌های خودِ بیمار
router.get("/prescription-list", requireAuth, getMyPrescriptionList);
// «همه اسناد» بیمار (نسخه + پرونده صحی) با جستجو/فیلتر/صفحه‌بندی سمت سرور — مالکیت از روی توکن
router.get("/documents", requireAuth, listMyDocuments);
router.get("/prescriptions/:id/detail", requireAuth, requireNumericParams("id"), getMyPrescriptionDetail);
router.get("/prescriptions/:appointmentId", requireAuth, requireNumericParams("appointmentId"), getMyPrescriptionForAppointment);
router.get("/prescriptions/:id/pdf", requireAuth, requireNumericParams("id"), downloadMyPrescriptionPdf);
router.get("/lab-results", requireAuth, getMyLabResults);
router.get("/lab-results/:id/report", requireAuth, requireNumericParams("id"), downloadMyLabReport);

// ماژول «انتقال معلومات بیمار»: فایل‌های ارسالی داکتر برای خودِ بیمار (فقط فایل‌های خودش)
router.get("/file-transfers", requireAuth, getMyFileTransfers);
router.get("/file-transfers/:id/download", requireAuth, downloadMyFileTransfer);

// سوابق صورت‌حساب و فاکتورهای خودِ بیمار (الزام شماره ۵: مشاهده سوابق صورت‌حساب)
router.get("/invoices", requireAuth, myInvoices);
router.get("/invoices/:id", requireAuth, myInvoiceDetail);

// اعلان‌های درون‌برنامه‌ای
router.get("/notifications", requireAuth, listNotifications);
router.get("/notifications/unread-count", requireAuth, unreadNotificationsCount);
router.put("/notifications/:id/read", requireAuth, readNotification);
router.put("/notifications/read-all", requireAuth, readAllNotifications);
// دیپ‌لینکینگ: مسیر/تب مقصد یک اعلان را برمی‌گرداند و آن را خوانده‌شده علامت می‌زند
router.get("/notifications/:id/target", requireAuth, resolveNotificationTarget);

export default router;

import express from "express";
import { login, register, verifyEmail, resendVerification, me, forgotPassword, resetPassword, logout } from "../controllers/authController.js";
import {
  loginValidation,
  registerValidation,
  emailOnlyValidation,
  verifyEmailValidation,
  resetPasswordValidation,
} from "../middleware/authValidators.js";
import { mfaVerify, mfaStatus, mfaSetup, mfaEnable, mfaDisable } from "../controllers/mfaController.js";
import { requireAuth, optionalAuth } from "../middleware/auth.js";
import { authLimiter } from "../middleware/rateLimiters.js";

const router = express.Router();

// محدودیت نرخ سخت‌گیرانه‌تر روی مسیرهای حساس (ورود، ثبت‌نام، فراموشی رمز عبور، کد تایید و ...)
// برای جلوگیری از حملات brute-force روی رمز عبور یا کد تایید ایمیل — علاوه بر محدودیت عمومی API
router.post("/login", authLimiter, loginValidation, login);
router.post("/register", authLimiter, registerValidation, register);
router.post("/verify-email", authLimiter, verifyEmailValidation, verifyEmail);
router.post("/resend-verification", authLimiter, emailOnlyValidation, resendVerification);
router.post("/forgot-password", authLimiter, emailOnlyValidation, forgotPassword);
router.post("/reset-password", authLimiter, resetPasswordValidation, resetPassword);
router.get("/me", requireAuth, me);
// احراز هویت دومرحله‌ای (TOTP). verify پیش از نشست است (با mfaToken کوتاه‌مدت)؛ بقیه نیازمند نشست‌اند.
router.post("/mfa/verify", authLimiter, mfaVerify);
router.get("/mfa/status", requireAuth, mfaStatus);
router.post("/mfa/setup", requireAuth, authLimiter, mfaSetup);
router.post("/mfa/enable", requireAuth, authLimiter, mfaEnable);
router.post("/mfa/disable", requireAuth, authLimiter, mfaDisable);
router.post("/logout", optionalAuth, logout);

export default router;

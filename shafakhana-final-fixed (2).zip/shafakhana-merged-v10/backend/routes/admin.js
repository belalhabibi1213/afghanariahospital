import express from "express";
import multer from "multer";
import { requireAuth, authorize } from "../middleware/auth.js";
import { requireNumericParams } from "../middleware/params.js";
import { uploadDoctorPhoto, uploadNewsImage, uploadAboutImage, uploadHeroImage, uploadNewsGallery, uploadDepartmentIcon as uploadDepartmentIconMiddleware, uploadDepartmentCover as uploadDepartmentCoverMiddleware, verifyImageContent, verifyNewsGalleryContent, verifyDepartmentIconContent } from "../middleware/upload.js";
import {
  listPatients, patientStats, editPatient, removePatient, bulkRemovePatients, exportPatients, viewPatient, getPatientFullProfile, togglePatientAccountStatus, resetPatientPassword, downloadPatientPdf, downloadPatientCardPdf, lookupPatientByCode,
  listDoctorsAdmin, nextDoctorCode, addDoctor, editDoctor, removeDoctor, changeDoctorPhoto, createDoctorAccount, exportDoctors,
  listAppointmentsAdmin, changeAppointmentStatus, removeAppointment, appointmentHistory,
  listDepartments, addDepartment, editDepartment, removeDepartment, uploadDepartmentIcon, uploadDepartmentCoverImage, removeDepartmentCoverImage,
  listSchedules, addSchedule, editSchedule, removeSchedule,
  listNewsAdmin, addNews, editNews, changeNewsStatus, changeNewsPin, changeNewsImage, removeNews, getNewsStatistics,
  listNewsGalleryAdmin, uploadNewsGalleryImages, removeNewsGalleryImage,
  listCommentsAdmin, getCommentStatistics, listCommentNewsOptions, viewComment, bulkComments, editComment, restoreRemovedComment, changeCommentStatus, removeComment,
  listContactMessages, getContactMessageStatistics, viewContactMessage, changeContactMessageStatus, removeContactMessage, changeContactMessageFlags, bulkContactMessages,
  reports, globalSearch,
} from "../controllers/adminController.js";
import { scheduleValidation, doctorValidation, newsValidation, newsStatusValidation, newsPinValidation, newsCommentStatusValidation, commentBulkValidation, commentEditValidation, contactStatusValidation, contactFlagsValidation, contactBulkValidation, createDepartmentValidation, updateDepartmentValidation } from "../middleware/formValidators.js";
import { getHeroAdmin, saveHero, uploadHeroImage as uploadHeroImageHandler, removeHeroImage, resetHero } from "../controllers/heroController.js";
import { getAboutAdmin, saveAbout, uploadAboutImage as uploadAboutImageHandler, removeAboutImage, resetAbout } from "../controllers/aboutController.js";
import { adminListAiChats, adminAiChatStats, adminFlagAiChat, adminDeleteAiChat, adminBulkDeleteAiChats } from "../controllers/aiController.js";
import { listAllFileTransfers, downloadFileTransferForAdmin } from "../controllers/fileTransferController.js";
import { listPrescriptionsAdmin, prescriptionStatsAdmin, changePrescriptionStatus } from "../controllers/adminPrescriptionController.js";
import { listMedicalDocuments, medicalDocumentStats, medicalDocumentDetail } from "../controllers/medicalDocumentController.js";

const router = express.Router();

// همه‌ی مسیرهای زیر فقط برای admin و superadmin باز است
// (superadmin هم به همه چیزهایی که admin دارد دسترسی کامل دارد)
router.use(requireAuth, authorize("admin", "superadmin"));

// خطاهای multer (فرمت نامعتبر، حجم بیش از حد و ...) را به پیام فارسی قابل‌فهم تبدیل می‌کند
// (همان الگوی استفاده‌شده برای آپلود عکس پروفایل در routes/users.js)
function handleDoctorPhotoUpload(req, res, next) {
  uploadDoctorPhoto.single("photo")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم عکس نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود عکس ناموفق بود" });
  });
}

function handleAboutImageUpload(req, res, next) {
  uploadAboutImage.single("image")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم عکس نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود عکس ناموفق بود" });
  });
}

function handleHeroImageUpload(req, res, next) {
  uploadHeroImage.single("image")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم عکس نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود عکس ناموفق بود" });
  });
}

// مدیریت بخش اصلی (Hero) صفحه‌ی اصلی سایت (عنوان، متن، دکمه‌ها، آمارها، کارت ضربان، عکس)
router.get("/hero", getHeroAdmin);
router.put("/hero", saveHero);
router.delete("/hero", resetHero);
router.post("/hero/image", handleHeroImageUpload, verifyImageContent, uploadHeroImageHandler);
router.delete("/hero/image", removeHeroImage);

// مدیریت بخش «معرفی» صفحه‌ی اصلی سایت (متن، عکس، موارد)
router.get("/about", getAboutAdmin);
router.put("/about", saveAbout);
router.delete("/about", resetAbout);
router.post("/about/image", handleAboutImageUpload, verifyImageContent, uploadAboutImageHandler);
router.delete("/about/image", removeAboutImage);

// نسخه و سوابق طبی — فهرست/آمار/وضعیت نسخه‌ها (جزئیات کامل از /patients/:id/full-profile)
// مسیر /prescriptions/stats باید پیش از /prescriptions/:id/... ثبت شود
router.get("/prescriptions/stats", prescriptionStatsAdmin);
router.get("/prescriptions", listPrescriptionsAdmin);
router.put("/prescriptions/:id/status", changePrescriptionStatus);

// فهرست یکپارچه‌ی اسناد طبی (نسخه / سابقه صحی / آزمایش / تصویر پزشکی) — فقط خواندنی
// (/stats باید پیش از /:type/:id ثبت شود)
router.get("/medical-documents/stats", medicalDocumentStats);
router.get("/medical-documents", listMedicalDocuments);
router.get("/medical-documents/:type/:id", requireNumericParams("id"), medicalDocumentDetail);

// مدیریت بیماران
router.get("/patients", listPatients);
// باید پیش از "/patients/:id" ثبت شود، وگرنه اکسپرس "stats" را به‌جای :id می‌خواند
router.get("/patients/stats", patientStats);
// این دو مسیر باید پیش از "/patients/:id" ثبت شوند، وگرنه اکسپرس "export"/"bulk" را
// به‌عنوان مقدار پارامتر :id در نظر می‌گیرد (ترتیب ثبت مسیرها در اکسپرس اهمیت دارد)
router.get("/patients/export", exportPatients);
router.delete("/patients/bulk", bulkRemovePatients);
// باید پیش از "/patients/:id" ثبت شود، وگرنه اکسپرس "lookup" را به‌جای :id می‌خواند
router.get("/patients/lookup/:code", lookupPatientByCode);
router.get("/patients/:id", viewPatient);
router.get("/patients/:id/full-profile", getPatientFullProfile);
router.get("/patients/:id/pdf", downloadPatientPdf);
router.get("/patients/:id/card", downloadPatientCardPdf);
router.put("/patients/:id", editPatient);
router.put("/patients/:id/status", togglePatientAccountStatus);
router.post("/patients/:id/reset-password", resetPatientPassword);
router.delete("/patients/:id", removePatient);

// مدیریت داکتران
router.get("/doctors", listDoctorsAdmin);
router.get("/doctors/export", exportDoctors);
router.get("/doctors/next-code", nextDoctorCode);
router.post("/doctors", doctorValidation, addDoctor);
router.put("/doctors/:id", doctorValidation, editDoctor);
router.delete("/doctors/:id", removeDoctor);
router.post("/doctors/:id/photo", handleDoctorPhotoUpload, verifyImageContent, changeDoctorPhoto);
router.post("/doctors/:id/account", createDoctorAccount);

// خطاهای multer برای آپلود عکس شاخص خبر، به همان شیوه‌ی آپلود عکس داکتر
function handleNewsImageUpload(req, res, next) {
  uploadNewsImage.single("image")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم عکس نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود عکس ناموفق بود" });
  });
}

// خطاهای multer برای آپلود چند عکس گالری خبر هم‌زمان
function handleNewsGalleryUpload(req, res, next) {
  uploadNewsGallery.array("images", 8)(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم هر عکس نباید بیشتر از ۲ مگابایت باشد" });
    }
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_COUNT") {
      return res.status(400).json({ message: "حداکثر ۸ عکس را می‌توانید هم‌زمان آپلود کنید" });
    }
    return res.status(400).json({ message: err.message || "آپلود گالری ناموفق بود" });
  });
}

// مدیریت نوبت‌ها
router.get("/appointments", listAppointmentsAdmin);
router.put("/appointments/:id/status", changeAppointmentStatus);
router.delete("/appointments/:id", removeAppointment);
router.get("/appointments/:id/history", appointmentHistory);

// خطاهای multer برای آپلود آیکون بخش، به همان شیوه‌ی آپلود عکس داکتر (فقط پیام و فرمت‌های مجاز فرق دارد)
function handleDepartmentIconUpload(req, res, next) {
  uploadDepartmentIconMiddleware.single("icon")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم آیکون نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود آیکون ناموفق بود" });
  });
}

// خطاهای multer برای آپلود عکس کاور بخش (JPG/PNG/WEBP، حداکثر ۲ مگابایت)
function handleDepartmentCoverUpload(req, res, next) {
  uploadDepartmentCoverMiddleware.single("cover")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم عکس نباید بیشتر از ۲ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود عکس ناموفق بود" });
  });
}

// مدیریت بخش‌ها
router.get("/departments", listDepartments);
router.post("/departments", createDepartmentValidation, addDepartment);
router.put("/departments/:id", updateDepartmentValidation, editDepartment);
router.delete("/departments/:id", removeDepartment);
router.post("/departments/:id/icon", handleDepartmentIconUpload, verifyDepartmentIconContent, uploadDepartmentIcon);
router.post("/departments/:id/cover", handleDepartmentCoverUpload, verifyImageContent, uploadDepartmentCoverImage);
router.delete("/departments/:id/cover", removeDepartmentCoverImage);

// مدیریت برنامه‌های کاری
router.get("/schedules", listSchedules);
router.post("/schedules", scheduleValidation, addSchedule);
router.put("/schedules/:id", scheduleValidation, editSchedule);
router.delete("/schedules/:id", removeSchedule);

// مدیریت اخبار و اعلانات (News & Announcements) — فقط admin/superadmin (از طریق router.use بالا)
router.get("/news", listNewsAdmin);
router.get("/news/stats", getNewsStatistics);
router.post("/news", newsValidation, addNews);
router.put("/news/:id", newsValidation, editNews);
router.put("/news/:id/status", newsStatusValidation, changeNewsStatus);
router.put("/news/:id/pin", newsPinValidation, changeNewsPin);
router.post("/news/:id/image", handleNewsImageUpload, verifyImageContent, changeNewsImage);
router.get("/news/:id/gallery", listNewsGalleryAdmin);
router.post("/news/:id/gallery", handleNewsGalleryUpload, verifyNewsGalleryContent, uploadNewsGalleryImages);
router.delete("/news/:id/gallery/:imageId", removeNewsGalleryImage);
router.delete("/news/:id", removeNews);

// مدیریت نظرات اخبار (News Comments Moderation) — تایید/رد/حذف نظرات کاربران
router.get("/comments", listCommentsAdmin);
// مسیرهای ثابت (stats / news-options / bulk) باید پیش از "/comments/:id" ثبت شوند
router.get("/comments/stats", getCommentStatistics);
router.get("/comments/news-options", listCommentNewsOptions);
router.post("/comments/bulk", commentBulkValidation, bulkComments);
router.get("/comments/:id", requireNumericParams("id"), viewComment);
router.put("/comments/:id", requireNumericParams("id"), commentEditValidation, editComment);
router.post("/comments/:id/restore", requireNumericParams("id"), restoreRemovedComment);
router.put("/comments/:id/status", newsCommentStatusValidation, changeCommentStatus);
router.delete("/comments/:id", removeComment);

// مدیریت پیام‌های تماس با ما (Contact Messages Management) — فقط admin/superadmin (طبق router.use بالا)
// بازبینی گفتگوهای دستیار هوشمند (ai_chat_logs) — فقط admin/superadmin
router.get("/ai-chats", adminListAiChats);
router.get("/ai-chats/stats", adminAiChatStats);
router.post("/ai-chats/bulk-delete", adminBulkDeleteAiChats);
router.put("/ai-chats/:id/flag", requireNumericParams("id"), adminFlagAiChat);
router.delete("/ai-chats/:id", requireNumericParams("id"), adminDeleteAiChat);

router.get("/contacts", listContactMessages);
router.get("/contacts/stats", getContactMessageStatistics);
// «bulk» باید پیش از "/contacts/:id" ثبت شود (POST است و با GET/PUT/DELETE تداخلی ندارد، ولی ترتیب خوانا بماند)
router.post("/contacts/bulk", contactBulkValidation, bulkContactMessages);
router.get("/contacts/:id", viewContactMessage);
router.put("/contacts/:id/status", contactStatusValidation, changeContactMessageStatus);
router.put("/contacts/:id/flags", contactFlagsValidation, changeContactMessageFlags);
router.delete("/contacts/:id", removeContactMessage);

// جستجوی کلی (Global Search) در بیماران، داکتران و نوبت‌ها
router.get("/search", globalSearch);

// گزارش‌ها و آمار
router.get("/reports", reports);

// ماژول «انتقال معلومات بیمار»: مشاهده‌ی همه‌ی انتقال‌ها توسط ادمین/سوپرادمین — این ماژول
// اصلاً مسیر ویرایش/حذف ندارد، پس ادمین/سوپرادمین هم مثل داکتر/بیمار فقط می‌تواند مشاهده/دانلود کند
router.get("/file-transfers", listAllFileTransfers);
router.get("/file-transfers/:id/download", downloadFileTransferForAdmin);

export default router;

import express from "express";
import { searchLimiter } from "../middleware/rateLimiters.js";
import { globalSearch } from "../controllers/searchController.js";

const router = express.Router();

// GET /api/search?q=... — جستجوی سراسری هدر؛ عمومی (بدون نیاز به توکن)، دقیقاً مثل
// GET /api/departments و GET /api/news که همین‌الان بدون احراز هویت در دسترس‌اند.
router.get("/", searchLimiter, globalSearch);

export default router;

import express from "express";
import multer from "multer";
import { requireAuth, authorize } from "../middleware/auth.js";
import { numericParam } from "../middleware/params.js";
import { uploadLabReport, verifyLabReportContent, uploadMedicalFile } from "../middleware/upload.js";
import {
  getPatientEmr,
  addEncounter, editEncounter, removeEncounter,
  addDiagnosis, editDiagnosis, removeDiagnosis,
  addPrescription, editPrescription, removePrescription, getPrescriptionsForAppointment, downloadPrescriptionPdf,
  addAllergy, editAllergy, removeAllergy,
  addLabResult, editLabResult, removeLabResult, recordLabResult, uploadLabReport as uploadLabReportHandler, downloadLabReport,
  addRadiologyReport, editRadiologyReport, removeRadiologyReport,
} from "../controllers/medicalRecordController.js";
import {
  getEncounterReport, addEncounterFile, getEncounterFile, removeEncounterFile, sendEncounterToPatient,
} from "../controllers/healthRecordController.js";
import {
  addEncounterValidation, editEncounterValidation, sendEncounterValidation,
  addDiagnosisValidation, editDiagnosisValidation,
  addPrescriptionValidation, editPrescriptionValidation,
  addAllergyValidation, editAllergyValidation,
  addLabResultValidation, editLabResultValidation, recordLabResultValidation,
  addRadiologyReportValidation, editRadiologyReportValidation,
} from "../middleware/formValidators.js";

const router = express.Router();

// خطاهای multer برای فایل‌های «پرونده صحی» (تصاویر پزشکی / اسناد) به پیام فارسی
function handleMedicalFileUpload(req, res, next) {
  uploadMedicalFile.single("file")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم فایل نباید بیشتر از ۱۰ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود فایل ناموفق بود" });
  });
}

// خطاهای multer (فرمت نامعتبر، حجم بیش از حد و ...) را به پیام فارسی قابل‌فهم تبدیل می‌کند
function handleLabReportUpload(req, res, next) {
  uploadLabReport.single("report")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم فایل نباید بیشتر از ۱۰ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود گزارش ناموفق بود" });
  });
}

// همه‌ی مسیرهای پرونده الکترونیک صحی (EMR) فقط برای داکتر، ادمین و سوپرادمین باز است.
// مالکیت هر آیتم (اینکه کدام داکتر آن را ثبت کرده) داخل کنترلر بررسی می‌شود؛
// دیدن پرونده خودِ بیمار از مسیر جداگانه‌ی GET /api/users/emr انجام می‌شود (routes/users.js)
router.use(requireAuth, authorize("doctor", "admin", "superadmin"));

// ماتریس دسترسی:
//   خواندن/چاپ/PDF (GET): داکتر (فقط بیماران/آیتم‌های مجاز خودش)، ادمین و سوپرادمین (نمایش‌دهنده).
//   نوشتن (POST/PUT/DELETE): فقط «داکتر». ثبت/ویرایش/حذف اطلاعات بالینی باید به یک داکتر مشخص نسبت داده
//   شود (doctorId + مالکیت)، پس ادمین و سوپرادمین نمی‌توانند نسخه/تشخیص/آزمایش/... بنویسند یا تغییر دهند؛
//   تنها اقدام ادمین روی نسخه، تغییر «وضعیت» از /api/admin/prescriptions/:id/status است (با لاگ حسابرسی).
const doctorOnly = authorize("doctor");
// شناسه‌های مسیر باید عدد صحیح مثبت باشند (۴۰۰ به‌جای رسیدن مقدار نامعتبر به کوئری)
router.param("patientId", numericParam);
router.param("appointmentId", numericParam);
router.param("id", numericParam);
router.param("fileId", numericParam);

// پرونده کامل یک بیمار مشخص
router.get("/patient/:patientId", getPatientEmr);

// ویزیت‌های کلی (encounters)
router.post("/encounters", doctorOnly, addEncounterValidation, addEncounter);
router.put("/encounters/:id", doctorOnly, editEncounterValidation, editEncounter);
// حذف پرونده صحی (ویزیت) فقط برای داکتر — نه بیمار و نه ادمین
router.delete("/encounters/:id", authorize("doctor"), removeEncounter);
// گزارش کامل پرونده (ویرایش/خلاصه/چاپ)، فایل‌های پرونده (تصویر پزشکی/سند) و ارسال گزارش به بیمار
router.get("/encounters/:id/report", getEncounterReport);
router.post("/encounters/:id/files", doctorOnly, handleMedicalFileUpload, verifyLabReportContent, addEncounterFile);
router.post("/encounters/:id/send", doctorOnly, sendEncounterValidation, sendEncounterToPatient);
router.get("/files/:fileId", getEncounterFile);
router.delete("/files/:fileId", doctorOnly, removeEncounterFile);

// تشخیص‌ها
router.post("/diagnoses", doctorOnly, addDiagnosisValidation, addDiagnosis);
router.put("/diagnoses/:id", doctorOnly, editDiagnosisValidation, editDiagnosis);
router.delete("/diagnoses/:id", doctorOnly, removeDiagnosis);

// نسخه‌ها
router.post("/prescriptions", doctorOnly, addPrescriptionValidation, addPrescription);
router.put("/prescriptions/:id", doctorOnly, editPrescriptionValidation, editPrescription);
// حذف نسخه فقط برای داکتر (مالکیت رکورد در کنترلر بررسی می‌شود)
router.delete("/prescriptions/:id", authorize("doctor"), removePrescription);
router.get("/appointments/:appointmentId/prescriptions", getPrescriptionsForAppointment);
router.get("/prescriptions/:id/pdf", downloadPrescriptionPdf);

// حساسیت‌ها
router.post("/allergies", doctorOnly, addAllergyValidation, addAllergy);
router.put("/allergies/:id", doctorOnly, editAllergyValidation, editAllergy);
router.delete("/allergies/:id", doctorOnly, removeAllergy);

// نتایج آزمایشگاه
router.post("/lab-results", doctorOnly, addLabResultValidation, addLabResult);
router.put("/lab-results/:id", doctorOnly, editLabResultValidation, editLabResult);
// حذف نتیجه‌ی آزمایش فقط برای داکتر (مالکیت رکورد در کنترلر بررسی می‌شود)
router.delete("/lab-results/:id", authorize("doctor"), removeLabResult);
router.put("/lab-results/:id/result", doctorOnly, recordLabResultValidation, recordLabResult);
router.post("/lab-results/:id/report", doctorOnly, handleLabReportUpload, verifyLabReportContent, uploadLabReportHandler);
router.get("/lab-results/:id/report", downloadLabReport);

// گزارش‌های رادیولوژی
router.post("/radiology-reports", doctorOnly, addRadiologyReportValidation, addRadiologyReport);
router.put("/radiology-reports/:id", doctorOnly, editRadiologyReportValidation, editRadiologyReport);
router.delete("/radiology-reports/:id", doctorOnly, removeRadiologyReport);

export default router;

import express from "express";
import { bookAppointment, myAppointments, cancelMyAppointment } from "../controllers/appointmentController.js";
import { requireAuth } from "../middleware/auth.js";
import { bookAppointmentValidation } from "../middleware/formValidators.js";

const router = express.Router();

// گرفتن وقت — فقط برای کاربر واردشده مجاز است (مهمان‌ها اجازه ثبت نوبت ندارند)
router.post("/", requireAuth, bookAppointmentValidation, bookAppointment);

// دیدن نوبت‌های خودم — فقط کاربر واردشده
router.get("/mine", requireAuth, myAppointments);

// لغو نوبت توسط خودِ بیمار (فقط نوبت‌های خودش)
router.post("/:id/cancel", requireAuth, cancelMyAppointment);

export default router;

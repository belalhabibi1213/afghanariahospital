import express from "express";
import multer from "multer";
import { requireAuth, authorize } from "../middleware/auth.js";
import { buildIceServers } from "../utils/iceServers.js";
import {
  listConversations, startConversation, getMessages, sendMessage,
  editMessage, deleteMessage, reactToMessage,
  sendMessageAttachment, downloadMessageAttachment, sendVoiceMessage,
} from "../controllers/chatController.js";
import {
  startConversationValidation, sendMessageValidation, reactToMessageValidation,
  sendMessageAttachmentValidation, sendVoiceMessageValidation,
} from "../middleware/formValidators.js";
import { uploadChatAttachment, verifyChatAttachmentContent, uploadChatVoice, verifyChatVoiceContent } from "../middleware/upload.js";

const router = express.Router();

// گفتگوی خصوصی فقط بین «بیمار» (نقش user) و «داکتر» است؛ مالکیت هر مکالمه
// (اینکه کدام بیمار/داکتر) داخل کنترلر بررسی می‌شود (RBAC).
router.use(requireAuth, authorize("user", "doctor"));

// فهرست سرورهای STUN/TURN برای تماس صوتی/تصویری. رمز TURN موقتی است (رمز اصلی به مرورگر نمی‌رسد).
router.get("/ice-servers", (req, res) => {
  res.set("Cache-Control", "no-store");
  res.json({ iceServers: buildIceServers(req.user) });
});

// مدیریت خطای multer برای پیوست چت — همان الگوی routes/doctors.js (آپلود امضا/انتقال فایل)
function handleChatAttachmentUpload(req, res, next) {
  uploadChatAttachment.single("file")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم فایل نباید بیشتر از ۱۵ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "آپلود پیوست ناموفق بود" });
  });
}

router.get("/conversations", listConversations);
router.post("/conversations", startConversationValidation, startConversation);
router.get("/conversations/:conversationId/messages", getMessages);
router.post("/conversations/:conversationId/messages", sendMessageValidation, sendMessage);
// ویرایش/حذف یک پیام — فقط فرستنده‌ی خودِ پیام مجاز است (بررسی مالکیت در chatController)؛
// همان قوانین اعتبارسنجی متن پیام ارسالی (sendMessageValidation) برای ویرایش هم اعمال می‌شود
router.put("/conversations/:conversationId/messages/:messageId", sendMessageValidation, editMessage);
router.delete("/conversations/:conversationId/messages/:messageId", deleteMessage);
// واکنش ایموجی روی یک پیام — هر دو طرفِ مکالمه مجازند (بررسی دسترسی در chatController)
router.post("/conversations/:conversationId/messages/:messageId/reactions", reactToMessageValidation, reactToMessage);
// پیوست عکس/سند به یک پیام تازه (multipart/form-data: file الزامی، content اختیاری) —
// آپلود امن مشابه ماژول انتقال معلومات بیمار (نام‌گذاری تصادفی + بررسی امضای باینری فایل)
router.post(
  "/conversations/:conversationId/attachments",
  handleChatAttachmentUpload,
  verifyChatAttachmentContent,
  sendMessageAttachmentValidation,
  sendMessageAttachment
);
// دانلود/نمایش امن پیوست یک پیام — فقط طرفینِ همان مکالمه (بررسی دسترسی در chatController)
router.get("/conversations/:conversationId/messages/:messageId/attachment", downloadMessageAttachment);

// مدیریت خطای multer برای پیام صوتی — همان الگوی handleChatAttachmentUpload، سقف حجم جداگانه (۸ مگابایت)
function handleChatVoiceUpload(req, res, next) {
  uploadChatVoice.single("file")(req, res, (err) => {
    if (!err) return next();
    if (err instanceof multer.MulterError && err.code === "LIMIT_FILE_SIZE") {
      return res.status(400).json({ message: "حجم پیام صوتی نباید بیشتر از ۸ مگابایت باشد" });
    }
    return res.status(400).json({ message: err.message || "ارسال پیام صوتی ناموفق بود" });
  });
}

// ارسال پیام صوتی (multipart/form-data: file الزامی، duration به ثانیه الزامی) — آپلود امن
// مشابه پیوست چت (نام‌گذاری تصادفی + بررسی امضای باینری فایل مخصوص فرمت‌های صوتی)
router.post(
  "/conversations/:conversationId/voice",
  handleChatVoiceUpload,
  verifyChatVoiceContent,
  sendVoiceMessageValidation,
  sendVoiceMessage
);

export default router;

import express from "express";
import {
  generateInvoice, listInvoices, listInvoicesForPatient, getInvoice, addPayment, voidInvoice, approveInvoice, deleteInvoice,
} from "../controllers/billingController.js";
import { requireAuth, authorize } from "../middleware/auth.js";
import { generateInvoiceValidation, recordPaymentValidation } from "../middleware/formValidators.js";

const router = express.Router();

// این کل ماژول فقط برای ادمین/سوپرادمین (کارمندان بخش صورت‌حساب) است؛
// بیمار سوابق و جزئیات فاکتورهای خودش را از طریق /api/users/invoices می‌بیند
router.use(requireAuth, authorize("admin", "superadmin"));

// صدور فاکتور (الزام ۱) + فهرست/سوابق صورت‌حساب (الزام ۵)
router.get("/invoices", listInvoices);
router.post("/invoices", generateInvoiceValidation, generateInvoice);
router.get("/invoices/:id", getInvoice);
router.put("/invoices/:id/cancel", voidInvoice);

// تایید فاکتور (Invoice Approval Workflow) — فقط admin/superadmin (طبق router.use بالا)
router.put("/invoices/:id/approve", approveInvoice);

// حذف کامل فاکتور (Delete Synchronization) — فقط admin/superadmin (طبق router.use بالا)؛
// داکتر/بیمار به این روتر اصلاً دسترسی ندارند (RBAC — الزام شماره ۵)
router.delete("/invoices/:id", deleteInvoice);

// ثبت پرداخت (الزام ۲) — وضعیت فاکتور (الزام ۳) به‌صورت خودکار در پاسخ برمی‌گردد
router.post("/invoices/:id/payments", recordPaymentValidation, addPayment);

// سوابق صورت‌حساب یک بیمار مشخص (برای نمایش در پرونده‌ی بیمار)
router.get("/patients/:patientId/invoices", listInvoicesForPatient);

export default router;

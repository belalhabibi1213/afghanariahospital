-- ⚠️ هشدار: این فایل دستی است و ممکن است با مهاجرت‌های نسخه‌دار (db/migrations/versions) ناهماهنگ باشد.
-- راه‌اندازی عادی نیازی به آن ندارد (db.js اسکیما را می‌سازد). برای اسکیمای به‌روز: node db/dumpSchema.js > schema.sql
-- =====================================================================
-- شفاخانه افغان آریا (Shafakhana) — فایل واحد و کامل دیتابیس
-- =====================================================================
-- این فایل «ادغام‌شده‌ی» دو فایل قبلی (database.sql قدیمی + database_full.sql جدید) است
-- و فایل database.sql حذف شده است؛ از این پس فقط همین یک فایل لازم است.
--
--   • شامل همه‌ی ۳۶ جدول اصلی + جدول داخلی _migrations (جمعاً ۳۷ جدول)
--   • حالت نهایی ساختار بعد از اعمال تمام مهاجرت‌های backend/db/migrations
--   • ستون‌هایی که فقط در فایل قدیمی بودند اضافه شدند:
--       prescriptions.quantity / medicineNotes / groupId / status
--   • طول ستون‌های رنگِ departments (۴۰) و فیلدهای طبیِ users (TEXT) از نسخه‌ی
--     گسترده‌تر گرفته شد تا هیچ داده‌ای بریده نشود
--   • ستون activeSlotKey و ایندکس uq_appointments_active_slot (فقط در فایل قدیمی)
--     عمداً وارد نشد: بک‌اند (db/migrations/appointments-and-news.js) آن‌ها را
--     حذف می‌کند، چون ظرفیت چندنفره‌ی هر نوبت را مسدود می‌کرد
--
-- نحوه‌ی استفاده در phpMyAdmin:
--   ۱. XAMPP → Start MySQL
--   ۲. phpMyAdmin → تب Import → همین فایل → Go
--      (دیتابیس shafakhana خودش ساخته می‌شود)
--
-- نکته: اجرای دستی لازم نیست؛ اگر بک‌اند را اجرا کنید همین ساختار را خودش می‌سازد.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `shafakhana` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `shafakhana`;

-- =====================================================================
-- ۰) جدول داخلی نسخه‌های مهاجرت (فقط برای ردیابی ارتقای خودکار دیتابیس)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `_migrations` (
  `id` INT PRIMARY KEY,
  `appliedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۱) users — کاربران (بیمار/ادمین/سوپرادمین/داکتر)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `fullName` VARCHAR(150) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('user','admin','superadmin','doctor') NOT NULL DEFAULT 'user',
  `phone` VARCHAR(30) NULL,
  `isActive` TINYINT(1) NOT NULL DEFAULT 1,
  `isVerified` TINYINT(1) NOT NULL DEFAULT 0,
  `verificationCodeHash` VARCHAR(255) NULL,
  `verificationExpires` DATETIME NULL,
  `resetCodeHash` VARCHAR(255) NULL,
  `resetExpires` DATETIME NULL,
  `verificationAttempts` INT NOT NULL DEFAULT 0,
  `resetAttempts` INT NOT NULL DEFAULT 0,
  `photoUrl` VARCHAR(255) NULL,
  `dateOfBirth` DATE NULL,
  `gender` ENUM('male','female','other') NULL,
  `bloodGroup` ENUM('A+','A-','B+','B-','AB+','AB-','O+','O-') NULL,
  `address` VARCHAR(255) NULL,
  `emergencyContactName` VARCHAR(150) NULL,
  `emergencyContactRelationship` VARCHAR(50) NULL,
  `emergencyContactPhone` VARCHAR(30) NULL,
  `allergies` TEXT NULL,
  `chronicDiseases` TEXT NULL,
  `drugAllergies` TEXT NULL,
  `height` DECIMAL(5,2) NULL,
  `weight` DECIMAL(5,2) NULL,
  `themePreference` VARCHAR(10) NOT NULL DEFAULT 'light',
  `palettePreference` VARCHAR(20) NOT NULL DEFAULT 'teal',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۲) doctors — داکتران
-- =====================================================================
CREATE TABLE IF NOT EXISTS `doctors` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `doctorCode` VARCHAR(20) NOT NULL,
  `fullName` VARCHAR(150) NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `yearsExperience` INT NOT NULL DEFAULT 0,
  `gender` VARCHAR(10) NOT NULL DEFAULT 'men',
  `photoId` INT NOT NULL DEFAULT 1,
  `rating` DECIMAL(2,1) NOT NULL DEFAULT 4.5,
  `workDays` VARCHAR(150) NOT NULL DEFAULT 'شنبه تا چهارشنبه',
  `photoUrl` VARCHAR(255) NULL,
  `bio` TEXT NULL,
  `userId` INT NULL UNIQUE,
  `signatureUrl` VARCHAR(255) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_doctor_code` (`doctorCode`),
  CONSTRAINT `fk_doctors_userId` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۳) patients — بیماران
-- =====================================================================
CREATE TABLE IF NOT EXISTS `patients` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NULL,
  `fullName` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(30) NOT NULL,
  `email` VARCHAR(150) NULL,
  `gender` ENUM('male','female') NULL,
  `dateOfBirth` DATE NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۴) appointments — نوبت‌ها
-- =====================================================================
CREATE TABLE IF NOT EXISTS `appointments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `department` VARCHAR(100) NOT NULL,
  `appointmentDate` DATE NOT NULL,
  `appointmentTime` TIME NOT NULL,
  `notes` TEXT NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۵) appointment_status_history — تاریخچه‌ی تغییر وضعیت نوبت
-- =====================================================================
CREATE TABLE IF NOT EXISTS `appointment_status_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `appointmentId` INT NOT NULL,
  `oldStatus` VARCHAR(20) NULL,
  `newStatus` VARCHAR(20) NOT NULL,
  `changedByUserId` INT NULL,
  `changedByRole` VARCHAR(20) NULL,
  `note` VARCHAR(255) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`changedByUserId`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۶) news — اخبار و مقالات
-- =====================================================================
CREATE TABLE IF NOT EXISTS `news` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `title` VARCHAR(255) NOT NULL,
  `titleEn` VARCHAR(255) NULL,
  `excerpt` TEXT NOT NULL,
  `excerptEn` TEXT NULL,
  `content` TEXT NULL,
  `contentEn` TEXT NULL,
  `tag` VARCHAR(100) NOT NULL,
  `type` ENUM('news','article') NOT NULL DEFAULT 'news',
  `author` VARCHAR(150) NULL,
  `status` ENUM('draft','published','scheduled') NOT NULL DEFAULT 'draft',
  `imageUrl` VARCHAR(500) NULL,
  `scheduledAt` DATETIME NULL,
  `isPinned` TINYINT(1) NOT NULL DEFAULT 0,
  `tags` VARCHAR(500) NULL,
  `views` INT NOT NULL DEFAULT 0,
  `metaTitle` VARCHAR(255) NULL,
  `metaDescription` VARCHAR(500) NULL,
  `publishedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۷) news_gallery — گالری تصاویر خبر
-- =====================================================================
CREATE TABLE IF NOT EXISTS `news_gallery` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `newsId` INT NOT NULL,
  `imageUrl` VARCHAR(500) NOT NULL,
  `sortOrder` INT NOT NULL DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`newsId`) REFERENCES `news`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۸) news_likes — لایک‌های خبر
-- =====================================================================
CREATE TABLE IF NOT EXISTS `news_likes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `newsId` INT NOT NULL,
  `userId` INT NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_news_likes_news_user` (`newsId`, `userId`),
  FOREIGN KEY (`newsId`) REFERENCES `news`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۹) news_comments — نظرات خبر
-- =====================================================================
CREATE TABLE IF NOT EXISTS `news_comments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `newsId` INT NOT NULL,
  `userId` INT NOT NULL,
  `content` TEXT NOT NULL,
  `status` ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`newsId`) REFERENCES `news`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۰) news_views — شمارنده‌ی بازدید بدون تکرار
-- =====================================================================
CREATE TABLE IF NOT EXISTS `news_views` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `newsId` INT NOT NULL,
  `viewerKey` VARCHAR(64) NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`newsId`) REFERENCES `news`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۱) departments — بخش‌های شفاخانه
-- =====================================================================
CREATE TABLE IF NOT EXISTS `departments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `nameEn` VARCHAR(100) NULL,
  `description` TEXT NULL,
  `descriptionEn` TEXT NULL,
  `icon` VARCHAR(255) NULL,
  `coverImage` VARCHAR(255) NULL,
  `iconType` ENUM('upload','lucide') NOT NULL DEFAULT 'lucide',
  `iconColor` VARCHAR(40) NULL,
  `iconBackground` VARCHAR(40) NULL,
  `cardBackground` VARCHAR(40) NULL,
  `textColor` VARCHAR(40) NULL,
  `slug` VARCHAR(150) NULL,
  `displayOrder` INT NOT NULL DEFAULT 0,
  `status` ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `showOnWebsite` TINYINT(1) NOT NULL DEFAULT 1,
  `seoTitle` VARCHAR(200) NULL,
  `seoDescription` VARCHAR(300) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_departments_slug` (`slug`)
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۲) services — خدمات شفاخانه (کاتالوگ، برای جستجوی سراسری)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `services` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `description` TEXT NULL,
  `department` VARCHAR(100) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۳) specialties — تخصص‌های بالینی (کاتالوگ)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `specialties` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL UNIQUE,
  `description` TEXT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۴) medicines — ادویه (کاتالوگ، فقط نمایشی)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `medicines` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(150) NOT NULL,
  `genericName` VARCHAR(150) NULL,
  `description` TEXT NULL,
  `requiresPrescription` TINYINT(1) NOT NULL DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۵) schedules — برنامه‌ی کاری داکتران
-- =====================================================================
CREATE TABLE IF NOT EXISTS `schedules` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `doctorId` INT NOT NULL,
  `dayOfWeek` VARCHAR(20) NOT NULL,
  `startTime` TIME NOT NULL,
  `endTime` TIME NOT NULL,
  `breakStart` TIME NULL,
  `breakEnd` TIME NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۶) medical_records — پرونده‌ی صحی (ویزیت‌ها)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `medical_records` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NULL,
  `appointmentId` INT NULL,
  `visitDate` DATE NOT NULL DEFAULT (CURRENT_DATE),
  `diagnosis` TEXT NULL,
  `symptoms` TEXT NULL,
  `bloodPressure` VARCHAR(20) NULL,
  `temperature` VARCHAR(20) NULL,
  `height` VARCHAR(20) NULL,
  `weight` VARCHAR(20) NULL,
  `labResults` TEXT NULL,
  `treatment` TEXT NULL,
  `prescription` TEXT NULL,
  `notes` TEXT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۷) diagnoses — تشخیص‌ها (EMR)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `diagnoses` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NULL,
  `recordId` INT NULL,
  `title` VARCHAR(255) NOT NULL,
  `description` TEXT NULL,
  `icdCode` VARCHAR(20) NULL,
  `status` ENUM('active','resolved') NOT NULL DEFAULT 'active',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`recordId`) REFERENCES `medical_records`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۸) prescriptions — نسخه‌ها (EMR)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `prescriptions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NULL,
  `recordId` INT NULL,
  `appointmentId` INT NULL,
  `medicationName` VARCHAR(150) NOT NULL,
  `dosage` VARCHAR(100) NULL,
  `frequency` VARCHAR(100) NULL,
  `duration` VARCHAR(100) NULL,
  `instructions` TEXT NULL,
  `diagnosis` TEXT NULL,
  `followUpDate` DATE NULL,
  `notes` TEXT NULL,
  `quantity` VARCHAR(50) NULL,
  `medicineNotes` VARCHAR(500) NULL,
  `groupId` VARCHAR(36) NULL,
  `status` VARCHAR(20) NOT NULL DEFAULT 'active',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`recordId`) REFERENCES `medical_records`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_prescriptions_appointmentId` FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۱۹) allergies — حساسیت‌ها (EMR)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `allergies` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NULL,
  `allergen` VARCHAR(150) NOT NULL,
  `reaction` VARCHAR(255) NULL,
  `severity` ENUM('mild','moderate','severe') NOT NULL DEFAULT 'mild',
  `notes` TEXT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۰) lab_results — نتایج آزمایشگاه (EMR)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `lab_results` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NULL,
  `recordId` INT NULL,
  `testName` VARCHAR(150) NOT NULL,
  `result` TEXT NULL,
  `unit` VARCHAR(50) NULL,
  `referenceRange` VARCHAR(100) NULL,
  `status` ENUM('pending','completed') NOT NULL DEFAULT 'completed',
  `testDate` DATE NULL,
  `reportUrl` VARCHAR(255) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`recordId`) REFERENCES `medical_records`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۱) radiology_reports — گزارش‌های رادیولوژی (EMR)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `radiology_reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NULL,
  `recordId` INT NULL,
  `examType` VARCHAR(150) NOT NULL,
  `findings` TEXT NULL,
  `impression` TEXT NULL,
  `imageUrl` VARCHAR(255) NULL,
  `examDate` DATE NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`recordId`) REFERENCES `medical_records`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۲) file_transfers — انتقال معلومات بیمار (فایل/سند)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `file_transfers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `fileName` VARCHAR(255) NOT NULL,
  `originalName` VARCHAR(255) NOT NULL,
  `fileType` VARCHAR(150) NOT NULL,
  `fileSize` INT NOT NULL,
  `note` TEXT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۳) chat_conversations — گفتگوی خصوصی بیمار ↔ داکتر
-- =====================================================================
CREATE TABLE IF NOT EXISTS `chat_conversations` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `patientId` INT NOT NULL,
  `doctorId` INT NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_chat_conversation_patient_doctor` (`patientId`, `doctorId`),
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۴) chat_messages — پیام‌های گفتگو
-- =====================================================================
CREATE TABLE IF NOT EXISTS `chat_messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `conversationId` INT NOT NULL,
  `senderUserId` INT NOT NULL,
  `senderRole` VARCHAR(20) NOT NULL,
  `content` TEXT NOT NULL,
  `isRead` TINYINT(1) NOT NULL DEFAULT 0,
  `isDelivered` TINYINT(1) NOT NULL DEFAULT 0,
  `isEdited` TINYINT(1) NOT NULL DEFAULT 0,
  `editedAt` TIMESTAMP NULL,
  `isDeleted` TINYINT(1) NOT NULL DEFAULT 0,
  `deletedAt` TIMESTAMP NULL,
  `attachmentFileName` VARCHAR(255) NULL,
  `attachmentOriginalName` VARCHAR(255) NULL,
  `attachmentFileType` VARCHAR(150) NULL,
  `attachmentFileSize` INT NULL,
  `attachmentDurationSeconds` INT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`conversationId`) REFERENCES `chat_conversations`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`senderUserId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۵) chat_message_reactions — واکنش ایموجی روی پیام
-- =====================================================================
CREATE TABLE IF NOT EXISTS `chat_message_reactions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `messageId` INT NOT NULL,
  `userId` INT NOT NULL,
  `emoji` VARCHAR(16) NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uniq_chat_message_reaction_user` (`messageId`, `userId`),
  FOREIGN KEY (`messageId`) REFERENCES `chat_messages`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۶) notifications — اعلان‌ها
-- =====================================================================
CREATE TABLE IF NOT EXISTS `notifications` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `title` VARCHAR(150) NOT NULL,
  `message` TEXT NOT NULL,
  `type` VARCHAR(30) NOT NULL DEFAULT 'general',
  `relatedId` INT NULL,
  `isRead` TINYINT(1) NOT NULL DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۷) activity_logs — لاگ فعالیت‌ها
-- =====================================================================
CREATE TABLE IF NOT EXISTS `activity_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NULL,
  `userName` VARCHAR(150) NULL,
  `role` VARCHAR(20) NULL,
  `action` VARCHAR(255) NOT NULL,
  `details` TEXT NULL,
  `ipAddress` VARCHAR(45) NULL,
  `userAgent` VARCHAR(255) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۸) user_sessions — نشست‌ها و دستگاه‌های فعال (Super Admin)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `userId` INT NOT NULL,
  `tokenId` VARCHAR(64) NOT NULL,
  `userName` VARCHAR(150) NULL,
  `role` VARCHAR(20) NULL,
  `ipAddress` VARCHAR(45) NULL,
  `userAgent` VARCHAR(255) NULL,
  `loginAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `lastActivityAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expiresAt` DATETIME NULL,
  `revokedAt` DATETIME NULL,
  `revokedByUserId` INT NULL,
  UNIQUE KEY `uq_user_sessions_tokenId` (`tokenId`),
  FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`revokedByUserId`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۲۹) audit_logs — سیستم حسابرسی (Audit Trail، فقط Super Admin)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `tableName` VARCHAR(100) NOT NULL,
  `recordId` VARCHAR(50) NULL,
  `action` ENUM('INSERT','UPDATE','DELETE') NOT NULL,
  `oldValues` JSON NULL,
  `newValues` JSON NULL,
  `changedFields` TEXT NULL,
  `userId` INT NULL,
  `userName` VARCHAR(150) NULL,
  `userRole` VARCHAR(20) NULL,
  `ipAddress` VARCHAR(45) NULL,
  `userAgent` VARCHAR(255) NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۳۰) settings — تنظیمات سیستم (key/value)
-- =====================================================================
CREATE TABLE IF NOT EXISTS `settings` (
  `key` VARCHAR(100) PRIMARY KEY,
  `value` TEXT NULL,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۳۱) contacts — پیام‌های «تماس با ما»
-- =====================================================================
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `fullName` VARCHAR(150) NOT NULL,
  `phone` VARCHAR(30) NULL,
  `email` VARCHAR(150) NULL,
  `message` TEXT NOT NULL,
  `status` ENUM('unread','read') NOT NULL DEFAULT 'unread',
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- ۳۲) invoices — فاکتورها
-- =====================================================================
CREATE TABLE IF NOT EXISTS `invoices` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoiceNumber` VARCHAR(30) NOT NULL,
  `patientId` INT NOT NULL,
  `doctorId` INT NULL,
  `appointmentId` INT NULL,
  `issueDate` DATE NOT NULL,
  `dueDate` DATE NULL,
  `subtotal` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `discount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `tax` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `totalAmount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `paidAmount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `status` VARCHAR(20) NOT NULL DEFAULT 'unpaid',
  `approvalStatus` ENUM('pending','approved') NOT NULL DEFAULT 'pending',
  `approvedByUserId` INT NULL,
  `approvedAt` DATETIME NULL,
  `notes` TEXT NULL,
  `createdByUserId` INT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `uq_invoices_invoiceNumber` (`invoiceNumber`),
  FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`doctorId`) REFERENCES `doctors`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE SET NULL,
  FOREIGN KEY (`createdByUserId`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_invoices_approvedByUserId` FOREIGN KEY (`approvedByUserId`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =====================================================================
-- ۳۳) invoice_items — ردیف‌های فاکتور
-- =====================================================================
CREATE TABLE IF NOT EXISTS `invoice_items` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoiceId` INT NOT NULL,
  `description` VARCHAR(255) NOT NULL,
  `quantity` DECIMAL(10,2) NOT NULL DEFAULT 1,
  `unitPrice` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `amount` DECIMAL(10,2) NOT NULL DEFAULT 0,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`invoiceId`) REFERENCES `invoices`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- ۳۴) payments — پرداخت‌ها
-- =====================================================================
CREATE TABLE IF NOT EXISTS `payments` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `invoiceId` INT NOT NULL,
  `amount` DECIMAL(10,2) NOT NULL,
  `method` VARCHAR(20) NOT NULL DEFAULT 'cash',
  `paidAt` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reference` VARCHAR(100) NULL,
  `receivedByUserId` INT NULL,
  `notes` TEXT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`invoiceId`) REFERENCES `invoices`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`receivedByUserId`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- =====================================================================
-- ایندکس‌های جستجو / بهینه‌سازی
-- =====================================================================
ALTER TABLE `patients` ADD INDEX `idx_patients_fullName` (`fullName`);
ALTER TABLE `patients` ADD INDEX `idx_patients_phone` (`phone`);
ALTER TABLE `patients` ADD INDEX `idx_patients_email` (`email`);
ALTER TABLE `doctors` ADD INDEX `idx_doctors_department` (`department`);
ALTER TABLE `doctors` ADD INDEX `idx_doctors_fullName` (`fullName`);
ALTER TABLE `appointments` ADD INDEX `idx_appointments_status` (`status`);
ALTER TABLE `appointments` ADD INDEX `idx_appointments_date` (`appointmentDate`);
ALTER TABLE `appointments` ADD INDEX `idx_appointments_date_status` (`appointmentDate`, `status`);
ALTER TABLE `appointments` ADD INDEX `idx_appointments_doctor_date_time` (`doctorId`, `appointmentDate`, `appointmentTime`);
ALTER TABLE `appointment_status_history` ADD INDEX `idx_history_appointmentId` (`appointmentId`);
ALTER TABLE `diagnoses` ADD INDEX `idx_diagnoses_patientId` (`patientId`);
ALTER TABLE `prescriptions` ADD INDEX `idx_prescriptions_patientId` (`patientId`);
ALTER TABLE `prescriptions` ADD INDEX `idx_prescriptions_appointmentId` (`appointmentId`);
ALTER TABLE `allergies` ADD INDEX `idx_allergies_patientId` (`patientId`);
ALTER TABLE `lab_results` ADD INDEX `idx_lab_results_patientId` (`patientId`);
ALTER TABLE `radiology_reports` ADD INDEX `idx_radiology_reports_patientId` (`patientId`);
ALTER TABLE `file_transfers` ADD INDEX `idx_file_transfers_patientId` (`patientId`);
ALTER TABLE `file_transfers` ADD INDEX `idx_file_transfers_doctorId` (`doctorId`);
ALTER TABLE `file_transfers` ADD INDEX `idx_file_transfers_createdAt` (`createdAt`);
ALTER TABLE `chat_conversations` ADD INDEX `idx_chat_conversations_patientId` (`patientId`);
ALTER TABLE `chat_conversations` ADD INDEX `idx_chat_conversations_doctorId` (`doctorId`);
ALTER TABLE `chat_messages` ADD INDEX `idx_chat_messages_conversationId` (`conversationId`);
ALTER TABLE `chat_messages` ADD INDEX `idx_chat_messages_conversationId_isRead` (`conversationId`, `isRead`);
ALTER TABLE `chat_messages` ADD INDEX `idx_chat_messages_createdAt` (`createdAt`);
ALTER TABLE `chat_message_reactions` ADD INDEX `idx_chat_message_reactions_messageId` (`messageId`);
ALTER TABLE `invoices` ADD INDEX `idx_invoices_patientId` (`patientId`);
ALTER TABLE `invoices` ADD INDEX `idx_invoices_status` (`status`);
ALTER TABLE `invoices` ADD INDEX `idx_invoices_issueDate` (`issueDate`);
ALTER TABLE `invoices` ADD INDEX `idx_invoices_approvalStatus` (`approvalStatus`);
ALTER TABLE `invoice_items` ADD INDEX `idx_invoice_items_invoiceId` (`invoiceId`);
ALTER TABLE `payments` ADD INDEX `idx_payments_invoiceId` (`invoiceId`);
ALTER TABLE `news` ADD INDEX `idx_news_status` (`status`);
ALTER TABLE `news` ADD INDEX `idx_news_isPinned` (`isPinned`);
ALTER TABLE `news` ADD INDEX `idx_news_scheduledAt` (`scheduledAt`);
ALTER TABLE `news` ADD INDEX `idx_news_type` (`type`);
ALTER TABLE `news_gallery` ADD INDEX `idx_news_gallery_newsId` (`newsId`);
ALTER TABLE `news_likes` ADD INDEX `idx_news_likes_newsId` (`newsId`);
ALTER TABLE `news_comments` ADD INDEX `idx_news_comments_newsId` (`newsId`);
ALTER TABLE `news_comments` ADD INDEX `idx_news_comments_status` (`status`);
ALTER TABLE `user_sessions` ADD INDEX `idx_user_sessions_userId` (`userId`);
ALTER TABLE `user_sessions` ADD INDEX `idx_user_sessions_revokedAt` (`revokedAt`);
ALTER TABLE `user_sessions` ADD INDEX `idx_user_sessions_expiresAt` (`expiresAt`);
ALTER TABLE `departments` ADD INDEX `idx_departments_displayOrder` (`displayOrder`);
ALTER TABLE `departments` ADD INDEX `idx_departments_status` (`status`);
ALTER TABLE `audit_logs` ADD INDEX `idx_audit_logs_tableName` (`tableName`);
ALTER TABLE `audit_logs` ADD INDEX `idx_audit_logs_recordId` (`recordId`);
ALTER TABLE `audit_logs` ADD INDEX `idx_audit_logs_userId` (`userId`);
ALTER TABLE `audit_logs` ADD INDEX `idx_audit_logs_action` (`action`);
ALTER TABLE `audit_logs` ADD INDEX `idx_audit_logs_createdAt` (`createdAt`);

-- =====================================================================
-- ایندکس‌های تمام‌متنی (FULLTEXT) — موتور «جستجوی سراسری» هدر
-- =====================================================================
ALTER TABLE `doctors` ADD FULLTEXT INDEX `ft_doctors_search` (`fullName`, `department`, `bio`);
ALTER TABLE `departments` ADD FULLTEXT INDEX `ft_departments_search` (`name`, `description`);
ALTER TABLE `services` ADD FULLTEXT INDEX `ft_services_search` (`name`, `description`);
ALTER TABLE `specialties` ADD FULLTEXT INDEX `ft_specialties_search` (`name`, `description`);
ALTER TABLE `medicines` ADD FULLTEXT INDEX `ft_medicines_search` (`name`, `genericName`, `description`);
ALTER TABLE `news` ADD FULLTEXT INDEX `ft_news_search` (`title`, `excerpt`, `tag`);

-- =====================================================================
-- Trigger های حفاظت از جدول حسابرسی (audit_logs غیرقابل ویرایش/حذف)
-- =====================================================================
DELIMITER $$

CREATE TRIGGER `trg_audit_logs_no_update`
BEFORE UPDATE ON `audit_logs`
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ثبت‌های حسابرسی غیرقابل ویرایش هستند (Audit logs are immutable)';
END$$

CREATE TRIGGER `trg_audit_logs_no_delete`
BEFORE DELETE ON `audit_logs`
FOR EACH ROW
BEGIN
  SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ثبت‌های حسابرسی غیرقابل حذف هستند (Audit logs cannot be deleted)';
END$$

DELIMITER ;

-- =====================================================================
-- علامت‌گذاری مهاجرت (تا خودِ Node.js دوباره سعی نکند appointments/doctors
-- را برای «ارتقای نسخه قدیم» پاک کند — این فقط برای نصب تازه است)
-- =====================================================================
INSERT INTO `_migrations` (`id`) VALUES (3) ON DUPLICATE KEY UPDATE `id` = `id`;

-- =====================================================================
-- داده‌های اولیه / نمونه (Seed Data) — همان چیزی که db.js هنگام اجرای
-- اول بک‌اند خودکار درج می‌کند. اگر نمی‌خواهید داده‌ی نمونه داشته باشید،
-- از این‌جا تا انتهای فایل را اجرا نکنید.
-- =====================================================================

-- حساب‌های کاربر آزمایشی / مدیر کل / ادمین عمداً در این فایل ساخته نمی‌شوند (قبلاً با رمزهای ثابت و
-- شناخته‌شده ساخته می‌شدند). هنگام اولین اجرای بک‌اند، اگر جدول users خالی باشد، این حساب‌ها با
-- «رمز تصادفی یکتا» ساخته می‌شوند، رمز فقط همان یک‌بار در کنسول سرور چاپ می‌شود و در اولین ورود
-- تغییر رمز اجباری است (mustChangePassword).

-- بخش‌های پیش‌فرض
INSERT INTO `departments` (`name`) VALUES
('قلب و عروق'), ('اطفال'), ('زنان و زایمان'), ('ارتوپیدی'), ('دندان'), ('داخله'), ('چشم'), ('اعصاب');

-- تنظیمات پیش‌فرض
INSERT INTO `settings` (`key`, `value`) VALUES
('hospitalName', 'شفاخانه افغان آریا'),
('maintenanceMode', 'off');

-- ۸ داکتر نمونه
INSERT INTO `doctors` (`doctorCode`, `fullName`, `department`, `yearsExperience`, `gender`, `photoId`, `rating`, `workDays`, `photoUrl`) VALUES
('DR-1001', 'داکتر عزیزالرحمن امیری', 'قلب و عروق', 15, 'men', 32, 4.9, 'شنبه، یکشنبه، سه‌شنبه', NULL),
('DR-1002', 'داکتره پرسیلا طاهری', 'اطفال', 10, 'women', 68, 4.8, 'یکشنبه تا پنجشنبه', NULL),
('DR-1003', 'داکتره مریم صادقی', 'زنان و زایمان', 12, 'women', 44, 4.7, 'شنبه تا سه‌شنبه', NULL),
('DR-1004', 'داکتر محسن فروتن', 'ارتوپیدی', 9, 'men', 22, 4.6, 'دوشنبه، چهارشنبه، پنجشنبه', NULL),
('DR-1005', 'داکتره فرزانه کریمی', 'دندان', 7, 'women', 21, 4.8, 'همه روزه', NULL),
('DR-1006', 'داکتر توریالی سبحانی', 'داخله', 18, 'men', 54, 4.9, 'شنبه تا چهارشنبه', NULL),
('DR-1007', 'داکتره لیلا احمدی', 'قلب و عروق', 11, 'women', 60, 4.7, 'یکشنبه، سه‌شنبه، پنجشنبه', NULL),
('DR-1008', 'داکتر بشیر نظری', 'اطفال', 8, 'men', 63, 4.6, 'شنبه، دوشنبه، چهارشنبه', NULL);

-- ۶ خبر نمونه
INSERT INTO `news` (`title`, `excerpt`, `tag`, `imageUrl`) VALUES
('۵ نشانه که باید به داکتر قلب مراجعه کنید', 'درد قفسه سینه همیشه جدی نیست، اما این نشانه‌ها را نباید نادیده گرفت...', 'قلب و عروق', 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800'),
('تغذیه سالم برای کودکان در فصل تابستان', 'چند نکته ساده برای اینکه فرزندتان در گرمای تابستان سالم و پرانرژی بماند...', 'اطفال', 'https://images.pexels.com/photos/8460035/pexels-photo-8460035.jpeg?auto=compress&cs=tinysrgb&w=800'),
('چرا معاینه دوره‌ای چشم مهم است؟', 'بسیاری از مشکلات چشمی در مراحل اول علامتی ندارند؛ معاینه منظم را جدی بگیرید...', 'چشم', 'https://images.pexels.com/photos/5452193/pexels-photo-5452193.jpeg?auto=compress&cs=tinysrgb&w=1200'),
('ورزش و سلامت مفاصل: از کجا شروع کنیم؟', 'راهنمای ساده برای شروع فعالیت بدنی بدون آسیب به زانو و کمر...', 'ارتوپیدی', 'https://images.pexels.com/photos/12955896/pexels-photo-12955896.jpeg?auto=compress&cs=tinysrgb&w=800'),
('استرس و تاثیر آن بر مغز و اعصاب', 'چگونه استرس روزمره را مدیریت کنیم تا به سلامت ذهنی ما آسیب نزند...', 'اعصاب', 'https://images.pexels.com/photos/5452190/pexels-photo-5452190.jpeg?auto=compress&cs=tinysrgb&w=1200'),
('مراقبت از دندان‌ها؛ عادت‌های روزانه ضروری', 'چند عادت ساده که می‌تواند از پوسیدگی دندان جلوگیری کند...', 'دندان', 'https://images.pexels.com/photos/4269698/pexels-photo-4269698.jpeg?auto=compress&cs=tinysrgb&w=800');

-- خدمات نمونه
INSERT INTO `services` (`name`, `description`, `department`) VALUES
('معاینات عمومی و چکاپ', 'چکاپ کامل و معاینه‌ی اولیه توسط داکتران عمومی، هر روز از ساعت ۸ صبح تا ۴ عصر.', 'داخله'),
('تصویربرداری (سی‌تی‌اسکن و اشعه ایکس)', 'خدمات رادیولوژی برای تشخیص دقیق‌تر بیماری‌ها.', NULL),
('آزمایشگاه تشخیص طبی', 'انجام انواع آزمایش‌های خون، ادرار و میکروبیولوژی با نتیجه‌ی سریع.', NULL),
('جراحی‌های عمومی و تخصصی', 'اتاق عمل مجهز برای جراحی‌های کوچک و بزرگ زیر نظر جراحان مجرب.', NULL),
('فزیوتراپی و توانبخشی', 'برنامه‌های درمانی فردی برای بازتوانی پس از آسیب یا جراحی.', 'ارتوپیدی'),
('نوبت‌دهی و مشاوره آنلاین', 'رزرو نوبت با داکتر دلخواه از طریق سایت، بدون نیاز به حضور فیزیکی.', NULL);

-- تخصص‌های نمونه
INSERT IGNORE INTO `specialties` (`name`, `description`) VALUES
('قلب و عروق', 'تشخیص و درمان بیماری‌های قلبی و فشار خون'),
('اطفال', 'مراقبت صحی کودکان از تولد تا نوجوانی'),
('زنان و زایمان', 'مراقبت پیش و پس از زایمان و سلامت باروری'),
('ارتوپیدی', 'درمان آسیب‌های استخوان، مفصل و عضلات'),
('دندان', 'خدمات دندان‌پزشکی عمومی و تخصصی'),
('داخله', 'تشخیص و درمان بیماری‌های عمومی داخلی'),
('چشم', 'معاینه و درمان بیماری‌های چشم'),
('اعصاب', 'تشخیص و درمان بیماری‌های مغز و اعصاب');

-- ادویه نمونه
INSERT INTO `medicines` (`name`, `genericName`, `description`, `requiresPrescription`) VALUES
('پاراستامول', 'Paracetamol', 'تسکین‌دهنده‌ی درد و تب خفیف تا متوسط', 0),
('آموکسی‌سیلین', 'Amoxicillin', 'آنتی‌بیوتیک برای درمان عفونت‌های باکتریایی', 1),
('ایبوپروفن', 'Ibuprofen', 'ضدالتهاب و مسکن درد', 0),
('متفورمین', 'Metformin', 'کنترل قند خون در دیابت نوع ۲', 1),
('اومپرازول', 'Omeprazole', 'کاهش اسید معده و درمان زخم گوارشی', 0),
('قطره ویتامین D اطفال', 'Vitamin D3', 'مکمل غذایی برای رشد استخوان کودکان', 0);

-- مقالات صحی نمونه (از همان جدول news، با type='article')
INSERT INTO `news` (`title`, `excerpt`, `tag`, `type`) VALUES
('۷ نکته برای مراقبت از سلامت قلب', 'چند عادت ساده روزانه که خطر بیماری‌های قلبی را کاهش می‌دهد...', 'قلب و عروق', 'article'),
('چگونه در فصل سرما از اطفال مراقبت کنیم', 'راهنمای ساده برای پیشگیری از سرماخوردگی و آنفلوانزا در کودکان...', 'اطفال', 'article'),
('اهمیت تغذیه‌ی متعادل در دوران بارداری', 'چه غذاهایی برای مادر و جنین در دوران بارداری ضروری‌اند...', 'زنان و زایمان', 'article');

-- ۳۵) uploaded_files / uploaded_file_chunks — محتوای عکس‌های عمومی آپلودشده (داکتر، بخش، خبر، پروفایل، لوگو)
-- هر عکس در تکه‌های ۲۵۶ کیلوبایتی ذخیره می‌شود تا با max_allowed_packet کوچک هم کار کند
CREATE TABLE IF NOT EXISTS `uploaded_files` (
  `path` VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NOT NULL PRIMARY KEY,
  `mimeType` VARCHAR(100) NOT NULL,
  `size` INT UNSIGNED NOT NULL,
  `createdAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `uploaded_file_chunks` (
  `path` VARCHAR(190) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `seq` INT UNSIGNED NOT NULL,
  `data` MEDIUMBLOB NOT NULL,
  PRIMARY KEY (`path`, `seq`),
  FOREIGN KEY (`path`) REFERENCES `uploaded_files`(`path`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- پایان فایل — ۳۶ جدول اصلی + ۱ جدول داخلی migrations (ادغام‌شده با database.sql قدیمی)
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 1;


-- محتوای قابل‌ویرایش سایت (بخش معرفی صفحه‌ی اصلی) — جدا از settings
CREATE TABLE IF NOT EXISTS `site_content` (
  `key` VARCHAR(100) PRIMARY KEY,
  `value` MEDIUMTEXT NULL,
  `updatedAt` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

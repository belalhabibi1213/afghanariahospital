import crypto from "crypto";
import { logger } from "../utils/logger.js";

// شناسه‌ی درخواست (X-Request-Id) برای ردیابی یک درخواست بین لاگ‌ها/پروکسی/کلاینت + لاگ پایان هر درخواست.
// شناسه‌ی ورودیِ کلاینت فقط اگر ساده و کوتاه باشد پذیرفته می‌شود (جلوگیری از log injection). مسیرهای سلامت لاگ نمی‌شوند.
// همان منطق getClientIp (models/ActivityLog.js) — اینجا تکرار شده تا این میان‌افزار به دیتابیس وابسته نشود
const clientIp = (req) => (req.ip || req.socket?.remoteAddress || "").replace(/^::ffff:/, "") || null;
const SAFE_ID = /^[A-Za-z0-9._-]{8,64}$/;

export function requestLogger(req, res, next) {
  const incoming = req.get("x-request-id");
  req.id = incoming && SAFE_ID.test(incoming) ? incoming : crypto.randomUUID();
  res.setHeader("X-Request-Id", req.id);
  if (req.path.startsWith("/health")) return next();

  const start = process.hrtime.bigint();
  res.on("finish", () => {
    const durationMs = Number(process.hrtime.bigint() - start) / 1e6;
    const level = res.statusCode >= 500 ? "error" : res.statusCode >= 400 ? "warn" : "info";
    logger[level](
      {
        event: "http.request",
        reqId: req.id,
        method: req.method,
        path: (req.originalUrl || req.url || "").split("?")[0].slice(0, 200), // بدون query (ممکن است حساس باشد)
        status: res.statusCode,
        durationMs: Math.round(durationMs * 10) / 10,
        userId: req.user?.id ?? null,
        role: req.user?.role ?? null,
        ip: clientIp(req),
      },
      "request"
    );
  });
  next();
}

import fs from "fs";
import path from "path";
import crypto from "crypto";
import multer from "multer";
import { fileURLToPath } from "url";
import { looksLikeSvg, sanitizeSvgContent } from "../utils/sanitizeSvg.js";
import { persistUploadedFile } from "../utils/uploadStore.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// عکس‌های پروفایل در backend/uploads/avatars و عکس‌های داکتران در backend/uploads/doctors
// ذخیره می‌شوند (خارج از src فرانت‌اند و با نام تصادفی، تا نه قابل حدس زدن باشند و نه بتوانند
// فایل کاربر/داکتر دیگری را رونویسی کنند)
export const AVATARS_DIR = path.join(__dirname, "..", "uploads", "avatars");
export const DOCTORS_DIR = path.join(__dirname, "..", "uploads", "doctors");
// لوگوی شفاخانه (تنظیمات سیستم) — عمومی و قابل‌دسترسی از /uploads، مثل عکس داکتر/پروفایل
export const LOGO_DIR = path.join(__dirname, "..", "uploads", "logo");
// عکس شاخص (Featured Image) مقالات خبری — عمومی و قابل‌دسترسی از /uploads، مثل عکس داکتر/پروفایل
export const NEWS_DIR = path.join(__dirname, "..", "uploads", "news");
// آیکون بخش‌ها (Department Management > آپلود آیکون) — عمومی و قابل‌دسترسی از /uploads،
// همان الگوی عکس داکتر/لوگو؛ برای نمایش در پنل ادمین و بخش «خدمات ما»ی سایت اصلی
export const DEPARTMENTS_DIR = path.join(__dirname, "..", "uploads", "departments");
fs.mkdirSync(AVATARS_DIR, { recursive: true });
fs.mkdirSync(DOCTORS_DIR, { recursive: true });
fs.mkdirSync(LOGO_DIR, { recursive: true });
fs.mkdirSync(NEWS_DIR, { recursive: true });
fs.mkdirSync(DEPARTMENTS_DIR, { recursive: true });
// عکس بخش «معرفی» صفحه‌ی اصلی (داشبورد ادمین ← مدیریت بخش معرفی) — عمومی از /uploads
export const ABOUT_DIR = path.join(__dirname, "..", "uploads", "about");
fs.mkdirSync(ABOUT_DIR, { recursive: true });
// عکس پس‌زمینه‌ی بخش اصلی (Hero) صفحه‌ی اصلی (داشبورد ادمین ← مدیریت بخش اصلی) — عمومی از /uploads
export const HERO_DIR = path.join(__dirname, "..", "uploads", "hero");
fs.mkdirSync(HERO_DIR, { recursive: true });

// گزارش‌های آزمایشگاهی (لابراتوار) اسناد صحی حساس هستند و برخلاف عکس پروفایل/داکتر
// نباید به‌صورت عمومی از مسیر استاتیک /uploads قابل‌دسترسی باشند. به همین دلیل در یک
// پوشه‌ی جداگانه و خصوصی نگه‌داری می‌شوند و فقط از طریق مسیرهای احرازهویت‌شده (کنترلر)
// و بعد از بررسی مالکیت/نقش کاربر قابل دانلود هستند.
export const LAB_REPORTS_DIR = path.join(__dirname, "..", "private-uploads", "lab-reports");
fs.mkdirSync(LAB_REPORTS_DIR, { recursive: true });

// تصاویر پزشکی و اسناد «پرونده صحی» (فرم افزودن پرونده صحی داکتر) — اسناد حساس صحی؛ پوشه‌ی خصوصی
// و فقط از طریق مسیرهای احرازهویت‌شده بعد از بررسی مالکیت قابل‌دسترسی‌اند.
export const MEDICAL_FILES_DIR = path.join(__dirname, "..", "private-uploads", "medical-files");
fs.mkdirSync(MEDICAL_FILES_DIR, { recursive: true });

// امضای دیجیتال داکتر هم به همین دلیل (ذخیره‌سازی امن — الزام شماره ۲) در همان پوشه‌ی
// خصوصیِ private-uploads نگه‌داری می‌شود، نه در uploads/doctors عمومی: امضا روی هر نسخه
// چاپ می‌شود و اگر عمومی/قابل‌حدس باشد می‌تواند برای جعل نسخه سوءاستفاده شود. فقط از طریق
// مسیر احرازهویت‌شده‌ی «پنل داکتر» (GET/POST /api/doctors/me/signature) قابل‌دسترسی است.
export const SIGNATURES_DIR = path.join(__dirname, "..", "private-uploads", "signatures");
fs.mkdirSync(SIGNATURES_DIR, { recursive: true });

// اسناد ماژول «انتقال معلومات بیمار» (Patient Information Transfer) — گزارش‌ها/اسناد صحی
// ارسالی داکتر به بیمار. مثل گزارش آزمایشگاه، این‌ها اسناد صحی حساس هستند و در پوشه‌ی
// خصوصی نگه‌داری می‌شوند؛ فقط از طریق مسیرهای احرازهویت‌شده و بعد از بررسی مالکیت/نقش
// (داکتر فقط برای بیماران خودش، بیمار فقط فایل‌های خودش) قابل‌دسترسی هستند.
export const FILE_TRANSFERS_DIR = path.join(__dirname, "..", "private-uploads", "file-transfers");
fs.mkdirSync(FILE_TRANSFERS_DIR, { recursive: true });

// پیوست‌های (عکس/سند) پیام‌های چت خصوصی بیمار ↔ داکتر — این‌ها هم مثل گزارش آزمایشگاه/
// انتقال معلومات بیمار اسناد شخصی/صحی هستند که فقط طرفینِ همان مکالمه باید ببینند، پس
// در همان الگوی پوشه‌ی خصوصی (نه uploads عمومی) نگه‌داری می‌شوند.
export const CHAT_ATTACHMENTS_DIR = path.join(__dirname, "..", "private-uploads", "chat-attachments");
fs.mkdirSync(CHAT_ATTACHMENTS_DIR, { recursive: true });

// فقط فرمت‌های تصویری امن و رایج مجاز است؛ پسوند فایل از روی mimetype واقعی
// ساخته می‌شود، نه از روی نام فایل ارسالی کاربر (که می‌تواند دستکاری‌شده باشد)
const ALLOWED_MIME_TO_EXT = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
};

function fileFilter(req, file, cb) {
  if (!ALLOWED_MIME_TO_EXT[file.mimetype]) {
    return cb(new Error("فرمت عکس مجاز نیست. فقط JPG، PNG یا WEBP مجاز است."));
  }
  cb(null, true);
}

// آیکون بخش (Department icon) — برخلاف سایر عکس‌ها (پروفایل/داکتر/لوگو/خبر)، SVG هم
// مجاز است چون آیکون‌های برداری معمولاً برای بخش‌های شفاخانه استفاده می‌شوند.
const ALLOWED_DEPARTMENT_ICON_MIME_TO_EXT = {
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "image/svg+xml": ".svg",
};

function departmentIconFileFilter(req, file, cb) {
  if (!ALLOWED_DEPARTMENT_ICON_MIME_TO_EXT[file.mimetype]) {
    return cb(new Error("فرمت آیکون مجاز نیست. فقط PNG، JPG، JPEG یا SVG مجاز است."));
  }
  cb(null, true);
}

// گزارش آزمایشگاهی می‌تواند عکس اسکن‌شده یا فایل PDF باشد
const ALLOWED_LAB_REPORT_MIME_TO_EXT = {
  ...ALLOWED_MIME_TO_EXT,
  "application/pdf": ".pdf",
};

function labReportFileFilter(req, file, cb) {
  if (!ALLOWED_LAB_REPORT_MIME_TO_EXT[file.mimetype]) {
    return cb(new Error("فرمت فایل مجاز نیست. فقط JPG، PNG، WEBP یا PDF مجاز است."));
  }
  cb(null, true);
}

// فرمت‌های مجاز برای ماژول «انتقال معلومات بیمار»: PDF، اکسل (xlsx/xls)، ورد (docx)، JPG/JPEG/PNG
const ALLOWED_FILE_TRANSFER_MIME_TO_EXT = {
  "application/pdf": ".pdf",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
  "application/vnd.ms-excel": ".xls",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
  "image/jpeg": ".jpg",
  "image/png": ".png",
};

function fileTransferFileFilter(req, file, cb) {
  if (!ALLOWED_FILE_TRANSFER_MIME_TO_EXT[file.mimetype]) {
    return cb(new Error("فرمت فایل مجاز نیست. فقط PDF، Excel (xlsx/xls)، Word (docx)، JPG یا PNG مجاز است."));
  }
  cb(null, true);
}

// فرمت‌های مجاز برای پیوست پیام‌های چت: عکس (JPG/PNG/WEBP) یا سند (PDF/DOC/DOCX/XLS/XLSX)
const ALLOWED_CHAT_ATTACHMENT_MIME_TO_EXT = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "application/pdf": ".pdf",
  "application/msword": ".doc",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
  "application/vnd.ms-excel": ".xls",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
};

function chatAttachmentFileFilter(req, file, cb) {
  if (!ALLOWED_CHAT_ATTACHMENT_MIME_TO_EXT[file.mimetype]) {
    return cb(new Error("فرمت فایل مجاز نیست. فقط عکس (JPG/PNG/WEBP) یا سند (PDF/DOC/DOCX/XLS/XLSX) مجاز است."));
  }
  cb(null, true);
}

// نام اصلیِ فایل ارسالیِ کاربر را قبل از ذخیره در دیتابیس پاک‌سازی می‌کند: هر بخش مسیر
// (برای جلوگیری از Path Traversal در نام نمایشی) حذف می‌شود، کاراکترهای کنترلی/خط‌جدید
// (که می‌توانند در هدر Content-Disposition دستکاری ایجاد کنند) پاک می‌شوند و طول آن
// محدود می‌شود. نام فیزیکی فایل روی دیسک هرگز از این مقدار ساخته نمی‌شود (همیشه تصادفی است).
export function sanitizeOriginalFilename(name) {
  const base = path.basename(String(name || "file")).replace(/[\r\n\u0000-\u001f]/g, "").trim();
  return base.slice(0, 255) || "file";
}

// سازنده‌ی عمومی آپلودکننده عکس — هم برای عکس پروفایل و هم عکس داکتر استفاده می‌شود
// تا تنظیمات (فرمت مجاز، حداکثر حجم، نام‌گذاری تصادفی) در یک‌جا تعریف شود
function createImageUploader(destDir) {
  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, destDir),
    filename: (req, file, cb) => {
      const ext = ALLOWED_MIME_TO_EXT[file.mimetype] || ".jpg";
      const randomName = crypto.randomBytes(24).toString("hex");
      cb(null, `${randomName}${ext}`);
    },
  });

  return multer({
    storage,
    fileFilter,
    limits: { fileSize: 2 * 1024 * 1024, files: 1 }, // حداکثر ۲ مگابایت
  });
}

export const uploadAvatar = createImageUploader(AVATARS_DIR);
export const uploadDoctorPhoto = createImageUploader(DOCTORS_DIR);
export const uploadLogo = createImageUploader(LOGO_DIR);
export const uploadSignature = createImageUploader(SIGNATURES_DIR);
export const uploadNewsImage = createImageUploader(NEWS_DIR);
export const uploadAboutImage = createImageUploader(ABOUT_DIR);
export const uploadHeroImage = createImageUploader(HERO_DIR);
// عکس کاور کارت بخش (JPG/PNG/WEBP، حداکثر ۲ مگابایت) — همان پوشه‌ی عمومی آیکون بخش‌ها
export const uploadDepartmentCover = createImageUploader(DEPARTMENTS_DIR);

// آپلودکننده‌ی آیکون بخش — همان الگوی createImageUploader (نام‌گذاری تصادفی، پوشه‌ی مقصد
// عمومی)، اما با فیلتر/پسوند مجاز جداگانه چون SVG هم پذیرفته می‌شود
const departmentIconStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, DEPARTMENTS_DIR),
  filename: (req, file, cb) => {
    const ext = ALLOWED_DEPARTMENT_ICON_MIME_TO_EXT[file.mimetype] || ".png";
    const randomName = crypto.randomBytes(24).toString("hex");
    cb(null, `${randomName}${ext}`);
  },
});
export const uploadDepartmentIcon = multer({
  storage: departmentIconStorage,
  fileFilter: departmentIconFileFilter,
  limits: { fileSize: 2 * 1024 * 1024, files: 1 }, // حداکثر ۲ مگابایت
});

// آپلودکننده‌ی گالری تصاویر خبر — چند عکس هم‌زمان (حداکثر ۸ عکس)، همان پوشه‌ی عمومی
// عکس شاخص خبر (backend/uploads/news)، همان فرمت‌های مجاز و نام‌گذاری تصادفی
const newsGalleryStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, NEWS_DIR),
  filename: (req, file, cb) => {
    const ext = ALLOWED_MIME_TO_EXT[file.mimetype] || ".jpg";
    const randomName = crypto.randomBytes(24).toString("hex");
    cb(null, `${randomName}${ext}`);
  },
});
export const uploadNewsGallery = multer({
  storage: newsGalleryStorage,
  fileFilter,
  limits: { fileSize: 2 * 1024 * 1024, files: 8 }, // حداکثر ۲ مگابایت هر عکس، حداکثر ۸ عکس هم‌زمان
});

// آپلودکننده‌ی گزارش آزمایشگاهی — همان الگوی نام‌گذاری تصادفی، اما پوشه‌ی خصوصی،
// فرمت‌های مجاز بیشتر (شامل PDF) و حداکثر حجم بزرگ‌تر (اسکن/PDF معمولاً حجیم‌تر است)
const labReportStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, LAB_REPORTS_DIR),
  filename: (req, file, cb) => {
    const ext = ALLOWED_LAB_REPORT_MIME_TO_EXT[file.mimetype] || ".pdf";
    const randomName = crypto.randomBytes(24).toString("hex");
    cb(null, `${randomName}${ext}`);
  },
});
export const uploadLabReport = multer({
  storage: labReportStorage,
  fileFilter: labReportFileFilter,
  limits: { fileSize: 10 * 1024 * 1024, files: 1 }, // حداکثر ۱۰ مگابایت
});

// فایل‌های پرونده صحی (تصویر پزشکی / سند): همان فرمت‌های مجاز و همان سقف حجم گزارش آزمایشگاه
// (JPG/PNG/WEBP/PDF، حداکثر ۱۰ مگابایت) تا محدودیت‌های فعلی بک‌اند بی‌دلیل تغییر نکند؛ اعتبارسنجی
// محتوای واقعی با همان verifyLabReportContent (magic number) انجام می‌شود.
const medicalFileStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, MEDICAL_FILES_DIR),
  filename: (req, file, cb) => {
    const ext = ALLOWED_LAB_REPORT_MIME_TO_EXT[file.mimetype] || ".pdf";
    cb(null, `${crypto.randomBytes(24).toString("hex")}${ext}`);
  },
});
export const uploadMedicalFile = multer({
  storage: medicalFileStorage,
  fileFilter: labReportFileFilter,
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
});

// آپلودکننده‌ی ماژول «انتقال معلومات بیمار» — چند فایل هم‌زمان (حداکثر ۵ فایل)،
// پوشه‌ی خصوصی، نام‌گذاری تصادفی (نام اصلی فایل جداگانه در دیتابیس نگه‌داری می‌شود)
const fileTransferStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, FILE_TRANSFERS_DIR),
  filename: (req, file, cb) => {
    const ext = ALLOWED_FILE_TRANSFER_MIME_TO_EXT[file.mimetype] || ".bin";
    const randomName = crypto.randomBytes(24).toString("hex");
    cb(null, `${randomName}${ext}`);
  },
});
export const uploadFileTransfer = multer({
  storage: fileTransferStorage,
  fileFilter: fileTransferFileFilter,
  limits: { fileSize: 15 * 1024 * 1024, files: 5 }, // حداکثر ۱۵ مگابایت برای هر فایل، حداکثر ۵ فایل هم‌زمان
});

// آپلودکننده‌ی پیوست پیام چت — یک فایل به‌ازای هر پیام (عکس یا سند)، پوشه‌ی خصوصی،
// نام‌گذاری تصادفی (نام اصلی فایل جداگانه و پاک‌سازی‌شده در دیتابیس نگه‌داری می‌شود)
const chatAttachmentStorage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, CHAT_ATTACHMENTS_DIR),
  filename: (req, file, cb) => {
    const ext = ALLOWED_CHAT_ATTACHMENT_MIME_TO_EXT[file.mimetype] || ".bin";
    const randomName = crypto.randomBytes(24).toString("hex");
    cb(null, `${randomName}${ext}`);
  },
});
export const uploadChatAttachment = multer({
  storage: chatAttachmentStorage,
  fileFilter: chatAttachmentFileFilter,
  limits: { fileSize: 15 * 1024 * 1024, files: 1 }, // حداکثر ۱۵ مگابایت، یک فایل برای هر پیام
});

// فرمت‌های مجاز برای پیام صوتی — فرمت خروجیِ MediaRecorder مرورگر بسته به مرورگر/دستگاه
// فرق می‌کند (کروم/فایرفاکس معمولاً webm، سافاری معمولاً mp4/m4a)؛ mp3/wav/ogg هم برای
// سازگاری بیشتر (مثلاً آپلود جایگزین) پذیرفته می‌شوند.
const ALLOWED_VOICE_MIME_TO_EXT = {
  "audio/webm": ".webm",
  "audio/ogg": ".ogg",
  "audio/mp4": ".m4a",
  "audio/x-m4a": ".m4a",
  "audio/mpeg": ".mp3",
  "audio/wav": ".wav",
  "audio/x-wav": ".wav",
};

function chatVoiceFileFilter(req, file, cb) {
  if (!ALLOWED_VOICE_MIME_TO_EXT[file.mimetype]) {
    return cb(new Error("فرمت پیام صوتی مجاز نیست"));
  }
  cb(null, true);
}

// آپلودکننده‌ی پیام صوتی چت — یک فایل به‌ازای هر پیام، همان پوشه‌ی خصوصیِ پیوست‌های چت
// (چون پیام صوتی هم مثل عکس/سند پیوست‌شده، محتوای خصوصیِ همان مکالمه است)، نام‌گذاری
// تصادفی، حداکثر ۸ مگابایت (پیام صوتی فشرده‌شده با کدک opus معمولاً حدود ۱ مگابایت به
// ازای هر دقیقه است؛ سقف مدت‌زمان هم جداگانه در sendVoiceMessageValidation/کنترلر بررسی می‌شود)
export const uploadChatVoice = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, CHAT_ATTACHMENTS_DIR),
    filename: (req, file, cb) => {
      const ext = ALLOWED_VOICE_MIME_TO_EXT[file.mimetype] || ".webm";
      const randomName = crypto.randomBytes(24).toString("hex");
      cb(null, `${randomName}${ext}`);
    },
  }),
  fileFilter: chatVoiceFileFilter,
  limits: { fileSize: 8 * 1024 * 1024, files: 1 }, // حداکثر ۸ مگابایت
});

// ---------- اعتبارسنجی محتوای واقعی فایل (Magic Number) ----------
// هدر Content-Type ارسالی از سمت کاربر به‌راحتی قابل جعل است (مثلاً یک فایل اجرایی/اسکریپت
// مخرب با mimetype جعلی "image/png"). برای جلوگیری از آپلود فایل‌های مخرب، بایت‌های ابتدایی
// فایل ذخیره‌شده روی دیسک با امضای باینری (magic number) فرمت‌های تصویری مجاز مقایسه می‌شود.
const MAGIC_SIGNATURES = {
  ".jpg": [[0xff, 0xd8, 0xff]],
  ".png": [[0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]],
  ".webp": [[0x52, 0x49, 0x46, 0x46]], // "RIFF" — عبارت "WEBP" در بایت‌های ۸ تا ۱۱ جداگانه بررسی می‌شود
  ".pdf": [[0x25, 0x50, 0x44, 0x46]], // "%PDF"
  // فرمت‌های Office مدرن (xlsx/docx) در واقع یک فایل ZIP هستند — امضای "PK"
  ".xlsx": [[0x50, 0x4b, 0x03, 0x04]],
  ".docx": [[0x50, 0x4b, 0x03, 0x04]],
  // فرمت قدیمی اکسل (xls) — امضای OLE Compound File Binary
  ".xls": [[0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]],
  // فرمت قدیمی ورد (doc) هم از همان قالب باینری OLE استفاده می‌کند — امضای یکسان با xls
  ".doc": [[0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1]],
};

function isValidImageSignature(filePath, ext) {
  const signatures = MAGIC_SIGNATURES[ext];
  if (!signatures) return false;

  const fd = fs.openSync(filePath, "r");
  const buffer = Buffer.alloc(16);
  fs.readSync(fd, buffer, 0, 16, 0);
  fs.closeSync(fd);

  const matches = signatures.some((sig) => sig.every((byte, idx) => buffer[idx] === byte));
  if (!matches) return false;

  if (ext === ".webp") {
    return buffer.toString("ascii", 8, 12) === "WEBP";
  }
  return true;
}

// بعد از تاییدِ محتوای عکس، خودِ عکس در دیتابیس هم ذخیره می‌شود (فقط برای پوشه‌های عمومی
// uploads — برای امضا و سایر فایل‌های خصوصی بی‌اثر است) تا با جایگزین شدن پوشه‌ی پروژه از
// بین نرود. اگر ذخیره در دیتابیس ناموفق باشد، فایل پاک و درخواست رد می‌شود تا ادمین مطمئن
// باشد هر عکسی که «موفق» آپلود شده واقعاً ماندگار است.
async function persistOrReject(files, res, next) {
  try {
    for (const file of files) await persistUploadedFile(file.path);
    return next();
  } catch (err) {
    console.error("ذخیره‌ی عکس در دیتابیس ناموفق بود:", err);
    files.forEach((file) => fs.unlink(file.path, () => {}));
    return res.status(500).json({ message: "ذخیره‌ی عکس در دیتابیس ناموفق بود؛ دوباره تلاش کنید" });
  }
}

// این میان‌افزار بعد از multer اجرا می‌شود. اگر محتوای واقعی فایل با هیچ‌کدام از
// امضاهای مجاز مطابقت نداشته باشد (یعنی فایل واقعاً عکس نیست)، بلافاصله از دیسک
// حذف شده و درخواست با خطا رد می‌شود.
export function verifyImageContent(req, res, next) {
  if (!req.file) return next();

  const ext = path.extname(req.file.filename).toLowerCase();
  const valid = isValidImageSignature(req.file.path, ext);

  if (!valid) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ message: "محتوای فایل ارسالی یک عکس معتبر نیست" });
  }

  return persistOrReject([req.file], res, next);
}

// این میان‌افزار بعد از multer اجرا می‌شود و برای آیکون بخش استفاده می‌شود. PNG/JPG با همان
// بررسی امضای باینری بالا تایید می‌شوند؛ SVG که یک فایل متنی است (نه باینری خالص) جداگانه
// بررسی می‌شود: هم این‌که واقعاً یک SVG معتبر است، و هم محتوایش (اسکریپت/event handler و ...)
// با sanitizeSvgContent پاک‌سازی و روی همان فایل بازنویسی می‌شود تا XSS ذخیره‌شده رخ ندهد.
export function verifyDepartmentIconContent(req, res, next) {
  if (!req.file) return next();

  const ext = path.extname(req.file.filename).toLowerCase();

  if (ext === ".svg") {
    let raw;
    try {
      raw = fs.readFileSync(req.file.path, "utf8");
    } catch (err) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ message: "محتوای فایل SVG ارسالی قابل خواندن نیست" });
    }

    if (!looksLikeSvg(raw)) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ message: "محتوای فایل ارسالی یک SVG معتبر نیست" });
    }

    const sanitized = sanitizeSvgContent(raw);
    if (!sanitized) {
      fs.unlink(req.file.path, () => {});
      return res.status(400).json({ message: "محتوای فایل ارسالی یک SVG معتبر نیست" });
    }

    fs.writeFileSync(req.file.path, sanitized, "utf8");
    return persistOrReject([req.file], res, next);
  }

  const valid = isValidImageSignature(req.file.path, ext);
  if (!valid) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ message: "محتوای فایل ارسالی یک عکس معتبر نیست" });
  }

  return persistOrReject([req.file], res, next);
}

// همان بررسی امضای باینری، اما برای گزارش آزمایشگاهی (عکس یا PDF) — پیام خطای متفاوت
export function verifyLabReportContent(req, res, next) {
  if (!req.file) return next();

  const ext = path.extname(req.file.filename).toLowerCase();
  const valid = isValidImageSignature(req.file.path, ext);

  if (!valid) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ message: "محتوای فایل ارسالی یک عکس یا PDF معتبر نیست" });
  }

  next();
}

// همان بررسی امضای باینری، اما برای چند عکس هم‌زمان (گالری تصاویر خبر) — اگر حتی یکی از
// عکس‌ها محتوای واقعی‌اش با فرمت ادعاشده مطابقت نداشته باشد، همه‌ی فایل‌های همان درخواست
// از دیسک حذف می‌شوند تا فایل یتیم روی سرور باقی نماند (همان الگوی verifyFileTransferContent).
export function verifyNewsGalleryContent(req, res, next) {
  const files = req.files || [];
  if (files.length === 0) return next();

  const allValid = files.every((file) => {
    const ext = path.extname(file.filename).toLowerCase();
    return isValidImageSignature(file.path, ext);
  });

  if (!allValid) {
    files.forEach((file) => fs.unlink(file.path, () => {}));
    return res.status(400).json({ message: "محتوای یک یا چند عکس ارسالی معتبر نیست" });
  }

  return persistOrReject(files, res, next);
}
// اگر حتی یکی از فایل‌ها محتوای واقعی‌اش با فرمت ادعاشده مطابقت نداشته باشد (مثلاً یک
// فایل اجرایی/اسکریپت مخرب با mimetype جعلی)، همه‌ی فایل‌های همان درخواست از دیسک حذف
// شده و درخواست با خطا رد می‌شود — نه فقط یکی از فایل‌ها، تا فایل یتیم باقی نماند.
export function verifyFileTransferContent(req, res, next) {
  const files = req.files || [];
  if (files.length === 0) return next();

  const allValid = files.every((file) => {
    const ext = path.extname(file.filename).toLowerCase();
    return isValidImageSignature(file.path, ext);
  });

  if (!allValid) {
    files.forEach((file) => fs.unlink(file.path, () => {}));
    return res.status(400).json({ message: "محتوای یک یا چند فایل ارسالی با فرمت اعلام‌شده مطابقت ندارد" });
  }

  next();
}

// همان بررسی امضای باینری، اما برای پیوست پیام‌های چت (عکس یا سند) — یک فایل به‌ازای هر
// پیام. اگر محتوای واقعی فایل با فرمت ادعاشده (mimetype) مطابقت نداشته باشد (مثلاً یک
// فایل اجرایی/اسکریپت مخرب با پسوند/mimetype جعلی)، فوراً از دیسک حذف شده و رد می‌شود.
export function verifyChatAttachmentContent(req, res, next) {
  if (!req.file) return next();

  const ext = path.extname(req.file.filename).toLowerCase();
  const valid = isValidImageSignature(req.file.path, ext);

  if (!valid) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ message: "محتوای فایل ارسالی با فرمت اعلام‌شده مطابقت ندارد" });
  }

  next();
}

// بررسی امضای باینری فایل صوتی — برخلاف عکس/سند، محفظه‌ی webm/ogg/mp4/wav هر کدام
// قالب/آفست متفاوتی دارند، پس نمی‌توان از isValidImageSignature (که فرض می‌کند امضا
// همیشه از بایت صفر شروع می‌شود) به‌صورت یک‌دست استفاده کرد.
function isValidVoiceSignature(filePath, ext) {
  const fd = fs.openSync(filePath, "r");
  const buffer = Buffer.alloc(16);
  fs.readSync(fd, buffer, 0, 16, 0);
  fs.closeSync(fd);

  if (ext === ".webm") {
    // محفظه‌ی EBML/Matroska (webm) — امضا از بایت صفر
    return [0x1a, 0x45, 0xdf, 0xa3].every((b, i) => buffer[i] === b);
  }
  if (ext === ".ogg") {
    return buffer.toString("ascii", 0, 4) === "OggS";
  }
  if (ext === ".m4a") {
    // محفظه‌ی MP4/M4A — نوع باکس ("ftyp") در بایت‌های ۴ تا ۷ قرار دارد، نه ابتدای فایل
    return buffer.toString("ascii", 4, 8) === "ftyp";
  }
  if (ext === ".wav") {
    return buffer.toString("ascii", 0, 4) === "RIFF" && buffer.toString("ascii", 8, 12) === "WAVE";
  }
  if (ext === ".mp3") {
    // فایل mp3 یا با تگ ID3 شروع می‌شود، یا مستقیماً با فریم صوتی MPEG (بایت همگام‌سازی 0xFF)
    if (buffer.toString("ascii", 0, 3) === "ID3") return true;
    return buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0;
  }
  return false;
}

// این میان‌افزار بعد از multer (uploadChatVoice) اجرا می‌شود. اگر محتوای واقعی فایلِ
// ذخیره‌شده با هیچ‌کدام از امضاهای صوتیِ مجاز مطابقت نداشته باشد (یعنی یک فایل غیرصوتی
// با mimetype جعلی ارسال شده)، بلافاصله از دیسک حذف شده و درخواست رد می‌شود.
export function verifyChatVoiceContent(req, res, next) {
  if (!req.file) return next();

  const ext = path.extname(req.file.filename).toLowerCase();
  const valid = isValidVoiceSignature(req.file.path, ext);

  if (!valid) {
    fs.unlink(req.file.path, () => {});
    return res.status(400).json({ message: "محتوای فایل ارسالی یک پیام صوتی معتبر نیست" });
  }

  next();
}

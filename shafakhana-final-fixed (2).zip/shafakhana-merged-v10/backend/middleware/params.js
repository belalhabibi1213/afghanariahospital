// اعتبارسنجی پارامترهای مسیر: شناسه‌ها باید عدد صحیح مثبت باشند.
// هم با router.param("id", numericParam) و هم به‌صورت میان‌افزار (requireNumericParams("id")) قابل استفاده است.
const POSITIVE_INT = /^[1-9]\d{0,9}$/;

export function numericParam(req, res, next, value) {
  if (!POSITIVE_INT.test(String(value))) {
    return res.status(400).json({ message: "شناسه نامعتبر است" });
  }
  return next();
}

export function requireNumericParams(...names) {
  return (req, res, next) => {
    for (const name of names) {
      if (!POSITIVE_INT.test(String(req.params[name]))) {
        return res.status(400).json({ message: "شناسه نامعتبر است" });
      }
    }
    return next();
  };
}

import rateLimit, { ipKeyGenerator } from "express-rate-limit";
import { IS_PRODUCTION } from "../utils/env.js";

// پیام یکنواخت هنگام عبور از سقف مجاز درخواست‌ها — بدون افشای جزئیات داخلی سرور
const tooManyRequestsHandler = (req, res) => {
  res.status(429).json({ message: "تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً کمی بعد دوباره تلاش کنید." });
};

// محدودیت عمومی روی کل API — جلوگیری از سوءاستفاده/DoS ابتدایی، بدون مزاحمت برای استفاده عادی.
// مسیرهای ماژول «انتقال معلومات بیمار» (routes/doctors.js) از این محدودیت مشترک بر اساس IP
// معاف شده‌اند: چون چند داکتر/کارمند معمولاً پشت یک IP مشترک (شبکه‌ی داخلی شفاخانه) هستند و
// هر انتقال شامل چند درخواست (آپلود + بازخوانی تاریخچه + دانلود) است، این سقف مشترک باعث
// می‌شد داکترها به‌اشتباه با خطای «تعداد درخواست‌های شما بیش از حد مجاز است» مواجه شوند، در
// حالی که این مسیرها از قبل با requireAuth + authorize("doctor") محافظت می‌شوند و محدودیت
// اختصاصی و سخاوتمندانه‌ی خودشان را دارند (fileTransferLimiter در پایین همین فایل).
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // ۱۵ دقیقه
  max: 300, // حداکثر ۳۰۰ درخواست به ازای هر IP در بازه‌ی بالا
  standardHeaders: true,
  legacyHeaders: false,
  skip: (req) => req.path.startsWith("/doctors/me/file-transfers"),
  handler: tooManyRequestsHandler,
});

// محدودیت سخت‌گیرانه‌تر روی مسیرهای حساس احراز هویت (ورود، ثبت‌نام، فراموشی رمز عبور و ...)
// برای جلوگیری از حملات brute-force روی رمز عبور یا کد تایید ایمیل
// نکته: در محیط توسعه (NODE_ENV غیر از production) این محدودیت کاملاً غیرفعال است
// (skip همیشه true برمی‌گرداند) تا هنگام تست دستی و جابه‌جایی مکرر بین چند اکانت
// هرگز با خطای «تعداد درخواست‌های شما بیش از حد مجاز است» مواجه نشوید. در پروداکشن
// (IS_PRODUCTION === true) همان سقف سخت‌گیرانه‌ی ۲۰ تلاش در ۱۵ دقیقه برای جلوگیری از
// brute-force فعال باقی می‌ماند.
export const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // ۱۵ دقیقه
  max: 20, // حداکثر ۲۰ تلاش به ازای هر IP در بازه‌ی بالا (فقط در پروداکشن اعمال می‌شود)
  standardHeaders: true,
  legacyHeaders: false,
  skipSuccessfulRequests: false,
  skip: () => !IS_PRODUCTION,
  handler: tooManyRequestsHandler,
});

// محدودیت ارسال نظر روی اخبار — جلوگیری از اسپم کامنت (علاوه بر الزام ورود به حساب
// کاربری و تایید ادمین قبل از نمایش عمومی که در سطوح دیگر اعمال می‌شود)
export const commentLimiter = rateLimit({
  windowMs: 10 * 60 * 1000, // ۱۰ دقیقه
  max: 8, // حداکثر ۸ نظر به ازای هر IP در بازه‌ی بالا
  standardHeaders: true,
  legacyHeaders: false,
  handler: tooManyRequestsHandler,
});

// محدودیت اختصاصی ماژول «انتقال معلومات بیمار» (پنل داکتر) — به‌جای شمارش بر اساس IP
// (که چند داکتر پشت یک IP مشترک را با هم به سقف می‌رساند)، بر اساس شناسه‌ی کاربر واردشده
// شمارش می‌شود، تا سهمیه‌ی هر داکتر کاملاً مستقل از داکترهای دیگر باشد. سقف به‌اندازه‌ای
// سخاوتمندانه است که استفاده‌ی عادی (ارسال چندین انتقال/فایل در روز) هرگز به آن برخورد
// نکند، و در عین حال از سوءاستفاده‌ی خودکار/اسکریپتی جلوگیری می‌کند.
export const fileTransferLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // ۱۵ دقیقه
  max: 100, // حداکثر ۱۰۰ درخواست به ازای هر داکتر واردشده در بازه‌ی بالا
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => (req.user ? `user:${req.user.id}` : ipKeyGenerator(req.ip)),
  handler: tooManyRequestsHandler,
});

// فرم «تماس با ما» عمومی است (بدون ورود) و مستقیم در صندوق ادمین ذخیره می‌شود → هدف اسپم.
// سقف سخت‌گیرانه برای هر IP: ۵ پیام در ساعت. (در تست/توسعه با CONTACT_LIMIT_DISABLED=true خاموش می‌شود.)
export const contactLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  max: Number(process.env.CONTACT_LIMIT_MAX) || 5,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => (process.env.CONTACT_LIMIT_DISABLED || "").toLowerCase() === "true" || !IS_PRODUCTION,
  handler: tooManyRequestsHandler,
});

// جستجوی عمومی هر درخواست چند کوئری LIKE/فازی اجرا می‌کند؛ سقف جدا از محدودیت عمومی API
// (۶۰ جستجو در دقیقه به ازای هر IP) تا برای فشار روی دیتابیس استفاده نشود.
export const searchLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  skip: () => !IS_PRODUCTION,
  handler: tooManyRequestsHandler,
});

// دستیار هوش مصنوعی: سقف کوتاه‌مدت به ازای هر کاربر (علاوه بر سقف روزانه در aiController)
// تا سهمیه‌ی رایگان سرویس بیرونی با ارسال پشت‌سرهم تمام نشود.
export const aiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 6,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req, res) => (req.user?.id ? `u:${req.user.id}` : ipKeyGenerator(req.ip)),
  handler: tooManyRequestsHandler,
});

import jwt from "jsonwebtoken";
import { JWT_SECRET, isMfaRequiredForRole } from "../utils/env.js";
import { findByIdRawCached } from "../models/User.js";
import { findSessionByTokenIdCached, touchSession } from "../models/Session.js";
import { getTokenFromRequest } from "../utils/authCookies.js";

// این نوبت‌دهی را هم برای کاربر واردشده و هم برای مهمان (guest) قابل استفاده می‌کند
export function optionalAuth(req, res, next) {
  const { token } = getTokenFromRequest(req); // هدر Authorization یا کوکی httpOnly
  if (token) {
    try {
      req.user = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] });
    } catch (err) {
      // توکن نامعتبر بود؛ کاربر را مهمان در نظر می‌گیریم
    }
  }
  next();
}

// کاربری که رمز موقت دارد (mustChangePassword) تا تعیین رمز جدید فقط به این مسیرها دسترسی دارد.
// قبلاً این الزام فقط در رابط کاربری (React) اعمال می‌شد و با فراخوانی مستقیم API دور زده می‌شد.
const PASSWORD_CHANGE_ALLOWED = new Set([
  "PUT /api/users/change-password",
  "GET /api/auth/me",
]);

function isAllowedWhilePasswordChangePending(req) {
  const urlPath = (req.originalUrl || "").split("?")[0].replace(/\/+$/, "");
  return PASSWORD_CHANGE_ALLOWED.has(`${req.method} ${urlPath}`);
}

// نقش‌هایی که MFA برایشان اجباری است (MFA_REQUIRED_ROLES) تا فعال‌سازی MFA فقط به این مسیرها دسترسی دارند.
const MFA_SETUP_ALLOWED = new Set([
  "GET /api/auth/me",
  "GET /api/auth/mfa/status",
  "POST /api/auth/mfa/setup",
  "POST /api/auth/mfa/enable",
]);

function isAllowedWhileMfaSetupPending(req) {
  const urlPath = (req.originalUrl || "").split("?")[0].replace(/\/+$/, "");
  return MFA_SETUP_ALLOWED.has(`${req.method} ${urlPath}`);
}

// این مسیرها فقط برای کاربر واردشده باز است
export async function requireAuth(req, res, next) {
  const { token } = getTokenFromRequest(req); // هدر Authorization یا کوکی httpOnly
  if (!token) {
    return res.status(401).json({ message: "برای این عملیات باید وارد حساب کاربری شوید" });
  }
  try {
    const payload = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] }); // الگوریتم ثابت: جلوگیری از حمله‌ی تعویض الگوریتم
    // حتی اگر توکن معتبر باشد، اگر حساب کاربر در همین فاصله توسط ادمین غیرفعال شده
    // باشد، دسترسی فوراً قطع می‌شود (نه فقط در زمان ورود)
    const dbUser = await findByIdRawCached(payload.id);
    if (!dbUser || !dbUser.isActive) {
      return res.status(403).json({ message: "حساب کاربری شما غیرفعال شده است. با مدیر سیستم تماس بگیرید.", code: "ACCOUNT_DISABLED" });
    }

    // بررسی نشست («نشست‌ها و دستگاه‌های فعال» پنل Super Admin): اگر Super Admin این
    // نشست را از قبل خاتمه داده باشد، دسترسی فوراً قطع می‌شود — حتی با یک JWT هنوز معتبر.
    // توکن‌های قدیمی‌تر (بدون jti، پیش از افزودن این قابلیت) رفتار قبلی‌شان حفظ می‌شود.
    if (payload.jti) {
      const session = await findSessionByTokenIdCached(payload.jti);
      if (session && session.revokedAt) {
        return res.status(401).json({ message: "این نشست توسط مدیر کل خاتمه یافته است، دوباره وارد شوید", code: "SESSION_TERMINATED" });
      }
      if (session) {
        touchSession(payload.jti).catch(() => {}); // فقط برای نمایش «آخرین فعالیت»؛ نباید درخواست اصلی را کند یا مسدود کند
      }
    }

    if (dbUser.mustChangePassword && !isAllowedWhilePasswordChangePending(req)) {
      return res.status(403).json({
        message: "برای ادامه باید ابتدا رمز عبور موقت خود را تغییر دهید",
        code: "PASSWORD_CHANGE_REQUIRED",
      });
    }

    if (isMfaRequiredForRole(dbUser.role) && !dbUser.mfaEnabled && !isAllowedWhileMfaSetupPending(req)) {
      return res.status(403).json({
        message: "برای ادامه باید ابتدا احراز هویت دومرحله‌ای (MFA) را فعال کنید",
        code: "MFA_SETUP_REQUIRED",
      });
    }

    // نقش از دیتابیس خوانده می‌شود، نه از توکن: اگر ادمین/سوپرادمین نقش کاربری را عوض کند (مثلاً داکتری را
    // به «بیمار» برگرداند)، توکن قدیمی تا ۷ روز با نقش سابق معتبر نمی‌ماند و دسترسی فوراً تغییر می‌کند.
    req.user = { ...payload, role: dbUser.role };
    next();
  } catch (err) {
    return res.status(401).json({ message: "نشست شما منقضی شده، دوباره وارد شوید", code: "SESSION_EXPIRED" });
  }
}

// نقش‌های مجاز به عنوان آرگومان داده می‌شود، مثال: authorize("admin", "superadmin")
// باید بعد از requireAuth استفاده شود چون به req.user.role نیاز دارد
export function authorize(...allowedRoles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ message: "برای این عملیات باید وارد حساب کاربری شوید" });
    }
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({
        message: "شما اجازه دسترسی به این بخش را ندارید",
        code: "ACCESS_DENIED",
      });
    }
    next();
  };
}

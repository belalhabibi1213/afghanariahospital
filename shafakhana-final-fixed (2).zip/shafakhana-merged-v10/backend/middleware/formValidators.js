import { body, query } from "express-validator";
import { handleValidation } from "./authValidators.js";
import { WEEKDAY_NAMES } from "../models/Schedule.js";
import { PAYMENT_METHODS } from "../models/Payment.js";
import { getDoctorByCode } from "../models/Doctor.js";
import { isValidPersianName, PERSIAN_NAME_ERROR_MESSAGE } from "../utils/persianName.js";
import { ICON_TYPES, DEPARTMENT_STATUSES } from "../models/Department.js";

// فرمت ساعت HH:MM (۲۴ساعته) — همان فرمتی که ستون‌های TIME در دیتابیس و
// فورمه‌های برنامه کاری استفاده می‌کنند
const TIME_REGEX = /^([01]\d|2[0-3]):[0-5]\d$/;

function isBefore(a, b) {
  return a < b; // مقایسه‌ی رشته‌ای HH:MM به‌درستی کار می‌کند
}

// اعتبارسنجی مشترک ثبت/ویرایش برنامه کاری داکتر (روز، ساعت شروع/پایان، زمان استراحت)
// هم توسط ادمین (POST/PUT /api/admin/schedules) و هم خودِ داکتر
// (POST/PUT /api/doctors/me/schedules) استفاده می‌شود
export const scheduleValidation = [
  body("dayOfWeek")
    .trim()
    .notEmpty()
    .withMessage("روز هفته الزامی است")
    .isIn(WEEKDAY_NAMES)
    .withMessage("روز هفته نامعتبر است"),
  body("startTime")
    .trim()
    .notEmpty()
    .withMessage("ساعت شروع الزامی است")
    .matches(TIME_REGEX)
    .withMessage("فرمت ساعت شروع نامعتبر است (مثال: 08:00)"),
  body("endTime")
    .trim()
    .notEmpty()
    .withMessage("ساعت پایان الزامی است")
    .matches(TIME_REGEX)
    .withMessage("فرمت ساعت پایان نامعتبر است (مثال: 16:00)"),
  body("breakStart")
    .optional({ checkFalsy: true })
    .trim()
    .matches(TIME_REGEX)
    .withMessage("فرمت زمان شروع استراحت نامعتبر است (مثال: 12:00)"),
  body("breakEnd")
    .optional({ checkFalsy: true })
    .trim()
    .matches(TIME_REGEX)
    .withMessage("فرمت زمان پایان استراحت نامعتبر است (مثال: 13:00)"),
  // بررسی منطقی بین فیلدها: پایان بعد از شروع، و زمان استراحت داخل بازه‌ی کاری
  body("endTime").custom((endTime, { req }) => {
    if (req.body.startTime && TIME_REGEX.test(req.body.startTime) && TIME_REGEX.test(endTime)) {
      if (!isBefore(req.body.startTime, endTime)) {
        throw new Error("ساعت پایان باید بعد از ساعت شروع باشد");
      }
    }
    return true;
  }),
  body("breakEnd").custom((breakEnd, { req }) => {
    const { startTime, endTime, breakStart } = req.body;
    if (!breakStart && !breakEnd) return true; // زمان استراحت اختیاری است
    if (!breakStart || !breakEnd) {
      throw new Error("برای تعریف زمان استراحت، هر دو ساعت شروع و پایان آن الزامی است");
    }
    if (!TIME_REGEX.test(breakStart) || !TIME_REGEX.test(breakEnd)) return true; // خطای فرمت قبلاً گزارش شده
    if (!isBefore(breakStart, breakEnd)) {
      throw new Error("ساعت پایان استراحت باید بعد از ساعت شروع آن باشد");
    }
    if (startTime && TIME_REGEX.test(startTime) && isBefore(breakStart, startTime)) {
      throw new Error("زمان استراحت باید داخل بازه‌ی کاری باشد");
    }
    if (endTime && TIME_REGEX.test(endTime) && isBefore(endTime, breakEnd)) {
      throw new Error("زمان استراحت باید داخل بازه‌ی کاری باشد");
    }
    return true;
  }),
  handleValidation,
];

// شناسه داکتر فقط می‌تواند شامل حروف انگلیسی، عدد و خط تیره باشد (مثال: DR-1001)
const DOCTOR_CODE_REGEX = /^[A-Za-z0-9-]{2,20}$/;

// روزهای کاری در فرانت‌اند به‌صورت رشته‌ای جدا‌شده با "،" یا "," ارسال می‌شود
// (مثال: "شنبه، یکشنبه، سه‌شنبه")؛ این تابع آن را به آرایه تبدیل می‌کند
function parseWorkDaysList(value) {
  if (!value) return [];
  return String(value)
    .split(/[,،]/)
    .map((d) => d.trim())
    .filter(Boolean);
}

// اعتبارسنجی مشترک افزودن/ویرایش داکتر (POST/PUT /api/admin/doctors[/:id])
// شامل: نام، بخش، شناسه یکتای داکتر (doctorCode)، سابقه کاری، جنسیت، امتیاز (۱ تا ۵)
// و روزهای کاری (فقط روزهای معتبر هفته)
export const doctorValidation = [
  body("fullName")
    .trim()
    .notEmpty()
    .withMessage("نام داکتر الزامی است")
    .isLength({ max: 150 })
    .withMessage("نام داکتر نباید بیشتر از ۱۵۰ کاراکتر باشد"),
  body("department")
    .trim()
    .notEmpty()
    .withMessage("بخش داکتر الزامی است")
    .isLength({ max: 100 })
    .withMessage("نام بخش نباید بیشتر از ۱۰۰ کاراکتر باشد"),
  body("doctorCode")
    // در «افزودن» (POST) شناسه اختیاری است؛ اگر خالی باشد سرور خودش شناسه‌ی بعدی (DR-1010 ...) را می‌سازد
    .if((value, { req }) => req.method !== "POST" || String(value || "").trim() !== "")
    .trim()
    .notEmpty()
    .withMessage("شناسه داکتر الزامی است")
    .isLength({ max: 20 })
    .withMessage("شناسه داکتر نباید بیشتر از ۲۰ کاراکتر باشد")
    .matches(DOCTOR_CODE_REGEX)
    .withMessage("شناسه داکتر فقط می‌تواند شامل حروف انگلیسی، عدد و خط تیره باشد")
    .custom(async (value, { req }) => {
      const existing = await getDoctorByCode(value);
      // در حالت ویرایش، برخورد با شناسه‌ی خودِ همین داکتر مجاز است
      if (existing && String(existing.id) !== String(req.params.id || "")) {
        throw new Error("این شناسه داکتر قبلاً برای داکتر دیگری استفاده شده است");
      }
      return true;
    }),
  body("yearsExperience")
    .optional({ checkFalsy: true })
    .isInt({ min: 0, max: 80 })
    .withMessage("سابقه کاری باید عددی بین ۰ تا ۸۰ باشد"),
  body("gender")
    .optional({ checkFalsy: true })
    .isIn(["men", "women"])
    .withMessage("جنسیت نامعتبر است"),
  body("rating")
    .optional({ checkFalsy: true })
    .isInt({ min: 1, max: 5 })
    .withMessage("امتیاز باید عددی بین ۱ تا ۵ باشد"),
  body("workDays").custom((value) => {
    const days = parseWorkDaysList(value);
    const invalid = days.filter((d) => !WEEKDAY_NAMES.includes(d));
    if (invalid.length > 0) {
      throw new Error("روزهای کاری فقط می‌تواند شامل روزهای معتبر هفته باشد");
    }
    return true;
  }),
  handleValidation,
];

// اعتبارسنجی مشترک افزودن/ویرایش خبر توسط ادمین (POST/PUT /api/admin/news[/:id])
export const newsValidation = [
  body("title")
    .trim()
    .notEmpty()
    .withMessage("عنوان خبر الزامی است")
    .isLength({ max: 255 })
    .withMessage("عنوان خبر نباید بیشتر از ۲۵۵ کاراکتر باشد"),
  body("excerpt")
    .trim()
    .notEmpty()
    .withMessage("توضیح کوتاه الزامی است")
    .isLength({ max: 500 })
    .withMessage("توضیح کوتاه نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("content").optional({ checkFalsy: true }).trim().isLength({ max: 20000 }).withMessage("متن کامل خبر بسیار طولانی است"),
  body("titleEn").optional({ checkFalsy: true }).trim().isLength({ max: 255 }).withMessage("عنوان انگلیسی نباید بیشتر از ۲۵۵ کاراکتر باشد"),
  body("excerptEn").optional({ checkFalsy: true }).trim().isLength({ max: 500 }).withMessage("خلاصه‌ی انگلیسی نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("contentEn").optional({ checkFalsy: true }).trim().isLength({ max: 20000 }).withMessage("متن کامل انگلیسی بسیار طولانی است"),
  body("tag")
    .trim()
    .notEmpty()
    .withMessage("دسته‌بندی خبر الزامی است")
    .isLength({ max: 100 })
    .withMessage("دسته‌بندی نباید بیشتر از ۱۰۰ کاراکتر باشد"),
  body("tags").optional({ checkFalsy: true }).isLength({ max: 500 }).withMessage("برچسب‌ها بسیار طولانی است"),
  body("author").optional({ checkFalsy: true }).trim().isLength({ max: 150 }).withMessage("نام نویسنده نباید بیشتر از ۱۵۰ کاراکتر باشد"),
  body("status").optional({ checkFalsy: true }).isIn(["draft", "published", "scheduled"]).withMessage("وضعیت خبر نامعتبر است"),
  body("scheduledAt")
    .optional({ checkFalsy: true })
    .isISO8601()
    .withMessage("تاریخ/ساعت زمان‌بندی نامعتبر است"),
  body("isPinned").optional().isBoolean().withMessage("مقدار سنجاق‌کردن نامعتبر است"),
  body("metaTitle")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 255 })
    .withMessage("عنوان سئو نباید بیشتر از ۲۵۵ کاراکتر باشد"),
  body("metaDescription")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 300 })
    .withMessage("توضیح سئو نباید بیشتر از ۳۰۰ کاراکتر باشد"),
  handleValidation,
];

// اعتبارسنجی تغییر وضعیت خبر (PUT /api/admin/news/:id/status)
export const newsStatusValidation = [
  body("status").trim().notEmpty().withMessage("وضعیت الزامی است").isIn(["draft", "published"]).withMessage("وضعیت خبر نامعتبر است"),
  handleValidation,
];

// اعتبارسنجی سنجاق‌کردن/برداشتن سنجاق خبر (PUT /api/admin/news/:id/pin)
export const newsPinValidation = [
  body("isPinned").isBoolean().withMessage("مقدار سنجاق‌کردن الزامی و باید true/false باشد"),
  handleValidation,
];

// اعتبارسنجی ثبت نظر روی خبر (POST /api/news/:id/comments) — فقط کاربر واردشده
export const newsCommentValidation = [
  body("content")
    .trim()
    .notEmpty()
    .withMessage("متن نظر الزامی است")
    .isLength({ min: 2, max: 1000 })
    .withMessage("متن نظر باید بین ۲ تا ۱۰۰۰ کاراکتر باشد"),
  body("rating").optional({ values: "null" }).isInt({ min: 1, max: 5 }).withMessage("امتیاز باید عددی بین ۱ تا ۵ باشد"),
  handleValidation,
];

// اعتبارسنجی تغییر وضعیت نظر توسط ادمین (PUT /api/admin/comments/:id/status) — تایید یا رد
export const newsCommentStatusValidation = [
  body("status")
    .trim()
    .notEmpty()
    .withMessage("وضعیت الزامی است")
    .isIn(["approved", "rejected"])
    .withMessage("وضعیت نظر نامعتبر است"),
  handleValidation,
];

// اعتبارسنجی ویرایش نظر توسط ادمین (PUT /api/admin/comments/:id) — حداقل یک فیلد
export const commentEditValidation = [
  body("content").optional().isString().trim().isLength({ min: 2, max: 1000 }).withMessage("متن نظر باید بین ۲ تا ۱۰۰۰ کاراکتر باشد"),
  body("adminReply").optional({ values: "null" }).isString().trim().isLength({ max: 1000 }).withMessage("پاسخ ادمین حداکثر ۱۰۰۰ کاراکتر است"),
  body("internalNote").optional({ values: "null" }).isString().trim().isLength({ max: 1000 }).withMessage("یادداشت داخلی حداکثر ۱۰۰۰ کاراکتر است"),
  body().custom((value) => ["content", "adminReply", "internalNote"].some((k) => value && value[k] !== undefined)).withMessage("حداقل یک فیلد برای ویرایش لازم است"),
  handleValidation,
];

// اعتبارسنجی عملیات گروهی نظرات (POST /api/admin/comments/bulk) — تأیید/رد/حذف، حداکثر ۲۰۰ مورد
export const commentBulkValidation = [
  body("ids").isArray({ min: 1, max: 200 }).withMessage("حداقل یک و حداکثر ۲۰۰ نظر را انتخاب کنید"),
  body("action").isIn(["approve", "reject", "delete"]).withMessage("عملیات نامعتبر است"),
  handleValidation,
];

// اعتبارسنجی تغییر وضعیت پیام تماس با ما (PUT /api/admin/contacts/:id/status)
export const contactStatusValidation = [
  body("status")
    .trim()
    .notEmpty()
    .withMessage("وضعیت الزامی است")
    .isIn(["read", "unread"])
    .withMessage("وضعیت پیام نامعتبر است"),
  handleValidation,
];

// اعتبارسنجی پرچم‌های پیام (PUT /api/admin/contacts/:id/flags) — حداقل یکی از دو پرچم الزامی است
export const contactFlagsValidation = [
  body("isImportant").optional().isBoolean({ strict: true }).withMessage("مقدار «مهم» نامعتبر است"),
  body("isAnswered").optional().isBoolean({ strict: true }).withMessage("مقدار «پاسخ‌داده‌شده» نامعتبر است"),
  body().custom((_, { req }) => {
    if (typeof req.body?.isImportant !== "boolean" && typeof req.body?.isAnswered !== "boolean") {
      throw new Error("حداقل یکی از فیلدهای isImportant یا isAnswered الزامی است");
    }
    return true;
  }),
  handleValidation,
];

// اعتبارسنجی عملیات گروهی پیام‌ها (POST /api/admin/contacts/bulk)
export const contactBulkValidation = [
  body("ids").isArray({ min: 1, max: 200 }).withMessage("حداقل یک و حداکثر ۲۰۰ پیام را انتخاب کنید"),
  body("action")
    .isIn(["read", "unread", "important", "unimportant", "answered", "unanswered", "delete"])
    .withMessage("عملیات نامعتبر است"),
  handleValidation,
];

// توجه: فورمه‌های عمومی تماس و گرفتن وقت هیچ‌وقت فرمت دقیقی برای شماره تماس تحمیل نکرده‌اند
// (فقط یک placeholder راهنما دارند)، پس عمداً یک الگوی سخت‌گیرانه (regex) روی شماره تماس اعمال
// نمی‌شود تا ورودی‌های واقعی که قبلاً کار می‌کردند رد نشوند؛ در عوض فقط طول و عدم خالی بودن
// بررسی می‌شود — همچنان جلوی ورودی خالی/بیش‌ازحد بزرگ/مخرب را می‌گیرد.
const PHONE_MAX_LENGTH = 30;

// اعتبارسنجی فورمه تماس با ما (POST /api/contacts) — مسیر عمومی و بدون نیاز به ورود،
// پس باید در برابر ورودی نامعتبر/حجیم/مخرب محکم باشد
export const contactValidation = [
  body("fullName")
    .trim()
    .notEmpty()
    .withMessage("نام کامل الزامی است")
    .isLength({ max: 150 })
    .withMessage("نام کامل نباید بیشتر از ۱۵۰ کاراکتر باشد"),
  body("phone")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: PHONE_MAX_LENGTH })
    .withMessage("شماره تماس معتبر نیست"),
  body("email")
    .optional({ checkFalsy: true })
    .trim()
    .isEmail()
    .withMessage("فرمت ایمیل معتبر نیست")
    .normalizeEmail(),
  body("message")
    .trim()
    .notEmpty()
    .withMessage("متن پیام الزامی است")
    .isLength({ max: 3000 })
    .withMessage("متن پیام نباید بیشتر از ۳۰۰۰ کاراکتر باشد"),
  // اختیاری (برای صندوق پیام ادمین): فرم قدیمی بدون این دو فیلد همچنان معتبر است
  body("subject")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 200 })
    .withMessage("موضوع نباید بیشتر از ۲۰۰ کاراکتر باشد"),
  body("type")
    .optional({ checkFalsy: true })
    .isIn(["suggestion", "criticism", "complaint", "question", "other"])
    .withMessage("نوع پیام نامعتبر است"),
  handleValidation,
];

// اعتبارسنجی فورمه گرفتن وقت (POST /api/appointments) — هم برای کاربر واردشده و هم مهمان
export const bookAppointmentValidation = [
  body("fullName")
    .trim()
    .notEmpty()
    .withMessage("نام کامل الزامی است")
    .isLength({ max: 150 })
    .withMessage("نام کامل نباید بیشتر از ۱۵۰ کاراکتر باشد")
    .custom((value) => isValidPersianName(value))
    .withMessage(PERSIAN_NAME_ERROR_MESSAGE),
  body("phone")
    .trim()
    .notEmpty()
    .withMessage("شماره تماس الزامی است")
    .isLength({ max: PHONE_MAX_LENGTH })
    .withMessage("شماره تماس معتبر نیست"),
  body("email").optional({ checkFalsy: true }).trim().isEmail().withMessage("فرمت ایمیل معتبر نیست").normalizeEmail(),
  body("department").trim().notEmpty().withMessage("انتخاب بخش الزامی است").isLength({ max: 100 }),
  body("doctorId").notEmpty().withMessage("انتخاب داکتر الزامی است").isInt({ min: 1 }).withMessage("داکتر انتخاب‌شده نامعتبر است"),
  body("appointmentDate")
    .notEmpty()
    .withMessage("تاریخ نوبت الزامی است")
    .isISO8601()
    .withMessage("فرمت تاریخ نامعتبر است"),
  body("appointmentTime")
    .trim()
    .notEmpty()
    .withMessage("ساعت نوبت الزامی است")
    .isLength({ max: 20 })
    .withMessage("مقدار ساعت نوبت نامعتبر است"),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }).withMessage("یادداشت نباید بیشتر از ۱۰۰۰ کاراکتر باشد"),
  handleValidation,
];

// اعتبارسنجی تایید/رد/تکمیل نوبت توسط داکتر (PUT /api/doctors/me/appointments/:id/status)
export const doctorAppointmentStatusValidation = [
  body("status")
    .trim()
    .notEmpty()
    .withMessage("وضعیت الزامی است")
    .isIn(["confirmed", "cancelled", "completed"])
    .withMessage("وضعیت نامعتبر است"),
  body("note").optional({ checkFalsy: true }).trim().isLength({ max: 255 }).withMessage("یادداشت نباید بیشتر از ۲۵۵ کاراکتر باشد"),
  handleValidation,
];

// ---------------------------------------------------------
// پرونده الکترونیک صحی (EMR) — اعتبارسنجی‌ها
// ---------------------------------------------------------

// express-validator روی آرایه، هر عضو را جداگانه بررسی می‌کند؛ پس [1,2] از isInt رد می‌شد و به کوئری می‌رسید (۵۰۰).
// این بررسی تضمین می‌کند شناسه‌ها فقط مقدار تکی (نه آرایه/آبجکت) باشند.
const isScalar = (value) => value === undefined || value === null || ["string", "number"].includes(typeof value);

const patientIdValidator = body("patientId")
  .custom(isScalar)
  .withMessage("شناسه بیمار نامعتبر است")
  .bail()
  .notEmpty()
  .withMessage("شناسه بیمار الزامی است")
  .isInt({ min: 1 })
  .withMessage("شناسه بیمار نامعتبر است");

const recordIdValidator = body("recordId")
  .optional({ checkFalsy: true })
  .custom(isScalar)
  .bail()
  .isInt({ min: 1 })
  .withMessage("شناسه ویزیت نامعتبر است");

// ثبت ویزیت کلی (POST /api/medical-records/encounters)
export const addEncounterValidation = [
  patientIdValidator,
  body("appointmentId").optional({ checkFalsy: true }).custom(isScalar).bail().isInt({ min: 1 }).withMessage("شناسه نوبت نامعتبر است"),
  body("visitDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ ویزیت نامعتبر است"),
  body("symptoms").optional({ checkFalsy: true }).trim().isLength({ max: 5000 }).withMessage("علائم و شرح حال نباید بیشتر از ۵۰۰۰ کاراکتر باشد"),
  body("diagnosis").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("bloodPressure").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("فشار خون نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("temperature").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("درجه حرارت نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("height").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("قد نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("weight").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("وزن نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("labResults").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("نتایج آزمایشگاه نباید بیشتر از ۲۰۰۰ کاراکتر باشد"),
  body("treatment").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("تداوی نباید بیشتر از ۲۰۰۰ کاراکتر باشد"),
  body("prescription").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  // --- فیلدهای فرم «افزودن پرونده صحی» (همه اختیاری) ---
  body("status").optional({ checkFalsy: true }).isIn(["draft", "registered"]).withMessage("وضعیت پرونده نامعتبر است"),
  body("visitReason").optional({ checkFalsy: true }).trim().isLength({ max: 500 }).withMessage("دلیل مراجعه نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("chiefComplaint").optional({ checkFalsy: true }).trim().isLength({ max: 3000 }).withMessage("شکایت اصلی نباید بیشتر از ۳۰۰۰ کاراکتر باشد"),
  body("pulse").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("نبض نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("respiratoryRate").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("تعداد تنفس نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("spo2").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("SpO2 نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("generalCondition").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body(["examFindings", "abnormalFindings", "examNotes", "diagnosisNotes", "followUpNotes"]).optional({ checkFalsy: true }).trim().isLength({ max: 3000 }).withMessage("متن نباید بیشتر از ۳۰۰۰ کاراکتر باشد"),
  body("primaryDiagnosis").optional({ checkFalsy: true }).trim().isLength({ max: 500 }).withMessage("تشخیص اولیه نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("followUpDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ مراجعه بعدی نامعتبر است"),
  body("followUpStatus").optional({ checkFalsy: true }).isIn(["pending", "scheduled", "completed", "cancelled"]).withMessage("وضعیت پیگیری نامعتبر است"),
  body("followUpRequired").optional({ nullable: true }).isBoolean().withMessage("مقدار «نیاز به مراجعه مجدد» نامعتبر است"),
  body(["systemsReview", "recommendations"]).optional({ nullable: true }).custom((v) => v === null || (typeof v === "object" && !Array.isArray(v))).withMessage("ساختار داده نامعتبر است"),
  handleValidation,
];

export const editEncounterValidation = [
  body("visitDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ ویزیت نامعتبر است"),
  body("symptoms").optional({ checkFalsy: true }).trim().isLength({ max: 5000 }).withMessage("علائم و شرح حال نباید بیشتر از ۵۰۰۰ کاراکتر باشد"),
  body("diagnosis").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("bloodPressure").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("فشار خون نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("temperature").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("درجه حرارت نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("height").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("قد نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("weight").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("وزن نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("labResults").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("نتایج آزمایشگاه نباید بیشتر از ۲۰۰۰ کاراکتر باشد"),
  body("treatment").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("تداوی نباید بیشتر از ۲۰۰۰ کاراکتر باشد"),
  body("prescription").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
    // --- فیلدهای فرم «افزودن پرونده صحی» (همه اختیاری) ---
  body("status").optional({ checkFalsy: true }).isIn(["draft", "registered"]).withMessage("وضعیت پرونده نامعتبر است"),
  body("visitReason").optional({ checkFalsy: true }).trim().isLength({ max: 500 }).withMessage("دلیل مراجعه نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("chiefComplaint").optional({ checkFalsy: true }).trim().isLength({ max: 3000 }).withMessage("شکایت اصلی نباید بیشتر از ۳۰۰۰ کاراکتر باشد"),
  body("pulse").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("نبض نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("respiratoryRate").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("تعداد تنفس نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("spo2").optional({ checkFalsy: true }).trim().isLength({ max: 20 }).withMessage("SpO2 نباید بیشتر از ۲۰ کاراکتر باشد"),
  body("generalCondition").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body(["examFindings", "abnormalFindings", "examNotes", "diagnosisNotes", "followUpNotes"]).optional({ checkFalsy: true }).trim().isLength({ max: 3000 }).withMessage("متن نباید بیشتر از ۳۰۰۰ کاراکتر باشد"),
  body("primaryDiagnosis").optional({ checkFalsy: true }).trim().isLength({ max: 500 }).withMessage("تشخیص اولیه نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("followUpDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ مراجعه بعدی نامعتبر است"),
  body("followUpStatus").optional({ checkFalsy: true }).isIn(["pending", "scheduled", "completed", "cancelled"]).withMessage("وضعیت پیگیری نامعتبر است"),
  body("followUpRequired").optional({ nullable: true }).isBoolean().withMessage("مقدار «نیاز به مراجعه مجدد» نامعتبر است"),
  body(["systemsReview", "recommendations"]).optional({ nullable: true }).custom((v) => v === null || (typeof v === "object" && !Array.isArray(v))).withMessage("ساختار داده نامعتبر است"),
  handleValidation,
];

// تشخیص (Diagnosis)
export const addDiagnosisValidation = [
  patientIdValidator,
  recordIdValidator,
  body("title").trim().notEmpty().withMessage("عنوان تشخیص الزامی است").isLength({ max: 255 }),
  body("description").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("icdCode").optional({ checkFalsy: true }).trim().isLength({ max: 20 }),
  body("status").optional({ checkFalsy: true }).isIn(["active", "resolved"]).withMessage("وضعیت نامعتبر است"),
  handleValidation,
];
export const editDiagnosisValidation = [
  body("title").optional({ checkFalsy: true }).trim().isLength({ max: 255 }),
  body("description").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("icdCode").optional({ checkFalsy: true }).trim().isLength({ max: 20 }),
  body("status").optional({ checkFalsy: true }).isIn(["active", "resolved"]).withMessage("وضعیت نامعتبر است"),
  handleValidation,
];

// نسخه (Prescription)
export const addPrescriptionValidation = [
  patientIdValidator,
  recordIdValidator,
  body("appointmentId").optional({ checkFalsy: true }).custom(isScalar).bail().isInt({ min: 1 }).withMessage("شناسه نوبت نامعتبر است"),
  body("groupId").optional({ checkFalsy: true }).matches(/^[A-Za-z0-9-]{8,36}$/).withMessage("شناسه گروه نسخه نامعتبر است"),
  body("diagnosis").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }).withMessage("تشخیص نباید بیشتر از ۱۰۰۰ کاراکتر باشد"),
  body("medicationName").trim().notEmpty().withMessage("نام دوا الزامی است").isLength({ max: 150 }),
  body("dosage").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("frequency").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("duration").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("quantity").optional({ checkFalsy: true }).trim().isLength({ max: 50 }).withMessage("تعداد نباید بیشتر از ۵۰ کاراکتر باشد"),
  body("medicineNotes").optional({ checkFalsy: true }).trim().isLength({ max: 500 }).withMessage("توضیحات دارو نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("instructions").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }),
  body("followUpDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ پیگیری نامعتبر است"),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }).withMessage("یادداشت نباید بیشتر از ۱۰۰۰ کاراکتر باشد"),
  handleValidation,
];
export const editPrescriptionValidation = [
  body("groupId").optional({ checkFalsy: true }).matches(/^[A-Za-z0-9-]{8,36}$/).withMessage("شناسه گروه نسخه نامعتبر است"),
  body("diagnosis").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }).withMessage("تشخیص نباید بیشتر از ۱۰۰۰ کاراکتر باشد"),
  body("medicationName").optional({ checkFalsy: true }).trim().isLength({ max: 150 }),
  body("dosage").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("frequency").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("duration").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("quantity").optional({ checkFalsy: true }).trim().isLength({ max: 50 }).withMessage("تعداد نباید بیشتر از ۵۰ کاراکتر باشد"),
  body("medicineNotes").optional({ checkFalsy: true }).trim().isLength({ max: 500 }).withMessage("توضیحات دارو نباید بیشتر از ۵۰۰ کاراکتر باشد"),
  body("instructions").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }),
  body("followUpDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ پیگیری نامعتبر است"),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }).withMessage("یادداشت نباید بیشتر از ۱۰۰۰ کاراکتر باشد"),
  handleValidation,
];

// حساسیت (Allergy)
export const addAllergyValidation = [
  patientIdValidator,
  body("allergen").trim().notEmpty().withMessage("نام ماده حساسیت‌زا الزامی است").isLength({ max: 150 }),
  body("reaction").optional({ checkFalsy: true }).trim().isLength({ max: 255 }),
  body("severity").optional({ checkFalsy: true }).isIn(["mild", "moderate", "severe"]).withMessage("شدت حساسیت نامعتبر است"),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }),
  handleValidation,
];
export const editAllergyValidation = [
  body("allergen").optional({ checkFalsy: true }).trim().isLength({ max: 150 }),
  body("reaction").optional({ checkFalsy: true }).trim().isLength({ max: 255 }),
  body("severity").optional({ checkFalsy: true }).isIn(["mild", "moderate", "severe"]).withMessage("شدت حساسیت نامعتبر است"),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }),
  handleValidation,
];

// نتیجه آزمایشگاه (Lab Result)
export const addLabResultValidation = [
  patientIdValidator,
  recordIdValidator,
  body("testName").trim().notEmpty().withMessage("نام آزمایش الزامی است").isLength({ max: 150 }),
  body("result").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("unit").optional({ checkFalsy: true }).trim().isLength({ max: 50 }),
  body("referenceRange").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("status").optional({ checkFalsy: true }).isIn(["pending", "completed"]).withMessage("وضعیت نامعتبر است"),
  body("testDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ نامعتبر است"),
  handleValidation,
];
export const editLabResultValidation = [
  body("testName").optional({ checkFalsy: true }).trim().isLength({ max: 150 }),
  body("result").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("unit").optional({ checkFalsy: true }).trim().isLength({ max: 50 }),
  body("referenceRange").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("status").optional({ checkFalsy: true }).isIn(["pending", "completed"]).withMessage("وضعیت نامعتبر است"),
  body("testDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ نامعتبر است"),
  handleValidation,
];

// ثبت نتیجه‌ی نهایی یک آزمایش درخواست‌شده (PUT /api/medical-records/lab-results/:id/result)
export const recordLabResultValidation = [
  body("result").trim().notEmpty().withMessage("نتیجه آزمایش الزامی است").isLength({ max: 2000 }),
  body("unit").optional({ checkFalsy: true }).trim().isLength({ max: 50 }),
  body("referenceRange").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("testDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ نامعتبر است"),
  handleValidation,
];

// گزارش رادیولوژی (Radiology Report)
export const addRadiologyReportValidation = [
  patientIdValidator,
  recordIdValidator,
  body("examType").trim().notEmpty().withMessage("نوع معاینه الزامی است").isLength({ max: 150 }),
  body("findings").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("impression").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }),
  body("imageUrl").optional({ checkFalsy: true }).trim().isLength({ max: 255 }),
  body("examDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ نامعتبر است"),
  handleValidation,
];
export const editRadiologyReportValidation = [
  body("examType").optional({ checkFalsy: true }).trim().isLength({ max: 150 }),
  body("findings").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }),
  body("impression").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }),
  body("imageUrl").optional({ checkFalsy: true }).trim().isLength({ max: 255 }),
  body("examDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ نامعتبر است"),
  handleValidation,
];

// ---------------------------------------------------------
// صورت‌حساب و فاکتور (Billing & Invoice Management) — اعتبارسنجی‌ها
// ---------------------------------------------------------

// صدور فاکتور (POST /api/billing/invoices): بیمار الزامی، حداقل یک ردیف کالا/خدمت
export const generateInvoiceValidation = [
  patientIdValidator,
  body("doctorId").optional({ checkFalsy: true }).isInt({ min: 1 }).withMessage("شناسه داکتر نامعتبر است"),
  body("appointmentId").optional({ checkFalsy: true }).custom(isScalar).bail().isInt({ min: 1 }).withMessage("شناسه نوبت نامعتبر است"),
  body("issueDate").notEmpty().withMessage("تاریخ صدور الزامی است").isISO8601().withMessage("فرمت تاریخ صدور نامعتبر است"),
  body("dueDate").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ سررسید نامعتبر است"),
  body("discount").optional({ checkFalsy: true }).isFloat({ min: 0 }).withMessage("تخفیف نمی‌تواند منفی باشد"),
  body("tax").optional({ checkFalsy: true }).isFloat({ min: 0 }).withMessage("مالیات نمی‌تواند منفی باشد"),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }),
  body("items")
    .isArray({ min: 1 })
    .withMessage("فاکتور باید حداقل یک ردیف کالا/خدمت داشته باشد"),
  body("items.*.description")
    .trim()
    .notEmpty()
    .withMessage("عنوان هر ردیف الزامی است")
    .isLength({ max: 255 }),
  body("items.*.quantity")
    .isFloat({ gt: 0 })
    .withMessage("تعداد هر ردیف باید عددی بزرگ‌تر از صفر باشد"),
  body("items.*.unitPrice")
    .isFloat({ min: 0 })
    .withMessage("قیمت واحد نمی‌تواند منفی باشد"),
  handleValidation,
];

// ثبت پرداخت (POST /api/billing/invoices/:id/payments)
export const recordPaymentValidation = [
  body("amount").isFloat({ gt: 0 }).withMessage("مبلغ پرداختی باید بزرگ‌تر از صفر باشد"),
  body("method").optional({ checkFalsy: true }).isIn(PAYMENT_METHODS).withMessage("روش پرداخت نامعتبر است"),
  body("paidAt").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ پرداخت نامعتبر است"),
  body("reference").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  body("notes").optional({ checkFalsy: true }).trim().isLength({ max: 500 }),
  handleValidation,
];

// ---------------------------------------------------------
// سیستم گزارش‌گیری (Reporting System) — اعتبارسنجی فیلترها
// ---------------------------------------------------------

// فیلترهای مشترک همه‌ی گزارش‌ها: بازه‌ی تاریخ + فرمت خروجی (json/pdf/excel)
export const reportFilterValidation = [
  query("from").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ شروع نامعتبر است"),
  query("to").optional({ checkFalsy: true }).isISO8601().withMessage("فرمت تاریخ پایان نامعتبر است"),
  query("format").optional({ checkFalsy: true }).isIn(["json", "pdf", "excel"]).withMessage("فرمت خروجی نامعتبر است"),
  handleValidation,
];

// فیلترهای اضافی مخصوص گزارش نوبت‌ها
export const appointmentReportFilterValidation = [
  ...reportFilterValidation.slice(0, -1),
  query("status").optional({ checkFalsy: true }).isIn(["pending", "confirmed", "completed", "cancelled"]).withMessage("وضعیت نامعتبر است"),
  query("doctorId").optional({ checkFalsy: true }).isInt({ min: 1 }).withMessage("شناسه داکتر نامعتبر است"),
  query("department").optional({ checkFalsy: true }).trim().isLength({ max: 100 }),
  handleValidation,
];

// ---------------------------------------------------------
// مدیریت بخش‌ها (Department Management) — اعتبارسنجی POST/PUT
// ---------------------------------------------------------

// یک رنگ به‌صورت کد HEX (#fff یا #ffffff) یا نام رنگ ساده‌ی CSS (حروف/عدد/فاصله/خط‌تیره)
// می‌تواند باشد — کاملاً اختیاری، فقط طول و کاراکترهای مجاز بررسی می‌شود تا فرم‌های
// رنگ‌بندی کارت بخش (iconColor/iconBackground/cardBackground/textColor) محدود نشوند.
const COLOR_REGEX = /^(#[0-9a-fA-F]{3,8}|[a-zA-Z][a-zA-Z0-9\s-]{0,30})$/;

// ثبت بخش جدید (POST /api/departments) — فقط name الزامی است؛ بقیه‌ی فیلدها
// (آیکون/رنگ‌بندی/ترتیب نمایش/وضعیت/سئو) اختیاری‌اند و در صورت نبود، مقدار
// پیش‌فرض ستون دیتابیس را می‌گیرند (models/Department.js).
export const createDepartmentValidation = [
  body("name")
    .trim()
    .notEmpty()
    .withMessage("نام بخش الزامی است")
    .isLength({ max: 100 })
    .withMessage("نام بخش نباید بیشتر از ۱۰۰ کاراکتر باشد"),
  body("nameEn").optional({ checkFalsy: true }).trim().isLength({ max: 100 }).withMessage("نام انگلیسی بخش نباید بیشتر از ۱۰۰ کاراکتر باشد"),
  body("description").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("توضیحات طولانی است"),
  body("descriptionEn").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("توضیحات انگلیسی طولانی است"),
  body("icon").optional({ checkFalsy: true }).trim().isLength({ max: 255 }).withMessage("مقدار آیکون نامعتبر است"),
  body("iconType").optional({ checkFalsy: true }).isIn(ICON_TYPES).withMessage("نوع آیکون باید upload یا lucide باشد"),
  body("iconColor").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ آیکون نامعتبر است"),
  body("iconBackground").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ پس‌زمینه آیکون نامعتبر است"),
  body("cardBackground").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ پس‌زمینه کارت نامعتبر است"),
  body("textColor").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ متن نامعتبر است"),
  body("slug")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 150 })
    .withMessage("نامک (slug) نباید بیشتر از ۱۵۰ کاراکتر باشد"),
  body("displayOrder").optional({ checkFalsy: true }).isInt().withMessage("ترتیب نمایش باید عدد صحیح باشد"),
  body("status").optional({ checkFalsy: true }).isIn(DEPARTMENT_STATUSES).withMessage("وضعیت باید active یا inactive باشد"),
  body("showOnWebsite").optional().isBoolean().withMessage("مقدار نمایش در سایت باید true/false باشد"),
  body("seoTitle").optional({ checkFalsy: true }).trim().isLength({ max: 200 }).withMessage("عنوان سئو نباید بیشتر از ۲۰۰ کاراکتر باشد"),
  body("seoDescription").optional({ checkFalsy: true }).trim().isLength({ max: 300 }).withMessage("توضیحات سئو نباید بیشتر از ۳۰۰ کاراکتر باشد"),
  handleValidation,
];

// ویرایش بخش (PUT /api/departments/:id) — همان قوانین بالا، با این تفاوت که name
// هم اختیاری است (به‌روزرسانی جزئی مجاز است) اما اگر ارسال شود نباید خالی باشد.
export const updateDepartmentValidation = [
  body("name")
    .optional({ checkFalsy: true })
    .trim()
    .notEmpty()
    .withMessage("نام بخش نمی‌تواند خالی باشد")
    .isLength({ max: 100 })
    .withMessage("نام بخش نباید بیشتر از ۱۰۰ کاراکتر باشد"),
  body("nameEn").optional({ checkFalsy: true }).trim().isLength({ max: 100 }).withMessage("نام انگلیسی بخش نباید بیشتر از ۱۰۰ کاراکتر باشد"),
  body("description").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("توضیحات طولانی است"),
  body("descriptionEn").optional({ checkFalsy: true }).trim().isLength({ max: 2000 }).withMessage("توضیحات انگلیسی طولانی است"),
  body("icon").optional({ checkFalsy: true }).trim().isLength({ max: 255 }).withMessage("مقدار آیکون نامعتبر است"),
  body("iconType").optional({ checkFalsy: true }).isIn(ICON_TYPES).withMessage("نوع آیکون باید upload یا lucide باشد"),
  body("iconColor").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ آیکون نامعتبر است"),
  body("iconBackground").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ پس‌زمینه آیکون نامعتبر است"),
  body("cardBackground").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ پس‌زمینه کارت نامعتبر است"),
  body("textColor").optional({ checkFalsy: true }).trim().matches(COLOR_REGEX).withMessage("رنگ متن نامعتبر است"),
  body("slug")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 150 })
    .withMessage("نامک (slug) نباید بیشتر از ۱۵۰ کاراکتر باشد"),
  body("displayOrder").optional({ checkFalsy: true }).isInt().withMessage("ترتیب نمایش باید عدد صحیح باشد"),
  body("status").optional({ checkFalsy: true }).isIn(DEPARTMENT_STATUSES).withMessage("وضعیت باید active یا inactive باشد"),
  body("showOnWebsite").optional().isBoolean().withMessage("مقدار نمایش در سایت باید true/false باشد"),
  body("seoTitle").optional({ checkFalsy: true }).trim().isLength({ max: 200 }).withMessage("عنوان سئو نباید بیشتر از ۲۰۰ کاراکتر باشد"),
  body("seoDescription").optional({ checkFalsy: true }).trim().isLength({ max: 300 }).withMessage("توضیحات سئو نباید بیشتر از ۳۰۰ کاراکتر باشد"),
  handleValidation,
];

// ---------- گفتگوی خصوصی بیمار ↔ داکتر (Chat) ----------

// شروع مکالمه: بیمار doctorId می‌فرستد، داکتر patientId می‌فرستد؛ کدام یک الزامی است
// در کنترلر بر اساس نقش کاربر واردشده تعیین می‌شود، نه اینجا
export const startConversationValidation = [
  body("doctorId").optional({ checkFalsy: true }).isInt({ min: 1 }).withMessage("شناسه‌ی داکتر نامعتبر است"),
  body("patientId").optional({ checkFalsy: true }).isInt({ min: 1 }).withMessage("شناسه‌ی بیمار نامعتبر است"),
  handleValidation,
];

// ارسال پیام متنی در یک مکالمه
export const sendMessageValidation = [
  body("content")
    .trim()
    .notEmpty()
    .withMessage("متن پیام نمی‌تواند خالی باشد")
    .isLength({ max: 4000 })
    .withMessage("متن پیام نباید بیشتر از ۴۰۰۰ کاراکتر باشد"),
  handleValidation,
];

// واکنش ایموجی روی یک پیام — فقط مجموعه‌ی ثابت زیر مجاز است (مشابه اپ‌های پیام‌رسان رایج)
const ALLOWED_MESSAGE_REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "😡"];

export const reactToMessageValidation = [
  body("emoji")
    .trim()
    .notEmpty()
    .withMessage("نوع واکنش الزامی است")
    .isIn(ALLOWED_MESSAGE_REACTIONS)
    .withMessage("نوع واکنش مجاز نیست"),
  handleValidation,
];

// ارسال یک پیوست (عکس/سند) به‌همراه پیام؛ برخلاف sendMessageValidation، متن اینجا
// اختیاری است (پیام می‌تواند فقط شامل فایل باشد، بدون هیچ متنی)
export const sendMessageAttachmentValidation = [
  body("content")
    .optional({ checkFalsy: true })
    .trim()
    .isLength({ max: 4000 })
    .withMessage("متن پیام نباید بیشتر از ۴۰۰۰ کاراکتر باشد"),
  handleValidation,
];

// ارسال یک پیام صوتی؛ duration (مدت‌زمان ضبط‌شده به ثانیه، محاسبه‌شده در مرورگر کاربر)
// الزامی است و برای نمایش سریع مدت‌زمان در پخش‌کننده استفاده می‌شود. این مقدار صرفاً برای
// نمایش است، نه یک کنترل امنیتی — محدودیت واقعیِ حجم/مدت روی خودِ فایل توسط میان‌افزار
// آپلود (uploadChatVoice) اعمال می‌شود.
export const sendVoiceMessageValidation = [
  body("duration")
    .notEmpty()
    .withMessage("مدت‌زمان پیام صوتی الزامی است")
    .isFloat({ min: 0.5, max: 300 })
    .withMessage("مدت‌زمان پیام صوتی باید بین نیم ثانیه تا ۵ دقیقه باشد"),
  handleValidation,
];

// ارسال گزارش پرونده صحی به بیمار — توضیح کوتاه اختیاری
export const sendEncounterValidation = [
  body("message").optional({ checkFalsy: true }).trim().isLength({ max: 1000 }).withMessage("توضیح همراه پرونده نباید بیشتر از ۱۰۰۰ کاراکتر باشد"),
  handleValidation,
];

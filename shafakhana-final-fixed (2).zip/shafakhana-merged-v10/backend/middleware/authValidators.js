import { body, validationResult } from "express-validator";
import { getPasswordPolicyError } from "../utils/passwordPolicy.js";
import { isValidPersianName, PERSIAN_NAME_ERROR_MESSAGE } from "../utils/persianName.js";
import { getEmailValidationErrorAsync } from "../utils/emailValidation.js";

// اگر خطای اعتبارسنجی وجود داشته باشد، پاسخ ۴۰۰ با اولین پیام خطا برمی‌گرداند
export function handleValidation(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ message: errors.array()[0].msg });
  }
  next();
}

// اعتبارسنجی رمز عبور طبق سیاست مشترک (فقط حروف انگلیسی/عدد/کاراکتر خاص مجاز، بدون
// حروف فارسی/عربی، حداقل ۸ کاراکتر — بدون نیاز به حرف بزرگ/کوچک/عدد/کاراکتر خاص
// اجباری) — همان تابعی که در backend/utils/passwordPolicy.js تعریف شده، برای
// جلوگیری از تکرار منطق.
function validatePasswordPolicy(value) {
  const error = getPasswordPolicyError(value);
  if (error) throw new Error(error);
  return true;
}

// اعتبارسنجی ایمیل هنگام ثبت‌نام، طبق سیاست مشترک backend/utils/emailValidation.js:
// ۱) فرمت کلی معتبر + قوانین Gmail (فقط دامنه‌ی دقیقاً gmail.com) + رد اشتباهات تایپی
//    رایج دامنه + رد حروف فارسی/عربی، سپس
// ۲) در صورت معتبر بودن فرمت، بررسی فنی DNS/MX دامنه (در صورت امکان) — این مرجع نهایی
//    امنیتی است: اگر نامعتبر باشد، به handleValidation می‌رسد و درخواست با ۴۰۰ رد
//    می‌شود — پیش از آنکه کنترلر register به هیچ‌وجه کد تایید ۶ رقمی را ارسال کند.
// express-validator از custom validator های async (که Promise برمی‌گردانند) پشتیبانی
// می‌کند؛ در صورت رد شدن Promise، همان پیام به‌عنوان خطای فیلد ثبت می‌شود.
async function validateEmailFormat(value) {
  const error = await getEmailValidationErrorAsync(value);
  if (error) throw new Error(error);
  return true;
}

export const registerValidation = [
  body("fullName")
    .trim()
    .notEmpty()
    .withMessage("نام کامل الزامی است")
    .custom((value) => isValidPersianName(value))
    .withMessage(PERSIAN_NAME_ERROR_MESSAGE),
  body("email")
    .trim()
    .notEmpty()
    .withMessage("ایمیل الزامی است")
    .custom(validateEmailFormat),
    // توجه: عمداً از .normalizeEmail() استفاده نشده است. آن تابع به‌طور پیش‌فرض روی
    // Gmail، نقطه‌های local-part و بخش +subaddress را حذف و googlemail.com را به
    // gmail.com تبدیل می‌کند — یعنی ایمیلی که واقعاً ذخیره/ارسال می‌شود می‌توانست با
    // چیزی که کاربر عیناً تایپ کرده متفاوت باشد. کد تایید باید دقیقاً به همان آدرسی
    // که کاربر وارد کرده ارسال شود (فقط فاصله‌های اضافی با .trim() حذف می‌شوند).
  body("password").custom(validatePasswordPolicy),
  handleValidation,
];

export const loginValidation = [
  body("email")
    .trim()
    .notEmpty()
    .withMessage("ایمیل الزامی است")
    .isEmail()
    .withMessage("فرمت ایمیل معتبر نیست")
    .normalizeEmail(),
  body("password").notEmpty().withMessage("رمز عبور الزامی است"),
  handleValidation,
];

export const emailOnlyValidation = [
  body("email")
    .trim()
    .notEmpty()
    .withMessage("ایمیل الزامی است")
    .isEmail()
    .withMessage("فرمت ایمیل معتبر نیست")
    .normalizeEmail(),
  handleValidation,
];

export const verifyEmailValidation = [
  body("email")
    .trim()
    .notEmpty()
    .withMessage("ایمیل الزامی است")
    .isEmail()
    .withMessage("فرمت ایمیل معتبر نیست")
    .normalizeEmail(),
  body("code")
    .trim()
    .notEmpty()
    .withMessage("کد تایید الزامی است")
    .isLength({ min: 6, max: 6 })
    .withMessage("کد تایید باید ۶ رقم باشد"),
  handleValidation,
];

export const resetPasswordValidation = [
  body("email")
    .trim()
    .notEmpty()
    .withMessage("ایمیل الزامی است")
    .isEmail()
    .withMessage("فرمت ایمیل معتبر نیست")
    .normalizeEmail(),
  body("code")
    .trim()
    .notEmpty()
    .withMessage("کد بازیابی الزامی است")
    .isLength({ min: 6, max: 6 })
    .withMessage("کد بازیابی باید ۶ رقم باشد"),
  body("newPassword").custom(validatePasswordPolicy),
  handleValidation,
];

import jwt from "jsonwebtoken";
import { JWT_SECRET } from "../utils/env.js";
import { CSRF_HEADER, csrfTokenFor, getTokenFromRequest, safeEqual } from "../utils/authCookies.js";

// محافظت CSRF برای درخواست‌های تغییردهنده‌ای که با «کوکی» احراز هویت می‌شوند.
// - درخواست‌های امن (GET/HEAD/OPTIONS) بررسی نمی‌شوند.
// - درخواست‌هایی که با هدر Authorization می‌آیند (کلاینت API، تست‌ها) بررسی نمی‌شوند؛ مرورگر این هدر را
//   خودکار و cross-site نمی‌فرستد، پس CSRF‌پذیر نیستند.
// - درخواست‌های بدون نشست (مهمان) یا با کوکی نامعتبر/منقضی هم عبور می‌کنند؛ خودِ requireAuth آن‌ها را رد می‌کند.
// - مسیرهای پیش از ورود (login/register/...) و logout معاف‌اند: هنوز نشستی برای ساخت توکن وجود ندارد
//   (logout هم عمداً تلورانس دارد تا کاربر همیشه بتواند کوکی را پاک کند).
// علاوه بر این، CORS پروژه فقط origin های فهرست‌شده را می‌پذیرد، پس فرم‌های cross-site هم از قبل رد می‌شوند.
const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);
const EXEMPT_PATHS = new Set([
  "/auth/login",
  "/auth/mfa/verify",
  "/auth/register",
  "/auth/verify-email",
  "/auth/resend-verification",
  "/auth/forgot-password",
  "/auth/reset-password",
  "/auth/logout",
]);

export function csrfProtection(req, res, next) {
  if (SAFE_METHODS.has(req.method)) return next();
  if (EXEMPT_PATHS.has(req.path)) return next();

  const { token, source } = getTokenFromRequest(req);
  if (source !== "cookie") return next();

  let payload;
  try {
    payload = jwt.verify(token, JWT_SECRET, { algorithms: ["HS256"] });
  } catch {
    return next();
  }

  if (!safeEqual(csrfTokenFor(payload), req.headers[CSRF_HEADER])) {
    return res.status(403).json({
      message: "درخواست نامعتبر است (توکن امنیتی CSRF). صفحه را دوباره بارگذاری کنید.",
      code: "CSRF_INVALID",
    });
  }
  return next();
}

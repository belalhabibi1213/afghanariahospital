import { IS_PRODUCTION } from "../utils/env.js";

// برای مسیرهایی که به هیچ route ای نخوردند (۴۰۴) — باید بعد از همه‌ی route ها اضافه شود
export function notFoundHandler(req, res) {
  res.status(404).json({ message: "مسیر درخواستی یافت نشد" });
}

// میان‌افزار نهایی مدیریت خطا — باید آخرین چیزی باشد که به app.use() اضافه می‌شود.
// خطای کامل (شامل stack trace) همیشه در کنسول سرور لاگ می‌شود تا برای عیب‌یابی در دسترس باشد،
// اما به کلاینت هرگز جزئیات داخلی (stack trace، پیام خطای خام دیتابیس و ...) فرستاده نمی‌شود؛
// این کار از افشای اطلاعات حساس (نسخه دیتابیس، ساختار جداول، مسیرهای فایل سرور و ...) جلوگیری می‌کند.
// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  console.error("❌ خطای مدیریت‌نشده:", err);

  // خطاهای شناخته‌شده‌ی express.json() برای بدنه‌ی JSON نامعتبر
  if (err.type === "entity.parse.failed") {
    return res.status(400).json({ message: "فرمت داده ارسالی نامعتبر است" });
  }

  const status = err.status || err.statusCode || 500;
  const message =
    status < 500
      ? err.message || "درخواست نامعتبر است"
      : "خطای غیرمنتظره سرور رخ داد. لطفاً کمی بعد دوباره تلاش کنید.";

  const payload = { message };
  if (!IS_PRODUCTION && status >= 500) {
    // فقط در محیط توسعه، برای کمک به عیب‌یابی محلی، پیام خام خطا هم اضافه می‌شود
    payload.debug = err.message;
  }

  res.status(status).json(payload);
}

// اجرای بدون Docker با pm2:  cd backend && pm2 start ../deploy/ecosystem.config.cjs && pm2 save
// متغیرها را در backend/.env بگذارید (NODE_ENV=production، JWT_SECRET، DB_* با کاربر محدود، TRUST_PROXY=1 پشت Nginx).
module.exports = {
  apps: [{
    name: "shafakhana-api",
    script: "server.js",
    cwd: __dirname + "/../backend",
    instances: 1,            // Socket.IO و زمان‌بندها (cron) تک‌نمونه‌اند؛ cluster نکنید
    exec_mode: "fork",
    max_memory_restart: "600M",
    env: { NODE_ENV: "production" },
    kill_timeout: 12000,     // خاموشی تمیز تا ۱۰ ثانیه
  }],
};

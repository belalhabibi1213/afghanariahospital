import { describe, it, expect } from "vitest";
import fs from "node:fs";
import path from "node:path";

// هدرهای امنیتی فرانت در vercel.json تعریف می‌شوند (بک‌اند فقط API را سرو می‌کند).
// این تست تضمین می‌کند هدرها حذف نشوند و CSP با منابعی که index.html واقعاً لود می‌کند هماهنگ بماند.
const root = process.cwd();
const vercel = JSON.parse(fs.readFileSync(path.join(root, "vercel.json"), "utf-8"));
const html = fs.readFileSync(path.join(root, "index.html"), "utf-8");

const headerMap = Object.fromEntries(
  vercel.headers.find((h) => h.source === "/(.*)").headers.map((h) => [h.key, h.value])
);
const csp = Object.fromEntries(
  headerMap["Content-Security-Policy"].split(";").map((d) => d.trim()).filter(Boolean).map((d) => {
    const [name, ...vals] = d.split(/\s+/);
    return [name, vals];
  })
);

describe("هدرهای امنیتی (vercel.json)", () => {
  it("rewrite مربوط به SPA سر جایش مانده است", () => {
    expect(vercel.rewrites).toEqual([{ source: "/(.*)", destination: "/index.html" }]);
  });

  it("هدرهای پایه‌ی ضدحمله وجود دارند", () => {
    expect(headerMap["X-Content-Type-Options"]).toBe("nosniff");
    expect(headerMap["X-Frame-Options"]).toBe("DENY");
    expect(headerMap["Referrer-Policy"]).toBe("strict-origin-when-cross-origin");
    expect(headerMap["Strict-Transport-Security"]).toMatch(/max-age=\d{7,}/);
  });

  it("CSP: اسکریپت فقط از خود سایت، بدون inline و بدون eval", () => {
    expect(csp["script-src"]).toEqual(["'self'"]);
    expect(JSON.stringify(csp)).not.toMatch(/unsafe-eval/);
    expect(csp["object-src"]).toEqual(["'none'"]);
    expect(csp["base-uri"]).toEqual(["'self'"]);
  });

  it("CSP: connect-src/img-src/media-src بدون wildcard کلی https: یا wss:", () => {
    for (const key of ["connect-src", "img-src", "media-src"]) {
      expect(csp[key], key).not.toContain("https:");
      expect(csp[key], key).not.toContain("wss:");
    }
  });

  it("CSP: جلوگیری از قرارگرفتن سایت داخل iframe (clickjacking)", () => {
    expect(csp["frame-ancestors"]).toEqual(["'none'"]);
  });

  it("Permissions-Policy: دوربین/میکروفون برای تماس صوتی/تصویری مجاز، بقیه‌ی قابلیت‌های حساس بسته", () => {
    const pp = headerMap["Permissions-Policy"];
    expect(pp).toContain("microphone=(self)");
    expect(pp).toContain("camera=(self)");
    expect(pp).toContain("geolocation=()");
  });

  it("هر منبع خارجی (در صورت وجود) که index.html لود می‌کند در CSP مجاز شده — فونت‌ها اکنون محلی‌اند", () => {
    const hosts = [...html.matchAll(/(?:src|href)="(https?:\/\/[^"/]+)/g)].map((m) => m[1]);
    for (const host of new Set(hosts)) {
      const allowed = [...csp["style-src"], ...csp["font-src"], ...csp["connect-src"]].includes(host);
      expect(allowed, `${host} در CSP مجاز نیست`).toBe(true);
    }
  });

  it("index.html اسکریپت inline ندارد (وگرنه با script-src 'self' بلوکه می‌شود)", () => {
    expect(html).not.toMatch(/<script(?![^>]*\ssrc=)[^>]*>\s*\S/);
  });
});

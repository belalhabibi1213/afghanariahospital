// عکس‌های واقعی از Pexels (رایگان، بدون کپی‌رایت، بدون نیاز به attribution)
// اگر خواستید بعداً عکس‌های اختصاصی شفاخانه را جایگزین کنید، فقط همین آدرس‌ها را عوض کنید.

export const photos = {
  heroBuilding: "/images/hospital-building.webp",
  heroBuilding640: "/images/hospital-building-640.webp",
  hospitalCorridor:
    "https://images.pexels.com/photos/33812023/pexels-photo-33812023.jpeg?auto=compress&cs=tinysrgb&w=1200",
  doctorsTeam1:
    "https://images.pexels.com/photos/6129507/pexels-photo-6129507.jpeg?auto=compress&cs=tinysrgb&w=1200",
  doctorsTeam2:
    "https://images.pexels.com/photos/5452193/pexels-photo-5452193.jpeg?auto=compress&cs=tinysrgb&w=1200",
  doctorsTeam3:
    "https://images.pexels.com/photos/5452190/pexels-photo-5452190.jpeg?auto=compress&cs=tinysrgb&w=1200",
  doctorsTeam4:
    "https://images.pexels.com/photos/5452233/pexels-photo-5452233.jpeg?auto=compress&cs=tinysrgb&w=1200",
  stethoscopeHeart:
    "https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800",
  stethoscopeChart:
    "https://images.pexels.com/photos/40568/pexels-photo-40568.jpeg?auto=compress&cs=tinysrgb&w=800",
  doctorStethoscope:
    "https://images.pexels.com/photos/12955896/pexels-photo-12955896.jpeg?auto=compress&cs=tinysrgb&w=800",
  pediatrician:
    "https://images.pexels.com/photos/8460035/pexels-photo-8460035.jpeg?auto=compress&cs=tinysrgb&w=800",
};

import { describe, it, expect, vi, beforeEach } from "vitest";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Route } from "react-router-dom";
import ChangePasswordRequired from "./ChangePasswordRequired.jsx";
import { renderWithProviders, jsonResponse } from "../test/renderWithProviders.jsx";
import { USER_KEY } from "../utils/api.js";

const admin = { id: 1, fullName: "مدیر", role: "admin", mustChangePassword: true };
let fetchMock;

function setup() {
  localStorage.setItem(USER_KEY, JSON.stringify(admin));
  fetchMock = vi.fn().mockResolvedValueOnce(jsonResponse(200, { user: admin, csrfToken: "csrf-1" })); // restoreSession
  vi.stubGlobal("fetch", fetchMock);
  const utils = renderWithProviders(null, {
    route: "/anything",
    routes: (
      <>
        <Route path="/anything" element={<ChangePasswordRequired />} />
        <Route path="/dashboard/admin" element={<div>داشبورد ادمین</div>} />
      </>
    ),
  });
  return utils;
}

const inputs = (container) => container.querySelectorAll('input[type="password"]');
const submitBtn = () => screen.getByRole("button", { name: "تغییر رمز عبور و ادامه" });

describe("تغییر رمز عبور اجباری", () => {
  beforeEach(() => vi.restoreAllMocks());

  it("رمز جدید ضعیف رد می‌شود و درخواستی نمی‌رود", async () => {
    const { container } = setup();
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1)); // بازیابی نشست
    const [cur, next, confirm] = inputs(container);
    await userEvent.type(cur, "TempPass123");
    await userEvent.type(next, "short");
    await userEvent.type(confirm, "short");
    await userEvent.click(submitBtn());
    expect(await screen.findByText(/حداقل ۸ کاراکتر باشد/, { selector: ".form-message" })).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("تکرار رمز نامطابق رد می‌شود", async () => {
    const { container } = setup();
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    const [cur, next, confirm] = inputs(container);
    await userEvent.type(cur, "TempPass123");
    await userEvent.type(next, "NewPassword1");
    await userEvent.type(confirm, "NewPassword2");
    await userEvent.click(submitBtn());
    expect(await screen.findByText("رمز عبور جدید و تکرار آن یکسان نیست.")).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledTimes(1);
  });

  it("رمز موقت اشتباه: پیام سرور نمایش داده می‌شود و پرچم تغییر رمز برداشته نمی‌شود", async () => {
    const { container } = setup();
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    fetchMock.mockResolvedValueOnce(jsonResponse(400, { message: "رمز فعلی اشتباه است" }));
    const [cur, next, confirm] = inputs(container);
    await userEvent.type(cur, "wrong");
    await userEvent.type(next, "NewPassword1");
    await userEvent.type(confirm, "NewPassword1");
    await userEvent.click(submitBtn());
    expect(await screen.findByText("رمز فعلی اشتباه است")).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(USER_KEY)).mustChangePassword).toBe(true);
  });

  it("تغییر موفق: PUT با بدنه و CSRF درست، پرچم برداشته و هدایت به داشبورد همان نقش", async () => {
    const { container } = setup();
    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(1));
    fetchMock.mockResolvedValueOnce(jsonResponse(200, { message: "ok" }));
    const [cur, next, confirm] = inputs(container);
    await userEvent.type(cur, "TempPass123");
    await userEvent.type(next, "NewPassword1");
    await userEvent.type(confirm, "NewPassword1");
    await userEvent.click(submitBtn());

    await waitFor(() => expect(fetchMock).toHaveBeenCalledTimes(2));
    const [url, opts] = fetchMock.mock.calls[1];
    expect(url).toMatch(/\/users\/change-password$/);
    expect(opts.method).toBe("PUT");
    expect(opts.headers["X-CSRF-Token"]).toBe("csrf-1");
    expect(JSON.parse(opts.body)).toEqual({ currentPassword: "TempPass123", newPassword: "NewPassword1" });

    expect(await screen.findByText("داشبورد ادمین")).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(USER_KEY)).mustChangePassword).toBe(false);
  });
});

import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { API_BASE } from "../utils/api.js";

const FORGOT_URL = `${API_BASE}/auth/forgot-password`;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function ForgotPassword() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    if (!email.trim() || !EMAIL_REGEX.test(email.trim())) {
      setStatus({ type: "error", text: "لطفاً یک ایمیل معتبر وارد کنید." });
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(FORGOT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();

      if (!res.ok) {
        setStatus({ type: "error", text: data.message || "درخواست بازیابی رمز عبور ناموفق بود." });
        setLoading(false);
        return;
      }

      setStatus({
        type: "success",
        text: data.message || "اگر این ایمیل در سیستم ثبت باشد، کد بازیابی برای آن ارسال می‌شود.",
      });

      // بعد از چند لحظه کاربر را به صفحه وارد کردن کد و رمز جدید منتقل می‌کنیم
      setTimeout(() => {
        navigate("/reset-password", { state: { email: email.trim() } });
      }, 1200);
    } catch (err) {
      setStatus({
        type: "error",
        text: "اتصال به سرور برقرار نشد. مطمئن شوید بک‌اند اجرا است (npm run dev در پوشه backend).",
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page pub-page">
      <Link to="/home" className="back-home">→ بازگشت به سایت</Link>

      <div className="login-card pub-card">
        <div className="login-head">
          <div className="brand-mark" style={{ width: 46, height: 46, fontSize: 20, borderRadius: 14 }}>🔑</div>
          <h1>فراموشی رمز عبور</h1>
          <p>ایمیل ثبت‌شده خود را وارد کنید تا کد بازیابی برای شما ارسال شود</p>
        </div>

        <form className="login-form" onSubmit={handleSubmit} noValidate>
          {status.text && (
            <div className={`form-message ${status.type}`}>{status.text}</div>
          )}

          <div className="field">
            <label>ایمیل</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? "در حال ارسال..." : "ارسال کد بازیابی"}
          </button>
        </form>

        <p className="login-footer-text">
          کد بازیابی را دریافت کرده‌اید؟ <Link to="/reset-password" state={{ email }}>وارد کردن کد</Link>
        </p>
        <p className="login-footer-text">
          <Link to="/login">بازگشت به صفحه ورود</Link>
        </p>
      </div>
    </div>
  );
}

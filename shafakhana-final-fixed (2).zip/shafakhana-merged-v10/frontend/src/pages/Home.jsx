import { startTransition, useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import Header from "../components/header/Header.jsx";
import Hero from "../components/Hero.jsx";
import QuickAccess from "../components/QuickAccess.jsx";
import useScrollReveal from "../components/useScrollReveal.js";
import About from "../components/About.jsx";
import Doctors from "../components/Doctors.jsx";
import Services from "../components/Services.jsx";
import AppointmentSection from "../components/AppointmentSection.jsx";
import News from "../components/News.jsx";
import Contact from "../components/Contact.jsx";
import Footer from "../components/Footer.jsx";
import SectionErrorBoundary from "../components/SectionErrorBoundary.jsx";

export default function Home() {
  useScrollReveal();
  const location = useLocation();

  // رندر دو مرحله‌ای: اول فقط هدر + Hero (کوچک و سریع ⇒ نمایش اولیه و LCP زودتر)، بعد بقیه‌ی بخش‌ها داخل
  // startTransition؛ ری‌اکت آن را تکه‌تکه (time-slicing) رندر می‌کند و main thread را برای اسکرول/کلیک
  // آزاد نگه می‌دارد. اگر آدرس هش دارد (مثلاً #appointment) همه‌چیز از همان اول رندر می‌شود.
  const [restReady, setRestReady] = useState(Boolean(location.hash));
  useEffect(() => {
    if (restReady) return undefined;
    const timer = setTimeout(() => startTransition(() => setRestReady(true)), 0);
    return () => clearTimeout(timer);
  }, [restReady]);

  // به هدر خبر می‌دهیم بخش‌ها آماده‌اند تا لینک فعال (scroll-spy) را روی آن‌ها وصل کند
  useEffect(() => {
    if (restReady) window.dispatchEvent(new Event("shafakhana:sections-ready"));
  }, [restReady]);

  // وقتی کاربر با یک هش وارد صفحه اصلی می‌شود (مثلاً بعد از ورود موفق و بازگشت به
  // #appointment)، به همان بخش اسکرول نرم می‌شود؛ کمی تأخیر تا رندر کامل بخش‌ها.
  // اگر هش عوض شد ولی بخش هنوز رندر نشده، بقیه‌ی بخش‌ها فوراً رندر می‌شوند.
  useEffect(() => {
    if (!location.hash) return undefined;
    const target = document.querySelector(location.hash);
    if (!target) {
      if (!restReady) setRestReady(true);
      return undefined;
    }
    const timer = setTimeout(() => target.scrollIntoView({ behavior: "smooth", block: "start" }), 150);
    return () => clearTimeout(timer);
  }, [location.hash, restReady]);

  return (
    <div className="pub-page">
      <Header />
      <SectionErrorBoundary label="hero"><Hero /></SectionErrorBoundary>
      {restReady && (
        <>
          <SectionErrorBoundary label="quick-access"><QuickAccess /></SectionErrorBoundary>
          <SectionErrorBoundary label="about"><About /></SectionErrorBoundary>
          <SectionErrorBoundary label="doctors"><Doctors /></SectionErrorBoundary>
          <SectionErrorBoundary label="services"><Services /></SectionErrorBoundary>
          <SectionErrorBoundary label="appointment"><AppointmentSection /></SectionErrorBoundary>
          <SectionErrorBoundary label="news"><News /></SectionErrorBoundary>
          <SectionErrorBoundary label="contact"><Contact /></SectionErrorBoundary>
          <Footer />
        </>
      )}
    </div>
  );
}

import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { ArrowLeft, CalendarCheck, Stethoscope } from "lucide-react";
import Header from "../components/header/Header.jsx";
import Footer from "../components/Footer.jsx";
import { DoctorPhoto } from "../components/Doctors.jsx";
import { DepartmentIcon, DepartmentCover } from "../components/departments/DepartmentCard.jsx";
import { getDepartmentMeta } from "../components/departments/departmentMeta.js";
import { API_BASE } from "../utils/api.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useSiteSettings } from "../context/SettingsContext.jsx";
import { setPageSEO } from "../utils/seo.js";
import { saveBookingIntent } from "../utils/bookingIntent.js";
import "../components/doctors/Doctors.css";
import "../components/departments/Departments.css";

// صفحه‌ی جزئیات یک بخش — همان رکورد واقعی GET /api/departments/:id + داکتران همان بخش
// (GET /api/doctors). بخش غیرفعال یا «نمایش در سایت اصلی»=۰ در سایت عمومی «پیدا نشد» است.
export default function DepartmentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, dept, loc, docName, days, formatNumber } = useLanguage();
  const { settings } = useSiteSettings();
  const [department, setDepartment] = useState(null);
  const [doctors, setDoctors] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ok | not-found | error

  useEffect(() => {
    let cancelled = false;
    setStatus("loading");
    setDepartment(null);
    fetch(`${API_BASE}/departments/${encodeURIComponent(id)}`)
      .then((res) => {
        if (res.status === 404) return { notFound: true };
        if (!res.ok) throw new Error("bad response");
        return res.json();
      })
      .then((data) => {
        if (cancelled) return;
        const d = data?.department;
        const visible = d && d.status === "active" && Number(d.showOnWebsite) === 1;
        if (!visible) { setStatus("not-found"); return; }
        setDepartment(d);
        setStatus("ok");
      })
      .catch(() => { if (!cancelled) setStatus("error"); });
    fetch(`${API_BASE}/doctors`)
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error("bad response"))))
      .then((data) => { if (!cancelled) setDoctors(Array.isArray(data.doctors) ? data.doctors : []); })
      .catch(() => { if (!cancelled) setDoctors([]); });
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
    return () => { cancelled = true; };
  }, [id]);

  const name = department ? dept(department.name) : "";
  const description = department ? loc(department, "description") || t("services.defaultDescription") : "";

  useEffect(() => {
    if (!department) return undefined;
    return setPageSEO({
      title: `${department.seoTitle || name} | ${settings.hospitalName}`,
      description: (department.seoDescription || description).slice(0, 300),
      url: typeof window !== "undefined" ? window.location.href : undefined,
      type: "website",
    });
  }, [department, name, description, settings.hospitalName]);

  const meta = department ? getDepartmentMeta(department) : null;
  // «گرفتن وقت ملاقات»: مستقیم به فرم نوبت‌دهی صفحه‌ی اصلی، مرحله‌ی «انتخاب داکتر»، با همین بخش انتخاب‌شده
  function goBook(doctorId = null) {
    if (!department) return;
    saveBookingIntent({ department: department.name, doctorId });
    navigate("/home#appointment");
  }

  const deptDoctors = department ? doctors.filter((d) => d.department === department.name) : [];

  return (
    <div className="pub-page">
      <Header />
      <main className="dpt dpt-page dpt-detail">
        {status === "loading" && <p className="dpt-state dpt-state--page" role="status">{t("common.loading")}</p>}

        {(status === "not-found" || status === "error") && (
          <div className="container dpt-notfound" role={status === "error" ? "alert" : undefined}>
            <h1>{status === "error" ? t("departmentPage.loadError") : t("departmentPage.notFoundTitle")}</h1>
            {status === "not-found" && <p>{t("departmentPage.notFoundText")}</p>}
            <Link to="/departments" className="dpt-more-btn">
              <span>{t("departmentPage.back")}</span>
              <ArrowLeft className="dpt-arrow" size={18} aria-hidden="true" />
            </Link>
          </div>
        )}

        {status === "ok" && department && (
          <>
            <div className={`dpt-detail-hero dpt-accent-${meta.accent}`}>
              <DepartmentCover meta={meta} eager className="dpt-detail-cover" />
              <div className="container dpt-detail-hero-inner">
                <Link to="/departments" className="dpt-back">
                  <ArrowLeft className="dpt-arrow" size={16} aria-hidden="true" />
                  <span>{t("departmentPage.back")}</span>
                </Link>
                <div className="dpt-detail-title">
                  <span className="dpt-detail-icon" aria-hidden="true">
                    <DepartmentIcon department={department} fallbackName={meta.icon} size={34} />
                  </span>
                  <h1>{name}</h1>
                </div>
                <p className="dpt-detail-lead">{description}</p>
                <div className="dpt-detail-actions">
                  <button type="button" className="dpt-more-btn dpt-cta-btn" onClick={() => goBook()}>
                    <CalendarCheck size={18} aria-hidden="true" />
                    <span>{t("departmentPage.book")}</span>
                  </button>
                  {deptDoctors.length > 0 && (
                    <span className="dpt-chip">
                      <Stethoscope size={16} aria-hidden="true" />
                      {formatNumber(deptDoctors.length)} {t("services.statDoctors")}
                    </span>
                  )}
                </div>
              </div>
            </div>

            <div className={`container dpt-detail-body dpt-accent-${meta.accent}`}>
                {/* توضیح کوتاه همان‌جا در هیرو دیده می‌شود؛ پنل «درباره» فقط برای توضیح بلند می‌آید تا متن تکراری نشود */}
                {description.length > 160 && (
                  <section className="dpt-panel" aria-labelledby="dpt-about">
                    <h2 id="dpt-about">{t("departmentPage.about")}</h2>
                    <p className="dpt-about-text">{description}</p>
                  </section>
                )}

                <section aria-labelledby="dpt-doctors">
                  <h2 id="dpt-doctors" className="dpt-section-title">{t("departmentPage.doctorsTitle")}</h2>
                  {deptDoctors.length === 0 ? (
                    <p className="dpt-empty">{t("departmentPage.doctorsEmpty")}</p>
                  ) : (
                    <ul className="dpt-doctors">
                      {deptDoctors.map((d) => {
                        const years = d.yearsExperience != null ? d.yearsExperience : "-";
                        const workDays = d.workDays ? days(d.workDays) : t("doctors.defaultWorkDays");
                        return (
                          <li key={d.id} className="dr-card pub-card">
                            <div className="dr-photo"><DoctorPhoto doctor={d} /></div>
                            <div className="dr-body">
                              <h3>{docName(d.fullName)}</h3>
                              <span className="dr-role">{dept(d.department)}</span>
                              <ul className="dr-facts">
                                <li>{t("doctors.experience", { years })}</li>
                                <li>{t("doctors.workDays", { days: workDays })}</li>
                              </ul>
                              <button type="button" className="pub-btn pub-btn--primary pub-btn--block dr-book" onClick={() => goBook(d.id)}>
                                <CalendarCheck size={16} aria-hidden="true" />
                                {t("doctors.book")}
                              </button>
                            </div>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </section>

            </div>
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}

// نمایش داده می‌شود وقتی نقش کاربر (مثلاً ادمین/مدیر کل) باید احراز هویت دومرحله‌ای (MFA/TOTP) داشته باشد
// ولی هنوز فعال نکرده است. App.jsx تا زمانی که MFA فعال نشده کل رابط را با همین صفحه جایگزین می‌کند
// (و سرور هم هر مسیر دیگری را با کد MFA_SETUP_REQUIRED رد می‌کند، پس دور زدن رابط فایده‌ای ندارد).
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth, DASHBOARD_PATH } from "../context/AuthContext.jsx";
import { apiRequest } from "../utils/api.js";

export default function MfaSetupRequired() {
  const navigate = useNavigate();
  const { user, updateUser, logout } = useAuth();
  const [setup, setSetup] = useState(null); // { secret, otpauthUrl, qrDataUrl }
  const [code, setCode] = useState("");
  const [recoveryCodes, setRecoveryCodes] = useState(null);
  const [saved, setSaved] = useState(false);
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);

  const startedRef = useRef(false);
  useEffect(() => {
    if (startedRef.current) return; // StrictMode: effect دوبار اجرا می‌شود؛ فقط یک راز ساخته شود
    startedRef.current = true;
    apiRequest("/auth/mfa/setup", { method: "POST" })
      .then((data) => setSetup(data))
      .catch((err) => setStatus({ type: "error", text: err.message }));
  }, []);

  async function handleEnable(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });
    if (!/^\d{6}$/.test(code.trim())) {
      setStatus({ type: "error", text: "کد باید ۶ رقم باشد." });
      return;
    }
    setLoading(true);
    try {
      const data = await apiRequest("/auth/mfa/enable", { method: "POST", body: { code: code.trim() } });
      setRecoveryCodes(data.recoveryCodes || []);
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setLoading(false);
    }
  }

  function finish() {
    updateUser({ mfaEnabled: true, mfaSetupRequired: false });
    navigate(user ? DASHBOARD_PATH[user.role] || "/home" : "/home", { replace: true });
  }

  // مرحله‌ی دوم: کدهای بازیابی فقط همین یک‌بار نمایش داده می‌شوند
  if (recoveryCodes) {
    return (
      <div className="login-page pub-page">
        <div className="login-card pub-card" style={{ maxWidth: 480, margin: "60px auto" }}>
          <h2>کدهای بازیابی را نگه دارید</h2>
          <p className="field-hint" style={{ marginBottom: 12 }}>
            اگر دسترسی به برنامه‌ی احراز هویت را از دست بدهید، هر یک از این کدها فقط یک‌بار به‌جای
            کد ۶ رقمی کار می‌کند. آن‌ها را در جای امن (مثلاً مدیر رمز عبور) ذخیره کنید؛ دیگر نمایش داده نمی‌شوند.
          </p>
          <ul dir="ltr" data-testid="recovery-codes" style={{ columns: 2, fontFamily: "monospace", fontSize: 16, listStyle: "none", padding: 0 }}>
            {recoveryCodes.map((c) => <li key={c}>{c}</li>)}
          </ul>
          <button type="button" className="btn" onClick={() => navigator.clipboard?.writeText(recoveryCodes.join("\n"))}>کپی کدها</button>
          <label className="checkbox-row" style={{ margin: "14px 0" }}>
            <input type="checkbox" checked={saved} onChange={(e) => setSaved(e.target.checked)} />
            کدها را در جای امن ذخیره کردم
          </label>
          <button type="button" className="btn btn-primary" disabled={!saved} onClick={finish}>ادامه</button>
        </div>
      </div>
    );
  }

  return (
    <div className="login-page pub-page">
      <div className="login-card pub-card" style={{ maxWidth: 480, margin: "60px auto" }}>
        <h2>فعال‌سازی احراز هویت دومرحله‌ای</h2>
        <p className="field-hint" style={{ marginBottom: 12 }}>
          برای حساب شما (نقش مدیریتی) احراز هویت دومرحله‌ای الزامی است. یک برنامه‌ی احراز هویت
          (Google Authenticator، Microsoft Authenticator، Authy و ...) نصب کنید، کد QR را اسکن کنید و کد ۶ رقمی را وارد کنید.
        </p>
        {status.text && <div className={`form-message ${status.type}`}>{status.text}</div>}
        {setup && (
          <>
            {setup.qrDataUrl && (
              <img src={setup.qrDataUrl} alt="کد QR احراز هویت دومرحله‌ای" width={220} height={220} style={{ display: "block", margin: "0 auto 12px", background: "#fff", padding: 6, borderRadius: 8 }} />
            )}
            <p className="field-hint">یا این کلید را دستی وارد کنید:</p>
            <code dir="ltr" style={{ display: "block", wordBreak: "break-all", marginBottom: 14 }}>{setup.secret}</code>
            <form className="login-form" onSubmit={handleEnable} noValidate>
              <div className="field">
                <label>کد ۶ رقمی برنامه</label>
                <input
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  maxLength={6}
                  autoFocus
                  dir="ltr"
                  value={code}
                  onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
                />
              </div>
              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? "در حال بررسی..." : "فعال‌سازی"}
              </button>
            </form>
          </>
        )}
        <button type="button" className="btn" style={{ marginTop: 12 }} onClick={logout}>خروج از حساب</button>
      </div>
    </div>
  );
}

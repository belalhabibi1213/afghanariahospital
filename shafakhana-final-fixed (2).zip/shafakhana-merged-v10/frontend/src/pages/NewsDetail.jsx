import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import Header from "../components/header/Header.jsx";
import Footer from "../components/Footer.jsx";
import { formatDate, resolveNewsImage } from "../components/News.jsx";
import { apiRequest, resolvePhotoUrl } from "../utils/api.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useSiteSettings } from "../context/SettingsContext.jsx";
import { setPageSEO } from "../utils/seo.js";
import { sanitizeHtml } from "../utils/sanitizeHtml.js";

const HTML_TAG_REGEX = /<[a-z][\s\S]*>/i;
const COMMENT_MAX_LENGTH = 1000;

// آواتار حرفی نظرات، دقیقاً همان الگوی UserMenu.jsx/MobileMenu.jsx (بدون
// وابستگی جدید؛ چون نظرات فقط authorName دارند نه تصویر پروفایل)
function getInitials(fullName) {
  if (!fullName) return "؟";
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "؟";
  const first = parts[0][0] || "";
  const last = parts.length > 1 ? parts[parts.length - 1][0] : "";
  return (first + last).toUpperCase();
}

export default function NewsDetail() {
  const { dept, loc } = useLanguage();
  const { id } = useParams();
  const { isAuthenticated } = useAuth();
  const { settings } = useSiteSettings();
  const [article, setArticle] = useState(null);
  const [status, setStatus] = useState("loading");

  // ---------- لایک خبر ----------
  const [likesCount, setLikesCount] = useState(0);
  const [liked, setLiked] = useState(false);
  const [likeSubmitting, setLikeSubmitting] = useState(false);

  // ---------- نظرات خبر ----------
  const [comments, setComments] = useState([]);
  const [commentText, setCommentText] = useState("");
  const [commentRating, setCommentRating] = useState(0); // امتیاز اختیاری ۱ تا ۵ (۰ = بدون امتیاز)
  const [commentSubmitting, setCommentSubmitting] = useState(false);
  const [commentError, setCommentError] = useState("");
  const [commentNotice, setCommentNotice] = useState("");

  useEffect(() => {
    setStatus("loading");
    setArticle(null);
    setLikesCount(0);
    setLiked(false);
    setComments([]);
    setCommentText("");
    setCommentRating(0);
    setCommentError("");
    setCommentNotice("");

    // apiRequest به‌جای fetch خام استفاده می‌شود تا در صورت وجود توکن کاربر واردشده، هدر
    // نشست (کوکی) خودکار ارسال شود (لازم برای دریافت وضعیت «آیا خودم لایک کرده‌ام»).
    // «اخبار مرتبط» و «آخرین اخبار» هم مستقیماً در همین پاسخ می‌آیند (سبک، بدون content
    // کامل هر خبر) — دیگر نیازی به یک درخواست جداگانه برای کل فهرست اخبار نیست.
    apiRequest(`/news/${id}`)
      .then((data) => {
        setArticle(data.news);
        setLikesCount(data.news.likesCount || 0);
        setLiked(!!data.news.liked);
        setComments(Array.isArray(data.news.comments) ? data.news.comments : []);
        setStatus("ok");
      })
      .catch((err) => setStatus(err.status === 404 ? "not-found" : "error"));

    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }, [id]);

  // ---------- SEO: عنوان/توضیح/برچسب‌های Open Graph اختصاصیِ همین خبر ----------
  // برای اشتراک‌گذاری صحیح لینک خبر در شبکه‌های اجتماعی و نمایش بهتر در نتایج جست‌وجو.
  // با خروج از صفحه (تغییر خبر یا رفتن به مسیر دیگر)، مقادیر پیش‌فرض سایت بازگردانده می‌شوند.
  useEffect(() => {
    if (!article) return undefined;
    const plainExcerpt = (article.metaDescription || loc(article, "excerpt") || "").slice(0, 300);
    const cleanup = setPageSEO({
      title: `${article.metaTitle || loc(article, "title")} | ${settings.hospitalName}`,
      description: plainExcerpt,
      image: resolveNewsImage(article.imageUrl),
      url: typeof window !== "undefined" ? window.location.href : undefined,
      type: "article",
      structuredData: {
        "@context": "https://schema.org",
        "@type": "NewsArticle",
        headline: loc(article, "title"),
        description: plainExcerpt,
        datePublished: article.publishedAt,
        author: article.author ? { "@type": "Person", name: article.author } : undefined,
      },
    });
    return cleanup;
  }, [article, settings.hospitalName, loc]);

  async function handleToggleLike() {
    if (!isAuthenticated || likeSubmitting) return;
    setLikeSubmitting(true);
    // به‌روزرسانی خوش‌بینانه (Optimistic Update) برای حس واکنش سریع؛ در صورت خطا برگردانده می‌شود
    const previousLiked = liked;
    const previousCount = likesCount;
    setLiked(!previousLiked);
    setLikesCount(previousLiked ? previousCount - 1 : previousCount + 1);
    try {
      const data = await apiRequest(`/news/${id}/like`, { method: "POST" });
      setLiked(!!data.liked);
      setLikesCount(data.likesCount);
    } catch (err) {
      setLiked(previousLiked);
      setLikesCount(previousCount);
    } finally {
      setLikeSubmitting(false);
    }
  }

  async function handleSubmitComment(e) {
    e.preventDefault();
    setCommentError("");
    setCommentNotice("");
    const trimmed = commentText.trim();
    if (!trimmed) {
      setCommentError("متن نظر الزامی است");
      return;
    }
    setCommentSubmitting(true);
    try {
      await apiRequest(`/news/${id}/comments`, { method: "POST", body: { content: trimmed, ...(commentRating ? { rating: commentRating } : {}) } });
      setCommentText("");
      setCommentRating(0);
      setCommentNotice("نظر شما ثبت شد و پس از تایید ادمین نمایش داده خواهد شد.");
    } catch (err) {
      setCommentError(err.message || "ثبت نظر ناموفق بود");
    } finally {
      setCommentSubmitting(false);
    }
  }

  const imageSrc = article ? resolveNewsImage(article.imageUrl) : null;

  const relatedNews = useMemo(() => (Array.isArray(article?.related) ? article.related : []), [article]);
  const latestSidebarItems = useMemo(() => (Array.isArray(article?.latest) ? article.latest : []), [article]);

  const articleContent = article ? loc(article, "content") : "";
  const isRichContent = articleContent ? HTML_TAG_REGEX.test(articleContent) : false;

  return (
    <div className="pub-page">
      <Header />
      <section id="news-detail" style={{ paddingTop: 120, minHeight: "60vh" }}>
        <div className="container">
          {status === "loading" && <p style={{ textAlign: "center" }}>در حال بارگذاری خبر...</p>}

          {status === "not-found" && (
            <div className="section-head">
              <h2>خبر یافت نشد</h2>
              <p>این خبر ممکن است حذف شده یا هنوز منتشر نشده باشد.</p>
              <Link to="/home#news" className="pub-btn pub-btn--primary" style={{ marginTop: 16 }}>
                بازگشت به اخبار
              </Link>
            </div>
          )}

          {status === "error" && (
            <div className="section-head">
              <h2>خطا در بارگذاری خبر</h2>
              <p>اتصال به سرور برقرار نشد. مطمئن شوید بک‌اند اجرا است (npm run dev در پوشه backend).</p>
              <Link to="/home#news" className="pub-btn pub-btn--primary" style={{ marginTop: 16 }}>
                بازگشت به اخبار
              </Link>
            </div>
          )}

          {status === "ok" && article && (
            <div className="news-detail-layout">
              <article className="news-detail pub-card">
                {imageSrc && (
                  <div className="news-detail-thumb">
                    <img src={imageSrc} alt={loc(article, "title")} />
                    {article.isPinned && <span className="news-pin-badge">📌 خبر مهم</span>}
                  </div>
                )}
                <div className="news-detail-body">
                  <div className="news-meta">
                    <span className="news-tag">{dept(article.tag)}</span>
                    <span>{formatDate(article.publishedAt)}</span>
                    {article.author && <span>نویسنده: {article.author}</span>}
                    {typeof article.views === "number" && <span>👁 {article.views} بازدید</span>}
                  </div>
                  <h1>{loc(article, "title")}</h1>

                  <div className="news-like-row">
                    <button
                      type="button"
                      className={`news-like-btn ${liked ? "is-liked" : ""}`}
                      onClick={handleToggleLike}
                      disabled={!isAuthenticated || likeSubmitting}
                      title={isAuthenticated ? (liked ? "برداشتن لایک" : "لایک این خبر") : "برای لایک‌کردن وارد حساب کاربری شوید"}
                    >
                      <span aria-hidden="true">{liked ? "❤️" : "🤍"}</span>
                      <span>{likesCount} لایک</span>
                    </button>
                    {!isAuthenticated && (
                      <Link to="/login" className="news-like-login-hint">
                        برای لایک‌کردن وارد شوید
                      </Link>
                    )}
                  </div>

                  <p className="news-detail-excerpt">{loc(article, "excerpt")}</p>

                  {Array.isArray(article.tags) && article.tags.length > 0 && (
                    <div className="news-tags-list">
                      {article.tags.map((t) => (
                        <span className="news-tag-chip" key={t}>{t}</span>
                      ))}
                    </div>
                  )}

                  {articleContent && isRichContent && (
                    <div className="news-detail-content" dangerouslySetInnerHTML={{ __html: sanitizeHtml(articleContent) }} />
                  )}
                  {articleContent && !isRichContent && (
                    <div className="news-detail-content">
                      {articleContent.split(/\n+/).map((paragraph, idx) => (
                        <p key={idx}>{paragraph}</p>
                      ))}
                    </div>
                  )}

                  {Array.isArray(article.gallery) && article.gallery.length > 0 && (
                    <div className="news-detail-gallery">
                      <h4>گالری تصاویر</h4>
                      <div className="news-detail-gallery-grid">
                        {article.gallery.map((img) => (
                          <a
                            key={img.id}
                            href={resolvePhotoUrl(img.imageUrl) || img.imageUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="news-detail-gallery-item"
                          >
                            <img src={resolvePhotoUrl(img.imageUrl) || img.imageUrl} alt="گالری خبر" loading="lazy" />
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="news-comments-section">
                    <h4>نظرات ({comments.length})</h4>

                    {isAuthenticated ? (
                      <form className="news-comment-form" onSubmit={handleSubmitComment}>
                        <label htmlFor="news-comment-input">ثبت نظر</label>
                        <textarea
                          id="news-comment-input"
                          rows={4}
                          maxLength={COMMENT_MAX_LENGTH}
                          value={commentText}
                          onChange={(e) => setCommentText(e.target.value)}
                          placeholder="نظر خود را درباره‌ی این خبر بنویسید..."
                        />
                        <div className="news-comment-rating" role="radiogroup" aria-label="امتیاز (اختیاری)">
                          <span>امتیاز (اختیاری):</span>
                          {[1, 2, 3, 4, 5].map((n) => (
                            <button
                              key={n}
                              type="button"
                              role="radio"
                              aria-checked={commentRating === n}
                              aria-label={`${n} ستاره`}
                              className={n <= commentRating ? "is-on" : ""}
                              onClick={() => setCommentRating(commentRating === n ? 0 : n)}
                            >
                              ★
                            </button>
                          ))}
                        </div>
                        {commentError && <div className="form-message error">{commentError}</div>}
                        {commentNotice && <div className="form-message success">{commentNotice}</div>}
                        <div className="news-comment-form-actions">
                          <button className="pub-btn pub-btn--primary pub-btn--sm" type="submit" disabled={commentSubmitting}>
                            {commentSubmitting ? "در حال ارسال..." : "ارسال نظر"}
                          </button>
                        </div>
                        <p className="news-comment-note">نظرات پس از تایید ادمین نمایش داده می‌شوند.</p>
                      </form>
                    ) : (
                      <p className="news-comments-empty">
                        برای ثبت نظر، لطفاً <Link to="/login">وارد حساب کاربری</Link> شوید.
                      </p>
                    )}

                    {comments.length > 0 ? (
                      <div className="news-comments-list-wrap">
                        <h5 className="news-comments-subhead">نظرات کاربران</h5>
                        <ul className="news-comments-list">
                          {comments.map((c) => (
                            <li key={c.id} className="news-comment-item">
                              <div className="news-comment-head">
                                <span className="user-avatar news-comment-avatar" aria-hidden="true">
                                  {getInitials(c.authorName)}
                                </span>
                                <div className="news-comment-headtext">
                                  <span className="news-comment-author">{c.authorName}</span>
                                  <span className="news-comment-date">{formatDate(c.createdAt)}</span>
                                </div>
                              </div>
                              <p className="news-comment-text">{c.content}</p>
                              {c.adminReply && (
                                <div className="news-comment-reply">
                                  <div className="news-comment-reply-head">
                                    <strong>پاسخ مدیریت شفاخانه</strong>
                                    {c.adminReplyAt && <span className="news-comment-date">{formatDate(c.adminReplyAt)}</span>}
                                  </div>
                                  <p className="news-comment-text">{c.adminReply}</p>
                                </div>
                              )}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ) : (
                      <p className="news-comments-empty">هنوز نظری برای این خبر ثبت نشده است.</p>
                    )}
                  </div>

                  <Link to="/home#news" className="pub-btn pub-btn--ghost" style={{ marginTop: 24 }}>
                    ← بازگشت به اخبار
                  </Link>
                </div>
              </article>

              <aside className="news-aside">
                {latestSidebarItems.length > 0 && (
                  <div className="news-aside-block pub-card">
                    <h4>آخرین اخبار</h4>
                    <ul className="news-latest-list">
                      {latestSidebarItems.map((a) => (
                        <li key={a.id}>
                          <Link to={`/news/${a.id}`} className="news-latest-item">
                            <img src={resolveNewsImage(a.imageUrl)} alt={loc(a, "title")} loading="lazy" />
                            <span>
                              <span className="news-latest-title">{loc(a, "title")}</span>
                              <span className="news-latest-date">{formatDate(a.publishedAt)}</span>
                            </span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </aside>

              {relatedNews.length > 0 && (
                <div className="news-related">
                  <h4>اخبار مرتبط</h4>
                  <div className="news-grid">
                    {relatedNews.map((a) => (
                      <article className="news-card pub-card" key={a.id}>
                        <div className="news-thumb">
                          <img src={resolveNewsImage(a.imageUrl)} alt={loc(a, "title")} loading="lazy" />
                        </div>
                        <div className="news-body">
                          <div className="news-meta">
                            <span className="news-tag">{dept(a.tag)}</span>
                            <span>{formatDate(a.publishedAt)}</span>
                          </div>
                          <h3>{loc(a, "title")}</h3>
                          <p>{a.excerpt}</p>
                          <Link to={`/news/${a.id}`} className="news-link">ادامه مطلب ←</Link>
                        </div>
                      </article>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </section>
      <Footer />
    </div>
  );
}

import { Link } from "react-router-dom";
import { useSiteSettings } from "../context/SettingsContext.jsx";

// وقتی Super Admin «حالت تعمیرات» را از تنظیمات سیستم روشن کند، این صفحه به‌جای
// کل سایت به بازدیدکنندگان عادی نمایش داده می‌شود. مدیر کل و ادمین از این محدودیت
// مستثنا هستند (نگاه کنید به بررسی نقش در App.jsx) تا بتوانند سایت را ببینند و
// دوباره حالت تعمیرات را خاموش کنند. لینک ورود همیشه در دسترس می‌ماند.
export default function Maintenance() {
  const { settings } = useSiteSettings();

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        padding: 24,
        gap: 16,
        background: "#0f2b2e",
        color: "#fff",
      }}
    >
      <span style={{ fontSize: 48 }}>🛠️</span>
      <h1 style={{ margin: 0 }}>{settings.hospitalName} موقتاً در حال تعمیر است</h1>
      <p style={{ opacity: 0.85, maxWidth: 480 }}>
        سایت در حال حاضر برای انجام برخی به‌روزرسانی‌ها در دسترس نیست. لطفاً کمی بعد دوباره سر بزنید.
      </p>
      <Link to="/login" className="btn btn-ghost" style={{ marginTop: 8 }}>
        ورود کارمندان
      </Link>
    </div>
  );
}

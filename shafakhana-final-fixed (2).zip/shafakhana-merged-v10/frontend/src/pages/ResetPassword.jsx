import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { API_BASE } from "../utils/api.js";
import { getPasswordError, PASSWORD_HINT_FA } from "../utils/passwordPolicy.js";

const RESET_URL = `${API_BASE}/auth/reset-password`;
const FORGOT_URL = `${API_BASE}/auth/forgot-password`;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const RESEND_COOLDOWN_SECONDS = 60;

export default function ResetPassword() {
  const navigate = useNavigate();
  const location = useLocation();
  const [email, setEmail] = useState(location.state?.email || "");
  const [code, setCode] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fieldErrors, setFieldErrors] = useState({});
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);

  const [resendStatus, setResendStatus] = useState({ type: "", text: "" });
  const [resendLoading, setResendLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (cooldown <= 0) return undefined;
    const timer = setInterval(() => setCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    const errs = {};
    if (!email.trim() || !EMAIL_REGEX.test(email.trim())) {
      errs.email = "لطفاً یک ایمیل معتبر وارد کنید.";
    }
    if (!/^\d{6}$/.test(code)) {
      errs.code = "کد بازیابی باید ۶ رقم باشد.";
    }
    const passwordError = getPasswordError(newPassword);
    if (passwordError) {
      errs.newPassword = passwordError;
    }
    if (newPassword !== confirmPassword) {
      errs.confirmPassword = "رمز عبور جدید و تکرار آن یکسان نیست.";
    }

    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) {
      setStatus({ type: "error", text: "لطفاً خطاهای فرم را برطرف کنید." });
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(RESET_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), code, newPassword }),
      });
      const data = await res.json();

      if (!res.ok) {
        setStatus({ type: "error", text: data.message || "بازیابی رمز عبور ناموفق بود." });
        setLoading(false);
        return;
      }

      setStatus({
        type: "success",
        text: data.message || "رمز عبور شما با موفقیت تغییر کرد. در حال انتقال به صفحه ورود...",
      });
      setTimeout(() => navigate("/login"), 1200);
    } catch (err) {
      setStatus({
        type: "error",
        text: "اتصال به سرور برقرار نشد. مطمئن شوید بک‌اند اجرا است (npm run dev در پوشه backend).",
      });
    } finally {
      setLoading(false);
    }
  }

  async function handleResend() {
    setResendStatus({ type: "", text: "" });

    if (!email.trim() || !EMAIL_REGEX.test(email.trim())) {
      setResendStatus({ type: "error", text: "لطفاً ابتدا یک ایمیل معتبر وارد کنید." });
      return;
    }

    setResendLoading(true);
    try {
      const res = await fetch(FORGOT_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();

      if (!res.ok) {
        setResendStatus({ type: "error", text: data.message || "ارسال مجدد کد ناموفق بود." });
        return;
      }

      setResendStatus({ type: "success", text: "کد بازیابی جدید ارسال شد." });
      setCooldown(RESEND_COOLDOWN_SECONDS);
    } catch (err) {
      setResendStatus({
        type: "error",
        text: "اتصال به سرور برقرار نشد. مطمئن شوید بک‌اند اجرا است (npm run dev در پوشه backend).",
      });
    } finally {
      setResendLoading(false);
    }
  }

  return (
    <div className="login-page pub-page">
      <Link to="/home" className="back-home">→ بازگشت به سایت</Link>

      <div className="login-card pub-card">
        <div className="login-head">
          <div className="brand-mark" style={{ width: 46, height: 46, fontSize: 20, borderRadius: 14 }}>🔒</div>
          <h1>بازیابی رمز عبور</h1>
          <p>کد ۶ رقمی ارسال‌شده به ایمیل خود و رمز عبور جدید را وارد کنید</p>
        </div>

        <form className="login-form" onSubmit={handleSubmit} noValidate>
          {status.text && (
            <div className={`form-message ${status.type}`}>{status.text}</div>
          )}

          <div className="field">
            <label>ایمیل</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (fieldErrors.email) setFieldErrors((f) => ({ ...f, email: "" }));
              }}
              autoComplete="email"
            />
            {fieldErrors.email && <span className="field-error">{fieldErrors.email}</span>}
          </div>

          <div className="field">
            <label>کد بازیابی</label>
            <input
              type="text"
              inputMode="numeric"
              className="otp-input"
              placeholder="------"
              maxLength={6}
              value={code}
              onChange={(e) => {
                setCode(e.target.value.replace(/\D/g, "").slice(0, 6));
                if (fieldErrors.code) setFieldErrors((f) => ({ ...f, code: "" }));
              }}
              autoComplete="one-time-code"
            />
            {fieldErrors.code && <span className="field-error">{fieldErrors.code}</span>}
          </div>

          <div className="field">
            <label>رمز عبور جدید</label>
            <input
              type="password"
              placeholder="••••••••"
              value={newPassword}
              onChange={(e) => {
                setNewPassword(e.target.value);
                if (fieldErrors.newPassword) setFieldErrors((f) => ({ ...f, newPassword: "" }));
              }}
              autoComplete="new-password"
            />
            <span className="field-hint">{PASSWORD_HINT_FA}</span>
            {fieldErrors.newPassword && <span className="field-error">{fieldErrors.newPassword}</span>}
          </div>

          <div className="field">
            <label>تکرار رمز عبور جدید</label>
            <input
              type="password"
              placeholder="••••••••"
              value={confirmPassword}
              onChange={(e) => {
                setConfirmPassword(e.target.value);
                if (fieldErrors.confirmPassword) setFieldErrors((f) => ({ ...f, confirmPassword: "" }));
              }}
              autoComplete="new-password"
            />
            {fieldErrors.confirmPassword && <span className="field-error">{fieldErrors.confirmPassword}</span>}
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? "در حال ثبت..." : "تغییر رمز عبور"}
          </button>
        </form>

        <div className="resend-row" style={{ marginTop: 18 }}>
          {resendStatus.text ? (
            <span style={{ color: resendStatus.type === "error" ? "var(--warm)" : "var(--pulse)" }}>
              {resendStatus.text}
            </span>
          ) : (
            <span>کدی دریافت نکردید؟</span>
          )}
          <button
            type="button"
            className="resend-btn"
            onClick={handleResend}
            disabled={resendLoading || cooldown > 0}
          >
            {cooldown > 0
              ? `ارسال مجدد (${cooldown} ثانیه)`
              : resendLoading
              ? "در حال ارسال..."
              : "ارسال مجدد کد"}
          </button>
        </div>

        <p className="login-footer-text">
          <Link to="/login">بازگشت به صفحه ورود</Link>
        </p>
      </div>
    </div>
  );
}

// این صفحه وقتی نمایش داده می‌شود که کاربر با یک رمز عبور موقت وارد شده باشد — یا حساب‌های
// پیش‌فرض تازه‌ساز (Super Admin/Admin/کاربر آزمایشی که در اولین راه‌اندازی دیتابیس با یک رمز
// تصادفی ساخته می‌شوند)، یا هر حسابی که ادمین برایش رمز موقت ساخته (بازنشانی رمز عبور بیمار).
// App.jsx کاربر را هر بار (بعد از ورود و بعد از هر رفرش صفحه، تا وقتی رمز عوض نشده) به همین‌جا
// هدایت می‌کند؛ بعد از تغییر موفق، به داشبورد خودش برمی‌گردد.
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth, DASHBOARD_PATH } from "../context/AuthContext.jsx";
import { apiRequest } from "../utils/api.js";
import { getPasswordError, PASSWORD_HINT_FA } from "../utils/passwordPolicy.js";

export default function ChangePasswordRequired() {
  const navigate = useNavigate();
  const { user, updateUser, logout } = useAuth();
  const [form, setForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    const passwordError = getPasswordError(form.newPassword);
    if (passwordError) {
      setStatus({ type: "error", text: passwordError });
      return;
    }
    if (form.newPassword !== form.confirm) {
      setStatus({ type: "error", text: "رمز عبور جدید و تکرار آن یکسان نیست." });
      return;
    }

    setLoading(true);
    try {
      await apiRequest("/users/change-password", {
        method: "PUT",
        body: { currentPassword: form.currentPassword, newPassword: form.newPassword },
      });
      updateUser({ mustChangePassword: false });
      navigate(user ? DASHBOARD_PATH[user.role] || "/home" : "/home", { replace: true });
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page pub-page">
      <div className="login-card pub-card" style={{ maxWidth: 460, margin: "60px auto" }}>
        <h2>لازم است رمز عبور خود را تغییر دهید</h2>
        <p className="field-hint" style={{ marginBottom: 16 }}>
          حساب شما با یک رمز عبور موقت ساخته شده است. برای ادامه، ابتدا باید همان رمز موقت را
          وارد کنید و یک رمز عبور تازه برای خودتان تعیین کنید.
        </p>
        <form className="login-form" onSubmit={handleSubmit}>
          {status.text && <div className={`form-message ${status.type}`}>{status.text}</div>}
          <div className="field">
            <label>رمز عبور موقت (فعلی)</label>
            <input
              type="password"
              autoFocus
              value={form.currentPassword}
              onChange={(e) => setForm((f) => ({ ...f, currentPassword: e.target.value }))}
            />
          </div>
          <div className="field">
            <label>رمز عبور جدید</label>
            <input
              type="password"
              value={form.newPassword}
              onChange={(e) => setForm((f) => ({ ...f, newPassword: e.target.value }))}
            />
            <span className="field-hint">{PASSWORD_HINT_FA}</span>
          </div>
          <div className="field">
            <label>تکرار رمز عبور جدید</label>
            <input
              type="password"
              value={form.confirm}
              onChange={(e) => setForm((f) => ({ ...f, confirm: e.target.value }))}
            />
          </div>
          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? "در حال ذخیره..." : "تغییر رمز عبور و ادامه"}
          </button>
        </form>
        <button type="button" className="btn btn-ghost btn-sm" style={{ marginTop: 12 }} onClick={logout}>
          خروج از حساب
        </button>
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth, resolvePostLoginRedirect } from "../context/AuthContext.jsx";
import { API_BASE, authFetch } from "../utils/api.js";

const VERIFY_URL = `${API_BASE}/auth/verify-email`;
const RESEND_URL = `${API_BASE}/auth/resend-verification`;
const RESEND_COOLDOWN_SECONDS = 60;

export default function VerifyEmail() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const [email, setEmail] = useState(location.state?.email || "");
  const [code, setCode] = useState("");
  const [status, setStatus] = useState({ type: "", text: "" });
  const [resendStatus, setResendStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);

  useEffect(() => {
    if (location.state?.notice) {
      setStatus({ type: location.state.noticeType || "success", text: location.state.notice });
    }
  }, [location.state]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const timer = setInterval(() => setCooldown((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(timer);
  }, [cooldown]);

  async function handleVerify(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setStatus({ type: "error", text: "لطفاً یک ایمیل معتبر وارد کنید." });
      return;
    }
    if (!/^\d{6}$/.test(code)) {
      setStatus({ type: "error", text: "کد تایید باید ۶ رقم باشد." });
      return;
    }

    setLoading(true);
    try {
      const res = await authFetch(VERIFY_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, code }),
      });
      const data = await res.json();

      if (!res.ok) {
        setStatus({ type: "error", text: data.message || "تایید ایمیل ناموفق بود." });
        return;
      }

      setStatus({ type: "success", text: "ایمیل شما تایید شد! در حال انتقال..." });
      login(data.user, data.csrfToken);
      // مطابق با رفتار صفحه ورود: بعد از تایید ایمیل هم کاربر به صفحه اصلی سایت
      // هدایت می‌شود، نه مستقیم به داشبورد — مگر اینکه ثبت‌نام از یک بخش خاص
      // (مثلاً نوبت‌دهی، از طریق state.from) شروع شده باشد که به همان‌جا بازمی‌گردد؛
      // آن‌هم فقط اگر نقش همین کاربر واقعاً به آن مسیر دسترسی داشته باشد.
      const redirectTo = resolvePostLoginRedirect(location.state?.from, data.user);
      setTimeout(() => navigate(redirectTo), 900);
    } catch (err) {
      setStatus({
        type: "error",
        text: "اتصال به سرور برقرار نشد. مطمئن شوید بک‌اند اجرا است (npm run dev در پوشه backend).",
      });
    } finally {
      setLoading(false);
    }
  }

  async function handleResend() {
    setResendStatus({ type: "", text: "" });

    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setResendStatus({ type: "error", text: "لطفاً ابتدا یک ایمیل معتبر وارد کنید." });
      return;
    }

    setResendLoading(true);
    try {
      const res = await fetch(RESEND_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();

      if (!res.ok) {
        setResendStatus({ type: "error", text: data.message || "ارسال مجدد کد ناموفق بود." });
        return;
      }

      if (data.emailDelivered === false) {
        setResendStatus({
          type: "error",
          text: "کد صادر شد اما ارسال ایمیل با مشکل مواجه شد. لطفاً بعداً دوباره تلاش کنید یا با پشتیبانی تماس بگیرید.",
        });
      } else {
        setResendStatus({ type: "success", text: "کد تایید جدید ارسال شد." });
      }
      setCooldown(RESEND_COOLDOWN_SECONDS);
    } catch (err) {
      setResendStatus({
        type: "error",
        text: "اتصال به سرور برقرار نشد. مطمئن شوید بک‌اند اجرا است (npm run dev در پوشه backend).",
      });
    } finally {
      setResendLoading(false);
    }
  }

  return (
    <div className="login-page pub-page">
      <Link to="/home" className="back-home">→ بازگشت به سایت</Link>

      <div className="login-card pub-card">
        <div className="login-head">
          <div className="brand-mark" style={{ width: 46, height: 46, fontSize: 20, borderRadius: 14 }}>✉️</div>
          <h1>تایید ایمیل</h1>
          <p>کد ۶ رقمی ارسال‌شده به ایمیل خود را وارد کنید</p>
        </div>

        <form className="login-form" onSubmit={handleVerify}>
          {status.text && (
            <div className={`form-message ${status.type}`}>{status.text}</div>
          )}

          <div className="field">
            <label>ایمیل</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
            />
          </div>

          <div className="field">
            <label>کد تایید</label>
            <input
              type="text"
              inputMode="numeric"
              className="otp-input"
              placeholder="------"
              maxLength={6}
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
              autoComplete="one-time-code"
            />
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? "در حال بررسی..." : "تایید کد"}
          </button>
        </form>

        <div className="resend-row" style={{ marginTop: 18 }}>
          {resendStatus.text ? (
            <span style={{ color: resendStatus.type === "error" ? "var(--warm)" : "var(--pulse)" }}>
              {resendStatus.text}
            </span>
          ) : (
            <span>کدی دریافت نکردید؟</span>
          )}
          <button
            type="button"
            className="resend-btn"
            onClick={handleResend}
            disabled={resendLoading || cooldown > 0}
          >
            {cooldown > 0
              ? `ارسال مجدد (${cooldown} ثانیه)`
              : resendLoading
              ? "در حال ارسال..."
              : "ارسال مجدد کد"}
          </button>
        </div>

        <p className="login-footer-text">
          <Link to="/login">بازگشت به صفحه ورود</Link>
        </p>
      </div>
    </div>
  );
}

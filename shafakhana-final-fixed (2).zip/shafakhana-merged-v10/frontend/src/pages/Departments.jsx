import { useEffect } from "react";
import Header from "../components/header/Header.jsx";
import Footer from "../components/Footer.jsx";
import { DepartmentsHero, DepartmentsFeatures, DepartmentsGrid } from "../components/Services.jsx";
import useDepartments from "../components/departments/useDepartments.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useSiteSettings } from "../context/SettingsContext.jsx";
import { setPageSEO } from "../utils/seo.js";
import "../components/departments/Departments.css";

// صفحه‌ی «همه بخش‌ها» — همان داده‌ی واقعی و همان کارت‌های صفحه‌ی اصلی، بدون محدودیت تعداد
export default function DepartmentsPage() {
  const { t } = useLanguage();
  const { settings } = useSiteSettings();
  const { departments, status } = useDepartments();

  useEffect(() => setPageSEO({
    title: `${t("services.title")} | ${settings.hospitalName}`,
    description: t("services.subtitle"),
    url: typeof window !== "undefined" ? window.location.href : undefined,
    type: "website",
  }), [t, settings.hospitalName]);

  return (
    <div className="pub-page">
      <Header />
      <main className="dpt dpt-page" aria-labelledby="dpt-title">
        <DepartmentsHero headingTag="h1" departmentCount={status === "ok" ? departments.length : 0} />
        <div className="container dpt-main">
          <DepartmentsGrid departments={departments} status={status} />
          <DepartmentsFeatures />
        </div>
      </main>
      <Footer />
    </div>
  );
}

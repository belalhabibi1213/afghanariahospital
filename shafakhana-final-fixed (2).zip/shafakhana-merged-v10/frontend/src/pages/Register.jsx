import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { API_BASE } from "../utils/api.js";
import { getPasswordError, PASSWORD_POLICY_MESSAGE } from "../utils/passwordPolicy.js";
import { isValidPersianName } from "../utils/persianName.js";
import { getEmailError, EMAIL_INVALID_MESSAGE } from "../utils/emailValidation.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import LanguageSwitcher from "../components/LanguageSwitcher.jsx";
import PasswordInput from "../components/PasswordInput.jsx";

const API_URL = `${API_BASE}/auth/register`;

export default function Register() {
  const navigate = useNavigate();
  const location = useLocation();
  const { t, tm } = useLanguage();
  const [form, setForm] = useState({ fullName: "", email: "", password: "", confirm: "" });
  const [fieldErrors, setFieldErrors] = useState({});
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
    if (fieldErrors[field]) {
      setFieldErrors((errs) => ({ ...errs, [field]: "" }));
    }
  }

  function validate() {
    const errs = {};
    if (!form.fullName.trim()) {
      errs.fullName = t("register.fullNameRequired");
    } else if (!isValidPersianName(form.fullName)) {
      errs.fullName = t("validation.nameInvalid");
    }
    if (!form.email.trim()) {
      errs.email = t("register.emailRequired");
    } else {
      const emailError = getEmailError(form.email);
      if (emailError) errs.email = emailError === EMAIL_INVALID_MESSAGE ? t("validation.emailInvalid") : tm(emailError);
    }
    const passwordError = getPasswordError(form.password);
    if (passwordError) errs.password = passwordError === PASSWORD_POLICY_MESSAGE ? t("validation.passwordPolicy") : passwordError === "رمز عبور الزامی است." ? t("login.passwordRequired") : passwordError;
    if (form.password !== form.confirm) errs.confirm = t("register.mismatch");
    return errs;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    const errs = validate();
    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) {
      setStatus({ type: "error", text: t("common.fixFormErrors") });
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fullName: form.fullName,
          email: form.email,
          password: form.password,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        // اگر پیام خطای بک‌اند دقیقاً همان پیام نامعتبر بودن فرمت ایمیل باشد (مرجع نهایی
        // اعتبارسنجی سمت سرور رد کرده، مثلاً درخواستی که از مسیر فرم رد نشده)، علاوه بر
        // پیام کلی بالای فرم، کاربر روی فیلد ایمیل هم نگه داشته می‌شود تا آن را اصلاح کند
        if (data.message === EMAIL_INVALID_MESSAGE) {
          setFieldErrors((errs) => ({ ...errs, email: t("validation.emailInvalid") }));
        }
        setStatus({ type: "error", text: tm(data.message) || t("register.failed") });
        return;
      }

      // اگر ارسال ایمیل واقعاً ناموفق بوده (مثلاً SMTP در بک‌اند تنظیم نشده یا App
      // Password اشتباه است)، به‌جای پیام موفقیت‌آمیز گمراه‌کننده، به کاربر هشدار
      // داده می‌شود که ایمیل نرسیده و باید «ارسال مجدد کد» را امتحان کند یا با پشتیبانی تماس بگیرد.
      const notice =
        data.emailDelivered === false
          ? t("register.emailNotDelivered")
          : tm(data.message) || t("register.codeSent");

      navigate("/verify-email", {
        state: {
          email: data.email || form.email,
          notice,
          noticeType: data.emailDelivered === false ? "error" : "success",
          // اگر ثبت‌نام از مسیر «ورود الزامی است» (مثلاً نوبت‌دهی) شروع شده بود، همان
          // مقصد را تا مرحله تایید ایمیل هم منتقل می‌کنیم تا در پایان به آن بازگردیم.
          from: location.state?.from,
        },
      });
    } catch (err) {
      setStatus({
        type: "error",
        text: t("common.serverUnreachable"),
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page pub-page">
      <Link to="/home" className="back-home">{t("common.backToSite")}</Link>
      <LanguageSwitcher className="lang-switcher-corner" />

      <div className="login-card pub-card">
        <div className="login-head">
          <div className="brand-mark" style={{ width: 46, height: 46, fontSize: 20, borderRadius: 14 }}>✚</div>
          <h1>{t("register.title")}</h1>
          <p>{t("register.subtitle")}</p>
        </div>

        <form className="login-form" onSubmit={handleSubmit} noValidate>
          {status.text && (
            <div className={`form-message ${status.type}`}>{status.text}</div>
          )}

          <div className="field">
            <label>{t("register.fullName")}</label>
            <input
              type="text"
              placeholder={t("register.fullNamePlaceholder")}
              value={form.fullName}
              onChange={(e) => update("fullName", e.target.value)}
              autoComplete="name"
            />
            {fieldErrors.fullName && <span className="field-error">{fieldErrors.fullName}</span>}
          </div>

          <div className="field">
            <label>{t("register.email")}</label>
            <input
              type="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              autoComplete="email"
            />
            {fieldErrors.email && <span className="field-error">{fieldErrors.email}</span>}
          </div>

          <div className="field">
            <label>{t("register.password")}</label>
            <PasswordInput
              placeholder={t("register.passwordPlaceholder")}
              value={form.password}
              onChange={(e) => update("password", e.target.value)}
              autoComplete="new-password"
            />
            {fieldErrors.password && <span className="field-error">{fieldErrors.password}</span>}
          </div>

          <div className="field">
            <label>{t("register.confirm")}</label>
            <PasswordInput
              placeholder="••••••••"
              value={form.confirm}
              onChange={(e) => update("confirm", e.target.value)}
              autoComplete="new-password"
            />
            {fieldErrors.confirm && <span className="field-error">{fieldErrors.confirm}</span>}
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? t("register.submitting") : t("register.submit")}
          </button>
        </form>

        <p className="login-footer-text">
          {t("register.haveAccount")} <Link to="/login">{t("register.loginLink")}</Link>
        </p>
      </div>
    </div>
  );
}

import { useEffect, useMemo, useState } from "react";
import {
  Activity, AlertTriangle, Check, Globe, History, LogOut, Monitor, MonitorSmartphone, RefreshCw,
  Search, ShieldAlert, Smartphone, Tablet, UserCheck, Users, X,
} from "lucide-react";
import { apiRequest } from "../../../../utils/api.js";
import { useAuth } from "../../../../context/AuthContext.jsx";
import GlobalModal from "../../../../components/GlobalModal.jsx";
import { ROLE_LABEL_FA } from "../shared.js";
import "./SessionsDevices.css";

const INACTIVE_SESSION_STATUS_FA = {
  logged_out: "خروج توسط کاربر",
  ended_by_admin: "خاتمه توسط مدیر کل",
  expired: "منقضی‌شده",
};
const STATUS_TONE = { logged_out: "info", ended_by_admin: "danger", expired: "warn" };
const ROLE_TONE = { user: "info", doctor: "ok", admin: "warn", superadmin: "violet" };
const PAGE_SIZE = 50;
const TERMINATE_BLOCKED_HINT = "برای خاتمه‌دادن نشست جاری خودتان از دکمه‌ی خروج در منوی کاربری استفاده کنید";

// منطق محاسبه‌ی مدت نشست عیناً مثل قبل است
function formatSessionDuration(durationMs) {
  if (durationMs === null || durationMs === undefined || Number.isNaN(durationMs)) return "-";
  const totalMinutes = Math.floor(durationMs / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours > 0) return `${hours} ساعت و ${minutes} دقیقه`;
  if (minutes > 0) return `${minutes} دقیقه`;
  return "کمتر از ۱ دقیقه";
}

// فقط نمایش: ارقام لاتین خروجی تابع بالا به ارقام فارسی تبدیل می‌شود
function faDigits(text) {
  return String(text).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[d]);
}
function toFa(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString("fa-IR-u-ca-persian", { useGrouping: false }) : "—";
}

function toDate(value) {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}
function fmtDate(value) {
  const d = toDate(value);
  return d ? d.toLocaleDateString("fa-IR-u-ca-persian", { year: "numeric", month: "2-digit", day: "2-digit" }) : "—";
}
function fmtTime(value) {
  const d = toDate(value);
  return d ? d.toLocaleTimeString("fa-IR-u-ca-persian", { hour: "2-digit", minute: "2-digit" }) : "";
}
function fmtDateTime(value) {
  const d = toDate(value);
  return d ? d.toLocaleString("fa-IR-u-ca-persian") : "—";
}

const rtf = new Intl.RelativeTimeFormat("fa", { numeric: "auto" });
// فقط از lastActivityAt واقعی محاسبه می‌شود؛ اختلاف منفی (ساعت کلاینت جلوتر از سرور) «هم‌اکنون» نمایش داده می‌شود
function relativeTime(value, now) {
  const d = toDate(value);
  if (!d) return "—";
  const sec = Math.round((d.getTime() - now) / 1000);
  const abs = Math.abs(sec);
  if (sec >= 0 || abs < 60) return "هم‌اکنون";
  if (abs < 3600) return rtf.format(Math.round(sec / 60), "minute");
  if (abs < 86400) return rtf.format(Math.round(sec / 3600), "hour");
  if (abs < 86400 * 30) return rtf.format(Math.round(sec / 86400), "day");
  if (abs < 86400 * 365) return rtf.format(Math.round(sec / (86400 * 30)), "month");
  return rtf.format(Math.round(sec / (86400 * 365)), "year");
}

// تشخیص ساده‌ی مرورگر/سیستم‌عامل فقط از متن واقعی userAgent (بدون Library). اگر تشخیص ممکن نبود
// null برمی‌گرداند تا همان متن واقعی (کوتاه‌شده) نمایش داده شود.
function parseUserAgent(ua) {
  if (!ua) return null;
  let browser = null;
  if (/Edg(e|A|iOS)?\//.test(ua)) browser = "Edge";
  else if (/OPR\/|Opera/.test(ua)) browser = "Opera";
  else if (/SamsungBrowser/.test(ua)) browser = "Samsung Internet";
  else if (/Firefox\/|FxiOS/.test(ua)) browser = "Firefox";
  else if (/Chrome\/|CriOS/.test(ua)) browser = "Chrome";
  else if (/Safari\//.test(ua) && /Version\//.test(ua)) browser = "Safari";
  else if (/MSIE |Trident\//.test(ua)) browser = "Internet Explorer";

  let os = null;
  let kind = "desktop";
  if (/Windows/.test(ua)) os = "Windows";
  else if (/Android/.test(ua)) { os = "Android"; kind = /Mobile/.test(ua) ? "mobile" : "tablet"; }
  else if (/iPhone|iPod/.test(ua)) { os = "iOS"; kind = "mobile"; }
  else if (/iPad/.test(ua)) { os = "iPadOS"; kind = "tablet"; }
  else if (/Mac OS X|Macintosh/.test(ua)) os = "macOS";
  else if (/CrOS/.test(ua)) os = "ChromeOS";
  else if (/Linux|X11/.test(ua)) os = "Linux";

  if (!browser && !os) return null;
  return { label: [browser, os].filter(Boolean).join(" · "), kind };
}

function DeviceIcon({ kind, size = 16 }) {
  if (kind === "mobile") return <Smartphone size={size} aria-hidden="true" />;
  if (kind === "tablet") return <Tablet size={size} aria-hidden="true" />;
  if (kind === "desktop") return <Monitor size={size} aria-hidden="true" />;
  return <Globe size={size} aria-hidden="true" />;
}

function DeviceCell({ userAgent }) {
  const parsed = parseUserAgent(userAgent);
  if (!userAgent) return <span className="sd-muted">—</span>;
  return (
    <div className="sd-device" title={userAgent}>
      <DeviceIcon kind={parsed ? parsed.kind : "unknown"} />
      <span className={`sd-device-text ${parsed ? "" : "is-raw sd-mono"}`}>{parsed ? parsed.label : userAgent}</span>
    </div>
  );
}

function deviceLabel(userAgent) {
  const parsed = parseUserAgent(userAgent);
  if (parsed) return parsed.label;
  return userAgent ? String(userAgent).slice(0, 120) : "—";
}

function initials(name) {
  const words = String(name || "").trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return "؟";
  return words.length > 1 ? `${[...words[0]][0]}${[...words[1]][0]}` : [...words[0]][0];
}

function UserCell({ s }) {
  return (
    <div className="sd-user">
      <span className={`sd-avatar role-${s.role}`} aria-hidden="true">{initials(s.userName)}</span>
      <div className="sd-user-text">
        <span className="sd-user-name" title={s.userName || ""}>{s.userName || "کاربر ناشناس"}</span>
        {s.isCurrent && <span className="sd-chip sd-chip-violet" style={{ width: "fit-content" }}>نشست جاری شما</span>}
      </div>
    </div>
  );
}

function RoleBadge({ role }) {
  return <span className={`sd-chip sd-chip-${ROLE_TONE[role] || ""}`}>{ROLE_LABEL_FA[role] || role || "-"}</span>;
}

function IpCell({ ip }) {
  return ip ? <span className="sd-ip sd-mono" title={ip}>{ip}</span> : <span className="sd-muted">—</span>;
}

// پیام خطای عملیات: فقط پیام کوتاه و فارسیِ برگشتی از خود سرور؛ خطای شبکه/فنی نمایش داده نمی‌شود
function opError(err) {
  const msg = err && err.status && err.message ? String(err.message).trim() : "";
  const looksTechnical = /\bat\s+\S+\s*\(|node_modules|ER_[A-Z_]+|SQL|\.js:\d+/i.test(msg);
  return { title: "عملیات با مشکل مواجه شد.", detail: msg && msg.length <= 200 && !looksTechnical ? msg : "" };
}

function Alert({ tone, icon, title, children, onClose, role }) {
  return (
    <div className={`sd-alert sd-alert-${tone}`} role={role}>
      <span className="sd-alert-icon" aria-hidden="true">{icon}</span>
      <div className="sd-alert-text">{title && <strong>{title}</strong>}{children}</div>
      {onClose && <button type="button" className="sd-alert-close" onClick={onClose} aria-label="بستن پیام"><X size={16} /></button>}
    </div>
  );
}

function Kpi({ icon, title, value, sub, tone, loading }) {
  return (
    <div className="sd-kpi" style={tone ? { "--c": `var(--sd-${tone})` } : undefined}>
      <div className="sd-kpi-top">{icon}<span>{title}</span></div>
      {loading ? <div className="sd-skel" style={{ height: 30, width: "50%" }} /> : <div className="sd-kpi-value">{value}</div>}
      <div className="sd-kpi-sub">{sub}</div>
    </div>
  );
}

function SkeletonRows() {
  return (
    <div className="sd-skel-rows" aria-busy="true" aria-label="در حال بارگذاری">
      {Array.from({ length: 5 }).map((_, i) => <div key={i} className="sd-skel" style={{ height: 54 }} />)}
    </div>
  );
}

function ErrorState({ text, onRetry, busy }) {
  return (
    <div className="sd-state is-error" role="alert">
      <AlertTriangle size={32} aria-hidden="true" />
      <p>{text}</p>
      <button type="button" className="btn btn-primary btn-sm" onClick={onRetry} disabled={busy}>
        <RefreshCw size={14} aria-hidden="true" />تلاش مجدد
      </button>
    </div>
  );
}

function EmptyState({ icon, text, children }) {
  return (
    <div className="sd-state">
      {icon}
      <p>{text}</p>
      {children}
    </div>
  );
}

function Toolbar({ query, onQuery, role, onRole, status, onStatus, shown, total }) {
  return (
    <div className="sd-toolbar">
      <div className="sd-search">
        <Search size={16} aria-hidden="true" />
        <input type="search" value={query} onChange={(e) => onQuery(e.target.value)} placeholder="جستجوی نام کاربر" aria-label="جستجوی نام کاربر" />
      </div>
      <select value={role} onChange={(e) => onRole(e.target.value)} aria-label="فیلتر نقش">
        <option value="all">همه‌ی نقش‌ها</option>
        {Object.entries(ROLE_LABEL_FA).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
      </select>
      {onStatus && (
        <select value={status} onChange={(e) => onStatus(e.target.value)} aria-label="فیلتر وضعیت">
          <option value="all">همه‌ی وضعیت‌ها</option>
          {Object.entries(INACTIVE_SESSION_STATUS_FA).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
        </select>
      )}
      <span className="sd-count">{toFa(shown)} از {toFa(total)} نشست</span>
    </div>
  );
}

export default function SessionsDevices() {
  const { user: me } = useAuth();
  const [tab, setTab] = useState("active");
  const [now, setNow] = useState(() => Date.now());

  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [inactiveSessions, setInactiveSessions] = useState([]);
  const [inactiveLoading, setInactiveLoading] = useState(true);
  const [inactiveError, setInactiveError] = useState(false);

  const [terminatingId, setTerminatingId] = useState(null);
  const [terminateTarget, setTerminateTarget] = useState(null);
  const [status, setStatus] = useState({ type: "", text: "" });
  const [opErr, setOpErr] = useState(null);

  const [aQuery, setAQuery] = useState("");
  const [aRole, setARole] = useState("all");
  const [aLimit, setALimit] = useState(PAGE_SIZE);
  const [hQuery, setHQuery] = useState("");
  const [hRole, setHRole] = useState("all");
  const [hStatus, setHStatus] = useState("all");
  const [hLimit, setHLimit] = useState(PAGE_SIZE);

  function load() {
    setLoading(true);
    setError(false);
    apiRequest("/superadmin/sessions")
      .then((d) => setSessions(d.sessions))
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }

  function loadInactive() {
    setInactiveLoading(true);
    setInactiveError(false);
    apiRequest("/superadmin/sessions/inactive")
      .then((d) => setInactiveSessions(d.sessions))
      .catch(() => setInactiveError(true))
      .finally(() => setInactiveLoading(false));
  }

  useEffect(() => {
    load();
    loadInactive();
  }, []);

  // زمان «چند دقیقه پیش» هر دقیقه تازه می‌شود (بدون هیچ درخواست جدید به سرور)
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 60000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (status.type !== "success") return undefined;
    const t = setTimeout(() => setStatus({ type: "", text: "" }), 6000);
    return () => clearTimeout(t);
  }, [status]);

  // دکمه‌ی خاتمه‌ی نشست جاری خودِ Super Admin غیرفعال است (منطق قبلی بدون تغییر؛ Backend هم رد می‌کند)
  const isSelfSession = (s) => s.isCurrent && s.userId === me?.id;

  // مرحله‌ی اول: فقط مودال تأیید باز می‌شود؛ هیچ درخواستی ارسال نمی‌شود
  function openTerminate(session) {
    if (isSelfSession(session) || terminatingId === session.id) return;
    setStatus({ type: "", text: "" });
    setOpErr(null);
    setTerminateTarget(session);
  }

  async function confirmTerminate() {
    const session = terminateTarget;
    if (!session) return;
    setTerminateTarget(null);
    setTerminatingId(session.id);
    setOpErr(null);
    try {
      await apiRequest(`/superadmin/sessions/${session.id}`, { method: "DELETE" });
      setSessions((prev) => prev.filter((s) => s.id !== session.id));
      setStatus({ type: "success", text: "نشست با موفقیت خاتمه یافت." });
      loadInactive();
    } catch (err) {
      setOpErr(opError(err));
    } finally {
      setTerminatingId(null);
    }
  }

  const userCount = useMemo(() => new Set(sessions.map((s) => s.userId)).size, [sessions]);
  const currentCount = useMemo(() => sessions.filter((s) => s.isCurrent).length, [sessions]);

  const activeVisible = useMemo(() => {
    const q = aQuery.trim().toLowerCase();
    return sessions.filter((s) => (aRole === "all" || s.role === aRole) && (!q || String(s.userName || "").toLowerCase().includes(q)));
  }, [sessions, aQuery, aRole]);
  const historyVisible = useMemo(() => {
    const q = hQuery.trim().toLowerCase();
    return inactiveSessions.filter(
      (s) => (hRole === "all" || s.role === hRole) && (hStatus === "all" || s.status === hStatus) && (!q || String(s.userName || "").toLowerCase().includes(q))
    );
  }, [inactiveSessions, hQuery, hRole, hStatus]);

  const aFiltersOn = aQuery.trim() !== "" || aRole !== "all";
  const hFiltersOn = hQuery.trim() !== "" || hRole !== "all" || hStatus !== "all";

  return (
    <div className="dash-card glass sd-scope">
      <header className="sd-header">
        <div className="sd-header-icon" aria-hidden="true"><MonitorSmartphone size={24} /></div>
        <div className="sd-header-text">
          <h2>نشست‌ها و دستگاه‌ها</h2>
          <p>مدیریت نشست‌های فعال و مشاهده تاریخچه ورود کاربران به سیستم</p>
        </div>
      </header>

      <div className="sd-kpis">
        <Kpi
          icon={<Activity size={15} />} title="نشست‌های فعال" tone="ok" loading={loading}
          value={error ? "—" : toFa(sessions.length)} sub="تعداد نشست‌های فعال فعلی"
        />
        <Kpi
          icon={<Users size={15} />} title="کاربران دارای نشست" loading={loading}
          value={error ? "—" : toFa(userCount)} sub="کاربران یکتا در نشست‌های فعال"
        />
        <Kpi
          icon={<History size={15} />} title="نشست‌های غیرفعال" tone="warn" loading={inactiveLoading}
          value={inactiveError ? "—" : toFa(inactiveSessions.length)} sub="خروج، خاتمه توسط مدیر یا انقضا"
        />
        <Kpi
          icon={<UserCheck size={15} />} title="نشست‌های جاری" tone="violet" loading={loading}
          value={error ? "—" : toFa(currentCount)} sub="نشست‌های فعلیِ شما در همین فهرست"
        />
      </div>

      {status.text && (
        <Alert tone="success" icon={<Check size={18} />} role="status" onClose={() => setStatus({ type: "", text: "" })}>{status.text}</Alert>
      )}
      {opErr && (
        <Alert tone="error" icon={<AlertTriangle size={18} />} role="alert" title={opErr.title} onClose={() => setOpErr(null)}>{opErr.detail}</Alert>
      )}

      <div className="sd-tabs" role="tablist" aria-label="بخش‌های نشست‌ها">
        <button type="button" role="tab" id="sd-tab-active" aria-selected={tab === "active"} aria-controls="sd-panel" className={`sd-tab ${tab === "active" ? "is-active" : ""}`} onClick={() => setTab("active")}>
          <span className="sd-live-dot" aria-hidden="true" />نشست‌های فعال
          {!loading && !error && <span className="sd-tab-count">{toFa(sessions.length)}</span>}
        </button>
        <button type="button" role="tab" id="sd-tab-history" aria-selected={tab === "history"} aria-controls="sd-panel" className={`sd-tab ${tab === "history" ? "is-active" : ""}`} onClick={() => setTab("history")}>
          <History size={15} aria-hidden="true" />تاریخچه نشست‌ها
          {!inactiveLoading && !inactiveError && <span className="sd-tab-count">{toFa(inactiveSessions.length)}</span>}
        </button>
      </div>

      <section className="sd-card" id="sd-panel" role="tabpanel" aria-labelledby={tab === "active" ? "sd-tab-active" : "sd-tab-history"}>
        {tab === "active" ? (
          <>
            <div className="sd-card-head">
              <div className="sd-card-head-text">
                <h3 className="sd-card-title"><span className="sd-live-dot" aria-hidden="true" />نشست‌های فعال</h3>
                <p className="sd-card-desc">تمام نشست‌های فعال کاربران سیستم در این بخش نمایش داده می‌شوند.</p>
              </div>
              <button type="button" className="btn btn-ghost btn-sm" onClick={load} disabled={loading}>
                <RefreshCw size={14} aria-hidden="true" />{loading ? "در حال بروزرسانی..." : "بروزرسانی"}
              </button>
            </div>

            {loading && sessions.length === 0 ? (
              <SkeletonRows />
            ) : error ? (
              <ErrorState text="بارگذاری نشست‌های فعال با مشکل مواجه شد." onRetry={load} busy={loading} />
            ) : sessions.length === 0 ? (
              <EmptyState icon={<MonitorSmartphone size={34} aria-hidden="true" />} text="هیچ نشست فعالی یافت نشد." />
            ) : (
              <>
                <Toolbar
                  query={aQuery} onQuery={(v) => { setAQuery(v); setALimit(PAGE_SIZE); }}
                  role={aRole} onRole={(v) => { setARole(v); setALimit(PAGE_SIZE); }}
                  shown={activeVisible.length} total={sessions.length}
                />
                {activeVisible.length === 0 ? (
                  <EmptyState icon={<Search size={30} aria-hidden="true" />} text="نشستی با این جستجو/فیلتر پیدا نشد.">
                    {aFiltersOn && <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setAQuery(""); setARole("all"); }}>پاک کردن فیلترها</button>}
                  </EmptyState>
                ) : (
                  <>
                    <div className="sd-table-wrap">
                      <table className="sd-table" aria-label="نشست‌های فعال">
                        <thead>
                          <tr><th>کاربر</th><th>نقش</th><th>ورود</th><th>آخرین فعالیت</th><th>IP</th><th>دستگاه</th><th>عملیات</th></tr>
                        </thead>
                        <tbody>
                          {activeVisible.slice(0, aLimit).map((s) => {
                            const self = isSelfSession(s);
                            const busy = terminatingId === s.id;
                            return (
                              <tr key={s.id}>
                                <td className="sd-col-user" data-label="کاربر"><UserCell s={s} /></td>
                                <td data-label="نقش"><RoleBadge role={s.role} /></td>
                                <td data-label="ورود">
                                  <div className="sd-time"><span>{fmtDate(s.loginAt)}</span><small>{fmtTime(s.loginAt)}</small></div>
                                </td>
                                <td data-label="آخرین فعالیت">
                                  <div className="sd-time" title={fmtDateTime(s.lastActivityAt)}>
                                    <span className="sd-status-line"><span className="sd-chip sd-chip-ok"><span className="sd-dot" />فعال</span></span>
                                    <small>{relativeTime(s.lastActivityAt, now)}</small>
                                  </div>
                                </td>
                                <td data-label="IP"><IpCell ip={s.ipAddress} /></td>
                                <td data-label="دستگاه"><DeviceCell userAgent={s.userAgent} /></td>
                                <td className="sd-col-actions" data-label="عملیات">
                                  <span className="sd-action-wrap" title={s.isCurrent ? TERMINATE_BLOCKED_HINT : ""}>
                                    <button
                                      type="button" className="btn btn-ghost btn-sm sd-danger" aria-busy={busy}
                                      disabled={busy || self}
                                      onClick={() => openTerminate(s)}
                                      title={s.isCurrent ? TERMINATE_BLOCKED_HINT : ""}
                                    >
                                      <LogOut size={14} aria-hidden="true" />{busy ? "در حال خاتمه..." : "خاتمه نشست"}
                                    </button>
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                    {activeVisible.length > aLimit && (
                      <div className="sd-more"><button type="button" className="btn btn-ghost btn-sm" onClick={() => setALimit((n) => n + PAGE_SIZE)}>نمایش بیشتر</button></div>
                    )}
                  </>
                )}
              </>
            )}
          </>
        ) : (
          <>
            <div className="sd-card-head">
              <div className="sd-card-head-text">
                <h3 className="sd-card-title"><History size={18} aria-hidden="true" />تاریخچه نشست‌ها</h3>
                <p className="sd-card-desc">تاریخچه نشست‌هایی که با خروج، خاتمه توسط مدیر یا انقضا پایان یافته‌اند.</p>
              </div>
              <button type="button" className="btn btn-ghost btn-sm" onClick={loadInactive} disabled={inactiveLoading}>
                <RefreshCw size={14} aria-hidden="true" />{inactiveLoading ? "در حال بروزرسانی..." : "بروزرسانی"}
              </button>
            </div>

            {inactiveLoading && inactiveSessions.length === 0 ? (
              <SkeletonRows />
            ) : inactiveError ? (
              <ErrorState text="بارگذاری تاریخچه نشست‌ها با مشکل مواجه شد." onRetry={loadInactive} busy={inactiveLoading} />
            ) : inactiveSessions.length === 0 ? (
              <EmptyState icon={<History size={34} aria-hidden="true" />} text="هیچ سابقه نشست غیرفعالی وجود ندارد." />
            ) : (
              <>
                <Toolbar
                  query={hQuery} onQuery={(v) => { setHQuery(v); setHLimit(PAGE_SIZE); }}
                  role={hRole} onRole={(v) => { setHRole(v); setHLimit(PAGE_SIZE); }}
                  status={hStatus} onStatus={(v) => { setHStatus(v); setHLimit(PAGE_SIZE); }}
                  shown={historyVisible.length} total={inactiveSessions.length}
                />
                {historyVisible.length === 0 ? (
                  <EmptyState icon={<Search size={30} aria-hidden="true" />} text="نشستی با این جستجو/فیلتر پیدا نشد.">
                    {hFiltersOn && <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setHQuery(""); setHRole("all"); setHStatus("all"); }}>پاک کردن فیلترها</button>}
                  </EmptyState>
                ) : (
                  <>
                    <div className="sd-table-wrap">
                      <table className="sd-table" aria-label="تاریخچه نشست‌ها">
                        <thead>
                          <tr><th>کاربر</th><th>نقش</th><th>ورود</th><th>پایان نشست</th><th>آخرین فعالیت</th><th>IP</th><th>دستگاه</th><th>مدت نشست</th><th>وضعیت</th></tr>
                        </thead>
                        <tbody>
                          {historyVisible.slice(0, hLimit).map((s) => (
                            <tr key={s.id}>
                              <td className="sd-col-user" data-label="کاربر"><UserCell s={s} /></td>
                              <td data-label="نقش"><RoleBadge role={s.role} /></td>
                              <td data-label="ورود"><div className="sd-time"><span>{fmtDate(s.loginAt)}</span><small>{fmtTime(s.loginAt)}</small></div></td>
                              <td data-label="پایان نشست">
                                {s.endedAt ? <div className="sd-time"><span>{fmtDate(s.endedAt)}</span><small>{fmtTime(s.endedAt)}</small></div> : "-"}
                              </td>
                              <td data-label="آخرین فعالیت">
                                <div className="sd-time" title={fmtDateTime(s.lastActivityAt)}><span>{fmtDate(s.lastActivityAt)}</span><small>{fmtTime(s.lastActivityAt)}</small></div>
                              </td>
                              <td data-label="IP"><IpCell ip={s.ipAddress} /></td>
                              <td data-label="دستگاه"><DeviceCell userAgent={s.userAgent} /></td>
                              <td data-label="مدت نشست">{faDigits(formatSessionDuration(s.durationMs))}</td>
                              <td data-label="وضعیت">
                                <span className={`sd-chip sd-chip-${STATUS_TONE[s.status] || ""}`}>{INACTIVE_SESSION_STATUS_FA[s.status] || s.status}</span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {historyVisible.length > hLimit && (
                      <div className="sd-more"><button type="button" className="btn btn-ghost btn-sm" onClick={() => setHLimit((n) => n + PAGE_SIZE)}>نمایش بیشتر</button></div>
                    )}
                  </>
                )}
              </>
            )}
          </>
        )}
      </section>

      {/* ---------- مودال خاتمه نشست ---------- */}
      <GlobalModal
        isOpen={!!terminateTarget}
        onClose={() => setTerminateTarget(null)}
        size="sm"
        title="خاتمه نشست"
        className="sd-modal"
        footer={
          terminateTarget && (
            <>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setTerminateTarget(null)}>انصراف</button>
              <button type="button" className="btn btn-danger btn-sm" onClick={confirmTerminate}>خاتمه نشست</button>
            </>
          )
        }
      >
        {terminateTarget && (
          <>
            <p style={{ marginTop: 0, lineHeight: 1.9 }}>آیا مطمئن هستید که می‌خواهید نشست این کاربر را خاتمه دهید؟</p>
            <div className="sd-info-grid">
              <div><span>کاربر</span><strong>{terminateTarget.userName || "کاربر ناشناس"}</strong></div>
              <div><span>نقش</span><strong>{ROLE_LABEL_FA[terminateTarget.role] || terminateTarget.role || "-"}</strong></div>
              <div className="is-wide"><span>دستگاه</span><strong>{deviceLabel(terminateTarget.userAgent)}</strong></div>
              <div className="is-wide"><span>IP</span><strong className="sd-mono">{terminateTarget.ipAddress || "—"}</strong></div>
            </div>
            <Alert tone="warn" icon={<ShieldAlert size={18} />} role="alert">
              پس از خاتمه نشست، این کاربر برای ادامه فعالیت باید دوباره وارد سیستم شود.
            </Alert>
          </>
        )}
      </GlobalModal>
    </div>
  );
}

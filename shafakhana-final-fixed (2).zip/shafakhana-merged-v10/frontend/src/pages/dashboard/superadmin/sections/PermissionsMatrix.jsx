import { useEffect, useState } from "react";
import { apiRequest } from "../../../../utils/api.js";

export default function PermissionsMatrix() {
  const [matrix, setMatrix] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    apiRequest("/superadmin/permissions").then((d) => setMatrix(d.matrix)).catch((err) => setError(err.message));
  }, []);

  if (error) return <div className="form-message error">{error}</div>;
  if (!matrix) return <p>در حال بارگذاری...</p>;

  return (
    <div className="dash-card glass">
      <h2>مدیریت مجوزها — ماتریس دسترسی نقش‌ها</h2>
      <div className="permissions-grid">
        {Object.entries(matrix).map(([role, perms]) => (
          <div key={role} className="permission-col">
            <h3>{role === "user" ? "بیمار" : role === "admin" ? "ادمین" : "مدیر کل"}</h3>
            <ul>
              {perms.map((p) => <li key={p}>{p}</li>)}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle, Archive, Check, CalendarClock, ChevronLeft, ChevronRight, Clock, Copy, Database, Download,
  Folder, FolderOpen, Info, RefreshCw, RotateCcw, Search, Settings,
  ShieldCheck, Trash2, X,
} from "lucide-react";
import { apiRequest, apiDownload } from "../../../../utils/api.js";
import GlobalModal from "../../../../components/GlobalModal.jsx";
import "./DatabaseBackups.css";

const BACKUP_TYPE_META = {
  manual: { label: "دستی", tone: "info" },
  scheduled: { label: "خودکار", tone: "ok" },
  "pre-restore": { label: "پیش از بازیابی", tone: "warn" },
};

const BACKUP_FREQUENCY_LABELS = {
  daily: "هر روز",
  weekly: "هفتگی — هر جمعه",
  every12h: "هر ۱۲ ساعت",
  every6h: "هر ۶ ساعت",
};

const SORT_OPTIONS = [
  { value: "date-desc", label: "جدیدترین" },
  { value: "date-asc", label: "قدیمی‌ترین" },
  { value: "size-desc", label: "حجم: زیاد به کم" },
  { value: "size-asc", label: "حجم: کم به زیاد" },
];

const TIME_REGEX = /^([01]\d|2[0-3]):[0-5]\d$/;
const PAGE_SIZE = 10;

function formatBackupSize(bytes) {
  if (bytes === null || bytes === undefined || Number.isNaN(Number(bytes))) return "—";
  const n = Number(bytes);
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(2)} MB`;
  return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
}

// منطقه‌ی زمانی تنظیم‌شده‌ی سیستم (تنظیمات سیستم ← timezone)؛ اگر نامعتبر بود زمان مرورگر استفاده می‌شود
function safeTimeZone(tz) {
  if (!tz) return undefined;
  try {
    new Intl.DateTimeFormat("fa-IR", { timeZone: tz });
    return tz;
  } catch {
    return undefined;
  }
}
function toDate(value) {
  if (!value) return null;
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? null : d;
}
function fmtDate(value, tz) {
  const d = toDate(value);
  return d ? d.toLocaleDateString("fa-IR-u-ca-persian", { year: "numeric", month: "2-digit", day: "2-digit", timeZone: safeTimeZone(tz) }) : "—";
}
function fmtTime(value, tz) {
  const d = toDate(value);
  return d ? d.toLocaleTimeString("fa-IR-u-ca-persian", { hour: "2-digit", minute: "2-digit", timeZone: safeTimeZone(tz) }) : "";
}
function fmtDateTime(value, tz) {
  const d = toDate(value);
  return d ? d.toLocaleString("fa-IR-u-ca-persian", { timeZone: safeTimeZone(tz) }) : "—";
}
function toFa(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString("fa-IR-u-ca-persian", { useGrouping: false }) : "—";
}

// پیام خطای عملیات: فقط پیام کوتاهِ برگشتی از خود سرور (که از قبل فارسی و بدون جزئیات فنی است)
// نمایش داده می‌شود؛ خطاهای شبکه/ناشناخته و هر چیزی شبیه Stack Trace نمایش داده نمی‌شود.
function opError(err) {
  const msg = err && err.status && err.message ? String(err.message).trim() : "";
  const looksTechnical = /\bat\s+\S+\s*\(|node_modules|ER_[A-Z_]+|SQL|\.js:\d+/i.test(msg);
  return { title: "عملیات با مشکل مواجه شد.", detail: msg && msg.length <= 220 && !looksTechnical ? msg : "" };
}

function TypeBadge({ type }) {
  const meta = BACKUP_TYPE_META[type];
  return <span className={`bk-chip bk-chip-${meta ? meta.tone : ""}`}>{meta ? meta.label : type}</span>;
}

function Alert({ tone, icon, title, children, onClose, action, role }) {
  return (
    <div className={`bk-alert bk-alert-${tone}`} role={role}>
      <span className="bk-alert-icon" aria-hidden="true">{icon}</span>
      <div className="bk-alert-text">
        {title && <strong>{title}</strong>}
        {children}
      </div>
      {action && <div className="bk-alert-actions">{action}</div>}
      {onClose && (
        <button type="button" className="bk-alert-close" onClick={onClose} aria-label="بستن پیام"><X size={16} /></button>
      )}
    </div>
  );
}

function Kpi({ icon, title, value, sub, tone, text }) {
  return (
    <div className="bk-kpi" style={tone ? { "--c": `var(--bk-${tone})` } : undefined}>
      <div className="bk-kpi-top">{icon}<span>{title}</span></div>
      <div className={`bk-kpi-value ${text ? "is-text" : ""}`}>{value}</div>
      <div className="bk-kpi-sub">{sub}</div>
    </div>
  );
}

function PageSkeleton() {
  return (
    <div aria-busy="true" aria-label="در حال بارگذاری نسخه‌های پشتیبان" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="bk-kpis">
        {Array.from({ length: 4 }).map((_, i) => <div key={i} className="bk-skel" style={{ height: 96, borderRadius: 12 }} />)}
      </div>
      <div className="bk-skel" style={{ height: 320, borderRadius: 14 }} />
      <div className="bk-skel" style={{ height: 260, borderRadius: 14 }} />
    </div>
  );
}

function Pagination({ page, pageCount, onChange }) {
  if (pageCount <= 1) return null;
  const pages = [];
  const from = Math.max(1, Math.min(page - 2, pageCount - 4));
  const to = Math.min(pageCount, from + 4);
  for (let p = from; p <= to; p += 1) pages.push(p);
  return (
    <nav className="bk-pager" aria-label="صفحه‌بندی">
      <button type="button" className="bk-page-btn" onClick={() => onChange(page + 1)} disabled={page >= pageCount} aria-label="صفحه بعد"><ChevronLeft size={16} /></button>
      {pages.reverse().map((p) => (
        <button key={p} type="button" className={`bk-page-btn ${p === page ? "is-current" : ""}`} onClick={() => onChange(p)} aria-current={p === page ? "page" : undefined}>
          {toFa(p)}
        </button>
      ))}
      <button type="button" className="bk-page-btn" onClick={() => onChange(page - 1)} disabled={page <= 1} aria-label="صفحه قبل"><ChevronRight size={16} /></button>
    </nav>
  );
}

export default function DatabaseBackups() {
  const [backups, setBackups] = useState([]);
  const [backupsFolderId, setBackupsFolderId] = useState(null); // پوشه‌ای که فهرست backups متعلق به آن است
  const [folders, setFolders] = useState([]);
  const [activeFolderId, setActiveFolderId] = useState(null);
  const [activeFolderMessage, setActiveFolderMessage] = useState("");
  const [selectedId, setSelectedId] = useState(null);
  const [schedule, setSchedule] = useState(null);
  const [loaded, setLoaded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [listError, setListError] = useState(false);

  const [status, setStatus] = useState({ type: "", text: "" });
  const [error, setError] = useState(null); // { title, detail }
  const [created, setCreated] = useState(null); // پاسخ واقعی آخرین «بکاپ دستی»
  const [creating, setCreating] = useState(false);
  const [busyAction, setBusyAction] = useState(""); // "download-<filename>" | "activate-<id>"

  // بازیابی دیتابیس (مودال تأیید نوشتاری — منطق امنیتی قبلی بدون تغییر)
  const [restoreTarget, setRestoreTarget] = useState(null);
  const [confirmText, setConfirmText] = useState("");
  const [restoreError, setRestoreError] = useState("");
  const [restoring, setRestoring] = useState(false);

  // حذف پشتیبان
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleteError, setDeleteError] = useState("");
  const [deleting, setDeleting] = useState(false);

  // انتخاب پوشه از روی کامپیوتر (پنجره‌ی انتخاب پوشه‌ی سیستم‌عامل)
  const [picking, setPicking] = useState(false);
  const [activateOpen, setActivateOpen] = useState(false);
  const [activateChoice, setActivateChoice] = useState("");
  const [activateError, setActivateError] = useState("");
  const [activating, setActivating] = useState(false);

  // تنظیمات پشتیبان‌گیری خودکار
  const [autoForm, setAutoForm] = useState(null);
  const [autoSaving, setAutoSaving] = useState(false);
  const [autoErrors, setAutoErrors] = useState({});

  // جستجو / فیلتر / مرتب‌سازی / صفحه‌بندی (کاملاً سمت کلاینت و فقط روی داده‌ی همین API)
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [sort, setSort] = useState("date-desc");
  const [page, setPage] = useState(1);
  const [copied, setCopied] = useState("");

  const selectedRef = useRef(null);
  const requestRef = useRef(0);
  const autoSectionRef = useRef(null);

  const autoFormFromSchedule = (s) => ({
    enabled: s.enabled,
    frequency: s.frequency,
    time: s.time,
    retentionCount: String(s.retentionCount),
  });

  const autoDirty = useMemo(() => {
    if (!schedule || !autoForm) return false;
    const base = autoFormFromSchedule(schedule);
    return Object.keys(base).some((k) => String(base[k]) !== String(autoForm[k]));
  }, [schedule, autoForm]);
  const autoDirtyRef = useRef(false);
  autoDirtyRef.current = autoDirty;

  // folderId: پوشه‌ای که فهرست فایل‌هایش خوانده شود (پیش‌فرض: همان که الان انتخاب است؛ در نبودِ آن، پوشه‌ی فعال).
  // forceSync: بعد از ذخیره‌ی تنظیمات، فرم با مقدار واقعی سرور هم‌گام می‌شود؛ در بارگذاری‌های
  // دیگر ویرایش‌های ذخیره‌نشده‌ی فرم پاک نمی‌شوند.
  const reload = useCallback(async (forceSync = false, folderId) => {
    const requestId = requestRef.current + 1;
    requestRef.current = requestId;
    let target = folderId !== undefined ? folderId : selectedRef.current;
    setLoading(true);
    try {
      for (let attempt = 0; attempt < 2; attempt += 1) {
        try {
          const qs = target ? `?folder=${encodeURIComponent(target)}` : "";
          const d = await apiRequest(`/superadmin/backups${qs}`);
          if (requestId !== requestRef.current) return; // پاسخ کهنه (درخواست جدیدتری ارسال شده)
          setBackups(Array.isArray(d.backups) ? d.backups : []);
          setBackupsFolderId(d.selectedFolderId || null);
          setFolders(Array.isArray(d.folders) ? d.folders : []);
          setActiveFolderId(d.activeFolderId || null);
          setActiveFolderMessage(d.activeFolderAvailable === false ? d.activeFolderMessage || "پوشه‌ی فعال بکاپ در دسترس نیست." : "");
          selectedRef.current = d.selectedFolderId || null;
          setSelectedId(d.selectedFolderId || null);
          if (d.schedule) {
            setSchedule(d.schedule);
            if (forceSync || !autoDirtyRef.current) setAutoForm(autoFormFromSchedule(d.schedule));
          }
          setListError(false);
          setLoaded(true);
          return;
        } catch (err) {
          // پوشه‌ی انتخاب‌شده دیگر وجود ندارد → به پوشه‌ی فعال برمی‌گردیم
          if (target && err && err.status === 404) {
            target = null;
            continue;
          }
          if (requestId === requestRef.current) setListError(true);
          return;
        }
      }
    } finally {
      if (requestId === requestRef.current) setLoading(false);
    }
  }, []);
  useEffect(() => { reload(true, null); }, [reload]);

  useEffect(() => {
    if (status.type !== "success") return undefined;
    const t = setTimeout(() => setStatus({ type: "", text: "" }), 7000);
    return () => clearTimeout(t);
  }, [status]);

  const tz = schedule && schedule.timezone;
  const selectedFolder = useMemo(() => folders.find((f) => f.id === selectedId) || null, [folders, selectedId]);
  const activeFolder = useMemo(() => folders.find((f) => f.id === activeFolderId) || null, [folders, activeFolderId]);
  const activeUsable = !!activeFolder && !activeFolderMessage;

  const anyBusy = creating || autoSaving || !!busyAction || restoring || deleting || picking || activating;

  function clearMessages() {
    setStatus({ type: "", text: "" });
    setError(null);
  }

  /* ---------- انتخاب پوشه برای مشاهده ---------- */
  function selectFolder(id) {
    if (id === selectedRef.current) return;
    selectedRef.current = id;
    setSelectedId(id);
    setBackups([]);
    setQuery("");
    setTypeFilter("all");
    setPage(1);
    reload(false, id);
  }

  /* ---------- بکاپ دستی (در پوشه‌ی فعال) ---------- */
  async function createManualBackup() {
    if (anyBusy) return;
    setCreating(true);
    clearMessages();
    setCreated(null);
    try {
      const res = await apiRequest("/superadmin/backups", { method: "POST" });
      setStatus({ type: "success", text: "پشتیبان دیتابیس با موفقیت ایجاد شد." });
      setCreated(res.backup || null);
      await reload();
    } catch (err) {
      setError(opError(err));
      await reload(); // اگر پوشه‌ی فعال مشکل پیدا کرده باشد، وضعیت واقعی نمایش داده شود
    } finally {
      setCreating(false);
    }
  }

  /* ---------- تنظیمات خودکار ---------- */
  async function saveAutoBackup(e) {
    e.preventDefault();
    if (anyBusy || !autoForm) return;
    clearMessages();

    const errors = {};
    if (!TIME_REGEX.test(autoForm.time || "")) errors.backupAutoTime = "ساعت باید به شکل HH:MM باشد (مثلاً 03:00)";
    const n = Number(autoForm.retentionCount);
    if (!/^\d{1,3}$/.test(String(autoForm.retentionCount).trim()) || n < 1 || n > 200) {
      errors.backupRetentionCount = "تعداد فایل‌های نگه‌داشته‌شده باید بین ۱ تا ۲۰۰ باشد";
    }
    if (Object.keys(errors).length > 0) {
      setAutoErrors(errors);
      return;
    }

    setAutoSaving(true);
    setAutoErrors({});
    try {
      await apiRequest("/superadmin/settings", {
        method: "PUT",
        body: {
          backupAutoEnabled: autoForm.enabled ? "on" : "off",
          backupAutoFrequency: autoForm.frequency,
          backupAutoTime: autoForm.time,
          backupRetentionCount: autoForm.retentionCount,
        },
      });
      setStatus({ type: "success", text: "تنظیمات پشتیبان‌گیری خودکار ذخیره شد." });
      await reload(true);
    } catch (err) {
      setError(opError(err));
      if (err.data && err.data.errors) setAutoErrors(err.data.errors);
    } finally {
      setAutoSaving(false);
    }
  }

  /* ---------- دانلود ---------- */
  async function download(backup) {
    if (anyBusy) return;
    setBusyAction(`download-${backup.filename}`);
    clearMessages();
    try {
      await apiDownload(
        `/superadmin/backups/${encodeURIComponent(backup.filename)}/download?folder=${encodeURIComponent(backup.folderId)}`,
        backup.filename
      );
    } catch (err) {
      setError(opError(err));
    } finally {
      setBusyAction("");
    }
  }

  /* ---------- بازیابی ---------- */
  // مرحله‌ی اول: فقط مودال تأیید باز می‌شود؛ هیچ درخواستی به بک‌اند ارسال نمی‌شود
  function openRestoreModal(backup) {
    if (anyBusy) return;
    clearMessages();
    setRestoreError("");
    setConfirmText("");
    setRestoreTarget(backup);
  }
  function closeRestoreModal() {
    if (restoring) return;
    setRestoreTarget(null);
    setConfirmText("");
    setRestoreError("");
  }
  // مرحله‌ی دوم: فقط وقتی نام فایل عیناً تایپ شده باشد؛ Backend نیز دوباره همین تطابق را الزامی می‌کند
  async function confirmRestore() {
    if (!restoreTarget || restoring) return;
    if (confirmText !== restoreTarget.filename) {
      setRestoreError("نام وارد شده با نام فایل پشتیبان مطابقت ندارد");
      return;
    }
    setRestoring(true);
    setRestoreError("");
    try {
      const res = await apiRequest(`/superadmin/backups/${encodeURIComponent(restoreTarget.filename)}/restore`, {
        method: "POST",
        body: { confirm: confirmText, folder: restoreTarget.folderId },
      });
      setStatus({ type: "success", text: res.message });
      setRestoreTarget(null);
      setConfirmText("");
      setCreated(null);
      await reload(true);
    } catch (err) {
      const e = opError(err);
      setRestoreError(e.detail ? `${e.title} ${e.detail}` : e.title);
    } finally {
      setRestoring(false);
    }
  }

  /* ---------- حذف پشتیبان ---------- */
  function openDeleteModal(backup) {
    if (anyBusy) return;
    clearMessages();
    setDeleteError("");
    setDeleteTarget(backup);
  }
  function closeDeleteModal() {
    if (deleting) return;
    setDeleteTarget(null);
    setDeleteError("");
  }
  async function confirmDelete() {
    if (!deleteTarget || deleting) return;
    setDeleting(true);
    setDeleteError("");
    try {
      await apiRequest(
        `/superadmin/backups/${encodeURIComponent(deleteTarget.filename)}?folder=${encodeURIComponent(deleteTarget.folderId)}`,
        { method: "DELETE" }
      );
      setStatus({ type: "success", text: "نسخه پشتیبان با موفقیت حذف شد." });
      setDeleteTarget(null);
      await reload();
    } catch (err) {
      const e = opError(err);
      setDeleteError(e.detail ? `${e.title} ${e.detail}` : e.title);
    } finally {
      setDeleting(false);
    }
  }

  /* ---------- انتخاب پوشه‌ی ذخیره‌ی بکاپ از روی کامپیوتر ---------- */
  // پنجره‌ی انتخاب پوشه‌ی خودِ سیستم‌عامل باز می‌شود (درایوها + «Make New Folder»)؛ مسیر انتخاب‌شده
  // در سرور ذخیره و به‌عنوان پوشه‌ی فعال تنظیم می‌شود. در این بخش هیچ پوشه‌ای ساخته نمی‌شود.
  async function pickFolder() {
    if (anyBusy) return;
    clearMessages();
    setPicking(true);
    try {
      const res = await apiRequest("/superadmin/backups/folders/pick", { method: "POST" });
      if (res && res.cancelled) return; // کاربر پنجره را بست؛ چیزی تغییر نمی‌کند
      setStatus({
        type: "success",
        text: `پوشه‌ی ذخیره‌ی بکاپ روی کامپیوتر تنظیم شد: ${res.folder.path}. بکاپ‌های بعدی (دستی و خودکار) همان‌جا ذخیره می‌شوند و بکاپ‌های قبلی در جای خود باقی می‌مانند.`,
      });
      selectedRef.current = res.folder.id;
      setSelectedId(res.folder.id);
      setPage(1);
      await reload(false, res.folder.id);
    } catch (err) {
      setError(opError(err));
    } finally {
      setPicking(false);
    }
  }

  /* ---------- تغییر پوشه‌ی فعال (مقصد بکاپ‌های بعدی) ---------- */
  async function activateFolder(folderId, { fromModal = false } = {}) {
    if (anyBusy) return;
    if (fromModal) {
      setActivating(true);
      setActivateError("");
    } else {
      clearMessages();
      setBusyAction(`activate-${folderId}`);
    }
    try {
      const res = await apiRequest(`/superadmin/backups/folders/${encodeURIComponent(folderId)}/activate`, { method: "POST" });
      setStatus({ type: "success", text: `پوشه‌ی فعال بکاپ به «${res.folder.name}» تغییر کرد. بکاپ‌های قبلی در جای خود باقی می‌مانند.` });
      if (fromModal) setActivateOpen(false);
      await reload();
    } catch (err) {
      const e = opError(err);
      if (fromModal) setActivateError(e.detail || e.title);
      else setError(e);
    } finally {
      setActivating(false);
      setBusyAction("");
    }
  }
  function openActivateModal() {
    if (anyBusy) return;
    clearMessages();
    setActivateError("");
    setActivateChoice(activeFolderId || "");
    setActivateOpen(true);
  }

  async function copyName(filename) {
    try {
      await navigator.clipboard.writeText(filename);
      setCopied(filename);
      setTimeout(() => setCopied((c) => (c === filename ? "" : c)), 1800);
    } catch {
      // کلیپ‌بورد در دسترس نیست (مثلاً HTTP غیرامن)؛ نام فایل همچنان در Tooltip قابل مشاهده است
    }
  }

  function scrollToAutoSettings() {
    if (autoSectionRef.current) autoSectionRef.current.scrollIntoView({ block: "start" });
  }

  /* ---------- مقادیر مشتق‌شده (فقط از داده‌ی واقعی API) ---------- */
  const totalCount = useMemo(() => folders.reduce((sum, f) => sum + (f.count || 0), 0), [folders]);
  const totalSize = useMemo(() => folders.reduce((sum, f) => sum + (f.totalSize || 0), 0), [folders]);
  const lastSuccess = useMemo(() => {
    let best = null;
    folders.forEach((f) => {
      const d = toDate(f.lastBackupAt);
      if (d && (!best || d > best.date)) best = { date: d, folder: f };
    });
    return best;
  }, [folders]);

  const tableReady = backupsFolderId === selectedId;
  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = backups.filter((b) => (typeFilter === "all" || b.type === typeFilter) && (!q || b.filename.toLowerCase().includes(q)));
    const time = (b) => (toDate(b.createdAt) ? toDate(b.createdAt).getTime() : 0);
    const by = {
      "date-desc": (a, b) => time(b) - time(a),
      "date-asc": (a, b) => time(a) - time(b),
      "size-desc": (a, b) => (b.size || 0) - (a.size || 0),
      "size-asc": (a, b) => (a.size || 0) - (b.size || 0),
    }[sort];
    return [...list].sort(by);
  }, [backups, query, typeFilter, sort]);

  const pageCount = Math.max(1, Math.ceil(visible.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const pageRows = visible.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const filtersActive = query.trim() !== "" || typeFilter !== "all";
  const restoreConfirmMatches = !!restoreTarget && confirmText === restoreTarget.filename;
  const showToolbar = backups.length > 5;
  const folderNameOf = (id) => (folders.find((f) => f.id === id) || {}).name || "";

  function setAuto(patch) {
    setAutoForm((f) => ({ ...f, ...patch }));
    setAutoErrors({});
  }

  /* ---------- رندر ---------- */
  return (
    <div className="dash-card glass bk-scope">
      <header className="bk-header">
        <div className="bk-header-icon" aria-hidden="true"><Database size={24} /></div>
        <div className="bk-header-text">
          <h2>بکاپ‌گیری از دیتابیس</h2>
          <p>مدیریت و ذخیره‌سازی نسخه‌های پشتیبان از اطلاعات سیستم</p>
        </div>
      </header>

      {status.text && (
        <Alert tone="success" icon={<Check size={18} />} role="status" onClose={() => setStatus({ type: "", text: "" })}>
          {status.text}
        </Alert>
      )}
      {error && (
        <Alert tone="error" icon={<AlertTriangle size={18} />} role="alert" title={error.title} onClose={() => setError(null)}>
          {error.detail}
        </Alert>
      )}

      {/* ---------- وضعیت کلی ---------- */}
      {!loaded && listError ? (
        <div className="bk-state is-error" role="alert">
          <AlertTriangle size={32} aria-hidden="true" />
          <p>بارگذاری نسخه‌های پشتیبان با مشکل مواجه شد.</p>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => reload(true)} disabled={loading}>
            <RefreshCw size={14} aria-hidden="true" />{loading ? "در حال تلاش..." : "تلاش مجدد"}
          </button>
        </div>
      ) : !loaded ? (
        <PageSkeleton />
      ) : (
        <>
          {listError && (
            <Alert
              tone="error" icon={<AlertTriangle size={18} />} role="alert"
              action={<button type="button" className="btn btn-ghost btn-sm" onClick={() => reload()} disabled={loading}><RefreshCw size={14} />تلاش مجدد</button>}
            >
              بارگذاری نسخه‌های پشتیبان با مشکل مواجه شد. اطلاعات زیر ممکن است قدیمی باشد.
            </Alert>
          )}
          {activeFolderMessage && (
            <Alert
              tone="warn" icon={<AlertTriangle size={18} />} role="alert" title="پوشه‌ی فعال بکاپ در دسترس نیست"
              action={<button type="button" className="btn btn-ghost btn-sm" onClick={openActivateModal} disabled={anyBusy}>تغییر پوشه</button>}
            >
              {activeFolderMessage} تا آن زمان بکاپ جدیدی گرفته نمی‌شود و بکاپ‌های قبلی دست‌نخورده می‌مانند.
            </Alert>
          )}
          {schedule && schedule.lastError && (
            <Alert tone="error" icon={<AlertTriangle size={18} />} role="alert" title="آخرین بکاپ خودکار ناموفق بود">
              {schedule.lastError.message}
              {schedule.lastError.at ? ` (${fmtDateTime(schedule.lastError.at, tz)})` : ""}
            </Alert>
          )}

          {/* ---------- کارت‌های آماری ---------- */}
          <div className="bk-kpis">
            <button type="button" className="bk-kpi bk-kpi-action" onClick={pickFolder} disabled={anyBusy} aria-busy={picking}>
              <span className="bk-kpi-plus" aria-hidden="true"><FolderOpen size={22} /></span>
              <span className="bk-kpi-action-text">
                <strong>{picking ? "در انتظار انتخاب پوشه..." : "انتخاب پوشه"}</strong>
                <small>{picking ? "پنجره‌ی انتخاب پوشه باز شد؛ اگر دیده نمی‌شود نوار وظیفه (Taskbar) را بررسی کنید" : "انتخاب درایو/پوشه‌ی ذخیره‌ی بکاپ‌ها از روی کامپیوتر"}</small>
              </span>
            </button>
            <Kpi
              icon={<FolderOpen size={15} />} title="پوشه فعال" text tone="info"
              value={activeFolder ? activeFolder.name : "—"}
              sub={<button type="button" className="bk-link" onClick={openActivateModal} disabled={anyBusy}>تغییر پوشه</button>}
            />
            <Kpi
              icon={<Archive size={15} />} title="تعداد کل بکاپ‌ها"
              value={<>{toFa(totalCount)} <span className="bk-kpi-unit">فایل</span></>}
              sub={<>مجموع حجم: <span className="bk-size">{formatBackupSize(totalSize)}</span></>}
            />
            <Kpi
              icon={<Clock size={15} />} title="آخرین بکاپ موفق" text tone="ok"
              value={lastSuccess ? `${fmtDate(lastSuccess.date, tz)} ${fmtTime(lastSuccess.date, tz)}` : "—"}
              sub={lastSuccess ? `در پوشه «${lastSuccess.folder.name}»` : "هنوز بکاپ سالمی ایجاد نشده"}
            />
          </div>

          {/* ---------- پوشه‌ها و فهرست بکاپ‌ها ---------- */}
          <section className="bk-card" aria-labelledby="bk-panel-title">
            <div className="bk-card-head">
              <div className="bk-card-icon" aria-hidden="true"><Folder size={20} /></div>
              <div className="bk-card-head-text">
                <h3 className="bk-card-title" id="bk-panel-title">پوشه‌های بکاپ</h3>
                <p className="bk-card-desc">بکاپ‌های دستی و خودکار در «پوشه فعال» ذخیره می‌شوند؛ با انتخاب هر پوشه، فقط بکاپ‌های همان پوشه نمایش داده می‌شود.</p>
              </div>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => reload()} disabled={loading || anyBusy}>
                <RefreshCw size={14} aria-hidden="true" />{loading ? "در حال به‌روزرسانی..." : "به‌روزرسانی"}
              </button>
            </div>

            <div className="bk-layout">
              {/* ----- جدول بکاپ‌های پوشه انتخاب‌شده ----- */}
              <div className="bk-files">
                <div className="bk-files-head">
                  <div className="bk-files-title">
                    <FolderOpen size={18} aria-hidden="true" />
                    <div>
                      <h4>{selectedFolder ? selectedFolder.name : "—"}</h4>
                      {selectedFolder && selectedFolder.description && <p>{selectedFolder.description}</p>}
                      {selectedFolder && <span className="bk-path bk-mono" title="مسیر ذخیره‌سازی">{selectedFolder.path}</span>}
                    </div>
                  </div>
                  <div className="bk-files-actions">
                    <button type="button" className="btn btn-primary btn-sm" onClick={createManualBackup} disabled={anyBusy || !activeUsable} aria-busy={creating}
                      title={activeFolder ? `ذخیره در پوشه فعال: ${activeFolder.name}` : undefined}>
                      <Database size={16} aria-hidden="true" />
                      {creating ? "در حال تهیه پشتیبان..." : "ایجاد بکاپ دستی"}
                    </button>
                    <button type="button" className="btn btn-ghost btn-sm" onClick={scrollToAutoSettings}>
                      <Settings size={14} aria-hidden="true" />تنظیمات زمان‌بندی
                    </button>
                  </div>
                </div>
                {activeFolder && (
                  <p className="bk-hint">
                    <Info size={14} aria-hidden="true" />
                    بکاپ جدید در پوشه فعال «{activeFolder.name}» ذخیره می‌شود{selectedId !== activeFolderId ? " (متفاوت از پوشه‌ی در حال مشاهده)" : ""}.
                  </p>
                )}

                {created && (
                  <div className="bk-created" aria-label="اطلاعات پشتیبان ایجادشده">
                    <div>
                      <span>نام فایل</span>
                      <strong className="bk-mono" style={{ fontSize: 12.5 }}>{created.filename}</strong>
                    </div>
                    <div><span>زمان ایجاد</span><strong>{fmtDateTime(created.createdAt, tz)}</strong></div>
                    <div><span>تعداد جداول</span><strong>{created.tableCount !== undefined ? toFa(created.tableCount) : "—"}</strong></div>
                    <div><span>حجم فایل</span><strong className="bk-size">{formatBackupSize(created.size)}</strong></div>
                  </div>
                )}

                {!tableReady ? (
                  <div className="bk-skel" aria-busy="true" aria-label="در حال بارگذاری بکاپ‌ها" style={{ height: 220, borderRadius: 12 }} />
                ) : backups.length === 0 ? (
                  <div className="bk-state">
                    <Archive size={34} aria-hidden="true" />
                    <p>هنوز هیچ نسخه پشتیبانی در این پوشه وجود ندارد.</p>
                    {selectedId === activeFolderId && (
                      <button type="button" className="btn btn-primary btn-sm" onClick={createManualBackup} disabled={anyBusy || !activeUsable}>
                        {creating ? "در حال تهیه پشتیبان..." : "تهیه اولین پشتیبان"}
                      </button>
                    )}
                  </div>
                ) : (
                  <>
                    {showToolbar && (
                      <div className="bk-toolbar">
                        <div className="bk-search">
                          <Search size={16} aria-hidden="true" />
                          <input type="search" value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }} placeholder="جستجوی نام فایل" aria-label="جستجوی نام فایل" />
                        </div>
                        <select value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setPage(1); }} aria-label="فیلتر نوع پشتیبان">
                          <option value="all">همه‌ی انواع</option>
                          {Object.entries(BACKUP_TYPE_META).map(([value, m]) => <option key={value} value={value}>{m.label}</option>)}
                        </select>
                        <select value={sort} onChange={(e) => { setSort(e.target.value); setPage(1); }} aria-label="مرتب‌سازی">
                          {SORT_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                      </div>
                    )}

                    {visible.length === 0 ? (
                      <div className="bk-state">
                        <Search size={30} aria-hidden="true" />
                        <p>نسخه‌ای با این جستجو/فیلتر پیدا نشد.</p>
                        {filtersActive && (
                          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setQuery(""); setTypeFilter("all"); setPage(1); }}>پاک کردن فیلترها</button>
                        )}
                      </div>
                    ) : (
                      <>
                        <div className="bk-table-wrap">
                          <table className="bk-table">
                            <thead>
                              <tr>
                                <th className="bk-col-num">#</th><th>نام فایل</th><th>تاریخ و زمان</th><th>نوع</th><th>حجم</th><th>وضعیت</th><th>عملیات</th>
                              </tr>
                            </thead>
                            <tbody>
                              {pageRows.map((b, i) => {
                                const corrupt = b.status === "corrupt";
                                return (
                                  <tr key={`${b.folderId}-${b.filename}`}>
                                    <td className="bk-col-num" data-label="ردیف">{toFa((currentPage - 1) * PAGE_SIZE + i + 1)}</td>
                                    <td className="bk-col-file" data-label="نام فایل">
                                      <div className="bk-file">
                                        <span className="bk-fname bk-mono" title={b.filename}>{b.filename}</span>
                                        <button
                                          type="button" className={`bk-copy ${copied === b.filename ? "is-copied" : ""}`}
                                          onClick={() => copyName(b.filename)} aria-label="کپی نام فایل" title="کپی نام فایل"
                                        >
                                          {copied === b.filename ? <Check size={14} /> : <Copy size={14} />}
                                        </button>
                                      </div>
                                    </td>
                                    <td data-label="تاریخ و زمان">
                                      <div className="bk-date"><span>{fmtDate(b.createdAt, tz)}</span><small>{fmtTime(b.createdAt, tz)}</small></div>
                                    </td>
                                    <td data-label="نوع"><TypeBadge type={b.type} /></td>
                                    <td data-label="حجم"><span className="bk-size">{formatBackupSize(b.size)}</span></td>
                                    <td data-label="وضعیت">
                                      {corrupt
                                        ? <span className="bk-chip bk-chip-danger" title={b.statusMessage || "فایل ناقص یا نامعتبر است"}><span className="bk-dot" />ناقص</span>
                                        : <span className="bk-chip bk-chip-ok"><span className="bk-dot" />سالم</span>}
                                    </td>
                                    <td className="bk-col-actions">
                                      <div className="bk-actions">
                                        <button type="button" className="btn btn-ghost btn-sm bk-icon-btn" disabled={anyBusy} onClick={() => download(b)}
                                          aria-label={`دانلود ${b.filename}`} title="دانلود" aria-busy={busyAction === `download-${b.filename}`}>
                                          <Download size={15} aria-hidden="true" /><span className="bk-btn-label">{busyAction === `download-${b.filename}` ? "در حال دانلود..." : "دانلود"}</span>
                                        </button>
                                        <button type="button" className="btn btn-ghost btn-sm bk-icon-btn bk-ok" disabled={anyBusy || corrupt} onClick={() => openRestoreModal(b)}
                                          aria-label={`بازیابی ${b.filename}`} title={corrupt ? "فایل ناقص است و قابل بازیابی نیست" : "بازیابی"}>
                                          <RotateCcw size={15} aria-hidden="true" /><span className="bk-btn-label">بازیابی</span>
                                        </button>
                                        <button type="button" className="btn btn-ghost btn-sm bk-icon-btn bk-danger" disabled={anyBusy} onClick={() => openDeleteModal(b)}
                                          aria-label={`حذف ${b.filename}`} title="حذف">
                                          <Trash2 size={15} aria-hidden="true" /><span className="bk-btn-label">حذف</span>
                                        </button>
                                      </div>
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                          </table>
                        </div>
                        <div className="bk-table-foot">
                          <span className="bk-count">
                            نمایش {toFa((currentPage - 1) * PAGE_SIZE + 1)} تا {toFa(Math.min(currentPage * PAGE_SIZE, visible.length))} از {toFa(visible.length)} مورد
                          </span>
                          <Pagination page={currentPage} pageCount={pageCount} onChange={setPage} />
                        </div>
                      </>
                    )}
                  </>
                )}
              </div>

              {/* ----- فهرست پوشه‌ها ----- */}
              <aside className="bk-folders" aria-label="فهرست پوشه‌های بکاپ">
                <div className="bk-folders-head">
                  <h4>پوشه‌ها</h4>
                  <button type="button" className="bk-link" onClick={pickFolder} disabled={anyBusy}><FolderOpen size={14} aria-hidden="true" />انتخاب پوشه</button>
                </div>
                <ul className="bk-folder-list">
                  {folders.map((f) => {
                    const selected = f.id === selectedId;
                    return (
                      <li key={f.id} className={`bk-folder ${selected ? "is-selected" : ""} ${f.writable ? "" : "is-unusable"}`}>
                        <button type="button" className="bk-folder-main" onClick={() => selectFolder(f.id)} aria-current={selected ? "true" : undefined}>
                          {selected ? <FolderOpen size={17} aria-hidden="true" /> : <Folder size={17} aria-hidden="true" />}
                          <span className="bk-folder-name">{f.name}</span>
                          {f.isActive && <span className="bk-chip bk-chip-ok bk-chip-sm">فعال</span>}
                          {!f.writable && <span className="bk-chip bk-chip-danger bk-chip-sm" title="پوشه قابل نوشتن نیست">غیرقابل‌نوشتن</span>}
                          <span className="bk-folder-count" title="تعداد بکاپ‌ها">{toFa(f.count)}</span>
                        </button>
                        <div className="bk-folder-actions">
                          {!f.isActive && f.writable && (
                            <button type="button" className="bk-mini" onClick={() => activateFolder(f.id)} disabled={anyBusy}
                              aria-label={`فعال‌سازی پوشه ${f.name}`} title="انتخاب به‌عنوان پوشه فعال">
                              <Check size={14} aria-hidden="true" />
                            </button>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </aside>
            </div>
          </section>

          {/* ---------- تنظیمات بکاپ‌گیری خودکار ---------- */}
          {autoForm && schedule && (
            <section className="bk-card" ref={autoSectionRef} aria-labelledby="bk-auto-title">
              <div className="bk-card-head">
                <div className="bk-card-icon" aria-hidden="true"><CalendarClock size={20} /></div>
                <div className="bk-card-head-text">
                  <h3 className="bk-card-title" id="bk-auto-title">تنظیمات بکاپ‌گیری خودکار</h3>
                  <p className="bk-card-desc">زمان‌بندی تهیه‌ی خودکار نسخه پشتیبان و تعداد فایل‌های نگهداری‌شده. بکاپ‌های خودکار در پوشه فعال ذخیره می‌شوند.</p>
                </div>
                {autoDirty && <span className="bk-chip bk-chip-info">تغییرات ذخیره نشده</span>}
              </div>

              {/* وضعیت زمان‌بندی و مقصد — فقط از مقدار واقعی ذخیره‌شده در سرور */}
              <div className={`bk-sched ${schedule.enabled ? "is-on" : ""}`} aria-live="polite">
                <div className="bk-sched-title">
                  <span aria-hidden="true">{schedule.enabled ? "🟢" : "⚪"}</span>
                  {schedule.enabled ? "پشتیبان‌گیری خودکار فعال است" : "پشتیبان‌گیری خودکار غیرفعال است"}
                </div>
                <div className="bk-sched-grid">
                  {schedule.enabled && (
                    <>
                      <div><span>تناوب</span><strong>{BACKUP_FREQUENCY_LABELS[schedule.frequency] || schedule.frequency}</strong></div>
                      <div>
                        <span>ساعت اجرا</span>
                        <strong>
                          <span className="bk-mono">{schedule.time}</span>
                          {(schedule.frequency === "every6h" || schedule.frequency === "every12h") && " (فقط دقیقه)"}
                        </strong>
                      </div>
                      <div><span>اجرای بعدی</span><strong>{schedule.nextRunAt ? fmtDateTime(schedule.nextRunAt, tz) : "نامشخص"}</strong></div>
                    </>
                  )}
                  <div><span>تعداد نگهداری در هر پوشه</span><strong>{toFa(schedule.retentionCount)} فایل</strong></div>
                  <div><span>آخرین بکاپ خودکار</span><strong>{schedule.lastScheduledAt ? fmtDateTime(schedule.lastScheduledAt, tz) : "هنوز انجام نشده"}</strong></div>
                  <div className="bk-sched-wide">
                    <span>مسیر پوشه مقصد{activeFolder ? ` — «${activeFolder.name}»` : ""}</span>
                    <strong className="bk-mono">{activeFolder ? activeFolder.path : "—"}</strong>
                  </div>
                </div>
              </div>

              <form onSubmit={saveAutoBackup} noValidate style={{ display: "flex", flexDirection: "column", gap: 16 }}>
                <div className="bk-toggle-row">
                  <div className="bk-toggle-text">
                    <label htmlFor="bk-auto-enabled">وضعیت پشتیبان‌گیری خودکار</label>
                    <span className="field-hint">با فعال‌بودن، سیستم طبق تناوب و ساعت زیر خودکار پشتیبان می‌گیرد.</span>
                  </div>
                  <div className="bk-toggle-ctl">
                    <span className={`bk-toggle-state ${autoForm.enabled ? "on" : ""}`}>{autoForm.enabled ? "فعال" : "غیرفعال"}</span>
                    <button
                      type="button" id="bk-auto-enabled" role="switch" aria-checked={autoForm.enabled}
                      className={`bk-switch ${autoForm.enabled ? "is-on" : ""}`} disabled={anyBusy}
                      onClick={() => setAuto({ enabled: !autoForm.enabled })}
                    >
                      <span className="bk-switch-knob" />
                    </button>
                  </div>
                </div>
                {autoErrors.backupAutoEnabled && <span className="field-error" role="alert">{autoErrors.backupAutoEnabled}</span>}

                <div className="bk-grid">
                  <div className={`field bk-field ${autoErrors.backupAutoFrequency ? "has-error" : ""}`}>
                    <label htmlFor="bk-auto-frequency">تناوب</label>
                    <select id="bk-auto-frequency" value={autoForm.frequency} onChange={(e) => setAuto({ frequency: e.target.value })} disabled={!autoForm.enabled || anyBusy}>
                      {Object.entries(BACKUP_FREQUENCY_LABELS).map(([value, label]) => <option key={value} value={value}>{label}</option>)}
                    </select>
                    {autoErrors.backupAutoFrequency && <span className="field-error" role="alert">{autoErrors.backupAutoFrequency}</span>}
                  </div>
                  <div className={`field bk-field ${autoErrors.backupAutoTime ? "has-error" : ""}`}>
                    <label htmlFor="bk-auto-time">ساعت اجرا (به وقت سرور)</label>
                    <input id="bk-auto-time" type="time" value={autoForm.time} onChange={(e) => setAuto({ time: e.target.value })} disabled={!autoForm.enabled || anyBusy} />
                    {(autoForm.frequency === "every6h" || autoForm.frequency === "every12h") && (
                      <span className="field-hint">برای «هر ۶/۱۲ ساعت» فقط دقیقه‌ی این ساعت مهم است.</span>
                    )}
                    {autoErrors.backupAutoTime && <span className="field-error" role="alert">{autoErrors.backupAutoTime}</span>}
                  </div>
                  <div className={`field bk-field ${autoErrors.backupRetentionCount ? "has-error" : ""}`}>
                    <label htmlFor="bk-auto-retention">تعداد فایل‌های نگه‌داشته‌شده در هر پوشه</label>
                    <div className="bk-unit">
                      <input id="bk-auto-retention" type="number" inputMode="numeric" min="1" max="200" value={autoForm.retentionCount} onChange={(e) => setAuto({ retentionCount: e.target.value })} disabled={anyBusy} />
                      <span className="bk-unit-label">فایل</span>
                    </div>
                    <span className="field-hint">بین ۱ تا ۲۰۰ — فقط در «پوشه‌ای که بکاپ جدید در آن ذخیره می‌شود»، قدیمی‌ترین فایل‌های اضافه حذف می‌شوند؛ پوشه‌های دیگر دست‌نخورده می‌مانند.</span>
                    {autoErrors.backupRetentionCount && <span className="field-error" role="alert">{autoErrors.backupRetentionCount}</span>}
                  </div>
                </div>

                <p className="field-hint" style={{ margin: 0 }}>
                  اگر سرور در ساعت برنامه خاموش بوده باشد، بعد از روشن شدن خودکار یک پشتیبان جبرانی گرفته می‌شود.
                </p>

                <div className="bk-form-actions">
                  <button className="btn btn-primary btn-sm" type="submit" disabled={anyBusy || !autoDirty} aria-busy={autoSaving}>
                    {autoSaving ? "در حال ذخیره..." : "ذخیره تنظیمات پشتیبان‌گیری خودکار"}
                  </button>
                  {autoDirty && (
                    <button type="button" className="btn btn-ghost btn-sm" disabled={anyBusy} onClick={() => { setAutoForm(autoFormFromSchedule(schedule)); setAutoErrors({}); }}>
                      لغو تغییرات
                    </button>
                  )}
                </div>
              </form>

              <div className="bk-note">
                <Info size={16} aria-hidden="true" />
                نکته: بکاپ‌ها در پوشه خصوصی سرور ذخیره می‌شوند و فقط سوپر ادمین به آن‌ها دسترسی دارد. برای امنیت بیشتر، از پوشه‌های مشخص‌شده در لیست بالا استفاده کنید.
              </div>
            </section>
          )}
        </>
      )}

      {/* ---------- مودال تغییر پوشه فعال ---------- */}
      <GlobalModal
        isOpen={activateOpen}
        onClose={() => { if (!activating) setActivateOpen(false); }}
        size="sm"
        title="تغییر پوشه فعال بکاپ"
        className="bk-modal"
        closeOnOverlayClick={!activating}
        closeOnEsc={!activating}
        hideCloseButton={activating}
        footer={
          <>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setActivateOpen(false)} disabled={activating}>انصراف</button>
            <button type="button" className="btn btn-primary btn-sm" disabled={activating || !activateChoice || activateChoice === activeFolderId}
              onClick={() => activateFolder(activateChoice, { fromModal: true })} aria-busy={activating}>
              {activating ? "در حال ذخیره..." : "تأیید پوشه"}
            </button>
          </>
        }
      >
        <p style={{ marginTop: 0, lineHeight: 1.9 }}>
          بکاپ‌های بعدی (دستی و خودکار) در پوشه‌ی انتخاب‌شده ذخیره می‌شوند. بکاپ‌های قبلی حذف یا جابه‌جا نمی‌شوند.
        </p>
        <div className="bk-radio-list" role="radiogroup" aria-label="پوشه مقصد بکاپ">
          {folders.map((f) => (
            <label key={f.id} className={`bk-radio ${activateChoice === f.id ? "is-checked" : ""} ${f.writable ? "" : "is-disabled"}`}>
              <input type="radio" name="bk-active-folder" value={f.id} checked={activateChoice === f.id} disabled={!f.writable || activating}
                onChange={() => { setActivateChoice(f.id); setActivateError(""); }} />
              <Folder size={16} aria-hidden="true" />
              <span className="bk-radio-name">{f.name}</span>
              <span className="bk-folder-count">{toFa(f.count)}</span>
            </label>
          ))}
        </div>
        {activateError && <div style={{ marginTop: 12 }}><Alert tone="error" icon={<AlertTriangle size={18} />} role="alert">{activateError}</Alert></div>}
      </GlobalModal>

      {/* ---------- مودال بازیابی ---------- */}
      <GlobalModal
        isOpen={!!restoreTarget}
        onClose={closeRestoreModal}
        size="md"
        title="بازیابی دیتابیس"
        className="bk-modal"
        closeOnOverlayClick={!restoring}
        closeOnEsc={!restoring}
        hideCloseButton={restoring}
        footer={
          restoreTarget && (
            <>
              <button type="button" className="btn btn-ghost btn-sm" onClick={closeRestoreModal} disabled={restoring}>انصراف</button>
              <button type="button" className="btn btn-danger btn-sm" onClick={confirmRestore} disabled={!restoreConfirmMatches || restoring} aria-busy={restoring}>
                {restoring ? "در حال بازیابی..." : "تأیید و بازیابی دیتابیس"}
              </button>
            </>
          )
        }
      >
        {restoreTarget && (
          <>
            <div className="bk-modal-warning">
              <Alert tone="error" icon={<AlertTriangle size={18} />} role="alert">
                <strong>هشدار:</strong> با بازیابی این نسخه، اطلاعات فعلی دیتابیس با اطلاعات موجود در این Backup جایگزین می‌شود. این عملیات حساس است.
              </Alert>
            </div>
            <div className="bk-modal-warning">
              <Alert tone="info" icon={<ShieldCheck size={18} />}>
                قبل از بازیابی، سیستم به‌صورت خودکار یک نسخه پشتیبان ایمنی از وضعیت فعلی (در پوشه فعال) تهیه می‌کند.
              </Alert>
            </div>

            <div className="bk-info-grid">
              <div className="is-wide">
                <span>فایل انتخاب‌شده</span>
                <strong className="bk-mono" style={{ wordBreak: "break-all" }}>{restoreTarget.filename}</strong>
              </div>
              <div><span>پوشه</span><strong>{folderNameOf(restoreTarget.folderId) || "—"}</strong></div>
              <div><span>نوع پشتیبان</span><strong><TypeBadge type={restoreTarget.type} /></strong></div>
              <div><span>حجم فایل</span><strong className="bk-size">{formatBackupSize(restoreTarget.size)}</strong></div>
              <div><span>تاریخ ایجاد</span><strong>{fmtDateTime(restoreTarget.createdAt, tz)}</strong></div>
            </div>

            <div className={`bk-confirm-input ${confirmText ? (restoreConfirmMatches ? "is-match" : "is-mismatch") : ""}`}>
              <label htmlFor="bk-restore-confirm">برای تأیید، نام دقیق فایل Backup را وارد کنید.</label>
              <input
                id="bk-restore-confirm" type="text" value={confirmText}
                onChange={(e) => { setConfirmText(e.target.value); setRestoreError(""); }}
                placeholder="نام دقیق فایل را وارد کنید"
                disabled={restoring} autoFocus autoComplete="off" spellCheck={false}
              />
              {confirmText && (
                restoreConfirmMatches
                  ? <span className="bk-confirm-hint ok"><Check size={14} />نام فایل مطابقت دارد.</span>
                  : <span className="bk-confirm-hint bad"><X size={14} />نام وارد شده با نام فایل پشتیبان مطابقت ندارد.</span>
              )}
            </div>

            {restoreError && (
              <div style={{ marginTop: 12 }}>
                <Alert tone="error" icon={<AlertTriangle size={18} />} role="alert">{restoreError}</Alert>
              </div>
            )}
          </>
        )}
      </GlobalModal>

      {/* ---------- مودال حذف بکاپ ---------- */}
      <GlobalModal
        isOpen={!!deleteTarget}
        onClose={closeDeleteModal}
        size="sm"
        title="حذف نسخه پشتیبان"
        className="bk-modal"
        closeOnOverlayClick={!deleting}
        closeOnEsc={!deleting}
        hideCloseButton={deleting}
        footer={
          deleteTarget && (
            <>
              <button type="button" className="btn btn-ghost btn-sm" onClick={closeDeleteModal} disabled={deleting}>انصراف</button>
              <button type="button" className="btn btn-danger btn-sm" onClick={confirmDelete} disabled={deleting} aria-busy={deleting}>
                {deleting ? "در حال حذف..." : "حذف نسخه پشتیبان"}
              </button>
            </>
          )
        }
      >
        {deleteTarget && (
          <>
            <p style={{ marginTop: 0, lineHeight: 1.9 }}>
              آیا مطمئن هستید که می‌خواهید این نسخه پشتیبان را حذف کنید؟ این عملیات قابل بازگشت نیست.
            </p>
            <div className="bk-info-grid">
              <div className="is-wide">
                <span>فایل انتخاب‌شده</span>
                <strong className="bk-mono" style={{ wordBreak: "break-all" }}>{deleteTarget.filename}</strong>
              </div>
            </div>
            {deleteError && <Alert tone="error" icon={<AlertTriangle size={18} />} role="alert">{deleteError}</Alert>}
          </>
        )}
      </GlobalModal>
    </div>
  );
}

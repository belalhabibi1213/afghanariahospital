import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Users, User, Stethoscope, UserCog, ShieldCheck, Search, RotateCcw, Lock, CircleCheck, TriangleAlert, ChevronRight, ChevronLeft } from "lucide-react";
import { apiRequest } from "../../../../utils/api.js";
import { useAuth } from "../../../../context/AuthContext.jsx";
import GlobalModal from "../../../../components/GlobalModal.jsx";

const PAGE_SIZE = 15;
const ROLE_META = {
  user: { label: "بیمار", Icon: User },
  doctor: { label: "داکتر", Icon: Stethoscope },
  admin: { label: "ادمین", Icon: UserCog },
  superadmin: { label: "مدیر کل", Icon: ShieldCheck },
};
// نقش‌های قابل تخصیص از این بخش. «داکتر» عمداً نیست: بک‌اند تبدیل حساب دیگر به داکتر را
// رد می‌کند (باید از «حساب‌های داکتر» ساخته شود). «مدیر کل» هم هرگز تخصیص‌دادنی نیست.
const ASSIGNABLE = ["user", "admin"];

const fa = (n) => Number(n || 0).toLocaleString("fa-IR-u-ca-persian");
const norm = (s) => String(s || "").toLowerCase();

function RoleBadge({ role }) {
  const m = ROLE_META[role] || { label: role || "-", Icon: User };
  return (
    <span className={`ra-badge ra-role-${ROLE_META[role] ? role : "other"}`}>
      <m.Icon size={13} aria-hidden="true" /> {m.label}
    </span>
  );
}

function StatusBadge({ u }) {
  if (u.isActive === undefined || u.isActive === null) return <span className="ra-muted">-</span>;
  return u.isActive ? <span className="ra-status ra-on">فعال</span> : <span className="ra-status ra-off">غیرفعال</span>;
}

function initials(name) {
  const parts = String(name || "").trim().split(/\s+/).filter(Boolean);
  return (parts[0]?.[0] || "?") + (parts[1]?.[0] ? "\u200c" + parts[1][0] : "");
}

export default function RoleAssignment() {
  const { user: me } = useAuth();
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [page, setPage] = useState(1);
  const [target, setTarget] = useState(null); // کاربری که نقشش در حال تغییر است
  const [newRole, setNewRole] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [saving, setSaving] = useState(false);
  const [modalError, setModalError] = useState("");
  const [toast, setToast] = useState("");
  const toastTimer = useRef(null);

  const load = useCallback(() => {
    setLoading(true);
    setError("");
    apiRequest("/superadmin/users")
      .then((d) => setUsers(d.users || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);
  useEffect(load, [load]);
  useEffect(() => () => clearTimeout(toastTimer.current), []);

  const counts = useMemo(() => {
    const c = { total: users.length, user: 0, doctor: 0, admin: 0, superadmin: 0 };
    users.forEach((u) => { if (c[u.role] !== undefined) c[u.role] += 1; });
    return c;
  }, [users]);

  const filtered = useMemo(() => {
    const q = norm(search.trim());
    return users.filter((u) => (!roleFilter || u.role === roleFilter) && (!q || norm(u.fullName).includes(q) || norm(u.email).includes(q)));
  }, [users, search, roleFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages);
  const pageRows = filtered.slice((safePage - 1) * PAGE_SIZE, safePage * PAGE_SIZE);

  function resetFilters() { setSearch(""); setRoleFilter(""); setPage(1); }

  function openChange(u) {
    setTarget(u);
    setNewRole(u.role === "admin" ? "user" : "admin");
    setConfirming(false);
    setModalError("");
  }
  function closeModal() { if (!saving) setTarget(null); }

  async function save() {
    // مدافعه‌ی سمت کلاینت؛ مرجع اصلی امنیت همچنان بک‌اند است
    if (!target || newRole === "superadmin" || !ASSIGNABLE.includes(newRole) || target.id === me?.id || target.role === "superadmin") return;
    setSaving(true);
    setModalError("");
    try {
      await apiRequest(`/superadmin/users/${target.id}/role`, { method: "PUT", body: { role: newRole } });
      setTarget(null);
      setToast("نقش کاربر با موفقیت تغییر کرد.");
      clearTimeout(toastTimer.current);
      toastTimer.current = setTimeout(() => setToast(""), 4000);
      load();
    } catch (err) {
      setModalError(err.message);
      setConfirming(false);
    } finally {
      setSaving(false);
    }
  }

  const cards = [
    { key: "total", label: "کل کاربران", Icon: Users, value: counts.total },
    { key: "user", label: "بیمار", Icon: User, value: counts.user },
    { key: "doctor", label: "داکتر", Icon: Stethoscope, value: counts.doctor },
    { key: "admin", label: "ادمین", Icon: UserCog, value: counts.admin },
    { key: "superadmin", label: "مدیر کل", Icon: ShieldCheck, value: counts.superadmin },
  ];

  function action(u) {
    if (u.role === "superadmin") return <span className="role-locked ra-locked" title="نقش حساب مدیر کل قابل تغییر نیست"><Lock size={12} aria-hidden="true" /> مدیر کل — غیرقابل تغییر</span>;
    if (u.id === me?.id) return <span className="role-locked ra-locked" title="نمی‌توانید نقش خودتان را تغییر دهید"><Lock size={12} aria-hidden="true" /> حساب شما</span>;
    return <button type="button" className="btn btn-ghost btn-sm" onClick={() => openChange(u)}>تغییر نقش</button>;
  }

  return (
    <div className="ra-scope">
      <header className="ra-header">
        <span className="ra-header-icon" aria-hidden="true"><UserCog size={22} /></span>
        <div>
          <h2>تخصیص و مدیریت نقش کاربران</h2>
          <p>مدیریت دسترسی کاربران سیستم بر اساس نقش سازمانی</p>
        </div>
      </header>

      {toast && <div className="ra-toast" role="status"><CircleCheck size={16} aria-hidden="true" /> {toast}</div>}

      <section className="ra-cards" aria-label="خلاصه کاربران">
        {cards.map((c) => (
          <div className="ra-card" key={c.key}>
            <span className="ra-card-label"><c.Icon size={15} aria-hidden="true" /> {c.label}</span>
            {loading ? <span className="ra-skel ra-skel-num" /> : <strong>{error ? "—" : fa(c.value)}</strong>}
          </div>
        ))}
      </section>

      <div className="ra-panel">
        <div className="ra-toolbar">
          <label className="ra-search">
            <Search size={16} aria-hidden="true" />
            <input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="جستجوی نام یا ایمیل..." aria-label="جستجوی نام یا ایمیل" />
          </label>
          <select className="dash-select ra-filter" value={roleFilter} onChange={(e) => { setRoleFilter(e.target.value); setPage(1); }} aria-label="فیلتر نقش">
            <option value="">همه نقش‌ها</option>
            {Object.entries(ROLE_META).map(([v, m]) => <option key={v} value={v}>{m.label}</option>)}
          </select>
          <button type="button" className="btn btn-ghost btn-sm" onClick={resetFilters}><RotateCcw size={14} aria-hidden="true" /> پاک کردن فیلترها</button>
        </div>

        {error && (
          <div className="ra-error" role="alert">
            <TriangleAlert size={18} aria-hidden="true" />
            <span>{error}</span>
            <button type="button" className="btn btn-ghost btn-sm" onClick={load}>تلاش مجدد</button>
          </div>
        )}

        {loading && (
          <div className="ra-skel-list" aria-busy="true" aria-label="در حال بارگذاری">
            {Array.from({ length: 6 }).map((_, i) => (
              <div className="ra-skel-row" key={i}><span className="ra-skel ra-skel-av" /><span className="ra-skel" style={{ flex: 1 }} /><span className="ra-skel" style={{ flex: 1 }} /><span className="ra-skel" style={{ width: 80 }} /></div>
            ))}
          </div>
        )}

        {!loading && !error && users.length === 0 && <div className="ra-empty">کاربری برای نمایش وجود ندارد</div>}
        {!loading && !error && users.length > 0 && filtered.length === 0 && (
          <div className="ra-empty">کاربری مطابق فیلترها پیدا نشد.<br /><button type="button" className="btn btn-ghost btn-sm" onClick={resetFilters}>پاک کردن فیلترها</button></div>
        )}

        {!loading && !error && pageRows.length > 0 && (
          <>
            <div className="ra-table-wrap">
              <table className="ra-table">
                <thead><tr><th>کاربر</th><th>ایمیل</th><th>نقش فعلی</th><th>وضعیت</th><th>عملیات</th></tr></thead>
                <tbody>
                  {pageRows.map((u) => (
                    <tr key={u.id}>
                      <td><span className="ra-user"><span className="ra-avatar" aria-hidden="true">{initials(u.fullName)}</span><span className="ra-name">{u.fullName}</span></span></td>
                      <td className="ra-email" dir="ltr">{u.email}</td>
                      <td><RoleBadge role={u.role} /></td>
                      <td><StatusBadge u={u} /></td>
                      <td>{action(u)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <ul className="ra-mobile-list">
              {pageRows.map((u) => (
                <li key={u.id} className="ra-mcard">
                  <span className="ra-user"><span className="ra-avatar" aria-hidden="true">{initials(u.fullName)}</span><span className="ra-name">{u.fullName}</span></span>
                  <span className="ra-email" dir="ltr">{u.email}</span>
                  <span className="ra-mrow"><RoleBadge role={u.role} /><StatusBadge u={u} /></span>
                  <span>{action(u)}</span>
                </li>
              ))}
            </ul>

            <nav className="ra-pagination" aria-label="صفحه‌بندی">
              <span>{fa(filtered.length)} کاربر</span>
              <div>
                <button type="button" className="btn btn-ghost btn-sm" disabled={safePage <= 1} onClick={() => setPage(safePage - 1)}><ChevronRight size={15} aria-hidden="true" /> قبلی</button>
                <b>صفحه {fa(safePage)} از {fa(totalPages)}</b>
                <button type="button" className="btn btn-ghost btn-sm" disabled={safePage >= totalPages} onClick={() => setPage(safePage + 1)}>بعدی <ChevronLeft size={15} aria-hidden="true" /></button>
              </div>
            </nav>
          </>
        )}
      </div>

      <GlobalModal isOpen={!!target} onClose={closeModal} size="md" title={confirming ? "تأیید تغییر نقش" : "تغییر نقش کاربر"} labelledBy="ra-modal-title">
        {target && !confirming && (
          <div className="ra-modal">
            <dl className="ra-info">
              <div><dt>نام کاربر</dt><dd>{target.fullName}</dd></div>
              <div><dt>ایمیل</dt><dd dir="ltr">{target.email}</dd></div>
              <div><dt>نقش فعلی</dt><dd><RoleBadge role={target.role} /></dd></div>
            </dl>
            <fieldset className="ra-options">
              <legend>نقش جدید</legend>
              {ASSIGNABLE.map((r) => {
                const M = ROLE_META[r];
                return (
                  <label key={r} className={`ra-option ${newRole === r ? "is-selected" : ""} ${target.role === r ? "is-current" : ""}`}>
                    <input type="radio" name="ra-new-role" value={r} checked={newRole === r} disabled={target.role === r} onChange={() => setNewRole(r)} />
                    <M.Icon size={16} aria-hidden="true" /> {M.label}{target.role === r && <small>(نقش فعلی)</small>}
                  </label>
                );
              })}
            </fieldset>
            <p className="ra-hint">نقش «داکتر» از بخش «حساب‌های داکتر» ساخته می‌شود و نقش «مدیر کل» از این بخش قابل تخصیص نیست.</p>
            {modalError && <div className="form-message error">{modalError}</div>}
            <div className="ra-actions">
              <button type="button" className="btn btn-primary btn-sm" disabled={!newRole || newRole === target.role} onClick={() => setConfirming(true)}>ذخیره تغییرات</button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={closeModal}>انصراف</button>
            </div>
          </div>
        )}
        {target && confirming && (
          <div className="ra-modal">
            <p className="ra-confirm">آیا مطمئن هستید که می‌خواهید نقش این کاربر را تغییر دهید؟</p>
            <p className="ra-confirm-detail"><b>{target.fullName}</b>: <RoleBadge role={target.role} /> ← <RoleBadge role={newRole} /></p>
            {newRole === "admin" && <p className="ra-warn"><TriangleAlert size={14} aria-hidden="true" /> نقش ادمین به بخش‌های مدیریتی سیستم دسترسی دارد.</p>}
            {modalError && <div className="form-message error">{modalError}</div>}
            <div className="ra-actions">
              <button type="button" className="btn btn-primary btn-sm" disabled={saving} onClick={save}>{saving ? "در حال ذخیره..." : "تأیید تغییر"}</button>
              <button type="button" className="btn btn-ghost btn-sm" disabled={saving} onClick={() => setConfirming(false)}>انصراف</button>
            </div>
          </div>
        )}
      </GlobalModal>
    </div>
  );
}

import { useEffect, useState } from "react";
import {
  Activity, Users, CalendarDays, Download, Search, Eye, RotateCcw, LayoutList,
  GitCommitHorizontal, Clock, Globe, Monitor, ShieldCheck, UserCog, Stethoscope, User,
} from "lucide-react";
import { apiRequest, API_BASE } from "../../../../utils/api.js";
import { defaultLogDateFrom } from "../shared.js";
import { JalaliDateInput } from "../../../../components/JalaliDateInput.jsx";
import {
  RoleBadge, roleMeta, LOG_ROLES, faNum, faDateTime, faDate, faTime, todayStr, shortUserAgent,
  fetchLogTotal, downloadLogCsv, LogKpiCard, SkeletonRows, SkeletonFeed, LogEmptyState,
  LogPagination, LogDrawer, DetailRow,
} from "../logsUi.jsx";

const ACTIVITY_ROLE_TABS = [
  { value: "", label: "همه فعالیت‌ها", Icon: Users },
  { value: "superadmin", label: "فعالیت‌های سوپر ادمین", Icon: ShieldCheck },
  { value: "admin", label: "فعالیت‌های ادمین", Icon: UserCog },
  { value: "doctor", label: "فعالیت‌های داکتر", Icon: Stethoscope },
  { value: "user", label: "فعالیت‌های بیمار", Icon: User },
];

export default function ActivityLogs() {
  const [logs, setLogs] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, limit: 21, totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);
  const [detail, setDetail] = useState(null);
  const [view, setView] = useState("table"); // table | timeline
  const [kpis, setKpis] = useState(null); // null = در حال بارگذاری

  // فیلتر نقش جدا از بقیه فیلترها نگه‌داشته می‌شود چون با کلیک بلافاصله اعمال می‌شود
  // (بدون نیاز به دکمه «اعمال فیلتر») در حالی که جست‌وجو/تاریخ مثل قبل با دکمه اعمال می‌شوند
  const [roleTab, setRoleTab] = useState("");
  const [filters, setFilters] = useState({ search: "", dateFrom: defaultLogDateFrom(), dateTo: "" });
  const [appliedFilters, setAppliedFilters] = useState(filters);
  const [page, setPage] = useState(1);

  function buildQuery(extra = {}) {
    const params = new URLSearchParams();
    if (appliedFilters.search) params.set("search", appliedFilters.search);
    if (roleTab) params.set("role", roleTab);
    if (appliedFilters.dateFrom) params.set("dateFrom", appliedFilters.dateFrom);
    if (appliedFilters.dateTo) params.set("dateTo", appliedFilters.dateTo);
    Object.entries(extra).forEach(([k, v]) => params.set(k, v));
    return params.toString();
  }

  function selectRole(value) {
    setRoleTab(value);
    setPage(1);
  }

  // KPIها فقط از همان API فعلی (pagination.total با limit=1) محاسبه می‌شوند؛ اگر درخواستی
  // شکست بخورد مقدار «—» نمایش داده می‌شود و هیچ داده‌ی ساختگی‌ای ساخته نمی‌شود.
  useEffect(() => {
    let cancelled = false;
    const path = "/superadmin/activity-logs";
    const t = todayStr();
    const safe = (p) => p.then((r) => r.total).catch(() => null);
    Promise.all([
      safe(fetchLogTotal(path)),
      safe(fetchLogTotal(path, { dateFrom: t, dateTo: t })),
      safe(fetchLogTotal(path, { role: "admin" })),
      safe(fetchLogTotal(path, { role: "doctor" })),
      safe(fetchLogTotal(path, { role: "user" })),
    ]).then(([total, today, admin, doctor, patient]) => {
      if (!cancelled) setKpis({ total, today, admin, doctor, patient });
    });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    apiRequest(`/superadmin/activity-logs?${buildQuery({ page, limit: 21 })}`)
      .then((d) => {
        if (cancelled) return;
        setLogs(d.logs);
        setPagination(d.pagination);
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appliedFilters, roleTab, page]);

  function applyFilters(e) {
    e.preventDefault();
    setPage(1);
    setAppliedFilters(filters);
  }

  function resetFilters() {
    const cleared = { search: "", dateFrom: defaultLogDateFrom(), dateTo: "" };
    setFilters(cleared);
    setAppliedFilters(cleared);
    setRoleTab("");
    setPage(1);
  }

  async function handleExport() {
    setExporting(true);
    setError("");
    try {
      await downloadLogCsv(
        `${API_BASE}/superadmin/activity-logs/export?${buildQuery()}`,
        `activity-logs-${Date.now()}.csv`,
        "خروجی گرفتن از لاگ‌ها ناموفق بود"
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setExporting(false);
    }
  }

  // گروه‌بندی رکوردهای همین صفحه بر اساس روز برای نمای Timeline (فقط داده‌ی واقعی دریافت‌شده)
  const groups = [];
  logs.forEach((l) => {
    const key = faDate(l.createdAt);
    const last = groups[groups.length - 1];
    if (last && last.key === key) last.items.push(l);
    else groups.push({ key, items: [l] });
  });

  const activeTab = ACTIVITY_ROLE_TABS.find((t) => t.value === roleTab) || ACTIVITY_ROLE_TABS[0];
  const kpiLoading = kpis === null;
  const k = (key) => (kpiLoading || kpis[key] === null ? null : faNum(kpis[key]));

  return (
    <div className="lg-scope lg-activity">
      <header className="lg-header">
        <span className="lg-header-icon" aria-hidden="true"><Activity size={24} /></span>
        <div className="lg-header-text">
          <h2>لاگ فعالیت‌های سیستم</h2>
          <p>تاریخچه فعالیت کاربران و رویدادهای مهم سیستم</p>
        </div>
        <button type="button" className="btn btn-primary btn-sm lg-export" onClick={handleExport} disabled={exporting}>
          <Download size={15} aria-hidden="true" />
          {exporting ? "در حال آماده‌سازی خروجی..." : "خروجی CSV"}
        </button>
      </header>

      <section className="lg-kpis" aria-label="خلاصه فعالیت‌ها">
        <LogKpiCard icon={Activity} label="کل فعالیت‌ها" value={k("total")} hint="در دوره‌ی نگهداری" tone="neutral" loading={kpiLoading} />
        <LogKpiCard icon={CalendarDays} label="فعالیت‌های امروز" value={k("today")} tone="admin" loading={kpiLoading} />
        <LogKpiCard icon={UserCog} label="فعالیت‌های ادمین" value={k("admin")} tone="admin" loading={kpiLoading} />
        <LogKpiCard icon={Stethoscope} label="فعالیت‌های داکتر" value={k("doctor")} tone="doctor" loading={kpiLoading} />
        <LogKpiCard icon={User} label="فعالیت‌های بیمار" value={k("patient")} tone="user" loading={kpiLoading} />
      </section>

      <div className="lg-panel">
        <div className="lg-tabs" role="tablist" aria-label="فیلتر نقش لاگ فعالیت‌ها">
          {ACTIVITY_ROLE_TABS.map((tab) => {
            const active = roleTab === tab.value;
            return (
              <button
                key={tab.value}
                type="button"
                role="tab"
                aria-selected={active}
                className={`lg-tab lg-tone-${tab.value || "neutral"} ${active ? "is-active" : ""}`}
                onClick={() => selectRole(tab.value)}
              >
                <tab.Icon size={15} aria-hidden="true" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <form className="lg-toolbar" onSubmit={applyFilters}>
          <label className="lg-search">
            <Search size={16} aria-hidden="true" />
            <input
              value={filters.search}
              onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
              placeholder="جستجو در فعالیت، کاربر یا IP..."
              aria-label="جستجو در فعالیت، جزئیات، نام کاربر یا IP"
            />
          </label>
          <div className="lg-tfield">
            <span>نقش</span>
            <select className="dash-select" value={roleTab} onChange={(e) => selectRole(e.target.value)}>
              <option value="">همه نقش‌ها</option>
              {Object.entries(LOG_ROLES).map(([value, r]) => <option key={value} value={value}>{r.label}</option>)}
            </select>
          </div>
          <div className="lg-tfield">
            <span>از تاریخ</span>
            <JalaliDateInput value={filters.dateFrom} onChange={(e) => setFilters((f) => ({ ...f, dateFrom: e.target.value }))} />
          </div>
          <div className="lg-tfield">
            <span>تا تاریخ</span>
            <JalaliDateInput value={filters.dateTo} onChange={(e) => setFilters((f) => ({ ...f, dateTo: e.target.value }))} />
          </div>
          <div className="lg-toolbar-actions">
            <button className="btn btn-primary btn-sm" type="submit">اعمال فیلتر</button>
            <button className="btn btn-ghost btn-sm" type="button" onClick={resetFilters}>
              <RotateCcw size={14} aria-hidden="true" /> پاک کردن
            </button>
          </div>
        </form>

        <div className="lg-subbar">
          <span className="lg-result-line">
            {!loading && <>{activeTab.label} — <b>{faNum(pagination.total)}</b> رکورد</>}
          </span>
          <div className="lg-view-switch" role="group" aria-label="نحوه نمایش">
            <button type="button" className={view === "table" ? "is-active" : ""} aria-pressed={view === "table"} onClick={() => setView("table")}>
              <LayoutList size={15} aria-hidden="true" /> جدول
            </button>
            <button type="button" className={view === "timeline" ? "is-active" : ""} aria-pressed={view === "timeline"} onClick={() => setView("timeline")}>
              <GitCommitHorizontal size={15} aria-hidden="true" /> خط زمانی
            </button>
          </div>
        </div>

        {error && <div className="form-message error">{error}</div>}

        {loading && (view === "table" ? <SkeletonRows rows={8} cols={7} /> : <SkeletonFeed rows={7} />)}

        {!loading && logs.length === 0 && !error && (
          <LogEmptyState message="هیچ فعالیتی مطابق فیلترهای انتخاب‌شده پیدا نشد." onReset={resetFilters} />
        )}

        {!loading && logs.length > 0 && view === "table" && (
          <div className="lg-table-wrap">
            <table className="lg-table">
              <thead>
                <tr>
                  <th>کاربر</th><th>نقش</th><th>فعالیت</th><th>جزئیات</th>
                  <th>IP</th><th>مرورگر</th><th>زمان</th><th aria-label="عملیات" />
                </tr>
              </thead>
              <tbody>
                {logs.map((l) => (
                  <tr key={l.id} onClick={() => setDetail(l)}>
                    <td className="lg-cell-user">{l.userName || "-"}</td>
                    <td><RoleBadge role={l.role} /></td>
                    <td className="lg-cell-action">{l.action}</td>
                    <td className="lg-cell-details">{l.details || "-"}</td>
                    <td className="lg-mono">{l.ipAddress || "-"}</td>
                    <td className="lg-cell-ua" title={l.userAgent || ""}>{shortUserAgent(l.userAgent) || l.userAgent || "-"}</td>
                    <td className="lg-cell-time">{faDateTime(l.createdAt)}</td>
                    <td>
                      <button
                        type="button"
                        className="btn btn-ghost btn-sm lg-view-btn"
                        onClick={(e) => { e.stopPropagation(); setDetail(l); }}
                      >
                        <Eye size={14} aria-hidden="true" /> جزئیات
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {!loading && logs.length > 0 && view === "timeline" && (
          <div className="lg-timeline">
            {groups.map((g) => (
              <section key={g.key} className="lg-tl-group">
                <h4 className="lg-tl-day">{g.key}</h4>
                <ol>
                  {g.items.map((l) => {
                    const { Icon } = roleMeta(l.role);
                    return (
                      <li key={l.id} className={`lg-tl-item lg-tone-${LOG_ROLES[l.role] ? l.role : "neutral"}`}>
                        <span className="lg-tl-dot" aria-hidden="true"><Icon size={14} /></span>
                        <button type="button" className="lg-tl-card" onClick={() => setDetail(l)}>
                          <span className="lg-tl-line1">
                            <b>{l.userName || "-"}</b>
                            <RoleBadge role={l.role} />
                            <span className="lg-tl-time"><Clock size={12} aria-hidden="true" /> {faTime(l.createdAt)}</span>
                          </span>
                          <span className="lg-tl-action">{l.action}</span>
                          {l.ipAddress && <span className="lg-tl-ip lg-mono"><Globe size={12} aria-hidden="true" /> {l.ipAddress}</span>}
                        </button>
                      </li>
                    );
                  })}
                </ol>
              </section>
            ))}
          </div>
        )}

        {!loading && logs.length > 0 && (
          <LogPagination page={page} totalPages={pagination.totalPages} total={pagination.total} onPage={setPage} />
        )}
      </div>

      <LogDrawer
        open={!!detail}
        onClose={() => setDetail(null)}
        title="جزئیات فعالیت"
        subtitle={detail ? faDateTime(detail.createdAt) : ""}
        icon={Activity}
        variant="activity"
      >
        {detail && (
          <div className="lg-detail-list">
            <DetailRow label="کاربر">{detail.userName || "-"}</DetailRow>
            <DetailRow label="نقش"><RoleBadge role={detail.role} /></DetailRow>
            <DetailRow label="فعالیت">{detail.action}</DetailRow>
            <DetailRow label="جزئیات کامل">
              <div className="lg-longtext">{detail.details || "-"}</div>
            </DetailRow>
            <DetailRow label="آدرس IP"><span className="lg-mono">{detail.ipAddress || "-"}</span></DetailRow>
            <DetailRow label="مرورگر">
              {shortUserAgent(detail.userAgent) && (
                <span className="lg-ua-short"><Monitor size={14} aria-hidden="true" /> {shortUserAgent(detail.userAgent)}</span>
              )}
              <div className="lg-longtext lg-mono lg-ua-full">{detail.userAgent || "-"}</div>
            </DetailRow>
            <DetailRow label="تاریخ و ساعت">{faDateTime(detail.createdAt)}</DetailRow>
          </div>
        )}
      </LogDrawer>
    </div>
  );
}

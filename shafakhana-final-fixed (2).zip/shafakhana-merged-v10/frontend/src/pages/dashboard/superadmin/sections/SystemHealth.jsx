import { useCallback, useEffect, useRef, useState } from "react";
import {
  Activity, AlertTriangle, CheckCircle2, CircleHelp, Clock, Database, DatabaseBackup,
  HardDrive, HeartPulse, Inbox, RefreshCw, Server, XCircle,
} from "lucide-react";
import { apiRequest } from "../../../../utils/api.js";
import "./SystemHealth.css";

const REFRESH_MS = 60000; // بروزرسانی خودکار هر ۶۰ ثانیه (رفتار قبلی حفظ شده است)

// برچسب‌های نمایشی (فقط Frontend). مقدار واقعی status از API تغییر نمی‌کند؛ اگر مقدار جدیدی
// برگردد، همان متن خام با ظاهر خنثی نمایش داده می‌شود.
const STATUS_META = {
  healthy: { name: "سالم", tone: "ok", Icon: CheckCircle2 },
  warning: { name: "هشدار", tone: "warn", Icon: AlertTriangle },
  error: { name: "خطا", tone: "danger", Icon: XCircle },
};
function statusMeta(status) {
  return STATUS_META[status] || { name: status ? String(status) : "نامشخص", tone: "neutral", Icon: CircleHelp };
}
const BACKUP_TYPE_FA = { manual: "دستی", auto: "خودکار", automatic: "خودکار", scheduled: "زمان‌بندی‌شده" };

const isNum = (v) => v !== null && v !== undefined && v !== "" && Number.isFinite(Number(v));
const fa = (v, opts) => (isNum(v) ? Number(v).toLocaleString("fa-IR-u-ca-persian", { useGrouping: false, ...opts }) : "—");
const obj = (v) => (v && typeof v === "object" && !Array.isArray(v) ? v : null);

function formatUptime(seconds) {
  if (!isNum(seconds)) return "—";
  const s = Number(seconds);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const parts = [];
  if (d) parts.push(`${fa(d)} روز`);
  if (h) parts.push(`${fa(h)} ساعت`);
  if (d === 0) parts.push(`${fa(m)} دقیقه`);
  return parts.join(" و ") || "کمتر از یک دقیقه";
}
function formatDateTime(value) {
  if (!value) return "—";
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleString("fa-IR-u-ca-persian");
}
// پیام خطا: عنوان ثابت فارسی + پیام کوتاه واقعیِ برگشتی (در صورت امن‌بودن)؛ بدون جزئیات فنی
function errInfo(err) {
  const msg = err && err.message ? String(err.message).trim() : "";
  const technical = /\bat\s+\S+\s*\(|node_modules|ER_[A-Z_]+|SQL|\.js:\d+/i.test(msg);
  return { detail: msg && msg.length <= 200 && !technical ? msg : "" };
}

function StatusChip({ status }) {
  const meta = statusMeta(status);
  return (
    <span className={`sh-chip sh-tone-${meta.tone}`}>
      <span className="sh-dot" aria-hidden="true" />{meta.name}
    </span>
  );
}

function HealthCard({ icon, title, section, meter, rows }) {
  const s = obj(section);
  const meta = statusMeta(s ? s.status : null);
  return (
    <section className={`sh-card sh-tone-${meta.tone}`}>
      <div className="sh-card-head">
        <div className="sh-card-icon" aria-hidden="true">{icon}</div>
        <h3 className="sh-card-title">{title}</h3>
        {s && <StatusChip status={s.status} />}
      </div>
      {!s ? (
        <div className="sh-state is-inline">
          <Inbox size={26} aria-hidden="true" />
          <p>اطلاعاتی برای نمایش وجود ندارد</p>
        </div>
      ) : (
        <>
          {s.message && <p className="sh-card-msg">{s.message}</p>}
          {meter && isNum(meter.percent) && (
            <div className="sh-meter">
              <div className="sh-meter-top"><span>{meter.label}</span><strong>{fa(meter.percent)}٪</strong></div>
              <div className="sh-bar" role="progressbar" aria-label={meter.label} aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.min(100, Math.max(0, Number(meter.percent)))}>
                <span style={{ width: `${Math.min(100, Math.max(0, Number(meter.percent)))}%` }} />
              </div>
            </div>
          )}
          <dl className="sh-rows">
            {rows.filter(Boolean).map(([label, value, ltr]) => (
              <div key={label} className="sh-row"><dt>{label}</dt><dd className={ltr ? "is-ltr" : undefined}>{value}</dd></div>
            ))}
          </dl>
        </>
      )}
    </section>
  );
}

function HealthSkeleton() {
  return (
    <div aria-busy="true" aria-label="در حال بررسی وضعیت سیستم" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="sh-skel" style={{ height: 92 }} />
      <div className="sh-grid">
        {Array.from({ length: 5 }).map((_, i) => <div key={i} className="sh-skel" style={{ height: 210 }} />)}
      </div>
    </div>
  );
}

export default function SystemHealth() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [refreshing, setRefreshing] = useState(true);
  const [checkedAt, setCheckedAt] = useState(null);
  const inFlight = useRef(false);
  const mounted = useRef(true);

  // همان API قبلی؛ از ارسال هم‌زمان دو درخواست جلوگیری می‌شود و بعد از خروج از صفحه state تغییر نمی‌کند
  const load = useCallback(() => {
    if (inFlight.current) return Promise.resolve();
    inFlight.current = true;
    setRefreshing(true);
    return apiRequest("/superadmin/system-health")
      .then((d) => {
        if (!mounted.current) return;
        const checked = d && d.checkedAt ? new Date(d.checkedAt) : null;
        setData(obj(d) || {});
        setError(null);
        setCheckedAt(checked && !Number.isNaN(checked.getTime()) ? checked : new Date());
      })
      .catch((err) => { if (mounted.current) setError(errInfo(err)); })
      .finally(() => {
        inFlight.current = false;
        if (mounted.current) setRefreshing(false);
      });
  }, []);

  useEffect(() => {
    mounted.current = true;
    load();
    const interval = setInterval(load, REFRESH_MS);
    return () => { mounted.current = false; clearInterval(interval); };
  }, [load]);

  const api = data ? obj(data.api) : null;
  const database = data ? obj(data.database) : null;
  const server = data ? obj(data.server) : null;
  const storage = data ? obj(data.storage) : null;
  const backup = data ? obj(data.backup) : null;

  const parts = [
    { title: "بک‌اند / API", section: api },
    { title: "دیتابیس MySQL", section: database },
    { title: "سرور", section: server },
    { title: "فضای ذخیره‌سازی", section: storage },
    { title: "آخرین پشتیبان", section: backup },
  ];
  const known = parts.filter((p) => p.section);
  const count = (st) => known.filter((p) => p.section.status === st).length;
  const attention = known.filter((p) => p.section.status === "warning" || p.section.status === "error").map((p) => p.title);
  const overallMeta = statusMeta(data ? data.overall : null);
  const OverallIcon = overallMeta.Icon;
  const overallMsg = !data || known.length === 0
    ? ""
    : data.overall === "healthy"
      ? "همه‌ی بخش‌های بررسی‌شده در وضعیت سالم هستند."
      : attention.length > 0
        ? `بخش‌های نیازمند توجه: ${attention.join("، ")}`
        : "";

  return (
    <div className="dash-card glass sh-scope">
      <header className="sh-header">
        <div className="sh-header-icon" aria-hidden="true"><HeartPulse size={24} /></div>
        <div className="sh-header-text">
          <h2>سلامت سیستم</h2>
          <p>وضعیت زنده‌ی زیرساخت: اتصال به دیتابیس، سرور بک‌اند، فضای ذخیره‌سازی و آخرین پشتیبان‌گیری. این بخش هر ۶۰ ثانیه به‌صورت خودکار بروزرسانی می‌شود.</p>
        </div>
        <div className="sh-header-actions">
          {checkedAt && (
            <span className="sh-updated" title={checkedAt.toLocaleString("fa-IR-u-ca-persian")}>
              <Clock size={14} aria-hidden="true" />
              آخرین بررسی: {checkedAt.toLocaleTimeString("fa-IR-u-ca-persian")}
            </span>
          )}
          <button type="button" className="btn btn-ghost btn-sm" onClick={load} disabled={refreshing} aria-busy={refreshing}>
            <RefreshCw size={14} className={refreshing ? "sh-spin" : undefined} aria-hidden="true" />
            {refreshing ? "در حال بررسی..." : "بررسی مجدد"}
          </button>
        </div>
      </header>

      {!data && !error && <HealthSkeleton />}

      {!data && error && (
        <div className="sh-state is-error" role="alert">
          <AlertTriangle size={36} aria-hidden="true" />
          <p>دریافت وضعیت سلامت سیستم با مشکل مواجه شد.</p>
          {error.detail && <small>{error.detail}</small>}
          <button type="button" className="btn btn-primary btn-sm" onClick={load} disabled={refreshing}>
            <RefreshCw size={14} className={refreshing ? "sh-spin" : undefined} aria-hidden="true" />
            {refreshing ? "در حال تلاش..." : "تلاش مجدد"}
          </button>
        </div>
      )}

      {data && (
        <>
          {error && (
            <div className="sh-alert" role="alert">
              <AlertTriangle size={18} aria-hidden="true" />
              <div className="sh-alert-text">
                <strong>بروزرسانی وضعیت با مشکل مواجه شد. اطلاعات زیر ممکن است قدیمی باشد.</strong>
                {error.detail}
              </div>
              <button type="button" className="btn btn-ghost btn-sm" onClick={load} disabled={refreshing}>تلاش مجدد</button>
            </div>
          )}

          {known.length === 0 ? (
            <div className="sh-state">
              <Inbox size={34} aria-hidden="true" />
              <p>اطلاعاتی برای نمایش وجود ندارد</p>
            </div>
          ) : (
            <>
              <div className={`sh-overall sh-tone-${overallMeta.tone}`}>
                <div className="sh-overall-icon" aria-hidden="true"><OverallIcon size={28} /></div>
                <div className="sh-overall-body">
                  <span className="sh-overall-label">وضعیت کلی سیستم</span>
                  <h3 className="sh-overall-title"><StatusChip status={data.overall} /></h3>
                  {overallMsg && <p className="sh-overall-msg">{overallMsg}</p>}
                </div>
                <div className="sh-counts">
                  <span className="sh-count sh-tone-ok"><strong>{fa(count("healthy"))}</strong>سالم</span>
                  <span className="sh-count sh-tone-warn"><strong>{fa(count("warning"))}</strong>هشدار</span>
                  <span className="sh-count sh-tone-danger"><strong>{fa(count("error"))}</strong>خطا</span>
                </div>
              </div>

              <div className="sh-grid">
                <HealthCard
                  icon={<Activity size={20} />} title="بک‌اند / API" section={api}
                  rows={[["زمان فعالیت سرور", api ? formatUptime(api.uptimeSeconds) : "—"]]}
                />
                <HealthCard
                  icon={<Database size={20} />} title="اتصال دیتابیس MySQL" section={database}
                  rows={[["زمان پاسخ", database && isNum(database.latencyMs) ? `${fa(database.latencyMs)} میلی‌ثانیه` : "—"]]}
                />
                <HealthCard
                  icon={<Server size={20} />} title="وضعیت سرور" section={server}
                  meter={server ? { label: "مصرف حافظه‌ی سیستم", percent: server.memoryUsedPercent } : null}
                  rows={server ? [
                    ["زمان فعالیت", formatUptime(server.uptimeSeconds)],
                    isNum(server.memoryTotalMB) && isNum(server.memoryFreeMB) ? ["حافظه‌ی آزاد", `${fa(server.memoryFreeMB)} از ${fa(server.memoryTotalMB)} MB`] : null,
                    ["حافظه‌ی پردازه", isNum(server.processMemoryMB) ? `${fa(server.processMemoryMB)} MB` : "—"],
                    server.platform && server.platform !== "win32" && isNum(server.loadAvg1m) ? ["بار پردازنده (۱ دقیقه)", fa(server.loadAvg1m, { maximumFractionDigits: 2 })] : null,
                    server.platform ? ["سیستم‌عامل", String(server.platform), true] : null,
                    ["نسخه‌ی Node.js", server.nodeVersion ? String(server.nodeVersion) : "—", true],
                  ] : []}
                />
                <HealthCard
                  icon={<HardDrive size={20} />} title="فضای ذخیره‌سازی" section={storage}
                  meter={storage ? { label: "فضای استفاده‌شده", percent: storage.usedPercent } : null}
                  rows={storage ? [
                    !isNum(storage.usedPercent) ? ["فضای استفاده‌شده", "نامشخص"] : null,
                    isNum(storage.freeGB) && isNum(storage.totalGB) ? ["فضای آزاد", `${fa(storage.freeGB, { maximumFractionDigits: 1 })} از ${fa(storage.totalGB, { maximumFractionDigits: 1 })} GB`] : null,
                  ] : []}
                />
                <HealthCard
                  icon={<DatabaseBackup size={20} />} title="آخرین پشتیبان دیتابیس" section={backup}
                  rows={backup ? [
                    ["زمان آخرین پشتیبان", formatDateTime(backup.lastBackupAt)],
                    isNum(backup.ageHours) ? ["گذشته از آخرین پشتیبان", `${fa(backup.ageHours, { maximumFractionDigits: 1 })} ساعت`] : null,
                    backup.lastBackupType ? ["نوع پشتیبان", BACKUP_TYPE_FA[backup.lastBackupType] || String(backup.lastBackupType)] : null,
                    backup.lastBackupFilename ? ["نام فایل", String(backup.lastBackupFilename), true] : null,
                  ] : []}
                />
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

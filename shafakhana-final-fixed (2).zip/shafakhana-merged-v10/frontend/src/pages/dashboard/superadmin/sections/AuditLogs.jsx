import { useEffect, useState } from "react";
import {
  ShieldCheck, Lock, Layers, CirclePlus, RefreshCw, CircleMinus, CalendarDays, Clock, Download,
  Search, Eye, RotateCcw, Users, UserCog, Stethoscope, User, Globe, Monitor,
} from "lucide-react";
import { apiRequest, API_BASE } from "../../../../utils/api.js";
import { defaultLogDateFrom } from "../shared.js";
import { JalaliDateInput } from "../../../../components/JalaliDateInput.jsx";
import {
  RoleBadge, LOG_ROLES, faNum, faDateTime, faDate, faTime, todayStr, shortUserAgent,
  fetchLogTotal, downloadLogCsv, LogKpiCard, SkeletonRows, LogEmptyState,
  LogPagination, LogDrawer, DetailRow,
} from "../logsUi.jsx";

const AUDIT_ACTION_META = {
  INSERT: { label: "افزودن", Icon: CirclePlus },
  UPDATE: { label: "ویرایش", Icon: RefreshCw },
  DELETE: { label: "حذف", Icon: CircleMinus },
};

// لایه‌ی محافظتی نمایشی: Backend از قبل این کلیدها را ذخیره نمی‌کند (sanitizeValues)،
// اما UI هم هرگز آن‌ها را نمایش نمی‌دهد (برای رکوردهای احتمالی قدیمی)
const SENSITIVE_KEY = /password|hash|secret|token/i;

function formatAuditValue(raw) {
  if (!raw) return null;
  try {
    return typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch {
    return null;
  }
}

function cleanValues(raw) {
  const value = formatAuditValue(raw);
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const out = {};
  Object.entries(value).forEach(([k, v]) => {
    if (!SENSITIVE_KEY.test(k)) out[k] = v;
  });
  return out;
}

function parseChangedFields(raw) {
  const v = formatAuditValue(raw);
  return Array.isArray(v) ? v.filter((k) => !SENSITIVE_KEY.test(String(k))) : null;
}

function shortVal(v) {
  if (v === null || v === undefined || v === "") return "—";
  const s = typeof v === "object" ? JSON.stringify(v) : String(v);
  return s.length > 36 ? `${s.slice(0, 36)}…` : s;
}

function ActionBadge({ action }) {
  const meta = AUDIT_ACTION_META[action];
  const Icon = meta?.Icon;
  return (
    <span className={`lg-badge lg-tone-${(action || "").toLowerCase() || "neutral"}`}>
      {Icon && <Icon size={13} aria-hidden="true" />}
      {meta ? meta.label : action}
      <span className="lg-badge-code">{action}</span>
    </span>
  );
}

// نمای خلاصه‌ی «قبل / بعد» در جدول: حداکثر ۳ فیلد (برای UPDATE ابتدا فیلدهای واقعاً تغییرکرده)
function ChangesPreview({ log }) {
  const oldV = cleanValues(log.oldValues);
  const newV = cleanValues(log.newValues);
  const changed = parseChangedFields(log.changedFields);
  const source = newV || oldV || {};
  const keys = log.action === "UPDATE" && changed && changed.length ? changed : Object.keys(source);
  if (keys.length === 0) return <span className="lg-muted">-</span>;
  const shown = keys.slice(0, 3);
  const more = keys.length - shown.length;
  const block = (label, values, cls) => (
    <div className={`lg-chg ${cls}`}>
      <span className="lg-chg-label">{label}</span>
      {shown.map((key) => (
        <div className="lg-chg-row" key={key}>
          <span className="lg-chg-key">{key}:</span> <span className="lg-chg-val">{shortVal(values?.[key])}</span>
        </div>
      ))}
    </div>
  );
  return (
    <div className="lg-changes">
      {oldV && block("قبل:", oldV, "is-old")}
      {newV && block("بعد:", newV, "is-new")}
      {more > 0 && <div className="lg-chg-more">+ {faNum(more)} فیلد دیگر</div>}
    </div>
  );
}

// JSON مرتب و خوانا؛ خط‌های مربوط به فیلدهای تغییرکرده برجسته می‌شوند
function JsonView({ value, changed = [] }) {
  if (!value || Object.keys(value).length === 0) return <div className="lg-json lg-json-empty">بدون مقدار</div>;
  const lines = JSON.stringify(value, null, 2).split("\n");
  const changedSet = new Set(changed);
  return (
    <pre className="lg-json" dir="ltr">
      {lines.map((line, i) => {
        const m = line.match(/^ {2}"([^"]+)":/);
        const hit = m && changedSet.has(m[1]);
        return <span key={i} className={`lg-json-line ${hit ? "is-changed" : ""}`}>{line}{"\n"}</span>;
      })}
    </pre>
  );
}

const AUDIT_ROLE_TABS = [
  { value: "", label: "همه", Icon: Users },
  { value: "superadmin", label: "سوپر ادمین", Icon: ShieldCheck },
  { value: "admin", label: "ادمین", Icon: UserCog },
  { value: "doctor", label: "داکتر", Icon: Stethoscope },
  { value: "user", label: "بیمار", Icon: User },
];

const ACTION_TABS = [
  { value: "", label: "همه عملیات" },
  { value: "INSERT", label: "افزودن" },
  { value: "UPDATE", label: "ویرایش" },
  { value: "DELETE", label: "حذف" },
];

export default function AuditLogs() {
  const [logs, setLogs] = useState([]);
  const [tables, setTables] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, totalPages: 1 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [exporting, setExporting] = useState(false);
  const [detail, setDetail] = useState(null);
  const [kpis, setKpis] = useState(null);

  // فیلتر نقش و نوع عملیات جدا از بقیه فیلترها نگه‌داشته می‌شوند چون با کلیک بلافاصله اعمال می‌شوند
  const [roleTab, setRoleTab] = useState("");
  const [actionTab, setActionTab] = useState("");
  const [filters, setFilters] = useState({ search: "", tableName: "", dateFrom: defaultLogDateFrom(), dateTo: "" });
  const [appliedFilters, setAppliedFilters] = useState(filters);
  const [page, setPage] = useState(1);

  // Export دقیقاً از همین buildQuery می‌آید، یعنی عین فیلترهای فعال لیست
  function buildQuery(extra = {}) {
    const params = new URLSearchParams();
    if (appliedFilters.search) params.set("search", appliedFilters.search);
    if (appliedFilters.tableName) params.set("tableName", appliedFilters.tableName);
    if (actionTab) params.set("action", actionTab);
    if (roleTab) params.set("role", roleTab);
    if (appliedFilters.dateFrom) params.set("dateFrom", appliedFilters.dateFrom);
    if (appliedFilters.dateTo) params.set("dateTo", appliedFilters.dateTo);
    Object.entries(extra).forEach(([k, v]) => params.set(k, v));
    return params.toString();
  }

  function selectRole(value) {
    setRoleTab(value);
    setPage(1);
  }
  function selectAction(value) {
    setActionTab(value);
    setPage(1);
  }

  // KPIها فقط از همان API فعلی (pagination.total با limit=1) محاسبه می‌شوند؛ هیچ داده‌ی ساختگی‌ای ساخته نمی‌شود
  useEffect(() => {
    let cancelled = false;
    const path = "/superadmin/audit-logs";
    const t = todayStr();
    const safe = (p) => p.catch(() => null);
    Promise.all([
      safe(fetchLogTotal(path)),
      safe(fetchLogTotal(path, { action: "INSERT" })),
      safe(fetchLogTotal(path, { action: "UPDATE" })),
      safe(fetchLogTotal(path, { action: "DELETE" })),
      safe(fetchLogTotal(path, { dateFrom: t, dateTo: t })),
    ]).then(([all, ins, upd, del, today]) => {
      if (cancelled) return;
      setKpis({
        total: all?.total ?? null,
        last: all?.first || null,
        insert: ins?.total ?? null,
        update: upd?.total ?? null,
        del: del?.total ?? null,
        today: today?.total ?? null,
      });
    });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    apiRequest(`/superadmin/audit-logs?${buildQuery({ page, limit: 21 })}`)
      .then((d) => {
        if (cancelled) return;
        setLogs(d.logs);
        setTables(d.tables || []);
        setPagination(d.pagination);
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [appliedFilters, roleTab, actionTab, page]);

  function applyFilters(e) {
    e.preventDefault();
    setPage(1);
    setAppliedFilters(filters);
  }

  function resetFilters() {
    const cleared = { search: "", tableName: "", dateFrom: defaultLogDateFrom(), dateTo: "" };
    setFilters(cleared);
    setAppliedFilters(cleared);
    setRoleTab("");
    setActionTab("");
    setPage(1);
  }

  async function handleExport() {
    setExporting(true);
    setError("");
    try {
      await downloadLogCsv(
        `${API_BASE}/superadmin/audit-logs/export?${buildQuery()}`,
        `audit-logs-${Date.now()}.csv`,
        "خروجی گرفتن از لاگ حسابرسی ناموفق بود"
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setExporting(false);
    }
  }

  const kpiLoading = kpis === null;
  const k = (key) => (kpiLoading || kpis[key] === null ? null : faNum(kpis[key]));
  const activeRole = AUDIT_ROLE_TABS.find((t) => t.value === roleTab) || AUDIT_ROLE_TABS[0];

  const detailOld = detail ? cleanValues(detail.oldValues) : null;
  const detailNew = detail ? cleanValues(detail.newValues) : null;
  const detailChanged = detail ? parseChangedFields(detail.changedFields) : null;

  return (
    <div className="lg-scope lg-audit">
      <header className="lg-header">
        <span className="lg-header-icon" aria-hidden="true"><ShieldCheck size={24} /></span>
        <div className="lg-header-text">
          <h2>لاگ حسابرسی</h2>
          <p>ثبت غیرقابل‌تغییر تغییرات مهم داده‌ها و سوابق سیستم</p>
        </div>
        <span className="lg-secure-badge">
          <span className="lg-pulse-dot" aria-hidden="true" />
          Audit Trail فعال
        </span>
        <button type="button" className="btn btn-primary btn-sm lg-export" onClick={handleExport} disabled={exporting}>
          <Download size={15} aria-hidden="true" />
          {exporting ? "در حال آماده‌سازی خروجی..." : "خروجی CSV"}
        </button>
      </header>

      <div className="lg-readonly-note">
        <Lock size={14} aria-hidden="true" />
        این لاگ فقط‌خواندنی است؛ رکوردهای حسابرسی قابل ویرایش یا حذف نیستند و مقدارهای حساس مثل رمز عبور ثبت نمی‌شوند.
      </div>

      <section className="lg-kpis lg-kpis-audit" aria-label="خلاصه تغییرات حسابرسی‌شده">
        <LogKpiCard icon={Layers} label="کل تغییرات" value={k("total")} tone="neutral" loading={kpiLoading} />
        <LogKpiCard icon={CirclePlus} label="افزودن‌ها" value={k("insert")} tone="insert" loading={kpiLoading} />
        <LogKpiCard icon={RefreshCw} label="ویرایش‌ها" value={k("update")} tone="update" loading={kpiLoading} />
        <LogKpiCard icon={CircleMinus} label="حذف‌ها" value={k("del")} tone="delete" loading={kpiLoading} />
        <LogKpiCard icon={CalendarDays} label="تغییرات امروز" value={k("today")} tone="neutral" loading={kpiLoading} />
        <LogKpiCard
          icon={Clock}
          label="آخرین تغییر"
          value={!kpiLoading && kpis.last ? faTime(kpis.last.createdAt) : null}
          hint={!kpiLoading && kpis.last ? `${faDate(kpis.last.createdAt)} — ${kpis.last.tableName}` : undefined}
          tone="neutral"
          loading={kpiLoading}
        />
      </section>

      <div className="lg-panel">
        <div className="lg-tabs" role="tablist" aria-label="فیلتر نقش لاگ حسابرسی">
          {AUDIT_ROLE_TABS.map((tab) => {
            const active = roleTab === tab.value;
            return (
              <button
                key={tab.value}
                type="button"
                role="tab"
                aria-selected={active}
                className={`lg-tab lg-tone-${tab.value || "neutral"} ${active ? "is-active" : ""}`}
                onClick={() => selectRole(tab.value)}
              >
                <tab.Icon size={15} aria-hidden="true" />
                {tab.label}
              </button>
            );
          })}
        </div>

        <div className="lg-action-filter" role="group" aria-label="فیلتر نوع عملیات">
          {ACTION_TABS.map((a) => {
            const meta = AUDIT_ACTION_META[a.value];
            const active = actionTab === a.value;
            return (
              <button
                key={a.value || "all"}
                type="button"
                aria-pressed={active}
                className={`lg-chip lg-tone-${a.value ? a.value.toLowerCase() : "neutral"} ${active ? "is-active" : ""}`}
                onClick={() => selectAction(a.value)}
              >
                {meta && <meta.Icon size={14} aria-hidden="true" />}
                {a.label}
                {a.value && <span className="lg-badge-code">{a.value}</span>}
              </button>
            );
          })}
        </div>

        <form className="lg-toolbar" onSubmit={applyFilters}>
          <label className="lg-search">
            <Search size={16} aria-hidden="true" />
            <input
              value={filters.search}
              onChange={(e) => setFilters((f) => ({ ...f, search: e.target.value }))}
              placeholder="جستجو در کاربر، جدول، مقدار یا IP..."
              aria-label="جستجو در نام کاربر، جدول، مقدار یا IP"
            />
          </label>
          <div className="lg-tfield">
            <span>نقش</span>
            <select className="dash-select" value={roleTab} onChange={(e) => selectRole(e.target.value)}>
              <option value="">همه نقش‌ها</option>
              {Object.entries(LOG_ROLES).map(([value, r]) => <option key={value} value={value}>{r.label}</option>)}
            </select>
          </div>
          <div className="lg-tfield">
            <span>جدول</span>
            <select className="dash-select" value={filters.tableName} onChange={(e) => setFilters((f) => ({ ...f, tableName: e.target.value }))}>
              <option value="">همه جدول‌ها</option>
              {tables.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="lg-tfield">
            <span>نوع عملیات</span>
            <select className="dash-select" value={actionTab} onChange={(e) => selectAction(e.target.value)}>
              <option value="">همه</option>
              <option value="INSERT">افزودن (INSERT)</option>
              <option value="UPDATE">ویرایش (UPDATE)</option>
              <option value="DELETE">حذف (DELETE)</option>
            </select>
          </div>
          <div className="lg-tfield">
            <span>از تاریخ</span>
            <JalaliDateInput value={filters.dateFrom} onChange={(e) => setFilters((f) => ({ ...f, dateFrom: e.target.value }))} />
          </div>
          <div className="lg-tfield">
            <span>تا تاریخ</span>
            <JalaliDateInput value={filters.dateTo} onChange={(e) => setFilters((f) => ({ ...f, dateTo: e.target.value }))} />
          </div>
          <div className="lg-toolbar-actions">
            <button className="btn btn-primary btn-sm" type="submit">اعمال فیلتر</button>
            <button className="btn btn-ghost btn-sm" type="button" onClick={resetFilters}>
              <RotateCcw size={14} aria-hidden="true" /> پاک کردن
            </button>
          </div>
        </form>

        <div className="lg-subbar">
          <span className="lg-result-line">
            {!loading && <>{activeRole.label} — <b>{faNum(pagination.total)}</b> رکورد</>}
          </span>
        </div>

        {error && <div className="form-message error">{error}</div>}

        {loading && <SkeletonRows rows={8} cols={8} />}

        {!loading && logs.length === 0 && !error && (
          <LogEmptyState message="هیچ تغییر حسابرسی‌شده‌ای مطابق فیلترهای انتخاب‌شده پیدا نشد." onReset={resetFilters} />
        )}

        {!loading && logs.length > 0 && (
          <div className="lg-table-wrap">
            <table className="lg-table lg-table-audit">
              <thead>
                <tr>
                  <th>عملیات</th><th>جدول</th><th>شناسه رکورد</th><th>کاربر</th>
                  <th>نقش</th><th>تغییرات</th><th>زمان</th><th>جزئیات</th>
                </tr>
              </thead>
              <tbody>
                {logs.map((l) => (
                  <tr key={l.id}>
                    <td><ActionBadge action={l.action} /></td>
                    <td><code className="lg-mono lg-table-name">{l.tableName}</code></td>
                    <td>
                      <span className="lg-mono">{l.recordId ? `#${l.recordId}` : "-"}</span>
                      {l.patientName && <div className="lg-sub">بیمار: {l.patientName}</div>}
                    </td>
                    <td className="lg-cell-user">{l.userName || "-"}</td>
                    <td><RoleBadge role={l.userRole} /></td>
                    <td><ChangesPreview log={l} /></td>
                    <td className="lg-cell-time">{faDateTime(l.createdAt)}</td>
                    <td>
                      <button type="button" className="btn btn-ghost btn-sm lg-view-btn" onClick={() => setDetail(l)}>
                        <Eye size={14} aria-hidden="true" /> مشاهده جزئیات
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {!loading && logs.length > 0 && (
          <LogPagination page={page} totalPages={pagination.totalPages} total={pagination.total} onPage={setPage} />
        )}
      </div>

      <LogDrawer
        open={!!detail}
        onClose={() => setDetail(null)}
        title="جزئیات تغییر"
        subtitle={detail ? `${detail.tableName} #${detail.recordId ?? "-"}` : ""}
        icon={ShieldCheck}
        variant="audit"
      >
        {detail && (
          <>
            <div className="lg-meta-grid">
              <DetailRow label="نوع عملیات"><ActionBadge action={detail.action} /></DetailRow>
              <DetailRow label="جدول"><code className="lg-mono lg-table-name">{detail.tableName}</code></DetailRow>
              <DetailRow label="Record ID"><span className="lg-mono">{detail.recordId ?? "-"}</span></DetailRow>
              <DetailRow label="کاربر">{detail.userName || "-"}</DetailRow>
              <DetailRow label="Role"><RoleBadge role={detail.userRole} /></DetailRow>
              <DetailRow label="تاریخ و ساعت">{faDateTime(detail.createdAt)}</DetailRow>
              {detail.patientName && <DetailRow label="بیمار">{detail.patientName}</DetailRow>}
              <DetailRow label="آدرس IP"><span className="lg-mono"><Globe size={12} aria-hidden="true" /> {detail.ipAddress || "-"}</span></DetailRow>
            </div>

            {detail.userAgent && (
              <div className="lg-ua-line" title={detail.userAgent}>
                <Monitor size={14} aria-hidden="true" />
                <span>{shortUserAgent(detail.userAgent) || "مرورگر"}</span>
                <span className="lg-mono lg-ua-full">{detail.userAgent}</span>
              </div>
            )}

            <div className="lg-json-grid">
              <section>
                <h4 className="lg-json-title is-old">مقدار قبلی</h4>
                <JsonView value={detailOld} changed={detailChanged || []} />
              </section>
              <section>
                <h4 className="lg-json-title is-new">مقدار جدید</h4>
                <JsonView value={detailNew} changed={detailChanged || []} />
              </section>
            </div>

            {detailChanged && (
              <section className="lg-changed-fields">
                <h4 className="lg-json-title">فیلدهای تغییرکرده</h4>
                {detailChanged.length > 0 ? (
                  <div className="lg-chip-list">
                    {detailChanged.map((f) => <code className="lg-field-chip lg-mono" key={f}>{f}</code>)}
                  </div>
                ) : (
                  <p className="lg-muted">هیچ فیلدی تغییر نکرده است.</p>
                )}
              </section>
            )}
          </>
        )}
      </LogDrawer>
    </div>
  );
}

// حساب‌های ادمین (Super Admin) — دو بخش جدا:
//   ۱) مدیریت حساب‌های ادمین     (GET/POST /superadmin/admins ، PUT/DELETE /superadmin/admins/:id)
//   ۲) حساب‌های داشبورد داکتران  (GET /admin/doctors ، POST /admin/doctors/:id/account ،
//                                 DELETE /superadmin/doctors/:id/account)
// در این بازطراحی فقط ظاهر/تجربه‌ی کاربری عوض شده است: APIها، Validation رمز عبور و تمام
// محدودیت‌های امنیتی (که در Backend اعمال می‌شوند) دست‌نخورده‌اند. هیچ داده‌ی ساختگی وجود
// ندارد؛ کارت‌های آماری فقط از همان پاسخ دو API بالا محاسبه می‌شوند.
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  AlertCircle, AlertTriangle, CheckCircle2, Eye, EyeOff, Info, KeyRound, MoreVertical, Plus,
  Power, Search, ShieldCheck, Stethoscope, Trash2, UserCheck, UserPlus, UserX, Users, X,
} from "lucide-react";
import GlobalModal from "../../../../components/GlobalModal.jsx";
import { apiRequest } from "../../../../utils/api.js";
import { getPasswordError, PASSWORD_HINT_FA } from "../../../../utils/passwordPolicy.js";
import { isScrollbarClick } from "../../../../utils/scrollbarClick.js";

const fa = (n) => Number(n || 0).toLocaleString("fa-IR-u-ca-persian");
const initialOf = (name) => (String(name || "").trim() ? [...String(name).trim()][0] : "؟");
const norm = (v) => String(v ?? "").toLowerCase();
const NO_MSG = { type: "", text: "" };

// ---------- اجزای مشترک ----------
function Alert({ type, children, onClose }) {
  const Icon = type === "success" ? CheckCircle2 : type === "error" ? AlertCircle : Info;
  return (
    <div className={`aa-alert is-${type}`} role={type === "error" ? "alert" : "status"}>
      <Icon size={18} />
      <div className="aa-alert-text">{children}</div>
      {onClose && (
        <button type="button" className="aa-alert-close" onClick={onClose} aria-label="بستن پیام"><X size={14} /></button>
      )}
    </div>
  );
}

function PasswordField({ value, onChange }) {
  const [show, setShow] = useState(false);
  return (
    <div className="field">
      <label>رمز عبور اولیه</label>
      <div className="aa-pass">
        <input required type={show ? "text" : "password"} value={value} onChange={onChange} autoComplete="new-password" dir="ltr" />
        <button type="button" className="aa-pass-toggle" onClick={() => setShow((s) => !s)} aria-label={show ? "پنهان‌کردن رمز عبور" : "نمایش رمز عبور"}>
          {show ? <EyeOff size={16} /> : <Eye size={16} />}
        </button>
      </div>
      <span className="field-hint">{PASSWORD_HINT_FA}</span>
    </div>
  );
}

// دیالوگ تایید حذف (همان الگوی دیالوگ‌های تایید پروژه: GlobalModal + logout-confirm-modal)
function ConfirmDelete({ open, busy, title, question, target, note, busyLabel, onConfirm, onClose }) {
  return (
    <GlobalModal
      isOpen={open}
      onClose={() => (busy ? null : onClose())}
      size="sm"
      className="logout-confirm-modal aa-scope"
      overlayClassName="logout-confirm-overlay"
      labelledBy="aa-delete-title"
      closeOnOverlayClick={!busy}
      closeOnEsc={!busy}
      bare
    >
      <h3 id="aa-delete-title">{title}</h3>
      <p>{question}</p>
      {target}
      {note && <p className="aa-confirm-note">{note}</p>}
      <div className="modal-actions">
        <button type="button" className="btn btn-primary danger-solid" onClick={onConfirm} disabled={busy}>
          {busy ? busyLabel : "حذف حساب"}
        </button>
        <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>انصراف</button>
      </div>
    </GlobalModal>
  );
}

function SkeletonRows({ rows = 4, cols }) {
  return Array.from({ length: rows }).map((_, i) => (
    <tr key={i} aria-hidden="true">
      {Array.from({ length: cols }).map((__, c) => (
        <td key={c}>
          {c === 0 ? (
            <div className="aa-person"><span className="aa-skel is-avatar" /><span className="aa-skel is-w60" style={{ flex: 1 }} /></div>
          ) : (
            <span className="aa-skel is-w60" />
          )}
        </td>
      ))}
    </tr>
  ));
}

// ---------- صفحه‌ی اصلی ----------
export default function AdminAccounts() {
  // داده‌ی هر دو بخش در همین‌جا بارگذاری می‌شود تا کارت‌های آماری بالا از همان داده‌ی واقعی
  // جدول‌ها محاسبه شوند (بدون هیچ درخواست یا API جدید).
  const [admins, setAdmins] = useState([]);
  const [adminsLoading, setAdminsLoading] = useState(true);
  const [adminsError, setAdminsError] = useState("");
  const [doctors, setDoctors] = useState([]);
  const [doctorsLoading, setDoctorsLoading] = useState(true);
  const [doctorsError, setDoctorsError] = useState("");
  const [adminsLoaded, setAdminsLoaded] = useState(false);
  const [doctorsLoaded, setDoctorsLoaded] = useState(false);
  // فیلتر وضعیت در این سطح نگه داشته می‌شود تا کلیک روی کارت‌های آمار آن را اعمال کند
  const [adminFilter, setAdminFilter] = useState("all");
  const [doctorFilter, setDoctorFilter] = useState("all");

  const loadAdmins = useCallback(() => {
    return apiRequest("/superadmin/admins")
      .then((d) => { setAdmins(d.admins || []); setAdminsError(""); setAdminsLoaded(true); })
      .catch((err) => setAdminsError(err.message))
      .finally(() => setAdminsLoading(false));
  }, []);

  const loadDoctors = useCallback(() => {
    return apiRequest("/admin/doctors")
      .then((d) => { setDoctors(d.doctors || []); setDoctorsError(""); setDoctorsLoaded(true); })
      .catch((err) => setDoctorsError(err.message))
      .finally(() => setDoctorsLoading(false));
  }, []);

  useEffect(() => { loadAdmins(); loadDoctors(); }, [loadAdmins, loadDoctors]);

  const activeAdmins = admins.filter((a) => a.isActive).length;
  const doctorsWithAccount = doctors.filter((d) => d.userId).length;

  // اگر داده‌ی یک منبع هنوز نیامده/خطا داده، KPI مربوط به آن «—» نشان می‌دهد (نه عدد ساختگی)
  const kpis = [
    { key: "total", label: "کل ادمین‌ها", icon: Users, tone: "total", ready: adminsLoaded, loading: adminsLoading, value: admins.length, target: "admins", apply: () => setAdminFilter("all") },
    { key: "active", label: "ادمین‌های فعال", icon: UserCheck, tone: "active", ready: adminsLoaded, loading: adminsLoading, value: activeAdmins, target: "admins", apply: () => setAdminFilter("active") },
    { key: "inactive", label: "ادمین‌های غیرفعال", icon: UserX, tone: "inactive", ready: adminsLoaded, loading: adminsLoading, value: admins.length - activeAdmins, target: "admins", apply: () => setAdminFilter("inactive") },
    { key: "with", label: "داکتران دارای حساب", icon: Stethoscope, tone: "with", ready: doctorsLoaded, loading: doctorsLoading, value: doctorsWithAccount, target: "doctors", apply: () => setDoctorFilter("with") },
    { key: "without", label: "داکتران بدون حساب", icon: AlertTriangle, tone: "without", ready: doctorsLoaded, loading: doctorsLoading, value: doctors.length - doctorsWithAccount, target: "doctors", apply: () => setDoctorFilter("without") },
  ];
  const pressed = { total: adminFilter === "all", active: adminFilter === "active", inactive: adminFilter === "inactive", with: doctorFilter === "with", without: doctorFilter === "without" };

  function onKpiClick(k) {
    k.apply();
    const el = document.getElementById(k.target === "admins" ? "aa-admins-card" : "aa-doctors-card");
    if (el && el.scrollIntoView) el.scrollIntoView({ block: "start" });
  }

  return (
    <div className="aa-page">
      <div className="aa-head">
        <span className="aa-head-icon"><ShieldCheck size={26} /></span>
        <div>
          <h2>مدیریت حساب‌های ادمین</h2>
          <p>مدیریت حساب‌های دسترسی، وضعیت ادمین‌ها و حساب‌های داشبورد داکتران</p>
        </div>
      </div>

      <div className="aa-stats">
        {kpis.map((k) => {
          const Icon = k.icon;
          return (
            <button key={k.key} type="button" className={`aa-stat aa-tone-${k.tone}`} aria-pressed={pressed[k.key]} onClick={() => onKpiClick(k)}>
              <span className="aa-stat-icon"><Icon size={20} /></span>
              <span>
                {k.loading ? <span className="aa-skel is-num" /> : <span className="aa-stat-num">{k.ready ? fa(k.value) : "—"}</span>}
                <span className="aa-stat-label">{k.label}</span>
              </span>
            </button>
          );
        })}
      </div>

      <AdminAccountsCard
        admins={admins} loading={adminsLoading} error={adminsError} onReload={loadAdmins}
        filter={adminFilter} setFilter={setAdminFilter}
      />
      <DoctorAccountsCard
        doctors={doctors} loading={doctorsLoading} error={doctorsError} onReload={loadDoctors}
        filter={doctorFilter} setFilter={setDoctorFilter}
      />
    </div>
  );
}

// ---------- ۱) حساب‌های ادمین ----------
function AdminAccountsCard({ admins, loading, error, onReload, filter, setFilter }) {
  const [msg, setMsg] = useState(NO_MSG);
  const [query, setQuery] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [menuId, setMenuId] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  // بستن منوی عملیات با کلیک بیرون یا Escape
  useEffect(() => {
    if (menuId === null) return undefined;
    const onDown = (e) => { if (isScrollbarClick(e)) return; if (!e.target.closest(".aa-menu-wrap")) setMenuId(null); };
    const onKey = (e) => { if (e.key === "Escape") setMenuId(null); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); };
  }, [menuId]);

  const filtered = useMemo(() => {
    const q = norm(query).trim();
    return admins.filter((a) => {
      if (filter === "active" && !a.isActive) return false;
      if (filter === "inactive" && a.isActive) return false;
      return !q || norm(a.fullName).includes(q) || norm(a.email).includes(q);
    });
  }, [admins, query, filter]);
  const hasFilters = !!query.trim() || filter !== "all";
  function clearFilters() { setQuery(""); setFilter("all"); }

  async function toggleActive(a) {
    setMenuId(null);
    setMsg(NO_MSG);
    setBusyId(a.id);
    const wasActive = !!a.isActive;
    try {
      await apiRequest(`/superadmin/admins/${a.id}`, { method: "PUT", body: { isActive: !wasActive } });
      setMsg({ type: "success", text: wasActive ? `حساب «${a.fullName}» غیرفعال شد.` : `حساب «${a.fullName}» فعال شد.` });
      await onReload();
    } catch (err) {
      setMsg({ type: "error", text: err.message });
    } finally {
      setBusyId(null);
    }
  }

  async function confirmDelete() {
    if (!deleting) return;
    setDeleteBusy(true);
    setMsg(NO_MSG);
    try {
      await apiRequest(`/superadmin/admins/${deleting.id}`, { method: "DELETE" });
      setDeleting(null);
      setMsg({ type: "success", text: "حساب ادمین حذف شد." });
      await onReload();
    } catch (err) {
      setDeleting(null);
      setMsg({ type: "error", text: err.message });
    } finally {
      setDeleteBusy(false);
    }
  }

  function created() {
    setCreateOpen(false);
    setMsg({ type: "success", text: "حساب ادمین با موفقیت ساخته شد." });
    onReload();
  }

  return (
    <section id="aa-admins-card" className="dash-card glass aa-card" aria-labelledby="aa-admins-title">
      <div className="aa-card-head">
        <div className="aa-card-title">
          <span className="aa-head-icon"><ShieldCheck size={20} /></span>
          <div>
            <h3 id="aa-admins-title">حساب‌های ادمین</h3>
            <p>مدیریت حساب‌های مدیریتی و وضعیت دسترسی آن‌ها</p>
          </div>
        </div>
        <button type="button" className="btn btn-primary aa-btn-icon" onClick={() => setCreateOpen(true)}>
          <Plus size={16} /> ساخت حساب ادمین
        </button>
      </div>

      {msg.text && <Alert type={msg.type} onClose={() => setMsg(NO_MSG)}>{msg.text}</Alert>}
      {error && (
        <Alert type="error">
          {error}
          <button type="button" className="btn btn-ghost btn-sm" onClick={onReload}>تلاش مجدد</button>
        </Alert>
      )}

      <div className="aa-filterbar">
        <div className="aa-search">
          <Search size={16} />
          <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="جستجو بر اساس نام یا ایمیل..." aria-label="جستجوی ادمین" />
        </div>
        <select className="dash-select aa-select" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="فیلتر وضعیت">
          <option value="all">همه</option>
          <option value="active">فعال</option>
          <option value="inactive">غیرفعال</option>
        </select>
        {hasFilters && <button type="button" className="btn btn-ghost btn-sm aa-clear" onClick={clearFilters}>پاک‌کردن فیلترها</button>}
      </div>

      <div className="aa-tablewrap">
        {loading ? (
          <table className="aa-table" aria-busy="true">
            <tbody><SkeletonRows cols={5} /></tbody>
          </table>
        ) : admins.length === 0 ? (
          <div className="aa-state">
            <ShieldCheck size={32} />
            <strong>هنوز هیچ حساب ادمینی ثبت نشده است.</strong>
            <button type="button" className="btn btn-primary aa-btn-icon" onClick={() => setCreateOpen(true)}><Plus size={16} /> ساخت حساب ادمین</button>
          </div>
        ) : filtered.length === 0 ? (
          <div className="aa-state">
            <Search size={32} />
            <strong>نتیجه‌ای یافت نشد.</strong>
            <p>جستجو یا فیلتر را تغییر دهید.</p>
            <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>پاک‌کردن فیلترها</button>
          </div>
        ) : (
          <table className="aa-table">
            <thead>
              <tr><th>ادمین</th><th>ایمیل</th><th>نقش</th><th>وضعیت</th><th>عملیات</th></tr>
            </thead>
            <tbody>
              {filtered.map((a, idx) => {
                const open = menuId === a.id;
                const up = filtered.length > 3 && idx >= filtered.length - 2;
                return (
                  <tr key={a.id}>
                    <td className="aa-cell-main">
                      <div className="aa-person"><span className="aa-avatar" aria-hidden="true">{initialOf(a.fullName)}</span><span className="aa-person-name">{a.fullName}</span></div>
                    </td>
                    <td data-label="ایمیل" className="aa-cell-wide"><span className="aa-ltr">{a.email}</span></td>
                    <td data-label="نقش"><span className="aa-badge is-role">Admin</span></td>
                    <td data-label="وضعیت">
                      <span className={`aa-badge has-dot ${a.isActive ? "is-active" : "is-inactive"}`}>{a.isActive ? "فعال" : "غیرفعال"}</span>
                    </td>
                    <td className="aa-cell-actions">
                      <div className="aa-actions">
                        <div className="aa-menu-wrap">
                          <button type="button" className="aa-iconbtn" aria-haspopup="menu" aria-expanded={open} aria-label={`عملیات ${a.fullName}`} disabled={busyId === a.id} onClick={() => setMenuId(open ? null : a.id)}>
                            <MoreVertical size={16} />
                          </button>
                          {open && (
                            <div className={`aa-menu${up ? " is-up" : ""}`} role="menu">
                              <button type="button" role="menuitem" onClick={() => toggleActive(a)}>
                                <Power size={15} /> {a.isActive ? "غیرفعال کردن" : "فعال کردن"}
                              </button>
                              <hr />
                              <button type="button" role="menuitem" className="is-danger" onClick={() => { setMenuId(null); setDeleting(a); }}>
                                <Trash2 size={15} /> حذف
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <AdminCreateDrawer open={createOpen} onClose={() => setCreateOpen(false)} onCreated={created} />

      <ConfirmDelete
        open={!!deleting}
        busy={deleteBusy}
        busyLabel="در حال حذف..."
        title="تایید حذف حساب ادمین"
        question="آیا از حذف این حساب ادمین مطمئن هستید؟"
        target={deleting && (
          <div className="aa-confirm-target">
            <span className="aa-avatar" aria-hidden="true">{initialOf(deleting.fullName)}</span>
            <div><strong>{deleting.fullName}</strong><span className="aa-muted aa-ltr" style={{ display: "block" }}>{deleting.email}</span></div>
          </div>
        )}
        onConfirm={confirmDelete}
        onClose={() => setDeleting(null)}
      />
    </section>
  );
}

// Drawer ساخت حساب ادمین — همان فیلدها و همان Validation رمز عبور قبلی
function AdminCreateDrawer({ open, onClose, onCreated }) {
  const [form, setForm] = useState({ fullName: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) { setForm({ fullName: "", email: "", password: "" }); setError(""); setSaving(false); }
  }, [open]);

  async function submit(e) {
    e.preventDefault();
    setError("");
    const passwordError = getPasswordError(form.password);
    if (passwordError) { setError(passwordError); return; }
    setSaving(true);
    try {
      await apiRequest("/superadmin/admins", { method: "POST", body: { ...form, fullName: form.fullName.trim(), email: form.email.trim() } });
      onCreated();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <GlobalModal
      isOpen={open}
      onClose={() => (saving ? null : onClose())}
      title="ساخت حساب ادمین جدید"
      size="md"
      className="aa-scope"
      closeOnOverlayClick={false}
      closeOnEsc={!saving}
      footer={(
        <>
          <button type="submit" form="aa-admin-form" className="btn btn-primary" disabled={saving}>{saving ? "در حال ساخت حساب..." : "ساخت حساب ادمین"}</button>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={saving}>انصراف</button>
        </>
      )}
    >
      <form id="aa-admin-form" className="aa-form" onSubmit={submit}>
        {error && <Alert type="error">{error}</Alert>}
        <div className="field">
          <label>نام کامل</label>
          <input required value={form.fullName} onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))} autoComplete="off" />
        </div>
        <div className="field">
          <label>ایمیل</label>
          <input required type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} autoComplete="off" dir="ltr" />
        </div>
        <PasswordField value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
      </form>
    </GlobalModal>
  );
}

// ---------- ۲) حساب‌های داشبورد داکتران ----------
const PENDING_PREVIEW = 6;

function DoctorAccountsCard({ doctors, loading, error, onReload, filter, setFilter }) {
  const [msg, setMsg] = useState(NO_MSG);
  const [query, setQuery] = useState("");
  const [drawer, setDrawer] = useState({ open: false, doctorId: "" });
  const [deleting, setDeleting] = useState(null);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const [showAllPending, setShowAllPending] = useState(false);

  const doctorsWithoutAccount = useMemo(() => doctors.filter((d) => !d.userId), [doctors]);

  const filtered = useMemo(() => {
    const q = norm(query).trim();
    return doctors.filter((d) => {
      if (filter === "with" && !d.userId) return false;
      if (filter === "without" && d.userId) return false;
      return !q || norm(d.fullName).includes(q) || norm(d.department).includes(q) || norm(d.doctorCode).includes(q);
    });
  }, [doctors, query, filter]);
  const hasFilters = !!query.trim() || filter !== "all";
  function clearFilters() { setQuery(""); setFilter("all"); }

  function openCreate(doctorId = "") { setMsg(NO_MSG); setDrawer({ open: true, doctorId: String(doctorId) }); }

  function created() {
    setDrawer({ open: false, doctorId: "" });
    setMsg({ type: "success", text: "حساب داشبورد داکتر با موفقیت ساخته شد." });
    onReload();
  }

  // حذف حساب داشبورد داکتر — فقط Super Admin (مسیر /superadmin/doctors/:id/account در سمت
  // سرور فقط برای این نقش باز است). پیش از حذف دیالوگ تایید نشان داده می‌شود؛ با «انصراف»
  // هیچ تغییری اعمال نمی‌شود.
  async function confirmDelete() {
    if (!deleting) return;
    setDeleteBusy(true);
    setMsg(NO_MSG);
    try {
      await apiRequest(`/superadmin/doctors/${deleting.id}/account`, { method: "DELETE" });
      setDeleting(null);
      setMsg({ type: "success", text: "حساب داشبورد داکتر با موفقیت حذف شد." });
      await onReload();
    } catch (err) {
      setDeleting(null);
      setMsg({ type: "error", text: err.message });
    } finally {
      setDeleteBusy(false);
    }
  }

  const pendingShown = showAllPending ? doctorsWithoutAccount : doctorsWithoutAccount.slice(0, PENDING_PREVIEW);

  return (
    <section id="aa-doctors-card" className="dash-card glass aa-card" aria-labelledby="aa-doctors-title">
      <div className="aa-card-head">
        <div className="aa-card-title">
          <span className="aa-head-icon" style={{ color: "var(--aa-purple)", background: "color-mix(in srgb, var(--aa-purple) 16%, transparent)" }}><Stethoscope size={20} /></span>
          <div>
            <h3 id="aa-doctors-title">حساب‌های داشبورد داکتران</h3>
            <p>برای داکترانی که هنوز حساب ورود به داشبورد ندارند، از این قسمت حساب ایجاد کنید.</p>
          </div>
        </div>
        <button type="button" className="btn btn-primary aa-btn-icon" onClick={() => openCreate()} disabled={loading || doctorsWithoutAccount.length === 0}>
          <UserPlus size={16} /> ساخت حساب داشبورد داکتر
        </button>
      </div>

      {msg.text && <Alert type={msg.type} onClose={() => setMsg(NO_MSG)}>{msg.text}</Alert>}
      {error && (
        <Alert type="error">
          {error}
          <button type="button" className="btn btn-ghost btn-sm" onClick={onReload}>تلاش مجدد</button>
        </Alert>
      )}

      {/* ---- داکتران بدون حساب (Highlight) ---- */}
      {loading ? (
        <div className="aa-highlight" aria-busy="true">
          <div className="aa-pending-grid">
            {[0, 1, 2].map((i) => (
              <div className="aa-pending" key={i}><div className="aa-pending-top"><span className="aa-skel is-avatar" /><span className="aa-skel is-w60" style={{ flex: 1 }} /></div><span className="aa-skel is-w40" /></div>
            ))}
          </div>
        </div>
      ) : doctors.length > 0 && doctorsWithoutAccount.length > 0 ? (
        <div className="aa-highlight">
          <div className="aa-highlight-head">
            <h4><AlertTriangle size={18} /> داکتران بدون حساب <span className="aa-badge is-none aa-num">{fa(doctorsWithoutAccount.length)}</span></h4>
            {doctorsWithoutAccount.length > PENDING_PREVIEW && (
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setShowAllPending((s) => !s)}>
                {showAllPending ? "نمایش کمتر" : `نمایش همه (${fa(doctorsWithoutAccount.length)})`}
              </button>
            )}
          </div>
          <div className="aa-pending-grid">
            {pendingShown.map((d) => (
              <div className="aa-pending" key={d.id}>
                <div className="aa-pending-top">
                  <span className="aa-avatar is-doctor" aria-hidden="true">{initialOf(d.fullName)}</span>
                  <div className="aa-pending-info">
                    <span className="aa-pending-name">{d.fullName}</span>
                    <span className="aa-pending-meta">{d.department} · کد: <span className="aa-num">{d.doctorCode}</span></span>
                  </div>
                </div>
                <div className="aa-pending-foot">
                  <span className="aa-badge has-dot is-none">بدون حساب</span>
                  <button type="button" className="btn btn-ghost btn-sm aa-btn-icon" onClick={() => openCreate(d.id)}><KeyRound size={14} /> ساخت حساب</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : doctors.length > 0 ? (
        <div className="aa-state is-ok" style={{ padding: "22px 16px" }}>
          <CheckCircle2 size={30} />
          <strong>همه داکتران ثبت‌شده دارای حساب داشبورد هستند.</strong>
        </div>
      ) : null}

      {/* ---- جستجو و فیلتر ---- */}
      {!loading && doctors.length > 0 && (
        <div className="aa-filterbar">
          <div className="aa-search">
            <Search size={16} />
            <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="جستجو بر اساس نام، بخش یا کد داکتر..." aria-label="جستجوی داکتر" />
          </div>
          <select className="dash-select aa-select" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="فیلتر وضعیت حساب">
            <option value="all">همه</option>
            <option value="with">دارای حساب</option>
            <option value="without">بدون حساب</option>
          </select>
          {hasFilters && <button type="button" className="btn btn-ghost btn-sm aa-clear" onClick={clearFilters}>پاک‌کردن فیلترها</button>}
        </div>
      )}

      {/* ---- جدول داکتران ---- */}
      <div className="aa-tablewrap">
        {loading ? (
          <table className="aa-table" aria-busy="true"><tbody><SkeletonRows cols={5} /></tbody></table>
        ) : doctors.length === 0 ? (
          <div className="aa-state">
            <Stethoscope size={32} />
            <strong>هنوز هیچ داکتری در سیستم ثبت نشده است.</strong>
            <p>ابتدا از پنل ادمین یک داکتر اضافه کنید.</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="aa-state">
            <Search size={32} />
            <strong>نتیجه‌ای یافت نشد.</strong>
            <p>جستجو یا فیلتر را تغییر دهید.</p>
            <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>پاک‌کردن فیلترها</button>
          </div>
        ) : (
          <table className="aa-table">
            <thead>
              <tr><th>داکتر</th><th>بخش</th><th>کد داکتر</th><th>وضعیت حساب</th><th>عملیات</th></tr>
            </thead>
            <tbody>
              {filtered.map((d) => (
                <tr key={d.id}>
                  <td className="aa-cell-main">
                    <div className="aa-person"><span className="aa-avatar is-doctor" aria-hidden="true">{initialOf(d.fullName)}</span><span className="aa-person-name">{d.fullName}</span></div>
                  </td>
                  <td data-label="بخش">{d.department}</td>
                  <td data-label="کد داکتر"><span className="aa-num">{d.doctorCode}</span></td>
                  <td data-label="وضعیت حساب">
                    <span className={`aa-badge has-dot ${d.userId ? "is-has" : "is-none"}`}>{d.userId ? "دارای حساب" : "بدون حساب"}</span>
                  </td>
                  <td className="aa-cell-actions">
                    {d.userId ? (
                      <button type="button" className="btn btn-ghost btn-sm danger aa-btn-icon" onClick={() => setDeleting(d)}><Trash2 size={14} /> حذف حساب</button>
                    ) : (
                      <button type="button" className="btn btn-ghost btn-sm aa-btn-icon" onClick={() => openCreate(d.id)}><KeyRound size={14} /> ساخت حساب</button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <DoctorCreateDrawer
        open={drawer.open}
        initialDoctorId={drawer.doctorId}
        doctorsWithoutAccount={doctorsWithoutAccount}
        onClose={() => setDrawer({ open: false, doctorId: "" })}
        onCreated={created}
      />

      <ConfirmDelete
        open={!!deleting}
        busy={deleteBusy}
        busyLabel="در حال حذف..."
        title="تایید حذف حساب داشبورد داکتر"
        question="آیا از حذف حساب داشبورد این داکتر مطمئن هستید؟"
        target={deleting && (
          <div className="aa-confirm-target">
            <span className="aa-avatar is-doctor" aria-hidden="true">{initialOf(deleting.fullName)}</span>
            <div><strong>{deleting.fullName}</strong><span className="aa-muted" style={{ display: "block" }}>{deleting.department} · کد: {deleting.doctorCode}</span></div>
          </div>
        )}
        note="فقط حساب ورود به داشبورد حذف می‌شود؛ پروفایل داکتر در فهرست داکتران باقی می‌ماند."
        onConfirm={confirmDelete}
        onClose={() => setDeleting(null)}
      />
    </section>
  );
}

// Drawer ساخت حساب داشبورد داکتر — Select، ایمیل و رمز عبور اولیه با همان Validation قبلی
function DoctorCreateDrawer({ open, initialDoctorId, doctorsWithoutAccount, onClose, onCreated }) {
  const [form, setForm] = useState({ doctorId: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) { setForm({ doctorId: initialDoctorId || "", email: "", password: "" }); setError(""); setSaving(false); }
  }, [open, initialDoctorId]);

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (!form.doctorId) { setError("لطفاً یک داکتر را انتخاب کنید."); return; }
    const passwordError = getPasswordError(form.password);
    if (passwordError) { setError(passwordError); return; }
    setSaving(true);
    try {
      await apiRequest(`/admin/doctors/${form.doctorId}/account`, {
        method: "POST",
        body: { email: form.email.trim(), password: form.password },
      });
      onCreated();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <GlobalModal
      isOpen={open}
      onClose={() => (saving ? null : onClose())}
      title="ساخت حساب داشبورد داکتر"
      size="md"
      className="aa-scope"
      closeOnOverlayClick={false}
      closeOnEsc={!saving}
      footer={(
        <>
          <button type="submit" form="aa-doctor-form" className="btn btn-primary" disabled={saving || doctorsWithoutAccount.length === 0}>
            {saving ? "در حال ساخت..." : "ساخت حساب داشبورد داکتر"}
          </button>
          <button type="button" className="btn btn-ghost" onClick={onClose} disabled={saving}>انصراف</button>
        </>
      )}
    >
      <form id="aa-doctor-form" className="aa-form" onSubmit={submit}>
        {error && <Alert type="error">{error}</Alert>}
        {doctorsWithoutAccount.length === 0 && <Alert type="info">همه داکتران ثبت‌شده دارای حساب داشبورد هستند.</Alert>}
        <div className="field">
          <label>داکتر</label>
          <select required className="dash-select" value={form.doctorId} onChange={(e) => setForm((f) => ({ ...f, doctorId: e.target.value }))}>
            <option value="">— انتخاب کنید —</option>
            {doctorsWithoutAccount.map((d) => (
              <option key={d.id} value={d.id}>{d.fullName} — {d.department} — {d.doctorCode}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label>ایمیل</label>
          <input required type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} autoComplete="off" dir="ltr" />
        </div>
        <PasswordField value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} />
      </form>
    </GlobalModal>
  );
}

import { useCallback, useEffect, useMemo, useState } from "react";
import { apiRequest, apiUpload, resolvePhotoUrl } from "../../../../utils/api.js";
import { useSiteSettings } from "../../../../context/SettingsContext.jsx";
import "./SystemSettings.css";

const TIMEZONE_FALLBACK = [
  "Asia/Kabul", "Asia/Tehran", "Asia/Karachi", "Asia/Dubai", "Asia/Kolkata",
  "Asia/Tashkent", "Europe/Istanbul", "Europe/London", "UTC", "America/New_York",
];

function getTimezoneOptions() {
  try {
    if (typeof Intl.supportedValuesOf === "function") return Intl.supportedValuesOf("timeZone");
  } catch {
    // نادیده گرفته می‌شود و به فهرست جایگزین برمی‌گردد
  }
  return TIMEZONE_FALLBACK;
}

// دسته‌بندی‌های ناوبری داخلی. «fields» کلیدهای واقعی تنظیماتی است که در هر دسته نمایش داده
// می‌شود — برای نمایش تعداد خطا و نقطه‌ی «تغییر ذخیره‌نشده» روی هر دسته و پرش به اولین خطا.
const SECTIONS = [
  { key: "hospital", icon: "🏥", label: "اطلاعات شفاخانه", fields: ["hospitalName", "hospitalPhone", "hospitalEmail", "hospitalAddress", "hospitalDescription"] },
  { key: "appearance", icon: "🎨", label: "ظاهر و زبان", fields: ["defaultLanguage", "timezone", "theme"] },
  { key: "comms", icon: "📧", label: "ایمیل و اعلان‌ها", fields: ["emailFromName", "emailNotificationsEnabled", "inAppNotificationsEnabled"] },
  { key: "appointments", icon: "📅", label: "نوبت‌دهی", fields: ["appointmentBookingWindowDays", "appointmentApprovalMode", "appointmentSlotCapacity", "appointmentCancelMinHours", "appointmentReminderHours"] },
  { key: "security", icon: "🔐", label: "امنیت ورود", fields: ["loginMaxFailedAttempts", "loginLockoutMinutes"] },
  { key: "logs", icon: "📋", label: "نگهداری لاگ‌ها", fields: ["activityLogRetentionDays", "auditLogArchiveMonths"] },
  { key: "system", icon: "⚙️", label: "تنظیمات سیستم", fields: ["maintenanceMode"] },
  { key: "logo", icon: "🖼️", label: "لوگوی شفاخانه", fields: [] },
];

// بازه‌های عددی دقیقاً همان min/max هایی هستند که قبلاً روی inputها بود (اعتبارسنجی
// مرورگر). چون حالا فقط تب فعال رندر می‌شود، همین بازه‌ها قبل از ارسال برای همه‌ی تب‌ها
// بررسی می‌شوند. مرجع نهایی Validation همچنان Backend است و خطاهایش در همان فیلد نمایش داده می‌شود.
const NUMBER_RULES = {
  appointmentBookingWindowDays: [0, 365],
  appointmentSlotCapacity: [1, 200],
  appointmentCancelMinHours: [0, 720],
  appointmentReminderHours: [0, 168],
  loginMaxFailedAttempts: [3, 20],
  loginLockoutMinutes: [1, 1440],
  activityLogRetentionDays: [0, 3650],
  auditLogArchiveMonths: [0, 120],
};
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function clientValidate(settings) {
  const errors = {};
  const email = String(settings.hospitalEmail ?? "").trim();
  if (email && !EMAIL_REGEX.test(email)) errors.hospitalEmail = "ایمیل معتبر نیست";
  Object.entries(NUMBER_RULES).forEach(([key, [min, max]]) => {
    const raw = String(settings[key] ?? "").trim();
    if (raw === "") return; // خالی‌بودن را Backend طبق قانون هر کلید تصمیم می‌گیرد
    const n = Number(raw);
    if (!Number.isInteger(n)) errors[key] = "این مقدار باید یک عدد صحیح باشد";
    else if (n < min || n > max) errors[key] = `مقدار باید بین ${min} تا ${max} باشد`;
  });
  return errors;
}

function sectionOfField(key) {
  return SECTIONS.find((s) => s.fields.includes(key))?.key;
}

function toFa(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString("fa-IR-u-ca-persian", { useGrouping: false }) : "";
}

// مقدار عددی معتبر (عدد صحیح) یا null — برای خلاصه‌های زنده که فقط از مقدار واقعی فرم ساخته می‌شوند
function intOrNull(value) {
  const raw = String(value ?? "").trim();
  if (raw === "") return null;
  const n = Number(raw);
  return Number.isInteger(n) ? n : null;
}

/* ---------- اجزای نمایشی (بیرون از کامپوننت اصلی تا با هر رندر دوباره ساخته نشوند) ---------- */

function Card({ icon, title, desc, className = "", children }) {
  return (
    <section className={`ss-card ${className}`}>
      <div className="ss-card-head">
        {icon && <div className="ss-card-icon" aria-hidden="true">{icon}</div>}
        <div>
          <h3 className="ss-card-title">{title}</h3>
          {desc && <p className="ss-card-desc">{desc}</p>}
        </div>
      </div>
      {children}
    </section>
  );
}

function Toggle({ id, checked, onChange, label, description }) {
  return (
    <div className="ss-toggle-row">
      <div className="ss-toggle-text">
        <label htmlFor={id}>{label}</label>
        {description && <span className="field-hint">{description}</span>}
      </div>
      <div className="ss-toggle-ctl">
        <span className={`ss-toggle-state ${checked ? "on" : ""}`}>{checked ? "فعال" : "غیرفعال"}</span>
        <button
          type="button"
          id={id}
          role="switch"
          aria-checked={checked}
          className={`ss-switch ${checked ? "is-on" : ""}`}
          onClick={() => onChange(checked ? "off" : "on")}
        >
          <span className="ss-switch-knob" />
        </button>
      </div>
    </div>
  );
}

function Choices({ label, value, options, onChange, columns }) {
  return (
    <div className={`ss-choices ${columns === 2 ? "ss-choices-2" : ""}`} role="radiogroup" aria-label={label}>
      {options.map((o) => {
        const selected = value === o.value;
        return (
          <button
            key={o.value}
            type="button"
            role="radio"
            aria-checked={selected}
            className={`ss-choice ${selected ? "is-selected" : ""} ${o.warn ? "is-warn" : ""}`}
            onClick={() => onChange(o.value)}
          >
            {o.icon ? <span className="ss-choice-icon" aria-hidden="true">{o.icon}</span> : <span className="ss-choice-mark" aria-hidden="true" />}
            <span className="ss-choice-label">{o.label}</span>
            {o.sub && <span className="ss-choice-sub">{o.sub}</span>}
          </button>
        );
      })}
    </div>
  );
}

function Alert({ tone, icon, children, role }) {
  return (
    <div className={`ss-alert ss-alert-${tone}`} role={role}>
      <span className="ss-alert-icon" aria-hidden="true">{icon}</span>
      <div className="ss-alert-text">{children}</div>
    </div>
  );
}

function SettingsSkeleton() {
  return (
    <div className="ss-scope" aria-busy="true" aria-label="در حال بارگذاری تنظیمات">
      <div className="ss-header">
        <div className="ss-skel" style={{ width: 48, height: 48, borderRadius: 14 }} />
        <div style={{ flex: "1 1 240px", display: "flex", flexDirection: "column", gap: 8 }}>
          <div className="ss-skel ss-skel-line" style={{ width: "40%", height: 20 }} />
          <div className="ss-skel ss-skel-line" style={{ width: "62%" }} />
        </div>
      </div>
      <div className="ss-layout">
        <div className="ss-nav" aria-hidden="true">
          {Array.from({ length: 8 }).map((_, i) => <div key={i} className="ss-skel" style={{ height: 40 }} />)}
        </div>
        <div className="ss-skel-card" aria-hidden="true">
          <div className="ss-skel ss-skel-line" style={{ width: "30%", height: 18 }} />
          <div className="ss-grid">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                <div className="ss-skel ss-skel-line" style={{ width: "35%" }} />
                <div className="ss-skel ss-skel-input" />
              </div>
            ))}
          </div>
          <div className="ss-skel ss-skel-input" style={{ height: 90 }} />
        </div>
      </div>
    </div>
  );
}

export default function SystemSettings() {
  const { refreshSettings } = useSiteSettings();
  const [settings, setSettings] = useState({});
  // آخرین نسخه‌ی ذخیره‌شده/دریافت‌شده از سرور — مبنای تشخیص «تغییرات ذخیره‌نشده»
  const [saved, setSaved] = useState({});
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [status, setStatus] = useState({ type: "", text: "" });
  const [fieldErrors, setFieldErrors] = useState({});
  const [saveState, setSaveState] = useState("idle"); // idle | saving | success | error
  const [logoBusy, setLogoBusy] = useState(""); // "" | "upload" | "remove"
  const [confirmRemove, setConfirmRemove] = useState(false);
  const [active, setActive] = useState(SECTIONS[0].key);
  const timezones = useMemo(() => getTimezoneOptions(), []);
  const saving = saveState === "saving";

  const load = useCallback(() => {
    setLoading(true);
    setLoadError(false);
    return apiRequest("/superadmin/settings")
      .then((d) => {
        setSettings(d.settings);
        setSaved(d.settings);
      })
      .catch(() => setLoadError(true))
      .finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  // پیام موفقیت و وضعیت دکمه‌ی ذخیره بعد از چند ثانیه خودکار پاک می‌شوند
  useEffect(() => {
    if (status.type !== "success") return undefined;
    const t = setTimeout(() => setStatus({ type: "", text: "" }), 5000);
    return () => clearTimeout(t);
  }, [status]);
  useEffect(() => {
    if (saveState !== "success") return undefined;
    const t = setTimeout(() => setSaveState("idle"), 3000);
    return () => clearTimeout(t);
  }, [saveState]);

  // لوگو فوراً با آپلود/حذف ذخیره می‌شود و بخشی از فرم متنی نیست؛ پس در تشخیص تغییرات نیست
  const dirtyKeys = useMemo(() => {
    const keys = new Set([...Object.keys(settings), ...Object.keys(saved)]);
    keys.delete("logoUrl");
    return [...keys].filter((k) => String(settings[k] ?? "") !== String(saved[k] ?? ""));
  }, [settings, saved]);
  const dirty = dirtyKeys.length > 0;

  // هشدار خروج/رفرش مرورگر هنگام وجود تغییرات ذخیره‌نشده
  useEffect(() => {
    if (!dirty) return undefined;
    const handler = (e) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);

  function setValue(key, value) {
    setSettings((s) => ({ ...s, [key]: value }));
    setFieldErrors((fe) => {
      if (!fe[key]) return fe;
      const next = { ...fe };
      delete next[key];
      return next;
    });
    setSaveState((s) => (s === "success" || s === "error" ? "idle" : s));
  }

  function field(key) {
    return {
      value: settings[key] ?? "",
      onChange: (e) => setValue(key, e.target.value),
    };
  }

  function goToFirstError(errors) {
    const firstKey = Object.keys(errors).find((k) => sectionOfField(k));
    if (firstKey) setActive(sectionOfField(firstKey));
  }

  async function save(e) {
    e.preventDefault();
    if (saving) return;

    const clientErrors = clientValidate(settings);
    if (Object.keys(clientErrors).length > 0) {
      setFieldErrors(clientErrors);
      setStatus({ type: "error", text: "برخی مقادیر معتبر نیستند. لطفاً موارد مشخص‌شده را اصلاح کنید." });
      setSaveState("error");
      goToFirstError(clientErrors);
      return;
    }

    setSaveState("saving");
    setStatus({ type: "", text: "" });
    setFieldErrors({});
    try {
      // فقط فیلدهای تغییرکرده فرستاده می‌شوند (نه کل شیء)؛ logoUrl هم فقط از آپلود فایل تغییر می‌کند
      const changed = Object.fromEntries(dirtyKeys.map((k) => [k, settings[k] ?? ""]));
      const data = await apiRequest("/superadmin/settings", { method: "PUT", body: changed });
      setSettings(data.settings);
      setSaved(data.settings);
      setStatus({ type: "success", text: "تنظیمات با موفقیت ذخیره شد." });
      setSaveState("success");
      refreshSettings();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
      setSaveState("error");
      if (err.data && err.data.errors) {
        setFieldErrors(err.data.errors);
        goToFirstError(err.data.errors);
      }
    }
  }

  function discardChanges() {
    setSettings((s) => ({ ...saved, logoUrl: s.logoUrl }));
    setFieldErrors({});
    setStatus({ type: "", text: "" });
    setSaveState("idle");
  }

  async function handleLogoUpload(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;

    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
      setStatus({ type: "error", text: "فرمت لوگو مجاز نیست. فقط JPG، PNG یا WEBP مجاز است." });
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setStatus({ type: "error", text: "حجم لوگو نباید بیشتر از ۲ مگابایت باشد." });
      return;
    }

    setLogoBusy("upload");
    setConfirmRemove(false);
    setStatus({ type: "", text: "" });
    try {
      const formData = new FormData();
      formData.append("logo", file);
      const data = await apiUpload("/superadmin/settings/logo", formData);
      setSettings((s) => ({ ...s, logoUrl: data.logoUrl }));
      setStatus({ type: "success", text: data.message });
      refreshSettings();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setLogoBusy("");
    }
  }

  async function handleLogoRemove() {
    setLogoBusy("remove");
    setConfirmRemove(false);
    setStatus({ type: "", text: "" });
    try {
      const data = await apiRequest("/superadmin/settings/logo", { method: "DELETE" });
      setSettings((s) => ({ ...s, logoUrl: "" }));
      setStatus({ type: "success", text: data.message });
      refreshSettings();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setLogoBusy("");
    }
  }

  if (loading) return <div className="dash-card glass"><SettingsSkeleton /></div>;

  if (loadError) {
    return (
      <div className="dash-card glass ss-scope">
        <div className="ss-error-state" role="alert">
          <span className="ss-error-icon" aria-hidden="true">⚠️</span>
          <p>بارگذاری تنظیمات با مشکل مواجه شد.</p>
          <button type="button" className="btn btn-primary btn-sm" onClick={load}>تلاش مجدد</button>
        </div>
      </div>
    );
  }

  // وضعیت واقعی سیستم از مقدار ذخیره‌شده‌ی maintenanceMode (نه تغییر ذخیره‌نشده‌ی فرم)
  const maintenanceActive = saved.maintenanceMode === "on";
  const maintenanceFormOn = settings.maintenanceMode === "on";
  const logoName = settings.logoUrl ? String(settings.logoUrl).split("/").pop() : "";
  const errorCountBySection = {};
  Object.keys(fieldErrors).forEach((k) => {
    const s = sectionOfField(k);
    if (s) errorCountBySection[s] = (errorCountBySection[s] || 0) + 1;
  });
  const dirtyBySection = {};
  dirtyKeys.forEach((k) => {
    const s = sectionOfField(k);
    if (s) dirtyBySection[s] = true;
  });
  const showSaveBar = dirty || saveState !== "idle" || active !== "logo";
  const tzOptions = settings.timezone && !timezones.includes(settings.timezone) ? [settings.timezone, ...timezones] : timezones;

  const descLen = String(settings.hospitalDescription ?? "").length;
  const addressLen = String(settings.hospitalAddress ?? "").length;
  const maxAttempts = intOrNull(settings.loginMaxFailedAttempts);
  const lockoutMinutes = intOrNull(settings.loginLockoutMinutes);
  const activityDays = intOrNull(settings.activityLogRetentionDays);
  const auditMonths = intOrNull(settings.auditLogArchiveMonths);

  function errorOf(key) {
    return fieldErrors[key] ? <span className="field-error" role="alert">{fieldErrors[key]}</span> : null;
  }

  function textField(key, label, { type = "text", placeholder, ltr, span2, counter } = {}) {
    return (
      <div className={`field ss-field ${fieldErrors[key] ? "has-error" : ""} ${span2 ? "ss-span-2" : ""}`}>
        <label htmlFor={`ss-${key}`}>{label}</label>
        <input id={`ss-${key}`} type={type} placeholder={placeholder} dir={ltr ? "ltr" : undefined} {...field(key)} />
        {counter}
        {errorOf(key)}
      </div>
    );
  }

  function numberField(key, label, unit, hint, placeholder) {
    const [min, max] = NUMBER_RULES[key];
    return (
      <div className={`field ss-field ${fieldErrors[key] ? "has-error" : ""}`}>
        <label htmlFor={`ss-${key}`}>{label}</label>
        <div className="ss-unit">
          <input id={`ss-${key}`} type="number" inputMode="numeric" min={min} max={max} placeholder={placeholder} {...field(key)} />
          <span className="ss-unit-label">{unit}</span>
        </div>
        {hint && <span className="field-hint">{hint}</span>}
        {errorOf(key)}
      </div>
    );
  }

  function renderPanel() {
    switch (active) {
      case "hospital":
        return (
          <Card icon="🏥" title="اطلاعات شفاخانه" desc="این اطلاعات در هدر، فوتر، صفحه‌ی تماس و مدارک چاپی (فاکتور/نسخه) سایت نمایش داده می‌شود.">
            <div className="ss-grid">
              {textField("hospitalName", "نام شفاخانه")}
              {textField("hospitalPhone", "شماره تماس", { placeholder: "07XXXXXXXX", ltr: true })}
              {textField("hospitalEmail", "ایمیل شفاخانه", { type: "email", ltr: true })}
              {textField("hospitalAddress", "آدرس", {
                counter: <span className={`ss-counter ${addressLen > 300 ? "is-over" : ""}`}>{toFa(addressLen)} / {toFa(300)}</span>,
              })}
              <div className={`field ss-field ss-span-2 ${fieldErrors.hospitalDescription ? "has-error" : ""}`}>
                <label htmlFor="ss-hospitalDescription">توضیحات</label>
                <textarea id="ss-hospitalDescription" rows={4} {...field("hospitalDescription")} />
                <div className="ss-field-meta">
                  <span>{errorOf("hospitalDescription")}</span>
                  <span className={`ss-counter ${descLen > 500 ? "is-over" : ""}`}>{toFa(descLen)} / {toFa(500)}</span>
                </div>
              </div>
            </div>
          </Card>
        );

      case "appearance":
        return (
          <>
            <Card icon="🌐" title="زبان و منطقه" desc="زبان پیش‌فرض و منطقه‌ی زمانی سیستم.">
              <div className="ss-grid">
                <div className={`field ss-field ${fieldErrors.defaultLanguage ? "has-error" : ""}`}>
                  <label htmlFor="ss-defaultLanguage">زبان پیش‌فرض</label>
                  <select id="ss-defaultLanguage" {...field("defaultLanguage")}>
                    <option value="fa">دری</option>
                    <option value="ps">پشتو</option>
                    <option value="en">English</option>
                  </select>
                  {errorOf("defaultLanguage")}
                </div>
                <div className={`field ss-field ${fieldErrors.timezone ? "has-error" : ""}`}>
                  <label htmlFor="ss-timezone">منطقه‌ی زمانی</label>
                  <select id="ss-timezone" className="ss-ltr" {...field("timezone")}>
                    {tzOptions.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
                  </select>
                  {errorOf("timezone")}
                </div>
              </div>
            </Card>
            <Card icon="🎨" title="ظاهر سیستم" desc="تم ظاهری پیش‌فرض سیستم را انتخاب کنید.">
              <Choices
                label="تم ظاهری"
                value={settings.theme}
                onChange={(v) => setValue("theme", v)}
                options={[
                  { value: "dark", icon: "🌙", label: "تیره" },
                  { value: "light", icon: "☀️", label: "روشن" },
                  { value: "auto", icon: "🖥️", label: "خودکار", sub: "بر اساس سیستم" },
                ]}
              />
              {errorOf("theme")}
            </Card>
          </>
        );

      case "comms":
        return (
          <>
            <Card icon="📧" title="ایمیل" desc="تنظیمات ارسال ایمیل‌های سیستم. اتصال SMTP همچنان در تنظیمات سرور انجام می‌شود.">
              <div className="ss-grid">
                {textField("emailFromName", "نام فرستنده ایمیل‌ها", { span2: true })}
              </div>
              <Toggle
                id="ss-emailNotificationsEnabled"
                checked={settings.emailNotificationsEnabled === "on"}
                onChange={(v) => setValue("emailNotificationsEnabled", v)}
                label="ارسال ایمیل"
                description="ارسال ایمیل‌های کد تأیید و بازیابی رمز عبور"
              />
              {errorOf("emailNotificationsEnabled")}
            </Card>
            <Card icon="🔔" title="اعلان‌ها" desc="اعلان‌هایی که داخل خود سیستم به کاربران نمایش داده می‌شود.">
              <Toggle
                id="ss-inAppNotificationsEnabled"
                checked={settings.inAppNotificationsEnabled === "on"}
                onChange={(v) => setValue("inAppNotificationsEnabled", v)}
                label="اعلان‌های داخل‌سیستمی"
                description="نمایش اعلان‌ها در زنگوله‌ی بالای صفحه"
              />
              {errorOf("inAppNotificationsEnabled")}
            </Card>
          </>
        );

      case "appointments":
        return (
          <Card icon="📅" title="تنظیمات نوبت‌دهی" desc="قوانین رزرو، تأیید، لغو و یادآوری نوبت‌ها برای بیماران.">
            <div className="ss-grid">
              {numberField("appointmentBookingWindowDays", "بازه‌ی مجاز رزرو نوبت", "روز", "تعداد روزهایی که بیمار می‌تواند از امروز به بعد نوبت رزرو کند. ۰ = بدون محدودیت.", "۰ = بدون محدودیت")}
              <div className={`field ss-field ${fieldErrors.appointmentApprovalMode ? "has-error" : ""}`}>
                <label htmlFor="ss-appointmentApprovalMode">حالت تأیید نوبت‌های جدید</label>
                <select id="ss-appointmentApprovalMode" {...field("appointmentApprovalMode")}>
                  <option value="manual">دستی (نیازمند تأیید داکتر/ادمین)</option>
                  <option value="auto">خودکار (تأیید فوری هنگام ثبت)</option>
                </select>
                <span className="field-hint">مشخص می‌کند نوبت تازه‌ثبت‌شده منتظر تأیید بماند یا بلافاصله تأیید شود.</span>
                {errorOf("appointmentApprovalMode")}
              </div>
              {numberField("appointmentSlotCapacity", "ظرفیت هر ساعت", "بیمار", "حداکثر تعداد بیمار قابل پذیرش در یک بازه‌ی زمانی (هر ساعت).", "مثلاً 10")}
              {numberField("appointmentCancelMinHours", "مهلت لغو نوبت", "ساعت", "حداقل چند ساعت قبل از نوبت، بیمار می‌تواند نوبت خود را لغو کند. ۰ = تا لحظه‌ی نوبت.", "۰ = تا لحظه‌ی نوبت")}
              {numberField("appointmentReminderHours", "زمان یادآوری نوبت", "ساعت", "چند ساعت قبل از نوبت، یادآوری برای بیمار ارسال شود. ۰ = یادآوری غیرفعال.", "۰ = یادآوری غیرفعال")}
            </div>
          </Card>
        );

      case "security":
        return (
          <Card icon="🔐" title="امنیت ورود" desc="محدودسازی تلاش‌های ناموفق ورود برای هر حساب." className="ss-card-security">
            <div className="ss-security-box">
              <strong>🛡️ محافظت از حساب کاربران</strong>
              <p>
                پس از تعداد مشخصی تلاش ناموفق، حساب برای مدت تعیین‌شده موقتاً قفل می‌شود. این قفل برای هر حساب جداگانه
                اعمال می‌شود و مستقل از محدودیت تعداد درخواست بر اساس IP است.
              </p>
            </div>
            <div className="ss-grid">
              {numberField("loginMaxFailedAttempts", "حداکثر تلاش ناموفق مجاز", "تلاش")}
              {numberField("loginLockoutMinutes", "مدت قفل موقت حساب", "دقیقه")}
            </div>
            {maxAttempts !== null && lockoutMinutes !== null && (
              <div className="ss-live-summary">
                با مقادیر فعلی، بعد از <b>{toFa(maxAttempts)}</b> تلاش ناموفق پیاپی، حساب برای <b>{toFa(lockoutMinutes)}</b> دقیقه قفل می‌شود.
              </div>
            )}
          </Card>
        );

      case "logs":
        return (
          <Card icon="📋" title="مدیریت نگهداری لاگ‌ها" desc="کنترل رشد جدول‌های لاگ و آرشیو خودکار لاگ‌های قدیمی.">
            <div className="ss-stats">
              <div className="ss-stat">
                <span className="ss-stat-title">لاگ فعالیت</span>
                <span className="ss-stat-value">
                  {activityDays === null ? "—" : activityDays === 0 ? "بدون حذف خودکار" : <><small>نگهداری برای: </small>{toFa(activityDays)} <small>روز</small></>}
                </span>
              </div>
              <div className="ss-stat">
                <span className="ss-stat-title">لاگ حسابرسی</span>
                <span className="ss-stat-value">
                  {auditMonths === null ? "—" : auditMonths === 0 ? "آرشیو غیرفعال" : <><small>آرشیو پس از: </small>{toFa(auditMonths)} <small>ماه</small></>}
                </span>
              </div>
            </div>
            <div className="ss-grid">
              {numberField("activityLogRetentionDays", "مدت نگهداری لاگ فعالیت", "روز", null, "۰ = هرگز حذف نشود")}
              {numberField("auditLogArchiveMonths", "آرشیو لاگ حسابرسی پس از", "ماه", null, "۰ = آرشیو غیرفعال")}
            </div>
            <p className="field-hint" style={{ margin: 0 }}>
              هر شب، لاگ فعالیت‌های قدیمی‌تر از مدت بالا حذف می‌شوند. لاگ‌های حسابرسی قدیمی‌تر ابتدا در یک فایل فشرده آرشیو
              می‌شوند و فقط پس از تأیید سالم بودن فایل از جدول اصلی برداشته می‌شوند.
            </p>
          </Card>
        );

      case "system":
        return (
          <Card icon="⚙️" title="تنظیمات سیستم" desc="تنظیمات کلی و فنی سیستم.">
            <div>
              <div className="ss-toggle-text" style={{ marginBottom: 10 }}>
                <label style={{ cursor: "default" }}>حالت تعمیرات (Maintenance Mode)</label>
                <span className="field-hint">در این حالت ممکن است دسترسی کاربران عمومی به سیستم محدود شود.</span>
              </div>
              <Choices
                label="حالت تعمیرات"
                columns={2}
                value={settings.maintenanceMode}
                onChange={(v) => setValue("maintenanceMode", v)}
                options={[
                  { value: "off", label: "خاموش" },
                  { value: "on", label: "روشن", warn: true },
                ]}
              />
              {errorOf("maintenanceMode")}
            </div>
            {maintenanceFormOn && (
              <Alert tone="warn" icon="⚠️" role="alert">
                توجه: حالت تعمیرات فعال است و ممکن است دسترسی کاربران عمومی به سیستم محدود شود.
              </Alert>
            )}
          </Card>
        );

      case "logo":
        return (
          <Card icon="🖼️" title="لوگوی شفاخانه" desc="فرمت‌های مجاز: JPG، PNG و WEBP — حداکثر حجم ۲ مگابایت. لوگو بلافاصله پس از انتخاب فایل آپلود می‌شود.">
            <div className="ss-logo-row">
              <div className="ss-logo-preview">
                {settings.logoUrl ? <img src={resolvePhotoUrl(settings.logoUrl)} alt="لوگوی شفاخانه" /> : "بدون لوگو"}
              </div>
              <div className="ss-logo-info">
                {logoName && (
                  <div className="ss-logo-file">
                    <span>نام فایل ذخیره‌شده</span>
                    <span className="ss-mono">{logoName}</span>
                  </div>
                )}
                <div className="ss-logo-actions">
                  <label className={`btn btn-ghost btn-sm ss-upload-label ${logoBusy ? "is-disabled" : ""}`}>
                    {logoBusy === "upload" ? "در حال آپلود..." : "آپلود لوگوی جدید"}
                    <input
                      className="ss-sr-only"
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      onChange={handleLogoUpload}
                      disabled={!!logoBusy}
                    />
                  </label>
                  {settings.logoUrl && !confirmRemove && (
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirmRemove(true)} disabled={!!logoBusy}>
                      {logoBusy === "remove" ? "در حال حذف..." : "حذف لوگو"}
                    </button>
                  )}
                  {settings.logoUrl && confirmRemove && (
                    <span className="ss-confirm">
                      لوگو حذف شود؟
                      <button type="button" className="btn btn-ghost btn-sm btn-confirm-remove" onClick={handleLogoRemove} disabled={!!logoBusy}>بله، حذف شود</button>
                      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirmRemove(false)}>انصراف</button>
                    </span>
                  )}
                </div>
                {logoBusy && (
                  <div role="status" aria-live="polite">
                    <div className="ss-busy" />
                    <span className="field-hint">{logoBusy === "upload" ? "در حال آپلود لوگو، لطفاً صبر کنید..." : "در حال حذف لوگو..."}</span>
                  </div>
                )}
              </div>
            </div>
          </Card>
        );

      default:
        return null;
    }
  }

  const saveLabel =
    saveState === "saving" ? "در حال ذخیره..." : saveState === "success" ? "ذخیره شد ✓" : saveState === "error" ? "تلاش دوباره برای ذخیره" : "ذخیره تغییرات";

  return (
    <div className="dash-card glass ss-scope">
      <header className="ss-header">
        <div className="ss-header-icon" aria-hidden="true">⚙️</div>
        <div className="ss-header-text">
          <h2>تنظیمات سیستم</h2>
          <p>مدیریت تنظیمات عمومی، عملیاتی، امنیتی و فنی سیستم</p>
        </div>
        <div className="ss-header-status">
          <span className="ss-chip ss-chip-ok"><i className="ss-dot" />سیستم فعال</span>
          {maintenanceActive ? (
            <span className="ss-chip ss-chip-warn">حالت تعمیرات فعال است</span>
          ) : (
            <span className="ss-chip">سیستم در حالت عادی فعال است</span>
          )}
          {dirty && <span className="ss-chip ss-chip-pending">تغییرات ذخیره نشده</span>}
        </div>
      </header>

      <div className="ss-note">🔒 این بخش فقط برای مدیر کل (Super Admin) قابل مشاهده و ویرایش است.</div>

      <div className="ss-layout">
        <nav className="ss-nav" role="tablist" aria-label="دسته‌بندی تنظیمات">
          {SECTIONS.map((s) => (
            <button
              key={s.key}
              type="button"
              role="tab"
              id={`ss-tab-${s.key}`}
              aria-selected={active === s.key}
              aria-controls="ss-tabpanel"
              className={`ss-nav-item ${active === s.key ? "is-active" : ""}`}
              onClick={() => setActive(s.key)}
            >
              <span className="ss-nav-icon" aria-hidden="true">{s.icon}</span>
              <span className="ss-nav-label">{s.label}</span>
              {errorCountBySection[s.key] ? (
                <span className="ss-nav-badge" title="فیلد دارای خطا">{toFa(errorCountBySection[s.key])}</span>
              ) : dirtyBySection[s.key] ? (
                <span className="ss-nav-dirty" title="تغییر ذخیره‌نشده" />
              ) : null}
            </button>
          ))}
        </nav>

        <div className="ss-main">
          {status.text && (
            <Alert tone={status.type === "success" ? "success" : "error"} icon={status.type === "success" ? "✅" : "⛔"} role={status.type === "success" ? "status" : "alert"}>
              {status.text}
            </Alert>
          )}

          <form className="ss-form" onSubmit={save} noValidate>
            <div className="ss-panel" role="tabpanel" id="ss-tabpanel" aria-labelledby={`ss-tab-${active}`}>
              {renderPanel()}
            </div>

            {showSaveBar && (
              <div className={`ss-savebar ${dirty ? "is-dirty" : ""}`}>
                <div className="ss-savebar-info" aria-live="polite">
                  {saveState === "success" ? (
                    <span className="ss-ok">✓ تنظیمات با موفقیت ذخیره شد.</span>
                  ) : dirty ? (
                    <span className="ss-pending"><i className="ss-dot" />تغییرات ذخیره نشده</span>
                  ) : (
                    <span className="ss-muted">همه‌ی تغییرات ذخیره شده است</span>
                  )}
                </div>
                <div className="ss-savebar-actions">
                  {dirty && (
                    <button type="button" className="btn btn-ghost btn-sm" onClick={discardChanges} disabled={saving}>لغو تغییرات</button>
                  )}
                  <button className="btn btn-primary" type="submit" disabled={saving || !dirty}>
                    {saveLabel}
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useState } from "react";
import { AlertTriangle, CalendarCheck, ChartPie, Clock, Inbox, LayoutDashboard, RefreshCw, Stethoscope, UserRound, Users } from "lucide-react";
import { apiRequest } from "../../../../utils/api.js";
import "./DatabaseOverview.css";

// برچسب‌های نمایشی (فقط Frontend). مقدار واقعی role/status از API تغییر نمی‌کند و
// اگر API مقدار جدیدی برگرداند، همان مقدار خام با ظاهر خنثی نمایش داده می‌شود.
const ROLE_META = {
  user: { name: "بیمار", tone: "info" },
  doctor: { name: "داکتر", tone: "ok" },
  admin: { name: "ادمین", tone: "warn" },
  superadmin: { name: "مدیر کل", tone: "violet" },
};
const STATUS_META = {
  pending: { name: "در انتظار تایید", tone: "warn" },
  confirmed: { name: "تایید شده", tone: "info" },
  completed: { name: "انجام‌شده", tone: "ok" },
  cancelled: { name: "لغوشده", tone: "danger" },
};

function toFa(value) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toLocaleString("fa-IR-u-ca-persian", { useGrouping: false }) : "—";
}
function fmtPercent(p) {
  if (p === null) return "—";
  return `${(Math.round(p * 10) / 10).toLocaleString("fa-IR-u-ca-persian", { maximumFractionDigits: 1 })}٪`;
}

// ردیف‌های خام API را (بدون افزودن نقش/وضعیت ساختگی) به ردیف‌های قابل نمایش همراه با درصد تبدیل می‌کند
function buildRows(list, field, metaMap) {
  if (!Array.isArray(list)) return { rows: [], total: null };
  const rows = list.map((item) => {
    const key = String(item?.[field] ?? "");
    const count = Number(item?.count);
    return { key, count: Number.isFinite(count) ? count : 0, meta: metaMap[key] || null };
  });
  const total = rows.reduce((sum, r) => sum + r.count, 0);
  return { rows: rows.map((r) => ({ ...r, pct: total > 0 ? (r.count / total) * 100 : null })), total };
}

function sumOrNull(list) {
  return Array.isArray(list) ? list.reduce((s, i) => s + (Number(i?.count) || 0), 0) : null;
}

// پیام خطا: عنوان ثابت فارسی + پیام کوتاه واقعیِ برگشتی (در صورت امن‌بودن)؛ بدون جزئیات فنی
function errInfo(err) {
  const msg = err && err.message ? String(err.message).trim() : "";
  const technical = /\bat\s+\S+\s*\(|node_modules|ER_[A-Z_]+|SQL|\.js:\d+/i.test(msg);
  return { detail: msg && msg.length <= 200 && !technical ? msg : "" };
}

function Kpi({ icon, title, value, sub, tone }) {
  return (
    <div className={`ov-kpi ov-tone-${tone}`}>
      <div className="ov-kpi-icon" aria-hidden="true">{icon}</div>
      <div className="ov-kpi-body">
        <span className="ov-kpi-title">{title}</span>
        <strong className="ov-kpi-value">{value}</strong>
        <span className="ov-kpi-sub">{sub}</span>
      </div>
    </div>
  );
}

function Distribution({ icon, title, desc, totalLabel, list, field, metaMap, nameOf }) {
  const { rows, total } = buildRows(list, field, metaMap);
  return (
    <section className="ov-card">
      <div className="ov-card-head">
        <div className="ov-card-icon" aria-hidden="true">{icon}</div>
        <div>
          <h3 className="ov-card-title">{title}</h3>
          <p className="ov-card-desc">{desc}</p>
        </div>
        {rows.length > 0 && (
          <div className="ov-card-total"><strong>{toFa(total)}</strong><span>{totalLabel}</span></div>
        )}
      </div>

      {rows.length === 0 ? (
        <div className="ov-state is-inline">
          <Inbox size={30} aria-hidden="true" />
          <p>اطلاعاتی برای نمایش وجود ندارد</p>
        </div>
      ) : (
        <>
          {total > 0 && (
            <div className="ov-stack" aria-hidden="true">
              {rows.filter((r) => r.count > 0).map((r) => (
                <span key={r.key} className={`ov-tone-${r.meta ? r.meta.tone : "neutral"}`} style={{ flexGrow: r.count, flexBasis: 0 }} />
              ))}
            </div>
          )}
          <ul className="ov-rows">
            {rows.map((r) => {
              const tone = r.meta ? r.meta.tone : "neutral";
              const name = nameOf(r);
              return (
                <li key={r.key} className={`ov-row ov-tone-${tone}`}>
                  <div className="ov-row-top">
                    <span className="ov-chip"><span className="ov-dot" />{name}</span>
                    {name !== r.key && r.key && <span className="ov-key">{r.key}</span>}
                    <div className="ov-row-nums">
                      <span className="ov-count">{toFa(r.count)}</span>
                      <span className="ov-pct">{fmtPercent(r.pct)}</span>
                    </div>
                  </div>
                  <div className="ov-bar" aria-hidden="true"><span style={{ width: `${r.pct === null ? 0 : r.pct}%` }} /></div>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </section>
  );
}

function OverviewSkeleton() {
  return (
    <div aria-busy="true" aria-label="در حال بارگذاری آمار" style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      <div className="ov-kpis">
        {Array.from({ length: 4 }).map((_, i) => <div key={i} className="ov-skel" style={{ height: 96, borderRadius: 14 }} />)}
      </div>
      <div className="ov-grid">
        <div className="ov-skel" style={{ height: 300, borderRadius: 14 }} />
        <div className="ov-skel" style={{ height: 300, borderRadius: 14 }} />
      </div>
    </div>
  );
}

export default function DatabaseOverview() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [refreshing, setRefreshing] = useState(true);
  const [updatedAt, setUpdatedAt] = useState(null);

  // همان API و همان ساختار قبلی (d.tables)؛ تلاش مجدد/بروزرسانی فقط همین درخواست را دوباره می‌فرستد
  const load = useCallback(() => {
    setRefreshing(true);
    setError(null);
    return apiRequest("/superadmin/database-overview")
      .then((d) => {
        setData(d.tables || {});
        setUpdatedAt(new Date());
      })
      .catch((err) => setError(errInfo(err)))
      .finally(() => setRefreshing(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  const patients = data ? Number(data.patients) : NaN;
  const doctors = data ? Number(data.doctors) : NaN;
  const usersTotal = data ? sumOrNull(data.users) : null;
  const apptTotal = data ? sumOrNull(data.appointments) : null;

  return (
    <div className="dash-card glass ov-scope">
      <header className="ov-header">
        <div className="ov-header-icon" aria-hidden="true"><LayoutDashboard size={24} /></div>
        <div className="ov-header-text">
          <h2>داشبورد و آمار اصلی</h2>
          <p>نمای کلی وضعیت کاربران، بیماران، داکتران و نوبت‌های سیستم</p>
        </div>
        <div className="ov-header-actions">
          {updatedAt && (
            <span className="ov-updated" title={updatedAt.toLocaleString("fa-IR-u-ca-persian")}>
              <Clock size={14} aria-hidden="true" />
              آخرین بروزرسانی: {updatedAt.toLocaleTimeString("fa-IR-u-ca-persian", { hour: "2-digit", minute: "2-digit" })}
            </span>
          )}
          <button type="button" className="btn btn-ghost btn-sm" onClick={load} disabled={refreshing} aria-busy={refreshing}>
            <RefreshCw size={14} aria-hidden="true" />{refreshing ? "در حال بروزرسانی..." : "بروزرسانی"}
          </button>
        </div>
      </header>

      {!data && !error && <OverviewSkeleton />}

      {!data && error && (
        <div className="ov-state is-error" role="alert">
          <AlertTriangle size={36} aria-hidden="true" />
          <p>بارگذاری آمار داشبورد با مشکل مواجه شد.</p>
          {error.detail && <small>{error.detail}</small>}
          <button type="button" className="btn btn-primary btn-sm" onClick={load} disabled={refreshing}>
            <RefreshCw size={14} aria-hidden="true" />{refreshing ? "در حال تلاش..." : "تلاش مجدد"}
          </button>
        </div>
      )}

      {data && (
        <>
          {error && (
            <div className="ov-alert" role="alert">
              <AlertTriangle size={18} aria-hidden="true" />
              <div className="ov-alert-text">
                <strong>بروزرسانی آمار با مشکل مواجه شد. اطلاعات زیر ممکن است قدیمی باشد.</strong>
                {error.detail}
              </div>
              <button type="button" className="btn btn-ghost btn-sm" onClick={load} disabled={refreshing}>تلاش مجدد</button>
            </div>
          )}

          <div className="ov-kpis">
            <Kpi tone="info" icon={<UserRound size={22} />} title="کل بیماران" value={toFa(patients)} sub="بیماران ثبت‌شده در سیستم" />
            <Kpi tone="ok" icon={<Stethoscope size={22} />} title="کل داکتران" value={toFa(doctors)} sub="داکتران ثبت‌شده در سیستم" />
            <Kpi tone="violet" icon={<Users size={22} />} title="کل کاربران" value={toFa(usersTotal)} sub="مجموع کاربران همه‌ی نقش‌ها" />
            <Kpi tone="warn" icon={<CalendarCheck size={22} />} title="کل نوبت‌ها" value={toFa(apptTotal)} sub="مجموع نوبت‌ها در همه‌ی وضعیت‌ها" />
          </div>

          <div className="ov-grid">
            <Distribution
              icon={<Users size={20} />} title="توزیع کاربران" desc="کاربران به تفکیک نقش" totalLabel="کل کاربران"
              list={data.users} field="role" metaMap={ROLE_META}
              nameOf={(r) => (r.meta ? r.meta.name : r.key || "نامشخص")}
            />
            <Distribution
              icon={<ChartPie size={20} />} title="وضعیت نوبت‌ها" desc="نوبت‌ها به تفکیک وضعیت" totalLabel="کل نوبت‌ها"
              list={data.appointments} field="status" metaMap={STATUS_META}
              nameOf={(r) => (r.meta ? r.meta.name : r.key || "نامشخص")}
            />
          </div>
        </>
      )}
    </div>
  );
}

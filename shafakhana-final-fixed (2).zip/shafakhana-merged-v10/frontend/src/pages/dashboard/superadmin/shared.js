// توابع/ثابت‌های فارسی مشترک بین چند بخش داشبورد Super Admin — تا در هر فایل دوباره
// تعریف نشوند و همیشه هم‌راستا بمانند.

export const ROLE_LABEL_FA = {
  user: "بیمار (User)",
  doctor: "داکتر (Doctor)",
  admin: "ادمین (Admin)",
  superadmin: "مدیر کل (Super Admin)",
};

export function defaultLogDateFrom() {
  const d = new Date();
  d.setDate(d.getDate() - 30);
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// اجزای مشترک UI برای دو صفحه‌ی «لاگ فعالیت‌ها» و «لاگ حسابرسی» (Super Admin).
// فقط ظاهر و کمک‌تابع‌های نمایشی؛ هیچ منطق Backend یا فیلتری اینجا تغییر نمی‌کند.
import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { ShieldCheck, UserCog, Stethoscope, User, ChevronLeft, ChevronRight, X, SearchX } from "lucide-react";
import { apiRequest, API_BASE, authFetch } from "../../../utils/api.js";

import { formatJalaliDate } from "../../../utils/jalali.js";
/* ---------- نقش‌ها ---------- */
export const LOG_ROLES = {
  superadmin: { label: "سوپر ادمین", Icon: ShieldCheck },
  admin: { label: "ادمین", Icon: UserCog },
  doctor: { label: "داکتر", Icon: Stethoscope },
  user: { label: "بیمار", Icon: User },
};

export function roleMeta(role) {
  return LOG_ROLES[role] || { label: role || "-", Icon: User };
}

export function RoleBadge({ role }) {
  if (!role) return <span className="lg-muted">-</span>;
  const { label, Icon } = roleMeta(role);
  return (
    <span className={`lg-badge lg-tone-${LOG_ROLES[role] ? role : "neutral"}`}>
      <Icon size={13} aria-hidden="true" />
      {label}
    </span>
  );
}

/* ---------- قالب‌بندی فارسی ---------- */
export function faNum(n) {
  return Number(n || 0).toLocaleString("fa-IR-u-ca-persian");
}

function toDate(v) {
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? null : d;
}
export function faDateTime(v) {
  const d = toDate(v);
  return d ? d.toLocaleString("fa-IR-u-ca-persian") : "-";
}
export function faDate(v) {
  const d = toDate(v);
  return d ? formatJalaliDate(d, { month: "long" }) : "-";
}
export function faTime(v) {
  const d = toDate(v);
  return d ? d.toLocaleTimeString("fa-IR-u-ca-persian", { hour: "2-digit", minute: "2-digit" }) : "-";
}

export function todayStr() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

// خلاصه‌ی خوانا از User-Agent (فقط تفسیر همان رشته‌ی واقعی ثبت‌شده)
export function shortUserAgent(ua) {
  if (!ua) return null;
  let browser = null;
  if (/Edg\//.test(ua)) browser = "Edge";
  else if (/OPR\/|Opera/.test(ua)) browser = "Opera";
  else if (/Firefox\//.test(ua)) browser = "Firefox";
  else if (/Chrome\//.test(ua)) browser = "Chrome";
  else if (/Safari\//.test(ua)) browser = "Safari";
  else if (/PostmanRuntime/i.test(ua)) browser = "Postman";
  else if (/curl/i.test(ua)) browser = "curl";
  let os = null;
  if (/Windows/.test(ua)) os = "Windows";
  else if (/Android/.test(ua)) os = "Android";
  else if (/iPhone|iPad|iPod/.test(ua)) os = "iOS";
  else if (/Mac OS X|Macintosh/.test(ua)) os = "macOS";
  else if (/Linux/.test(ua)) os = "Linux";
  const parts = [browser, os].filter(Boolean);
  return parts.length ? parts.join(" · ") : null;
}

/* ---------- درخواست‌های کمکی (همان APIهای فعلی) ---------- */
// فقط total (و اولین رکورد) را از همان API فیلترشده‌ی موجود می‌گیرد: limit=1 — بدون API جدید
export async function fetchLogTotal(path, params = {}) {
  const qs = new URLSearchParams({ ...params, page: 1, limit: 1 });
  const d = await apiRequest(`${path}?${qs.toString()}`);
  return { total: d.pagination?.total ?? 0, first: d.logs?.[0] || null };
}

export async function downloadLogCsv(url, filename, fallbackMessage) {
  const res = await authFetch(url);
  if (!res.ok) {
    const data = await res.json().catch(() => null);
    throw new Error((data && data.message) || fallbackMessage);
  }
  const blob = await res.blob();
  const objectUrl = window.URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = objectUrl;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.URL.revokeObjectURL(objectUrl);
}
export { API_BASE };

/* ---------- KPI ---------- */
export function LogKpiCard({ icon: Icon, label, value, hint, tone = "neutral", loading }) {
  return (
    <div className={`lg-kpi lg-tone-${tone}`}>
      <div className="lg-kpi-top">
        <span className="lg-kpi-icon" aria-hidden="true">{Icon && <Icon size={17} />}</span>
        <span className="lg-kpi-label">{label}</span>
      </div>
      {loading ? (
        <span className="lg-skel lg-skel-kpi" />
      ) : (
        <strong className="lg-kpi-value">{value ?? "—"}</strong>
      )}
      {hint && !loading && <span className="lg-kpi-hint">{hint}</span>}
    </div>
  );
}

/* ---------- Skeleton ---------- */
export function SkeletonRows({ rows = 8, cols = 6 }) {
  return (
    <div className="lg-skel-table" aria-busy="true" aria-label="در حال بارگذاری">
      {Array.from({ length: rows }).map((_, r) => (
        <div className="lg-skel-row" key={r}>
          {Array.from({ length: cols }).map((__, c) => (
            <span className="lg-skel" key={c} style={{ flex: c === 0 ? "0.6" : c === cols - 2 ? "1.6" : "1" }} />
          ))}
        </div>
      ))}
    </div>
  );
}

export function SkeletonFeed({ rows = 6 }) {
  return (
    <div className="lg-skel-table" aria-busy="true" aria-label="در حال بارگذاری">
      {Array.from({ length: rows }).map((_, i) => (
        <div className="lg-skel-feed" key={i}>
          <span className="lg-skel lg-skel-dot" />
          <span className="lg-skel-feed-lines">
            <span className="lg-skel" style={{ width: "55%" }} />
            <span className="lg-skel" style={{ width: "80%" }} />
          </span>
        </div>
      ))}
    </div>
  );
}

/* ---------- Empty ---------- */
export function LogEmptyState({ message, onReset }) {
  return (
    <div className="lg-empty">
      <span className="lg-empty-icon" aria-hidden="true"><SearchX size={26} /></span>
      <p>{message}</p>
      {onReset && (
        <button type="button" className="btn btn-ghost btn-sm" onClick={onReset}>
          پاک کردن فیلترها
        </button>
      )}
    </div>
  );
}

/* ---------- Pagination ---------- */
export function LogPagination({ page, totalPages, total, onPage }) {
  return (
    <nav className="lg-pagination" aria-label="صفحه‌بندی">
      <span className="lg-pg-total">{faNum(total)} رکورد</span>
      <div className="lg-pg-controls">
        <button type="button" className="btn btn-ghost btn-sm" disabled={page <= 1} onClick={() => onPage(Math.max(1, page - 1))}>
          <ChevronRight size={15} aria-hidden="true" /> قبلی
        </button>
        <span className="lg-pg-page">صفحه {faNum(page)} از {faNum(totalPages)}</span>
        <button type="button" className="btn btn-ghost btn-sm" disabled={page >= totalPages} onClick={() => onPage(Math.min(totalPages, page + 1))}>
          بعدی <ChevronLeft size={15} aria-hidden="true" />
        </button>
      </div>
    </nav>
  );
}

/* ---------- Drawer ---------- */
// کشوی کناری استاندارد برای جزئیات؛ با Portal تا زیر backdrop-filter کارت‌های شیشه‌ای گیر نکند
// (همان دلیل GlobalModal). z-index هم‌سطح GlobalModal است (پنل اعلان‌ها همچنان بالاتر می‌ماند).
export function LogDrawer({ open, onClose, title, subtitle, icon: Icon, variant = "activity", children }) {
  const titleId = useRef(`lg-drawer-title-${Math.random().toString(36).slice(2, 9)}`).current;

  useEffect(() => {
    if (!open) return undefined;
    function onKey(e) {
      if (e.key === "Escape") onClose && onClose();
    }
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [open, onClose]);

  if (!open) return null;

  return createPortal(
    <div className={`lg-drawer-overlay lg-${variant}`} role="presentation" onClick={onClose}>
      <aside
        className="lg-drawer"
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onClick={(e) => e.stopPropagation()}
      >
        <header className="lg-drawer-head">
          {Icon && <span className="lg-drawer-icon" aria-hidden="true"><Icon size={20} /></span>}
          <div className="lg-drawer-titles">
            <h3 id={titleId}>{title}</h3>
            {subtitle && <p>{subtitle}</p>}
          </div>
          <button type="button" className="lg-drawer-close" onClick={onClose} aria-label="بستن">
            <X size={18} />
          </button>
        </header>
        <div className="lg-drawer-body">{children}</div>
      </aside>
    </div>,
    document.body
  );
}

export function DetailRow({ label, children }) {
  return (
    <div className="lg-detail-row">
      <span className="lg-detail-label">{label}</span>
      <div className="lg-detail-value">{children}</div>
    </div>
  );
}

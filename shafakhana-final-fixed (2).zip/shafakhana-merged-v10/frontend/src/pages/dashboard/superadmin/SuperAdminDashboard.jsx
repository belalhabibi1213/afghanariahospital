// این فایل فقط تب‌ها را تعریف و کامپوننت هر تب را رندر می‌کند. برای کاهش حجم فایل (که قبلاً
// نزدیک به ۱۹۰۰ خط و نگهداری‌اش سخت بود)، هر بخش داشبورد به فایل جداگانه‌ی خودش در پوشه‌ی
// sections/ منتقل شده؛ چند ثابت/تابع فارسی که بین دو بخش مشترک بودند (برچسب نقش‌ها، تاریخ
// پیش‌فرض فیلتر لاگ‌ها) در shared.js قرار گرفتند تا در دو جا تکراری تعریف نشوند.
import DashboardShell from "../../../components/dashboard/DashboardShell.jsx";
import useTabState from "../../../hooks/useTabState.js";
import { useLanguage } from "../../../context/LanguageContext.jsx";
import { tr, trc } from "../../../i18n/tr.js";
import DatabaseOverview from "./sections/DatabaseOverview.jsx";
import SystemHealth from "./sections/SystemHealth.jsx";
import RoleAssignment from "./sections/RoleAssignment.jsx";
import AdminAccounts from "./sections/AdminAccounts.jsx";
import SystemSettings from "./sections/SystemSettings.jsx";
import ActivityLogs from "./sections/ActivityLogs.jsx";
import AuditLogs from "./sections/AuditLogs.jsx";
import PermissionsMatrix from "./sections/PermissionsMatrix.jsx";
import DatabaseBackups from "./sections/DatabaseBackups.jsx";
import SessionsDevices from "./sections/SessionsDevices.jsx";

// ترتیب تب‌ها بر اساس اهمیت/کاربرد: نمای کلی و سلامت ← حساب‌ها و دسترسی‌ها ← تنظیمات ← لاگ‌ها ← پشتیبان و نشست‌ها
const TABS = trc([
  { key: "overview", label: "داشبورد و آمار اصلی", icon: "🗄️" },
  { key: "health", label: "سلامت سیستم", icon: "🩺" },
  { key: "admins", label: "حساب‌های ادمین", icon: "🛡️" },
  { key: "roles", label: "تخصیص نقش‌ها", icon: "🎚️" },
  { key: "permissions", label: "مدیریت مجوزها", icon: "🔑" },
  { key: "settings", label: "تنظیمات سیستم", icon: "⚙️" },
  { key: "logs", label: "لاگ فعالیت‌ها", icon: "📜" },
  { key: "audit", label: "لاگ حسابرسی", icon: "🕵️" },
  { key: "backups", label: "پشتیبان‌گیری دیتابیس", icon: "💾" },
  { key: "sessions", label: "نشست‌ها و دستگاه‌ها", icon: "💻" },
]);

export default function SuperAdminDashboard() {
  const [activeTab, setActiveTab] = useTabState("overview");
  const { lang } = useLanguage();
  return (
    <DashboardShell key={lang} title={tr("داشبورد مدیر کل (Super Admin)")} tabs={TABS} activeTab={activeTab} onTabChange={setActiveTab}>
      {activeTab === "overview" && <DatabaseOverview />}
      {activeTab === "health" && <SystemHealth />}
      {activeTab === "roles" && <RoleAssignment />}
      {activeTab === "admins" && <AdminAccounts />}
      {activeTab === "settings" && <SystemSettings />}
      {activeTab === "logs" && <ActivityLogs />}
      {activeTab === "audit" && <AuditLogs />}
      {activeTab === "permissions" && <PermissionsMatrix />}
      {activeTab === "backups" && <DatabaseBackups />}
      {activeTab === "sessions" && <SessionsDevices />}
    </DashboardShell>
  );
}

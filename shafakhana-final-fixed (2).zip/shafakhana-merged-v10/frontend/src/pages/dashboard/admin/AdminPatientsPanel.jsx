// پنل «بیماران» (ادمین) — این فایل فقط نقطه‌ی ورودِ سازگار با کدهای قبلی است.
// کد اصلی به فایل‌های کوچک‌تر در پوشه‌ی ./patients تقسیم شده است:
//   patients/PatientsPanel.jsx             → لیست بیماران (جستجو، فیلتر، عملیات)
//   patients/PatientDetailPage.jsx         → صفحه‌ی جزئیات یک بیمار
//   patients/sections/Patient*Section.jsx  → هر بخش از صفحه‌ی جزئیات (شخصی، تماس، سوابق طبی، نسخه‌ها، ...)
//   patients/PatientPager.jsx              → صفحه‌بندی (در پنل صورت‌حساب هم استفاده می‌شود)
//   patients/ResetPasswordResultModal.jsx  → مودال نتیجه‌ی بازنشانی رمز
//   patients/patientUtils.js               → توابع و برچسب‌های مشترک (سن، تاریخ، جنسیت، ...)
export * from "./patients/PatientsPanel.jsx";
export * from "./patients/PatientDetailPage.jsx";
export * from "./patients/PatientPager.jsx";
export * from "./patients/ResetPasswordResultModal.jsx";
export * from "./patients/patientUtils.js";
export * from "./patients/sections/PatientProfileHeader.jsx";
export * from "./patients/sections/PatientPersonalSection.jsx";
export * from "./patients/sections/PatientContactSection.jsx";
export * from "./patients/sections/PatientMedicalSection.jsx";
export * from "./patients/sections/PatientPrescriptionsSection.jsx";
export * from "./patients/sections/PatientAppointmentsSection.jsx";
export * from "./patients/sections/PatientFilesSection.jsx";
export * from "./patients/sections/PatientTimelineSection.jsx";
export * from "./patients/sections/PatientBillingSection.jsx";
export * from "./patients/sections/PatientAllergiesSection.jsx";
export * from "./patients/sections/PatientDiseasesSection.jsx";

import { useEffect, useRef, useState } from "react";
import { Plus, Trash2, ArrowUp, ArrowDown, ImagePlus, Save, RotateCcw, ImageOff } from "lucide-react";
import { apiRequest, apiUpload, resolvePhotoUrl } from "../../../utils/api.js";
import { useDepartmentToasts, DepartmentToastContainer } from "../../../components/dashboard/DepartmentToast.jsx";
import { PageHead, StateBlock, ConfirmDialog } from "../../../components/admin/AdminPro.jsx";
import { photos } from "../../../data/photos.js";
import fa from "../../../i18n/locales/fa.js";
import ps from "../../../i18n/locales/ps.js";
import en from "../../../i18n/locales/en.js";
import { getCurrentLang } from "../../../i18n/languages.js";
import { tr, trc } from "../../../i18n/tr.js";
import "./AdminAboutPanel.css";
import "./AdminHeroPanel.css";

// ویرایش بخش اصلی (Hero) صفحه‌ی اصلی سایت: عکس پس‌زمینه، برچسب بالای تیتر، تیتر، متن، دو دکمه،
// آمارها و کارت ضربان به سه زبان. تا وقتی ادمین چیزی ذخیره نکرده، فرم با متن‌های پیش‌فرض فعلی
// سایت پر می‌شود تا ویرایش از همان متن موجود شروع شود.
const LANGS = trc([
  { code: "fa", label: "دری", dir: "rtl" },
  { code: "ps", label: "پښتو", dir: "rtl" },
  { code: "en", label: "English", dir: "ltr" },
]);
const DICT = { fa, ps, en };
const MAX_IMAGE_SIZE = 2 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_STATS = 6;
const MAX_PULSE = 4;
const DEFAULT_PRIMARY_LINK = "#appointment";
const DEFAULT_SECONDARY_LINK = "#doctors";
// لینک‌های آماده‌ی بخش‌های صفحه‌ی اصلی (برای انتخاب سریع)؛ لینک دلخواه هم قابل‌نوشتن است
const LINK_PRESETS = trc([
  { value: "#appointment", label: "گرفتن وقت ملاقات" },
  { value: "#doctors", label: "داکتران" },
  { value: "#services", label: "خدمات" },
  { value: "#about", label: "معرفی" },
  { value: "#news", label: "اخبار" },
  { value: "#contact", label: "تماس" },
]);
const LINK_RE = /^(#[A-Za-z0-9_-]{1,60}|\/(?!\/)[^\s]{0,250}|https?:\/\/[^\s]{1,280})$/;

const emptyLangs = () => ({ fa: "", ps: "", en: "" });
const newId = () => `h${Math.random().toString(36).slice(2, 10)}`;
const per = (get) => Object.fromEntries(LANGS.map(({ code }) => [code, get(DICT[code].hero) || ""]));

function defaultsFromLocales() {
  return {
    imageUrl: "",
    eyebrowVisible: true,
    eyebrow: per((h) => h.eyebrow),
    titleBefore: per((h) => h.titleBefore),
    titleAccent: per((h) => h.titleAccent),
    titleAfter: per((h) => h.titleAfter),
    lead: per((h) => h.lead),
    primaryButton: { text: per((h) => h.book), link: DEFAULT_PRIMARY_LINK },
    secondaryVisible: true,
    secondaryButton: { text: per((h) => h.seeDoctors), link: DEFAULT_SECONDARY_LINK },
    statsVisible: true,
    stats: ["years", "doctors", "emergency"].map((k) => ({ id: k, value: per((h) => h.stats?.[`${k}Value`]), label: per((h) => h.stats?.[k]) })),
    pulseVisible: true,
    pulse: [["bpm", "bpmValue"], ["status", "statusValue"], ["satisfaction", "satisfactionValue"]].map(([k, v]) => ({
      id: k, value: per((h) => h.pulse?.[v]), label: per((h) => h.pulse?.[k]),
    })),
  };
}

// محتوای ذخیره‌شده را کامل می‌کند: زبان‌های گمشده خالی می‌شوند و بخش‌هایی که هنوز ذخیره نشده‌اند
// (مثلاً وقتی فقط عکس آپلود شده) از پیش‌فرض سایت پر می‌شوند
function normalize(hero) {
  const d = defaultsFromLocales();
  const langs = (o, fallback) => ({ ...emptyLangs(), ...(o || fallback || {}) });
  const items = (list, fallback) => (Array.isArray(list)
    ? list.map((p) => ({ id: p.id || newId(), value: langs(p.value), label: langs(p.label) }))
    : fallback);
  return {
    imageUrl: hero.imageUrl || "",
    eyebrowVisible: hero.eyebrowVisible !== false,
    eyebrow: langs(hero.eyebrow, d.eyebrow),
    titleBefore: langs(hero.titleBefore, d.titleBefore),
    titleAccent: langs(hero.titleAccent, d.titleAccent),
    titleAfter: langs(hero.titleAfter, d.titleAfter),
    lead: langs(hero.lead, d.lead),
    primaryButton: { text: langs(hero.primaryButton?.text, d.primaryButton.text), link: hero.primaryButton?.link || DEFAULT_PRIMARY_LINK },
    secondaryVisible: hero.secondaryVisible !== false,
    secondaryButton: { text: langs(hero.secondaryButton?.text, d.secondaryButton.text), link: hero.secondaryButton?.link || DEFAULT_SECONDARY_LINK },
    statsVisible: hero.statsVisible !== false,
    stats: items(hero.stats, d.stats),
    pulseVisible: hero.pulseVisible !== false,
    pulse: items(hero.pulse, d.pulse),
  };
}

// فیلد لینک دکمه: انتخاب سریع از بخش‌های سایت + نوشتن دلخواه (#بخش، /مسیر یا https://…)
function LinkField({ label, value, onChange }) {
  const valid = LINK_RE.test(value || "");
  return (
    <div className="about-field">
      <span>{label}</span>
      <div className="hero-link-row">
        <input type="text" dir="ltr" maxLength={300} value={value} onChange={(e) => onChange(e.target.value)} aria-invalid={!valid} />
        <select
          value=""
          onChange={(e) => e.target.value && onChange(e.target.value)}
          aria-label={tr("انتخاب سریع بخش سایت")}
        >
          <option value="">{tr("انتخاب سریع…")}</option>
          {LINK_PRESETS.map((p) => <option key={p.value} value={p.value}>{p.label} ({p.value})</option>)}
        </select>
      </div>
      {!valid && <small className="hero-link-err">{tr("آدرس نامعتبر است؛ فقط #بخش، /مسیر یا https://… مجاز است.")}</small>}
    </div>
  );
}

// فهرست قابل‌ویرایش (آمارها / کارت ضربان): مقدار + عنوان، افزودن، حذف و جابه‌جایی
function ItemsEditor({ title, hint, items, max, lang, dir, onChange, onAdd, onRemove, onMove, visible, onToggle, addLabel }) {
  return (
    <section className="about-card">
      <div className="about-card-head">
        <h3>{title} ({items.length})</h3>
        <button type="button" className="btn btn-primary btn-sm" onClick={onAdd} disabled={items.length >= max}>
          <Plus size={14} />{" "}{addLabel}
        </button>
      </div>
      <label className="hero-toggle">
        <input type="checkbox" checked={visible} onChange={(e) => onToggle(e.target.checked)} />
        <span>{tr("نمایش این بخش در سایت")}</span>
      </label>
      <p className="about-hint">{hint}</p>
      {items.length === 0 && <p className="about-hint">{tr("هنوز موردی نیست؛ با دکمه‌ی افزودن یک مورد تازه بسازید.")}</p>}
      <ul className="about-points-list">
        {items.map((it, i) => (
          <li key={it.id} className="about-point-card">
            <div className="about-point-top">
              <div className="hero-item-fields">
                <label className="about-field hero-item-value">
                  <span>{tr("مقدار")}</span>
                  <input type="text" dir={dir} maxLength={24} value={it.value[lang]} onChange={(e) => onChange(i, "value", e.target.value)} />
                </label>
                <label className="about-field hero-item-label">
                  <span>{tr("عنوان")}</span>
                  <input type="text" dir={dir} maxLength={60} value={it.label[lang]} onChange={(e) => onChange(i, "label", e.target.value)} />
                </label>
              </div>
              <div className="about-point-tools">
                <button type="button" className="about-tool" onClick={() => onMove(i, -1)} disabled={i === 0} aria-label={tr("بالا بردن")}><ArrowUp size={16} /></button>
                <button type="button" className="about-tool" onClick={() => onMove(i, 1)} disabled={i === items.length - 1} aria-label={tr("پایین بردن")}><ArrowDown size={16} /></button>
                <button type="button" className="about-tool about-tool-danger" onClick={() => onRemove(i)} aria-label={tr("حذف مورد")}><Trash2 size={16} /></button>
              </div>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

export function HeroPanel() {
  const [state, setState] = useState({ loading: true, error: null });
  const [form, setForm] = useState(null);
  const [isCustom, setIsCustom] = useState(false);
  const [lang, setLang] = useState(() => (["fa", "ps", "en"].includes(getCurrentLang()) ? getCurrentLang() : "fa"));
  const [saving, setSaving] = useState(false);
  const [imageBusy, setImageBusy] = useState(false);
  const [confirm, setConfirm] = useState(null); // "reset" | { list: "stats"|"pulse", index }
  const [resetting, setResetting] = useState(false);
  const fileRef = useRef(null);
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  async function load() {
    setState({ loading: true, error: null });
    try {
      const data = await apiRequest("/admin/hero");
      setIsCustom(!!data.hero && !!data.hero.titleBefore);
      setForm(data.hero ? normalize(data.hero) : defaultsFromLocales());
      setState({ loading: false, error: null });
    } catch (err) {
      setState({ loading: false, error: err.message });
    }
  }
  useEffect(() => { load(); }, []);

  const cur = LANGS.find((l) => l.code === lang);
  const setField = (name, value) => setForm((f) => ({ ...f, [name]: { ...f[name], [lang]: value } }));
  const setButton = (name, patch) => setForm((f) => ({ ...f, [name]: { ...f[name], ...patch } }));
  const setButtonText = (name, value) => setForm((f) => ({ ...f, [name]: { ...f[name], text: { ...f[name].text, [lang]: value } } }));
  const setItem = (list) => (i, name, value) => setForm((f) => ({
    ...f, [list]: f[list].map((it, idx) => (idx === i ? { ...it, [name]: { ...it[name], [lang]: value } } : it)),
  }));
  const moveItem = (list) => (i, delta) => setForm((f) => {
    const j = i + delta;
    if (j < 0 || j >= f[list].length) return f;
    const arr = [...f[list]];
    [arr[i], arr[j]] = [arr[j], arr[i]];
    return { ...f, [list]: arr };
  });
  const addItem = (list, max) => () => setForm((f) => (f[list].length >= max ? f : {
    ...f, [list]: [...f[list], { id: newId(), value: emptyLangs(), label: emptyLangs() }],
  }));
  const removeItem = (list, i) => setForm((f) => ({ ...f, [list]: f[list].filter((_, idx) => idx !== i) }));

  async function save() {
    const badLink = [form.primaryButton.link, form.secondaryButton.link].some((l) => !LINK_RE.test(l || ""));
    if (badLink) return showToast(tr("آدرس دکمه‌ها نامعتبر است؛ فقط #بخش، /مسیر یا https://… مجاز است."), "error");
    setSaving(true);
    try {
      const { imageUrl, ...content } = form;
      const data = await apiRequest("/admin/hero", { method: "PUT", body: content });
      setForm(normalize(data.hero));
      setIsCustom(true);
      showToast(tr("تغییرات بخش اصلی ذخیره شد و در سایت نمایش داده می‌شود"), "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setSaving(false);
    }
  }

  async function onPickImage(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) return showToast(tr("فرمت عکس مجاز نیست. فقط JPG، PNG یا WEBP مجاز است."), "error");
    if (file.size > MAX_IMAGE_SIZE) return showToast(tr("حجم عکس نباید بیشتر از ۲ مگابایت باشد."), "error");
    setImageBusy(true);
    try {
      const fd = new FormData();
      fd.append("image", file);
      const data = await apiUpload("/admin/hero/image", fd);
      setForm((f) => ({ ...f, imageUrl: data.imageUrl }));
      showToast(tr("عکس جدید ذخیره شد"), "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setImageBusy(false);
    }
  }

  async function removeImage() {
    setImageBusy(true);
    try {
      await apiRequest("/admin/hero/image", { method: "DELETE" });
      setForm((f) => ({ ...f, imageUrl: "" }));
      showToast(tr("عکس حذف شد؛ عکس پیش‌فرض نمایش داده می‌شود"), "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setImageBusy(false);
    }
  }

  async function doReset() {
    setResetting(true);
    try {
      await apiRequest("/admin/hero", { method: "DELETE" });
      showToast(tr("بخش اصلی به حالت پیش‌فرض برگشت"), "success");
      setConfirm(null);
      await load();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setResetting(false);
    }
  }

  const head = tr("مدیریت بخش اصلی (Hero)");
  if (state.loading) return <div className="about-admin"><PageHead title={head} /><StateBlock kind="loading" title={tr("در حال بارگذاری...")} /></div>;
  if (state.error || !form) return <div className="about-admin"><PageHead title={head} /><StateBlock kind="error" title={tr("خطا در بارگذاری")} message={state.error} onRetry={load} /></div>;

  const imageSrc = form.imageUrl ? resolvePhotoUrl(form.imageUrl) : photos.heroBuilding;
  const removing = typeof confirm === "object" && confirm ? confirm : null;

  return (
    <div className="about-admin hero-admin">
      <PageHead title={head} subtitle={tr("عکس، تیتر، متن، دکمه‌ها و آمارهای بخش بالای صفحه‌ی اصلی سایت")} onRefresh={load}>
        {isCustom && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirm("reset")}>
            <RotateCcw size={14} />{" "}{tr("بازگشت به پیش‌فرض")}
          </button>
        )}
      </PageHead>

      <section className="about-card">
        <h3>{tr("عکس پس‌زمینه")}</h3>
        <div className="about-img-row">
          <img className="about-img-preview" src={imageSrc} alt={tr("پیش‌نمایش عکس بخش اصلی")} />
          <div className="about-img-actions">
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={onPickImage} />
            <button type="button" className="btn btn-primary btn-sm" onClick={() => fileRef.current?.click()} disabled={imageBusy}>
              <ImagePlus size={14} /> {imageBusy ? tr("در حال ارسال...") : tr("انتخاب عکس جدید")}
            </button>
            {form.imageUrl && (
              <button type="button" className="btn btn-ghost btn-sm" onClick={removeImage} disabled={imageBusy}>
                <ImageOff size={14} />{" "}{tr("حذف عکس")}
              </button>
            )}
            <small>{tr("JPG، PNG یا WEBP — حداکثر ۲ مگابایت. عکس به‌محض انتخاب ذخیره می‌شود.")}</small>
          </div>
        </div>
      </section>

      <div className="about-langs" role="tablist" aria-label={tr("زبان محتوا")}>
        {LANGS.map((l) => (
          <button key={l.code} type="button" role="tab" aria-selected={lang === l.code} className={`about-lang${lang === l.code ? " is-active" : ""}`} onClick={() => setLang(l.code)}>
            {l.label}
          </button>
        ))}
      </div>
      <p className="about-hint">{tr("برای نمایش نام شفاخانه در متن، از")}{" "}<code dir="ltr">{"{hospital}"}</code>{" "}{tr("استفاده کنید. اگر برای یک زبان چیزی ننویسید، متن پیش‌فرض همان زبان (یا دری) نمایش داده می‌شود.")}</p>

      <section className="about-card">
        <h3>{tr("تیتر و متن")}</h3>
        <label className="hero-toggle">
          <input type="checkbox" checked={form.eyebrowVisible} onChange={(e) => setForm((f) => ({ ...f, eyebrowVisible: e.target.checked }))} />
          <span>{tr("نمایش برچسب بالای تیتر")}</span>
        </label>
        <label className="about-field">
          <span>{tr("برچسب بالای تیتر")}</span>
          <input type="text" dir={cur.dir} maxLength={120} value={form.eyebrow[lang]} onChange={(e) => setField("eyebrow", e.target.value)} disabled={!form.eyebrowVisible} />
        </label>
        <div className="hero-title-grid">
          <label className="about-field">
            <span>{tr("تیتر — بخش اول")}</span>
            <input type="text" dir={cur.dir} maxLength={80} value={form.titleBefore[lang]} onChange={(e) => setField("titleBefore", e.target.value)} />
          </label>
          <label className="about-field">
            <span>{tr("تیتر — کلمه‌ی رنگی")}</span>
            <input type="text" dir={cur.dir} maxLength={80} value={form.titleAccent[lang]} onChange={(e) => setField("titleAccent", e.target.value)} />
          </label>
          <label className="about-field">
            <span>{tr("تیتر — بخش آخر")}</span>
            <input type="text" dir={cur.dir} maxLength={80} value={form.titleAfter[lang]} onChange={(e) => setField("titleAfter", e.target.value)} />
          </label>
        </div>
        <div className="hero-title-preview" dir={cur.dir} aria-label={tr("پیش‌نمایش تیتر")}>
          {form.titleBefore[lang]} <span>{form.titleAccent[lang]}</span> {form.titleAfter[lang]}
        </div>
        <label className="about-field">
          <span>{tr("متن توضیح زیر تیتر")}</span>
          <textarea dir={cur.dir} rows={4} maxLength={600} value={form.lead[lang]} onChange={(e) => setField("lead", e.target.value)} />
        </label>
      </section>

      <section className="about-card">
        <h3>{tr("دکمه‌ها")}</h3>
        <div className="about-point-card">
          <strong className="hero-sub">{tr("دکمه‌ی اصلی")}</strong>
          <label className="about-field">
            <span>{tr("متن دکمه")}</span>
            <input type="text" dir={cur.dir} maxLength={60} value={form.primaryButton.text[lang]} onChange={(e) => setButtonText("primaryButton", e.target.value)} />
          </label>
          <LinkField label={tr("آدرس دکمه")} value={form.primaryButton.link} onChange={(link) => setButton("primaryButton", { link })} />
          <small className="about-hint">{tr("اگر آدرس #appointment باشد، کاربرِ واردنشده اول به صفحه‌ی ورود هدایت می‌شود.")}</small>
        </div>
        <div className="about-point-card">
          <div className="about-card-head">
            <strong className="hero-sub">{tr("دکمه‌ی دوم")}</strong>
            <label className="hero-toggle">
              <input type="checkbox" checked={form.secondaryVisible} onChange={(e) => setForm((f) => ({ ...f, secondaryVisible: e.target.checked }))} />
              <span>{tr("نمایش در سایت")}</span>
            </label>
          </div>
          <label className="about-field">
            <span>{tr("متن دکمه")}</span>
            <input type="text" dir={cur.dir} maxLength={60} value={form.secondaryButton.text[lang]} onChange={(e) => setButtonText("secondaryButton", e.target.value)} disabled={!form.secondaryVisible} />
          </label>
          <LinkField label={tr("آدرس دکمه")} value={form.secondaryButton.link} onChange={(link) => setButton("secondaryButton", { link })} />
        </div>
      </section>

      <ItemsEditor
        title={tr("آمارهای زیر دکمه‌ها")}
        hint={tr("مثلاً «۱۸+» با عنوان «سال تجربه». حداکثر ۶ مورد.")}
        items={form.stats}
        max={MAX_STATS}
        lang={lang}
        dir={cur.dir}
        visible={form.statsVisible}
        onToggle={(v) => setForm((f) => ({ ...f, statsVisible: v }))}
        onChange={setItem("stats")}
        onAdd={addItem("stats", MAX_STATS)}
        onMove={moveItem("stats")}
        onRemove={(i) => setConfirm({ list: "stats", index: i })}
        addLabel={tr("افزودن آمار")}
      />

      <ItemsEditor
        title={tr("کارت ضربان (کنار تیتر)")}
        hint={tr("مثلاً «۹۸٪» با عنوان «رضایت بیماران». حداکثر ۴ مورد.")}
        items={form.pulse}
        max={MAX_PULSE}
        lang={lang}
        dir={cur.dir}
        visible={form.pulseVisible}
        onToggle={(v) => setForm((f) => ({ ...f, pulseVisible: v }))}
        onChange={setItem("pulse")}
        onAdd={addItem("pulse", MAX_PULSE)}
        onMove={moveItem("pulse")}
        onRemove={(i) => setConfirm({ list: "pulse", index: i })}
        addLabel={tr("افزودن مورد")}
      />

      <div className="about-savebar">
        <button type="button" className="btn btn-primary" onClick={save} disabled={saving}>
          <Save size={16} /> {saving ? tr("در حال ذخیره...") : tr("ذخیره‌ی تغییرات")}
        </button>
      </div>

      <ConfirmDialog
        open={confirm === "reset"}
        title={tr("بازگشت به حالت پیش‌فرض")}
        message={tr("همه‌ی متن‌ها، دکمه‌ها، آمارها و عکس آپلودشده‌ی بخش اصلی پاک می‌شود و سایت دوباره متن و عکس پیش‌فرض را نشان می‌دهد.")}
        confirmLabel={tr("بله، برگردان")}
        busyLabel={tr("در حال انجام...")}
        busy={resetting}
        danger
        onConfirm={doReset}
        onCancel={() => setConfirm(null)}
      />
      <ConfirmDialog
        open={removing !== null}
        title={tr("حذف این مورد")}
        message={tr("این مورد حذف می‌شود (بعد از «ذخیره‌ی تغییرات» در سایت اعمال می‌شود).")}
        confirmLabel={tr("حذف")}
        danger
        onConfirm={() => { removeItem(removing.list, removing.index); setConfirm(null); }}
        onCancel={() => setConfirm(null)}
      />
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

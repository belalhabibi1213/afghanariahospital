import { useEffect, useState } from "react";
import { Receipt, Wallet, CircleDollarSign, Hourglass, Search, X, Eye, Trash2, Plus } from "lucide-react";
import GlobalModal from "../../../components/GlobalModal.jsx";
import InvoiceDetail, { INVOICE_STATUS_LABEL, getApprovalStatusKey } from "../../../components/dashboard/InvoiceDetail.jsx";
import { PageHead, StatCards, StateBlock, SkeletonRows, ConfirmDialog, Badge, fa as faNum, fmtMoney } from "../../../components/admin/AdminPro.jsx";
import { apiRequest } from "../../../utils/api.js";
import useHighlightParam from "../../../hooks/useHighlightParam.js";
import { useDebouncedValue, useLoadable, useSearchable } from "./adminShared.jsx";
import { PatientPager } from "./AdminPatientsPanel.jsx";

import { JalaliDateInput } from "../../../components/JalaliDateInput.jsx";
import { todayISO } from "../../../utils/jalali.js";
import { tr, jdate } from "../../../i18n/tr.js";
// ---------- گزارش‌ها و آمار (داشبورد آنالیتیکس) ----------
// ---------- صورت‌حساب و فاکتورها ----------
export const EMPTY_ITEM = { description: "", quantity: 1, unitPrice: "" };
export const EMPTY_INVOICE_FORM = {
  patientId: "", doctorId: "", issueDate: todayISO(), dueDate: "",
  discount: "", tax: "", notes: "", items: [{ ...EMPTY_ITEM }],
};

export function BillingPanel() {
  const [view, setView] = useState("list"); // list | create | detail
  const [statusFilter, setStatusFilter] = useState("");
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebouncedValue(search);
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [page, setPage] = useState(1);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [approveTarget, setApproveTarget] = useState(null); // فاکتوری که در انتظار تایید نهایی کاربر است
  const [approving, setApproving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null); // فاکتوری که در انتظار تایید نهایی حذف است
  const [deleting, setDeleting] = useState(false);
  const { highlightRowProps } = useHighlightParam();
  // فهرست داکتران برای فیلتر «داکتر» فاکتورها — همان الگوی doctorOptions در پنل‌های دیگر
  const { items: doctorOptions } = useLoadable("/admin/doctors", "doctors");

  useEffect(() => setPage(1), [statusFilter, dateFrom, dateTo, doctorFilter, debouncedSearch]);

  const { items, pagination, loading, error, reload, setError } = useSearchable(
    "/billing/invoices", "invoices", { status: statusFilter, from: dateFrom, to: dateTo, doctorId: doctorFilter, q: debouncedSearch }, page
  );

  async function openDetail(id) {
    setError("");
    try {
      const data = await apiRequest(`/billing/invoices/${id}`);
      setSelectedInvoice(data.invoice);
      setView("detail");
    } catch (err) {
      setError(err.message);
    }
  }

  async function refreshDetail() {
    if (!selectedInvoice) return;
    const data = await apiRequest(`/billing/invoices/${selectedInvoice.id}`);
    setSelectedInvoice(data.invoice);
    reload();
  }

  const [cancelTarget, setCancelTarget] = useState(null);
  const [cancelling, setCancelling] = useState(false);
  async function confirmCancel() {
    if (!cancelTarget) return;
    setCancelling(true);
    try {
      await apiRequest(`/billing/invoices/${cancelTarget.id}/cancel`, { method: "PUT" });
      setCancelTarget(null);
      reload();
    } catch (err) {
      setError(err.message);
      setCancelTarget(null);
    } finally {
      setCancelling(false);
    }
  }

  // تایید فاکتور (Invoice Approval Workflow) — پس از تایید کاربر در مودال، درخواست به سرور
  // ارسال می‌شود، فهرست بدون رفرش صفحه به‌روزرسانی می‌شود، و در صورت باز بودن نمای جزئیات
  // همان فاکتور، آن هم به‌روز می‌شود تا نشان وضعیت جدید فوراً دیده شود.
  async function confirmApprove() {
    if (!approveTarget) return;
    setApproving(true);
    setError("");
    try {
      const data = await apiRequest(`/billing/invoices/${approveTarget.id}/approve`, { method: "PUT" });
      if (view === "detail" && selectedInvoice && selectedInvoice.id === approveTarget.id) {
        setSelectedInvoice(data.invoice);
      }
      setApproveTarget(null);
      reload();
    } catch (err) {
      setError(err.message);
    } finally {
      setApproving(false);
    }
  }

  // حذف فاکتور (الزام «Add Delete Button» + «Delete Synchronization») — پس از تایید
  // کاربر در مودال، فاکتور از فهرست ادمین بدون رفرش صفحه حذف می‌شود (reload()) و
  // چون همان رکورد از دیتابیس حذف شده، در پنل داکتر/بیمار هم دیگر نمایش داده نمی‌شود.
  async function confirmDelete() {
    if (!deleteTarget) return;
    setDeleting(true);
    setError("");
    try {
      await apiRequest(`/billing/invoices/${deleteTarget.id}`, { method: "DELETE" });
      setDeleteTarget(null);
      if (view === "detail" && selectedInvoice && selectedInvoice.id === deleteTarget.id) {
        setView("list");
        setSelectedInvoice(null);
      }
      reload();
    } catch (err) {
      setError(err.message);
    } finally {
      setDeleting(false);
    }
  }

  if (view === "create") {
    return (
      <div className="dash-card glass">
        <CreateInvoiceForm
          onDone={() => { setView("list"); reload(); }}
          onCancel={() => setView("list")}
        />
      </div>
    );
  }

  const hasFilters = !!(statusFilter || dateFrom || dateTo || doctorFilter || debouncedSearch);
  function clearFilters() { setStatusFilter(""); setDateFrom(""); setDateTo(""); setDoctorFilter(""); setSearch(""); }
  // KPIها فقط از داده‌ی واقعی API فعلی: تعداد کل (با همان فیلترها) از pagination.total؛ مبالغ فقط
  // مجموع ردیف‌های همین صفحه‌ی بارگذاری‌شده‌اند (API مجموع کل مالی برنمی‌گرداند) و برچسب آن گفته شده است.
  const pageTotal = items.reduce((sum, i) => sum + Number(i.totalAmount || 0), 0);
  const pagePaid = items.reduce((sum, i) => sum + Number(i.paidAmount || 0), 0);
  const loaded = !loading || items.length > 0;
  const kpis = [
    { key: "count", tone: "total", label: hasFilters ? tr("فاکتورهای مطابق فیلتر") : tr("مجموع فاکتورها"), value: pagination ? pagination.total : (loaded ? items.length : undefined), Icon: Receipt },
    { key: "amount", tone: "guest", label: tr("مبلغ کل (این صفحه)"), value: loaded ? fmtMoney(pageTotal) : undefined, Icon: CircleDollarSign },
    { key: "paid", tone: "active", label: tr("پرداخت‌شده (این صفحه)"), value: loaded ? fmtMoney(pagePaid) : undefined, Icon: Wallet },
    { key: "rest", tone: "inactive", label: tr("باقی‌مانده (این صفحه)"), value: loaded ? fmtMoney(pageTotal - pagePaid) : undefined, Icon: Hourglass },
  ];

  return (
    <div className="pm-page">
      <PageHead title={tr("صورت‌حساب و فاکتورها")} subtitle={tr("صدور، پیگیری پرداخت، تایید و چاپ فاکتورهای بیماران")} onRefresh={reload} refreshing={loading}>
        <button className="btn btn-primary btn-sm" type="button" onClick={() => setView("create")}><Plus size={14} />{" "}{tr("صدور فاکتور جدید")}</button>
      </PageHead>

      <StatCards items={kpis} />

      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="pm-search">
            <Search size={16} />
            <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder={tr("جستجوی شماره فاکتور، نام بیمار یا تاریخ صدور...")} aria-label={tr("جستجوی فاکتورها")} />
          </div>
          <select className="pm-select dash-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={tr("وضعیت فاکتور")}>
            <option value="">{tr("وضعیت: همه")}</option>
            {Object.entries(INVOICE_STATUS_LABEL).map(([k, label]) => <option key={k} value={k}>{label}</option>)}
          </select>
          <select className="pm-select dash-select" value={doctorFilter} onChange={(e) => setDoctorFilter(e.target.value)} aria-label={tr("فیلتر داکتر")}>
            <option value="">{tr("داکتر: همه")}</option>
            {doctorOptions.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
          </select>
          <label className="ap-datefield ap-datefield--lg"><span>{tr("از")}</span><JalaliDateInput value={dateFrom} max={dateTo || undefined} onChange={(e) => setDateFrom(e.target.value)} aria-label={tr("از تاریخ")} /></label>
          <label className="ap-datefield ap-datefield--lg"><span>{tr("تا")}</span><JalaliDateInput value={dateTo} min={dateFrom || undefined} onChange={(e) => setDateTo(e.target.value)} aria-label={tr("تا تاریخ")} /></label>
          {hasFilters && <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={clearFilters}><X size={14} />{" "}{tr("پاک کردن فیلترها")}</button>}
        </div>
      </div>

      <div className="pm-tablewrap">
        {error && items.length === 0 && <StateBlock kind="error" title={tr("بارگذاری فاکتورها انجام نشد")} message={error} onRetry={() => { setError(""); reload(); }} />}
        {error && items.length > 0 && <div className="form-message error" role="alert">{error}</div>}
        {loading && items.length === 0 && !error && <SkeletonRows rows={5} />}
        {!loading && !error && items.length === 0 && (
          hasFilters
            ? <StateBlock title={tr("برای این فیلتر فاکتوری پیدا نشد.")} message={tr("فیلترها را تغییر دهید.")} action={<button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button>} />
            : <StateBlock title={tr("هنوز فاکتوری ثبت نشده است.")} message={tr("با «صدور فاکتور جدید» اولین فاکتور را بسازید.")} />
        )}
        {items.length > 0 && (
          <div className={`ap-tablescroll ${loading ? "is-busy" : ""}`}>
            <table className="pm-table">
              <thead><tr><th>{tr("شماره فاکتور")}</th><th>{tr("بیمار")}</th><th>{tr("تاریخ صدور")}</th><th>{tr("مبلغ کل")}</th><th>{tr("پرداخت‌شده")}</th><th>{tr("باقی‌مانده")}</th><th>{tr("وضعیت")}</th><th>{tr("عملیات")}</th></tr></thead>
              <tbody>
                {items.map((inv) => {
                  const key = getApprovalStatusKey(inv);
                  const rest = Math.max(0, Number(inv.totalAmount || 0) - Number(inv.paidAmount || 0));
                  return (
                    <tr key={inv.id} {...highlightRowProps(inv.id)}>
                      <td data-label={tr("شماره فاکتور")} dir="ltr" className="ap-num-cell"><strong>{inv.invoiceNumber}</strong></td>
                      <td data-label={tr("بیمار")}>{inv.patientName}</td>
                      <td data-label={tr("تاریخ صدور")}>{jdate(inv.issueDate)}</td>
                      <td data-label={tr("مبلغ کل")} className="ap-num-cell">{fmtMoney(inv.totalAmount)}</td>
                      <td data-label={tr("پرداخت‌شده")} className="ap-num-cell">{fmtMoney(inv.paidAmount)}</td>
                      <td data-label={tr("باقی‌مانده")} className="ap-num-cell">{fmtMoney(rest)}</td>
                      <td data-label={tr("وضعیت")}><Badge tone={key === "approved" ? "success" : key === "cancelled" ? "danger" : "warn"}>{INVOICE_STATUS_LABEL[key]}</Badge></td>
                      <td className="pm-cell-actions">
                        <div className="pm-actions">
                          <button className="btn btn-ghost btn-sm" type="button" onClick={() => openDetail(inv.id)}><Eye size={14} />{" "}{tr("مشاهده / چاپ")}</button>
                          {inv.status !== "cancelled" && inv.approvalStatus !== "approved" && (
                            <button className="btn btn-ghost btn-sm" type="button" onClick={() => setApproveTarget(inv)}>{tr("تایید")}</button>
                          )}
                          {inv.status === "unpaid" && Number(inv.paidAmount) === 0 && (
                            <button className="btn btn-ghost btn-sm danger" type="button" onClick={() => setCancelTarget(inv)}>{tr("لغو")}</button>
                          )}
                          <button className="pm-iconbtn dm-iconbtn-danger" type="button" onClick={() => setDeleteTarget(inv)} aria-label={tr("حذف فاکتور {0}", [inv.invoiceNumber])} title={tr("حذف")}><Trash2 size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {pagination && pagination.total > 0 && <PatientPager pagination={pagination} page={page} onPageChange={setPage} fa={faNum} noun={tr("فاکتور")} />}
      </div>

      <GlobalModal
        isOpen={view === "detail" && !!selectedInvoice}
        onClose={() => { setView("list"); setSelectedInvoice(null); }}
        size="lg"
        title={tr("جزئیات فاکتور")}
        labelledBy="invoice-detail-title"
        footer={selectedInvoice && (
          <div className="no-print" style={{ display: "flex", gap: 8 }}>
            {selectedInvoice.status !== "cancelled" && selectedInvoice.approvalStatus !== "approved" && (
              <button className="btn btn-primary btn-sm" type="button" onClick={() => setApproveTarget(selectedInvoice)}>{tr("✅ تایید فاکتور")}</button>
            )}
            <button className="btn btn-ghost btn-sm danger" type="button" onClick={() => setDeleteTarget(selectedInvoice)}>{tr("🗑️ حذف فاکتور")}</button>
          </div>
        )}
      >
        {selectedInvoice && (
          <InvoiceDetail
            invoice={selectedInvoice}
            onClose={() => { setView("list"); setSelectedInvoice(null); }}
            onChanged={refreshDetail}
            canRecordPayment
            recordPaymentPath={`/billing/invoices/${selectedInvoice.id}/payments`}
          />
        )}
      </GlobalModal>

      <ConfirmDialog open={!!cancelTarget} danger title={tr("لغو فاکتور")} message={cancelTarget ? tr("آیا از لغو فاکتور {0} مطمئن هستید؟", [cancelTarget.invoiceNumber]) : ""} confirmLabel={tr("بله، لغو کن")} busyLabel={tr("در حال لغو...")} busy={cancelling} onConfirm={confirmCancel} onCancel={() => setCancelTarget(null)} />
      {approveTarget && <ApproveInvoiceConfirm invoice={approveTarget} approving={approving} onConfirm={confirmApprove} onCancel={() => setApproveTarget(null)} />}
      {deleteTarget && <DeleteInvoiceConfirm invoice={deleteTarget} deleting={deleting} onConfirm={confirmDelete} onCancel={() => setDeleteTarget(null)} />}
    </div>

  );
}

// مودال تایید نهایی پیش از تایید فاکتور (Invoice Approval Workflow) — همان الگوی CSS
// مودال «تایید خروج» (modal-overlay / logout-confirm-modal) دوباره استفاده می‌شود
// تا CSS تکراری اضافه نشود.
export function ApproveInvoiceConfirm({ invoice, approving, onConfirm, onCancel }) {
  return (
    <GlobalModal
      isOpen={!!invoice}
      onClose={onCancel}
      size="sm"
      className="logout-confirm-modal"
      overlayClassName="logout-confirm-overlay"
      labelledBy="approve-invoice-title"
      closeOnOverlayClick={!approving}
      closeOnEsc={!approving}
      bare
    >
      {invoice && (
        <>
          <h3 id="approve-invoice-title">{tr("تایید فاکتور")}</h3>
          <p>{tr("آیا از تایید فاکتور {0} مطمئن هستید؟", [invoice.invoiceNumber])}</p>
          <div className="modal-actions">
            <button type="button" className="btn btn-primary" onClick={onConfirm} disabled={approving}>
              {approving ? tr("در حال تایید...") : tr("بله، تایید کن")}
            </button>
            <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={approving}>{tr("انصراف")}</button>
          </div>
        </>
      )}
    </GlobalModal>
  );
}

// مودال تایید نهایی پیش از حذف کامل فاکتور (الزام «Add Delete Button») — همان الگوی
// CSS مودال تایید فاکتور/خروج دوباره استفاده می‌شود تا CSS تکراری اضافه نشود.
export function DeleteInvoiceConfirm({ invoice, deleting, onConfirm, onCancel }) {
  return (
    <GlobalModal
      isOpen={!!invoice}
      onClose={onCancel}
      size="sm"
      className="logout-confirm-modal"
      overlayClassName="logout-confirm-overlay"
      labelledBy="delete-invoice-title"
      closeOnOverlayClick={!deleting}
      closeOnEsc={!deleting}
      bare
    >
      {invoice && (
        <>
          <h3 id="delete-invoice-title">{tr("حذف فاکتور")}</h3>
          <p>{tr("آیا از حذف دائمی فاکتور {0} مطمئن هستید؟", [invoice.invoiceNumber])}</p>
          <p style={{ color: "var(--warm, #ff8a7a)", fontSize: 13 }}>{tr("این عملیات غیرقابل بازگشت است و تمام ردیف‌ها، پرداخت‌ها و اعلان‌های مرتبط با این فاکتور نیز حذف خواهند شد.")}</p>
          <div className="modal-actions">
            <button type="button" className="btn btn-danger" onClick={onConfirm} disabled={deleting}>
              {deleting ? tr("در حال حذف...") : tr("بله، حذف کن")}
            </button>
            <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={deleting}>{tr("انصراف")}</button>
          </div>
        </>
      )}
    </GlobalModal>
  );
}

// جستجوی بیمار هنگام صدور فاکتور جدید (بازاستفاده از /admin/patients که قبلاً برای پنل بیماران هم استفاده می‌شود)
export function PatientPicker({ value, onChange }) {
  const [search, setSearch] = useState("");
  const debounced = useDebouncedValue(search);
  const [results, setResults] = useState([]);

  useEffect(() => {
    if (!debounced.trim()) { setResults([]); return; }
    apiRequest(`/admin/patients?q=${encodeURIComponent(debounced)}&limit=8`)
      .then((data) => setResults(data.patients || []))
      .catch(() => setResults([]));
  }, [debounced]);

  if (value) {
    return (
      <div className="field">
        <label>{tr("بیمار")}</label>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span>{value.fullName} ({value.phone})</span>
          <button className="btn btn-ghost btn-sm" type="button" onClick={() => onChange(null)}>{tr("تغییر")}</button>
        </div>
      </div>
    );
  }

  return (
    <div className="field">
      <label>{tr("جستجوی بیمار (نام یا شماره تماس) *")}</label>
      <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={tr("مثلاً: احمدی")} />
      {results.length > 0 && (
        <div className="dash-card glass" style={{ marginTop: 8, padding: 8 }}>
          {results.map((p) => (
            <div key={p.id} style={{ padding: "6px 4px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span>{p.fullName} — {p.phone}</span>
              <button className="btn btn-ghost btn-sm" type="button" onClick={() => { onChange(p); setSearch(""); setResults([]); }}>{tr("انتخاب")}</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function CreateInvoiceForm({ onDone, onCancel }) {
  const [patient, setPatient] = useState(null);
  const [form, setForm] = useState(EMPTY_INVOICE_FORM);
  const { items: doctors } = useLoadable("/admin/doctors", "doctors");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  function updateItem(index, field, val) {
    setForm((f) => {
      const items = [...f.items];
      items[index] = { ...items[index], [field]: val };
      return { ...f, items };
    });
  }
  function addItemRow() {
    setForm((f) => ({ ...f, items: [...f.items, { ...EMPTY_ITEM }] }));
  }
  function removeItemRow(index) {
    setForm((f) => ({ ...f, items: f.items.filter((_, i) => i !== index) }));
  }

  const subtotal = form.items.reduce((sum, it) => sum + (Number(it.quantity) || 0) * (Number(it.unitPrice) || 0), 0);
  const total = Math.max(0, subtotal - (Number(form.discount) || 0) + (Number(form.tax) || 0));

  async function submit(e) {
    e.preventDefault();
    setError("");
    if (!patient) { setError(tr("لطفاً یک بیمار انتخاب کنید")); return; }
    if (form.items.some((it) => !it.description.trim() || !it.quantity || it.unitPrice === "")) {
      setError(tr("همه‌ی ردیف‌های فاکتور باید شرح، تعداد و قیمت واحد داشته باشند"));
      return;
    }
    setSaving(true);
    try {
      await apiRequest("/billing/invoices", {
        method: "POST",
        body: {
          patientId: patient.id,
          doctorId: form.doctorId || undefined,
          issueDate: form.issueDate,
          dueDate: form.dueDate || undefined,
          discount: form.discount ? Number(form.discount) : undefined,
          tax: form.tax ? Number(form.tax) : undefined,
          notes: form.notes || undefined,
          items: form.items.map((it) => ({ description: it.description, quantity: Number(it.quantity), unitPrice: Number(it.unitPrice) })),
        },
      });
      onDone();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <form className="login-form inline-edit-form" onSubmit={submit}>
      <h2 style={{ marginTop: 0 }}>{tr("صدور فاکتور جدید")}</h2>
      {error && <div className="form-message error">{error}</div>}

      <PatientPicker value={patient} onChange={setPatient} />

      <div className="field-row">
        <div className="field"><label>{tr("داکتر معالج (اختیاری)")}</label>
          <select value={form.doctorId} onChange={(e) => setForm((f) => ({ ...f, doctorId: e.target.value }))}>
            <option value="">{tr("بدون داکتر")}</option>
            {doctors.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
          </select>
        </div>
        <div className="field"><label>{tr("تاریخ صدور")}</label>
          <JalaliDateInput value={form.issueDate} onChange={(e) => setForm((f) => ({ ...f, issueDate: e.target.value }))} />
        </div>
        <div className="field"><label>{tr("سررسید (اختیاری)")}</label>
          <JalaliDateInput value={form.dueDate} onChange={(e) => setForm((f) => ({ ...f, dueDate: e.target.value }))} />
        </div>
      </div>

      <h3>{tr("ردیف‌های فاکتور")}</h3>
      {form.items.map((it, idx) => (
        <div className="field-row" key={idx} style={{ alignItems: "flex-end" }}>
          <div className="field" style={{ flex: 2 }}><label>{tr("شرح خدمت/کالا")}</label>
            <input value={it.description} onChange={(e) => updateItem(idx, "description", e.target.value)} placeholder={tr("مثلاً: ویزیت تخصصی")} />
          </div>
          <div className="field"><label>{tr("تعداد")}</label>
            <input type="number" min="0.01" step="0.01" value={it.quantity} onChange={(e) => updateItem(idx, "quantity", e.target.value)} />
          </div>
          <div className="field"><label>{tr("قیمت واحد")}</label>
            <input type="number" min="0" step="0.01" value={it.unitPrice} onChange={(e) => updateItem(idx, "unitPrice", e.target.value)} />
          </div>
          {form.items.length > 1 && (
            <button className="btn btn-ghost btn-sm danger" type="button" onClick={() => removeItemRow(idx)}>{tr("حذف ردیف")}</button>
          )}
        </div>
      ))}
      <button className="btn btn-ghost btn-sm" type="button" onClick={addItemRow}>{tr("+ افزودن ردیف")}</button>

      <div className="field-row" style={{ marginTop: 14 }}>
        <div className="field"><label>{tr("تخفیف (اختیاری)")}</label>
          <input type="number" min="0" step="0.01" value={form.discount} onChange={(e) => setForm((f) => ({ ...f, discount: e.target.value }))} />
        </div>
        <div className="field"><label>{tr("مالیات (اختیاری)")}</label>
          <input type="number" min="0" step="0.01" value={form.tax} onChange={(e) => setForm((f) => ({ ...f, tax: e.target.value }))} />
        </div>
      </div>
      <div className="field"><label>{tr("یادداشت (اختیاری)")}</label>
        <textarea value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} rows={2} />
      </div>

      <p><strong>{tr("جمع جزء: {0}", [subtotal.toFixed(2)])}</strong> — <strong>{tr("مبلغ کل قابل پرداخت: {0}", [total.toFixed(2)])}</strong></p>

      <div style={{ display: "flex", gap: 10 }}>
        <button className="btn btn-primary" type="submit" disabled={saving}>{saving ? tr("در حال صدور...") : tr("صدور فاکتور")}</button>
        <button className="btn btn-ghost" type="button" onClick={onCancel}>{tr("انصراف")}</button>
      </div>
    </form>
  );
}

import { STATUS_LABEL } from "../../adminShared.jsx";
import { fmtDate } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientAppointmentsSection({ appointments = [] }) {
  if (appointments.length === 0) return <p>{tr("هیچ نوبتی برای این بیمار ثبت نشده است.")}</p>;
  return (
    <table className="dash-table">
      <thead><tr><th>{tr("تاریخ")}</th><th>{tr("ساعت")}</th><th>{tr("بخش")}</th><th>{tr("داکتر")}</th><th>{tr("وضعیت")}</th><th>{tr("یادداشت")}</th></tr></thead>
      <tbody>
        {appointments.map((a) => (
          <tr key={a.id}>
            <td>{fmtDate(a.appointmentDate)}</td>
            <td>{a.appointmentTime}</td>
            <td>{a.department}</td>
            <td>{a.doctorName || "—"}</td>
            <td><span className={`status-badge status-${a.status}`}>{STATUS_LABEL[a.status] || a.status}</span></td>
            <td>{a.notes || "—"}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

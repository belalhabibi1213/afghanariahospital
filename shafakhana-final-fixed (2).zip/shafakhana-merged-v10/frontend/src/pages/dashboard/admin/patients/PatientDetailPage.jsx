import { DepartmentToastContainer, useDepartmentToasts } from "../../../../components/dashboard/DepartmentToast.jsx";
import GlobalModal from "../../../../components/GlobalModal.jsx";
import InvoiceDetail from "../../../../components/dashboard/InvoiceDetail.jsx";
import PrescriptionDetail from "../../../../components/dashboard/PrescriptionDetail.jsx";
import { STATUS_LABEL } from "../adminShared.jsx";
import { apiDownload, apiRequest } from "../../../../utils/api.js";
import { money } from "../AdminReportingPanel.jsx";
import { useEffect, useMemo, useState } from "react";
import { PATIENT_SECTIONS } from "./patientUtils.js";
import { PatientAllergiesSection } from "./sections/PatientAllergiesSection.jsx";
import { PatientAppointmentsSection } from "./sections/PatientAppointmentsSection.jsx";
import { PatientBillingSection } from "./sections/PatientBillingSection.jsx";
import { PatientContactSection } from "./sections/PatientContactSection.jsx";
import { PatientDiseasesSection } from "./sections/PatientDiseasesSection.jsx";
import { PatientFilesSection } from "./sections/PatientFilesSection.jsx";
import { PatientMedicalSection } from "./sections/PatientMedicalSection.jsx";
import { PatientPersonalSection } from "./sections/PatientPersonalSection.jsx";
import { PatientPrescriptionsSection } from "./sections/PatientPrescriptionsSection.jsx";
import { PatientProfileHeader } from "./sections/PatientProfileHeader.jsx";
import { PatientTimelineSection } from "./sections/PatientTimelineSection.jsx";

import { tr } from "../../../../i18n/tr.js";
export function PatientDetailPage({ patientId, onBack, initialSection = "personal" }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [section, setSection] = useState(initialSection);
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [invoiceLoading, setInvoiceLoading] = useState(false);
  const [selectedPrescription, setSelectedPrescription] = useState(null);
  const [busyAction, setBusyAction] = useState(null);
  const { showToast, toasts, dismissToast } = useDepartmentToasts();

  function reload() {
    setLoading(true);
    setError("");
    apiRequest(`/admin/patients/${patientId}/full-profile`)
      .then((res) => setData(res))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, [patientId]);

  async function openInvoice(id) {
    setInvoiceLoading(true);
    try {
      const res = await apiRequest(`/billing/invoices/${id}`);
      setSelectedInvoice(res.invoice);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setInvoiceLoading(false);
    }
  }

  async function refreshInvoiceDetail() {
    if (!selectedInvoice) return;
    const res = await apiRequest(`/billing/invoices/${selectedInvoice.id}`);
    setSelectedInvoice(res.invoice);
    reload();
  }

  async function downloadLabReport(labResultId) {
    setBusyAction(`lab-${labResultId}`);
    try {
      await apiDownload(`/medical-records/lab-results/${labResultId}/report`, `lab-report-${labResultId}`, { openInNewTab: true });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyAction(null);
    }
  }

  async function downloadFileTransfer(id, originalName) {
    setBusyAction(`file-${id}`);
    try {
      await apiDownload(`/admin/file-transfers/${id}/download`, originalName || `file-${id}`, { openInNewTab: true });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyAction(null);
    }
  }

  // «جدول زمانی» — ترکیب همه‌ی رویدادهای بیمار (ویزیت، نسخه، نوبت، فاکتور، فایل دریافتی)
  // بر اساس تاریخ، بدون نیاز به درخواست جداگانه از سرور (از همان داده‌های بارگذاری‌شده استفاده می‌شود)
  const timelineEvents = useMemo(() => {
    if (!data) return [];
    const events = [];
    (data.encounters || []).forEach((e) =>
      events.push({ date: e.visitDate || e.createdAt, type: "encounter", icon: "📋", label: tr("ویزیت"), detail: e.diagnosis || e.symptoms || tr("بدون تشخیص ثبت‌شده"), doctorName: e.doctorName }));
    (data.prescriptions || []).forEach((p) =>
      events.push({ date: p.createdAt, type: "prescription", icon: "💊", label: tr("نسخه"), detail: p.medicationName, doctorName: p.doctorName }));
    (data.appointments || []).forEach((a) =>
      events.push({ date: `${a.appointmentDate}T${a.appointmentTime || "00:00"}`, type: "appointment", icon: "📅", label: tr("نوبت"), detail: `${a.department} — ${STATUS_LABEL[a.status] || a.status}`, doctorName: a.doctorName }));
    (data.invoices || []).forEach((i) =>
      events.push({ date: i.createdAt || i.issueDate, type: "invoice", icon: "🧾", label: tr("فاکتور"), detail: tr("{0} — {1} افغانی", [i.invoiceNumber, money(i.totalAmount)]), doctorName: null }));
    (data.fileTransfers || []).forEach((f) =>
      events.push({ date: f.createdAt, type: "file", icon: "📎", label: tr("فایل دریافتی"), detail: f.originalName, doctorName: f.doctorName }));
    (data.diagnoses || []).forEach((d) =>
      events.push({ date: d.createdAt, type: "diagnosis", icon: "🩺", label: tr("تشخیص"), detail: d.title, doctorName: d.doctorName }));
    (data.labResults || []).forEach((l) =>
      events.push({ date: l.createdAt, type: "lab", icon: "🧪", label: tr("آزمایش"), detail: l.testName, doctorName: l.doctorName }));
    return events
      .filter((ev) => ev.date)
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [data]);

  return (
    <div className="dash-card glass">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10, marginBottom: 14 }}>
        <button className="btn btn-ghost btn-sm" type="button" onClick={onBack}>{tr("← بازگشت به فهرست بیماران")}</button>
      </div>

      {loading && <p>{tr("در حال بارگذاری پرونده‌ی بیمار...")}</p>}
      {error && <div className="form-message error">{error}</div>}

      {!loading && data && (
        <>
          <PatientProfileHeader patient={data.patient} />

          <div className="patient-section-tabs" style={{ display: "flex", flexWrap: "wrap", gap: 8, margin: "18px 0" }}>
            {PATIENT_SECTIONS.map((s) => (
              <button
                key={s.key}
                type="button"
                className={`btn ${section === s.key ? "btn-primary" : "btn-ghost"} btn-sm`}
                onClick={() => setSection(s.key)}
              >
                <span style={{ marginInlineEnd: 4 }}>{s.icon}</span>{s.label}
              </button>
            ))}
          </div>

          {section === "personal" && <PatientPersonalSection patient={data.patient} />}
          {section === "contact" && <PatientContactSection patient={data.patient} />}
          {section === "medical" && <PatientMedicalSection data={data} onDownloadLab={downloadLabReport} busyAction={busyAction} />}
          {section === "prescriptions" && (
            <PatientPrescriptionsSection prescriptions={data.prescriptions} onView={setSelectedPrescription} />
          )}
          {section === "appointments" && <PatientAppointmentsSection appointments={data.appointments} />}
          {section === "files" && (
            <PatientFilesSection fileTransfers={data.fileTransfers} onDownload={downloadFileTransfer} busyAction={busyAction} />
          )}
          {section === "timeline" && <PatientTimelineSection events={timelineEvents} />}
          {section === "billing" && (
            <PatientBillingSection invoices={data.invoices} onView={openInvoice} loading={invoiceLoading} />
          )}
          {section === "allergies" && <PatientAllergiesSection allergies={data.allergies} patient={data.patient} />}
          {section === "diseases" && <PatientDiseasesSection diagnoses={data.diagnoses} patient={data.patient} />}
        </>
      )}

      <GlobalModal
        isOpen={!!selectedInvoice}
        onClose={() => setSelectedInvoice(null)}
        size="lg"
        title={tr("جزئیات فاکتور")}
        labelledBy="patient-invoice-detail-title"
      >
        {selectedInvoice && (
          <InvoiceDetail
            invoice={selectedInvoice}
            onClose={() => setSelectedInvoice(null)}
            onChanged={refreshInvoiceDetail}
            canRecordPayment
            recordPaymentPath={`/billing/invoices/${selectedInvoice.id}/payments`}
          />
        )}
      </GlobalModal>

      <GlobalModal
        isOpen={!!selectedPrescription}
        onClose={() => setSelectedPrescription(null)}
        size="lg"
        title={tr("جزئیات نسخه")}
        labelledBy="patient-prescription-detail-title"
      >
        {selectedPrescription && data && (
          <PrescriptionDetail
            prescription={selectedPrescription}
            patientName={data.patient.fullName}
            patientPhone={data.patient.phone}
            pdfPath={`/medical-records/prescriptions/${selectedPrescription.id}/pdf`}
            onClose={() => setSelectedPrescription(null)}
          />
        )}
      </GlobalModal>
    </div>
  );
}


import { trc, numLocale } from "../../../../i18n/tr.js";

// سن از تاریخ تولد (فقط اگر ثبت شده باشد؛ وگرنه null و «—» نمایش داده می‌شود)
export function patientAge(dob) {
  if (!dob) return null;
  const d = new Date(dob);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  const m = now.getMonth() - d.getMonth();
  if (m < 0 || (m === 0 && now.getDate() < d.getDate())) age -= 1;
  return age >= 0 && age < 130 ? age : null;
}

export function fmtDate(v) {
  return v ? new Date(v).toLocaleDateString(numLocale()) : "—";
}

export function fmtDateTime(v) {
  return v ? new Date(v).toLocaleString(numLocale()) : "—";
}

export const GENDER_LABEL = trc({ male: "مرد", female: "زن" });

export const SEVERITY_LABEL = trc({ mild: "خفیف", moderate: "متوسط", severe: "شدید" });

export const SEVERITY_STATUS_CLASS = { mild: "status-active", moderate: "status-pending", severe: "status-cancelled" };

export const DIAGNOSIS_STATUS_LABEL = trc({ active: "در حال جریان", resolved: "بهبودیافته" });

export const DIAGNOSIS_STATUS_CLASS = { active: "status-scheduled", resolved: "status-active" };

export const LAB_STATUS_LABEL = trc({ pending: "در انتظار نتیجه", completed: "تکمیل‌شده" });

// ---------- صفحه‌ی اختصاصی جزئیات بیمار ----------
// بخش‌های این صفحه: اطلاعات شخصی، اطلاعات تماس، سوابق طبی، نسخه‌ها، نوبت‌ها،
// فایل‌های صحی دریافتی، جدول زمانی، صورت‌حساب و فاکتورها، حساسیت‌ها، بیماری‌های قبلی
export const PATIENT_SECTIONS = trc([
  { key: "personal", label: "اطلاعات شخصی", icon: "🪪" },
  { key: "contact", label: "اطلاعات تماس", icon: "📞" },
  { key: "medical", label: "سوابق طبی", icon: "📋" },
  { key: "prescriptions", label: "نسخه‌ها", icon: "💊" },
  { key: "appointments", label: "نوبت‌ها", icon: "📅" },
  { key: "files", label: "فایل‌های دریافتی", icon: "📎" },
  { key: "timeline", label: "جدول زمانی", icon: "🕒" },
  { key: "billing", label: "صورت‌حساب و فاکتورها", icon: "🧾" },
  { key: "allergies", label: "حساسیت‌ها", icon: "⚠️" },
  { key: "diseases", label: "بیماری‌های قبلی", icon: "🩺" },
]);

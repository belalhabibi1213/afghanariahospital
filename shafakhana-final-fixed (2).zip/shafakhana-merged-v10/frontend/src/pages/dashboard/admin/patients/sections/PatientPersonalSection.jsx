import { GENDER_LABEL, fmtDate } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientPersonalSection({ patient }) {
  return (
    <div className="info-grid">
      <div><span>{tr("شناسه بیمار")}</span>#{patient.id}</div>
      <div><span>{tr("نام کامل")}</span>{patient.fullName}</div>
      <div><span>{tr("جنسیت")}</span>{GENDER_LABEL[patient.gender] || "—"}</div>
      <div><span>{tr("تاریخ تولد")}</span>{fmtDate(patient.dateOfBirth)}</div>
      <div><span>{tr("گروه خونی")}</span>{patient.bloodGroup || "—"}</div>
      <div><span>{tr("قد")}</span>{patient.height ? tr("{0} سانتی‌متر", [patient.height]) : "—"}</div>
      <div><span>{tr("وزن")}</span>{patient.weight ? tr("{0} کیلوگرم", [patient.weight]) : "—"}</div>
      <div><span>{tr("داکتر مسئول (آخرین نوبت)")}</span>{patient.assignedDoctorName || "—"}</div>
      <div><span>{tr("آخرین مراجعه")}</span>{fmtDate(patient.lastVisitDate)}</div>
      <div><span>{tr("تعداد کل نوبت‌ها")}</span>{patient.totalAppointments ?? "—"}</div>
      <div><span>{tr("تاریخ ثبت پرونده")}</span>{fmtDate(patient.createdAt)}</div>
      {patient.userId && <div><span>{tr("ایمیل تایید شده")}</span>{patient.userIsVerified ? tr("بله") : tr("خیر")}</div>}
    </div>
  );
}

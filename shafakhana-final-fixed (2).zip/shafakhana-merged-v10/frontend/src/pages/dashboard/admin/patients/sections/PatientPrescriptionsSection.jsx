import { fmtDate } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientPrescriptionsSection({ prescriptions = [], onView }) {
  if (prescriptions.length === 0) return <p>{tr("هیچ نسخه‌ای برای این بیمار ثبت نشده است.")}</p>;
  return (
    <table className="dash-table">
      <thead><tr><th>{tr("تاریخ")}</th><th>{tr("دارو")}</th><th>{tr("دوز")}</th><th>{tr("مدت")}</th><th>{tr("داکتر")}</th><th>{tr("عملیات")}</th></tr></thead>
      <tbody>
        {prescriptions.map((p) => (
          <tr key={p.id}>
            <td>{fmtDate(p.createdAt)}</td>
            <td>{p.medicationName}</td>
            <td>{p.dosage || "—"}</td>
            <td>{p.duration || "—"}</td>
            <td>{p.doctorName || "—"}</td>
            <td><button className="btn btn-ghost btn-sm" onClick={() => onView(p)}>{tr("مشاهده / چاپ")}</button></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

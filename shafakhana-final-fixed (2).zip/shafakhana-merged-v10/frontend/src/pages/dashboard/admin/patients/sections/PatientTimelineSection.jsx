import { fmtDateTime } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientTimelineSection({ events = [] }) {
  if (events.length === 0) return <p>{tr("هنوز هیچ رویدادی برای این بیمار ثبت نشده است.")}</p>;
  return (
    <div className="patient-timeline">
      {events.map((ev, idx) => (
        <div key={`${ev.type}-${idx}`} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: "1px solid var(--glass-border)" }}>
          <div style={{ fontSize: 20 }}>{ev.icon}</div>
          <div style={{ flex: 1 }}>
            <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
              <strong>{ev.label}</strong>
              <span style={{ color: "var(--text-3)", fontSize: 13 }}>{fmtDateTime(ev.date)}</span>
            </div>
            <p style={{ margin: "4px 0 0", color: "var(--text-2)" }}>
              {ev.detail}{ev.doctorName ? ` — ${ev.doctorName}` : ""}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

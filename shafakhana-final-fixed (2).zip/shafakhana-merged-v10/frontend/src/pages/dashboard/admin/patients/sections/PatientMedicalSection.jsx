import { LAB_STATUS_LABEL, fmtDate } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientMedicalSection({ data, onDownloadLab, busyAction }) {
  const { encounters = [], labResults = [], radiologyReports = [] } = data;
  return (
    <div>
      <h3>{tr("ویزیت‌ها و رکوردهای طبی")}</h3>
      {encounters.length === 0 && <p>{tr("هیچ ویزیتی برای این بیمار ثبت نشده است.")}</p>}
      {encounters.length > 0 && (
        <table className="dash-table">
          <thead><tr><th>{tr("تاریخ ویزیت")}</th><th>{tr("داکتر")}</th><th>{tr("علائم")}</th><th>{tr("تشخیص")}</th><th>{tr("درمان")}</th><th>{tr("یادداشت")}</th></tr></thead>
          <tbody>
            {encounters.map((e) => (
              <tr key={e.id}>
                <td>{fmtDate(e.visitDate)}</td>
                <td>{e.doctorName || "—"}</td>
                <td>{e.symptoms || "—"}</td>
                <td>{e.diagnosis || "—"}</td>
                <td>{e.treatment || "—"}</td>
                <td>{e.notes || "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <h3 style={{ marginTop: 24 }}>{tr("نتایج آزمایشگاه")}</h3>
      {labResults.length === 0 && <p>{tr("هیچ آزمایشی برای این بیمار ثبت نشده است.")}</p>}
      {labResults.length > 0 && (
        <table className="dash-table">
          <thead><tr><th>{tr("نوع آزمایش")}</th><th>{tr("نتیجه")}</th><th>{tr("محدوده مرجع")}</th><th>{tr("تاریخ")}</th><th>{tr("وضعیت")}</th><th>{tr("گزارش")}</th></tr></thead>
          <tbody>
            {labResults.map((l) => (
              <tr key={l.id}>
                <td>{l.testName}</td>
                <td>{l.result ? `${l.result} ${l.unit || ""}` : "—"}</td>
                <td>{l.referenceRange || "—"}</td>
                <td>{fmtDate(l.testDate)}</td>
                <td><span className={`status-badge ${l.status === "completed" ? "status-completed" : "status-pending"}`}>{LAB_STATUS_LABEL[l.status] || l.status}</span></td>
                <td>
                  {l.reportUrl ? (
                    <button className="btn btn-ghost btn-sm" disabled={busyAction === `lab-${l.id}`} onClick={() => onDownloadLab(l.id)}>{tr("دانلود گزارش")}</button>
                  ) : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <h3 style={{ marginTop: 24 }}>{tr("گزارش‌های رادیولوژی")}</h3>
      {radiologyReports.length === 0 && <p>{tr("هیچ گزارش رادیولوژی برای این بیمار ثبت نشده است.")}</p>}
      {radiologyReports.length > 0 && (
        <table className="dash-table">
          <thead><tr><th>{tr("نوع بررسی")}</th><th>{tr("یافته‌ها")}</th><th>{tr("نتیجه‌گیری")}</th><th>{tr("تاریخ")}</th><th>{tr("تصویر")}</th></tr></thead>
          <tbody>
            {radiologyReports.map((r) => (
              <tr key={r.id}>
                <td>{r.examType}</td>
                <td>{r.findings || "—"}</td>
                <td>{r.impression || "—"}</td>
                <td>{fmtDate(r.examDate)}</td>
                <td>{r.imageUrl ? <a href={r.imageUrl} target="_blank" rel="noreferrer">{tr("مشاهده")}</a> : "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

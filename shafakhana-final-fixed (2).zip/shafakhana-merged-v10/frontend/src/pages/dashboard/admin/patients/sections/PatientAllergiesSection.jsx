import { SEVERITY_LABEL, SEVERITY_STATUS_CLASS, fmtDate } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientAllergiesSection({ allergies = [], patient }) {
  return (
    <div>
      {(patient.allergies || patient.drugAllergies) && (
        <div className="info-grid" style={{ marginBottom: 18 }}>
          {patient.allergies && <div><span>{tr("حساسیت‌های عمومی (ثبت‌شده در پروفایل)")}</span>{patient.allergies}</div>}
          {patient.drugAllergies && <div><span>{tr("حساسیت دارویی (ثبت‌شده در پروفایل)")}</span>{patient.drugAllergies}</div>}
        </div>
      )}
      {allergies.length === 0 && <p>{tr("هیچ حساسیت ثبت‌شده‌ی دقیقی در پرونده الکترونیک صحی این بیمار وجود ندارد.")}</p>}
      {allergies.length > 0 && (
        <table className="dash-table">
          <thead><tr><th>{tr("ماده حساسیت‌زا")}</th><th>{tr("واکنش")}</th><th>{tr("شدت")}</th><th>{tr("یادداشت")}</th><th>{tr("ثبت‌شده توسط")}</th><th>{tr("تاریخ")}</th></tr></thead>
          <tbody>
            {allergies.map((a) => (
              <tr key={a.id}>
                <td>{a.allergen}</td>
                <td>{a.reaction || "—"}</td>
                <td><span className={`status-badge ${SEVERITY_STATUS_CLASS[a.severity]}`}>{SEVERITY_LABEL[a.severity] || a.severity}</span></td>
                <td>{a.notes || "—"}</td>
                <td>{a.doctorName || "—"}</td>
                <td>{fmtDate(a.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

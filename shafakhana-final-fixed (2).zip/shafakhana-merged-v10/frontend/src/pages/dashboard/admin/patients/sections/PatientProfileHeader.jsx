import { resolvePhotoUrl } from "../../../../../utils/api.js";

import { tr } from "../../../../../i18n/tr.js";
// هدر پروفایل — عکس، نام، شناسه، وضعیت حساب و خلاصه‌ی سریع (بالای همه‌ی تب‌ها ثابت است)
export function PatientProfileHeader({ patient }) {
  const photoSrc = resolvePhotoUrl(patient.userPhotoUrl);
  const isActive = patient.userIsActive === undefined || patient.userIsActive === null ? true : !!patient.userIsActive;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
      <div className="doctor-thumb" style={{ width: 64, height: 64 }}>
        {photoSrc ? <img src={photoSrc} alt={patient.fullName} /> : <span className="avatar-fallback">{patient.fullName?.charAt(0) || "👤"}</span>}
      </div>
      <div>
        <h2 style={{ margin: 0 }}>{patient.fullName} <span style={{ fontWeight: 400, fontSize: 14, color: "var(--text-3)" }}>#{patient.id}</span></h2>
        <p style={{ margin: "4px 0", color: "var(--text-3)" }}>
          {patient.phone} {patient.email ? `— ${patient.email}` : ""}
        </p>
      </div>
      <div style={{ marginInlineStart: "auto" }}>
        {patient.userId
          ? <span className={`status-badge ${isActive ? "status-active" : "status-inactive"}`}>{isActive ? tr("حساب فعال") : tr("حساب غیرفعال")}</span>
          : <span className="status-badge status-pending">{tr("بدون حساب کاربری (مهمان)")}</span>}
      </div>
    </div>
  );
}

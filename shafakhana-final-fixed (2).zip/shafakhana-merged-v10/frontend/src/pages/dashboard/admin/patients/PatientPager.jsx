
import { tr } from "../../../../i18n/tr.js";

// صفحه‌بندی مخصوص جدول بیماران: بازه‌ی نمایش + مجموع + شماره‌صفحه‌ها (پنجره‌ی ۵تایی)
export function PatientPager({ pagination, page, onPageChange, fa, noun = tr("بیمار") }) {
  const { total, limit, totalPages } = pagination;
  const from = (page - 1) * limit + 1;
  const to = Math.min(page * limit, total);
  const start = Math.max(1, Math.min(page - 2, totalPages - 4));
  const nums = [];
  for (let n = start; n <= Math.min(totalPages, start + 4); n += 1) nums.push(n);
  return (
    <nav className="pm-pager" aria-label={tr("صفحه‌بندی")}>
      <span>{tr("نمایش {0} تا {1} از {2} {3}", [fa(from), fa(to), fa(total), noun])}</span>
      {totalPages > 1 && (
        <div className="pm-pages">
          <button type="button" className="pm-page-btn" disabled={page <= 1} onClick={() => onPageChange(page - 1)} aria-label={tr("صفحه قبل")}>›</button>
          {nums.map((n) => (
            <button key={n} type="button" className="pm-page-btn" aria-current={n === page ? "page" : undefined} onClick={() => onPageChange(n)}>{fa(n)}</button>
          ))}
          <button type="button" className="pm-page-btn" disabled={page >= totalPages} onClick={() => onPageChange(page + 1)} aria-label={tr("صفحه بعد")}>‹</button>
        </div>
      )}
    </nav>
  );
}

import { DIAGNOSIS_STATUS_CLASS, DIAGNOSIS_STATUS_LABEL, fmtDate } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientDiseasesSection({ diagnoses = [], patient }) {
  return (
    <div>
      {patient.chronicDiseases && (
        <div className="info-grid" style={{ marginBottom: 18 }}>
          <div><span>{tr("بیماری‌های مزمن (ثبت‌شده در پروفایل)")}</span>{patient.chronicDiseases}</div>
        </div>
      )}
      {diagnoses.length === 0 && <p>{tr("هیچ تشخیص/بیماری دقیقی در پرونده الکترونیک صحی این بیمار ثبت نشده است.")}</p>}
      {diagnoses.length > 0 && (
        <table className="dash-table">
          <thead><tr><th>{tr("عنوان")}</th><th>{tr("کد ICD")}</th><th>{tr("توضیحات")}</th><th>{tr("وضعیت")}</th><th>{tr("داکتر")}</th><th>{tr("تاریخ")}</th></tr></thead>
          <tbody>
            {diagnoses.map((d) => (
              <tr key={d.id}>
                <td>{d.title}</td>
                <td>{d.icdCode || "—"}</td>
                <td>{d.description || "—"}</td>
                <td><span className={`status-badge ${DIAGNOSIS_STATUS_CLASS[d.status]}`}>{DIAGNOSIS_STATUS_LABEL[d.status] || d.status}</span></td>
                <td>{d.doctorName || "—"}</td>
                <td>{fmtDate(d.createdAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

import { CalendarDays, ClipboardList, Download, Eye, FileSpreadsheet, FileText, KeyRound, MoreVertical, Pencil, Pill, Power, Printer, QrCode, Search, SlidersHorizontal, Trash2, UserCheck, UserRound, UserX, Users, X } from "lucide-react";
import { DepartmentToastContainer, useDepartmentToasts } from "../../../../components/dashboard/DepartmentToast.jsx";
import FloatingMenu from "../../../../components/dashboard/FloatingMenu.jsx";
import GlobalModal from "../../../../components/GlobalModal.jsx";
import { JalaliDateInput } from "../../../../components/JalaliDateInput.jsx";
import { PERSIAN_NAME_ERROR_MESSAGE, isValidPersianName } from "../../../../utils/persianName.js";
import { apiDownload, apiRequest, resolvePhotoUrl } from "../../../../utils/api.js";
import { buildQueryString, useDebouncedValue, useLoadable, useSearchable } from "../adminShared.jsx";
import { isScrollbarClick } from "../../../../utils/scrollbarClick.js";
import { useEffect, useState } from "react";
import { GENDER_LABEL, fmtDate, patientAge } from "./patientUtils.js";
import { PatientDetailPage } from "./PatientDetailPage.jsx";
import { PatientPager } from "./PatientPager.jsx";
import { ResetPasswordResultModal } from "./ResetPasswordResultModal.jsx";

import { tr, numLocale } from "../../../../i18n/tr.js";
// ---------- بیماران ----------
export function PatientsPanel() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [genderFilter, setGenderFilter] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  // بازه‌ی تاریخ ثبت پرونده (createdAt) — فیلتر پیشرفته داخل پنل «فیلترها»
  const [createdFrom, setCreatedFrom] = useState("");
  const [createdTo, setCreatedTo] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [page, setPage] = useState(1);
  const debouncedSearch = useDebouncedValue(search);
  // فهرست داکتران برای پرکردن فیلتر «داکتر مسئول» — بدون هیچ query param، همه‌ی
  // داکتران (بدون صفحه‌بندی) برگردانده می‌شود، همان الگوی departmentOptions در DoctorsPanel
  const { items: doctorOptions } = useLoadable("/admin/doctors", "doctors");

  // با شروع جستجوی جدید یا تغییر هر فیلتر، همیشه به صفحه اول برمی‌گردیم
  useEffect(() => setPage(1), [debouncedSearch, statusFilter, genderFilter, doctorFilter, createdFrom, createdTo]);

  const { items, pagination, loading, error, reload: reloadList, setError } = useSearchable(
    "/admin/patients",
    "patients",
    { q: debouncedSearch, status: statusFilter, gender: genderFilter, doctorId: doctorFilter, createdFrom, createdTo },
    page
  );

  // آمار کارت‌های بالا (یک کوئری تجمیعی در بک‌اند) — فقط یک‌بار هنگام ورود و بعد از هر
  // عملیاتی که تعداد/وضعیت را عوض می‌کند دوباره خوانده می‌شود، نه با هر جستجو/ورق‌زدن
  const [stats, setStats] = useState(null);
  function loadStats() {
    apiRequest("/admin/patients/stats").then((d) => setStats(d.stats || null)).catch(() => {});
  }
  useEffect(loadStats, []);
  // handlerهای موجود (حذف، تغییر وضعیت، ویرایش و ...) همچنان reload() را صدا می‌زنند
  function reload() {
    reloadList();
    loadStats();
  }

  // منوی ⋮ ردیف — فقط یک منو در هر لحظه باز است؛ با کلیک بیرون یا Esc بسته می‌شود
  const [menuId, setMenuId] = useState(null);
  useEffect(() => {
    if (menuId === null) return undefined;
    const onDown = (e) => { if (isScrollbarClick(e)) return; if (!e.target.closest?.(".pm-menu-wrap, .pm-menu")) setMenuId(null); };
    const onKey = (e) => { if (e.key === "Escape") setMenuId(null); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); };
  }, [menuId]);
  const [detailSection, setDetailSection] = useState("personal");
  const [headMenuOpen, setHeadMenuOpen] = useState(false);
  useEffect(() => {
    if (!headMenuOpen) return undefined;
    const onDown = (e) => { if (isScrollbarClick(e)) return; if (!e.target.closest?.(".pm-head-actions")) setHeadMenuOpen(false); };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [headMenuOpen]);

  const activeFilterCount = [statusFilter, genderFilter, doctorFilter, createdFrom, createdTo].filter(Boolean).length;
  function clearFilters() {
    setStatusFilter(""); setGenderFilter(""); setDoctorFilter(""); setCreatedFrom(""); setCreatedTo("");
  }

  // با تغییر صفحه/جستجو یا هر بارگذاری تازه، انتخاب چک‌باکس‌ها پاک می‌شود تا ردیف‌های
  // دیگر (که دیگر روی صفحه نیستند) به‌اشتباه انتخاب‌شده باقی نمانند
  useEffect(() => setSelectedIds([]), [items]);
  const [editing, setEditing] = useState(null);
  // به‌جای مودالِ قبلی، کلیک روی «مشاهده» حالا صفحه‌ی اختصاصی جزئیات بیمار را
  // به‌جای فهرست باز می‌کند (detailPatientId) — همان الگوی view=list/detail در BillingPanel
  const [detailPatientId, setDetailPatientId] = useState(null);
  const [resetResult, setResetResult] = useState(null);
  const [busyAction, setBusyAction] = useState(null); // مثلاً "3-status" یا "3-reset" — برای غیرفعال‌سازی موقت دکمه‌ی همان ردیف/عملیات
  const [exportBusy, setExportBusy] = useState(null); // "excel" | "pdf" | "print" — برای غیرفعال‌سازی موقت دکمه‌های خروجی/چاپ
  // انتخاب چندتایی (چک‌باکس) برای خروجی‌گیری/حذف گروهی — فقط شناسه‌های همین صفحه نگه‌داری می‌شود
  const [selectedIds, setSelectedIds] = useState([]);
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  const [editError, setEditError] = useState("");

  async function saveEdit(e) {
    e.preventDefault();
    setEditError("");
    if (!isValidPersianName(editing.fullName)) {
      setEditError(PERSIAN_NAME_ERROR_MESSAGE);
      return;
    }
    try {
      await apiRequest(`/admin/patients/${editing.id}`, { method: "PUT", body: editing });
      setEditing(null);
      showToast(tr("اطلاعات بیمار ذخیره شد"), "success");
      reload();
    } catch (err) {
      setError(err.message);
    }
  }

  async function remove(id) {
    if (!confirm(tr("آیا از حذف این بیمار مطمئن هستید؟ این عملیات قابل بازگشت نیست."))) return;
    try {
      await apiRequest(`/admin/patients/${id}`, { method: "DELETE" });
      showToast(tr("بیمار حذف شد"), "success");
      reload();
    } catch (err) {
      setError(err.message);
    }
  }

  function viewPatientDetails(p, section = "personal") {
    setDetailSection(section);
    setDetailPatientId(p.id);
  }

  async function toggleAccountStatus(p, nextActive) {
    const confirmMsg = nextActive
      ? tr("آیا از فعال‌سازی حساب «{0}» مطمئن هستید؟", [p.fullName])
      : tr("آیا از غیرفعال‌سازی حساب «{0}» مطمئن هستید؟ این بیمار دیگر نمی‌تواند وارد حساب خود شود.", [p.fullName]);
    if (!confirm(confirmMsg)) return;
    setBusyAction(`${p.id}-status`);
    try {
      await apiRequest(`/admin/patients/${p.id}/status`, { method: "PUT", body: { isActive: nextActive } });
      showToast(nextActive ? tr("حساب بیمار فعال شد") : tr("حساب بیمار غیرفعال شد"), "success");
      reload();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyAction(null);
    }
  }

  async function resetPassword(p) {
    if (!confirm(tr("آیا از بازنشانی رمز عبور «{0}» مطمئن هستید؟ رمز عبور فعلی این بیمار دیگر کار نخواهد کرد.", [p.fullName]))) return;
    setBusyAction(`${p.id}-reset`);
    try {
      const data = await apiRequest(`/admin/patients/${p.id}/reset-password`, { method: "POST" });
      setResetResult({ patient: p, ...data });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyAction(null);
    }
  }

  async function printPatientInfo(p) {
    setBusyAction(`${p.id}-print`);
    try {
      await apiDownload(`/admin/patients/${p.id}/pdf`, `patient-${p.id}.pdf`, { openInNewTab: true });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyAction(null);
    }
  }

  async function downloadPatientInfo(p) {
    setBusyAction(`${p.id}-download`);
    try {
      await apiDownload(`/admin/patients/${p.id}/pdf`, `patient-${p.id}.pdf`);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyAction(null);
    }
  }

  // کارت چاپی بیمار (نام + کد + QR) — برای تحویل به بیمار، تا در پذیرش با اسکن سریع پیدا شود
  async function downloadPatientCard(p) {
    setBusyAction(`${p.id}-card`);
    try {
      await apiDownload(`/admin/patients/${p.id}/card`, `patient-card-${p.id}.pdf`, { openInNewTab: true });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyAction(null);
    }
  }

  function toggleSelectOne(id) {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function toggleSelectAllOnPage() {
    const pageIds = items.map((p) => p.id);
    const allSelected = pageIds.length > 0 && pageIds.every((id) => selectedIds.includes(id));
    setSelectedIds(allSelected ? [] : pageIds);
  }

  // خروجی Excel/PDF: اگر بیمارانی انتخاب‌شده باشند فقط همان‌ها، وگرنه همان جستجوی
  // جاری پنل (q) — دقیقاً همان چیزی که ادمین روی صفحه می‌بیند
  async function exportPatients(format) {
    setExportBusy(format);
    try {
      const qs = buildQueryString({
        format,
        q: selectedIds.length > 0 ? undefined : debouncedSearch,
        ids: selectedIds.length > 0 ? selectedIds.join(",") : undefined,
      });
      const ext = format === "excel" ? "xlsx" : "pdf";
      await apiDownload(`/admin/patients/export${qs}`, `patients-list.${ext}`);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setExportBusy(null);
    }
  }

  // «چاپ لیست بیماران» — همان الگوی دکمه‌ی چاپ تکی بیمار: خروجی PDF در تب جدید باز
  // می‌شود تا از نمایشگر PDF مرورگر برای چاپ استفاده شود
  async function printPatientList() {
    setExportBusy("print");
    try {
      const qs = buildQueryString({
        format: "pdf",
        q: selectedIds.length > 0 ? undefined : debouncedSearch,
        ids: selectedIds.length > 0 ? selectedIds.join(",") : undefined,
      });
      await apiDownload(`/admin/patients/export${qs}`, "patients-list.pdf", { openInNewTab: true });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setExportBusy(null);
    }
  }

  async function bulkDelete() {
    if (selectedIds.length === 0) return;
    if (!confirm(tr("آیا از حذف {0} بیمار انتخاب‌شده مطمئن هستید؟ این عملیات قابل بازگشت نیست.", [selectedIds.length]))) return;
    setExportBusy("bulk-delete");
    try {
      const data = await apiRequest("/admin/patients/bulk", { method: "DELETE", body: { ids: selectedIds } });
      showToast(data.message || tr("بیماران انتخاب‌شده حذف شدند"), "success");
      setSelectedIds([]);
      reload();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setExportBusy(null);
    }
  }

  // «صفحه‌ی اختصاصی جزئیات بیمار» — به‌جای فهرست، کل این پنل با نمای پروفایل کامل
  // بیمار جایگزین می‌شود (همان الگوی چارچوب DashboardShell/dash-body حفظ می‌شود)
  if (detailPatientId) {
    return <PatientDetailPage patientId={detailPatientId} initialSection={detailSection} onBack={() => setDetailPatientId(null)} />;
  }

  const fa = (n) => Number(n || 0).toLocaleString(numLocale());
  const statCards = [
    { key: "", tone: "total", label: tr("کل بیماران"), value: stats?.total, Icon: Users },
    { key: "active", tone: "active", label: tr("حساب فعال"), value: stats?.active, Icon: UserCheck },
    { key: "inactive", tone: "inactive", label: tr("حساب غیرفعال"), value: stats?.inactive, Icon: UserX },
    { key: "guest", tone: "guest", label: tr("بدون حساب (مهمان)"), value: stats?.guest, Icon: UserRound },
  ];
  const hasFilters = activeFilterCount > 0 || !!debouncedSearch;
  const firstIdx = pagination ? (pagination.page - 1) * pagination.limit : 0;

  return (
    <div className="pm-page">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />

      <div className="pm-head">
        <div>
          <h2>{tr("مدیریت بیماران")}</h2>
          <p>{tr("مشاهده، جستجو و مدیریت اطلاعات بیماران به صورت کامل")}</p>
        </div>
        {/* خروجی‌ها (Excel/PDF/چاپ لیست) در یک منو جمع شده‌اند؛ منطق آن‌ها بدون تغییر است.
            دکمه‌ی «ثبت بیمار جدید» عمداً نیست: در بک‌اند ادمین مسیر ساخت بیمار وجود ندارد
            (بیمار از مسیر ثبت‌نام/رزرو نوبت ساخته می‌شود). */}
        <div className="pm-head-actions">
          <button type="button" className="btn btn-ghost btn-sm" aria-haspopup="menu" aria-expanded={headMenuOpen} onClick={() => setHeadMenuOpen((v) => !v)}>
            <Download size={14} />{" "}{tr("خروجی لیست")}</button>
          {headMenuOpen && (
            <div className="pm-menu" role="menu" style={{ top: "calc(100% + 6px)", left: 0 }}>
              <button type="button" role="menuitem" disabled={exportBusy === "excel"} onClick={() => { setHeadMenuOpen(false); exportPatients("excel"); }}><FileSpreadsheet size={15} />{" "}{tr("خروجی Excel")}</button>
              <button type="button" role="menuitem" disabled={exportBusy === "pdf"} onClick={() => { setHeadMenuOpen(false); exportPatients("pdf"); }}><FileText size={15} />{" "}{tr("خروجی PDF")}</button>
              <button type="button" role="menuitem" disabled={exportBusy === "print"} onClick={() => { setHeadMenuOpen(false); printPatientList(); }}><Printer size={15} />{" "}{tr("چاپ لیست بیماران")}</button>
            </div>
          )}
        </div>
      </div>

      <div className="pm-stats">
        {statCards.map(({ key, tone, label, value, Icon }) => (
          <button
            key={tone}
            type="button"
            className={`pm-stat pm-tone-${tone} ${stats ? "" : "is-loading"}`}
            aria-pressed={statusFilter === key}
            onClick={() => setStatusFilter(key)}
          >
            <span className="pm-stat-icon"><Icon size={20} /></span>
            <span>
              <span className="pm-stat-num">{stats ? fa(value) : "—"}</span>
              <span className="pm-stat-label">{label}</span>
            </span>
          </button>
        ))}
      </div>

      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="pm-search">
            <Search size={16} />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tr("جستجوی نام، شماره تماس، ایمیل یا کد بیمار...")}
              aria-label={tr("جستجوی بیماران")}
            />
          </div>
          <select className="pm-select dash-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={tr("وضعیت حساب")}>
            <option value="">{tr("وضعیت حساب: همه")}</option>
            <option value="active">{tr("فعال")}</option>
            <option value="inactive">{tr("غیرفعال")}</option>
            <option value="guest">{tr("مهمان (بدون حساب)")}</option>
          </select>
          <select className="pm-select dash-select" value={genderFilter} onChange={(e) => setGenderFilter(e.target.value)} aria-label={tr("جنسیت")}>
            <option value="">{tr("جنسیت: همه")}</option>
            <option value="male">{tr("مرد")}</option>
            <option value="female">{tr("زن")}</option>
          </select>
          <button type="button" className="btn btn-ghost btn-sm pm-filter-toggle" aria-expanded={filtersOpen} onClick={() => setFiltersOpen((v) => !v)}>
            <SlidersHorizontal size={14} />{" "}{tr("فیلترها")}{activeFilterCount > 0 && <span className="pm-filter-count">{fa(activeFilterCount)}</span>}
          </button>
          {activeFilterCount > 0 && (
            <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={clearFilters}>
              <X size={14} />{" "}{tr("پاک کردن فیلترها")}</button>
          )}
        </div>
        {filtersOpen && (
          <div className="pm-adv">
            <div className="field">
              <label htmlFor="pm-doctor">{tr("داکتر مسئول")}</label>
              <select id="pm-doctor" className="dash-select" value={doctorFilter} onChange={(e) => setDoctorFilter(e.target.value)}>
                <option value="">{tr("همه داکتران")}</option>
                {doctorOptions.map((d) => (<option key={d.id} value={d.id}>{d.fullName}</option>))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="pm-from">{tr("ثبت پرونده: از تاریخ")}</label>
              <JalaliDateInput id="pm-from" value={createdFrom} max={createdTo || undefined} onChange={(e) => setCreatedFrom(e.target.value)} />
            </div>
            <div className="field">
              <label htmlFor="pm-to">{tr("ثبت پرونده: تا تاریخ")}</label>
              <JalaliDateInput id="pm-to" value={createdTo} min={createdFrom || undefined} onChange={(e) => setCreatedTo(e.target.value)} />
            </div>
          </div>
        )}
      </div>

      {selectedIds.length > 0 && (
        <div className="pm-bulk" role="status">
          <span>{tr("{0} بیمار انتخاب‌شده", [fa(selectedIds.length)])}</span>
          <button type="button" className="btn btn-ghost btn-sm danger" disabled={exportBusy === "bulk-delete"} onClick={bulkDelete}>
            <Trash2 size={13} />{" "}{tr("حذف گروهی")}</button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setSelectedIds([])}>{tr("لغو انتخاب")}</button>
        </div>
      )}

      <div className="pm-tablewrap">
        {error && (
          <div className="pm-state" role="alert">
            <strong>{tr("بارگذاری فهرست بیماران انجام نشد")}</strong>
            {error}
            <div><button type="button" className="btn btn-ghost btn-sm" onClick={() => { setError(""); reload(); }}>{tr("تلاش دوباره")}</button></div>
          </div>
        )}

        {!error && loading && items.length === 0 && (
          <table className="pm-table" aria-busy="true">
            <tbody>
              {Array.from({ length: 6 }).map((_, i) => (
                <tr key={i}><td colSpan={8}><div className="pm-skel" style={{ width: `${60 + ((i * 13) % 35)}%` }} /></td></tr>
              ))}
            </tbody>
          </table>
        )}

        {!error && !loading && items.length === 0 && (
          <div className="pm-state">
            <strong>{tr("هیچ بیماری با این مشخصات پیدا نشد.")}</strong>
            {hasFilters ? tr("جستجو یا فیلترها را تغییر دهید.") : tr("هنوز بیماری ثبت نشده است.")}
            {activeFilterCount > 0 && (
              <div><button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button></div>
            )}
          </div>
        )}

        {!error && items.length > 0 && (
          <div className={loading ? "pm-table-wrap-busy" : undefined}>
            <table className="pm-table">
              <thead>
                <tr>
                  <th>
                    <input
                      type="checkbox"
                      checked={items.length > 0 && items.every((p) => selectedIds.includes(p.id))}
                      onChange={toggleSelectAllOnPage}
                      aria-label={tr("انتخاب همه‌ی بیماران این صفحه")}
                    />
                  </th>
                  <th>#</th>
                  <th>{tr("بیمار")}</th>
                  <th>{tr("جنسیت")}</th>
                  <th>{tr("سن")}</th>
                  <th>{tr("شماره تماس")}</th>
                  <th>{tr("آخرین مراجعه")}</th>
                  <th>{tr("وضعیت")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {items.map((p, idx) => {
                  const photoSrc = resolvePhotoUrl(p.userPhotoUrl);
                  const hasAccount = !!p.userId;
                  const isActive = p.userIsActive === undefined || p.userIsActive === null ? true : !!p.userIsActive;
                  const statusKey = !hasAccount ? "guest" : isActive ? "active" : "inactive";
                  const statusText = { guest: tr("بدون حساب"), active: tr("فعال"), inactive: tr("غیرفعال") }[statusKey];
                  const noAccountTitle = tr("این بیمار حساب کاربری ندارد (مهمان)");
                  const age = patientAge(p.dateOfBirth);
                  const menuOpen = menuId === p.id;
                  return (
                    <tr key={p.id}>
                      <td className="pm-cell-check">
                        <input type="checkbox" checked={selectedIds.includes(p.id)} onChange={() => toggleSelectOne(p.id)} aria-label={tr("انتخاب {0}", [p.fullName])} />
                      </td>
                      <td className="pm-cell-id pm-num pm-muted">{fa(firstIdx + idx + 1)}</td>
                      <td className="pm-cell-name">
                        <div className="pm-person">
                          <div className="doctor-thumb">
                            {photoSrc ? <img src={photoSrc} alt="" /> : <span className="avatar-fallback">{p.fullName?.charAt(0) || "👤"}</span>}
                          </div>
                          <div>
                            <span className="pm-person-name">{p.fullName}</span>
                            {p.publicCode && <span className="pm-sub pm-num">{tr("کد بیمار: {0}", [p.publicCode])}</span>}
                          </div>
                        </div>
                      </td>
                      <td data-label={tr("جنسیت")}>{p.gender ? <span className="pm-gender">{GENDER_LABEL[p.gender]}</span> : "—"}</td>
                      <td data-label={tr("سن")} className="pm-num">{age === null ? "—" : fa(age)}</td>
                      <td data-label={tr("شماره تماس")}>
                        <span className="pm-num" dir="ltr">{p.phone}</span>
                        {p.email && <span className="pm-sub">{p.email}</span>}
                      </td>
                      <td data-label={tr("آخرین مراجعه")}>
                        {p.lastVisitDate ? fmtDate(p.lastVisitDate) : "—"}
                        {p.assignedDoctorName && <span className="pm-sub">{p.assignedDoctorName}</span>}
                      </td>
                      <td data-label={tr("وضعیت")}><span className={`pm-status is-${statusKey}`}>{statusText}</span></td>
                      <td className="pm-cell-actions">
                        <div className="pm-actions">
                          <button type="button" className="pm-iconbtn" title={tr("مشاهده")} aria-label={tr("مشاهده {0}", [p.fullName])} onClick={() => viewPatientDetails(p)}><Eye size={16} /></button>
                          <button type="button" className="pm-iconbtn" title={tr("ویرایش")} aria-label={tr("ویرایش {0}", [p.fullName])} onClick={() => { setEditError(""); setEditing(p); }}><Pencil size={16} /></button>
                          <div className="pm-menu-wrap">
                            <button type="button" className="pm-iconbtn" title={tr("گزینه‌های بیشتر")} aria-label={tr("گزینه‌های بیشتر برای {0}", [p.fullName])} aria-haspopup="menu" aria-expanded={menuOpen} onClick={() => setMenuId(menuOpen ? null : p.id)}><MoreVertical size={16} /></button>
                            {menuOpen && (
                              <FloatingMenu onClose={() => setMenuId(null)}>
                                <button type="button" role="menuitem" onClick={() => { setMenuId(null); viewPatientDetails(p, "medical"); }}><ClipboardList size={15} />{" "}{tr("پرونده طبی")}</button>
                                <button type="button" role="menuitem" onClick={() => { setMenuId(null); viewPatientDetails(p, "prescriptions"); }}><Pill size={15} />{" "}{tr("نسخه‌ها")}</button>
                                <button type="button" role="menuitem" onClick={() => { setMenuId(null); viewPatientDetails(p, "appointments"); }}><CalendarDays size={15} />{" "}{tr("نوبت‌ها")}</button>
                                <hr />
                                <button type="button" role="menuitem" disabled={busyAction === `${p.id}-print`} onClick={() => { setMenuId(null); printPatientInfo(p); }}><Printer size={15} />{" "}{tr("چاپ اطلاعات")}</button>
                                <button type="button" role="menuitem" disabled={busyAction === `${p.id}-download`} onClick={() => { setMenuId(null); downloadPatientInfo(p); }}><Download size={15} />{" "}{tr("دانلود PDF")}</button>
                                <button type="button" role="menuitem" disabled={busyAction === `${p.id}-card`} onClick={() => { setMenuId(null); downloadPatientCard(p); }}><QrCode size={15} />{" "}{tr("کارت بیمار (QR)")}</button>
                                <hr />
                                <button type="button" role="menuitem" title={!hasAccount ? noAccountTitle : undefined} disabled={!hasAccount || busyAction === `${p.id}-status`} onClick={() => { setMenuId(null); toggleAccountStatus(p, !isActive); }}><Power size={15} /> {isActive ? tr("غیرفعال کردن حساب") : tr("فعال کردن حساب")}</button>
                                <button type="button" role="menuitem" title={!hasAccount ? noAccountTitle : undefined} disabled={!hasAccount || busyAction === `${p.id}-reset`} onClick={() => { setMenuId(null); resetPassword(p); }}><KeyRound size={15} />{" "}{tr("بازنشانی رمز عبور")}</button>
                                <hr />
                                <button type="button" role="menuitem" className="is-danger" onClick={() => { setMenuId(null); remove(p.id); }}><Trash2 size={15} />{" "}{tr("حذف بیمار")}</button>
                              </FloatingMenu>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {!error && pagination && pagination.total > 0 && (
          <PatientPager pagination={pagination} page={page} onPageChange={setPage} fa={fa} />
        )}
      </div>

      <GlobalModal
        isOpen={!!editing}
        onClose={() => setEditing(null)}
        title={tr("ویرایش اطلاعات بیمار")}
        size="sm"
        footer={
          <>
            <button className="btn btn-primary" type="submit" form="pm-edit-form">{tr("ذخیره")}</button>
            <button className="btn btn-ghost" type="button" onClick={() => setEditing(null)}>{tr("انصراف")}</button>
          </>
        }
      >
        {editing && (
          <form id="pm-edit-form" className="login-form" onSubmit={saveEdit}>
            <div className="field"><label htmlFor="pm-e-name">{tr("نام کامل")}</label><input id="pm-e-name" value={editing.fullName} onChange={(e) => setEditing((x) => ({ ...x, fullName: e.target.value }))} /></div>
            {editError && <div className="form-message error">{editError}</div>}
            <div className="field"><label htmlFor="pm-e-phone">{tr("شماره تماس")}</label><input id="pm-e-phone" dir="ltr" value={editing.phone} onChange={(e) => setEditing((x) => ({ ...x, phone: e.target.value }))} /></div>
            <div className="field"><label htmlFor="pm-e-email">{tr("ایمیل")}</label><input id="pm-e-email" dir="ltr" value={editing.email || ""} onChange={(e) => setEditing((x) => ({ ...x, email: e.target.value }))} /></div>
          </form>
        )}
      </GlobalModal>

      <ResetPasswordResultModal result={resetResult} onClose={() => setResetResult(null)} />
    </div>
  );
}

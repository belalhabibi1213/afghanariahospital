import { fmtDateTime } from "../patientUtils.js";

import { tr } from "../../../../../i18n/tr.js";
export function PatientFilesSection({ fileTransfers = [], onDownload, busyAction }) {
  if (fileTransfers.length === 0) return <p>{tr("هیچ فایل صحی‌ای برای این بیمار دریافت نشده است.")}</p>;
  return (
    <table className="dash-table">
      <thead><tr><th>{tr("نام فایل")}</th><th>{tr("نوع")}</th><th>{tr("حجم")}</th><th>{tr("ارسال‌کننده")}</th><th>{tr("یادداشت")}</th><th>{tr("تاریخ")}</th><th>{tr("عملیات")}</th></tr></thead>
      <tbody>
        {fileTransfers.map((f) => (
          <tr key={f.id}>
            <td>{f.originalName}</td>
            <td>{f.fileType}</td>
            <td>{f.fileSize ? tr("{0} کیلوبایت", [(f.fileSize / 1024).toFixed(0)]) : "—"}</td>
            <td>{f.doctorName || "—"}</td>
            <td>{f.note || "—"}</td>
            <td>{fmtDateTime(f.createdAt)}</td>
            <td>
              <button className="btn btn-ghost btn-sm" disabled={busyAction === `file-${f.id}`} onClick={() => onDownload(f.id, f.originalName)}>{tr("دانلود")}</button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

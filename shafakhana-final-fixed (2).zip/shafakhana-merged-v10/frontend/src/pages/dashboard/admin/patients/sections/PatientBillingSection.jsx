import { INVOICE_STATUS_LABEL, getApprovalStatusKey } from "../../../../../components/dashboard/InvoiceDetail.jsx";
import { money } from "../../AdminReportingPanel.jsx";

import { tr, jdate } from "../../../../../i18n/tr.js";
export function PatientBillingSection({ invoices = [], onView, loading }) {
  if (invoices.length === 0) return <p>{tr("هیچ فاکتوری برای این بیمار صادر نشده است.")}</p>;
  return (
    <table className="dash-table">
      <thead><tr><th>{tr("شماره فاکتور")}</th><th>{tr("تاریخ صدور")}</th><th>{tr("مبلغ کل")}</th><th>{tr("پرداخت‌شده")}</th><th>{tr("وضعیت")}</th><th>{tr("عملیات")}</th></tr></thead>
      <tbody>
        {invoices.map((inv) => (
          <tr key={inv.id}>
            <td>{inv.invoiceNumber}</td>
            <td>{jdate(inv.issueDate)}</td>
            <td>{money(inv.totalAmount)}</td>
            <td>{money(inv.paidAmount)}</td>
            <td>
              <span className={`status-badge status-${getApprovalStatusKey(inv)}`}>
                {INVOICE_STATUS_LABEL[getApprovalStatusKey(inv)]}
              </span>
            </td>
            <td><button className="btn btn-ghost btn-sm" disabled={loading} onClick={() => onView(inv.id)}>{tr("مشاهده / چاپ")}</button></td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

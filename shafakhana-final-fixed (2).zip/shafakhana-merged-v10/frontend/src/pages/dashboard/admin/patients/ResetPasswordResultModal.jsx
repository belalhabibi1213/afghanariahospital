import GlobalModal from "../../../../components/GlobalModal.jsx";
import { useEffect, useState } from "react";

import { tr } from "../../../../i18n/tr.js";
// مودال نمایش نتیجه‌ی «بازنشانی رمز عبور» — رمز عبور موقت باید همین‌جا به ادمین
// نمایش داده شود (نه فقط toast زودگذر) چون اگر ایمیل ارسال نشده باشد، تنها راه
// اطلاع‌رسانی به بیمار همین است که ادمین شخصاً آن را کپی/یادداشت کند.
export function ResetPasswordResultModal({ result, onClose }) {
  const [copied, setCopied] = useState(false);

  useEffect(() => setCopied(false), [result]);

  async function copyPassword() {
    try {
      await navigator.clipboard.writeText(result.tempPassword);
      setCopied(true);
    } catch {
      // اگر Clipboard API در دسترس نبود (مثلاً محدودیت مرورگر)، کاربر می‌تواند
      // رمز عبور را دستی از متن انتخاب و کپی کند؛ نیازی به شکستن جریان نیست
    }
  }

  return (
    <GlobalModal
      isOpen={!!result}
      onClose={onClose}
      size="sm"
      className="logout-confirm-modal"
      overlayClassName="logout-confirm-overlay"
      labelledBy="reset-password-title"
      bare
    >
      {result && (
        <>
          <h3 id="reset-password-title">{tr("رمز عبور جدید بیمار")}</h3>
          <p>{result.message}</p>
          <p style={{ fontFamily: "monospace", fontSize: 18, letterSpacing: 2, background: "var(--glass-bg)", border: "1px solid var(--glass-border)", borderRadius: "var(--radius-sm)", padding: "10px 14px", textAlign: "center" }}>
            {result.tempPassword}
          </p>
          {!result.emailDelivered && (
            <p className="form-message error">{tr("ایمیل ارسال نشد؛ لطفاً رمز عبور بالا را شخصاً به «{0}» اطلاع دهید.", [result.patient?.fullName])}</p>
          )}
          <div className="modal-actions">
            <button type="button" className="btn btn-primary" onClick={copyPassword}>
              {copied ? tr("کپی شد ✓") : tr("کپی رمز عبور")}
            </button>
            <button type="button" className="btn btn-ghost" onClick={onClose}>{tr("بستن")}</button>
          </div>
        </>
      )}
    </GlobalModal>
  );
}

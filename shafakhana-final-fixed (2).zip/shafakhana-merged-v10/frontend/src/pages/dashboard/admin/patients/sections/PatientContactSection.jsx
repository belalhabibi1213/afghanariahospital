
import { tr } from "../../../../../i18n/tr.js";

export function PatientContactSection({ patient }) {
  return (
    <div className="info-grid">
      <div><span>{tr("شماره تماس")}</span>{patient.phone}</div>
      <div><span>{tr("ایمیل")}</span>{patient.email || "—"}</div>
      <div><span>{tr("آدرس")}</span>{patient.address || "—"}</div>
      <div><span>{tr("نام تماس اضطراری")}</span>{patient.emergencyContactName || "—"}</div>
      <div><span>{tr("نسبت با بیمار")}</span>{patient.emergencyContactRelationship || "—"}</div>
      <div><span>{tr("شماره تماس اضطراری")}</span>{patient.emergencyContactPhone || "—"}</div>
    </div>
  );
}

import { useEffect, useMemo, useRef, useState } from "react";
import { Search, X, Eye, Power, Trash2, Pencil, MoreVertical, UserCheck, UserX, Building2, Globe, EyeOff, Plus, ChevronLeft, Camera, ImagePlus } from "lucide-react";
import GlobalModal from "../../../components/GlobalModal.jsx";
import DepartmentIconPicker, { DepartmentIconThumb } from "../../../components/dashboard/DepartmentIconPicker.jsx";
import { useDepartmentToasts, DepartmentToastContainer } from "../../../components/dashboard/DepartmentToast.jsx";
import { getDepartmentMeta } from "../../../components/departments/departmentMeta.js";
import { apiRequest, apiUpload, resolvePhotoUrl } from "../../../utils/api.js";
import { useLoadable } from "./adminShared.jsx";
import { fmtDate } from "./AdminPatientsPanel.jsx";
import { DoctorPager } from "./AdminDoctorsPanel.jsx";
import { isScrollbarClick } from "../../../utils/scrollbarClick.js";
import FloatingMenu from "../../../components/dashboard/FloatingMenu.jsx";
import FilePickerField from "../../../components/dashboard/FilePickerField.jsx";

import { tr, trc, numLocale } from "../../../i18n/tr.js";
// ---------- بخش‌ها ----------
// فرمت‌های مجاز برای آیکون بخش: PNG، JPG/JPEG و SVG (برخلاف عکس پروفایل/داکتر که فقط
// PNG/JPG/WEBP هستند، چون آیکون بخش‌ها اغلب برداری/SVG هستند) — همان اعتبارسنجی سمت
// بک‌اند در middleware/upload.js (uploadDepartmentIcon) هم اعمال می‌شود
export const ALLOWED_ICON_TYPES = ["image/png", "image/jpeg", "image/svg+xml"];
export const MAX_ICON_SIZE = 2 * 1024 * 1024; // ۲ مگابایت

// بررسی سمت کلاینت فرمت و حجم آیکون، پیش از ارسال به سرور (اعتبارسنجی نهایی همچنان در بک‌اند انجام می‌شود)
export function validateIconFile(file) {
  if (!ALLOWED_ICON_TYPES.includes(file.type)) {
    return tr("فرمت آیکون مجاز نیست. فقط PNG، JPG، JPEG یا SVG مجاز است.");
  }
  if (file.size > MAX_ICON_SIZE) {
    return tr("حجم آیکون نباید بیشتر از ۲ مگابایت باشد.");
  }
  return null;
}

// عکس کاور کارت بخش در سایت عمومی: فقط JPG/PNG/WEBP و حداکثر ۲ مگابایت (همان محدودیت بک‌اند)
export const ALLOWED_COVER_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const MAX_COVER_SIZE = 2 * 1024 * 1024;

export function validateCoverFile(file) {
  if (!ALLOWED_COVER_TYPES.includes(file.type)) {
    return tr("فرمت عکس مجاز نیست. فقط JPG، PNG یا WEBP مجاز است.");
  }
  if (file.size > MAX_COVER_SIZE) {
    return tr("حجم عکس نباید بیشتر از ۲ مگابایت باشد.");
  }
  return null;
}

// نوار تصویری بالای کارت بخش در پنل ادمین — همان عکسی که در کارت سایت عمومی دیده می‌شود
// (عکس کاور آپلودی، وگرنه عکس پیش‌فرض تخصص، وگرنه طرح رنگی تخصص)
export function DepartmentCoverStrip({ department, className = "dm-dept-cover" }) {
  const meta = getDepartmentMeta(department);
  return (
    <div
      className={`${className} dpt-accent-${meta.accent}${meta.photo ? " dm-has-photo" : ""}`}
      style={meta.photo ? { "--dm-photo": `url("${String(meta.photo).replace(/"/g, "%22")}")` } : undefined}
      aria-hidden="true"
    >
      {meta.photo ? <img src={meta.photo} alt="" loading="lazy" /> : <span className="dm-dept-cover-fallback" />}
    </div>
  );
}

export const DEPARTMENT_STATUS_LABEL = trc({ active: "فعال", inactive: "غیرفعال" });

// همه‌ی فیلدهای مدیریتی بخش (models/Department.js) — برای فرم افزودن/ویرایش. رنگ‌بندی
// (iconColor/iconBackground/cardBackground/textColor) دیگر از این فرم قابل تنظیم نیست؛
// نمایش آیکون/کارت بخش همیشه از تم پیش‌فرض سایت (CSS) پیروی می‌کند.
export const emptyDepartmentForm = {
  name: "", nameEn: "", description: "", descriptionEn: "",
  iconType: "lucide", icon: "",
  slug: "", displayOrder: 0, status: "active", showOnWebsite: true,
  seoTitle: "", seoDescription: "",
};

// اعتبارسنجی سمت کلاینت فرم بخش — هم‌راستا با createDepartmentValidation/updateDepartmentValidation
// سمت بک‌اند (middleware/formValidators.js)، برای بازخورد فوری به کاربر پیش از ارسال درخواست
export function validateDepartmentForm(form) {
  const errors = {};

  const name = form.name.trim();
  if (!name) errors.name = tr("نام بخش الزامی است");
  else if (name.length > 100) errors.name = tr("نام بخش نباید بیشتر از ۱۰۰ کاراکتر باشد");

  if (form.description && form.description.trim().length > 2000) {
    errors.description = tr("توضیحات نباید بیشتر از ۲۰۰۰ کاراکتر باشد");
  }

  if (form.iconType === "lucide" && !form.icon) {
    errors.icon = tr("انتخاب یک آیکون از فهرست الزامی است");
  }

  const order = Number(form.displayOrder);
  if (form.displayOrder === "" || form.displayOrder === null || !Number.isInteger(order)) {
    errors.displayOrder = tr("ترتیب نمایش باید یک عدد صحیح باشد");
  } else if (order < 0) {
    errors.displayOrder = tr("ترتیب نمایش نمی‌تواند منفی باشد");
  }

  if (form.slug && form.slug.trim().length > 150) {
    errors.slug = tr("نامک (slug) نباید بیشتر از ۱۵۰ کاراکتر باشد");
  }

  if (form.seoTitle && form.seoTitle.trim().length > 200) {
    errors.seoTitle = tr("عنوان سئو نباید بیشتر از ۲۰۰ کاراکتر باشد");
  }

  if (form.seoDescription && form.seoDescription.trim().length > 300) {
    errors.seoDescription = tr("توضیحات سئو نباید بیشتر از ۳۰۰ کاراکتر باشد");
  }

  return errors;
}

// مودال «تایید حذف بخش» — همان الگوی بصری LogoutConfirmModal (کلاس‌های logout-confirm-*
// اینجا دوباره استفاده می‌شوند تا ظاهر داشبورد یکدست بماند)
export function DeleteDepartmentModal({ department, deleting, onCancel, onConfirm }) {
  return (
    <GlobalModal
      isOpen={!!department}
      onClose={onCancel}
      size="sm"
      className="logout-confirm-modal"
      overlayClassName="logout-confirm-overlay"
      labelledBy="delete-department-title"
      closeOnOverlayClick={!deleting}
      closeOnEsc={!deleting}
      bare
    >
      {department && (
        <>
          <h3 id="delete-department-title">{tr("تایید حذف بخش")}</h3>
          <p>{tr("آیا از حذف بخش «{0}» مطمئن هستید؟ این عملیات قابل بازگشت نیست.", [department.name])}</p>
          <div className="modal-actions">
            <button type="button" className="btn btn-primary danger-solid" onClick={onConfirm} disabled={deleting}>
              {deleting ? tr("در حال حذف...") : tr("بله، حذف شود")}
            </button>
            <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={deleting}>{tr("انصراف")}</button>
          </div>
        </>
      )}
    </GlobalModal>
  );
}

export const DEPT_PAGE_SIZES = [6, 12, 24];
export const DEPT_SORTS = trc({
  "order-asc": { label: "ترتیب نمایش (صعودی)", key: "displayOrder", dir: 1 },
  "order-desc": { label: "ترتیب نمایش (نزولی)", key: "displayOrder", dir: -1 },
  "name-asc": { label: "نام (الف تا ی)", key: "name", dir: 1 },
  "name-desc": { label: "نام (ی تا الف)", key: "name", dir: -1 },
  "status": { label: "وضعیت (فعال‌ها اول)", key: "status", dir: 1 },
});

export const isOnWebsite = (d) => d.showOnWebsite === 1 || d.showOnWebsite === true;

export function DepartmentsPanel() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [webFilter, setWebFilter] = useState("");
  const [sort, setSort] = useState("order-asc");
  const [limit, setLimit] = useState(12);
  const [page, setPage] = useState(1);

  // همه‌ی بخش‌ها (بدون query param، بدون صفحه‌بندی) — منبع واحد برای آمار، جستجو، فیلتر، مرتب‌سازی و صفحه‌بندی.
  // فیلتر «نمایش در سایت» در بک‌اند وجود ندارد؛ چون تعداد بخش‌ها کم است، همه‌ی فیلترها سمت کلاینت و روی همین داده‌ی واقعی اعمال می‌شوند.
  const { items: all, loading, error, reload, setError } = useLoadable("/admin/departments", "departments");
  // داکتران (API موجود) فقط برای شمارش تعداد داکتر هر بخش؛ داده‌ی پرستاران در سیستم وجود ندارد و نمایش داده نمی‌شود
  const { items: doctors, reload: reloadDoctors } = useLoadable("/admin/doctors", "doctors");
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  const [form, setForm] = useState(emptyDepartmentForm);
  const [formErrors, setFormErrors] = useState({});
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formIconFile, setFormIconFile] = useState(null);
  const [formIconPreview, setFormIconPreview] = useState(null);
  // عکس کاور کارت (جدا از آیکون): فایل تازه‌ی انتخاب‌شده + پیش‌نمایش + درخواست حذف عکس کاور فعلی
  const [formCoverFile, setFormCoverFile] = useState(null);
  const [formCoverPreview, setFormCoverPreview] = useState(null);
  const [removeCoverRequested, setRemoveCoverRequested] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [uploadingId, setUploadingId] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [viewingId, setViewingId] = useState(null);
  const [deletingDepartment, setDeletingDepartment] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [menuId, setMenuId] = useState(null);
  // نوع آیکون بخش در لحظه‌ی شروع ویرایش — برای تشخیص تغییر نوع بدون انتخاب منبع تازه (رجوع کنید به submit)
  const originalIconTypeRef = useRef(null);
  const iconInputRef = useRef(null);
  const iconTargetRef = useRef(null);
  const fa = (n) => Number(n || 0).toLocaleString(numLocale());

  useEffect(() => setPage(1), [search, statusFilter, webFilter, sort, limit]);

  useEffect(() => {
    if (menuId === null) return undefined;
    const onDown = (e) => { if (isScrollbarClick(e)) return; if (!e.target.closest?.(".pm-menu-wrap, .pm-menu")) setMenuId(null); };
    const onKey = (e) => { if (e.key === "Escape") setMenuId(null); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); };
  }, [menuId]);

  const stats = useMemo(() => ({
    total: all.length,
    active: all.filter((d) => d.status === "active").length,
    inactive: all.filter((d) => d.status === "inactive").length,
    // همان شرط بخش «بخش‌های تخصصی ما» در سایت عمومی: فعال + نمایش در سایت
    onSite: all.filter((d) => d.status === "active" && isOnWebsite(d)).length,
  }), [all]);

  const doctorCounts = useMemo(() => {
    const map = new Map();
    doctors.forEach((doc) => {
      const key = String(doc.department || "").trim();
      if (key) map.set(key, (map.get(key) || 0) + 1);
    });
    return map;
  }, [doctors]);

  const filtered = useMemo(() => {
    const term = search.trim().toLowerCase();
    let rows = all.filter((d) => {
      if (term && !`${d.name || ""} ${d.description || ""} ${d.slug || ""}`.toLowerCase().includes(term)) return false;
      if (statusFilter && d.status !== statusFilter) return false;
      if (webFilter === "shown" && !isOnWebsite(d)) return false;
      if (webFilter === "hidden" && isOnWebsite(d)) return false;
      return true;
    });
    const { key, dir } = DEPT_SORTS[sort];
    rows = [...rows].sort((a, b) => {
      let r;
      if (key === "name") r = String(a.name || "").localeCompare(String(b.name || ""), "fa");
      else if (key === "status") r = String(a.status).localeCompare(String(b.status));
      else r = (Number(a.displayOrder) || 0) - (Number(b.displayOrder) || 0);
      return r * dir || String(a.name || "").localeCompare(String(b.name || ""), "fa");
    });
    return rows;
  }, [all, search, statusFilter, webFilter, sort]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / limit));
  const currentPage = Math.min(page, totalPages);
  const pageItems = filtered.slice((currentPage - 1) * limit, currentPage * limit);
  const pagination = { total: filtered.length, page: currentPage, limit, totalPages };
  const hasFilters = !!(search || statusFilter || webFilter);
  function clearFilters() { setSearch(""); setStatusFilter(""); setWebFilter(""); }

  const viewing = viewingId ? all.find((d) => d.id === viewingId) : null;
  useEffect(() => {
    if (viewingId && !loading && !viewing) setViewingId(null);
  }, [viewingId, loading, viewing]);

  function reloadAll() { reload(); reloadDoctors(); }

  function setField(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
    setFormErrors((errs) => (errs[key] ? { ...errs, [key]: undefined } : errs));
  }

  function clearIconFile() {
    setFormIconFile(null);
    setFormIconPreview((prev) => { if (prev) URL.revokeObjectURL(prev); return null; });
  }

  function handleFormIconChange(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const validationError = validateIconFile(file);
    if (validationError) {
      showToast(validationError, "error");
      return;
    }
    setFormIconFile(file);
    setFormIconPreview((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
  }

  function clearCoverFile() {
    setFormCoverFile(null);
    setFormCoverPreview((prev) => { if (prev) URL.revokeObjectURL(prev); return null; });
  }

  function handleFormCoverChange(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const validationError = validateCoverFile(file);
    if (validationError) {
      showToast(validationError, "error");
      return;
    }
    setRemoveCoverRequested(false);
    setFormCoverFile(file);
    setFormCoverPreview((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return URL.createObjectURL(file);
    });
  }

  function resetForm() {
    setForm(emptyDepartmentForm);
    clearCoverFile();
    setRemoveCoverRequested(false);
    setFormErrors({});
    setEditingId(null);
    originalIconTypeRef.current = null;
    clearIconFile();
  }
  function closeForm() { setFormOpen(false); resetForm(); }

  function openAdd() {
    resetForm();
    setViewingId(null);
    setFormOpen(true);
  }

  function edit(d) {
    setMenuId(null);
    setViewingId(null);
    setEditingId(d.id);
    originalIconTypeRef.current = d.iconType || "lucide";
    setFormErrors({});
    clearIconFile();
    clearCoverFile();
    setRemoveCoverRequested(false);
    setForm({
      name: d.name || "",
      nameEn: d.nameEn || "",
      description: d.description || "",
      descriptionEn: d.descriptionEn || "",
      iconType: d.iconType || "lucide",
      icon: d.iconType === "lucide" ? (d.icon || "") : "",
      slug: d.slug || "",
      displayOrder: d.displayOrder ?? 0,
      status: d.status || "active",
      showOnWebsite: isOnWebsite(d),
      seoTitle: d.seoTitle || "",
      seoDescription: d.seoDescription || "",
    });
    setFormOpen(true);
  }

  async function submit(e) {
    e.preventDefault();

    const errors = validateDepartmentForm(form);
    setFormErrors(errors);
    if (Object.keys(errors).length > 0) {
      showToast(tr("لطفاً خطاهای فرم را برطرف کنید"), "error");
      return;
    }

    setSubmitting(true);
    try {
      // اگر نوع آیکون از حالت اولیه (هنگام شروع ویرایش) عوض شده ولی هنوز منبع تازه‌ای (فایل آپلودی)
      // انتخاب نشده، مقدار قدیمی icon (ناسازگار با نوع تازه) صراحتاً پاک می‌شود
      const iconTypeChangedWithoutNewSource =
        form.iconType === "upload" && !formIconFile &&
        editingId && originalIconTypeRef.current && originalIconTypeRef.current !== "upload";

      const payload = {
        name: form.name.trim(),
        nameEn: form.nameEn.trim(),
        description: form.description,
        descriptionEn: form.descriptionEn,
        iconType: form.iconType,
        icon: form.iconType === "lucide" ? form.icon : (iconTypeChangedWithoutNewSource ? "" : undefined),
        slug: form.slug,
        displayOrder: form.displayOrder,
        status: form.status,
        showOnWebsite: form.showOnWebsite,
        seoTitle: form.seoTitle,
        seoDescription: form.seoDescription,
      };

      let department;
      if (editingId) {
        const res = await apiRequest(`/admin/departments/${editingId}`, { method: "PUT", body: payload });
        department = res.department;
      } else {
        const res = await apiRequest("/admin/departments", { method: "POST", body: payload });
        department = res.department;
      }

      // آیکون انتخاب‌شده در همین فرم، بلافاصله پس از ثبت/ویرایش بخش آپلود می‌شود
      if (formIconFile && department?.id) {
        const formData = new FormData();
        formData.append("icon", formIconFile);
        await apiUpload(`/admin/departments/${department.id}/icon`, formData);
      }

      // عکس کاور کارت: آپلود فایل تازه، یا حذف عکس فعلی (بازگشت به عکس پیش‌فرض تخصص)
      if (formCoverFile && department?.id) {
        const coverData = new FormData();
        coverData.append("cover", formCoverFile);
        await apiUpload(`/admin/departments/${department.id}/cover`, coverData);
      } else if (removeCoverRequested && editingId) {
        await apiRequest(`/admin/departments/${editingId}/cover`, { method: "DELETE" });
      }

      showToast(editingId ? tr("تغییرات بخش با موفقیت ذخیره شد") : tr("بخش جدید با موفقیت افزوده شد"), "success");
      closeForm();
      reloadAll();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setSubmitting(false);
    }
  }

  // تغییر سریع وضعیت/نمایش در سایت — به‌روزرسانی جزئی با همان PUT موجود (بک‌اند فقط فیلدهای ارسالی را عوض می‌کند)
  async function quickUpdate(d, patch, message) {
    setMenuId(null);
    setBusyId(d.id);
    try {
      await apiRequest(`/admin/departments/${d.id}`, { method: "PUT", body: patch });
      showToast(message, "success");
      reload();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyId(null);
    }
  }
  const toggleStatus = (d) => quickUpdate(d, { status: d.status === "active" ? "inactive" : "active" }, d.status === "active" ? tr("بخش «{0}» غیرفعال شد", [d.name]) : tr("بخش «{0}» فعال شد", [d.name]));
  const toggleWebsite = (d) => quickUpdate(d, { showOnWebsite: !isOnWebsite(d) }, isOnWebsite(d) ? tr("بخش از سایت اصلی پنهان شد") : tr("بخش در سایت اصلی نمایش داده می‌شود"));

  function pickIcon(departmentId) {
    setMenuId(null);
    iconTargetRef.current = departmentId;
    iconInputRef.current?.click();
  }

  async function handleIconUpload(e) {
    const departmentId = iconTargetRef.current;
    const file = e.target.files?.[0];
    e.target.value = ""; // امکان انتخاب دوباره همان فایل را فراهم می‌کند
    if (!file || !departmentId) return;

    const validationError = validateIconFile(file);
    if (validationError) {
      showToast(validationError, "error");
      return;
    }

    setUploadingId(departmentId);
    try {
      const formData = new FormData();
      formData.append("icon", file);
      await apiUpload(`/admin/departments/${departmentId}/icon`, formData);
      showToast(tr("آیکون بخش با موفقیت آپلود شد"), "success");
      reload();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setUploadingId(null);
    }
  }

  async function confirmDelete() {
    if (!deletingDepartment) return;
    setDeleting(true);
    try {
      await apiRequest(`/admin/departments/${deletingDepartment.id}`, { method: "DELETE" });
      if (editingId === deletingDepartment.id) closeForm();
      if (viewingId === deletingDepartment.id) setViewingId(null);
      showToast(tr("بخش «{0}» حذف شد", [deletingDepartment.name]), "success");
      setDeletingDepartment(null);
      reloadAll();
    } catch (err) {
      showToast(err.message, "error");
      setDeletingDepartment(null);
    } finally {
      setDeleting(false);
    }
  }

  const statCards = [
    { tone: "total", label: tr("کل بخش‌ها"), value: stats.total, Icon: Building2 },
    { tone: "active", label: tr("بخش‌های فعال"), value: stats.active, Icon: UserCheck },
    { tone: "inactive", label: tr("بخش‌های غیرفعال"), value: stats.inactive, Icon: UserX },
    { tone: "guest", label: tr("نمایش در سایت"), value: stats.onSite, Icon: Globe },
  ];
  const noDepartmentsAtAll = !loading && !error && all.length === 0;
  const editingRecord = editingId ? all.find((d) => d.id === editingId) : null;
  const hasUploadedCover = !!editingRecord?.coverImage && !removeCoverRequested;
  // پیش‌نمایش کاور در فرم: فایل تازه ← کاور آپلودی فعلی ← عکس پیش‌فرض تخصص (بر اساس نام فعلی فرم)
  const coverPreviewSrc = formCoverPreview
    || getDepartmentMeta({ id: editingId || 0, name: form.name, nameEn: form.nameEn, coverImage: removeCoverRequested ? null : editingRecord?.coverImage }).photo;
  const uploadedPreviewSrc = formIconPreview
    || (form.iconType === "upload" && editingId ? resolvePhotoUrl(all.find((d) => d.id === editingId)?.icon) : null);

  return (
    <div className="pm-page">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      <input ref={iconInputRef} type="file" accept="image/png,image/jpeg,image/svg+xml" hidden onChange={handleIconUpload} />

      <div className="pm-head">
        <div>
          <nav className="dm-breadcrumb" aria-label={tr("مسیر صفحه")}>
            <span>{tr("داشبورد")}</span><ChevronLeft size={13} aria-hidden="true" /><span aria-current="page">{tr("مدیریت بخش‌ها")}</span>
          </nav>
          <h2>{tr("مدیریت بخش‌ها")}</h2>
          <p>{tr("مدیریت، سازمان‌دهی و نظارت بر بخش‌های شفاخانه")}</p>
        </div>
        {/* خروجی PDF/Excel عمداً نیست: برای بخش‌ها در بک‌اند فعلی چنین قابلیتی وجود ندارد */}
        <div className="pm-head-actions">
          <button type="button" className="btn btn-primary btn-sm" onClick={openAdd}><Plus size={15} />{" "}{tr("افزودن بخش")}</button>
        </div>
      </div>

      <div className="pm-stats" aria-busy={loading}>
        {statCards.map(({ tone, label, value, Icon }) => (
          <div key={tone} className={`pm-stat dm-stat pm-tone-${tone}`}>
            <span className="pm-stat-icon"><Icon size={20} /></span>
            <span>
              {loading ? <span className="pm-skel dm-skel-num" /> : <span className="pm-stat-num">{fa(value)}</span>}
              <span className="pm-stat-label">{label}</span>
            </span>
          </div>
        ))}
      </div>

      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="pm-search">
            <Search size={16} />
            <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder={tr("جستجوی نام، توضیحات یا نامک (Slug)...")} aria-label={tr("جستجوی بخش‌ها")} />
          </div>
          <select className="pm-select dash-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={tr("فیلتر وضعیت")}>
            <option value="">{tr("وضعیت: همه")}</option>
            <option value="active">{tr("فعال")}</option>
            <option value="inactive">{tr("غیرفعال")}</option>
          </select>
          <select className="pm-select dash-select" value={webFilter} onChange={(e) => setWebFilter(e.target.value)} aria-label={tr("فیلتر نمایش در سایت")}>
            <option value="">{tr("نمایش در سایت: همه")}</option>
            <option value="shown">{tr("نمایش داده می‌شود")}</option>
            <option value="hidden">{tr("پنهان از سایت")}</option>
          </select>
          <select className="pm-select dash-select" value={sort} onChange={(e) => setSort(e.target.value)} aria-label={tr("مرتب‌سازی")}>
            {Object.entries(DEPT_SORTS).map(([k, v]) => (<option key={k} value={k}>{v.label}</option>))}
          </select>
          <select className="pm-select dash-select" value={limit} onChange={(e) => setLimit(Number(e.target.value))} aria-label={tr("تعداد نمایش در صفحه")}>
            {DEPT_PAGE_SIZES.map((n) => (<option key={n} value={n}>{tr("نمایش {0} مورد", [fa(n)])}</option>))}
          </select>
          {hasFilters && (
            <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={clearFilters}><X size={14} />{" "}{tr("پاک کردن فیلترها")}</button>
          )}
        </div>
      </div>

      {error && (
        <div className="pm-tablewrap">
          <div className="pm-state" role="alert">
            <strong>{tr("بارگذاری فهرست بخش‌ها انجام نشد")}</strong>
            {error}
            <div><button type="button" className="btn btn-ghost btn-sm" onClick={() => { setError(""); reloadAll(); }}>{tr("تلاش دوباره")}</button></div>
          </div>
        </div>
      )}

      {!error && loading && (
        <div className="dm-dept-grid" aria-busy="true">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="dm-dept-card">
              <div className="dm-skel-row"><span className="pm-skel dm-skel-avatar" style={{ borderRadius: 10 }} /><span className="pm-skel" style={{ width: "50%" }} /></div>
              <span className="pm-skel" style={{ width: "90%" }} />
              <span className="pm-skel" style={{ width: "65%" }} />
            </div>
          ))}
        </div>
      )}

      {noDepartmentsAtAll && (
        <div className="pm-tablewrap">
          <div className="pm-state">
            <Building2 size={34} aria-hidden="true" style={{ opacity: 0.55, marginBottom: 8 }} />
            <strong>{tr("هنوز بخشی ثبت نشده است")}</strong>{tr("برای شروع، اولین بخش شفاخانه را اضافه کنید.")}<div><button type="button" className="btn btn-primary btn-sm" onClick={openAdd}><Plus size={15} />{" "}{tr("افزودن اولین بخش")}</button></div>
          </div>
        </div>
      )}

      {!error && !loading && all.length > 0 && filtered.length === 0 && (
        <div className="pm-tablewrap">
          <div className="pm-state">
            <strong>{tr("هیچ بخشی با این مشخصات پیدا نشد.")}</strong>{tr("جستجو یا فیلترها را تغییر دهید.")}<div><button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button></div>
          </div>
        </div>
      )}

      {!error && !loading && pageItems.length > 0 && (
        <div className="dm-dept-grid">
          {pageItems.map((d, idx) => {
            const menuOpen = menuId === d.id;
            const docCount = doctorCounts.get(String(d.name || "").trim()) || 0;
            const busy = busyId === d.id || uploadingId === d.id;
            return (
              <article key={d.id} className={`dm-dept-card${d.status === "inactive" ? " is-inactive" : ""}`}>
                <DepartmentCoverStrip department={d} />
                <header className="dm-dept-top">
                  <DepartmentIconThumb department={d} />
                  <div className="dm-dept-title">
                    <h3>{d.name}</h3>
                    <span className="pm-sub dm-ltr" dir="ltr">/{d.slug || "—"}</span>
                  </div>
                  <span className={`pm-status ${d.status === "active" ? "is-active" : "is-inactive"}`}>{DEPARTMENT_STATUS_LABEL[d.status] || d.status}</span>
                </header>
                <p className="dm-dept-desc">{d.description || tr("توضیحاتی ثبت نشده است.")}</p>
                <div className="dm-dept-meta">
                  <span title={tr("تعداد داکتران این بخش")}>{tr("داکتران:")}{" "}<b className="pm-num">{fa(docCount)}</b></span>
                  <span>{tr("ترتیب:")}{" "}<b className="pm-num">{fa(d.displayOrder)}</b></span>
                  <span className={`dm-web ${isOnWebsite(d) ? "is-on" : "is-off"}`}>
                    {isOnWebsite(d) ? <Globe size={13} /> : <EyeOff size={13} />} {isOnWebsite(d) ? tr("نمایش در سایت") : tr("پنهان از سایت")}
                  </span>
                </div>
                <footer className="pm-actions dm-dept-actions">
                  <button type="button" className="pm-iconbtn" title={tr("مشاهده")} aria-label={tr("مشاهده {0}", [d.name])} onClick={() => setViewingId(d.id)}><Eye size={16} /></button>
                  <button type="button" className="pm-iconbtn" title={tr("ویرایش")} aria-label={tr("ویرایش {0}", [d.name])} onClick={() => edit(d)}><Pencil size={16} /></button>
                  <button type="button" className="pm-iconbtn dm-iconbtn-danger" title={tr("حذف")} aria-label={tr("حذف {0}", [d.name])} onClick={() => { setMenuId(null); setDeletingDepartment(d); }}><Trash2 size={16} /></button>
                  <div className="pm-menu-wrap">
                    <button type="button" className="pm-iconbtn" title={tr("گزینه‌های بیشتر")} aria-label={tr("گزینه‌های بیشتر برای {0}", [d.name])} aria-haspopup="menu" aria-expanded={menuOpen} disabled={busy} onClick={() => setMenuId(menuOpen ? null : d.id)}><MoreVertical size={16} /></button>
                    {menuOpen && (
                      <FloatingMenu onClose={() => setMenuId(null)}>
                        <button type="button" role="menuitem" onClick={() => toggleStatus(d)}><Power size={15} /> {d.status === "active" ? tr("غیرفعال کردن بخش") : tr("فعال کردن بخش")}</button>
                        <button type="button" role="menuitem" onClick={() => toggleWebsite(d)}>{isOnWebsite(d) ? <EyeOff size={15} /> : <Globe size={15} />} {isOnWebsite(d) ? tr("پنهان کردن از سایت") : tr("نمایش در سایت")}</button>
                        <button type="button" role="menuitem" onClick={() => pickIcon(d.id)}><Camera size={15} /> {uploadingId === d.id ? tr("در حال آپلود...") : tr("آپلود آیکون")}</button>
                      </FloatingMenu>
                    )}
                  </div>
                </footer>
              </article>
            );
          })}
        </div>
      )}

      {!error && !loading && filtered.length > 0 && (
        <div className="pm-tablewrap">
          <DoctorPager pagination={pagination} page={currentPage} onPageChange={setPage} fa={fa} noun={tr("بخش")} />
        </div>
      )}

      {/* ---------- پنل جزئیات (مودال وسط صفحه) ---------- */}
      <GlobalModal
        isOpen={!!viewing}
        onClose={() => setViewingId(null)}
        title={tr("جزئیات بخش")}
        size="sm"
        footer={viewing && (
          <>
            <button type="button" className="btn btn-primary" onClick={() => edit(viewing)}><Pencil size={14} />{" "}{tr("ویرایش بخش")}</button>
            <button type="button" className="btn btn-ghost danger" onClick={() => setDeletingDepartment(viewing)}><Trash2 size={14} />{" "}{tr("حذف بخش")}</button>
          </>
        )}
      >
        {viewing && (
          <div className="dm-view">
            <DepartmentCoverStrip department={viewing} className="dm-view-cover" />
            <div className="department-preview-card">
              <DepartmentIconThumb department={viewing} size={26} />
              <div className="department-preview-name">{viewing.name}</div>
              {viewing.description && <p className="department-preview-desc">{viewing.description}</p>}
            </div>

            <h4 className="dm-form-title">{tr("اطلاعات عمومی")}</h4>
            <dl className="dm-info dm-info-1">
              <div><dt>{tr("نام بخش")}</dt><dd>{viewing.name}</dd></div>
              <div><dt>{tr("توضیحات")}</dt><dd className="dm-plain">{viewing.description || "—"}</dd></div>
              <div><dt>{tr("عکس کاور کارت")}</dt><dd>{viewing.coverImage ? tr("آپلودی") : (getDepartmentMeta(viewing).photo ? tr("عکس پیش‌فرض تخصص") : tr("بدون عکس (طرح رنگی)"))}</dd></div>
              <div><dt>{tr("آیکون")}</dt><dd>{viewing.iconType === "upload" ? tr("آپلودی") : (viewing.icon ? `Lucide — ${viewing.icon}` : "—")}</dd></div>
              <div><dt>{tr("نامک (Slug)")}</dt><dd dir="ltr" className="dm-ltr">{viewing.slug || "—"}</dd></div>
              <div><dt>{tr("ترتیب نمایش")}</dt><dd className="pm-num">{fa(viewing.displayOrder)}</dd></div>
              <div><dt>{tr("تعداد داکتران")}</dt><dd className="pm-num">{fa(doctorCounts.get(String(viewing.name || "").trim()) || 0)}</dd></div>
              {viewing.createdAt && <div><dt>{tr("تاریخ ثبت")}</dt><dd>{fmtDate(viewing.createdAt)}</dd></div>}
            </dl>

            <h4 className="dm-form-title">{tr("وضعیت")}</h4>
            <div className="dm-status-rows">
              <div className="dm-status-row">
                <span className={`pm-status ${viewing.status === "active" ? "is-active" : "is-inactive"}`}>{DEPARTMENT_STATUS_LABEL[viewing.status] || viewing.status}</span>
                <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === viewing.id} onClick={() => toggleStatus(viewing)}><Power size={13} /> {viewing.status === "active" ? tr("غیرفعال کردن") : tr("فعال کردن")}</button>
              </div>
              <div className="dm-status-row">
                <span className={`dm-web ${isOnWebsite(viewing) ? "is-on" : "is-off"}`}>{isOnWebsite(viewing) ? <Globe size={14} /> : <EyeOff size={14} />} {isOnWebsite(viewing) ? tr("در سایت اصلی نمایش داده می‌شود") : tr("از سایت اصلی پنهان است")}</span>
                <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === viewing.id} onClick={() => toggleWebsite(viewing)}>{isOnWebsite(viewing) ? tr("پنهان کردن") : tr("نمایش در سایت")}</button>
              </div>
            </div>

            <h4 className="dm-form-title">{tr("اطلاعات سئو")}</h4>
            <dl className="dm-info dm-info-1">
              <div><dt>{tr("عنوان سئو")}</dt><dd className="dm-plain">{viewing.seoTitle || "—"}</dd></div>
              <div><dt>{tr("توضیحات سئو")}</dt><dd className="dm-plain">{viewing.seoDescription || "—"}</dd></div>
            </dl>
          </div>
        )}
      </GlobalModal>

      {/* ---------- فرم افزودن/ویرایش (مودال وسط صفحه) ---------- */}
      <GlobalModal
        isOpen={formOpen}
        onClose={() => !submitting && closeForm()}
        title={editingId ? tr("ویرایش بخش") : tr("افزودن بخش جدید")}
        size="lg"
        className="dm-form-modal"
        closeOnOverlayClick={false}
        footer={
          <>
            <button className="btn btn-primary" type="submit" form="dm-dept-form" disabled={submitting}>
              {submitting ? tr("در حال ذخیره...") : tr("ذخیره")}
            </button>
            <button className="btn btn-ghost" type="button" disabled={submitting} onClick={closeForm}>{tr("انصراف")}</button>
          </>
        }
      >
        <form id="dm-dept-form" className="login-form dm-form" onSubmit={submit} noValidate>
          <h4 className="dm-form-title">{tr("اطلاعات اصلی")}</h4>
          <div className="field">
            <label htmlFor="dd-name">{tr("نام بخش")}</label>
            <input id="dd-name" required value={form.name} onChange={(e) => setField("name", e.target.value)} />
            {formErrors.name && <p className="field-error">{formErrors.name}</p>}
          </div>
          <div className="field">
            <label htmlFor="dd-desc">{tr("توضیحات")}</label>
            <textarea id="dd-desc" rows={3} value={form.description} onChange={(e) => setField("description", e.target.value)} />
            {formErrors.description && <p className="field-error">{formErrors.description}</p>}
          </div>

          <h4 className="dm-form-title">{tr("نسخه‌ی انگلیسی (اختیاری)")}</h4>
          <div className="field">
            <label htmlFor="dd-name-en">Name</label>
            <input id="dd-name-en" dir="ltr" maxLength={100} value={form.nameEn} onChange={(e) => setField("nameEn", e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="dd-desc-en">Description</label>
            <textarea id="dd-desc-en" dir="ltr" rows={3} maxLength={2000} value={form.descriptionEn} onChange={(e) => setField("descriptionEn", e.target.value)} />
          </div>

          <h4 className="dm-form-title">{tr("عکس کاور کارت")}</h4>
          <div className="field">
            <label htmlFor="dd-cover">{tr("عکس بالای کارت در بخش «بخش‌های تخصصی ما» (JPG، PNG یا WEBP — حداکثر ۲ مگابایت — اندازه‌ی پیشنهادی ۱۲۸۰×۷۲۰، نسبت ۱۶:۹)")}</label>
            <div className="dm-cover-upload">
              <div className="dm-cover-preview">
                {coverPreviewSrc ? <img src={coverPreviewSrc} alt={tr("پیش‌نمایش عکس کاور")} /> : <span className="dm-cover-empty"><ImagePlus size={22} aria-hidden="true" /></span>}
              </div>
              <div className="dm-cover-actions">
                <FilePickerField id="dd-cover" accept="image/png,image/jpeg,image/webp" file={formCoverFile} onChange={handleFormCoverChange} />
                {(hasUploadedCover || formCoverFile) && (
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => { clearCoverFile(); if (hasUploadedCover) setRemoveCoverRequested(true); }}>
                    <Trash2 size={14} />{" "}{tr("حذف عکس کاور")}
                  </button>
                )}
                {removeCoverRequested && <p className="avatar-hint">{tr("عکس کاور بعد از ذخیره حذف می‌شود و عکس پیش‌فرض تخصص جایگزین آن خواهد شد.")}</p>}
                {!hasUploadedCover && !formCoverFile && !removeCoverRequested && <p className="avatar-hint">{tr("اگر عکسی انتخاب نشود، عکس پیش‌فرض تخصص (یا یک طرح رنگی) نمایش داده می‌شود.")}</p>}
              </div>
            </div>
          </div>

          <h4 className="dm-form-title">{tr("ظاهر بخش")}</h4>
          <div className="dm-seg" role="radiogroup" aria-label={tr("نوع آیکون")}>
            <button type="button" role="radio" aria-checked={form.iconType === "lucide"} className={form.iconType === "lucide" ? "is-active" : ""} onClick={() => { setField("iconType", "lucide"); clearIconFile(); }}>{tr("آیکون آماده")}</button>
            <button type="button" role="radio" aria-checked={form.iconType === "upload"} className={form.iconType === "upload" ? "is-active" : ""} onClick={() => setField("iconType", "upload")}>{tr("آپلود عکس/SVG")}</button>
          </div>
          {form.iconType === "lucide" ? (
            <div className="field">
              <label>{tr("انتخاب آیکون")}</label>
              <DepartmentIconPicker value={form.icon} onChange={(icon) => setField("icon", icon)} />
              {formErrors.icon && <p className="field-error">{formErrors.icon}</p>}
            </div>
          ) : (
            <div className="field">
              <label htmlFor="dd-icon">{tr("آیکون آپلودی (PNG، JPG یا SVG — حداکثر ۲ مگابایت)")}</label>
              <div className="dm-icon-upload">
                <span className="department-icon-thumb">
                  {uploadedPreviewSrc ? <img src={uploadedPreviewSrc} alt={tr("پیش‌نمایش آیکون")} /> : <span className="avatar-fallback">{form.name.trim().charAt(0) || "🏥"}</span>}
                </span>
                <FilePickerField id="dd-icon" accept="image/png,image/jpeg,image/svg+xml" file={formIconFile} onChange={handleFormIconChange} />
              </div>
            </div>
          )}

          <h4 className="dm-form-title">{tr("تنظیمات نمایش")}</h4>
          <div className="field">
            <label htmlFor="dd-slug">{tr("نامک (Slug، اختیاری)")}</label>
            <input id="dd-slug" dir="ltr" value={form.slug} onChange={(e) => setField("slug", e.target.value)} placeholder={tr("در صورت خالی بودن، خودکار از نام ساخته می‌شود")} />
            {formErrors.slug && <p className="field-error">{formErrors.slug}</p>}
          </div>
          <div className="field-row">
            <div className="field">
              <label htmlFor="dd-order">{tr("ترتیب نمایش")}</label>
              <input id="dd-order" type="number" value={form.displayOrder} onChange={(e) => setField("displayOrder", e.target.value === "" ? "" : Number(e.target.value))} />
              {formErrors.displayOrder && <p className="field-error">{formErrors.displayOrder}</p>}
            </div>
            <div className="field">
              <label htmlFor="dd-status">{tr("وضعیت")}</label>
              <select id="dd-status" value={form.status} onChange={(e) => setField("status", e.target.value)}>
                <option value="active">{tr("فعال")}</option>
                <option value="inactive">{tr("غیرفعال")}</option>
              </select>
            </div>
          </div>
          <label className="checkbox-row">
            <input type="checkbox" checked={form.showOnWebsite} onChange={(e) => setField("showOnWebsite", e.target.checked)} />{tr("نمایش در سایت اصلی (بخش «بخش‌های تخصصی ما»)")}</label>

          <h4 className="dm-form-title">{tr("سئو (SEO)")}</h4>
          <div className="field">
            <label htmlFor="dd-seot">{tr("عنوان سئو (اختیاری)")}</label>
            <input id="dd-seot" value={form.seoTitle} onChange={(e) => setField("seoTitle", e.target.value)} />
            <span className="dm-counter pm-num">{fa(form.seoTitle.length)} / {fa(200)}</span>
            {formErrors.seoTitle && <p className="field-error">{formErrors.seoTitle}</p>}
          </div>
          <div className="field">
            <label htmlFor="dd-seod">{tr("توضیحات سئو (اختیاری)")}</label>
            <textarea id="dd-seod" rows={2} value={form.seoDescription} onChange={(e) => setField("seoDescription", e.target.value)} />
            <span className="dm-counter pm-num">{fa(form.seoDescription.length)} / {fa(300)}</span>
            {formErrors.seoDescription && <p className="field-error">{formErrors.seoDescription}</p>}
          </div>
        </form>
      </GlobalModal>

      <DeleteDepartmentModal
        department={deletingDepartment}
        deleting={deleting}
        onCancel={() => (deleting ? null : setDeletingDepartment(null))}
        onConfirm={confirmDelete}
      />
    </div>
  );
}

// ---------- اخبار و اعلانات (News & Announcements) ----------
// رابط کاربری مدیریت اخبار به components/dashboard/NewsManagement.jsx منتقل شده است
// (همان endpointهای /admin/news؛ هیچ API یا مدل جدیدی ساخته نشده).

// برنامه‌های کاری داکتران: رابط کاربری در components/dashboard/WorkSchedulesManagement.jsx
// (همان endpointهای /admin/schedules؛ هیچ API یا مدل جدیدی ساخته نشده).

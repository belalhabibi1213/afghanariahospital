import { useEffect, useRef, useState } from "react";
import { X, Download, FileSpreadsheet, FileText, Users, UserCheck, UserX, ClipboardList, CalendarDays, Stethoscope } from "lucide-react";
import { BarChart, DonutChart } from "../../../components/dashboard/DashboardCharts.jsx";
import { PageHead, StatCards, StateBlock, SkeletonRows, Badge, fa as faNum } from "../../../components/admin/AdminPro.jsx";
import { apiRequest } from "../../../utils/api.js";
import { STATUS_COLOR, STATUS_LABEL, buildQueryString } from "./adminShared.jsx";

import { JalaliDateInput } from "../../../components/JalaliDateInput.jsx";
import { tr, curDir } from "../../../i18n/tr.js";
export function ReportsPanel() {
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [printMenuOpen, setPrintMenuOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const reportRef = useRef(null);

  // با تغییر بازه‌ی تاریخ، آمار/گزارش‌ها دوباره از سرور با همان فیلتر بارگذاری می‌شوند.
  // بدون از تاریخ/تا تاریخ، دقیقاً همان رفتار قبلی (همه‌ی داده‌ها) حفظ می‌شود.
  function reload() {
    setLoading(true);
    const qs = buildQueryString({ from: dateFrom, to: dateTo });
    apiRequest(`/admin/reports${qs}`)
      .then(setStats)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, [dateFrom, dateTo]);

  async function exportToPDF() {
    setPrintMenuOpen(false);
    if (!reportRef.current) return;
    setExporting(true);
    try {
      const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([
        import("html2canvas"),
        import("jspdf"),
      ]);
      const canvas = await html2canvas(reportRef.current, { scale: 2, backgroundColor: "#ffffff" });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pageWidth - 40;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 20;
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight - 40;
      while (heightLeft > 0) {
        position = heightLeft - imgHeight + 20;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
        heightLeft -= pageHeight - 40;
      }
      pdf.save(`reports-${dateFrom || "all"}-${dateTo || "all"}-${Date.now()}.pdf`);
    } catch (err) {
      setError(tr("خطا در ساخت فایل PDF"));
    } finally {
      setExporting(false);
    }
  }

  async function exportToExcel() {
    setPrintMenuOpen(false);
    if (!stats) return;
    setExporting(true);
    try {
      const { downloadXlsx } = await import("../../../utils/exportXlsx.js");
      const summaryRows = [
        { "شاخص": "بازه‌ی گزارش", "مقدار": dateFrom || dateTo ? `${dateFrom || "ابتدا"} تا ${dateTo || "اکنون"}` : "همه‌ی داده‌ها" },
        { "شاخص": "مجموع بیماران", "مقدار": stats.totalPatients },
        { "شاخص": "مجموع داکتران", "مقدار": stats.totalDoctors },
        { "شاخص": "مجموع نوبت‌ها", "مقدار": stats.totalAppointments },
        { "شاخص": "نوبت‌های امروز", "مقدار": stats.todayAppointments },
        { "شاخص": "نوبت‌های این ماه", "مقدار": stats.appointmentsThisMonth },
      ];
      const statusRows = (stats.appointmentsByStatus || []).map((s) => ({
        "وضعیت": STATUS_LABEL[s.status] || s.status,
        "تعداد": s.count,
      }));
      const monthlyRows = (stats.monthlyStats || []).map((m) => ({
        "ماه": m.label,
        "تعداد": m.count,
      }));
      await downloadXlsx(`reports-${dateFrom || "all"}-${dateTo || "all"}-${Date.now()}.xlsx`, [
        { name: "خلاصه", rows: summaryRows },
        { name: "وضعیت نوبت‌ها", rows: statusRows },
        { name: "روند ماهانه", rows: monthlyRows },
      ]);
    } catch (err) {
      setError(tr("خطا در ساخت فایل Excel"));
    } finally {
      setExporting(false);
    }
  }

  const pad = (n) => String(n).padStart(2, "0");
  const iso = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  // پیش‌تنظیم‌های بازه — فقط مقدار from/to را پر می‌کنند؛ همان پارامترهای فعلی بک‌اند
  function applyPreset(kind) {
    const now = new Date();
    if (kind === "today") { setDateFrom(iso(now)); setDateTo(iso(now)); return; }
    if (kind === "week") {
      const start = new Date(now); start.setDate(now.getDate() - ((now.getDay() + 1) % 7)); // شروع هفته: شنبه
      setDateFrom(iso(start)); setDateTo(iso(now)); return;
    }
    if (kind === "month") { setDateFrom(iso(new Date(now.getFullYear(), now.getMonth(), 1))); setDateTo(iso(now)); return; }
    setDateFrom(""); setDateTo("");
  }
  const rangeText = dateFrom || dateTo ? tr("{0} تا {1}", [dateFrom || tr("ابتدا"), dateTo || tr("اکنون")]) : tr("همه‌ی داده‌ها");

  const donutData = (stats?.appointmentsByStatus || []).map((s2) => ({
    label: STATUS_LABEL[s2.status] || s2.status,
    value: Number(s2.count) || 0,
    color: STATUS_COLOR[s2.status] || "#7f9aa0",
  }));
  const barData = (stats?.monthlyStats || []).map((m) => ({ label: m.label, count: Number(m.count) || 0 }));
  const completed = stats?.appointmentsByStatus?.find((x) => x.status === "completed")?.count;
  const cancelled = stats?.appointmentsByStatus?.find((x) => x.status === "cancelled")?.count;
  const kpis = [
    { key: "pat", tone: "total", label: tr("مجموع بیماران"), value: stats ? Number(stats.totalPatients) : undefined, Icon: Users },
    { key: "doc", tone: "active", label: tr("مجموع داکتران"), value: stats ? Number(stats.totalDoctors) : undefined, Icon: Stethoscope },
    { key: "apt", tone: "guest", label: tr("مجموع نوبت‌ها"), value: stats ? Number(stats.totalAppointments) : undefined, Icon: CalendarDays },
    { key: "today", tone: "inactive", label: tr("نوبت‌های امروز"), value: stats ? Number(stats.todayAppointments) : undefined, Icon: ClipboardList },
    { key: "month", tone: "total", label: tr("نوبت‌های این ماه"), value: stats ? Number(stats.appointmentsThisMonth) : undefined, Icon: CalendarDays },
    ...(completed !== undefined ? [{ key: "done", tone: "active", label: tr("نوبت‌های انجام‌شده"), value: Number(completed), Icon: UserCheck }] : []),
    ...(cancelled !== undefined ? [{ key: "canc", tone: "inactive", label: tr("نوبت‌های لغوشده"), value: Number(cancelled), Icon: UserX }] : []),
  ];
  const statusRows = stats?.appointmentsByStatus || [];
  const statusTotal = statusRows.reduce((sum, r) => sum + Number(r.count || 0), 0);

  return (
    <div className="pm-page">
      <PageHead title={tr("گزارش‌ها و آمار")} subtitle={tr("نمای مدیریتی از وضعیت بیماران، داکتران و نوبت‌ها بر اساس داده‌ی واقعی سیستم")} onRefresh={reload} refreshing={loading}>
        <div style={{ position: "relative" }}>
          <button type="button" className="btn btn-ghost btn-sm" aria-haspopup="menu" aria-expanded={printMenuOpen} disabled={exporting || !stats} onClick={() => setPrintMenuOpen((o) => !o)}>
            <Download size={14} /> {exporting ? tr("در حال آماده‌سازی...") : tr("خروجی")}
          </button>
          {printMenuOpen && (
            <div className="pm-menu" role="menu" style={{ top: "calc(100% + 6px)", left: 0 }}>
              <button type="button" role="menuitem" onClick={exportToPDF}><FileText size={15} />{" "}{tr("خروجی PDF")}</button>
              <button type="button" role="menuitem" onClick={exportToExcel}><FileSpreadsheet size={15} />{" "}{tr("خروجی Excel")}</button>
            </div>
          )}
        </div>
      </PageHead>

      {/* بازه‌ی تاریخ مخصوص همین پنل؛ پیش‌تنظیم‌ها فقط همین from/to را پر می‌کنند */}
      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="ap-presets" role="group" aria-label={tr("بازه‌های سریع")}>
            {[["today", tr("امروز")], ["week", tr("این هفته")], ["month", tr("این ماه")], ["all", tr("همه")]].map(([k, label]) => {
              const isAll = k === "all";
              return <button key={k} type="button" className={`btn btn-sm ${isAll && !dateFrom && !dateTo ? "btn-primary" : "btn-ghost"}`} onClick={() => applyPreset(k)}>{label}</button>;
            })}
          </div>
          <label className="ap-datefield"><span>{tr("از")}</span><JalaliDateInput value={dateFrom} max={dateTo || undefined} onChange={(e) => setDateFrom(e.target.value)} aria-label={tr("از تاریخ")} /></label>
          <label className="ap-datefield"><span>{tr("تا")}</span><JalaliDateInput value={dateTo} min={dateFrom || undefined} onChange={(e) => setDateTo(e.target.value)} aria-label={tr("تا تاریخ")} /></label>
          {(dateFrom || dateTo) && <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={() => applyPreset("all")}><X size={14} />{" "}{tr("پاک‌کردن بازه")}</button>}
        </div>
      </div>

      {error && !stats && <div className="pm-tablewrap"><StateBlock kind="error" title={tr("بارگذاری گزارش‌ها انجام نشد")} message={error} onRetry={() => { setError(""); reload(); }} /></div>}
      {error && stats && <div className="form-message error" role="alert">{error}</div>}
      {!stats && !error && <SkeletonRows rows={4} />}

      {stats && (
        <div ref={reportRef} dir={curDir()} className={`ap-report ${loading ? "is-busy" : ""}`}>
          <p className="ap-range">{tr("بازه‌ی گزارش:")}{" "}<strong>{rangeText}</strong>{loading && tr(" (در حال به‌روزرسانی...)")}</p>
          <StatCards items={kpis} columns={kpis.length > 5 ? 4 : 5} />

          <div className="chart-grid">
            <div className="chart-card">
              <h3>{tr("روند نوبت‌ها {0}", [(dateFrom || dateTo) ? tr("(بازه‌ی انتخاب‌شده)") : tr("(۶ ماه اخیر)")])}</h3>
              <BarChart data={barData} />
            </div>
            <div className="chart-card">
              <h3>{tr("توزیع وضعیت نوبت‌ها")}</h3>
              <DonutChart data={donutData} />
            </div>
          </div>

          <div className="pm-tablewrap ap-block">
            <div className="ap-block-head"><h3>{tr("وضعیت نوبت‌ها")}</h3><span className="pm-muted">{tr("{0} نوبت", [faNum(statusTotal)])}</span></div>
            {statusRows.length === 0
              ? <StateBlock title={tr("برای این بازه نوبتی ثبت نشده است.")} />
              : (
                <div className="ap-tablescroll">
                  <table className="pm-table">
                    <thead><tr><th>{tr("وضعیت")}</th><th>{tr("تعداد")}</th><th>{tr("سهم")}</th></tr></thead>
                    <tbody>
                      {statusRows.map((r) => (
                        <tr key={r.status}>
                          <td data-label={tr("وضعیت")}><Badge tone={r.status === "confirmed" ? "success" : r.status === "cancelled" ? "danger" : r.status === "completed" ? "info" : "warn"}>{STATUS_LABEL[r.status] || r.status}</Badge></td>
                          <td data-label={tr("تعداد")} className="ap-num-cell">{faNum(r.count)}</td>
                          <td data-label={tr("سهم")} className="ap-num-cell">{statusTotal ? tr("{0}٪", [faNum(Math.round((Number(r.count) / statusTotal) * 100))]) : "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
          </div>
        </div>
      )}
    </div>
  );
}

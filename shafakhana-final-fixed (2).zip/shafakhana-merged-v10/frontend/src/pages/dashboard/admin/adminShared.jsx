import { useEffect, useState } from "react";
import { apiRequest } from "../../../utils/api.js";

import { tr, trc } from "../../../i18n/tr.js";
export const STATUS_LABEL = trc({ pending: "در انتظار", confirmed: "تایید شده", completed: "انجام‌شده", cancelled: "لغوشده" });
// همان رنگ‌های کلاس‌های .status-pending / .status-confirmed / ... در index.css، برای هماهنگی بصری نمودار با جدول‌ها
export const STATUS_COLOR = { pending: "#ffc857", confirmed: "#2fe6c9", completed: "#78aaff", cancelled: "#ff8a7a" };

export function useLoadable(path, mapKey) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  function reload() {
    setLoading(true);
    apiRequest(path)
      .then((data) => setItems(data[mapKey] || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(reload, []);
  return { items, loading, error, reload, setError };
}

// تاخیر کوتاه قبل از ارسال درخواست جستجو، تا با هر ضربه کلید یک درخواست جدید به سرور نرود
// (جستجوی سریع و بهینه‌شده — کاهش تعداد درخواست‌های غیرضروری)
export function useDebouncedValue(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

export function buildQueryString(params) {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") usp.set(key, value);
  });
  const qs = usp.toString();
  return qs ? `?${qs}` : "";
}

// هوک عمومی برای بارگذاری لیستی که قابل جستجو/فیلتر و صفحه‌بندی است.
// filters: آبجکت کلید-مقدار که به صورت query string به سرور ارسال می‌شود
export function useSearchable(basePath, mapKey, filters, page, limit = 10) {
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const filtersKey = JSON.stringify(filters);

  function reload() {
    setLoading(true);
    const qs = buildQueryString({ ...filters, page, limit });
    apiRequest(`${basePath}${qs}`)
      .then((data) => {
        setItems(data[mapKey] || []);
        setPagination(data.pagination || null);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, [basePath, mapKey, filtersKey, page, limit]);
  return { items, pagination, loading, error, reload, setError };
}

// کنترل صفحه‌بندی مشترک (قبلی/بعدی + شماره صفحه)
export function Pagination({ pagination, page, onPageChange }) {
  if (!pagination || pagination.totalPages <= 1) return null;
  return (
    <div className="pagination-controls" style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 14 }}>
      <button
        type="button"
        className="btn btn-ghost btn-sm"
        disabled={page <= 1}
        onClick={() => onPageChange(page - 1)}
      >{tr("صفحه قبل")}</button>
      <span>{tr("صفحه {0} از {1} (مجموع {2} نتیجه)", [pagination.page, pagination.totalPages, pagination.total])}</span>
      <button
        type="button"
        className="btn btn-ghost btn-sm"
        disabled={page >= pagination.totalPages}
        onClick={() => onPageChange(page + 1)}
      >{tr("صفحه بعد")}</button>
    </div>
  );
}

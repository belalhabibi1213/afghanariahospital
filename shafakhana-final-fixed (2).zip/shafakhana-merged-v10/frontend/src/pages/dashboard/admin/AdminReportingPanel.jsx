import { useEffect, useMemo, useState } from "react";
import { Wallet, CircleDollarSign, Hourglass, RefreshCw, Search, X, FileSpreadsheet, FileText, Users, UserCheck, ClipboardList, CalendarDays, Stethoscope } from "lucide-react";
import { useDepartmentToasts, DepartmentToastContainer } from "../../../components/dashboard/DepartmentToast.jsx";
import { PageHead, StatCards, StateBlock, SkeletonRows, Badge, fa as faNum } from "../../../components/admin/AdminPro.jsx";
import { apiRequest, apiDownload } from "../../../utils/api.js";
import { STATUS_LABEL, useLoadable } from "./adminShared.jsx";

import { JalaliDateInput } from "../../../components/JalaliDateInput.jsx";
import { tr, trc, jdate } from "../../../i18n/tr.js";
// ---------- سیستم گزارش‌گیری (Reporting System) ----------
// چهار نوع گزارش (نوبت‌ها، بیماران، داکتران، درآمد) با فیلتر بازه‌ی تاریخ و خروجی PDF/Excel
export const REPORT_TYPES = trc([
  { key: "appointments", label: "گزارش نوبت‌ها", Icon: CalendarDays },
  { key: "patients", label: "گزارش بیماران", Icon: Users },
  { key: "doctors", label: "گزارش داکتران", Icon: Stethoscope },
  { key: "revenue", label: "گزارش درآمد", Icon: CircleDollarSign },
]);

export function money(n) {
  return Number(n || 0).toLocaleString("en-US", { maximumFractionDigits: 2 });
}

export function ReportingSystemPanel() {
  const [reportType, setReportType] = useState("appointments");
  const [filters, setFilters] = useState({ from: "", to: "", status: "", doctorId: "", department: "" });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [exporting, setExporting] = useState("");
  const [error, setError] = useState("");

  const { items: doctors } = useLoadable("/admin/doctors", "doctors");
  const { items: departments } = useLoadable("/admin/departments", "departments");
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  function buildQuery(extra = {}) {
    const params = new URLSearchParams();
    if (filters.from) params.set("from", filters.from);
    if (filters.to) params.set("to", filters.to);
    if (reportType === "appointments") {
      if (filters.status) params.set("status", filters.status);
      if (filters.doctorId) params.set("doctorId", filters.doctorId);
      if (filters.department) params.set("department", filters.department);
    }
    Object.entries(extra).forEach(([k, v]) => params.set(k, v));
    return params.toString();
  }

  async function generate() {
    setLoading(true);
    setError("");
    setResult(null);
    try {
      const data = await apiRequest(`/reports/${reportType}?${buildQuery()}`);
      setResult(data);
      showToast(tr("گزارش با موفقیت تولید شد."));
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  async function exportReport(format) {
    setExporting(format);
    setError("");
    try {
      await apiDownload(`/reports/${reportType}?${buildQuery({ format })}`, `${reportType}-report.${format === "pdf" ? "pdf" : "xlsx"}`);
      showToast(format === "pdf" ? tr("فایل PDF دانلود شد.") : tr("فایل Excel دانلود شد."));
    } catch (err) {
      setError(err.message);
      showToast(err.message || tr("خروجی گرفته نشد."), "error");
    } finally {
      setExporting("");
    }
  }

  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));
  const typeInfo = REPORT_TYPES.find((t) => t.key === reportType);
  const filterCount = [filters.from, filters.to, reportType === "appointments" ? filters.status : "", reportType === "appointments" ? filters.doctorId : "", reportType === "appointments" ? filters.department : ""].filter(Boolean).length;

  return (
    <div className="pm-page">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      <PageHead title={tr("سیستم گزارش‌گیری")} subtitle={tr("نوع گزارش را انتخاب کنید، فیلترها را تنظیم کنید و گزارش را تولید یا خروجی بگیرید")} />

      <section className="pm-tablewrap ap-step" aria-labelledby="ap-step1">
        <h3 id="ap-step1"><span className="ap-step-no">{tr("۱")}</span>{" "}{tr("نوع گزارش")}</h3>
        <div className="ap-typecards" role="radiogroup" aria-label={tr("نوع گزارش")}>
          {REPORT_TYPES.map((t) => (
            <button key={t.key} type="button" role="radio" aria-checked={reportType === t.key} className={`ap-typecard ${reportType === t.key ? "is-active" : ""}`}
              onClick={() => { setReportType(t.key); setResult(null); setError(""); }}>
              <t.Icon size={20} />
              <span>{t.label}</span>
            </button>
          ))}
        </div>
      </section>

      <section className="pm-tablewrap ap-step" aria-labelledby="ap-step2">
        <h3 id="ap-step2"><span className="ap-step-no">{tr("۲")}</span>{" "}{tr("فیلترها و بازه‌ی زمانی")}</h3>
        <div className="ap-filtergrid">
          <div className="field"><label htmlFor="rs-from">{tr("از تاریخ")}</label><JalaliDateInput id="rs-from" value={filters.from} max={filters.to || undefined} onChange={set("from")} /></div>
          <div className="field"><label htmlFor="rs-to">{tr("تا تاریخ")}</label><JalaliDateInput id="rs-to" value={filters.to} min={filters.from || undefined} onChange={set("to")} /></div>
          {reportType === "appointments" && (
            <>
              <div className="field"><label htmlFor="rs-status">{tr("وضعیت")}</label>
                <select id="rs-status" className="dash-select" value={filters.status} onChange={set("status")}>
                  <option value="">{tr("همه")}</option>
                  {Object.entries(STATUS_LABEL).map(([k, label]) => <option key={k} value={k}>{label}</option>)}
                </select>
              </div>
              <div className="field"><label htmlFor="rs-doc">{tr("داکتر")}</label>
                <select id="rs-doc" className="dash-select" value={filters.doctorId} onChange={set("doctorId")}>
                  <option value="">{tr("همه")}</option>
                  {doctors.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
                </select>
              </div>
              <div className="field"><label htmlFor="rs-dep">{tr("بخش")}</label>
                <select id="rs-dep" className="dash-select" value={filters.department} onChange={set("department")}>
                  <option value="">{tr("همه")}</option>
                  {departments.map((d) => <option key={d.id} value={d.name}>{d.name}</option>)}
                </select>
              </div>
            </>
          )}
        </div>
        {filterCount > 0 && (
          <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={() => setFilters({ from: "", to: "", status: "", doctorId: "", department: "" })}><X size={14} />{" "}{tr("پاک کردن فیلترها")}</button>
        )}
      </section>

      <section className="pm-tablewrap ap-step" aria-labelledby="ap-step3">
        <h3 id="ap-step3"><span className="ap-step-no">{tr("۳")}</span>{" "}{tr("تولید و خروجی")}</h3>
        <div className="ap-step-actions">
          <button className="btn btn-primary" type="button" onClick={generate} disabled={loading}>
            {loading ? <><RefreshCw size={14} className="ap-spin" />{" "}{tr("در حال تولید گزارش...")}</> : tr("تولید گزارش")}
          </button>
          <button className="btn btn-ghost" type="button" onClick={() => exportReport("pdf")} disabled={!!exporting || loading}>
            <FileText size={15} /> {exporting === "pdf" ? tr("در حال دانلود...") : tr("خروجی PDF")}
          </button>
          <button className="btn btn-ghost" type="button" onClick={() => exportReport("excel")} disabled={!!exporting || loading}>
            <FileSpreadsheet size={15} /> {exporting === "excel" ? tr("در حال دانلود...") : tr("خروجی Excel")}
          </button>
        </div>
      </section>

      {error && <div className="pm-tablewrap"><StateBlock kind="error" title={tr("انجام عملیات ممکن نشد")} message={error} onRetry={generate} /></div>}
      {loading && <SkeletonRows rows={4} />}
      {!loading && !error && !result && (
        <div className="pm-tablewrap"><StateBlock title={tr("«{0}» هنوز تولید نشده است", [typeInfo.label])} message={tr("پس از تنظیم فیلترها روی «تولید گزارش» بزنید.")} /></div>
      )}

      {result && reportType === "appointments" && <AppointmentReportView result={result} />}
      {result && reportType === "patients" && <PatientReportView result={result} />}
      {result && reportType === "doctors" && <DoctorReportView result={result} />}
      {result && reportType === "revenue" && <RevenueReportView result={result} />}
    </div>
  );
}

// جدول نتیجه‌ی گزارش: جستجو و صفحه‌بندی سمت کلاینت روی همان ردیف‌هایی که API برگردانده
export function ResultTable({ columns, rows, rowKey, noun = tr("رکورد") }) {
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const SIZE = 15;
  const term = q.trim().toLowerCase();
  const filtered = useMemo(() => (term
    ? rows.filter((r) => columns.some((c) => String(c.text ? c.text(r) : (c.render ? "" : r[c.key]) ?? "").toLowerCase().includes(term)))
    : rows), [rows, term, columns]);
  useEffect(() => setPage(1), [term]);
  const pages = Math.max(1, Math.ceil(filtered.length / SIZE));
  const cur = Math.min(page, pages);
  const slice = filtered.slice((cur - 1) * SIZE, cur * SIZE);
  return (
    <div className="pm-tablewrap ap-block">
      <div className="ap-block-head">
        <h3>{tr("جزئیات")}{" "}<span className="pm-muted">({faNum(filtered.length)} {noun})</span></h3>
        {rows.length > 0 && (
          <div className="pm-search ap-block-search"><Search size={15} /><input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={tr("جستجو در نتایج...")} aria-label={tr("جستجو در نتایج گزارش")} /></div>
        )}
      </div>
      {rows.length === 0 ? <StateBlock title={tr("برای این فیلتر نتیجه‌ای پیدا نشد.")} message={tr("بازه‌ی زمانی یا فیلترها را تغییر دهید.")} />
        : filtered.length === 0 ? <StateBlock title={tr("نتیجه‌ای با این عبارت پیدا نشد.")} />
        : (
          <>
            <div className="ap-tablescroll">
              <table className="pm-table">
                <thead><tr>{columns.map((c) => <th key={c.label}>{c.label}</th>)}</tr></thead>
                <tbody>
                  {slice.map((r) => (
                    <tr key={rowKey(r)}>{columns.map((c) => <td key={c.label} data-label={c.label} className={c.num ? "ap-num-cell" : undefined}>{c.render ? c.render(r) : (r[c.key] ?? "—")}</td>)}</tr>
                  ))}
                </tbody>
              </table>
            </div>
            {filtered.length > SIZE && (
              <nav className="pm-pager" aria-label={tr("صفحه‌بندی")}>
                <span>{tr("نمایش {0} تا {1} از {2} {3}", [faNum((cur - 1) * SIZE + 1), faNum(Math.min(cur * SIZE, filtered.length)), faNum(filtered.length), noun])}</span>
                <div className="pm-pages">
                  <button type="button" className="pm-page-btn" disabled={cur <= 1} onClick={() => setPage(cur - 1)} aria-label={tr("صفحه قبل")}>›</button>
                  <span className="pm-muted">{faNum(cur)} / {faNum(pages)}</span>
                  <button type="button" className="pm-page-btn" disabled={cur >= pages} onClick={() => setPage(cur + 1)} aria-label={tr("صفحه بعد")}>‹</button>
                </div>
              </nav>
            )}
          </>
        )}
    </div>
  );
}

// تاریخ شمسی برای جدول/خروجی گزارش‌ها (ورودی: ISO میلادی از API)
export const d10 = (v) => (v ? jdate(v, { latin: true }) : "—");

export function AppointmentReportView({ result }) {
  const { summary, rows } = result;
  const tone = { pending: "warn", confirmed: "success", completed: "info", cancelled: "danger" };
  const cards = [
    { key: "t", tone: "total", label: tr("مجموع نوبت‌ها"), value: Number(summary.total ?? rows.length), Icon: CalendarDays },
    ...(summary.byStatus || []).map((st) => ({ key: st.status, tone: st.status === "cancelled" ? "inactive" : st.status === "pending" ? "guest" : "active", label: STATUS_LABEL[st.status] || st.status, value: Number(st.count), Icon: ClipboardList })),
  ];
  const columns = [
    { label: tr("بیمار"), key: "patientName" }, { label: tr("داکتر"), key: "doctorName" }, { label: tr("بخش"), key: "department" },
    { label: tr("تاریخ"), render: (r) => d10(r.appointmentDate), text: (r) => d10(r.appointmentDate) },
    { label: tr("ساعت"), render: (r) => String(r.appointmentTime || "").slice(0, 5) || "—", text: (r) => String(r.appointmentTime || "") },
    { label: tr("وضعیت"), render: (r) => <Badge tone={tone[r.status] || "muted"}>{STATUS_LABEL[r.status] || r.status}</Badge>, text: (r) => STATUS_LABEL[r.status] || r.status },
  ];
  return <><StatCards items={cards} columns={Math.min(cards.length, 5)} /><ResultTable columns={columns} rows={rows} rowKey={(r) => r.id} noun={tr("نوبت")} /></>;
}

export function PatientReportView({ result }) {
  const { summary, rows } = result;
  const cards = [
    { key: "a", tone: "total", label: tr("تعداد کل بیماران"), value: Number(summary.totalPatients), Icon: Users },
    { key: "b", tone: "active", label: tr("تازه‌ثبت‌شده در این بازه"), value: Number(summary.newPatientsInRange), Icon: UserCheck },
  ];
  const columns = [
    { label: tr("نام بیمار"), key: "fullName" }, { label: tr("تماس"), key: "phone" },
    { label: tr("تاریخ ثبت‌نام"), render: (r) => d10(r.createdAt), text: (r) => d10(r.createdAt) },
    { label: tr("تعداد نوبت‌ها"), key: "appointmentCount", num: true },
    { label: tr("آخرین ویزیت"), render: (r) => d10(r.lastAppointmentDate), text: (r) => d10(r.lastAppointmentDate) },
  ];
  return <><StatCards items={cards} columns={2} /><ResultTable columns={columns} rows={rows} rowKey={(r) => r.id} noun={tr("بیمار")} /></>;
}

export function DoctorReportView({ result }) {
  const { summary, rows } = result;
  const cards = [
    { key: "a", tone: "total", label: tr("مجموع نوبت‌ها"), value: Number(summary.totalAppointments), Icon: CalendarDays },
    { key: "b", tone: "guest", label: tr("مجموع درآمد"), value: money(summary.totalRevenue), Icon: CircleDollarSign },
    { key: "c", tone: "active", label: tr("وصول‌شده"), value: money(summary.totalCollected), Icon: Wallet },
  ];
  const columns = [
    { label: tr("داکتر"), key: "fullName" }, { label: tr("بخش"), key: "department" },
    { label: tr("مجموع نوبت‌ها"), key: "totalAppointments", num: true }, { label: tr("تکمیل‌شده"), key: "completedAppointments", num: true },
    { label: tr("لغوشده"), key: "cancelledAppointments", num: true },
    { label: tr("درآمد"), render: (r) => money(r.revenue), text: (r) => money(r.revenue), num: true },
    { label: tr("وصول‌شده"), render: (r) => money(r.collectedRevenue), text: (r) => money(r.collectedRevenue), num: true },
  ];
  return <><StatCards items={cards} columns={3} /><ResultTable columns={columns} rows={rows} rowKey={(r) => r.id} noun={tr("داکتر")} /></>;
}

export function RevenueReportView({ result }) {
  const { summary, rows } = result;
  // مجموع مبلغ فاکتورهای صادرشده در بازه (بر اساس تاریخ صدور) — فاکتورهای لغوشده حساب نمی‌شوند
  const totalIssued = (summary.invoicesByStatus || [])
    .filter((x) => x.status !== "cancelled")
    .reduce((sum, x) => sum + Number(x.totalAmount || 0), 0);
  const cards = [
    { key: "i", tone: "total", label: tr("مجموع فاکتورهای صادرشده (بدون لغوشده)"), value: money(totalIssued), Icon: CircleDollarSign },
    { key: "a", tone: "active", label: tr("درآمد وصول‌شده (پرداخت‌های بازه)"), value: money(summary.totalCollected), Icon: Wallet },
    { key: "b", tone: "inactive", label: tr("مانده‌ی مطالبات (تا امروز)"), value: money(summary.totalOutstanding), Icon: Hourglass },
    ...(summary.byMethod || []).map((m) => ({ key: `m-${m.method}`, tone: "total", label: tr("روش: {0}", [m.method]), value: money(m.total), Icon: CircleDollarSign })),
  ];
  const columns = [
    { label: tr("شماره فاکتور"), render: (r) => <span dir="ltr">{r.invoiceNumber}</span>, text: (r) => r.invoiceNumber },
    { label: tr("بیمار"), key: "patientName" },
    { label: tr("مبلغ"), render: (r) => money(r.amount), text: (r) => money(r.amount), num: true },
    { label: tr("روش"), key: "method" },
    { label: tr("تاریخ پرداخت"), render: (r) => d10(r.paidAt), text: (r) => d10(r.paidAt) },
    { label: tr("مرجع"), render: (r) => r.reference || "-", text: (r) => r.reference || "" },
  ];
  return <><StatCards items={cards} columns={Math.min(cards.length, 4)} /><ResultTable columns={columns} rows={rows} rowKey={(r) => r.id} noun={tr("پرداخت")} /></>;
}

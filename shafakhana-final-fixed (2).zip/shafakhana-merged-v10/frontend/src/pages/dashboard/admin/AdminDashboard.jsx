import { lazy, Suspense } from "react";
import DashboardShell from "../../../components/dashboard/DashboardShell.jsx";
import SectionErrorBoundary from "../../../components/SectionErrorBoundary.jsx";
import useTabState from "../../../hooks/useTabState.js";
import { useLanguage } from "../../../context/LanguageContext.jsx";

import { tr, trc } from "../../../i18n/tr.js";
// هر پنل سنگین در فایل جدا و lazy بارگذاری می‌شود؛ فقط کد تبِ باز دانلود می‌شود.
const PatientsPanel = lazy(() => import("./AdminPatientsPanel.jsx").then((m) => ({ default: m.PatientsPanel })));
const DoctorsPanel = lazy(() => import("./AdminDoctorsPanel.jsx").then((m) => ({ default: m.DoctorsPanel })));
const DepartmentsPanel = lazy(() => import("./AdminDepartmentsPanel.jsx").then((m) => ({ default: m.DepartmentsPanel })));
const BillingPanel = lazy(() => import("./AdminBillingPanel.jsx").then((m) => ({ default: m.BillingPanel })));
const ReportsPanel = lazy(() => import("./AdminReportsPanel.jsx").then((m) => ({ default: m.ReportsPanel })));
const ReportingSystemPanel = lazy(() => import("./AdminReportingPanel.jsx").then((m) => ({ default: m.ReportingSystemPanel })));
const AppointmentsManagement = lazy(() => import("../../../components/dashboard/AppointmentsManagement.jsx"));
const MedicalSection = lazy(() => import("../../../components/dashboard/MedicalSection.jsx"));
const HeroPanel = lazy(() => import("./AdminHeroPanel.jsx").then((m) => ({ default: m.HeroPanel })));
const AboutPanel = lazy(() => import("./AdminAboutPanel.jsx").then((m) => ({ default: m.AboutPanel })));
const NewsManagement = lazy(() => import("../../../components/dashboard/NewsManagement.jsx"));
const WorkSchedulesManagement = lazy(() => import("../../../components/dashboard/WorkSchedulesManagement.jsx"));
const AdminGlobalSearch = lazy(() => import("../../../components/admin/AdminGlobalSearch.jsx"));
const AdminComments = lazy(() => import("../../../components/admin/AdminComments.jsx"));
const AdminAiChats = lazy(() => import("../../../components/admin/AdminAiChats.jsx"));
const AdminContactMessages = lazy(() => import("../../../components/admin/AdminContactMessages.jsx"));

// ترتیب تب‌ها بر اساس اهمیت/کاربرد: جستجو ← کار روزانه‌ی بیمارستان ← مالی و گزارش‌ها ← ارتباط با مردم ← مدیریت محتوای سایت
const TABS = trc([
  { key: "search", label: "جستجوی کلی", icon: "🔍" },
  { key: "patients", label: "مدیریت بیماران", icon: "🧑‍🤝‍🧑" },
  { key: "doctors", label: "مدیریت داکتران", icon: "🩺" },
  { key: "appointments", label: "مدیریت نوبت‌ها", icon: "📅" },
  { key: "schedules", label: "برنامه‌های کاری", icon: "🗓️" },
  { key: "prescriptions", label: "نسخه و سوابق طبی", icon: "💊" },
  { key: "billing", label: "صورت‌حساب و فاکتورها", icon: "🧾" },
  { key: "reports", label: "گزارش‌ها و آمار", icon: "📊" },
  { key: "reportingSystem", label: "سیستم گزارش‌گیری", icon: "📈" },
  { key: "contactMessages", label: "پیام‌های تماس با ما", icon: "✉️" },
  { key: "newsComments", label: "نظرات کاربران", icon: "💬" },
  { key: "aiChats", label: "گفتگوهای دستیار هوشمند", icon: "🤖" },
  { key: "news", label: "اخبار و اعلانات", icon: "📰" },
  { key: "departments", label: "مدیریت بخش‌ها", icon: "🏥" },
  { key: "hero", label: "مدیریت بخش اصلی (Hero)", icon: "🏠" },
  { key: "about", label: "مدیریت بخش معرفی", icon: "📝" },
]);

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useTabState("patients");
  const { lang } = useLanguage();
  // key={lang}: با تغییر زبان کل داشبورد دوباره ساخته می‌شود تا همه‌ی متن‌ها (حتی ثابت‌های بیرون از کامپوننت) به زبان جدید برگردند
  return (
    <DashboardShell key={lang} title={tr("داشبورد ادمین")} tabs={TABS} activeTab={activeTab} onTabChange={setActiveTab}>
      <SectionErrorBoundary key={activeTab} label={activeTab}>
      <Suspense fallback={<div className="pm-state" role="status">{tr("در حال بارگذاری...")}</div>}>
      {activeTab === "search" && <AdminGlobalSearch />}
      {activeTab === "patients" && <PatientsPanel />}
      {activeTab === "doctors" && <DoctorsPanel />}
      {activeTab === "appointments" && <AppointmentsManagement />}
      {activeTab === "prescriptions" && <MedicalSection role="admin" />}
      {activeTab === "departments" && <DepartmentsPanel />}
      {activeTab === "news" && <NewsManagement />}
      {activeTab === "hero" && <HeroPanel />}
      {activeTab === "about" && <AboutPanel />}
      {activeTab === "newsComments" && <AdminComments />}
      {activeTab === "contactMessages" && <AdminContactMessages />}
      {activeTab === "aiChats" && <AdminAiChats />}
      {activeTab === "schedules" && <WorkSchedulesManagement />}
      {activeTab === "billing" && <BillingPanel />}
      {activeTab === "reports" && <ReportsPanel />}
      {activeTab === "reportingSystem" && <ReportingSystemPanel />}
      </Suspense>
      </SectionErrorBoundary>
    </DashboardShell>
  );
}

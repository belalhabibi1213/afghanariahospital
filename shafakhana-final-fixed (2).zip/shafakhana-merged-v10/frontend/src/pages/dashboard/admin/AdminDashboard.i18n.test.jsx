import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, waitFor, cleanup, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AuthProvider } from "../../../context/AuthContext.jsx";
import { LanguageProvider } from "../../../context/LanguageContext.jsx";
import { SettingsProvider } from "../../../context/SettingsContext.jsx";
import { ThemeProvider } from "../../../context/ThemeContext.jsx";
import AdminDashboard from "./AdminDashboard.jsx";
import { LANG_STORAGE_KEY } from "../../../i18n/languages.js";
import { USER_KEY } from "../../../utils/api.js";
import enDict from "../../../i18n/dashboard/en.js";
import psDict from "../../../i18n/dashboard/ps.js";

// تست دود: داشبورد ادمین با زبان انگلیسی/پشتو نباید هیچ متن دری در رابط (منو، عنوان، دکمه) نشان بدهد.
const PERSIAN = /[\u0600-\u06FF]/;
const TABS = [
  "search", "patients", "doctors", "appointments", "prescriptions", "departments", "news",
  "about", "newsComments", "contactMessages", "aiChats", "schedules", "billing", "reports", "reportingSystem",
];

function visibleText(root) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const out = [];
  while (walker.nextNode()) {
    const el = walker.currentNode.parentElement;
    if (el && /^(SCRIPT|STYLE)$/.test(el.tagName)) continue;
    out.push(walker.currentNode.nodeValue);
  }
  root.querySelectorAll("[placeholder],[title],[aria-label]").forEach((el) => {
    ["placeholder", "title", "aria-label"].forEach((a) => el.getAttribute(a) && out.push(el.getAttribute(a)));
  });
  return out.join("\n");
}

describe.each(["en", "ps"])("داشبورد ادمین — زبان %s", (lang) => {
  beforeEach(() => {
    localStorage.setItem(LANG_STORAGE_KEY, lang);
    const user = { id: 1, fullName: "Admin", role: "admin" };
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    vi.stubGlobal("fetch", vi.fn().mockImplementation(async (url) => ({
      ok: true,
      status: 200,
      json: async () => (String(url).includes("/auth/") ? { user, csrfToken: "c" } : {}),
      clone() { return this; },
      headers: { get: () => "application/json" },
    })));
  });
  afterEach(() => { cleanup(); vi.unstubAllGlobals(); localStorage.clear(); });

  it.each(TABS)("تب %s متن دری ندارد", async (tab) => {
    const { container } = render(
      <MemoryRouter initialEntries={[`/dashboard/admin?tab=${tab}`]}>
        <LanguageProvider>
          <AuthProvider>
            <SettingsProvider>
              <ThemeProvider>
                <AdminDashboard />
              </ThemeProvider>
            </SettingsProvider>
          </AuthProvider>
        </LanguageProvider>
      </MemoryRouter>
    );
    await waitFor(() => expect(container.querySelector(".dash-shell")).toBeTruthy());
    // منتظر بارگذاری تنبل (lazy) و درخواست‌ها
    await waitFor(() => expect(screen.queryByRole("status", { name: "" })).toBeNull(), { timeout: 4000 }).catch(() => {});
    await new Promise((r) => setTimeout(r, 400));
    const text = visibleText(container);
    // نام شفاخانه یک تنظیم سایت (داده) است، نه متن رابط
    const lines = text.split("\n").map((l) => l.trim()).filter((l) => l && l !== "شفاخانه افغان آریا");
    // انگلیسی: هیچ حرف عربی/فارسی نباید دیده شود. پشتو (هم‌خط دری): هیچ خطی نباید دقیقاً همان کلید دری ترجمه‌نشده باشد.
    const persianLines = lang === "en"
      ? lines.filter((l) => PERSIAN.test(l))
      : lines.filter((l) => Object.prototype.hasOwnProperty.call(enDict, l) && psDict[l] !== l);
    expect(persianLines).toEqual([]);
  });
});

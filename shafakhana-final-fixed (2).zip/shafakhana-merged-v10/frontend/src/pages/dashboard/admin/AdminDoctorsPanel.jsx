import { useEffect, useMemo, useRef, useState } from "react";
import { Search, X, Eye, FileSpreadsheet, FileText, Trash2, Pencil, MoreVertical, Users, CalendarDays, Plus, ChevronLeft, ArrowRight, Camera, Stethoscope, Briefcase } from "lucide-react";
import GlobalModal from "../../../components/GlobalModal.jsx";
import { useDepartmentToasts, DepartmentToastContainer } from "../../../components/dashboard/DepartmentToast.jsx";
import { apiRequest, apiUpload, apiDownload, resolvePhotoUrl } from "../../../utils/api.js";
import { buildQueryString, useDebouncedValue, useLoadable, useSearchable } from "./adminShared.jsx";
import { fmtDate } from "./AdminPatientsPanel.jsx";
import { isScrollbarClick } from "../../../utils/scrollbarClick.js";
import FloatingMenu from "../../../components/dashboard/FloatingMenu.jsx";
import FilePickerField from "../../../components/dashboard/FilePickerField.jsx";

import { tr, trc, numLocale, tdigits } from "../../../i18n/tr.js";
// ---------- داکتران ----------
// روزهای هفته — هم در این بخش (چک‌باکس روزهای کاری) و هم در برنامه‌های کاری (SchedulesPanel) استفاده می‌شود
export const WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
// نمایش روزهای کاری ذخیره‌شده (رشته‌ی دری جداشده با «،») به زبان فعلی؛ مقدار ذخیره‌شده تغییر نمی‌کند
const showWorkDays = (value) => parseWorkDaysList(value).map((d) => tr(d)).join(tr("، "));

export const emptyDoctor = {
  doctorCode: "", fullName: "", department: "", yearsExperience: 0, gender: "men", rating: 5, workDaysList: [],
};

export const ALLOWED_PHOTO_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const MAX_PHOTO_SIZE = 2 * 1024 * 1024; // ۲ مگابایت

// بررسی سمت کلاینت فرمت و حجم عکس، پیش از ارسال به سرور (اعتبارسنجی نهایی همچنان در بک‌اند انجام می‌شود)
export function validatePhotoFile(file) {
  if (!ALLOWED_PHOTO_TYPES.includes(file.type)) {
    return tr("فرمت عکس مجاز نیست. فقط JPG، PNG یا WEBP مجاز است.");
  }
  if (file.size > MAX_PHOTO_SIZE) {
    return tr("حجم عکس نباید بیشتر از ۲ مگابایت باشد.");
  }
  return null;
}

// رشته‌ی ذخیره‌شده در دیتابیس (مثل "شنبه، یکشنبه") را به آرایه تبدیل می‌کند
export function parseWorkDaysList(value) {
  if (!value) return [];
  return String(value).split(/[,،]/).map((d) => d.trim()).filter(Boolean);
}

// نمایش ستاره‌های امتیاز داکتر در جدول (همان الگوی کامپوننت Stars در صفحه عمومی داکتران)
export function Stars({ rating }) {
  const full = Math.round(Number(rating) || 0);
  return (
    <span className="stars" aria-hidden="true">
      {"★".repeat(Math.max(0, Math.min(5, full)))}
      {"☆".repeat(Math.max(0, 5 - full))}
    </span>
  );
}

// انتخاب‌گر امتیاز ۱ تا ۵ ستاره (به‌جای ورودی متنی/عددی ساده) — برای فرم افزودن/ویرایش داکتر
export function StarPicker({ value, onChange }) {
  return (
    <div className="star-picker" role="radiogroup" aria-label={tr("امتیاز داکتر")}>
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          className={`star-picker-btn${n <= value ? " active" : ""}`}
          onClick={() => onChange(n)}
          aria-pressed={n <= value}
          aria-label={tr("{0} ستاره", [n])}
        >
          ★
        </button>
      ))}
    </div>
  );
}

// انتخاب یک، چند یا هر هفت روز هفته به‌صورت چک‌باکس (به‌جای ورودی متنی آزاد)
export function WorkDaysPicker({ value, onChange }) {
  function toggleDay(day) {
    const exists = value.includes(day);
    onChange(exists ? value.filter((d) => d !== day) : [...value, day]);
  }
  return (
    <div className="workdays-picker">
      {WEEKDAYS.map((day) => (
        <label key={day} className="checkbox-row workday-checkbox">
          <input type="checkbox" checked={value.includes(day)} onChange={() => toggleDay(day)} />
          {tr(day)}
        </label>
      ))}
    </div>
  );
}

// ارقام لاتین را به ارقام فارسی تبدیل می‌کند (برای ساعت‌ها و متن‌های ترکیبی)
export function faDigits(value) {
  return tdigits(String(value ?? ""));
}

// ساعت دیتابیس («08:00:00») را به «۰۸:۰۰» تبدیل می‌کند
export function fmtTime(value) {
  return value ? faDigits(String(value).slice(0, 5)) : "";
}

export const DOCTOR_GENDER_LABEL = trc({ men: "آقا", women: "خانم" });
export const DOCTOR_PAGE_SIZES = [10, 25, 50];

export function DoctorAvatar({ doctor, size = "sm" }) {
  const photoSrc = resolvePhotoUrl(doctor.photoUrl);
  return (
    <div className={`doctor-thumb${size === "xl" ? " dm-avatar-xl" : ""}`}>
      {photoSrc ? <img src={photoSrc} alt="" /> : <span className="avatar-fallback">{doctor.fullName?.charAt(0) || "🩺"}</span>}
    </div>
  );
}

export function DoctorsPanel() {
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [genderFilter, setGenderFilter] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [limit, setLimit] = useState(10);
  const [page, setPage] = useState(1);
  const debouncedSpecialty = useDebouncedValue(specialty);
  const { items: departmentOptions } = useLoadable("/admin/departments", "departments");
  // کل داکتران (بدون query param، بدون صفحه‌بندی) برای کارت‌های آمار و صفحه‌ی پروفایل،
  // و برنامه‌های کاری ثبت‌شده برای «برنامه کاری هفته» — هر دو از APIهای موجود
  const { items: allDoctors, loading: allLoading, reload: reloadAllDoctors } = useLoadable("/admin/doctors", "doctors");
  const { items: schedules, loading: schedulesLoading, reload: reloadSchedules } = useLoadable("/admin/schedules", "schedules");
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  useEffect(() => setPage(1), [departmentFilter, genderFilter, debouncedSpecialty, limit]);

  const { items, pagination, loading, error, reload: reloadList, setError } = useSearchable(
    "/admin/doctors",
    "doctors",
    { department: departmentFilter, gender: genderFilter, specialty: debouncedSpecialty },
    page,
    limit
  );
  const [form, setForm] = useState(emptyDoctor);
  const [editingId, setEditingId] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [formError, setFormError] = useState("");
  const [uploadingId, setUploadingId] = useState(null);
  // عکس انتخاب‌شده در فرم افزودن/ویرایش (تا زمان ثبت، بخشی از JSON فرم نیست چون فایل است)
  const [formPhotoFile, setFormPhotoFile] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [printBusy, setPrintBusy] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const [menuId, setMenuId] = useState(null);
  const [detail, setDetail] = useState(null); // { id, tab }
  const photoInputRef = useRef(null);
  const photoTargetRef = useRef(null);

  // منوی ⋮ ردیف — فقط یک منو در هر لحظه باز است؛ با کلیک بیرون یا Esc بسته می‌شود
  useEffect(() => {
    if (menuId === null) return undefined;
    const onDown = (e) => { if (isScrollbarClick(e)) return; if (!e.target.closest?.(".pm-menu-wrap, .pm-menu")) setMenuId(null); };
    const onKey = (e) => { if (e.key === "Escape") setMenuId(null); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => { document.removeEventListener("mousedown", onDown); document.removeEventListener("keydown", onKey); };
  }, [menuId]);

  const fa = (n) => Number(n || 0).toLocaleString(numLocale());

  // آمار کارت‌ها — کاملاً از داده‌ی واقعی (بدون مقدار ثابت)
  const stats = useMemo(() => {
    const total = allDoctors.length;
    const specialties = new Set(allDoctors.map((d) => String(d.department || "").trim()).filter(Boolean)).size;
    const avgYears = total ? allDoctors.reduce((s, d) => s + (Number(d.yearsExperience) || 0), 0) / total : 0;
    const scheduledIds = new Set(schedules.map((s) => Number(s.doctorId)));
    const withSchedule = allDoctors.filter((d) => scheduledIds.has(Number(d.id))).length;
    return { total, specialties, avgYears: Math.round(avgYears * 10) / 10, withSchedule };
  }, [allDoctors, schedules]);

  function reloadAux() {
    reloadAllDoctors();
    reloadSchedules();
  }
  function reload() {
    reloadList();
    reloadAux();
  }

  const activeFilterCount = [departmentFilter, genderFilter].filter(Boolean).length + (specialty ? 1 : 0);
  const hasFilters = activeFilterCount > 0;
  function clearFilters() {
    setDepartmentFilter(""); setGenderFilter(""); setSpecialty("");
  }

  // چاپ/خروجی فهرست داکتران (PDF یا Excel) — همان فیلتر بخش/جستجوی جاری پنل
  async function exportDoctors(format) {
    setPrintBusy(format);
    try {
      const qs = buildQueryString({ format, department: departmentFilter, gender: genderFilter, specialty: debouncedSpecialty });
      const ext = format === "excel" ? "xlsx" : "pdf";
      await apiDownload(`/admin/doctors/export${qs}`, `doctors-list.${ext}`, format === "pdf" ? { openInNewTab: true } : undefined);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setPrintBusy(null);
    }
  }

  function pickPhoto(doctorId) {
    photoTargetRef.current = doctorId;
    photoInputRef.current?.click();
  }

  async function handlePhotoUpload(e) {
    const doctorId = photoTargetRef.current;
    const file = e.target.files?.[0];
    e.target.value = ""; // امکان انتخاب دوباره همان فایل را فراهم می‌کند
    if (!file || !doctorId) return;

    const validationError = validatePhotoFile(file);
    if (validationError) {
      showToast(validationError, "error");
      return;
    }

    setUploadingId(doctorId);
    try {
      const formData = new FormData();
      formData.append("photo", file);
      await apiUpload(`/admin/doctors/${doctorId}/photo`, formData);
      showToast(tr("عکس داکتر به‌روزرسانی شد"), "success");
      reload();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setUploadingId(null);
    }
  }

  function handleFormPhotoChange(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const validationError = validatePhotoFile(file);
    if (validationError) {
      setFormError(validationError);
      return;
    }
    setFormError("");
    setFormPhotoFile(file);
  }

  async function submit(e) {
    e.preventDefault();
    setSubmitting(true);
    setFormError("");
    try {
      const payload = {
        doctorCode: editingId ? form.doctorCode.trim() : "", // در افزودن، شناسه‌ی بعدی را سرور خودکار می‌سازد
        fullName: form.fullName,
        department: form.department,
        yearsExperience: form.yearsExperience,
        gender: form.gender,
        rating: form.rating,
        workDays: form.workDaysList.join("، "), // مقدار ذخیره‌شده در دیتابیس؛ همیشه دری
      };

      let doctor;
      if (editingId) {
        const res = await apiRequest(`/admin/doctors/${editingId}`, { method: "PUT", body: payload });
        doctor = res.doctor;
      } else {
        const res = await apiRequest("/admin/doctors", { method: "POST", body: payload });
        doctor = res.doctor;
      }

      // اگر عکسی در همین فرم انتخاب شده، بلافاصله پس از ثبت/ویرایش داکتر آپلود می‌شود
      // (برای داکتر تازه‌ساخته‌شده، شناسه‌ی داکتر تازه از پاسخ سرور در دسترس است)
      if (formPhotoFile && doctor?.id) {
        const formData = new FormData();
        formData.append("photo", formPhotoFile);
        await apiUpload(`/admin/doctors/${doctor.id}/photo`, formData);
      }

      showToast(editingId ? tr("اطلاعات داکتر ذخیره شد") : tr("داکتر جدید افزوده شد"), "success");
      closeForm();
      reload();
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  function openAdd() {
    setEditingId(null);
    setForm(emptyDoctor);
    // شناسه‌ی بعدی (مثلاً DR-1010) فقط برای نمایش؛ مقدار نهایی را سرور هنگام ثبت می‌دهد
    apiRequest("/admin/doctors/next-code")
      .then((r) => setForm((f) => (f.doctorCode ? f : { ...f, doctorCode: r.doctorCode || "" })))
      .catch(() => {});
    setFormPhotoFile(null);
    setFormError("");
    setFormOpen(true);
  }

  function edit(doc) {
    setMenuId(null);
    setEditingId(doc.id);
    setFormPhotoFile(null);
    setFormError("");
    setForm({
      doctorCode: doc.doctorCode || "",
      fullName: doc.fullName,
      department: doc.department,
      yearsExperience: doc.yearsExperience,
      gender: doc.gender,
      rating: doc.rating != null ? Math.round(Number(doc.rating)) : 5,
      workDaysList: parseWorkDaysList(doc.workDays),
    });
    setFormOpen(true);
  }

  function closeForm() {
    setFormOpen(false);
    setEditingId(null);
    setForm(emptyDoctor);
    setFormPhotoFile(null);
    setFormError("");
  }

  async function confirmRemove() {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiRequest(`/admin/doctors/${deleteTarget.id}`, { method: "DELETE" });
      showToast(tr("داکتر حذف شد"), "success");
      if (detail?.id === deleteTarget.id) setDetail(null);
      setDeleteTarget(null);
      // اگر آخرین ردیف یک صفحه‌ی بعد از اول حذف شد، به صفحه‌ی قبل برمی‌گردیم (تغییر page خودش دوباره بارگذاری می‌کند)
      if (items.length === 1 && page > 1) {
        setPage(page - 1);
        reloadAux();
      } else {
        reload();
      }
    } catch (err) {
      setDeleteTarget(null);
      showToast(err.message, "error");
    } finally {
      setDeleting(false);
    }
  }

  const detailDoctor = detail ? allDoctors.find((d) => d.id === detail.id) : null;
  // اگر داکترِ در حال مشاهده دیگر وجود نداشت (مثلاً حذف شد)، به فهرست برمی‌گردیم
  useEffect(() => {
    if (detail && !allLoading && !detailDoctor) setDetail(null);
  }, [detail, allLoading, detailDoctor]);

  const statCards = [
    { tone: "total", label: tr("کل داکتران"), value: fa(stats.total), Icon: Users },
    { tone: "active", label: tr("دارای برنامه کاری"), value: fa(stats.withSchedule), Icon: CalendarDays },
    { tone: "guest", label: tr("تعداد تخصص‌ها"), value: fa(stats.specialties), Icon: Stethoscope },
    { tone: "inactive", label: tr("میانگین سابقه کاری (سال)"), value: stats.avgYears.toLocaleString(numLocale()), Icon: Briefcase },
  ];
  const statsLoading = allLoading || schedulesLoading;
  const firstIdx = pagination ? (pagination.page - 1) * pagination.limit : 0;
  const noDoctorsAtAll = !error && !loading && items.length === 0 && !hasFilters && stats.total === 0 && !allLoading;

  const listView = (
    <div className="pm-page">
      <div className="pm-head">
        <div>
          <nav className="dm-breadcrumb" aria-label={tr("مسیر صفحه")}>
            <span>{tr("داشبورد")}</span><ChevronLeft size={13} aria-hidden="true" /><span aria-current="page">{tr("مدیریت داکتران")}</span>
          </nav>
          <h2>{tr("مدیریت داکتران")}</h2>
          <p>{tr("مشاهده، ویرایش و مدیریت اطلاعات داکتران شفاخانه")}</p>
        </div>
        {/* خروجی PDF/Excel: همان exportDoctors قبلی و همان فیلترهای جاری */}
        <div className="pm-head-actions">
          <button type="button" className="btn btn-primary btn-sm" onClick={openAdd}><Plus size={15} />{" "}{tr("افزودن داکتر")}</button>
          <button type="button" className="btn btn-ghost btn-sm" disabled={printBusy !== null} onClick={() => exportDoctors("pdf")}>
            <FileText size={14} /> {printBusy === "pdf" ? tr("در حال آماده‌سازی...") : tr("خروجی PDF")}
          </button>
          <button type="button" className="btn btn-ghost btn-sm" disabled={printBusy !== null} onClick={() => exportDoctors("excel")}>
            <FileSpreadsheet size={14} /> {printBusy === "excel" ? tr("در حال آماده‌سازی...") : tr("خروجی Excel")}
          </button>
        </div>
      </div>

      <div className="pm-stats" aria-busy={statsLoading}>
        {statCards.map(({ tone, label, value, Icon }) => (
          <div key={tone} className={`pm-stat dm-stat pm-tone-${tone}`}>
            <span className="pm-stat-icon"><Icon size={20} /></span>
            <span>
              {statsLoading ? <span className="pm-skel dm-skel-num" /> : <span className="pm-stat-num">{value}</span>}
              <span className="pm-stat-label">{label}</span>
            </span>
          </div>
        ))}
      </div>

      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="pm-search">
            <Search size={16} />
            <input
              type="search"
              value={specialty}
              onChange={(e) => setSpecialty(e.target.value)}
              placeholder={tr("جستجوی نام، کد داکتر یا تخصص...")}
              aria-label={tr("جستجوی داکتران")}
            />
          </div>
          <select className="pm-select dash-select" value={departmentFilter} onChange={(e) => setDepartmentFilter(e.target.value)} aria-label={tr("فیلتر بخش")}>
            <option value="">{tr("بخش: همه")}</option>
            {departmentOptions.map((dep) => (
              <option key={dep.id} value={dep.name}>{dep.name}</option>
            ))}
          </select>
          <select className="pm-select dash-select" value={genderFilter} onChange={(e) => setGenderFilter(e.target.value)} aria-label={tr("فیلتر جنسیت")}>
            <option value="">{tr("جنسیت: همه")}</option>
            <option value="men">{tr("آقا")}</option>
            <option value="women">{tr("خانم")}</option>
          </select>
          <select className="pm-select dash-select" value={limit} onChange={(e) => setLimit(Number(e.target.value))} aria-label={tr("تعداد نمایش در صفحه")}>
            {DOCTOR_PAGE_SIZES.map((n) => (<option key={n} value={n}>{tr("نمایش {0} مورد", [fa(n)])}</option>))}
          </select>
          {hasFilters && (
            <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={clearFilters}>
              <X size={14} />{" "}{tr("پاک کردن فیلترها")}</button>
          )}
        </div>
      </div>

      <div className="pm-tablewrap">
        {error && (
          <div className="pm-state" role="alert">
            <strong>{tr("بارگذاری فهرست داکتران انجام نشد")}</strong>
            {error}
            <div><button type="button" className="btn btn-ghost btn-sm" onClick={() => { setError(""); reload(); }}>{tr("تلاش دوباره")}</button></div>
          </div>
        )}

        {!error && loading && items.length === 0 && (
          <table className="pm-table" aria-busy="true">
            <tbody>
              {Array.from({ length: 6 }).map((_, i) => (
                <tr key={i}>
                  <td colSpan={7}>
                    <div className="dm-skel-row">
                      <span className="pm-skel dm-skel-avatar" />
                      <span className="pm-skel" style={{ width: `${40 + ((i * 13) % 35)}%` }} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}

        {noDoctorsAtAll && (
          <div className="pm-state">
            <Stethoscope size={34} aria-hidden="true" style={{ opacity: 0.55, marginBottom: 8 }} />
            <strong>{tr("هنوز داکتری ثبت نشده است")}</strong>{tr("برای شروع، اولین داکتر شفاخانه را اضافه کنید.")}<div><button type="button" className="btn btn-primary btn-sm" onClick={openAdd}><Plus size={15} />{" "}{tr("افزودن اولین داکتر")}</button></div>
          </div>
        )}

        {!error && !loading && items.length === 0 && !noDoctorsAtAll && (
          <div className="pm-state">
            <strong>{tr("هیچ داکتری با این مشخصات پیدا نشد.")}</strong>{tr("جستجو یا فیلترها را تغییر دهید.")}{hasFilters && (
              <div><button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button></div>
            )}
          </div>
        )}

        {!error && items.length > 0 && (
          <div className={loading ? "pm-table-wrap-busy" : undefined}>
            <table className="pm-table">
              <thead>
                <tr>
                  <th>{tr("داکتر")}</th>
                  <th>{tr("تخصص / بخش")}</th>
                  <th>{tr("جنسیت")}</th>
                  <th>{tr("سابقه کاری")}</th>
                  <th>{tr("امتیاز")}</th>
                  <th>{tr("روزهای کاری")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {items.map((d, idx) => {
                  const days = parseWorkDaysList(d.workDays);
                  const menuOpen = menuId === d.id;
                  return (
                    <tr key={d.id}>
                      <td className="pm-cell-name">
                        <div className="pm-person">
                          <DoctorAvatar doctor={d} />
                          <div>
                            <span className="pm-person-name">{d.fullName}</span>
                            <span className="pm-sub pm-num">{tr("کد داکتر: {0}", [d.doctorCode || "—"])}</span>
                          </div>
                        </div>
                      </td>
                      <td data-label={tr("تخصص / بخش")}>{d.department || "—"}</td>
                      <td data-label={tr("جنسیت")}>{DOCTOR_GENDER_LABEL[d.gender] ? <span className="pm-gender">{DOCTOR_GENDER_LABEL[d.gender]}</span> : "—"}</td>
                      <td data-label={tr("سابقه کاری")} className="pm-num">{tr("{0} سال", [fa(d.yearsExperience)])}</td>
                      <td data-label={tr("امتیاز")}><Stars rating={d.rating} /></td>
                      <td data-label={tr("روزهای کاری")}>
                        {days.length ? (
                          <>
                            <span className="pm-num">{tr("{0} روز در هفته", [fa(days.length)])}</span>
                            <span className="pm-sub dm-ellipsis" title={showWorkDays(d.workDays)}>{showWorkDays(d.workDays)}</span>
                          </>
                        ) : "—"}
                      </td>
                      <td className="pm-cell-actions">
                        <div className="pm-actions">
                          <button type="button" className="pm-iconbtn" title={tr("مشاهده")} aria-label={tr("مشاهده {0}", [d.fullName])} onClick={() => setDetail({ id: d.id, tab: "general" })}><Eye size={16} /></button>
                          <button type="button" className="pm-iconbtn" title={tr("ویرایش")} aria-label={tr("ویرایش {0}", [d.fullName])} onClick={() => edit(d)}><Pencil size={16} /></button>
                          <button type="button" className="pm-iconbtn dm-iconbtn-danger" title={tr("حذف")} aria-label={tr("حذف {0}", [d.fullName])} onClick={() => setDeleteTarget(d)}><Trash2 size={16} /></button>
                          <div className="pm-menu-wrap">
                            <button type="button" className="pm-iconbtn" title={tr("گزینه‌های بیشتر")} aria-label={tr("گزینه‌های بیشتر برای {0}", [d.fullName])} aria-haspopup="menu" aria-expanded={menuOpen} onClick={() => setMenuId(menuOpen ? null : d.id)}><MoreVertical size={16} /></button>
                            {menuOpen && (
                              <FloatingMenu onClose={() => setMenuId(null)}>
                                <button type="button" role="menuitem" onClick={() => { setMenuId(null); setDetail({ id: d.id, tab: "schedule" }); }}><CalendarDays size={15} />{" "}{tr("برنامه کاری هفته")}</button>
                                <button type="button" role="menuitem" disabled={uploadingId === d.id} onClick={() => { setMenuId(null); pickPhoto(d.id); }}><Camera size={15} /> {uploadingId === d.id ? tr("در حال آپلود...") : tr("تغییر عکس")}</button>
                              </FloatingMenu>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {!error && pagination && pagination.total > 0 && (
          <DoctorPager pagination={pagination} page={page} onPageChange={setPage} fa={fa} firstIdx={firstIdx} />
        )}
      </div>
    </div>
  );

  return (
    <>
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      {/* ورودی مشترک انتخاب عکس برای منوی ⋮ ردیف‌ها و صفحه‌ی پروفایل */}
      <input ref={photoInputRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={handlePhotoUpload} />

      {detailDoctor ? (
        <DoctorProfilePage
          doctor={detailDoctor}
          doctors={allDoctors}
          schedules={schedules}
          schedulesLoading={schedulesLoading}
          initialTab={detail.tab}
          uploading={uploadingId === detailDoctor.id}
          fa={fa}
          onBack={() => setDetail(null)}
          onEdit={() => edit(detailDoctor)}
          onDelete={() => setDeleteTarget(detailDoctor)}
          onPhoto={() => pickPhoto(detailDoctor.id)}
        />
      ) : listView}

      <GlobalModal
        isOpen={formOpen}
        onClose={closeForm}
        title={editingId ? tr("ویرایش اطلاعات داکتر") : tr("افزودن داکتر جدید")}
        size="lg"
        footer={
          <>
            <button className="btn btn-primary" type="submit" form="dm-doctor-form" disabled={submitting}>
              {submitting ? tr("در حال ذخیره...") : editingId ? tr("ذخیره تغییرات") : tr("افزودن داکتر")}
            </button>
            <button className="btn btn-ghost" type="button" onClick={closeForm}>{tr("انصراف")}</button>
          </>
        }
      >
        <form id="dm-doctor-form" className="login-form dm-form" onSubmit={submit}>
          {formError && <div className="form-message error" role="alert">{formError}</div>}
          <h4 className="dm-form-title">{tr("اطلاعات اصلی")}</h4>
          <div className="field-row">
            <div className="field"><label htmlFor="dm-code">{tr("شناسه داکتر")}</label><input id="dm-code" required={!!editingId} readOnly={!editingId} dir="ltr" value={form.doctorCode} onChange={(e) => setForm((f) => ({ ...f, doctorCode: e.target.value }))} placeholder={editingId ? tr("مثلاً: DR-1009") : tr("خودکار")} />{!editingId && <span className="field-hint">{tr("شناسه به‌صورت خودکار و پشت‌سرهم داده می‌شود")}</span>}</div>
            <div className="field"><label htmlFor="dm-name">{tr("نام")}</label><input id="dm-name" required value={form.fullName} onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))} /></div>
          </div>
          <div className="field-row">
            <div className="field">
              <label htmlFor="dm-dep">{tr("بخش / تخصص")}</label>
              <input id="dm-dep" required list="dm-dep-list" value={form.department} onChange={(e) => setForm((f) => ({ ...f, department: e.target.value }))} />
              <datalist id="dm-dep-list">
                {departmentOptions.map((dep) => (<option key={dep.id} value={dep.name} />))}
              </datalist>
            </div>
            <div className="field"><label htmlFor="dm-gender">{tr("جنسیت")}</label>
              <select id="dm-gender" value={form.gender} onChange={(e) => setForm((f) => ({ ...f, gender: e.target.value }))}>
                <option value="men">{tr("آقا")}</option><option value="women">{tr("خانم")}</option>
              </select>
            </div>
          </div>
          <h4 className="dm-form-title">{tr("سابقه و امتیاز")}</h4>
          <div className="field-row">
            <div className="field"><label htmlFor="dm-years">{tr("سابقه کاری (سال)")}</label><input id="dm-years" type="number" min="0" max="80" value={form.yearsExperience} onChange={(e) => setForm((f) => ({ ...f, yearsExperience: Number(e.target.value) }))} /></div>
            <div className="field">
              <label>{tr("امتیاز")}</label>
              <StarPicker value={form.rating} onChange={(rating) => setForm((f) => ({ ...f, rating }))} />
            </div>
          </div>
          <h4 className="dm-form-title">{tr("روزهای کاری و عکس")}</h4>
          <div className="field-row">
            <div className="field">
              <label>{tr("روزهای کاری")}</label>
              <WorkDaysPicker value={form.workDaysList} onChange={(workDaysList) => setForm((f) => ({ ...f, workDaysList }))} />
            </div>
            <div className="field">
              <label htmlFor="dm-photo">{tr("عکس پروفایل (اختیاری)")}</label>
              <FilePickerField id="dm-photo" accept="image/jpeg,image/png,image/webp" file={formPhotoFile} onChange={handleFormPhotoChange} />
            </div>
          </div>
        </form>
      </GlobalModal>

      <GlobalModal
        isOpen={!!deleteTarget}
        onClose={() => !deleting && setDeleteTarget(null)}
        title={tr("حذف داکتر")}
        size="sm"
        footer={
          <>
            <button className="btn btn-danger" type="button" disabled={deleting} onClick={confirmRemove}>{deleting ? tr("در حال حذف...") : tr("حذف داکتر")}</button>
            <button className="btn btn-ghost" type="button" disabled={deleting} onClick={() => setDeleteTarget(null)}>{tr("انصراف")}</button>
          </>
        }
      >
        {deleteTarget && (
          <p>{tr("آیا از حذف «{0}» مطمئن هستید؟ این عملیات قابل بازگشت نیست و نوبت‌ها، برنامه‌های کاری و گفتگوهای وابسته به این داکتر نیز حذف می‌شوند.", [deleteTarget.fullName])}</p>
        )}
      </GlobalModal>
    </>
  );
}

// صفحه‌بندی مخصوص جدول داکتران: بازه‌ی نمایش + مجموع + شماره‌صفحه‌ها (پنجره‌ی ۵تایی)
export function DoctorPager({ pagination, page, onPageChange, fa, noun = tr("داکتر") }) {
  const { total, limit, totalPages } = pagination;
  const from = (page - 1) * limit + 1;
  const to = Math.min(page * limit, total);
  const start = Math.max(1, Math.min(page - 2, totalPages - 4));
  const nums = [];
  for (let n = start; n <= Math.min(totalPages, start + 4); n += 1) nums.push(n);
  return (
    <nav className="pm-pager" aria-label={tr("صفحه‌بندی")}>
      <span>{tr("نمایش {0} تا {1} از {2} {3}", [fa(from), fa(to), fa(total), noun])}</span>
      {totalPages > 1 && (
        <div className="pm-pages">
          <button type="button" className="pm-page-btn" disabled={page <= 1} onClick={() => onPageChange(page - 1)} aria-label={tr("صفحه قبل")}>›</button>
          {nums.map((n) => (
            <button key={n} type="button" className="pm-page-btn" aria-current={n === page ? "page" : undefined} onClick={() => onPageChange(n)}>{fa(n)}</button>
          ))}
          <button type="button" className="pm-page-btn" disabled={page >= totalPages} onClick={() => onPageChange(page + 1)} aria-label={tr("صفحه بعد")}>‹</button>
        </div>
      )}
    </nav>
  );
}

// پروفایل داکتر — به‌جای فهرست باز می‌شود (همان الگوی صفحه‌ی جزئیات بیمار).
// فقط فیلدهایی نمایش داده می‌شوند که واقعاً در جدول doctors / schedules وجود دارند؛
// (وضعیت فعال/غیرفعال، تلفن و ایمیل در این دیتابیس برای داکتر ذخیره نمی‌شوند.)
export const DOCTOR_TABS = trc([
  { key: "general", label: "اطلاعات عمومی" },
  { key: "experience", label: "سابقه کاری" },
  { key: "schedule", label: "روزهای کاری" },
  { key: "departments", label: "بخش‌ها و تخصص‌ها" },
]);

export function DoctorProfilePage({ doctor, doctors, schedules, schedulesLoading, initialTab, uploading, fa, onBack, onEdit, onDelete, onPhoto }) {
  const [tab, setTab] = useState(initialTab || "general");
  const days = parseWorkDaysList(doctor.workDays);
  const mySchedules = schedules.filter((s) => Number(s.doctorId) === Number(doctor.id));
  const colleagues = doctors.filter((d) => d.department === doctor.department && d.id !== doctor.id);

  const weekRows = WEEKDAYS.map((day) => {
    const slots = mySchedules
      .filter((s) => s.dayOfWeek === day)
      .sort((a, b) => String(a.startTime).localeCompare(String(b.startTime)));
    const listed = days.includes(day);
    return { day, slots, state: slots.length ? "work" : listed ? "work-nohours" : "off" };
  });

  return (
    <div className="pm-page">
      <div className="pm-head">
        <div>
          <nav className="dm-breadcrumb" aria-label={tr("مسیر صفحه")}>
            <span>{tr("داشبورد")}</span><ChevronLeft size={13} aria-hidden="true" />
            <button type="button" className="dm-crumb-link" onClick={onBack}>{tr("مدیریت داکتران")}</button>
            <ChevronLeft size={13} aria-hidden="true" /><span aria-current="page">{doctor.fullName}</span>
          </nav>
          <h2>{tr("پروفایل داکتر")}</h2>
          <p>{tr("اطلاعات ثبت‌شده‌ی داکتر در سیستم")}</p>
        </div>
        <div className="pm-head-actions">
          <button type="button" className="btn btn-ghost btn-sm" onClick={onBack}><ArrowRight size={15} />{" "}{tr("بازگشت به فهرست")}</button>
        </div>
      </div>

      <div className="dm-profile">
        {/* کارت خلاصه‌ی داکتر */}
        <aside className="pm-filterbar dm-summary">
          <DoctorAvatar doctor={doctor} size="xl" />
          <h3>{doctor.fullName}</h3>
          <span className="dm-summary-dep">{doctor.department}</span>
          <div className="dm-summary-rating"><Stars rating={doctor.rating} /> <span className="pm-num">{Number(doctor.rating || 0).toLocaleString(numLocale())}</span></div>
          <dl className="dm-summary-list">
            <div><dt>{tr("کد داکتر")}</dt><dd className="pm-num">{doctor.doctorCode || "—"}</dd></div>
            <div><dt>{tr("سابقه کاری")}</dt><dd className="pm-num">{tr("{0} سال", [fa(doctor.yearsExperience)])}</dd></div>
            <div><dt>{tr("جنسیت")}</dt><dd>{DOCTOR_GENDER_LABEL[doctor.gender] || "—"}</dd></div>
          </dl>
          {days.length > 0 && (
            <div className="dm-chips" aria-label={tr("روزهای کاری")}>{days.map((d) => (<span key={d} className="dm-chip">{tr(d)}</span>))}</div>
          )}
          <div className="dm-summary-actions">
            <button type="button" className="btn btn-primary btn-sm" onClick={onEdit}><Pencil size={14} />{" "}{tr("ویرایش")}</button>
            <button type="button" className="btn btn-ghost btn-sm danger" onClick={onDelete}><Trash2 size={14} />{" "}{tr("حذف")}</button>
          </div>
          <button type="button" className="btn btn-ghost btn-sm" disabled={uploading} onClick={onPhoto}><Camera size={14} /> {uploading ? tr("در حال آپلود...") : tr("تغییر عکس")}</button>
        </aside>

        <section className="pm-filterbar dm-detail">
          <div className="dm-tabs" role="tablist" aria-label={tr("بخش‌های پروفایل")}>
            {DOCTOR_TABS.map((t) => (
              <button key={t.key} type="button" role="tab" id={`dm-tab-${t.key}`} aria-selected={tab === t.key} aria-controls={`dm-panel-${t.key}`} className={`dm-tab${tab === t.key ? " is-active" : ""}`} onClick={() => setTab(t.key)}>
                {t.label}
              </button>
            ))}
          </div>

          <div role="tabpanel" id={`dm-panel-${tab}`} aria-labelledby={`dm-tab-${tab}`} className="dm-tabpanel">
            {tab === "general" && (
              <dl className="dm-info">
                <div><dt>{tr("نام کامل")}</dt><dd>{doctor.fullName}</dd></div>
                <div><dt>{tr("کد داکتر")}</dt><dd className="pm-num">{doctor.doctorCode || "—"}</dd></div>
                <div><dt>{tr("جنسیت")}</dt><dd>{DOCTOR_GENDER_LABEL[doctor.gender] || "—"}</dd></div>
                <div><dt>{tr("تخصص / بخش")}</dt><dd>{doctor.department || "—"}</dd></div>
                <div><dt>{tr("سابقه کاری")}</dt><dd className="pm-num">{tr("{0} سال", [fa(doctor.yearsExperience)])}</dd></div>
                <div><dt>{tr("امتیاز")}</dt><dd><Stars rating={doctor.rating} /> <span className="pm-num">{Number(doctor.rating || 0).toLocaleString(numLocale())}</span></dd></div>
                <div><dt>{tr("روزهای کاری")}</dt><dd>{showWorkDays(doctor.workDays) || "—"}</dd></div>
              </dl>
            )}

            {tab === "experience" && (
              <dl className="dm-info">
                <div><dt>{tr("سابقه کاری")}</dt><dd className="pm-num">{tr("{0} سال", [fa(doctor.yearsExperience)])}</dd></div>
                <div><dt>{tr("تاریخ ثبت در سیستم")}</dt><dd>{fmtDate(doctor.createdAt)}</dd></div>
                <div className="dm-info-wide"><dt>{tr("درباره‌ی داکتر")}</dt><dd>{doctor.bio || tr("توضیحاتی ثبت نشده است.")}</dd></div>
              </dl>
            )}

            {tab === "schedule" && (
              <>
                <h4 className="dm-form-title">{tr("برنامه کاری هفته")}</h4>
                {schedulesLoading ? (
                  <div aria-busy="true">{Array.from({ length: 7 }).map((_, i) => (<div key={i} className="pm-skel dm-skel-line" />))}</div>
                ) : (
                  <div className="dm-week">
                    {weekRows.map(({ day, slots, state }) => (
                      <div key={day} className={`dm-week-row is-${state}`}>
                        <span className="dm-week-day">{tr(day)}</span>
                        <span className="dm-week-hours pm-num">
                          {slots.length > 0
                            ? slots.map((s) => (
                                <span key={s.id}>{tr("{0} تا {1}", [fmtTime(s.startTime), fmtTime(s.endTime)])}{s.breakStart && s.breakEnd ? <span className="pm-sub">{tr("استراحت: {0} تا {1}", [fmtTime(s.breakStart), fmtTime(s.breakEnd)])}</span> : null}
                                </span>
                              ))
                            : state === "work-nohours" ? <span className="pm-muted">{tr("ساعت کاری ثبت نشده است")}</span> : "—"}
                        </span>
                        <span className={`pm-status ${state === "off" ? "is-off" : "is-active"}`}>{state === "off" ? tr("تعطیل") : tr("کاری")}</span>
                      </div>
                    ))}
                  </div>
                )}
              </>
            )}

            {tab === "departments" && (
              <>
                <dl className="dm-info">
                  <div><dt>{tr("تخصص / بخش اصلی")}</dt><dd>{doctor.department || "—"}</dd></div>
                  <div><dt>{tr("سایر داکتران همین بخش")}</dt><dd className="pm-num">{tr("{0} نفر", [fa(colleagues.length)])}</dd></div>
                </dl>
                {colleagues.length > 0 && (
                  <div className="dm-chips" style={{ marginTop: 14 }}>
                    {colleagues.map((c) => (<span key={c.id} className="dm-chip">{c.fullName}</span>))}
                  </div>
                )}
              </>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}

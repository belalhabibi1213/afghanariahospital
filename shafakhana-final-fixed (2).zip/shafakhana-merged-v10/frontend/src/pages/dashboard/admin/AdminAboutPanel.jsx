import { useEffect, useRef, useState } from "react";
import { Plus, Trash2, ArrowUp, ArrowDown, ImagePlus, Save, RotateCcw, ImageOff } from "lucide-react";
import { apiRequest, apiUpload, resolvePhotoUrl } from "../../../utils/api.js";
import { useDepartmentToasts, DepartmentToastContainer } from "../../../components/dashboard/DepartmentToast.jsx";
import { PageHead, StateBlock, ConfirmDialog } from "../../../components/admin/AdminPro.jsx";
import { photos } from "../../../data/photos.js";
import DepartmentIconPicker, { DepartmentLucideIcon } from "../../../components/dashboard/DepartmentIconPicker.jsx";
import fa from "../../../i18n/locales/fa.js";
import ps from "../../../i18n/locales/ps.js";
import en from "../../../i18n/locales/en.js";
import "./AdminAboutPanel.css";

import { getCurrentLang } from "../../../i18n/languages.js";
import { tr, trc } from "../../../i18n/tr.js";
// ویرایش بخش «معرفی» صفحه‌ی اصلی سایت: عکس، عنوان کوچک، عنوان اصلی، متن و فهرست موارد
// (آیکون + عنوان + توضیح) به سه زبان. تا وقتی ادمین چیزی ذخیره نکرده، فرم با متن‌های پیش‌فرض
// فعلی سایت پر می‌شود تا ویرایش از همان متن موجود شروع شود.
const LANGS = trc([
  { code: "fa", label: "دری", dir: "rtl" },
  { code: "ps", label: "پښتو", dir: "rtl" },
  { code: "en", label: "English", dir: "ltr" },
]);
const DICT = { fa, ps, en };
const DEFAULT_ICONS = { team: "🩺", equipment: "🏥", online: "💬" };
const MAX_ICON_SIZE = 2 * 1024 * 1024;
const ALLOWED_IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_POINTS = 12;
// ایموجی‌های آماده برای انتخاب سریع (برای کسانی که کیبورد ایموجی ندارند)
const QUICK_EMOJIS = ["🩺", "🏥", "💬", "⭐", "❤️", "💉", "💊", "🧪", "🔬", "🚑", "👨‍⚕️", "👩‍⚕️", "🕒", "📞", "✅", "🛡️"];

// انتخاب آیکون یک مورد: آیکون برداری (lucide:Name)، ایموجی آماده یا ایموجی/نماد دلخواه
function PointIconField({ value, onChange, index }) {
  const [open, setOpen] = useState(false);
  const isLucide = typeof value === "string" && value.startsWith("lucide:");
  return (
    <div className="about-icon-field">
      <span>{tr("آیکون")}</span>
      <button type="button" className="about-icon-btn" onClick={() => setOpen((o) => !o)} aria-expanded={open} aria-label={tr("انتخاب آیکون مورد {0}", [index + 1])}>
        {isLucide ? <DepartmentLucideIcon name={value.slice(7)} size={22} /> : (value || "＋")}
      </button>
      {open && (
        <div className="about-icon-pop">
          <p className="about-hint">{tr("آیکون‌های آماده")}</p>
          <DepartmentIconPicker value={isLucide ? value.slice(7) : ""} onChange={(name) => { onChange(name ? `lucide:${name}` : ""); if (name) setOpen(false); }} />
          <p className="about-hint">{tr("ایموجی آماده")}</p>
          <div className="about-emoji-row">
            {QUICK_EMOJIS.map((em) => (
              <button type="button" key={em} className="about-emoji" onClick={() => { onChange(em); setOpen(false); }}>{em}</button>
            ))}
          </div>
          <label className="about-field">
            <span>{tr("ایموجی دلخواه")}</span>
            <input type="text" maxLength={16} value={isLucide ? "" : value} onChange={(e) => onChange(e.target.value)} aria-label={tr("آیکون مورد {0}", [index + 1])} />
          </label>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpen(false)}>{tr("بستن")}</button>
        </div>
      )}
    </div>
  );
}

const emptyLangs = () => ({ fa: "", ps: "", en: "" });
const newId = () => `p${Math.random().toString(36).slice(2, 10)}`;

function defaultsFromLocales() {
  const per = (get) => Object.fromEntries(LANGS.map(({ code }) => [code, get(DICT[code].about) || ""]));
  return {
    imageUrl: "",
    eyebrow: per((a) => a.eyebrow),
    title: per((a) => a.title),
    text: per((a) => a.text),
    points: Object.keys(DEFAULT_ICONS).map((key) => ({
      id: key,
      icon: DEFAULT_ICONS[key],
      title: per((a) => a.points?.[key]?.title),
      text: per((a) => a.points?.[key]?.text),
    })),
  };
}

// محتوای ذخیره‌شده را کامل می‌کند (زبان‌های گمشده خالی می‌شوند)
function normalize(about) {
  const langs = (o) => ({ ...emptyLangs(), ...(o || {}) });
  return {
    imageUrl: about.imageUrl || "",
    eyebrow: langs(about.eyebrow),
    title: langs(about.title),
    text: langs(about.text),
    points: (about.points || []).map((p) => ({ id: p.id || newId(), icon: p.icon || "", title: langs(p.title), text: langs(p.text) })),
  };
}

export function AboutPanel() {
  const [state, setState] = useState({ loading: true, error: null });
  const [form, setForm] = useState(null);
  const [isCustom, setIsCustom] = useState(false);
  const [lang, setLang] = useState(() => (["fa", "ps", "en"].includes(getCurrentLang()) ? getCurrentLang() : "fa"));
  const [saving, setSaving] = useState(false);
  const [imageBusy, setImageBusy] = useState(false);
  const [confirm, setConfirm] = useState(null); // "reset" | { removePoint: index }
  const [resetting, setResetting] = useState(false);
  const fileRef = useRef(null);
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  async function load() {
    setState({ loading: true, error: null });
    try {
      const data = await apiRequest("/admin/about");
      setIsCustom(!!data.about);
      setForm(data.about ? normalize(data.about) : defaultsFromLocales());
      setState({ loading: false, error: null });
    } catch (err) {
      setState({ loading: false, error: err.message });
    }
  }
  useEffect(() => { load(); }, []);

  const cur = LANGS.find((l) => l.code === lang);
  const setField = (name, value) => setForm((f) => ({ ...f, [name]: { ...f[name], [lang]: value } }));
  const setPoint = (i, patch) => setForm((f) => ({ ...f, points: f.points.map((p, idx) => (idx === i ? { ...p, ...patch } : p)) }));
  const setPointLang = (i, name, value) => setForm((f) => ({
    ...f,
    points: f.points.map((p, idx) => (idx === i ? { ...p, [name]: { ...p[name], [lang]: value } } : p)),
  }));
  const movePoint = (i, delta) => setForm((f) => {
    const j = i + delta;
    if (j < 0 || j >= f.points.length) return f;
    const points = [...f.points];
    [points[i], points[j]] = [points[j], points[i]];
    return { ...f, points };
  });
  const addPoint = () => setForm((f) => (f.points.length >= MAX_POINTS ? f : {
    ...f, points: [...f.points, { id: newId(), icon: "⭐", title: emptyLangs(), text: emptyLangs() }],
  }));
  const removePoint = (i) => setForm((f) => ({ ...f, points: f.points.filter((_, idx) => idx !== i) }));

  async function save() {
    setSaving(true);
    try {
      const { imageUrl, ...content } = form;
      const data = await apiRequest("/admin/about", { method: "PUT", body: content });
      setForm(normalize(data.about));
      setIsCustom(true);
      showToast(tr("تغییرات بخش معرفی ذخیره شد و در سایت نمایش داده می‌شود"), "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setSaving(false);
    }
  }

  async function onPickImage(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!ALLOWED_IMAGE_TYPES.includes(file.type)) return showToast(tr("فرمت عکس مجاز نیست. فقط JPG، PNG یا WEBP مجاز است."), "error");
    if (file.size > MAX_ICON_SIZE) return showToast(tr("حجم عکس نباید بیشتر از ۲ مگابایت باشد."), "error");
    setImageBusy(true);
    try {
      const fd = new FormData();
      fd.append("image", file);
      const data = await apiUpload("/admin/about/image", fd);
      setForm((f) => ({ ...f, imageUrl: data.imageUrl }));
      showToast(tr("عکس جدید ذخیره شد"), "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setImageBusy(false);
    }
  }

  async function removeImage() {
    setImageBusy(true);
    try {
      await apiRequest("/admin/about/image", { method: "DELETE" });
      setForm((f) => ({ ...f, imageUrl: "" }));
      showToast(tr("عکس حذف شد؛ عکس پیش‌فرض نمایش داده می‌شود"), "success");
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setImageBusy(false);
    }
  }

  async function doReset() {
    setResetting(true);
    try {
      await apiRequest("/admin/about", { method: "DELETE" });
      showToast(tr("بخش معرفی به حالت پیش‌فرض برگشت"), "success");
      setConfirm(null);
      await load();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setResetting(false);
    }
  }

  if (state.loading) return <div className="about-admin"><PageHead title={tr("مدیریت بخش معرفی")} /><StateBlock kind="loading" title={tr("در حال بارگذاری...")} /></div>;
  if (state.error || !form) return <div className="about-admin"><PageHead title={tr("مدیریت بخش معرفی")} /><StateBlock kind="error" title={tr("خطا در بارگذاری")} message={state.error} onRetry={load} /></div>;

  const imageSrc = form.imageUrl ? resolvePhotoUrl(form.imageUrl) : photos.hospitalCorridor;
  const removing = typeof confirm === "object" && confirm ? confirm.removePoint : null;

  return (
    <div className="about-admin">
      <PageHead title={tr("مدیریت بخش معرفی")} subtitle={tr("عکس، متن و موارد بخش «درباره‌ی شفاخانه» صفحه‌ی اصلی سایت")} onRefresh={load}>
        {isCustom && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirm("reset")}>
            <RotateCcw size={14} />{" "}{tr("بازگشت به پیش‌فرض")}</button>
        )}
      </PageHead>

      <section className="about-card">
        <h3>{tr("عکس بخش")}</h3>
        <div className="about-img-row">
          <img className="about-img-preview" src={imageSrc} alt={tr("پیش‌نمایش عکس بخش معرفی")} />
          <div className="about-img-actions">
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={onPickImage} />
            <button type="button" className="btn btn-primary btn-sm" onClick={() => fileRef.current?.click()} disabled={imageBusy}>
              <ImagePlus size={14} /> {imageBusy ? tr("در حال ارسال...") : tr("انتخاب عکس جدید")}
            </button>
            {form.imageUrl && (
              <button type="button" className="btn btn-ghost btn-sm" onClick={removeImage} disabled={imageBusy}>
                <ImageOff size={14} />{" "}{tr("حذف عکس")}</button>
            )}
            <small>{tr("JPG، PNG یا WEBP — حداکثر ۲ مگابایت. عکس به‌محض انتخاب ذخیره می‌شود.")}</small>
          </div>
        </div>
      </section>

      <div className="about-langs" role="tablist" aria-label={tr("زبان محتوا")}>
        {LANGS.map((l) => (
          <button key={l.code} type="button" role="tab" aria-selected={lang === l.code} className={`about-lang${lang === l.code ? " is-active" : ""}`} onClick={() => setLang(l.code)}>
            {l.label}
          </button>
        ))}
      </div>
      <p className="about-hint">{tr("برای نمایش نام شفاخانه در متن، از")}{" "}<code dir="ltr">{"{hospital}"}</code>{" "}{tr("استفاده کنید. اگر برای یک زبان چیزی ننویسید، متن پیش‌فرض همان زبان (یا دری) نمایش داده می‌شود.")}</p>

      <section className="about-card">
        <h3>{tr("متن اصلی")}</h3>
        <label className="about-field">
          <span>{tr("عنوان کوچک (بالای تیتر)")}</span>
          <input type="text" dir={cur.dir} maxLength={120} value={form.eyebrow[lang]} onChange={(e) => setField("eyebrow", e.target.value)} />
        </label>
        <label className="about-field">
          <span>{tr("عنوان اصلی")}</span>
          <input type="text" dir={cur.dir} maxLength={200} value={form.title[lang]} onChange={(e) => setField("title", e.target.value)} />
        </label>
        <label className="about-field">
          <span>{tr("متن معرفی")}</span>
          <textarea dir={cur.dir} rows={6} maxLength={2000} value={form.text[lang]} onChange={(e) => setField("text", e.target.value)} />
        </label>
      </section>

      <section className="about-card">
        <div className="about-card-head">
          <h3>{tr("موارد زیر متن ({0})", [form.points.length])}</h3>
          <button type="button" className="btn btn-primary btn-sm" onClick={addPoint} disabled={form.points.length >= MAX_POINTS}>
            <Plus size={14} />{" "}{tr("افزودن مورد")}</button>
        </div>
        {form.points.length === 0 && <p className="about-hint">{tr("هنوز موردی نیست؛ با «افزودن مورد» یک مورد تازه بسازید.")}</p>}
        <ul className="about-points-list">
          {form.points.map((p, i) => (
            <li key={p.id} className="about-point-card">
              <div className="about-point-top">
                <PointIconField value={p.icon} index={i} onChange={(icon) => setPoint(i, { icon })} />
                <div className="about-point-tools">
                  <button type="button" className="about-tool" onClick={() => movePoint(i, -1)} disabled={i === 0} aria-label={tr("بالا بردن")}><ArrowUp size={16} /></button>
                  <button type="button" className="about-tool" onClick={() => movePoint(i, 1)} disabled={i === form.points.length - 1} aria-label={tr("پایین بردن")}><ArrowDown size={16} /></button>
                  <button type="button" className="about-tool about-tool-danger" onClick={() => setConfirm({ removePoint: i })} aria-label={tr("حذف مورد")}><Trash2 size={16} /></button>
                </div>
              </div>
              <label className="about-field">
                <span>{tr("عنوان")}</span>
                <input type="text" dir={cur.dir} maxLength={120} value={p.title[lang]} onChange={(e) => setPointLang(i, "title", e.target.value)} />
              </label>
              <label className="about-field">
                <span>{tr("توضیح")}</span>
                <textarea dir={cur.dir} rows={2} maxLength={400} value={p.text[lang]} onChange={(e) => setPointLang(i, "text", e.target.value)} />
              </label>
            </li>
          ))}
        </ul>
      </section>

      <div className="about-savebar">
        <button type="button" className="btn btn-primary" onClick={save} disabled={saving}>
          <Save size={16} /> {saving ? tr("در حال ذخیره...") : tr("ذخیره‌ی تغییرات")}
        </button>
      </div>

      <ConfirmDialog
        open={confirm === "reset"}
        title={tr("بازگشت به حالت پیش‌فرض")}
        message={tr("همه‌ی متن‌ها و موارد ویرایش‌شده و عکس آپلودشده پاک می‌شود و سایت دوباره متن و عکس پیش‌فرض را نشان می‌دهد.")}
        confirmLabel={tr("بله، برگردان")}
        busyLabel={tr("در حال انجام...")}
        busy={resetting}
        danger
        onConfirm={doReset}
        onCancel={() => setConfirm(null)}
      />
      <ConfirmDialog
        open={removing !== null}
        title={tr("حذف این مورد")}
        message={tr("این مورد از بخش معرفی حذف می‌شود (بعد از «ذخیره‌ی تغییرات» در سایت اعمال می‌شود).")}
        confirmLabel={tr("حذف")}
        danger
        onConfirm={() => { removePoint(removing); setConfirm(null); }}
        onCancel={() => setConfirm(null)}
      />
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
}

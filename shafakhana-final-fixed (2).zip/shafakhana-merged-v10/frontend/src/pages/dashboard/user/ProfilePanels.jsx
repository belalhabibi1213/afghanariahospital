import { useEffect, useMemo, useRef, useState } from "react";
import { } from "react-router-dom";
import {
  Activity,
  BadgeCheck,
  Clock,
  Mail,
  Pencil,
  Phone,
  ShieldCheck,
  User,
} from "lucide-react";
import {
  Badge,
  FormField,
  InfoItem,
  Notice,
  PageHeader,
  SectionCard,
  Skeleton,
  SkeletonBlock,
} from "../../../components/dashboard/patient/pdUi.jsx";
import { useAuth } from "../../../context/AuthContext.jsx";
import { } from "../../../context/LanguageContext.jsx";
import { tr, trc, tdigits } from "../../../i18n/tr.js";
import { apiRequest, apiUpload, resolvePhotoUrl } from "../../../utils/api.js";
import { } from "../../../utils/passwordPolicy.js";
import { isValidPersianName, PERSIAN_NAME_ERROR_MESSAGE } from "../../../utils/persianName.js";

import { JalaliDateInput } from "../../../components/JalaliDateInput.jsx";
import { todayISO } from "../../../utils/jalali.js";
import { calcAge, fmtDate, ButtonSpinner } from "./userShared.jsx";

export const GENDER_LABEL_FA = trc({ male: "مرد", female: "زن", other: "دیگر" });
export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export function ProfileView() {
  const { user, updateUser } = useAuth();
  const [profile, setProfile] = useState(user);
  const [loading, setLoading] = useState(true);
  const [photoStatus, setPhotoStatus] = useState({ type: "", text: "" });
  const [photoLoading, setPhotoLoading] = useState(false);

  useEffect(() => {
    apiRequest("/users/profile")
      .then((data) => setProfile(data.user))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  async function handlePhotoChange(e) {
    const file = e.target.files?.[0];
    e.target.value = ""; // امکان انتخاب دوباره همان فایل را فراهم می‌کند
    if (!file) return;

    const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
    if (!allowedTypes.includes(file.type)) {
      setPhotoStatus({ type: "error", text: tr("فرمت عکس مجاز نیست. فقط JPG، PNG یا WEBP مجاز است.") });
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setPhotoStatus({ type: "error", text: tr("حجم عکس نباید بیشتر از ۲ مگابایت باشد.") });
      return;
    }

    setPhotoStatus({ type: "", text: "" });
    setPhotoLoading(true);
    try {
      const formData = new FormData();
      formData.append("photo", file);
      const data = await apiUpload("/users/photo", formData);
      setProfile(data.user);
      updateUser({ photoUrl: data.user.photoUrl });
      setPhotoStatus({ type: "success", text: data.message });
    } catch (err) {
      setPhotoStatus({ type: "error", text: err.message });
    } finally {
      setPhotoLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="dash-card glass pd-panel">
        <PageHeader icon={User} title={tr("پروفایل من")} subtitle={tr("اطلاعات هویتی، تماس و حساب کاربری شما")} />
        <div className="pd-card">
          <div className="pd-hero">
            <Skeleton width={88} height={88} radius="50%" />
            <div className="pd-hero-body">
              <Skeleton width={180} height={20} />
              <Skeleton width={120} height={13} />
            </div>
          </div>
        </div>
        <div className="pd-card">
          <SkeletonBlock rows={5} label={tr("در حال بارگذاری پروفایل")} />
        </div>
      </div>
    );
  }

  const photoSrc = resolvePhotoUrl(profile?.photoUrl);
  const age = calcAge(profile?.dateOfBirth);
  const dob = profile?.dateOfBirth ? fmtDate(profile.dateOfBirth) : "";

  return (
    <div className="dash-card glass pd-panel">
      <PageHeader icon={User} title={tr("پروفایل من")} subtitle={tr("اطلاعات هویتی، تماس و حساب کاربری شما")} />

      {/* ---------- هویت بیمار ---------- */}
      <div className="pd-card">
        <div className="pd-hero">
          <div className="pd-avatar">
            {photoSrc ? (
              <img src={photoSrc} alt={tr("عکس پروفایل")} />
            ) : (
              <span aria-hidden="true">{profile?.fullName?.charAt(0) || <User size={34} />}</span>
            )}
          </div>

          <div className="pd-hero-body">
            <h3 className="pd-hero-name">{profile?.fullName || "—"}</h3>
            <div className="pd-hero-sub">
              <span>{tr("شناسه بیمار:")} <strong dir="ltr">{profile?.patientId || "—"}</strong></span>
            </div>
            <div className="pd-actions">
              <Badge tone={profile?.isActive ? "success" : "danger"}>
                {profile?.isActive ? tr("حساب فعال") : tr("حساب غیرفعال")}
              </Badge>
              <Badge tone={profile?.isVerified ? "info" : "warning"} icon={profile?.isVerified ? BadgeCheck : Clock}>
                {profile?.isVerified ? tr("ایمیل تایید شده") : tr("ایمیل در انتظار تایید")}
              </Badge>
            </div>
          </div>

          <div className="pd-hero-actions">
            <label className="btn btn-ghost btn-sm avatar-upload-btn">
              {photoLoading ? <ButtonSpinner /> : <Pencil size={14} aria-hidden="true" />}
              {photoLoading ? tr("در حال آپلود...") : tr("تغییر عکس پروفایل")}
              <input
                type="file"
                accept="image/jpeg,image/png,image/webp"
                onChange={handlePhotoChange}
                disabled={photoLoading}
                hidden
              />
            </label>
            <p className="pd-hero-hint">{tr("فرمت JPG، PNG یا WEBP — حداکثر ۲ مگابایت")}</p>
          </div>
        </div>
        {photoStatus.text && (
          <div style={{ marginTop: 14 }}>
            <Notice type={photoStatus.type === "success" ? "success" : "error"}>{photoStatus.text}</Notice>
          </div>
        )}
      </div>

      <div className="pd-two-col">
        {/* ---------- اطلاعات شخصی ---------- */}
        <SectionCard icon={User} title={tr("اطلاعات شخصی")}>
          <div className="pd-info-grid">
            <InfoItem label={tr("نام کامل")} value={profile?.fullName} />
            <InfoItem label={tr("شناسه بیمار")} value={profile?.patientId} dir="ltr" emptyText="—" />
            <InfoItem label={tr("تاریخ تولد")} value={dob ? `${dob}${age !== null ? tr(" ({0} سال)", [age]) : ""}` : ""} />
            <InfoItem label={tr("جنسیت")} value={GENDER_LABEL_FA[profile?.gender]} />
            <InfoItem label={tr("گروه خونی")} value={profile?.bloodGroup} dir="ltr" />
          </div>
        </SectionCard>

        {/* ---------- اطلاعات تماس ---------- */}
        <SectionCard icon={Mail} title={tr("اطلاعات تماس")}>
          <div className="pd-info-grid">
            <InfoItem label={tr("ایمیل")} value={profile?.email} dir="ltr" wide />
            <InfoItem label={tr("شماره تماس")} value={profile?.phone} dir="ltr" />
            <InfoItem label={tr("آدرس")} value={profile?.address} wide />
          </div>
        </SectionCard>
      </div>

      <div className="pd-two-col">
        {/* ---------- تماس اضطراری ---------- */}
        <SectionCard icon={Phone} title={tr("تماس اضطراری")}>
          <div className="pd-info-grid">
            <InfoItem label={tr("نام تماس اضطراری")} value={profile?.emergencyContactName} />
            <InfoItem label={tr("نسبت با بیمار")} value={profile?.emergencyContactRelationship} />
            <InfoItem label={tr("شماره تماس اضطراری")} value={profile?.emergencyContactPhone} dir="ltr" />
          </div>
        </SectionCard>

        {/* ---------- اطلاعات طبی ---------- */}
        <SectionCard icon={Activity} title={tr("اطلاعات طبی")}>
          <div className="pd-info-grid">
            <InfoItem label={tr("قد")} value={profile?.height ? tr("{0} سانتی‌متر", [tdigits(profile.height)]) : ""} />
            <InfoItem label={tr("وزن")} value={profile?.weight ? tr("{0} کیلوگرام", [tdigits(profile.weight)]) : ""} />
            <InfoItem label={tr("حساسیت‌ها")} value={profile?.allergies} wide />
            <InfoItem label={tr("بیماری‌های مزمن")} value={profile?.chronicDiseases} wide />
            <InfoItem label={tr("حساسیت‌های دارویی")} value={profile?.drugAllergies} wide />
          </div>
        </SectionCard>
      </div>

      {/* ---------- اطلاعات حساب ---------- */}
      <SectionCard icon={ShieldCheck} title={tr("اطلاعات حساب")}>
        <div className="pd-info-grid">
          <InfoItem label={tr("وضعیت حساب")} value={profile?.isActive ? tr("فعال") : tr("غیرفعال")} />
          <InfoItem label={tr("وضعیت تایید ایمیل")} value={profile?.isVerified ? tr("تایید شده") : tr("در انتظار تایید")} />
          <InfoItem label={tr("تاریخ عضویت")} value={fmtDate(profile?.createdAt)} emptyText="—" />
        </div>
      </SectionCard>
    </div>
  );
}

export const PHONE_REGEX = /^0\d{9}$/;

export function EditProfile() {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({
    fullName: user?.fullName || "",
    phone: user?.phone || "",
    dateOfBirth: user?.dateOfBirth ? String(user.dateOfBirth).slice(0, 10) : "",
    gender: user?.gender || "",
    bloodGroup: user?.bloodGroup || "",
    address: user?.address || "",
    emergencyContactName: user?.emergencyContactName || "",
    emergencyContactRelationship: user?.emergencyContactRelationship || "",
    emergencyContactPhone: user?.emergencyContactPhone || "",
    allergies: user?.allergies || "",
    chronicDiseases: user?.chronicDiseases || "",
    drugAllergies: user?.drugAllergies || "",
    height: user?.height != null ? String(user.height) : "",
    weight: user?.weight != null ? String(user.weight) : "" });
  // نسخه‌ی «آخرین مقدار ذخیره‌شده» برای تشخیص تغییرات ذخیره‌نشده (فقط UI)
  const [baseline, setBaseline] = useState(form);
  const [fieldErrors, setFieldErrors] = useState({});
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);
  const statusRef = useRef(null);

  const dirty = useMemo(() => JSON.stringify(form) !== JSON.stringify(baseline), [form, baseline]);

  // هشدار مرورگر هنگام ترک/رفرش صفحه با تغییرات ذخیره‌نشده
  useEffect(() => {
    if (!dirty) return undefined;
    const handler = (e) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty]);

  useEffect(() => {
    if (status.text && statusRef.current) {
      statusRef.current.scrollIntoView({ behavior: "smooth", block: "nearest" });
    }
  }, [status]);

  function updateField(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
    if (fieldErrors[key]) setFieldErrors((f) => ({ ...f, [key]: "" }));
    if (status.type === "success") setStatus({ type: "", text: "" });
  }

  function resetChanges() {
    setForm(baseline);
    setFieldErrors({});
    setStatus({ type: "", text: "" });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return; // جلوگیری از ارسال هم‌زمان
    setStatus({ type: "", text: "" });

    const errs = {};
    const name = form.fullName.trim();
    if (!name) {
      errs.fullName = tr("نام کامل الزامی است.");
    } else if (name.length < 3 || name.length > 150) {
      errs.fullName = tr("نام کامل باید بین ۳ تا ۱۵۰ کاراکتر باشد.");
    } else if (!isValidPersianName(name)) {
      errs.fullName = tr(PERSIAN_NAME_ERROR_MESSAGE);
    }
    if (form.phone && !PHONE_REGEX.test(form.phone.trim())) {
      errs.phone = tr("شماره تماس معتبر نیست (مثال: 07XXXXXXXX).");
    }
    if (form.dateOfBirth) {
      const parsed = new Date(form.dateOfBirth);
      const today = new Date();
      const minDate = new Date("1900-01-01");
      if (Number.isNaN(parsed.getTime()) || parsed > today || parsed < minDate) {
        errs.dateOfBirth = tr("تاریخ تولد معتبر نیست.");
      }
    }
    if (form.address && form.address.trim().length > 255) {
      errs.address = tr("آدرس نباید بیشتر از ۲۵۵ کاراکتر باشد.");
    }
    if (form.emergencyContactName && (form.emergencyContactName.trim().length < 3 || form.emergencyContactName.trim().length > 150)) {
      errs.emergencyContactName = tr("نام تماس اضطراری باید بین ۳ تا ۱۵۰ کاراکتر باشد.");
    }
    if (form.emergencyContactRelationship && form.emergencyContactRelationship.trim().length > 50) {
      errs.emergencyContactRelationship = tr("نسبت با بیمار نباید بیشتر از ۵۰ کاراکتر باشد.");
    }
    if (form.emergencyContactPhone && !PHONE_REGEX.test(form.emergencyContactPhone.trim())) {
      errs.emergencyContactPhone = tr("شماره تماس اضطراری معتبر نیست (مثال: 07XXXXXXXX).");
    }
    if (form.allergies && form.allergies.trim().length > 500) {
      errs.allergies = tr("حساسیت‌ها نباید بیشتر از ۵۰۰ کاراکتر باشد.");
    }
    if (form.chronicDiseases && form.chronicDiseases.trim().length > 500) {
      errs.chronicDiseases = tr("بیماری‌های مزمن نباید بیشتر از ۵۰۰ کاراکتر باشد.");
    }
    if (form.drugAllergies && form.drugAllergies.trim().length > 500) {
      errs.drugAllergies = tr("حساسیت‌های دارویی نباید بیشتر از ۵۰۰ کاراکتر باشد.");
    }
    if (form.height) {
      const h = Number(form.height);
      if (Number.isNaN(h) || h < 30 || h > 250) {
        errs.height = tr("قد معتبر نیست (بین ۳۰ تا ۲۵۰ سانتی‌متر).");
      }
    }
    if (form.weight) {
      const w = Number(form.weight);
      if (Number.isNaN(w) || w < 1 || w > 400) {
        errs.weight = tr("وزن معتبر نیست (بین ۱ تا ۴۰۰ کیلوگرام).");
      }
    }

    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) {
      setStatus({ type: "error", text: tr("لطفاً خطاهای فرم را برطرف کنید.") });
      return;
    }

    setLoading(true);
    try {
      const data = await apiRequest("/users/profile", {
        method: "PUT",
        body: {
          fullName: form.fullName,
          phone: form.phone,
          dateOfBirth: form.dateOfBirth || null,
          gender: form.gender || null,
          bloodGroup: form.bloodGroup || null,
          address: form.address,
          emergencyContactName: form.emergencyContactName,
          emergencyContactRelationship: form.emergencyContactRelationship,
          emergencyContactPhone: form.emergencyContactPhone,
          allergies: form.allergies,
          chronicDiseases: form.chronicDiseases,
          drugAllergies: form.drugAllergies,
          height: form.height || null,
          weight: form.weight || null } });
      setStatus({ type: "success", text: data.message });
      setBaseline(form);
      updateUser({
        fullName: data.user.fullName,
        phone: data.user.phone,
        dateOfBirth: data.user.dateOfBirth,
        gender: data.user.gender,
        bloodGroup: data.user.bloodGroup,
        address: data.user.address,
        emergencyContactName: data.user.emergencyContactName,
        emergencyContactRelationship: data.user.emergencyContactRelationship,
        emergencyContactPhone: data.user.emergencyContactPhone,
        allergies: data.user.allergies,
        chronicDiseases: data.user.chronicDiseases,
        drugAllergies: data.user.drugAllergies,
        height: data.user.height,
        weight: data.user.weight });
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setLoading(false);
    }
  }

  // کمک برای اتصال aria به خطای هر فیلد
  const a11y = (key) => ({
    "aria-invalid": fieldErrors[key] ? true : undefined,
    "aria-describedby": fieldErrors[key] ? `pd-edit-${key}-error` : undefined });

  return (
    <div className="dash-card glass pd-panel">
      <PageHeader
        icon={Pencil}
        title={tr("ویرایش اطلاعات شخصی")}
        subtitle={tr("اطلاعات خود را به‌روز نگه دارید. فیلدهای دارای ستاره (*) الزامی هستند.")}
      />

      <form className="pd-form" onSubmit={handleSubmit} noValidate>
        <div ref={statusRef}>
          <Notice type={status.type === "success" ? "success" : "error"}>{status.text}</Notice>
        </div>

        {/* ---------- هویت ---------- */}
        <SectionCard icon={User} title={tr("اطلاعات هویتی")}>
          <div className="pd-form-grid">
            {/* شناسه بیمار همیشه خودکار و از روی حساب کاربری ساخته می‌شود — هرگز قابل ویرایش نیست */}
            <FormField id="pd-edit-patientId" label={tr("شناسه بیمار")} hint={tr("خودکار ساخته می‌شود و قابل ویرایش نیست.")}>
              <input id="pd-edit-patientId" value={user?.patientId || ""} disabled readOnly dir="ltr" />
            </FormField>

            <FormField id="pd-edit-fullName" label={tr("نام کامل")} required error={fieldErrors.fullName}>
              <input
                id="pd-edit-fullName"
                value={form.fullName}
                onChange={(e) => updateField("fullName", e.target.value)}
                autoComplete="name"
                {...a11y("fullName")}
              />
            </FormField>

            <FormField id="pd-edit-dateOfBirth" label={tr("تاریخ تولد")} error={fieldErrors.dateOfBirth}>
              <JalaliDateInput
                id="pd-edit-dateOfBirth"
                value={form.dateOfBirth}
                max={todayISO()}
                onChange={(e) => updateField("dateOfBirth", e.target.value)}
                {...a11y("dateOfBirth")}
              />
            </FormField>

            <FormField id="pd-edit-gender" label={tr("جنسیت")}>
              <select id="pd-edit-gender" value={form.gender} onChange={(e) => updateField("gender", e.target.value)}>
                <option value="">{tr("انتخاب نشده")}</option>
                <option value="male">{tr("مرد")}</option>
                <option value="female">{tr("زن")}</option>
                <option value="other">{tr("دیگر")}</option>
              </select>
            </FormField>

            <FormField id="pd-edit-bloodGroup" label={tr("گروه خونی")}>
              <select id="pd-edit-bloodGroup" value={form.bloodGroup} onChange={(e) => updateField("bloodGroup", e.target.value)}>
                <option value="">{tr("انتخاب نشده")}</option>
                {BLOOD_GROUPS.map((bg) => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>
            </FormField>
          </div>
        </SectionCard>

        {/* ---------- تماس ---------- */}
        <SectionCard icon={Mail} title={tr("اطلاعات تماس")}>
          <div className="pd-form-grid">
            <FormField id="pd-edit-email" label={tr("ایمیل")} hint={tr("ایمیل از این بخش قابل ویرایش نیست.")}>
              <input id="pd-edit-email" value={user?.email || ""} disabled readOnly dir="ltr" />
            </FormField>

            <FormField id="pd-edit-phone" label={tr("شماره تماس")} error={fieldErrors.phone}>
              <input
                id="pd-edit-phone"
                className="pd-ltr-input"
                value={form.phone}
                onChange={(e) => updateField("phone", e.target.value)}
                placeholder="07XXXXXXXX"
                inputMode="tel"
                autoComplete="tel"
                {...a11y("phone")}
              />
            </FormField>

            <FormField id="pd-edit-address" label={tr("آدرس")} wide error={fieldErrors.address}>
              <textarea
                id="pd-edit-address"
                rows={3}
                maxLength={255}
                value={form.address}
                onChange={(e) => updateField("address", e.target.value)}
                placeholder={tr("آدرس محل سکونت...")}
                {...a11y("address")}
              />
            </FormField>
          </div>
        </SectionCard>

        {/* ---------- تماس اضطراری ---------- */}
        <SectionCard icon={Phone} title={tr("تماس اضطراری")} hint={tr("فردی که در شرایط اضطراری با او تماس گرفته می‌شود.")}>
          <div className="pd-form-grid">
            <FormField id="pd-edit-emergencyContactName" label={tr("نام تماس اضطراری")} error={fieldErrors.emergencyContactName}>
              <input
                id="pd-edit-emergencyContactName"
                value={form.emergencyContactName}
                onChange={(e) => updateField("emergencyContactName", e.target.value)}
                placeholder={tr("نام کامل فرد قابل تماس در شرایط اضطراری")}
                {...a11y("emergencyContactName")}
              />
            </FormField>

            <FormField id="pd-edit-emergencyContactRelationship" label={tr("نسبت با بیمار")} error={fieldErrors.emergencyContactRelationship}>
              <input
                id="pd-edit-emergencyContactRelationship"
                value={form.emergencyContactRelationship}
                onChange={(e) => updateField("emergencyContactRelationship", e.target.value)}
                placeholder={tr("مثال: پدر، مادر، همسر، برادر...")}
                maxLength={50}
                {...a11y("emergencyContactRelationship")}
              />
            </FormField>

            <FormField id="pd-edit-emergencyContactPhone" label={tr("شماره تماس اضطراری")} error={fieldErrors.emergencyContactPhone}>
              <input
                id="pd-edit-emergencyContactPhone"
                className="pd-ltr-input"
                value={form.emergencyContactPhone}
                onChange={(e) => updateField("emergencyContactPhone", e.target.value)}
                placeholder="07XXXXXXXX"
                inputMode="tel"
                {...a11y("emergencyContactPhone")}
              />
            </FormField>
          </div>
        </SectionCard>

        {/* ---------- اطلاعات طبی ---------- */}
        <SectionCard icon={Activity} title={tr("اطلاعات طبی")}>
          <div className="pd-form-grid">
            <FormField id="pd-edit-height" label={tr("قد (سانتی‌متر)")} error={fieldErrors.height}>
              <input
                id="pd-edit-height"
                type="number"
                min="30"
                max="250"
                step="0.1"
                value={form.height}
                onChange={(e) => updateField("height", e.target.value)}
                placeholder={tr("مثال: 170")}
                {...a11y("height")}
              />
            </FormField>

            <FormField id="pd-edit-weight" label={tr("وزن (کیلوگرام)")} error={fieldErrors.weight}>
              <input
                id="pd-edit-weight"
                type="number"
                min="1"
                max="400"
                step="0.1"
                value={form.weight}
                onChange={(e) => updateField("weight", e.target.value)}
                placeholder={tr("مثال: 65")}
                {...a11y("weight")}
              />
            </FormField>

            <FormField id="pd-edit-allergies" label={tr("حساسیت‌ها")} wide error={fieldErrors.allergies}>
              <textarea
                id="pd-edit-allergies"
                rows={2}
                maxLength={500}
                value={form.allergies}
                onChange={(e) => updateField("allergies", e.target.value)}
                placeholder={tr("مثال: حساسیت به گرد و غبار، بادام‌زمینی...")}
                {...a11y("allergies")}
              />
            </FormField>

            <FormField id="pd-edit-chronicDiseases" label={tr("بیماری‌های مزمن")} wide error={fieldErrors.chronicDiseases}>
              <textarea
                id="pd-edit-chronicDiseases"
                rows={2}
                maxLength={500}
                value={form.chronicDiseases}
                onChange={(e) => updateField("chronicDiseases", e.target.value)}
                placeholder={tr("مثال: دیابت، فشار خون بالا...")}
                {...a11y("chronicDiseases")}
              />
            </FormField>

            <FormField id="pd-edit-drugAllergies" label={tr("حساسیت‌های دارویی")} wide error={fieldErrors.drugAllergies}>
              <textarea
                id="pd-edit-drugAllergies"
                rows={2}
                maxLength={500}
                value={form.drugAllergies}
                onChange={(e) => updateField("drugAllergies", e.target.value)}
                placeholder={tr("مثال: پنی‌سیلین، آسپرین...")}
                {...a11y("drugAllergies")}
              />
            </FormField>
          </div>
        </SectionCard>

        {/* ---------- نوار اکشن ---------- */}
        <div className="pd-form-footer">
          {dirty && <span className="pd-unsaved">{tr("تغییرات ذخیره‌نشده")}</span>}
          <span className="pd-form-footer-spacer" />
          {dirty && (
            <button type="button" className="btn btn-ghost" disabled={loading} onClick={resetChanges}>
              {tr("لغو تغییرات")}
            </button>
          )}
          <button className="btn btn-primary" disabled={loading || !dirty} type="submit">
            {loading && <ButtonSpinner />}
            {loading ? tr("در حال ذخیره...") : tr("ذخیره تغییرات")}
          </button>
        </div>
      </form>
    </div>
  );
}


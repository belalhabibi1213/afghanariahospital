import { } from "react";
import { } from "react-router-dom";
import { CalendarCheck, CalendarX, CircleCheck, Clock } from "lucide-react";
import { } from "../../../context/AuthContext.jsx";
import { } from "../../../context/LanguageContext.jsx";
import { trc, jdate } from "../../../i18n/tr.js";
import { } from "../../../utils/api.js";
import { } from "../../../utils/passwordPolicy.js";
import { } from "../../../utils/persianName.js";

import { } from "../../../components/JalaliDateInput.jsx";
import { } from "../../../utils/jalali.js";

export const STATUS_LABEL = trc({
  pending: "در انتظار تایید",
  confirmed: "تایید شده",
  completed: "انجام‌شده",
  cancelled: "لغوشده" });

// وضعیت نوبت → رنگ/آیکون Badge (حداقل رنگ‌بندی: هر وضعیت یک آیکون هم دارد تا فقط به رنگ وابسته نباشد)
export const APPT_BADGE = {
  pending: { tone: "warning", icon: Clock },
  confirmed: { tone: "success", icon: CalendarCheck },
  completed: { tone: "info", icon: CircleCheck },
  cancelled: { tone: "danger", icon: CalendarX } };

// ---------- کمک‌تابع‌های نمایشی (بدون تغییر در داده) ----------
export function fmtDate(value) {
  return value ? jdate(value) : "";
}

export function fmtTime(value) {
  if (!value) return "";
  const m = /^(\d{2}:\d{2})/.exec(String(value));
  return m ? m[1] : String(value);
}

export function todayLocalISO() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function calcAge(dob) {
  if (!dob) return null;
  const birth = new Date(String(dob).slice(0, 10));
  if (Number.isNaN(birth.getTime())) return null;
  const now = new Date();
  let age = now.getFullYear() - birth.getFullYear();
  const beforeBirthday =
    now.getMonth() < birth.getMonth() || (now.getMonth() === birth.getMonth() && now.getDate() < birth.getDate());
  if (beforeBirthday) age -= 1;
  return age >= 0 && age < 130 ? age : null;
}

export function money(n) {
  return Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

export function ButtonSpinner() {
  return <span className="pd-btn-spinner" aria-hidden="true" />;
}


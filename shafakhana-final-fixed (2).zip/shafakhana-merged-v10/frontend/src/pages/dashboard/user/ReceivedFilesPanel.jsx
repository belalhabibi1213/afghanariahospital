import { useCallback, useEffect, useMemo, useState } from "react";
import { } from "react-router-dom";
import {
  Download,
  File as FileIcon,
  FileImage,
  FileSpreadsheet,
  FileText,
  Inbox,
  Search,
} from "lucide-react";
import {
  Badge,
  EmptyState,
  ErrorState,
  NoResults,
  Notice,
  PageHeader,
  SkeletonBlock,
} from "../../../components/dashboard/patient/pdUi.jsx";
import { } from "../../../context/AuthContext.jsx";
import { } from "../../../context/LanguageContext.jsx";
import { tr } from "../../../i18n/tr.js";
import { apiRequest, apiDownload } from "../../../utils/api.js";
import useHighlightParam from "../../../hooks/useHighlightParam.js";
import { } from "../../../utils/passwordPolicy.js";
import { } from "../../../utils/persianName.js";

import { } from "../../../components/JalaliDateInput.jsx";
import { } from "../../../utils/jalali.js";
import { fmtDate, ButtonSpinner } from "./userShared.jsx";

// ---------- فایل‌های دریافتی (ماژول «انتقال معلومات بیمار») ----------
// فایل‌ها/اسناد صحی که داکترها برای این بیمار ارسال کرده‌اند — فقط فایل‌های خودِ
// بیمار قابل‌مشاهده/دانلود است (بک‌اند این مالکیت را دوباره بررسی می‌کند).
export const FILE_TYPE_LABEL = {
  "application/pdf": "PDF",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "Excel",
  "application/vnd.ms-excel": "Excel",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "Word",
  "image/jpeg": "JPG",
  "image/png": "PNG" };

export function formatFileSize(bytes) {
  if (!bytes && bytes !== 0) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// آیکون و رنگ هر نوع فایل (فقط نمایشی؛ بر اساس همان fileType واقعی)
export function fileVisual(fileType) {
  const t = String(fileType || "");
  if (t === "application/pdf") return { Icon: FileText, cls: "pd-file-icon-pdf" };
  if (t.includes("spreadsheet") || t.includes("ms-excel")) return { Icon: FileSpreadsheet, cls: "pd-file-icon-sheet" };
  if (t.includes("wordprocessing") || t.includes("msword")) return { Icon: FileText, cls: "pd-file-icon-doc" };
  if (t.startsWith("image/")) return { Icon: FileImage, cls: "pd-file-icon-image" };
  return { Icon: FileIcon, cls: "" };
}

export function ReceivedFilesPanel() {
  const [transfers, setTransfers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [downloadError, setDownloadError] = useState("");
  const [downloadingId, setDownloadingId] = useState(null);
  const [query, setQuery] = useState("");
  const { highlightRowProps } = useHighlightParam();

  const load = useCallback(() => {
    setLoading(true);
    setError("");
    apiRequest("/users/file-transfers")
      .then((data) => setTransfers(data.transfers || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function handleDownload(id, originalName) {
    setDownloadError("");
    setDownloadingId(id);
    try {
      await apiDownload(`/users/file-transfers/${id}/download`, originalName || `file-${id}`);
    } catch (err) {
      setDownloadError(err.message);
    } finally {
      setDownloadingId(null);
    }
  }

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return transfers;
    return transfers.filter((t) =>
      [t.originalName, t.doctorName, t.note, FILE_TYPE_LABEL[t.fileType] || t.fileType]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q))
    );
  }, [transfers, query]);

  return (
    <div className="dash-card glass pd-panel">
      <PageHeader
        icon={Download}
        title={tr("فایل‌های دریافتی")}
        subtitle={tr("اسناد و فایل‌های صحی که داکترهای شما برایتان ارسال کرده‌اند.")}
        actions={
          !loading && !error && transfers.length > 0 ? <Badge tone="neutral">{transfers.length} {tr("فایل")}</Badge> : null
        }
      />

      {downloadError && <Notice type="error">{downloadError}</Notice>}

      {loading && <SkeletonBlock rows={5} label={tr("در حال بارگذاری فایل‌ها")} />}

      {!loading && error && <ErrorState message={error} onRetry={load} />}

      {!loading && !error && transfers.length === 0 && (
        <EmptyState
          icon={Inbox}
          title={tr("فایلی دریافت نکرده‌اید")}
          description={tr("هنوز هیچ فایلی برای شما ارسال نشده است. فایل‌های ارسالی داکتر در همین بخش نمایش داده می‌شود.")}
        />
      )}

      {!loading && !error && transfers.length > 0 && (
        <>
          <div className="pd-toolbar">
            <div className="pd-search">
              <Search size={16} aria-hidden="true" />
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={tr("جستجو در نام فایل، داکتر یا یادداشت...")}
                aria-label={tr("جستجو در فایل‌ها")}
              />
            </div>
            {query && <span className="pd-result-count">{filtered.length} {tr("نتیجه")}</span>}
          </div>

          {filtered.length === 0 ? (
            <NoResults onReset={() => setQuery("")} />
          ) : (
            <div className="pd-table-wrap">
              <table className="pd-table">
                <thead>
                  <tr>
                    <th>{tr("فایل")}</th>
                    <th>{tr("نوع")}</th>
                    <th>{tr("حجم")}</th>
                    <th>{tr("داکتر")}</th>
                    <th>{tr("یادداشت")}</th>
                    <th>{tr("تاریخ دریافت")}</th>
                    <th>{tr("عملیات")}</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((t) => {
                    const { Icon, cls } = fileVisual(t.fileType);
                    const hp = highlightRowProps(t.id);
                    const busy = downloadingId === t.id;
                    return (
                      <tr key={t.id} className={hp.className || undefined} ref={hp.ref}>
                        <td data-label={tr("فایل")}>
                          <div className="pd-file-cell">
                            <span className={`pd-file-icon ${cls}`} aria-hidden="true">
                              <Icon size={18} />
                            </span>
                            <div className="pd-cell-main">
                              <strong>{t.originalName}</strong>
                            </div>
                          </div>
                        </td>
                        <td data-label={tr("نوع")}>
                          <Badge tone="neutral">{FILE_TYPE_LABEL[t.fileType] || t.fileType}</Badge>
                        </td>
                        <td data-label={tr("حجم")} className="pd-num">{formatFileSize(t.fileSize)}</td>
                        <td data-label={tr("داکتر")}>{t.doctorName || "—"}</td>
                        <td data-label={tr("یادداشت")}>{t.note || "—"}</td>
                        <td data-label={tr("تاریخ دریافت")} className="pd-num">{fmtDate(t.createdAt)}</td>
                        <td data-label="">
                          <button
                            type="button"
                            className="btn btn-ghost btn-sm"
                            disabled={busy}
                            onClick={() => handleDownload(t.id, t.originalName)}
                            aria-label={tr("دانلود {0}", [t.originalName])}
                          >
                            {busy ? <ButtonSpinner /> : <Download size={14} aria-hidden="true" />}
                            {busy ? tr("در حال دانلود...") : tr("دانلود")}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}


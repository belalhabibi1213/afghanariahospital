import { } from "react";
import { } from "react-router-dom";
import {
  Activity,
  CalendarPlus,
  ClipboardList,
  Download,
  History,
  Lock,
  MessageCircle,
  Pencil,
  Pill,
  Receipt,
  User,
} from "lucide-react";
import DashboardShell from "../../../components/dashboard/DashboardShell.jsx";
import ChatWithDoctor from "../../../components/dashboard/ChatWithDoctor.jsx";
import PatientRecordsPanel from "../../../components/dashboard/PatientRecordsPanel.jsx";
import PatientHealthRecords from "../../../components/dashboard/PatientHealthRecords.jsx";
import HealthTimeline from "../../../components/dashboard/HealthTimeline.jsx";
import { } from "../../../context/AuthContext.jsx";
import { useLanguage } from "../../../context/LanguageContext.jsx";
import { tr, trc } from "../../../i18n/tr.js";
import { } from "../../../utils/api.js";
import useTabState from "../../../hooks/useTabState.js";
import { } from "../../../utils/passwordPolicy.js";
import { } from "../../../utils/persianName.js";

import { } from "../../../components/JalaliDateInput.jsx";
import { } from "../../../utils/jalali.js";
import { ProfileView, EditProfile } from "./ProfilePanels.jsx";
import { BookAppointment, AppointmentHistory } from "./AppointmentPanels.jsx";
import { ReceivedFilesPanel } from "./ReceivedFilesPanel.jsx";
import { MyBilling } from "./MyBilling.jsx";
import { ChangePassword } from "./ChangePassword.jsx";
const NAV_ICON_SIZE = 18;

// ترتیب تب‌ها بر اساس اهمیت/کاربرد: پروفایل ← نوبت‌ها و گفتگو ← سوابق طبی ← فایل‌ها و مالی ← تنظیمات حساب
const TABS = trc([
  { key: "profile", label: "پروفایل من", icon: <User size={NAV_ICON_SIZE} /> },
  { key: "book", label: "گرفتن وقت جدید", icon: <CalendarPlus size={NAV_ICON_SIZE} /> },
  { key: "history", label: "تاریخچه نوبت‌ها", icon: <History size={NAV_ICON_SIZE} /> },
  { key: "chat", label: "گفتگو با داکتر", icon: <MessageCircle size={NAV_ICON_SIZE} /> },
  { key: "records", label: "نسخه و سوابق طبی", icon: <Pill size={NAV_ICON_SIZE} /> },
  { key: "healthRecords", label: "پرونده‌های صحی من", icon: <ClipboardList size={NAV_ICON_SIZE} /> },
  { key: "timeline", label: "خط زمانی خدمات صحی", icon: <Activity size={NAV_ICON_SIZE} /> },
  { key: "files", label: "فایل‌های دریافتی", icon: <Download size={NAV_ICON_SIZE} /> },
  { key: "billing", label: "صورت‌حساب من", icon: <Receipt size={NAV_ICON_SIZE} /> },
  { key: "edit", label: "ویرایش اطلاعات", icon: <Pencil size={NAV_ICON_SIZE} /> },
  { key: "password", label: "تغییر رمز عبور", icon: <Lock size={NAV_ICON_SIZE} /> },
]);


export default function UserDashboard() {
  const [activeTab, setActiveTab] = useTabState("profile");
  const { lang } = useLanguage();

  return (
    <DashboardShell
      key={lang}
      title={tr("داشبورد بیمار")}
      tabs={TABS}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      variant="patient"
    >
      {activeTab === "profile" && <ProfileView />}
      {activeTab === "edit" && <EditProfile />}
      {activeTab === "book" && <BookAppointment />}
      {activeTab === "history" && <AppointmentHistory />}
      {activeTab === "chat" && <ChatWithDoctor />}
      {activeTab === "records" && <PatientRecordsPanel />}
      {activeTab === "healthRecords" && <PatientHealthRecords />}
      {activeTab === "timeline" && <HealthTimeline />}
      {activeTab === "files" && <ReceivedFilesPanel />}
      {activeTab === "billing" && <MyBilling />}
      {activeTab === "password" && <ChangePassword />}
    </DashboardShell>
  );
}


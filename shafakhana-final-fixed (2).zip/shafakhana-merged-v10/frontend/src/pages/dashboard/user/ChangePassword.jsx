import { useState } from "react";
import { } from "react-router-dom";
import {
  CircleCheck,
  Eye,
  EyeOff,
  Info,
  Lock,
} from "lucide-react";
import { FormField, Notice, PageHeader } from "../../../components/dashboard/patient/pdUi.jsx";
import { } from "../../../context/AuthContext.jsx";
import { } from "../../../context/LanguageContext.jsx";
import { tr } from "../../../i18n/tr.js";
import { apiRequest } from "../../../utils/api.js";
import { getPasswordError, PASSWORD_HINT_FA } from "../../../utils/passwordPolicy.js";
import { } from "../../../utils/persianName.js";

import { } from "../../../components/JalaliDateInput.jsx";
import { } from "../../../utils/jalali.js";
import { ButtonSpinner } from "./userShared.jsx";

// راهنمای قدرت رمز عبور — فقط یک شاخص بصری است؛ شرط پذیرش همچنان فقط
// getPasswordError (همان سیاست فعلی فرانت/بک‌اند) است و هیچ قانون جدیدی اعمال نمی‌شود.
export function passwordStrength(pw) {
  if (!pw) return { level: 0, label: "" };
  if (getPasswordError(pw)) return { level: 1, label: tr("ضعیف (طبق قوانین معتبر نیست)") };
  let score = 1; // حداقل شرایط سیاست برقرار است
  if (pw.length >= 12) score += 1;
  if (/[A-Za-z]/.test(pw) && /\d/.test(pw)) score += 1;
  if (/[^A-Za-z0-9]/.test(pw) && /[A-Z]/.test(pw) && /[a-z]/.test(pw)) score += 1;
  else if (pw.length >= 16) score += 1;
  const level = Math.min(4, score);
  const labels = { 1: tr("قابل‌قبول"), 2: tr("متوسط"), 3: tr("خوب"), 4: tr("قوی") };
  return { level, label: labels[level] };
}

export function PasswordInput({ id, value, onChange, show, onToggle, autoComplete, invalid, describedBy }) {
  return (
    <div className="pd-password-wrap">
      <input
        id={id}
        type={show ? "text" : "password"}
        value={value}
        onChange={onChange}
        autoComplete={autoComplete}
        aria-invalid={invalid ? true : undefined}
        aria-describedby={describedBy}
      />
      <button
        type="button"
        className="pd-password-toggle"
        onClick={onToggle}
        aria-label={show ? tr("پنهان‌کردن رمز عبور") : tr("نمایش رمز عبور")}
        aria-pressed={show}
      >
        {show ? <EyeOff size={17} /> : <Eye size={17} />}
      </button>
    </div>
  );
}

export function ChangePassword() {
  const [form, setForm] = useState({ currentPassword: "", newPassword: "", confirm: "" });
  const [show, setShow] = useState({ currentPassword: false, newPassword: false, confirm: false });
  const [fieldErrors, setFieldErrors] = useState({});
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);

  const strength = passwordStrength(form.newPassword);
  const lenOk = form.newPassword.length >= 8;
  // اگر رمز فقط کوتاه باشد ولی کاراکترهای مجاز داشته باشد، با padding بررسی کاراکترها جدا می‌شود
  const charsOk = form.newPassword.length > 0 && getPasswordError(form.newPassword.padEnd(8, "a")) === "";
  const mismatch = form.confirm.length > 0 && form.newPassword !== form.confirm;
  const incomplete = !form.currentPassword || !form.newPassword || !form.confirm;

  function updateField(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
    if (fieldErrors[key]) setFieldErrors((f) => ({ ...f, [key]: "" }));
    if (status.text) setStatus({ type: "", text: "" });
  }

  const toggle = (key) => setShow((s) => ({ ...s, [key]: !s[key] }));

  async function handleSubmit(e) {
    e.preventDefault();
    if (loading) return; // جلوگیری از ارسال هم‌زمان
    setStatus({ type: "", text: "" });

    const errs = {};
    if (!form.currentPassword) errs.currentPassword = tr("رمز عبور فعلی الزامی است.");
    const passwordError = getPasswordError(form.newPassword);
    if (passwordError) errs.newPassword = tr(passwordError);
    if (!form.confirm) {
      errs.confirm = tr("تکرار رمز عبور جدید الزامی است.");
    } else if (form.newPassword !== form.confirm) {
      errs.confirm = tr("رمز عبور جدید و تکرار آن یکسان نیست.");
    }
    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) return;

    setLoading(true);
    try {
      const data = await apiRequest("/users/change-password", {
        method: "PUT",
        body: { currentPassword: form.currentPassword, newPassword: form.newPassword } });
      setStatus({ type: "success", text: data.message });
      // پاک‌سازی امن: همه‌ی فیلدهای رمز و حالت «نمایش رمز» بعد از موفقیت ریست می‌شوند
      setForm({ currentPassword: "", newPassword: "", confirm: "" });
      setShow({ currentPassword: false, newPassword: false, confirm: false });
      setFieldErrors({});
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="dash-card glass pd-panel">
      <PageHeader
        icon={Lock}
        title={tr("تغییر رمز عبور")}
        subtitle={tr("برای امنیت بیشتر حساب، رمز عبور خود را به‌صورت دوره‌ای تغییر دهید.")}
      />

      <div className="pd-narrow pd-panel">
        <div className="pd-security-note">
          <Info size={18} aria-hidden="true" />
          <span>
            {tr("رمز عبور خود را با هیچ‌کس به اشتراک نگذارید و از رمزی که در سایت‌های دیگر استفاده می‌کنید استفاده نکنید. پس از تغییر، همان رمز جدید برای ورود بعدی لازم است.")}
          </span>
        </div>

        <form className="pd-form" onSubmit={handleSubmit} noValidate>
          <Notice type={status.type === "success" ? "success" : "error"}>{status.text}</Notice>

          <FormField id="pd-pw-current" label={tr("رمز عبور فعلی")} required error={fieldErrors.currentPassword}>
            <PasswordInput
              id="pd-pw-current"
              value={form.currentPassword}
              onChange={(e) => updateField("currentPassword", e.target.value)}
              show={show.currentPassword}
              onToggle={() => toggle("currentPassword")}
              autoComplete="current-password"
              invalid={!!fieldErrors.currentPassword}
              describedBy={fieldErrors.currentPassword ? "pd-pw-current-error" : undefined}
            />
          </FormField>

          <FormField id="pd-pw-new" label={tr("رمز عبور جدید")} required error={fieldErrors.newPassword} hint={tr(PASSWORD_HINT_FA)}>
            <PasswordInput
              id="pd-pw-new"
              value={form.newPassword}
              onChange={(e) => updateField("newPassword", e.target.value)}
              show={show.newPassword}
              onToggle={() => toggle("newPassword")}
              autoComplete="new-password"
              invalid={!!fieldErrors.newPassword}
              describedBy={fieldErrors.newPassword ? "pd-pw-new-error" : undefined}
            />
            {form.newPassword && (
              <div className="pd-strength" data-level={strength.level}>
                <div className="pd-strength-bar" aria-hidden="true">
                  <span /><span /><span /><span />
                </div>
                <span className="pd-strength-text">{tr("قدرت رمز (راهنما):")} {strength.label}</span>
              </div>
            )}
            <ul className="pd-rules" aria-label={tr("شرایط رمز عبور")}>
              <li className={lenOk ? "ok" : ""}>
                <CircleCheck size={14} aria-hidden="true" /> {tr("حداقل ۸ کاراکتر")}
              </li>
              <li className={charsOk ? "ok" : ""}>
                <CircleCheck size={14} aria-hidden="true" /> {tr("فقط حروف انگلیسی، عدد و کاراکترهای مجاز")}
              </li>
            </ul>
          </FormField>

          <FormField
            id="pd-pw-confirm"
            label={tr("تکرار رمز عبور جدید")}
            required
            error={fieldErrors.confirm || (mismatch ? tr("رمز عبور جدید و تکرار آن یکسان نیست.") : "")}
          >
            <PasswordInput
              id="pd-pw-confirm"
              value={form.confirm}
              onChange={(e) => updateField("confirm", e.target.value)}
              show={show.confirm}
              onToggle={() => toggle("confirm")}
              autoComplete="new-password"
              invalid={!!fieldErrors.confirm || mismatch}
              describedBy={fieldErrors.confirm || mismatch ? "pd-pw-confirm-error" : undefined}
            />
          </FormField>

          <div>
            <button className="btn btn-primary" disabled={loading || incomplete || mismatch} type="submit">
              {loading && <ButtonSpinner />}
              {loading ? tr("در حال ذخیره...") : tr("تغییر رمز عبور")}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}


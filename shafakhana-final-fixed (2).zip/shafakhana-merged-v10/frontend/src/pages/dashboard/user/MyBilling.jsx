import { useCallback, useEffect, useMemo, useState } from "react";
import { } from "react-router-dom";
import {
  CircleCheck,
  Clock,
  Eye,
  Receipt,
  Wallet } from "lucide-react";
import GlobalModal from "../../../components/GlobalModal.jsx";
import InvoiceDetail, { INVOICE_STATUS_LABEL, getApprovalStatusKey } from "../../../components/dashboard/InvoiceDetail.jsx";
import {
  Badge,
  EmptyState,
  ErrorState,
  Notice,
  PageHeader,
  SkeletonBlock,
  SkeletonStats,
  StatCard } from "../../../components/dashboard/patient/pdUi.jsx";
import { } from "../../../context/AuthContext.jsx";
import { } from "../../../context/LanguageContext.jsx";
import { tr, trc } from "../../../i18n/tr.js";
import { apiRequest } from "../../../utils/api.js";
import useHighlightParam from "../../../hooks/useHighlightParam.js";
import { } from "../../../utils/passwordPolicy.js";
import { } from "../../../utils/persianName.js";

import { } from "../../../components/JalaliDateInput.jsx";
import { } from "../../../utils/jalali.js";
import { money, fmtDate, ButtonSpinner } from "./userShared.jsx";
import { ListPager, fmtNum } from "../doctor/doctorListUi.jsx";

// نسخه‌ها و سوابق طبی بیمار — به‌صورت خودکار همان نسخه‌ها/رکوردهایی را نشان می‌دهد
// که داکتر از پنل خودش ثبت کرده (الزام شماره ۱ و ۲: اتصال پرونده داکتر به داشبورد بیمار).
// از GET /api/users/emr استفاده می‌شود که همیشه بر اساس req.user.id فیلتر می‌شود،
// یعنی بیمار فقط پرونده‌ی خودش را می‌بیند (الزام شماره ۳)، نه بیماران دیگر را.
// ---------- صورت‌حساب من (الزام شماره ۵: مشاهده سوابق صورت‌حساب توسط بیمار) ----------
export const PAYMENT_LABEL = trc({
  unpaid: "پرداخت‌نشده",
  partial: "پرداخت جزئی",
  paid: "پرداخت‌شده",
  cancelled: "لغوشده" });
export const PAYMENT_TONE = { unpaid: "danger", partial: "warning", paid: "success", cancelled: "neutral" };
export const APPROVAL_TONE = { pending: "warning", approved: "success", cancelled: "danger" };

export function MyBilling() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [actionError, setActionError] = useState("");
  const [openingId, setOpeningId] = useState(null);
  const [selected, setSelected] = useState(null);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10); // تعداد فاکتور در هر صفحه (۱۰ / ۲۰ / ۵۰)
  const { highlightRowProps } = useHighlightParam();

  const load = useCallback(() => {
    setLoading(true);
    setError("");
    apiRequest("/users/invoices")
      .then((data) => setInvoices(data.invoices || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function openDetail(id) {
    setActionError("");
    setOpeningId(id);
    try {
      const data = await apiRequest(`/users/invoices/${id}`);
      setSelected(data.invoice);
    } catch (err) {
      setActionError(err.message);
    } finally {
      setOpeningId(null);
    }
  }

  // خلاصه‌ی مالی — فقط جمع مقادیر واقعی همین فاکتورها (فاکتورهای لغوشده در جمع‌ها حساب نمی‌شوند)
  // صفحه‌بندی سمت کلاینت (کل فاکتورهای کاربر یک‌جا دریافت می‌شود)
  const totalPages = Math.max(1, Math.ceil(invoices.length / limit));
  const currentPage = Math.min(page, totalPages);
  const pageRows = invoices.slice((currentPage - 1) * limit, currentPage * limit);

  const summary = useMemo(() => {
    const active = invoices.filter((i) => i.status !== "cancelled");
    const total = active.reduce((s, i) => s + Number(i.totalAmount || 0), 0);
    const paid = active.reduce((s, i) => s + Number(i.paidAmount || 0), 0);
    return { count: invoices.length, total, paid, remaining: Math.max(0, total - paid) };
  }, [invoices]);

  return (
    <div className="dash-card glass pd-panel">
      <PageHeader
        icon={Receipt}
        title={tr("صورت‌حساب من")}
        subtitle={tr("فاکتورهای صادرشده برای شما، وضعیت تایید و پرداخت")}
      />

      {loading && (
        <>
          <SkeletonStats count={4} />
          <SkeletonBlock rows={5} label={tr("در حال بارگذاری صورت‌حساب‌ها")} />
        </>
      )}

      {!loading && error && <ErrorState message={error} onRetry={load} />}

      {!loading && !error && invoices.length === 0 && (
        <EmptyState
          icon={Receipt}
          title={tr("فاکتوری ثبت نشده است")}
          description={tr("هیچ فاکتوری برای شما ثبت نشده است. فاکتورهای شما پس از صدور در همین بخش نمایش داده می‌شود.")}
        />
      )}

      {!loading && !error && invoices.length > 0 && (
        <>
          <div className="pd-stats">
            <StatCard icon={Receipt} label={tr("تعداد صورت‌حساب‌ها")} value={summary.count} />
            <StatCard icon={Wallet} label={tr("مجموع مبلغ")} value={money(summary.total)} hint={tr("بدون فاکتورهای لغوشده")} />
            <StatCard icon={CircleCheck} label={tr("پرداخت‌شده")} value={money(summary.paid)} tone="success" />
            <StatCard
              icon={Clock}
              label={tr("باقی‌مانده")}
              value={money(summary.remaining)}
              tone={summary.remaining > 0 ? "warning" : "success"}
            />
          </div>

          {actionError && <Notice type="error">{actionError}</Notice>}

          <div className="pd-table-wrap">
            <table className="pd-table">
              <thead>
                <tr>
                  <th className="pd-num-col">#</th>
                  <th>{tr("شماره فاکتور")}</th>
                  <th>{tr("تاریخ")}</th>
                  <th>{tr("مبلغ کل")}</th>
                  <th>{tr("پرداخت‌شده")}</th>
                  <th>{tr("باقی‌مانده")}</th>
                  <th>{tr("وضعیت")}</th>
                  <th>{tr("پرداخت")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {pageRows.map((inv, idx) => {
                  const approvalKey = getApprovalStatusKey(inv);
                  const cancelled = inv.status === "cancelled";
                  const remaining = Math.max(0, Number(inv.totalAmount || 0) - Number(inv.paidAmount || 0));
                  const hp = highlightRowProps(inv.id);
                  return (
                    <tr key={inv.id} className={hp.className || undefined} ref={hp.ref}>
                      <td data-label="#" className="pd-num pd-num-col">{fmtNum((currentPage - 1) * limit + idx + 1)}</td>
                      <td data-label={tr("شماره فاکتور")}>
                        <div className="pd-cell-main">
                          <strong dir="ltr" style={{ textAlign: "right" }}>{inv.invoiceNumber}</strong>
                          {inv.doctorName && <span className="pd-cell-sub">{inv.doctorName}</span>}
                        </div>
                      </td>
                      <td data-label={tr("تاریخ")} className="pd-num">{fmtDate(inv.issueDate)}</td>
                      <td data-label={tr("مبلغ کل")} className="pd-num">{money(inv.totalAmount)}</td>
                      <td data-label={tr("پرداخت‌شده")} className="pd-num">{money(inv.paidAmount)}</td>
                      <td data-label={tr("باقی‌مانده")} className={`pd-num ${!cancelled && remaining > 0 ? "pd-remaining-due" : ""}`}>
                        {cancelled ? "—" : money(remaining)}
                      </td>
                      <td data-label={tr("وضعیت")}>
                        <Badge tone={APPROVAL_TONE[approvalKey] || "neutral"}>{INVOICE_STATUS_LABEL[approvalKey]}</Badge>
                      </td>
                      <td data-label={tr("پرداخت")}>
                        {PAYMENT_LABEL[inv.status] ? (
                          <Badge tone={PAYMENT_TONE[inv.status] || "neutral"}>{PAYMENT_LABEL[inv.status]}</Badge>
                        ) : (
                          "—"
                        )}
                      </td>
                      <td data-label="">
                        <button
                          type="button"
                          className="btn btn-ghost btn-sm"
                          disabled={openingId === inv.id}
                          onClick={() => openDetail(inv.id)}
                        >
                          {openingId === inv.id ? <ButtonSpinner /> : <Eye size={14} aria-hidden="true" />}
                          {tr("مشاهده / چاپ")}
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            <ListPager
              pagination={{ total: invoices.length, page: currentPage, totalPages }}
              limit={limit}
              sizes={[10, 20, 50]}
              noun={tr("فاکتور")}
              onPage={setPage}
              onLimit={(n) => { setLimit(n); setPage(1); }}
            />
          </div>
        </>
      )}

      <GlobalModal
        isOpen={!!selected}
        onClose={() => setSelected(null)}
        size="lg"
        title={tr("جزئیات فاکتور")}
        labelledBy="my-invoice-detail-title"
      >
        {selected && <InvoiceDetail invoice={selected} onClose={() => setSelected(null)} />}
      </GlobalModal>
    </div>
  );
}


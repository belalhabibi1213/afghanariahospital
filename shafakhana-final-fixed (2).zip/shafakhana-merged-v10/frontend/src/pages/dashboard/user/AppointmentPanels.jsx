import { useCallback, useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  CalendarClock,
  CalendarDays,
  CalendarPlus,
  CalendarX,
  CircleCheck,
  Eye,
  History,
  Search,
} from "lucide-react";
import GlobalModal from "../../../components/GlobalModal.jsx";
import {
  Badge,
  EmptyState,
  ErrorState,
  InfoItem,
  NoResults,
  Notice,
  PageHeader,
  SkeletonBlock,
  SkeletonStats,
  StatCard } from "../../../components/dashboard/patient/pdUi.jsx";
import { } from "../../../context/AuthContext.jsx";
import { } from "../../../context/LanguageContext.jsx";
import { tr } from "../../../i18n/tr.js";
import { apiRequest } from "../../../utils/api.js";
import useHighlightParam from "../../../hooks/useHighlightParam.js";
import { } from "../../../utils/passwordPolicy.js";
import { } from "../../../utils/persianName.js";

import { JalaliDateInput } from "../../../components/JalaliDateInput.jsx";
import { } from "../../../utils/jalali.js";
import { ListPager, fmtNum } from "../doctor/doctorListUi.jsx";
import { todayLocalISO, fmtDate, fmtTime, STATUS_LABEL, APPT_BADGE } from "./userShared.jsx";

export function BookAppointment() {
  return (
    <div className="dash-card glass">
      <h2>{tr("گرفتن وقت جدید")}</h2>
      <p>{tr("برای گرفتن وقت جدید از فورمه نوبت‌دهی در صفحه اصلی استفاده کنید. اطلاعات حساب شما به‌صورت خودکار به نوبت متصل می‌شود.")}</p>
      <Link to="/home#appointment" className="btn btn-primary" style={{ display: "inline-block", marginTop: 10 }}>
        {tr("رفتن به فورمه نوبت‌دهی")}
      </Link>
    </div>
  );
}

export function AppointmentHistory() {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [error, setError] = useState(""); // خطای عملیات (مثل لغو نوبت)
  const [confirmingId, setConfirmingId] = useState(null); // نوبتی که منتظر تایید لغو است
  const [cancellingId, setCancellingId] = useState(null);
  const [selected, setSelected] = useState(null); // نوبت انتخاب‌شده برای نمایش جزئیات
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10); // تعداد نوبت در هر صفحه (۱۰ / ۲۰ / ۵۰)
  const { highlightRowProps } = useHighlightParam();

  const load = useCallback(() => {
    setLoading(true);
    setLoadError("");
    apiRequest("/users/appointments")
      .then((data) => setAppointments(data.appointments || []))
      .catch((err) => setLoadError(err.message))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  // لغو نوبت توسط خودِ بیمار (سرور شرایط مجاز بودن و مهلت لغو را بررسی می‌کند)
  async function cancelAppointment(id) {
    setCancellingId(id);
    setError("");
    try {
      await apiRequest(`/appointments/${id}/cancel`, { method: "POST" });
      setAppointments((list) => list.map((a) => (a.id === id ? { ...a, status: "cancelled" } : a)));
      setSelected((s) => (s && s.id === id ? { ...s, status: "cancelled" } : s));
      setConfirmingId(null);
    } catch (err) {
      setError(err.message);
      setConfirmingId(null);
    } finally {
      setCancellingId(null);
    }
  }

  // آمار خلاصه — فقط از همان نوبت‌های واقعی محاسبه می‌شود
  const stats = useMemo(() => {
    const today = todayLocalISO();
    return {
      total: appointments.length,
      upcoming: appointments.filter(
        (a) => (a.status === "pending" || a.status === "confirmed") && fmtDate(a.appointmentDate) >= today
      ).length,
      completed: appointments.filter((a) => a.status === "completed").length,
      cancelled: appointments.filter((a) => a.status === "cancelled").length };
  }, [appointments]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return appointments.filter((a) => {
      if (statusFilter !== "all" && a.status !== statusFilter) return false;
      const d = fmtDate(a.appointmentDate);
      if (dateFrom && d < dateFrom) return false;
      if (dateTo && d > dateTo) return false;
      if (!q) return true;
      return [a.doctorName, a.department, STATUS_LABEL[a.status], a.notes]
        .filter(Boolean)
        .some((v) => String(v).toLowerCase().includes(q));
    });
  }, [appointments, query, statusFilter, dateFrom, dateTo]);

  // صفحه‌بندی سمت کلاینت (کل نوبت‌های کاربر یک‌جا دریافت می‌شود)
  const totalPages = Math.max(1, Math.ceil(filtered.length / limit));
  const currentPage = Math.min(page, totalPages);
  const pageRows = filtered.slice((currentPage - 1) * limit, currentPage * limit);
  // با تغییر جستجو/فیلتر، به صفحه‌ی اول برگرد
  useEffect(() => { setPage(1); }, [query, statusFilter, dateFrom, dateTo]);

  const hasFilter = query || statusFilter !== "all" || dateFrom || dateTo;
  function resetFilters() {
    setQuery("");
    setStatusFilter("all");
    setDateFrom("");
    setDateTo("");
  }

  const canCancel = (a) => a.status === "pending" || a.status === "confirmed";

  function renderCancelControls(a) {
    if (!canCancel(a)) return null;
    if (confirmingId === a.id) {
      return (
        <span className="pd-confirm">
          <span>{tr("مطمئن هستید؟")}</span>
          <button type="button" className="btn btn-danger btn-sm" disabled={cancellingId === a.id} onClick={() => cancelAppointment(a.id)}>
            {cancellingId === a.id ? tr("در حال لغو...") : tr("بله، لغو شود")}
          </button>
          <button type="button" className="btn btn-ghost btn-sm" disabled={cancellingId === a.id} onClick={() => setConfirmingId(null)}>
            {tr("انصراف")}
          </button>
        </span>
      );
    }
    return (
      <button type="button" className="btn btn-ghost btn-sm" onClick={() => setConfirmingId(a.id)}>
        {tr("لغو نوبت")}
      </button>
    );
  }

  const badgeFor = (status) => {
    const cfg = APPT_BADGE[status] || { tone: "neutral", icon: null };
    return (
      <Badge tone={cfg.tone} icon={cfg.icon}>
        {STATUS_LABEL[status] || status}
      </Badge>
    );
  };

  return (
    <div className="dash-card glass pd-panel">
      <PageHeader
        icon={History}
        title={tr("تاریخچه نوبت‌های من")}
        subtitle={tr("همه‌ی نوبت‌های ثبت‌شده‌ی شما با وضعیت و جزئیات")}
        actions={
          <Link to="/home#appointment" className="btn btn-primary btn-sm">
            <CalendarPlus size={14} aria-hidden="true" />
            {tr("گرفتن نوبت جدید")}
          </Link>
        }
      />

      {loading && (
        <>
          <SkeletonStats count={4} />
          <SkeletonBlock rows={5} label={tr("در حال بارگذاری نوبت‌ها")} />
        </>
      )}

      {!loading && loadError && <ErrorState message={loadError} onRetry={load} />}

      {!loading && !loadError && appointments.length === 0 && (
        <EmptyState
          icon={CalendarDays}
          title={tr("نوبتی ثبت نشده است")}
          description={tr("تا کنون نوبتی ثبت نکرده‌اید. پس از ثبت نوبت، تاریخچه‌ی آن در همین بخش نمایش داده می‌شود.")}
          action={
            <Link to="/home#appointment" className="btn btn-primary btn-sm">
              {tr("رفتن به فرم نوبت‌دهی")}
            </Link>
          }
        />
      )}

      {!loading && !loadError && appointments.length > 0 && (
        <>
          <div className="pd-stats">
            <StatCard icon={CalendarDays} label={tr("مجموع نوبت‌ها")} value={stats.total} />
            <StatCard icon={CalendarClock} label={tr("نوبت‌های آینده")} value={stats.upcoming} tone="success" />
            <StatCard icon={CircleCheck} label={tr("تکمیل‌شده")} value={stats.completed} tone="info" />
            <StatCard icon={CalendarX} label={tr("لغوشده")} value={stats.cancelled} tone="danger" />
          </div>

          {error && <Notice type="error">{error}</Notice>}

          <div className="pd-toolbar">
            <div className="pd-search">
              <Search size={16} aria-hidden="true" />
              <input
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={tr("جستجو در نام داکتر، بخش یا یادداشت...")}
                aria-label={tr("جستجو در نوبت‌ها")}
              />
            </div>
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={tr("فیلتر وضعیت")}>
              <option value="all">{tr("همه‌ی وضعیت‌ها")}</option>
              {Object.entries(STATUS_LABEL).map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
            <label className="pd-toolbar-label">
              {tr("از")}
              <JalaliDateInput value={dateFrom} max={dateTo || undefined} onChange={(e) => setDateFrom(e.target.value)} aria-label={tr("از تاریخ")} />
            </label>
            <label className="pd-toolbar-label">
              {tr("تا")}
              <JalaliDateInput value={dateTo} min={dateFrom || undefined} onChange={(e) => setDateTo(e.target.value)} aria-label={tr("تا تاریخ")} />
            </label>
            {hasFilter && <span className="pd-result-count">{filtered.length} {tr("نتیجه")}</span>}
          </div>

          {filtered.length === 0 ? (
            <NoResults onReset={resetFilters} />
          ) : (
            <div className="pd-table-wrap">
              <table className="pd-table">
                <thead>
                  <tr>
                    <th className="pd-num-col">#</th>
                    <th>{tr("داکتر")}</th>
                    <th>{tr("تاریخ")}</th>
                    <th>{tr("ساعت")}</th>
                    <th>{tr("وضعیت")}</th>
                    <th>{tr("عملیات")}</th>
                  </tr>
                </thead>
                <tbody>
                  {pageRows.map((a, idx) => {
                    const hp = highlightRowProps(a.id);
                    return (
                      <tr key={a.id} className={hp.className || undefined} ref={hp.ref}>
                        <td data-label="#" className="pd-num pd-num-col">{fmtNum((currentPage - 1) * limit + idx + 1)}</td>
                        <td data-label={tr("داکتر")}>
                          <div className="pd-cell-main">
                            <strong>{a.doctorName}</strong>
                            {a.department && <span className="pd-cell-sub">{a.department}</span>}
                          </div>
                        </td>
                        <td data-label={tr("تاریخ")} className="pd-num">{fmtDate(a.appointmentDate)}</td>
                        <td data-label={tr("ساعت")} className="pd-num">{fmtTime(a.appointmentTime)}</td>
                        <td data-label={tr("وضعیت")}>{badgeFor(a.status)}</td>
                        <td data-label="">
                          <div className="pd-actions">
                            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setSelected(a)}>
                              <Eye size={14} aria-hidden="true" />
                              {tr("جزئیات")}
                            </button>
                            {renderCancelControls(a)}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
              <ListPager
                pagination={{ total: filtered.length, page: currentPage, totalPages }}
                limit={limit}
                sizes={[10, 20, 50]}
                noun={tr("نوبت")}
                onPage={setPage}
                onLimit={(n) => { setLimit(n); setPage(1); }}
              />
            </div>
          )}
        </>
      )}

      <GlobalModal
        isOpen={!!selected}
        onClose={() => setSelected(null)}
        size="md"
        title={tr("جزئیات نوبت")}
        labelledBy="my-appointment-detail-title"
      >
        {selected && (
          <div className="pd-modal-scope">
            <div className="pd-detail-list">
              <InfoItem label={tr("داکتر")} value={selected.doctorName} />
              <InfoItem label={tr("بخش")} value={selected.department} />
              <InfoItem label={tr("تاریخ")} value={fmtDate(selected.appointmentDate)} />
              <InfoItem label={tr("ساعت")} value={fmtTime(selected.appointmentTime)} />
              <div className="pd-info-item">
                <span className="pd-info-label">{tr("وضعیت")}</span>
                <span>{badgeFor(selected.status)}</span>
              </div>
              <InfoItem label={tr("تاریخ ثبت")} value={fmtDate(selected.createdAt)} />
              {selected.notes && (
                <div className="pd-info-item pd-detail-notes">
                  <span className="pd-info-label">{tr("یادداشت")}</span>
                  <strong className="pd-info-value">{selected.notes}</strong>
                </div>
              )}
            </div>
            {canCancel(selected) && (
              <div className="pd-actions" style={{ marginTop: 16 }}>
                {renderCancelControls(selected)}
              </div>
            )}
          </div>
        )}
      </GlobalModal>
    </div>
  );
}


// اجزای مشترک دو بخش «برنامه کاری من» و «نوبت‌های من» در داشبورد داکتر
// (منوی چاپ/خروجی، قالب‌بندی نمایشی اعداد/ساعت، Skeleton و خروجی PDF).
// فقط نمایش را تغییر می‌دهد؛ مقدار واقعی داده‌ی Backend هیچ‌جا دست نمی‌خورد.
import { useEffect, useRef, useState } from "react";
import { ChevronDown, FileSpreadsheet, FileText, Loader2, Printer } from "lucide-react";
import "./doctorWorkspaceUi.css";
import { isScrollbarClick } from "../../../utils/scrollbarClick.js";

import { tr, jdate, tdigits } from "../../../i18n/tr.js";
import { getCurrentLang } from "../../../i18n/languages.js";
import { translateDepartmentName } from "../../../i18n/departmentNames.js";
import { translateDoctorName } from "../../../i18n/dataTranslate.js";
export const toFa = (value) => tdigits(String(value ?? ""));
export const fmtTime = (t) => (t ? toFa(String(t).slice(0, 5)) : "—");
// نام بخش و نام داکتر در دیتابیس به دری ذخیره می‌شود؛ فقط هنگام نمایش به زبان فعلی ترجمه می‌شود (نام ناشناخته بدون تغییر).
export const dept = (name) => translateDepartmentName(name, getCurrentLang());
export const docName = (name) => translateDoctorName(name, getCurrentLang());
export const cx = (...parts) => parts.filter(Boolean).join(" ");

export function ExportMenu({ disabled, exporting, onPdf, onExcel }) {
  const [open, setOpen] = useState(false);
  const rootRef = useRef(null);

  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => { if (isScrollbarClick(e)) return; if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false); };
    const onKey = (e) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const pick = (fn) => { setOpen(false); fn(); };

  return (
    <div className="dw-menu" ref={rootRef}>
      <button
        type="button"
        className="btn btn-ghost btn-sm"
        disabled={disabled || exporting}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-busy={exporting}
        onClick={() => setOpen((o) => !o)}
      >
        {exporting ? <Loader2 size={16} className="dw-spin" aria-hidden="true" /> : <Printer size={16} aria-hidden="true" />}
        {exporting ? tr("در حال آماده‌سازی...") : tr("چاپ")}
        {!exporting && <ChevronDown size={14} aria-hidden="true" />}
      </button>
      {open && !exporting && (
        <div className="dw-menu-list" role="menu">
          <button type="button" role="menuitem" className="dw-menu-item" onClick={() => pick(onPdf)}>
            <FileText size={16} aria-hidden="true" /> {tr("خروجی PDF")}
          </button>
          <button type="button" role="menuitem" className="dw-menu-item" onClick={() => pick(onExcel)}>
            <FileSpreadsheet size={16} aria-hidden="true" /> {tr("خروجی Excel")}
          </button>
        </div>
      )}
    </div>
  );
}

// همان منطق قبلی خروجی PDF (html2canvas + jsPDF، A4 افقی، نام فایل بدون تغییر)؛
// فقط روی کپی موقتیِ جدول، کلاس dw-export (نسخه‌ی روشن) اضافه می‌شود تا PDF در
// تم تیره هم خوانا باشد. جدول واقعیِ صفحه تغییری نمی‌کند.
export async function exportElementToPdf(element, filename) {
  const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
  const canvas = await html2canvas(element, {
    scale: 2,
    backgroundColor: "#ffffff",
    onclone: (doc) => {
      const el = doc.querySelector("[data-dw-export]");
      if (el) el.classList.add("dw-export");
    },
  });
  const imgData = canvas.toDataURL("image/png");
  const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
  const pageWidth = pdf.internal.pageSize.getWidth();
  const pageHeight = pdf.internal.pageSize.getHeight();
  const imgWidth = pageWidth - 40;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;
  let heightLeft = imgHeight;
  let position = 20;
  pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
  heightLeft -= pageHeight - 40;
  while (heightLeft > 0) {
    position = heightLeft - imgHeight + 20;
    pdf.addPage();
    pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
    heightLeft -= pageHeight - 40;
  }
  pdf.save(filename);
}

export function Kpi({ icon, title, value, sub, tone = "accent" }) {
  return (
    <div className={`dw-kpi dw-tone-${tone}`}>
      <div className="dw-kpi-icon" aria-hidden="true">{icon}</div>
      <div className="dw-kpi-body">
        <span className="dw-kpi-title">{title}</span>
        <strong className="dw-kpi-value">{value}</strong>
        {sub && <span className="dw-kpi-sub">{sub}</span>}
      </div>
    </div>
  );
}

export function SkeletonKpis({ count }) {
  return (
    <div className="dw-kpis" aria-hidden="true">
      {Array.from({ length: count }).map((_, i) => <div key={i} className="dw-skel" style={{ height: 72, borderRadius: 14 }} />)}
    </div>
  );
}

export function SkeletonTable({ cols, rows = 5 }) {
  return (
    <div className="dw-skel-table" aria-hidden="true">
      {Array.from({ length: rows + 1 }).map((_, r) => (
        <div key={r} className={cx("dw-skel-row", r === 0 && "is-head")} style={{ "--cols": cols }}>
          {Array.from({ length: cols }).map((__, c) => <div key={c} className="dw-skel" />)}
        </div>
      ))}
    </div>
  );
}

// پیام خطا: عنوان ثابت فارسی + پیام کوتاه واقعیِ برگشتی از سرور (بدون ساختن خطای ساختگی)
export function errDetail(err) {
  const msg = err && err.message ? String(err.message).trim() : "";
  return msg && msg.length <= 200 ? tr(msg) : "";
}

// کمکی‌های مشترک تب‌های «بیماران من» و «انتقال معلومات بیمار»
// تاریخ نمایشی شمسی (ارقام لاتین؛ برای ارقام فارسی از toFa استفاده می‌شود)
export const dpDate = (v) => (v ? jdate(v, { latin: true }) : "");
export function dpInitials(name) {
  const words = String(name || "").trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return tr("؟");
  const first = Array.from(words[0])[0];
  const last = words.length > 1 ? Array.from(words[words.length - 1])[0] : "";
  return `${first}${last ? `\u200c${last}` : ""}`;
}

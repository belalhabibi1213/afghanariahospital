// پنل «بیماران من» (داکتر) — این فایل فقط نقطه‌ی ورودِ سازگار با کدهای قبلی است.
// کد اصلی به فایل‌های کوچک‌تر در پوشه‌ی ./patients تقسیم شده است:
//   patients/MyPatients.jsx            → لیست بیماران داکتر (فیلتر، جستجو، عملیات)
//   patients/PatientPrescriptions.jsx  → نسخه‌های یک بیمار
//   patients/PatientMedicalRecords.jsx → سوابق طبی یک بیمار
//   patients/PatientPanelHeader.jsx    → هدر مشترک پنل‌های بالا
//   patients/patientsShared.jsx        → ثابت‌ها و توابع مشترک
// استایل: DoctorPatientsPanel.css (در همین پوشه، مشترک با DoctorTransferPanel و DoctorBillingPanel)
import "./DoctorPatientsPanel.css";

export { default } from "./patients/MyPatients.jsx";

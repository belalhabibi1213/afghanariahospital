import { SYSTEMS, RECOMMENDATION_FIELDS, IMAGE_CATEGORIES, DOC_CATEGORIES, FOLLOWUP_STATUS, LAB_STATUS, GENDER_LABEL, calcBmi, bmiCategory, fmtDay, fmtDateTime, toFa } from "./hrConstants.js";
import { SecureImage } from "./hrFields.jsx";

import { tr } from "../../../../i18n/tr.js";
import { getCurrentLang } from "../../../../i18n/languages.js";
import { translateDepartmentName } from "../../../../i18n/departmentNames.js";
// نمای گزارش پرونده صحی — هم برای «جمع‌بندی نهایی» روی صفحه، هم برای چاپ A4 (variant="print") و هم برای بیمار.
// همه‌ی مقادیر از داده‌ی واقعی فرم/سرور می‌آیند؛ بخش خالی «ثبت نشده» نشان داده می‌شود (نه مقدار ساختگی).
// نسخه‌ی دارویی عمداً هیچ‌جا در این نما نیست (در بخش مستقل «نسخه و سوابق طبی» می‌ماند).
const Empty = () => <span className="hr-rv-empty">{tr("ثبت نشده")}</span>;
const Val = ({ v, ltr }) => (v ? <span dir={ltr ? "ltr" : undefined}>{v}</span> : <Empty />);

function Section({ title, children }) {
  return (
    <section className="hr-rv-sec">
      <h4>{title}</h4>
      {children}
    </section>
  );
}
function Rows({ rows }) {
  return (
    <dl className="hr-rv-rows">
      {rows.map(([k, v, ltr]) => (<div key={k}><dt>{k}</dt><dd><Val v={v} ltr={ltr} /></dd></div>))}
    </dl>
  );
}
const Text = ({ v }) => (v ? <p className="hr-rv-text">{v}</p> : <Empty />);

export default function ReportView({ data, variant = "screen", hidePatient = false, released = true }) {
  const isPatient = variant === "patient";
  const { patient, doctor, appointmentLabel, form: f, labs = [], images = [], docs = [], sentAt, sentNote } = data;
  const bmi = calcBmi(f.weight, f.height);
  const abnormalSystems = SYSTEMS.filter((s) => f.systemsReview?.[s.key] && (f.systemsReview[s.key].abnormal || f.systemsReview[s.key].note));
  const recs = RECOMMENDATION_FIELDS.filter((r) => f.recommendations?.[r.key]);
  const age = patient?.age != null ? tr("{0} سال", [toFa(patient.age)]) : "";

  return (
    <div className={`hr-rv hr-rv-${variant}`}>
      {!hidePatient && (
        <Section title={tr("اطلاعات مریض")}>
          <Rows rows={[
            [tr("نام کامل"), patient?.fullName], [tr("شماره پرونده"), patient?.publicCode, true],
            [tr("جنسیت / سن"), [GENDER_LABEL[patient?.gender], age].filter(Boolean).join(" / ")], [tr("شماره تماس"), patient?.phone, true],
          ]} />
        </Section>
      )}
      <Section title={tr("اطلاعات مراجعه")}>
        <Rows rows={[
          [tr("تاریخ مراجعه"), fmtDay(f.visitDate)], [tr("داکتر"), doctor?.fullName], [tr("بخش / تخصص"), translateDepartmentName(doctor?.department, getCurrentLang())],
          [tr("نوبت مرتبط"), appointmentLabel], [tr("دلیل اصلی مراجعه"), f.visitReason],
        ]} />
      </Section>
      <Section title={tr("علائم حیاتی")}>
        <Rows rows={[
          [tr("فشار خون (mmHg)"), f.bloodPressure, true], [tr("نبض (bpm)"), f.pulse, true], [tr("درجه حرارت (°C)"), f.temperature, true],
          [tr("تعداد تنفس"), f.respiratoryRate, true], [tr("وزن (kg)"), f.weight, true], [tr("قد (cm)"), f.height, true], ["SpO2 (%)", f.spo2, true],
          ["BMI", bmi != null ? `${toFa(bmi)} — ${bmiCategory(bmi)}` : ""],
        ]} />
      </Section>
      <Section title={tr("شرح حال و علائم")}>
        <h5>{tr("شکایت اصلی")}</h5><Text v={f.chiefComplaint} />
        <h5>{tr("علائم و شرح حال فعلی")}</h5><Text v={f.symptoms} />
      </Section>
      {!isPatient && (<Section title={tr("معاینه پزشکی")}>
        <Rows rows={[[tr("وضعیت عمومی"), f.generalCondition ? tr(f.generalCondition) : f.generalCondition]]} />
        <h5>{tr("یافته‌های معاینه")}</h5><Text v={f.examFindings} />
        <h5>{tr("سیستم‌های مورد بررسی")}</h5>
        {abnormalSystems.length === 0 ? <Empty /> : (
          <ul className="hr-rv-list">
            {abnormalSystems.map((s) => (<li key={s.key}><b>{s.label}</b>{f.systemsReview[s.key].abnormal ? <em className="hr-rv-abn"> {tr("غیرطبیعی")}</em> : null}{f.systemsReview[s.key].note ? ` — ${f.systemsReview[s.key].note}` : ""}</li>))}
          </ul>
        )}
        {f.abnormalFindings ? (<><h5>{tr("موارد غیرطبیعی")}</h5><Text v={f.abnormalFindings} /></>) : null}
        <h5>{tr("سایر توضیحات پزشکی")}</h5><Text v={f.examNotes} />
      </Section>)}
      <Section title={tr("تشخیص")}>
        <Rows rows={[[tr("تشخیص اولیه"), f.primaryDiagnosis], [tr("تشخیص نهایی"), f.diagnosis]]} />
        <h5>{tr("توضیحات تشخیص")}</h5><Text v={f.diagnosisNotes} />
      </Section>
      <Section title={tr("نتایج آزمایش")}>
        {labs.length === 0 ? <Empty /> : (
          <table className="hr-rv-table">
            <thead><tr><th>{tr("نام آزمایش")}</th><th>{tr("نتیجه")}</th><th>{tr("واحد")}</th><th>{tr("محدوده مرجع")}</th><th>{tr("تاریخ")}</th><th>{tr("وضعیت")}</th></tr></thead>
            <tbody>
              {labs.map((l) => (
                <tr key={l.key}><td>{l.testName}</td><td dir="ltr">{l.result || "—"}</td><td dir="ltr">{l.unit || "—"}</td><td dir="ltr">{l.referenceRange || "—"}</td><td>{fmtDay(l.testDate)}</td><td>{LAB_STATUS[l.status] || "—"}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </Section>
      {(!isPatient || released) && (<Section title={tr("تصاویر پزشکی")}>
        {images.length === 0 ? <Empty /> : (
          <div className="hr-rv-gallery">
            {images.map((im) => (
              <figure key={im.key}>
                <SecureImage path={im.path} src={im.src} alt={im.title} className="hr-rv-img" onLoaded={im.onLoaded} onClick={im.onOpen} />
                <figcaption><b>{im.title}</b><span>{IMAGE_CATEGORIES[im.category] || ""}{im.fileDate ? ` • ${fmtDay(im.fileDate)}` : ""}</span>{im.description ? <i>{im.description}</i> : null}</figcaption>
              </figure>
            ))}
          </div>
        )}
      </Section>)}
      {(!isPatient || released) && (<Section title={tr("اسناد و فایل‌های پزشکی")}>
        {docs.length === 0 ? <Empty /> : (
          <ul className="hr-rv-list">
            {docs.map((d) => (<li key={d.key}><b>{d.title}</b> — {DOC_CATEGORIES[d.category] || tr("سند")}{d.fileDate ? ` • ${fmtDay(d.fileDate)}` : ""}{d.originalName ? <span dir="ltr" className="hr-rv-fname"> ({d.originalName})</span> : null}{d.onOpen ? <> <button type="button" className="hr-link" onClick={() => d.onOpen(false)}>{tr("مشاهده")}</button> <button type="button" className="hr-link" onClick={() => d.onOpen(true)}>{tr("دانلود")}</button></> : null}</li>))}
          </ul>
        )}
      </Section>)}
      {(!isPatient || released) && (<><Section title={tr("توصیه‌های پزشکی")}>
        {recs.length === 0 ? <Empty /> : recs.map((r) => (<div key={r.key}><h5>{r.label}</h5><Text v={f.recommendations[r.key]} /></div>))}
      </Section>
      <Section title={tr("پیگیری (Follow-up)")}>
        {!f.followUpRequired ? <p className="hr-rv-text">{tr("نیاز به مراجعه مجدد ثبت نشده است.")}</p> : (
          <Rows rows={[[tr("نیاز به مراجعه مجدد"), tr("بله")], [tr("تاریخ مراجعه بعدی"), f.followUpDate ? fmtDay(f.followUpDate) : ""], [tr("وضعیت پیگیری"), FOLLOWUP_STATUS[f.followUpStatus]], [tr("توضیحات پیگیری"), f.followUpNotes]]} />
        )}
      </Section></>)}
      {isPatient && !released && <p className="hr-rv-empty">{tr("توصیه‌ها، پیگیری و فایل‌های پزشکی پس از ارسال گزارش توسط داکتر در این‌جا نمایش داده می‌شود.")}</p>}
      {sentAt && (
        <Section title={tr("گزارش ارسال‌شده به بیمار")}>
          <Rows rows={[[tr("تاریخ ارسال"), fmtDateTime(sentAt)], [tr("توضیح داکتر"), sentNote]]} />
        </Section>
      )}
    </div>
  );
}

import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight, Check, ChevronLeft, ChevronRight, ClipboardList, FileText, Image as ImageIcon, Info, Loader2, Plus, Printer, Save, Send,
  Trash2, UploadCloud, Eye, Download, AlertTriangle, CheckCircle2, Paperclip,
} from "lucide-react";
import GlobalModal from "../../../../components/GlobalModal.jsx";
import { apiRequest, apiUpload, apiDownload } from "../../../../utils/api.js";
import { Field, HrDate, SecureImage, ImagePreview } from "./hrFields.jsx";
import ReportView from "./ReportView.jsx";
import HealthRecordPrint from "./HealthRecordPrint.jsx";
import {
  TABS, GENERAL_CONDITIONS, SYSTEMS, RECOMMENDATION_FIELDS, IMAGE_CATEGORIES, DOC_CATEGORIES, FOLLOWUP_STATUS, LAB_STATUS,
  MAX_FILE_SIZE, IMAGE_TYPES, DOC_TYPES, EMPTY_FORM, formFromRecord, payloadFromForm, calcBmi, bmiCategory, ageFromDob, GENDER_LABEL,
  fmtDay, fmtDateTime, toFa, todayISO, isoDay, fileSizeLabel, fileBaseName, tempId,
} from "./hrConstants.js";
import { tr } from "../../../../i18n/tr.js";
import { dept } from "../doctorWorkspaceUi.jsx";
import "./HealthRecordForm.css";

// ============================================================================
// فرم «افزودن پرونده صحی» (Doctor Dashboard → بیماران من) — ۹ مرحله‌ی تب‌دار
// ----------------------------------------------------------------------------
// APIهای استفاده‌شده (همگی موجود در بک‌اند؛ فقط ستون‌ها/مسیرهای لازم اضافه شده‌اند):
//   GET  /medical-records/patient/:id                 اطلاعات بیمار + داکتر واردشده
//   GET  /medical-records/encounters/:id/report       پرونده‌ی کامل برای ویرایش (آزمایش‌ها + فایل‌ها)
//   POST /medical-records/encounters                  ثبت (status = draft | registered)
//   PUT  /medical-records/encounters/:id              ویرایش / تبدیل پیش‌نویس به ثبت نهایی
//   POST/PUT/DELETE /medical-records/lab-results[/:id] + POST /lab-results/:id/report   آزمایش‌ها (موجود)
//   POST /medical-records/encounters/:id/files        تصویر پزشکی / سند    DELETE /medical-records/files/:id
//   GET  /medical-records/files/:id                   پیش‌نمایش/دانلود فایل
//   POST /medical-records/encounters/:id/send         ارسال گزارش به بیمار
// نسخه‌ی دارویی در این فرم وجود ندارد؛ فقط در بخش مستقل «نسخه و سوابق طبی».
// ============================================================================

const faToEn = (s) => String(s).replace(/[۰-۹]/g, (c) => String(c.charCodeAt(0) - 1776)).replace(/[٠-٩]/g, (c) => String(c.charCodeAt(0) - 1632));
const cleanNumber = (s) => faToEn(s).replace(/[^\d.]/g, "").replace(/(\..*)\./g, "$1").slice(0, 7);
const cleanBp = (s) => faToEn(s).replace(/[^\d/]/g, "").slice(0, 7);

const emptyLab = () => ({ key: tempId(), id: null, testName: "", result: "", unit: "", referenceRange: "", testDate: todayISO(), status: "completed", file: null, hasFile: false, dirty: true });

export default function HealthRecordForm({ patientId, patientName, appointments = [], defaultAppointmentId = "", recordId = null, onClose }) {
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [patient, setPatient] = useState(null);
  const [doctor, setDoctor] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [labs, setLabs] = useState([]);
  const [images, setImages] = useState([]);
  const [docs, setDocs] = useState([]);
  const [meta, setMeta] = useState({ id: recordId, status: recordId ? "registered" : "new", sentToPatientAt: null, sentNote: "" });
  const [readOnly, setReadOnly] = useState(false);
  const [tab, setTab] = useState(0);
  const [errors, setErrors] = useState({});
  const [banner, setBanner] = useState({ type: "", text: "" });
  const [saving, setSaving] = useState("");
  const [sending, setSending] = useState(false);
  const [dirty, setDirty] = useState(false);
  const [sendMessage, setSendMessage] = useState(() => tr("نتایج بررسی شما ثبت گردید. لطفاً توصیه‌های پزشکی را مطالعه کرده و در صورت نیاز برای پیگیری مراجعه نمایید."));
  const [modal, setModal] = useState(null); // { type: 'register'|'send'|'leave'|'delete', ... }
  const [preview, setPreview] = useState(null);
  const [printing, setPrinting] = useState(false);
  const topRef = useRef(null);

  // ---------- بارگذاری ----------
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setLoadError("");
    const req = recordId
      ? apiRequest(`/medical-records/encounters/${recordId}/report`).then((d) => ({ patient: d.patient, doctor: d.doctor, report: d }))
      : apiRequest(`/medical-records/patient/${patientId}`).then((d) => ({ patient: d.patient, doctor: d.doctor, report: null }));
    req.then(({ patient: p, doctor: dr, report }) => {
      if (cancelled) return;
      setPatient(p);
      setDoctor(dr);
      if (report) {
        const rec = report.record;
        setForm(formFromRecord(rec));
        setMeta({ id: rec.id, status: rec.status || "registered", sentToPatientAt: rec.sentToPatientAt, sentNote: rec.sentNote || "" });
        if (rec.sentNote) setSendMessage(rec.sentNote);
        setReadOnly(!report.canEdit);
        setLabs(report.labResults.map((l) => ({ key: `s${l.id}`, id: l.id, testName: l.testName || "", result: l.result || "", unit: l.unit || "", referenceRange: l.referenceRange || "", testDate: isoDay(l.testDate), status: l.status || "completed", file: null, hasFile: !!l.reportUrl, dirty: false })));
        const toItem = (f) => ({ key: `s${f.id}`, id: f.id, path: `/medical-records/files/${f.id}`, category: f.category, title: f.title, fileDate: isoDay(f.fileDate), description: f.description || "", originalName: f.originalName, mimeType: f.mimeType, sizeBytes: f.sizeBytes });
        setImages(report.files.filter((f) => f.kind === "image").map(toItem));
        setDocs(report.files.filter((f) => f.kind === "document").map(toItem));
      } else {
        setForm((f) => ({ ...f, appointmentId: defaultAppointmentId ? String(defaultAppointmentId) : "" }));
      }
    }).catch((err) => { if (!cancelled) setLoadError((err.message && tr(err.message)) || tr("بارگذاری پرونده انجام نشد.")); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [patientId, recordId]);

  // آزاد کردن Object URLهای تصاویر محلی هنگام خروج
  const imagesRef = useRef(images);
  imagesRef.current = images;
  useEffect(() => () => imagesRef.current.forEach((im) => im.src && URL.revokeObjectURL(im.src)), []);

  // هشدار بستن تب مرورگر با تغییرات ذخیره‌نشده
  useEffect(() => {
    if (!dirty) return undefined;
    const h = (e) => { e.preventDefault(); e.returnValue = ""; };
    window.addEventListener("beforeunload", h);
    return () => window.removeEventListener("beforeunload", h);
  }, [dirty]);

  const set = (key, value) => { setForm((f) => ({ ...f, [key]: value })); setDirty(true); setErrors((e) => (e[key] ? { ...e, [key]: undefined } : e)); };
  const bmi = calcBmi(form.weight, form.height);

  // ---------- محاسبه‌ی داده‌ی گزارش (جمع‌بندی/چاپ) ----------
  const reportData = useMemo(() => {
    const appt = appointments.find((a) => String(a.appointmentId) === String(form.appointmentId));
    return {
      patient: patient && { fullName: patient.fullName || patientName, publicCode: patient.publicCode, gender: patient.gender, age: ageFromDob(patient.dateOfBirth), phone: patient.phone },
      doctor, form,
      appointmentLabel: appt ? `${fmtDay(appt.appointmentDate)}${appt.appointmentTime ? tr(" — ساعت {0}", [toFa(String(appt.appointmentTime).slice(0, 5))]) : ""}` : "",
      labs: labs.filter((l) => l.testName.trim()).map((l) => ({ key: l.key, testName: l.testName, result: l.result, unit: l.unit, referenceRange: l.referenceRange, testDate: l.testDate, status: l.status })),
      images: images.map((im) => ({ key: im.key, title: im.title, category: im.category, fileDate: im.fileDate, description: im.description, path: im.src ? undefined : im.path, src: im.src })),
      docs: docs.map((d) => ({ key: d.key, title: d.title, category: d.category, fileDate: d.fileDate, originalName: d.originalName })),
      sentAt: meta.sentToPatientAt, sentNote: meta.sentNote,
    };
  }, [patient, patientName, doctor, form, labs, images, docs, appointments, meta]);

  // ---------- اعتبارسنجی ----------
  function validate(mode) {
    const errs = {};
    if (!form.visitDate) errs.visitDate = tr("تاریخ مراجعه الزامی است.");
    if (mode === "registered" && !form.visitReason.trim()) errs.visitReason = tr("دلیل اصلی مراجعه برای ثبت نهایی الزامی است.");
    if (form.bloodPressure && !/^\d{2,3}\/\d{2,3}$/.test(form.bloodPressure)) errs.bloodPressure = tr("فرمت فشار خون مثل 120/80 باشد.");
    if (form.followUpRequired && mode === "registered" && !form.followUpDate) errs.followUpDate = tr("تاریخ مراجعه بعدی را مشخص کنید.");
    labs.forEach((l) => {
      const empty = !l.id && !l.testName.trim() && !l.result.trim() && !l.unit.trim() && !l.referenceRange.trim() && !l.file;
      if (!empty && !l.testName.trim()) errs[`lab:${l.key}`] = tr("نام آزمایش الزامی است.");
    });
    [...images, ...docs].forEach((f) => { if (!f.id && !f.title.trim()) errs[`file:${f.key}`] = tr("عنوان فایل الزامی است."); });
    return errs;
  }
  const tabOfError = (k) => (k === "visitDate" || k === "visitReason" ? 0 : k === "bloodPressure" ? 1 : k.startsWith("lab:") ? 5 : k.startsWith("file:") ? 6 : 8);

  // ---------- ذخیره (پیش‌نویس / ثبت نهایی) ----------
  async function syncChildren(id) {
    const failures = [];
    for (const l of labs) {
      const emptyRow = !l.id && !l.testName.trim() && !l.result.trim() && !l.unit.trim() && !l.referenceRange.trim() && !l.file;
      if (emptyRow || (l.id && !l.dirty && !l.file)) continue;
      const body = { testName: l.testName.trim(), result: l.result.trim(), unit: l.unit.trim(), referenceRange: l.referenceRange.trim(), status: l.status, testDate: l.testDate || undefined };
      try {
        let labId = l.id;
        if (labId) await apiRequest(`/medical-records/lab-results/${labId}`, { method: "PUT", body });
        else { const r = await apiRequest("/medical-records/lab-results", { method: "POST", body: { ...body, patientId, recordId: id } }); labId = r.item.id; }
        let hasFile = l.hasFile;
        if (l.file) { const fd = new FormData(); fd.append("report", l.file); await apiUpload(`/medical-records/lab-results/${labId}/report`, fd); hasFile = true; }
        setLabs((list) => list.map((x) => (x.key === l.key ? { ...x, id: labId, dirty: false, file: null, hasFile } : x)));
      } catch (err) { failures.push(tr("آزمایش «{0}»: {1}", [l.testName || "—", tr(err.message)])); }
    }
    const uploadGroup = async (list, kind, setList) => {
      for (const f of list) {
        if (f.id || !f.file) continue;
        try {
          const fd = new FormData();
          fd.append("file", f.file); fd.append("kind", kind); fd.append("category", f.category); fd.append("title", f.title.trim());
          if (f.fileDate) fd.append("fileDate", f.fileDate);
          if (f.description.trim()) fd.append("description", f.description.trim());
          const r = await apiUpload(`/medical-records/encounters/${id}/files`, fd);
          if (f.src) URL.revokeObjectURL(f.src);
          setList((cur) => cur.map((x) => (x.key === f.key ? { ...x, id: r.file.id, path: `/medical-records/files/${r.file.id}`, file: null, src: undefined } : x)));
        } catch (err) { failures.push(tr("فایل «{0}»: {1}", [f.title || f.file.name, tr(err.message)])); }
      }
    };
    await uploadGroup(images, "image", setImages);
    await uploadGroup(docs, "document", setDocs);
    return failures;
  }

  async function save(mode) {
    if (readOnly) return;
    setBanner({ type: "", text: "" });
    const errs = validate(mode);
    if (Object.keys(errs).length) {
      setErrors(errs);
      setTab(tabOfError(Object.keys(errs)[0]));
      setBanner({ type: "error", text: tr("لطفاً موارد مشخص‌شده را اصلاح کنید.") });
      topRef.current?.scrollIntoView?.({ block: "start" });
      return;
    }
    setErrors({});
    setSaving(mode);
    try {
      const body = { ...payloadFromForm(form), status: mode === "draft" ? "draft" : "registered" };
      let id = meta.id;
      let status = mode === "draft" ? "draft" : "registered";
      if (id) {
        await apiRequest(`/medical-records/encounters/${id}`, { method: "PUT", body });
      } else {
        const r = await apiRequest("/medical-records/encounters", { method: "POST", body: { ...body, patientId } });
        id = r.record.id;
      }
      setMeta((m) => ({ ...m, id, status }));
      const failures = await syncChildren(id);
      if (failures.length) {
        setBanner({ type: "error", text: tr("پرونده ذخیره شد، اما برخی موارد ثبت نشدند: {0}", [failures.join(" | ")]) });
      } else {
        setDirty(false);
        setBanner({ type: "success", text: mode === "draft" ? tr("پیش‌نویس ذخیره شد. هنوز برای مریض دیده نمی‌شود.") : tr("پرونده صحی با موفقیت ثبت شد. اکنون می‌توانید آن را برای مریض ارسال یا چاپ کنید.") });
        if (mode === "registered") setTab(TABS.length - 1);
      }
      topRef.current?.scrollIntoView?.({ block: "start" });
    } catch (err) {
      setBanner({ type: "error", text: (err.message && tr(err.message)) || tr("ذخیره‌ی پرونده انجام نشد.") });
    } finally {
      setSaving("");
      setModal(null);
    }
  }

  // ---------- ارسال به مریض ----------
  async function doSend() {
    setSending(true);
    try {
      const r = await apiRequest(`/medical-records/encounters/${meta.id}/send`, { method: "POST", body: { message: sendMessage.trim() } });
      setMeta((m) => ({ ...m, sentToPatientAt: r.record.sentToPatientAt, sentNote: r.record.sentNote || "" }));
      setBanner({ type: "success", text: tr("گزارش پزشکی برای مریض ارسال شد و در بخش «پرونده‌های صحی من» او قابل مشاهده است.") });
    } catch (err) {
      setBanner({ type: "error", text: (err.message && tr(err.message)) || tr("ارسال انجام نشد.") });
    } finally {
      setSending(false);
      setModal(null);
      topRef.current?.scrollIntoView?.({ block: "start" });
    }
  }
  const canSend = meta.status === "registered" && !!meta.id && !dirty && !readOnly;

  // ---------- آزمایش‌ها ----------
  const updLab = (key, patch) => { setLabs((l) => l.map((x) => (x.key === key ? { ...x, ...patch, dirty: true } : x))); setDirty(true); setErrors((e) => ({ ...e, [`lab:${key}`]: undefined })); };
  function pickLabFile(key, file) {
    if (!file) return;
    if (!DOC_TYPES.includes(file.type)) { setBanner({ type: "error", text: tr("فرمت گزارش آزمایش مجاز نیست (JPG، PNG، WEBP یا PDF).") }); return; }
    if (file.size > MAX_FILE_SIZE) { setBanner({ type: "error", text: tr("حجم فایل نباید بیشتر از ۱۰ مگابایت باشد.") }); return; }
    updLab(key, { file });
  }

  // ---------- تصاویر و اسناد ----------
  function addFiles(fileList, kind) {
    const allowed = kind === "image" ? IMAGE_TYPES : DOC_TYPES;
    const accepted = [];
    const rejected = [];
    Array.from(fileList).forEach((file) => {
      if (!allowed.includes(file.type)) rejected.push(tr("«{0}»: فرمت مجاز نیست", [file.name]));
      else if (file.size > MAX_FILE_SIZE) rejected.push(tr("«{0}»: حجم بیش از ۱۰ مگابایت", [file.name]));
      else accepted.push(file);
    });
    if (rejected.length) setBanner({ type: "error", text: tr("برخی فایل‌ها اضافه نشدند — {0}", [rejected.join(tr("، "))]) });
    if (!accepted.length) return;
    const items = accepted.map((file) => ({
      key: tempId(), id: null, file, title: fileBaseName(file.name).slice(0, 150), category: kind === "image" ? "xray" : "medical_report",
      fileDate: todayISO(), description: "", originalName: file.name, mimeType: file.type, sizeBytes: file.size,
      src: file.type.startsWith("image/") ? URL.createObjectURL(file) : undefined,
    }));
    (kind === "image" ? setImages : setDocs)((cur) => [...cur, ...items]);
    setDirty(true);
  }
  const updFile = (kind, key, patch) => { (kind === "image" ? setImages : setDocs)((l) => l.map((x) => (x.key === key ? { ...x, ...patch } : x))); setDirty(true); setErrors((e) => ({ ...e, [`file:${key}`]: undefined })); };

  function removeStaged(kind, item) {
    if (item.src) URL.revokeObjectURL(item.src);
    (kind === "image" ? setImages : setDocs)((l) => l.filter((x) => x.key !== item.key));
  }
  async function confirmDeleteSaved() {
    const { kind, item } = modal;
    setSaving("delete");
    try {
      if (kind === "lab") {
        await apiRequest(`/medical-records/lab-results/${item.id}`, { method: "DELETE" });
        setLabs((l) => l.filter((x) => x.key !== item.key));
      } else {
        await apiRequest(`/medical-records/files/${item.id}`, { method: "DELETE" });
        (kind === "image" ? setImages : setDocs)((l) => l.filter((x) => x.key !== item.key));
      }
      setBanner({ type: "success", text: tr("مورد حذف شد.") });
    } catch (err) {
      setBanner({ type: "error", text: (err.message && tr(err.message)) || tr("حذف انجام نشد.") });
    } finally { setSaving(""); setModal(null); }
  }
  const askRemove = (kind, item) => (item.id ? setModal({ type: "delete", kind, item }) : kind === "lab" ? setLabs((l) => l.filter((x) => x.key !== item.key)) : removeStaged(kind, item));

  async function openDoc(item, download) {
    try {
      if (item.id) await apiDownload(`/medical-records/files/${item.id}${download ? "?download=1" : ""}`, item.originalName || "file", { openInNewTab: !download });
      else if (item.file) { const u = URL.createObjectURL(item.file); window.open(u, "_blank"); setTimeout(() => URL.revokeObjectURL(u), 60000); }
    } catch (err) { setBanner({ type: "error", text: tr(err.message) }); }
  }
  async function openLabReport(l) {
    try { await apiDownload(`/medical-records/lab-results/${l.id}/report`, "lab-report", { openInNewTab: true }); } catch (err) { setBanner({ type: "error", text: tr(err.message) }); }
  }

  // سیستم‌های مورد بررسی: فقط موارد غیرطبیعی علامت می‌خورند؛ ورودیِ بی‌علامت و بی‌توضیح از رکورد حذف می‌شود
  const sysVal = (k) => form.systemsReview[k] || { abnormal: false, note: "" };
  const updSys = (k, patch) => {
    const next = { ...form.systemsReview, [k]: { ...sysVal(k), ...patch } };
    if (!next[k].abnormal && !next[k].note) delete next[k];
    set("systemsReview", next);
  };

  const requestClose = () => (dirty ? setModal({ type: "leave" }) : onClose(!!meta.id));
  const filled = [
    !!(form.visitReason || form.appointmentId), !!(form.bloodPressure || form.pulse || form.temperature || form.weight || form.height || form.spo2 || form.respiratoryRate),
    !!(form.chiefComplaint || form.symptoms), !!(form.generalCondition || form.examFindings || form.abnormalFindings || Object.keys(form.systemsReview).length),
    !!(form.primaryDiagnosis || form.diagnosis), labs.some((l) => l.testName.trim()), images.length + docs.length > 0,
    RECOMMENDATION_FIELDS.some((r) => form.recommendations[r.key]), form.followUpRequired || !!meta.sentToPatientAt,
  ];
  const errTabs = new Set(Object.keys(errors).filter((k) => errors[k]).map(tabOfError));
  const statusBadge = meta.sentToPatientAt ? { cls: "sent", text: tr("ارسال‌شده به مریض") } : meta.status === "draft" ? { cls: "draft", text: tr("پیش‌نویس") } : meta.status === "registered" ? { cls: "ok", text: tr("ثبت‌شده") } : { cls: "new", text: tr("پرونده جدید") };

  if (loading) return <div className="hr-page"><div className="hr-state"><Loader2 className="hr-spin" size={26} /> {tr("در حال بارگذاری پرونده...")}</div></div>;
  if (loadError) {
    return (
      <div className="hr-page">
        <div className="hr-state hr-state-err"><AlertTriangle size={26} /><p>{loadError}</p><button type="button" className="btn btn-ghost btn-sm" onClick={() => onClose(false)}>{tr("بازگشت به بیماران من")}</button></div>
      </div>
    );
  }

  return (
    <div className="hr-page" ref={topRef}>
      <header className="hr-head">
        <button type="button" className="btn btn-ghost btn-sm" onClick={requestClose}><ArrowRight size={15} aria-hidden="true" /> {tr("بازگشت به بیماران من")}</button>
        <div className="hr-head-text">
          <h2>{recordId ? tr("ویرایش پرونده صحی") : tr("افزودن پرونده صحی مریض")}</h2>
          <p>{tr("اطلاعات مراجعه، معاینه، تشخیص و سایر جزئیات را ثبت کنید")}</p>
        </div>
        <span className={`hr-badge hr-badge-${statusBadge.cls}`}>{statusBadge.text}</span>
      </header>

      <nav className="hr-tabs" role="tablist" aria-label={tr("مراحل پرونده صحی")}>
        {TABS.map((t, i) => (
          <button key={t.key} type="button" role="tab" aria-selected={tab === i} className={`hr-tab ${tab === i ? "is-active" : ""} ${errTabs.has(i) ? "has-error" : ""}`} onClick={() => setTab(i)}>
            <span className="hr-tab-no">{filled[i] && tab !== i ? <Check size={12} /> : toFa(i + 1)}</span>
            <span>{t.label}</span>
          </button>
        ))}
      </nav>

      {banner.text && <div className={`hr-banner hr-banner-${banner.type}`} role={banner.type === "error" ? "alert" : "status"}>{banner.type === "success" ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />} <span>{banner.text}</span></div>}
      {readOnly && <div className="hr-banner hr-banner-info"><Info size={16} /> <span>{tr("این پرونده توسط داکتر دیگری ثبت شده است؛ فقط می‌توانید آن را مشاهده یا چاپ کنید.")}</span></div>}

      <fieldset className="hr-card" disabled={readOnly}>
        {tab === 0 && (
          <Section no={1} title={tr("اطلاعات مراجعه")}>
            <dl className="hr-info-strip">
              <div><dt>{tr("مریض")}</dt><dd>{patient?.fullName || patientName || "—"}</dd></div>
              <div><dt>{tr("شماره پرونده")}</dt><dd dir="ltr">{patient?.publicCode || "—"}</dd></div>
              <div><dt>{tr("جنسیت / سن")}</dt><dd>{[GENDER_LABEL[patient?.gender], ageFromDob(patient?.dateOfBirth) != null ? tr("{0} سال", [toFa(ageFromDob(patient.dateOfBirth))]) : ""].filter(Boolean).join(" / ") || "—"}</dd></div>
              <div><dt>{tr("داکتر")}</dt><dd>{doctor?.fullName || "—"}</dd></div>
              <div><dt>{tr("بخش / تخصص")}</dt><dd>{dept(doctor?.department) || "—"}</dd></div>
            </dl>
            <div className="hr-grid hr-grid-3">
              <Field label={tr("تاریخ مراجعه")} required error={errors.visitDate}><HrDate value={form.visitDate} onChange={(v) => set("visitDate", v)} ariaLabel={tr("تاریخ مراجعه")} /></Field>
              <Field label={tr("نوبت مرتبط (در صورت وجود)")} className="hr-span-2">
                <select className="hr-input" value={form.appointmentId} onChange={(e) => set("appointmentId", e.target.value)}>
                  <option value="">{tr("بدون نوبت مرتبط")}</option>
                  {appointments.map((a) => (<option key={a.appointmentId} value={a.appointmentId}>{fmtDay(a.appointmentDate)}{a.appointmentTime ? ` — ${toFa(String(a.appointmentTime).slice(0, 5))}` : ""}</option>))}
                </select>
              </Field>
              <Field label={tr("دلیل اصلی مراجعه")} required error={errors.visitReason} className="hr-span-3">
                <input className="hr-input" maxLength={500} value={form.visitReason} onChange={(e) => set("visitReason", e.target.value)} placeholder={tr("مثلاً: درد قفسه سینه، تب و سرفه...")} />
              </Field>
            </div>
          </Section>
        )}

        {tab === 1 && (
          <Section no={2} title={tr("علائم حیاتی")}>
            <div className="hr-grid hr-grid-4">
              <Field label={tr("فشار خون (mmHg)")} error={errors.bloodPressure}><input className="hr-input" dir="ltr" inputMode="numeric" value={form.bloodPressure} onChange={(e) => set("bloodPressure", cleanBp(e.target.value))} placeholder="120/80" /></Field>
              <Field label={tr("نبض (bpm)")}><input className="hr-input" dir="ltr" inputMode="decimal" value={form.pulse} onChange={(e) => set("pulse", cleanNumber(e.target.value))} placeholder="72" /></Field>
              <Field label={tr("درجه حرارت (°C)")}><input className="hr-input" dir="ltr" inputMode="decimal" value={form.temperature} onChange={(e) => set("temperature", cleanNumber(e.target.value))} placeholder="36.5" /></Field>
              <Field label={tr("تعداد تنفس (در دقیقه)")}><input className="hr-input" dir="ltr" inputMode="decimal" value={form.respiratoryRate} onChange={(e) => set("respiratoryRate", cleanNumber(e.target.value))} placeholder="16" /></Field>
              <Field label={tr("وزن (kg)")}><input className="hr-input" dir="ltr" inputMode="decimal" value={form.weight} onChange={(e) => set("weight", cleanNumber(e.target.value))} placeholder="70" /></Field>
              <Field label={tr("قد (cm)")}><input className="hr-input" dir="ltr" inputMode="decimal" value={form.height} onChange={(e) => set("height", cleanNumber(e.target.value))} placeholder="175" /></Field>
              <Field label={tr("اکسیژن خون SpO2 (%)")}><input className="hr-input" dir="ltr" inputMode="decimal" value={form.spo2} onChange={(e) => set("spo2", cleanNumber(e.target.value))} placeholder="98" /></Field>
              <div className="hr-bmi" aria-live="polite">
                <span className="hr-label">{tr("BMI (خودکار)")}</span>
                <b>{bmi != null ? toFa(bmi) : "—"}</b>
                <small>{bmi != null ? bmiCategory(bmi) : tr("وزن و قد را وارد کنید")}</small>
              </div>
            </div>
          </Section>
        )}

        {tab === 2 && (
          <Section no={3} title={tr("شرح حال و علائم")}>
            <div className="hr-grid">
              <Field label={tr("شکایت اصلی")} hint={tr("شکایت اصلی مریض به زبان خودش")}><textarea className="hr-input" rows={3} maxLength={3000} value={form.chiefComplaint} onChange={(e) => set("chiefComplaint", e.target.value)} placeholder={tr("مثلاً: درد قفسه سینه از دو روز پیش")} /></Field>
              <Field label={tr("علائم و شرح حال فعلی")}><textarea className="hr-input" rows={9} maxLength={5000} value={form.symptoms} onChange={(e) => set("symptoms", e.target.value)} placeholder={tr("شروع علائم، مدت، شدت، عوامل تشدید یا تسکین، سوابق مرتبط...")} /><small className="hr-count">{toFa(form.symptoms.length)} / {toFa(5000)}</small></Field>
            </div>
          </Section>
        )}

        {tab === 3 && (
          <Section no={4} title={tr("معاینه پزشکی")}>
            <div className="hr-grid hr-grid-3">
              <Field label={tr("وضعیت عمومی مریض")}>
                <div className="hr-chips" role="radiogroup" aria-label={tr("وضعیت عمومی")}>
                  {GENERAL_CONDITIONS.map((g) => (<button key={g} type="button" role="radio" aria-checked={form.generalCondition === g} className={`hr-chip ${form.generalCondition === g ? "is-on" : ""}`} onClick={() => set("generalCondition", form.generalCondition === g ? "" : g)}>{tr(g)}</button>))}
                </div>
              </Field>
            </div>
            <Field label={tr("یافته‌های معاینه")}><textarea className="hr-input" rows={4} maxLength={3000} value={form.examFindings} onChange={(e) => set("examFindings", e.target.value)} placeholder={tr("یافته‌های معاینه‌ی فیزیکی...")} /></Field>
            <div className="hr-sys">
              <span className="hr-label">{tr("سیستم‌های مورد بررسی")} <small>{tr("(فقط موارد غیرطبیعی را علامت بزنید)")}</small></span>
              <div className="hr-chips" role="group" aria-label={tr("سیستم‌های مورد بررسی")}>
                {SYSTEMS.map((sys) => (
                  <button key={sys.key} type="button" role="checkbox" aria-checked={!!sysVal(sys.key).abnormal} className={`hr-chip ${sysVal(sys.key).abnormal ? "is-abn" : ""}`} onClick={() => updSys(sys.key, { abnormal: !sysVal(sys.key).abnormal })}>{sys.label}</button>
                ))}
              </div>
              {SYSTEMS.filter((sys) => sysVal(sys.key).abnormal || sysVal(sys.key).note).map((sys) => (
                <label key={sys.key} className="hr-sys-note">
                  <span>{sys.label}</span>
                  <input className="hr-input" maxLength={500} value={sysVal(sys.key).note} onChange={(e) => updSys(sys.key, { note: e.target.value })} placeholder={tr("توضیح یافته...")} aria-label={tr("توضیح {0}", [sys.label])} />
                </label>
              ))}
            </div>
            {/* «موارد غیرطبیعی» دیگر در فرم نیست (با «یافته‌های معاینه» و توضیحِ هر سیستم تکراری بود)؛ فقط برای پرونده‌های قدیمیِ دارای مقدار نمایش داده می‌شود تا داده از دست نرود */}
            {form.abnormalFindings && (
              <Field label={tr("موارد غیرطبیعی (قدیمی)")}><textarea className="hr-input" rows={2} maxLength={3000} value={form.abnormalFindings} onChange={(e) => set("abnormalFindings", e.target.value)} /></Field>
            )}
            <Field label={tr("یادداشت داخلی داکتر")} hint={tr("برای مریض نمایش داده نمی‌شود.")}><textarea className="hr-input" rows={2} maxLength={3000} value={form.examNotes} onChange={(e) => set("examNotes", e.target.value)} /></Field>
          </Section>
        )}

        {tab === 4 && (
          <Section no={5} title={tr("تشخیص")}>
            <div className="hr-grid hr-grid-2">
              <Field label={tr("تشخیص اولیه")}><input className="hr-input" maxLength={500} value={form.primaryDiagnosis} onChange={(e) => set("primaryDiagnosis", e.target.value)} placeholder={tr("تشخیص احتمالی در شروع ویزیت")} /></Field>
              <Field label={tr("تشخیص نهایی")} hint={tr("همین مقدار در سوابق و خط زمانی بیمار نمایش داده می‌شود.")}><input className="hr-input" maxLength={2000} value={form.diagnosis} onChange={(e) => set("diagnosis", e.target.value)} placeholder={tr("تشخیص نهایی")} /></Field>
            </div>
            <Field label={tr("توضیحات تشخیص")}><textarea className="hr-input" rows={5} maxLength={3000} value={form.diagnosisNotes} onChange={(e) => set("diagnosisNotes", e.target.value)} placeholder={tr("توضیحات تکمیلی در مورد تشخیص...")} /></Field>
          </Section>
        )}

        {tab === 5 && (
          <Section no={6} title={tr("نتایج آزمایش")} aside={<button type="button" className="btn btn-ghost btn-sm" onClick={() => { setLabs((l) => [...l, emptyLab()]); setDirty(true); }}><Plus size={14} /> {tr("افزودن آزمایش")}</button>}>
            {labs.length === 0 ? (
              <div className="hr-empty"><ClipboardList size={26} /><p>{tr("هیچ آزمایشی اضافه نشده است.")}</p><button type="button" className="btn btn-ghost btn-sm" onClick={() => { setLabs([emptyLab()]); setDirty(true); }}><Plus size={14} /> {tr("افزودن آزمایش")}</button></div>
            ) : (
              <div className="hr-lab-list">
                {labs.map((l) => (
                  <div key={l.key} className="hr-lab">
                    <div className="hr-lab-grid">
                      <Field label={tr("نام آزمایش")} required error={errors[`lab:${l.key}`]}><input className="hr-input" maxLength={150} value={l.testName} onChange={(e) => updLab(l.key, { testName: e.target.value })} placeholder={tr("مثلاً CBC")} /></Field>
                      <Field label={tr("نتیجه")}><input className="hr-input" dir="ltr" value={l.result} onChange={(e) => updLab(l.key, { result: e.target.value })} /></Field>
                      <Field label={tr("واحد")}><input className="hr-input" dir="ltr" maxLength={50} value={l.unit} onChange={(e) => updLab(l.key, { unit: e.target.value })} placeholder="g/dL" /></Field>
                      <Field label={tr("محدوده مرجع")}><input className="hr-input" dir="ltr" maxLength={100} value={l.referenceRange} onChange={(e) => updLab(l.key, { referenceRange: e.target.value })} placeholder="12-16" /></Field>
                      <Field label={tr("تاریخ آزمایش")}><HrDate value={l.testDate} onChange={(v) => updLab(l.key, { testDate: v })} ariaLabel={tr("تاریخ آزمایش")} /></Field>
                      <Field label={tr("وضعیت")}><select className="hr-input" value={l.status} onChange={(e) => updLab(l.key, { status: e.target.value })}>{Object.entries(LAB_STATUS).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}</select></Field>
                    </div>
                    <div className="hr-lab-foot">
                      <span className="hr-lab-file">
                        <Paperclip size={14} />
                        {l.file ? <b>{l.file.name}</b> : l.hasFile ? <button type="button" className="hr-link" onClick={() => openLabReport(l)}>{tr("مشاهده فایل گزارش")}</button> : <em>{tr("فایل گزارش (اختیاری)")}</em>}
                        <label className="hr-link">{l.file || l.hasFile ? tr("تغییر فایل") : tr("انتخاب فایل")}<input type="file" hidden accept=".pdf,.jpg,.jpeg,.png,.webp" onChange={(e) => { pickLabFile(l.key, e.target.files?.[0]); e.target.value = ""; }} /></label>
                      </span>
                      {!l.id && <small className="hr-pending">{tr("ذخیره‌نشده")}</small>}
                      <button type="button" className="hr-icon-btn is-danger" onClick={() => askRemove("lab", l)} aria-label={tr("حذف آزمایش {0}", [l.testName])}><Trash2 size={15} /></button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Section>
        )}

        {tab === 6 && (
          <div className="hr-two">
            <Section no={7} title={tr("تصاویر پزشکی")}>
              <Dropzone kind="image" onFiles={(f) => addFiles(f, "image")} />
              {images.length > 0 && (
                <div className="hr-thumbs">
                  {images.map((im) => (
                    <figure key={im.key} className="hr-thumb">
                      <button type="button" className="hr-thumb-img" onClick={() => setPreview({ path: im.src ? undefined : im.path, src: im.src, title: im.title, date: im.fileDate, description: im.description })} aria-label={tr("پیش‌نمایش {0}", [im.title])}>
                        <SecureImage path={im.src ? undefined : im.path} src={im.src} alt={im.title} />
                        <span className="hr-thumb-eye"><Eye size={16} /></span>
                      </button>
                      <div className="hr-thumb-meta">
                        <Field label={tr("عنوان تصویر")} required error={errors[`file:${im.key}`]}><input className="hr-input" maxLength={150} disabled={!!im.id} value={im.title} onChange={(e) => updFile("image", im.key, { title: e.target.value })} /></Field>
                        <div className="hr-grid hr-grid-2">
                          <Field label={tr("نوع")}><select className="hr-input" disabled={!!im.id} value={im.category} onChange={(e) => updFile("image", im.key, { category: e.target.value })}>{Object.entries(IMAGE_CATEGORIES).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}</select></Field>
                          <Field label={tr("تاریخ")}>{im.id ? <span className="hr-input hr-input-ro">{fmtDay(im.fileDate)}</span> : <HrDate value={im.fileDate} onChange={(v) => updFile("image", im.key, { fileDate: v })} ariaLabel={tr("تاریخ تصویر")} />}</Field>
                        </div>
                        <Field label={tr("توضیحات داکتر")}><textarea className="hr-input" rows={2} maxLength={1500} disabled={!!im.id} value={im.description} onChange={(e) => updFile("image", im.key, { description: e.target.value })} /></Field>
                        <div className="hr-thumb-foot">{im.id ? <small className="hr-saved"><Check size={12} /> {tr("ذخیره‌شده")}</small> : <small className="hr-pending">{tr("ذخیره‌نشده")}</small>}<button type="button" className="hr-icon-btn is-danger" onClick={() => askRemove("image", im)} aria-label={tr("حذف {0}", [im.title])}><Trash2 size={15} /></button></div>
                      </div>
                    </figure>
                  ))}
                </div>
              )}
            </Section>
            <Section no={8} title={tr("اسناد و فایل‌های پزشکی")}>
              <Dropzone kind="document" onFiles={(f) => addFiles(f, "document")} />
              {docs.length > 0 && (
                <ul className="hr-docs">
                  {docs.map((d) => (
                    <li key={d.key} className="hr-doc">
                      <span className="hr-doc-ico">{d.mimeType === "application/pdf" ? <FileText size={20} /> : <ImageIcon size={20} />}</span>
                      <div className="hr-doc-body">
                        <span className="hr-doc-name" dir="ltr" title={d.originalName}>{d.originalName} <small>({fileSizeLabel(d.sizeBytes || 0)})</small></span>
                        <Field label={tr("عنوان")} required error={errors[`file:${d.key}`]}><input className="hr-input" maxLength={150} disabled={!!d.id} value={d.title} onChange={(e) => updFile("document", d.key, { title: e.target.value })} /></Field>
                        <div className="hr-grid hr-grid-2">
                          <Field label={tr("نوع سند")}><select className="hr-input" disabled={!!d.id} value={d.category} onChange={(e) => updFile("document", d.key, { category: e.target.value })}>{Object.entries(DOC_CATEGORIES).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}</select></Field>
                          <Field label={tr("تاریخ")}>{d.id ? <span className="hr-input hr-input-ro">{fmtDay(d.fileDate)}</span> : <HrDate value={d.fileDate} onChange={(v) => updFile("document", d.key, { fileDate: v })} ariaLabel={tr("تاریخ سند")} />}</Field>
                        </div>
                        <Field label={tr("توضیحات")}><textarea className="hr-input" rows={2} maxLength={1500} disabled={!!d.id} value={d.description} onChange={(e) => updFile("document", d.key, { description: e.target.value })} /></Field>
                      </div>
                      <div className="hr-doc-actions">
                        <button type="button" className="hr-icon-btn" onClick={() => openDoc(d, false)} aria-label={tr("پیش‌نمایش")}><Eye size={15} /></button>
                        {d.id && <button type="button" className="hr-icon-btn" onClick={() => openDoc(d, true)} aria-label={tr("دانلود")}><Download size={15} /></button>}
                        <button type="button" className="hr-icon-btn is-danger" onClick={() => askRemove("document", d)} aria-label={tr("حذف {0}", [d.title])}><Trash2 size={15} /></button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </Section>
          </div>
        )}

        {tab === 7 && (
          <Section no={9} title={tr("توصیه‌های پزشکی")}>
            <div className="hr-note hr-note-warn"><Info size={14} /> {tr("نسخه‌ی دارویی در این بخش ثبت نمی‌شود؛ برای تجویز دارو از بخش «نسخه و سوابق طبی» استفاده کنید.")}</div>
            <div className="hr-grid hr-grid-2">
              {RECOMMENDATION_FIELDS.map((r) => (
                <Field key={r.key} label={r.label} className={r.key === "other" ? "hr-span-2" : ""}>
                  <textarea className="hr-input" rows={3} maxLength={3000} value={form.recommendations[r.key] || ""} placeholder={r.placeholder}
                    onChange={(e) => set("recommendations", { ...form.recommendations, [r.key]: e.target.value })} />
                </Field>
              ))}
            </div>
          </Section>
        )}

        {tab === 8 && (
          <>
            <Section no={10} title={tr("پیگیری / Follow-up")}>
              <label className="hr-check hr-check-lg"><input type="checkbox" checked={form.followUpRequired} onChange={(e) => set("followUpRequired", e.target.checked)} /> <span>{tr("نیاز به مراجعه مجدد دارد")}</span></label>
              {form.followUpRequired && (
                <div className="hr-grid hr-grid-3">
                  <Field label={tr("تاریخ مراجعه بعدی")} error={errors.followUpDate}><HrDate value={form.followUpDate} onChange={(v) => set("followUpDate", v)} min={form.visitDate} ariaLabel={tr("تاریخ مراجعه بعدی")} /></Field>
                  <Field label={tr("وضعیت پیگیری")}><select className="hr-input" value={form.followUpStatus} onChange={(e) => set("followUpStatus", e.target.value)}>{Object.entries(FOLLOWUP_STATUS).map(([k, v]) => (<option key={k} value={k}>{v}</option>))}</select></Field>
                  <Field label={tr("توضیحات پیگیری")} className="hr-span-3"><textarea className="hr-input" rows={3} maxLength={3000} value={form.followUpNotes} onChange={(e) => set("followUpNotes", e.target.value)} placeholder={tr("توضیحات تکمیلی برای مراجعه بعدی...")} /></Field>
                </div>
              )}
              <p className="hr-note"><Info size={13} /> {tr("زمان‌بندی نوبت جدید فقط از طریق بخش نوبت‌ها انجام می‌شود؛ این‌جا فقط تاریخ و وضعیت پیگیری ثبت می‌شود.")}</p>
            </Section>

            <Section no={11} title={tr("ارسال گزارش پزشکی به مریض")}>
              <div className={`hr-send ${meta.sentToPatientAt ? "is-sent" : ""}`}>
                <div className="hr-send-status">
                  {meta.sentToPatientAt ? <><CheckCircle2 size={18} /> <span>{tr("ارسال‌شده در")} {fmtDateTime(meta.sentToPatientAt)}</span></> : <><Send size={18} /> <span>{meta.status === "registered" ? tr("هنوز برای مریض ارسال نشده است.") : tr("ابتدا پرونده را ثبت نهایی کنید تا امکان ارسال فعال شود.")}</span></>}
                </div>
                <Field label={tr("توضیح کوتاه همراه پرونده (اختیاری)")}><textarea className="hr-input" rows={3} maxLength={1000} value={sendMessage} onChange={(e) => setSendMessage(e.target.value)} /></Field>
                {!canSend && meta.status === "registered" && dirty && <p className="hr-note hr-note-warn"><Info size={13} /> {tr("تغییرات ذخیره‌نشده دارید؛ برای ارسال ابتدا «ثبت پرونده صحی» را بزنید.")}</p>}
              </div>
            </Section>

            <Section no={12} title={tr("جمع‌بندی نهایی")}>
              <ReportView data={reportData} variant="screen" />
            </Section>
          </>
        )}
      </fieldset>

      <div className="hr-stepnav">
        <button type="button" className="btn btn-ghost btn-sm" disabled={tab === 0} onClick={() => setTab((t) => t - 1)}><ChevronRight size={15} /> {tr("مرحله قبل")}</button>
        <span>{toFa(tab + 1)} {tr("از")} {toFa(TABS.length)}</span>
        <button type="button" className="btn btn-ghost btn-sm" disabled={tab === TABS.length - 1} onClick={() => setTab((t) => t + 1)}>{tr("مرحله بعد")} <ChevronLeft size={15} /></button>
      </div>

      <footer className="hr-actions">
        <button type="button" className="hr-btn hr-btn-primary" disabled={!!saving || readOnly} onClick={() => { const e = validate("registered"); if (Object.keys(e).length) { save("registered"); } else setModal({ type: "register" }); }}>
          {saving === "registered" ? <Loader2 size={16} className="hr-spin" /> : <ClipboardList size={16} />} {tr("ثبت پرونده صحی")}
        </button>
        {meta.status !== "registered" && (
          <button type="button" className="hr-btn" disabled={!!saving || readOnly} onClick={() => save("draft")}>{saving === "draft" ? <Loader2 size={16} className="hr-spin" /> : <Save size={16} />} {tr("ذخیره پیش‌نویس")}</button>
        )}
        <button type="button" className="hr-btn hr-btn-send" disabled={!canSend || sending} title={canSend ? "" : tr("ابتدا پرونده را ثبت نهایی (و ذخیره) کنید")} onClick={() => setModal({ type: "send" })}>
          {sending ? <Loader2 size={16} className="hr-spin" /> : <Send size={16} />} {meta.sentToPatientAt ? tr("ارسال مجدد به مریض") : tr("ارسال به مریض")}
        </button>
        <button type="button" className="hr-btn" onClick={() => setPrinting(true)}><Printer size={16} /> {tr("چاپ پرونده صحی")}</button>
      </footer>

      {/* ---- مودال‌ها ---- */}
      <GlobalModal isOpen={modal?.type === "register"} onClose={() => !saving && setModal(null)} title={tr("بررسی نهایی و ثبت پرونده صحی")} size="xl"
        footer={<><button type="button" className="btn btn-ghost" onClick={() => setModal(null)} disabled={!!saving}>{tr("بازگشت به ویرایش")}</button><button type="button" className="btn btn-primary" onClick={() => save("registered")} disabled={!!saving}>{saving ? tr("در حال ثبت...") : tr("تأیید و ثبت پرونده")}</button></>}>
        <p className="hr-modal-lead">{tr("اطلاعات زیر را بررسی کنید. بعد از ثبت، پرونده در سوابق بیمار قرار می‌گیرد و مریض از ثبت آن مطلع می‌شود.")}</p>
        <ReportView data={reportData} variant="screen" />
      </GlobalModal>

      <GlobalModal isOpen={modal?.type === "send"} onClose={() => !sending && setModal(null)} title={tr("ارسال گزارش پزشکی به مریض")} size="lg"
        footer={<><button type="button" className="btn btn-ghost" onClick={() => setModal(null)} disabled={sending}>{tr("انصراف")}</button><button type="button" className="btn btn-primary" onClick={doSend} disabled={sending}>{sending ? tr("در حال ارسال...") : tr("بله، ارسال شود")}</button></>}>
        <p className="hr-modal-lead">{tr("این گزارش برای حساب «{0}» ارسال می‌شود و او می‌تواند اطلاعات پرونده، تشخیص، آزمایش‌ها، تصاویر، فایل‌ها، توصیه‌ها و پیگیری را در بخش «پرونده‌های صحی من» ببیند (بدون امکان ویرایش).", [patient?.fullName || patientName])}</p>
        <ul className="hr-send-sum">
          <li><b>{tr("تاریخ مراجعه:")}</b> {fmtDay(form.visitDate)}</li>
          <li><b>{tr("تشخیص نهایی:")}</b> {form.diagnosis || tr("ثبت نشده")}</li>
          <li><b>{tr("آزمایش‌ها:")}</b> {toFa(labs.filter((l) => l.testName.trim()).length)} {tr("مورد")} &nbsp; <b>{tr("تصاویر:")}</b> {toFa(images.length)} &nbsp; <b>{tr("اسناد:")}</b> {toFa(docs.length)}</li>
          <li><b>{tr("پیگیری:")}</b> {form.followUpRequired ? tr("نیاز دارد{0}", [form.followUpDate ? ` — ${fmtDay(form.followUpDate)}` : ""]) : tr("ندارد")}</li>
        </ul>
        <Field label={tr("توضیح همراه پرونده")}><textarea className="hr-input" rows={3} maxLength={1000} value={sendMessage} onChange={(e) => setSendMessage(e.target.value)} /></Field>
        {meta.sentToPatientAt && <p className="hr-note hr-note-warn"><Info size={13} /> {tr("این پرونده قبلاً در {0} ارسال شده است؛ ارسال مجدد دوباره به مریض اعلان می‌دهد.", [fmtDateTime(meta.sentToPatientAt)])}</p>}
      </GlobalModal>

      <GlobalModal isOpen={modal?.type === "delete"} onClose={() => saving !== "delete" && setModal(null)} size="sm" title={tr("تأیید حذف")}
        footer={<><button type="button" className="btn btn-ghost" onClick={() => setModal(null)} disabled={saving === "delete"}>{tr("انصراف")}</button><button type="button" className="btn btn-danger" onClick={confirmDeleteSaved} disabled={saving === "delete"}>{saving === "delete" ? tr("در حال حذف...") : tr("بله، حذف کن")}</button></>}>
        <p>{tr("آیا از حذف «{0}» مطمئن هستید؟ این عملیات قابل بازگشت نیست.", [modal?.item?.testName || modal?.item?.title || tr("این مورد")])}</p>
      </GlobalModal>

      <GlobalModal isOpen={modal?.type === "leave"} onClose={() => setModal(null)} size="sm" title={tr("تغییرات ذخیره‌نشده")}
        footer={<><button type="button" className="btn btn-ghost" onClick={() => setModal(null)}>{tr("ادامه‌ی ویرایش")}</button><button type="button" className="btn btn-danger" onClick={() => onClose(!!meta.id)}>{tr("خروج بدون ذخیره")}</button></>}>
        <p>{tr("تغییراتی دارید که ذخیره نشده‌اند. اگر خارج شوید از بین می‌روند. می‌توانید ابتدا «ذخیره پیش‌نویس» یا «ثبت پرونده صحی» را بزنید.")}</p>
      </GlobalModal>

      <ImagePreview item={preview} onClose={() => setPreview(null)} />
      {printing && <HealthRecordPrint data={reportData} onDone={() => setPrinting(false)} />}
    </div>
  );
}

function Section({ no, title, aside, children }) {
  return (
    <section className="hr-section">
      <header className="hr-section-head"><span className="hr-section-no">{toFa(no)}</span><h3>{title}</h3>{aside && <span className="hr-section-aside">{aside}</span>}</header>
      <div className="hr-section-body">{children}</div>
    </section>
  );
}

function Dropzone({ kind, onFiles }) {
  const [over, setOver] = useState(false);
  const inputRef = useRef(null);
  const isImage = kind === "image";
  return (
    <div
      className={`hr-drop ${over ? "is-over" : ""}`} role="button" tabIndex={0}
      onClick={() => inputRef.current?.click()} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); inputRef.current?.click(); } }}
      onDragOver={(e) => { e.preventDefault(); setOver(true); }} onDragLeave={() => setOver(false)}
      onDrop={(e) => { e.preventDefault(); setOver(false); if (e.dataTransfer.files?.length) onFiles(e.dataTransfer.files); }}
    >
      <UploadCloud size={26} aria-hidden="true" />
      <b>{isImage ? tr("برای آپلود تصاویر کلیک کنید یا فایل را بکشید") : tr("برای آپلود فایل‌ها کلیک کنید یا بکشید")}</b>
      <small>{isImage ? "JPG, PNG, WEBP" : "PDF, JPG, PNG, WEBP"} {tr("(حداکثر ۱۰MB برای هر فایل)")}</small>
      <input ref={inputRef} type="file" hidden multiple accept={isImage ? ".jpg,.jpeg,.png,.webp" : ".pdf,.jpg,.jpeg,.png,.webp"} onChange={(e) => { if (e.target.files?.length) onFiles(e.target.files); e.target.value = ""; }} />
    </div>
  );
}

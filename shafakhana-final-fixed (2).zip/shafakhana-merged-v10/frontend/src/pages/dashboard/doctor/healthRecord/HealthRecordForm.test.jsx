import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { calcBmi, bmiCategory, fmtDay } from "./hrConstants.js";

vi.mock("../../../../utils/api.js", () => ({
  apiRequest: vi.fn(), apiUpload: vi.fn(), apiDownload: vi.fn(), apiFetchImageUrl: vi.fn(async () => null), resolvePhotoUrl: (u) => u,
}));
vi.mock("../../../../context/SettingsContext.jsx", () => ({
  useSiteSettings: () => ({ settings: { hospitalName: "شفاخانه آزمایشی", hospitalAddress: "هرات", hospitalPhone: "0700", logoUrl: "" } }),
}));
import { apiRequest, apiUpload } from "../../../../utils/api.js";
import HealthRecordForm from "./HealthRecordForm.jsx";

const PATIENT = { id: 5, fullName: "احمد احمدی", publicCode: "AAH-000005", gender: "male", dateOfBirth: "1990-01-01", phone: "0799" };
const DOCTOR = { id: 2, fullName: "داکتر صمدی", department: "داخله" };
const APPTS = [{ appointmentId: 11, appointmentDate: "2026-09-01", appointmentTime: "09:00:00", appointmentStatus: "confirmed" }];

function setup(handler = async () => ({}), props = {}) {
  apiRequest.mockImplementation(async (url, opts = {}) => {
    if (url === "/medical-records/patient/5") return { patient: PATIENT, doctor: DOCTOR, encounters: [] };
    return handler(url, opts);
  });
  const onClose = vi.fn();
  render(<HealthRecordForm patientId={5} patientName="احمد احمدی" appointments={APPTS} defaultAppointmentId={11} onClose={onClose} {...props} />);
  return { onClose };
}
const goTab = (name) => userEvent.click(screen.getByRole("tab", { name: new RegExp(name) }));
const calls = (re) => apiRequest.mock.calls.filter((c) => re.test(c[0]));

beforeEach(() => { apiRequest.mockReset(); apiUpload.mockReset(); window.print = vi.fn(); });

describe("توابع کمکی", () => {
  it("BMI از وزن و قد (سانتی‌متر یا متر) محاسبه می‌شود و مقدار نامعتبر null است", () => {
    expect(calcBmi("70", "175")).toBe(22.9);
    expect(calcBmi("70", "1.75")).toBe(22.9);
    expect(calcBmi("", "175")).toBeNull();
    expect(calcBmi("abc", "175")).toBeNull();
    expect(bmiCategory(22.9)).toBe("نرمال");
    expect(bmiCategory(31)).toBe("چاق");
    expect(fmtDay("2026-10-07")).toBe("۱۴۰۵/۰۷/۱۵");
  });
});

describe("HealthRecordForm — داکتر", () => {
  it("اطلاعات مریض و داکتر خودکار پر می‌شود و دوباره از داکتر پرسیده نمی‌شود", async () => {
    setup();
    expect(await screen.findByText("احمد احمدی")).toBeInTheDocument();
    expect(screen.getByText("AAH-000005")).toBeInTheDocument();
    expect(screen.getByText("داکتر صمدی")).toBeInTheDocument();
    expect(screen.getByText("داخله")).toBeInTheDocument();
    expect(screen.queryByRole("combobox", { name: /مریض/ })).not.toBeInTheDocument();
    expect(calls(/medical-records\/patient\/5/)).toHaveLength(1);
  });

  it("۹ تب مرحله‌ای دارد و BMI از وزن و قد خودکار حساب می‌شود", async () => {
    setup();
    await screen.findByText("احمد احمدی");
    expect(screen.getAllByRole("tab")).toHaveLength(9);
    await goTab("علائم حیاتی");
    await userEvent.type(screen.getByLabelText(/وزن/), "70");
    await userEvent.type(screen.getByLabelText(/قد/), "175");
    expect(screen.getByText("۲۲.۹")).toBeInTheDocument();
    expect(screen.getByText("نرمال")).toBeInTheDocument();
  });

  it("ثبت نهایی بدون دلیل مراجعه ارسال نمی‌شود و خطا نشان می‌دهد", async () => {
    setup();
    await screen.findByText("احمد احمدی");
    await userEvent.click(screen.getByRole("button", { name: /ثبت پرونده صحی/ }));
    expect(await screen.findByText("دلیل اصلی مراجعه برای ثبت نهایی الزامی است.")).toBeInTheDocument();
    expect(calls(/encounters$/).filter((c) => c[1]?.method === "POST")).toHaveLength(0);
  });

  it("پیش‌نویس: POST با status=draft، سپس آزمایش با recordId متصل می‌شود", async () => {
    const handler = async (url, opts) => {
      if (url === "/medical-records/encounters" && opts.method === "POST") return { record: { id: 99, status: "draft" } };
      if (url === "/medical-records/lab-results" && opts.method === "POST") return { item: { id: 7 } };
      return {};
    };
    setup(handler);
    await screen.findByText("احمد احمدی");
    await userEvent.type(screen.getByPlaceholderText(/درد قفسه سینه/), "سردرد");
    await goTab("آزمایش‌ها");
    await userEvent.click(screen.getAllByRole("button", { name: /افزودن آزمایش/ })[0]);
    await userEvent.type(screen.getByLabelText(/نام آزمایش/), "CBC");
    await userEvent.click(screen.getByRole("button", { name: /ذخیره پیش‌نویس/ }));
    await waitFor(() => expect(screen.getByText(/پیش‌نویس ذخیره شد/)).toBeInTheDocument());
    const post = calls(/medical-records\/encounters$/).find((c) => c[1]?.method === "POST");
    expect(post[1].body).toMatchObject({ patientId: 5, status: "draft", visitReason: "سردرد", appointmentId: "11" });
    const lab = calls(/lab-results$/).find((c) => c[1]?.method === "POST");
    expect(lab[1].body).toMatchObject({ patientId: 5, recordId: 99, testName: "CBC" });
    // پس از ثبت، دکمه‌ی ارسال هنوز غیرفعال است (فقط پرونده‌ی ثبت‌شده قابل ارسال است)
    expect(screen.getByRole("button", { name: /ارسال به مریض/ })).toBeDisabled();
  });

  it("آپلود تصویر پزشکی: فرمت/حجم نامعتبر رد می‌شود و فایل معتبر با کلیدهای درست آپلود می‌شود", async () => {
    const handler = async (url, opts) => {
      if (url === "/medical-records/encounters" && opts.method === "POST") return { record: { id: 99, status: "draft" } };
      return {};
    };
    apiUpload.mockResolvedValue({ file: { id: 31 } });
    URL.createObjectURL = vi.fn(() => "blob:x"); URL.revokeObjectURL = vi.fn();
    setup(handler);
    await screen.findByText("احمد احمدی");
    await goTab("تصاویر و فایل‌ها");
    const inputs = document.querySelectorAll('input[type="file"]');
    await userEvent.upload(inputs[0], new File(["x"], "bad.exe", { type: "application/x-msdownload" }), { applyAccept: false });
    expect(await screen.findByText(/فرمت مجاز نیست/)).toBeInTheDocument();
    await userEvent.upload(inputs[0], new File(["png"], "chest.png", { type: "image/png" }));
    expect(await screen.findByDisplayValue("chest")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: /ذخیره پیش‌نویس/ }));
    await waitFor(() => expect(apiUpload).toHaveBeenCalled());
    const [url, fd] = apiUpload.mock.calls[0];
    expect(url).toBe("/medical-records/encounters/99/files");
    expect(fd.get("kind")).toBe("image");
    expect(fd.get("title")).toBe("chest");
    expect(fd.get("file").name).toBe("chest.png");
  });

  it("بخش توصیه‌ها هیچ فیلد دارو/نسخه ندارد و به «نسخه و سوابق طبی» ارجاع می‌دهد", async () => {
    setup();
    await screen.findByText("احمد احمدی");
    await goTab("توصیه‌ها");
    expect(screen.getByText(/نسخه‌ی دارویی در این بخش ثبت نمی‌شود/)).toBeInTheDocument();
    expect(screen.queryByLabelText(/دارو|medication/i)).not.toBeInTheDocument();
    ["توصیه‌های داکتر", "مراقبت‌های لازم", "رژیم غذایی", "استراحت", "توصیه برای انجام آزمایش", "سایر توصیه‌ها"].forEach((l) => expect(screen.getByLabelText(l)).toBeInTheDocument());
  });

  it("ثبت نهایی: خلاصه نمایش داده می‌شود، تأیید → POST registered، سپس ارسال با تأیید و توضیح", async () => {
    const handler = async (url, opts) => {
      if (url === "/medical-records/encounters" && opts.method === "POST") return { record: { id: 99, status: "registered" } };
      if (url === "/medical-records/encounters/99/send") return { record: { sentToPatientAt: "2026-10-08T10:00:00Z", sentNote: opts.body.message } };
      return {};
    };
    setup(handler);
    await screen.findByText("احمد احمدی");
    await userEvent.type(screen.getByPlaceholderText(/درد قفسه سینه/), "تب");
    await goTab("تشخیص");
    await userEvent.type(screen.getByLabelText(/تشخیص نهایی/), "سرماخوردگی");
    await userEvent.click(screen.getByRole("button", { name: /ثبت پرونده صحی/ }));
    const dlg = await screen.findByRole("dialog");
    expect(within(dlg).getByText("سرماخوردگی")).toBeInTheDocument(); // خلاصه
    expect(within(dlg).getByText("AAH-000005")).toBeInTheDocument();
    await userEvent.click(within(dlg).getByRole("button", { name: /تأیید و ثبت پرونده/ }));
    await waitFor(() => expect(screen.getByText(/پرونده صحی با موفقیت ثبت شد/)).toBeInTheDocument());
    const post = calls(/encounters$/).find((c) => c[1]?.method === "POST");
    expect(post[1].body).toMatchObject({ status: "registered", diagnosis: "سرماخوردگی", visitReason: "تب" });
    const sendBtn = screen.getByRole("button", { name: /ارسال به مریض/ });
    expect(sendBtn).toBeEnabled();
    await userEvent.click(sendBtn);
    const sdlg = await screen.findByRole("dialog");
    expect(apiRequest).not.toHaveBeenCalledWith("/medical-records/encounters/99/send", expect.anything()); // بدون تأیید ارسال نمی‌شود
    await userEvent.click(within(sdlg).getByRole("button", { name: /بله، ارسال شود/ }));
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("/medical-records/encounters/99/send", { method: "POST", body: { message: expect.stringContaining("نتایج بررسی شما ثبت گردید") } }));
    expect(await screen.findByText(/گزارش پزشکی برای مریض ارسال شد/)).toBeInTheDocument();
  });

  it("چاپ: برگه‌ی A4 با سربرگ شفاخانه و بدون نسخه‌ی دارویی ساخته و window.print صدا زده می‌شود", async () => {
    setup();
    await screen.findByText("احمد احمدی");
    await userEvent.type(screen.getByPlaceholderText(/درد قفسه سینه/), "سرفه");
    await userEvent.click(screen.getByRole("button", { name: /چاپ پرونده صحی/ }));
    await waitFor(() => expect(window.print).toHaveBeenCalled(), { timeout: 3000 });
    const root = document.querySelector(".hr-print-root");
    expect(root).toBeTruthy();
    expect(document.body.classList.contains("hr-printing")).toBe(true);
    expect(within(root).getByText("شفاخانه آزمایشی")).toBeInTheDocument();
    expect(within(root).getAllByText("AAH-000005").length).toBeGreaterThanOrEqual(2); // سربرگ + اطلاعات مریض
    expect(root.textContent).not.toMatch(/نسخه‌ی دارویی|نسخه دارویی|Prescription/);
    window.dispatchEvent(new Event("afterprint"));
    await waitFor(() => expect(document.querySelector(".hr-print-root")).toBeNull());
    expect(document.body.classList.contains("hr-printing")).toBe(false);
  });

  it("ویرایش پرونده‌ی ثبت‌شده: داده از report پر می‌شود و با PUT ذخیره می‌شود", async () => {
    const report = {
      record: { id: 40, status: "registered", visitDate: "2026-09-01", visitReason: "درد", symptoms: "x", pulse: "70", diagnosis: "الف", systemsReview: {}, recommendations: { advice: "استراحت" }, followUpRequired: 0 },
      patient: PATIENT, doctor: DOCTOR, labResults: [{ id: 3, testName: "FBS", result: "90", unit: "mg", referenceRange: "70-100", status: "completed", testDate: "2026-09-01", reportUrl: null }], files: [], canEdit: true,
    };
    const handler = async (url, opts) => {
      if (url === "/medical-records/encounters/40/report") return report;
      if (url === "/medical-records/encounters/40" && opts.method === "PUT") return { record: { id: 40 } };
      return {};
    };
    apiRequest.mockImplementation(async (url, opts = {}) => handler(url, opts));
    render(<HealthRecordForm patientId={5} patientName="احمد" recordId={40} appointments={[]} onClose={vi.fn()} />);
    expect(await screen.findByDisplayValue("درد")).toBeInTheDocument();
    await goTab("آزمایش‌ها");
    expect(screen.getByDisplayValue("FBS")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: /ثبت پرونده صحی/ }));
    await userEvent.click(await screen.findByRole("button", { name: /تأیید و ثبت پرونده/ }));
    await waitFor(() => expect(calls(/encounters\/40$/).some((c) => c[1]?.method === "PUT")).toBe(true));
    expect(calls(/lab-results$/).filter((c) => c[1]?.method === "POST")).toHaveLength(0); // آزمایش دست‌نخورده دوباره ثبت نمی‌شود
  });
});

import { useEffect } from "react";
import { createPortal } from "react-dom";
import { resolvePhotoUrl } from "../../../../utils/api.js";
import { useSiteSettings } from "../../../../context/SettingsContext.jsx";
import ReportView from "./ReportView.jsx";
import { fmtDay, toFa } from "./hrConstants.js";
import { tr, curDir, numLocale } from "../../../../i18n/tr.js";

// چاپ پرونده صحی (A4): فقط این برگه چاپ می‌شود؛ سایدبار/هدر/دکمه‌های داشبورد با CSS چاپ (body.hr-printing) پنهان‌اند.
// نسخه‌ی دارویی در این برگه وجود ندارد. تصاویر پزشکی (در صورت وجود) پیش از باز شدن دیالوگ چاپ کامل بارگذاری می‌شوند.
export default function HealthRecordPrint({ data, onDone }) {
  const { settings } = useSiteSettings();

  useEffect(() => {
    document.body.classList.add("hr-printing");
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      document.body.classList.remove("hr-printing");
      window.removeEventListener("afterprint", finish);
      onDone();
    };
    window.addEventListener("afterprint", finish);

    // صبر برای بارگذاری تصاویر (حداکثر ۵ ثانیه) و بعد دیالوگ چاپ
    let cancelled = false;
    const started = Date.now();
    const tick = () => {
      if (cancelled) return;
      const imgs = Array.from(document.querySelectorAll(".hr-print-root img"));
      const pending = imgs.some((im) => !im.complete);
      const skeletons = document.querySelectorAll(".hr-print-root .hr-img-skel").length > 0;
      if ((pending || skeletons) && Date.now() - started < 5000) { setTimeout(tick, 150); return; }
      setTimeout(() => { if (!cancelled) window.print(); }, 100);
    };
    tick();
    // اگر مرورگر afterprint نفرستاد (مثلاً انصراف)، پاک‌سازی با تأخیر انجام می‌شود
    return () => { cancelled = true; window.removeEventListener("afterprint", finish); document.body.classList.remove("hr-printing"); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const { patient, form } = data;
  return createPortal(
    <div className="hr-print-root" dir={curDir()}>
      <article className="hr-print-sheet">
        <header className="hr-print-head">
          {settings.logoUrl ? <img className="hr-print-logo" src={resolvePhotoUrl(settings.logoUrl)} alt="" /> : null}
          <div className="hr-print-hosp">
            <h2>{settings.hospitalName}</h2>
            <p>{settings.hospitalAddress || ""}{settings.hospitalPhone ? <> {"  |  "} {tr("تلفن:")} <span dir="ltr">{settings.hospitalPhone}</span></> : null}</p>
          </div>
          <div className="hr-print-meta">
            <b>{tr("پرونده صحی")}</b>
            <span>{tr("شماره پرونده:")} <span dir="ltr">{patient?.publicCode || "—"}</span></span>
            <span>{tr("تاریخ مراجعه:")} {fmtDay(form.visitDate)}</span>
          </div>
        </header>
        <ReportView data={data} variant="print" />
        <footer className="hr-print-foot">
          <div className="hr-print-sign"><span>{tr("امضا و مهر داکتر")}</span></div>
          <p>{tr("این پرونده به صورت الکترونیکی از سامانه {0} صادر شده است. تاریخ چاپ: {1}", [settings.hospitalName, toFa(new Date().toLocaleDateString(numLocale()))])}</p>
        </footer>
      </article>
    </div>,
    document.body
  );
}

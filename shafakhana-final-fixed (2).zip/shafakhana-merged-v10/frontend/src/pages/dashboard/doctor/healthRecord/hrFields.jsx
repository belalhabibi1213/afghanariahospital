import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";
import { apiFetchImageUrl } from "../../../../utils/api.js";

import { JalaliDateInput } from "../../../../components/JalaliDateInput.jsx";
import { tr, jdate } from "../../../../i18n/tr.js";
// برچسب + کنترل + راهنما/خطا (ظاهر یکسان همه‌ی فیلدهای فرم)
export function Field({ label, required, hint, error, children, className = "" }) {
  return (
    <label className={`hr-field ${className}`}>
      <span className="hr-label">{label}{required && <b className="hr-req" aria-hidden="true"> *</b>}</span>
      {children}
      {error ? <span className="hr-err" role="alert">{error}</span> : hint ? <span className="hr-hint">{hint}</span> : null}
    </label>
  );
}

// فیلد تاریخ: نمایش شمسی؛ مقدار واقعی همان ISO میلادی است که API می‌خواهد (input اصلی شفاف روی کادر)
export function HrDate({ value, onChange, placeholder = tr("انتخاب تاریخ"), min, max, ariaLabel }) {
  return (
    <span className="hr-datebox">
      <JalaliDateInput value={value || ""} min={min || undefined} max={max || undefined} aria-label={ariaLabel} placeholder={placeholder} onChange={(e) => onChange(e.target.value)} />
    </span>
  );
}

// تصویر خصوصی که نیاز به نشست دارد (فایل‌های ذخیره‌شده‌ی پرونده) → Blob URL؛ یا تصویر محلی (src)
export function SecureImage({ path, src, alt = "", className, onLoaded, onClick }) {
  const [url, setUrl] = useState(src || null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    if (src) { setUrl(src); return undefined; }
    if (!path) return undefined;
    let revoked = false;
    let created = null;
    apiFetchImageUrl(path)
      .then((u) => { if (revoked) { if (u) URL.revokeObjectURL(u); return; } created = u; setUrl(u); if (!u) setFailed(true); })
      .catch(() => { if (!revoked) setFailed(true); });
    return () => { revoked = true; if (created) URL.revokeObjectURL(created); };
  }, [path, src]);
  if (failed) return <span className={`hr-img-fail ${className || ""}`}>{tr("تصویر بارگذاری نشد")}</span>;
  if (!url) return <span className={`hr-img-skel ${className || ""}`} aria-hidden="true" />;
  return <img className={className} src={url} alt={alt} onLoad={onLoaded} onError={() => setFailed(true)} onClick={onClick} />;
}

// پیش‌نمایش بزرگ تصویر (Lightbox) — با Esc و کلیک روی پس‌زمینه بسته می‌شود
export function ImagePreview({ item, onClose }) {
  useEffect(() => {
    if (!item) return undefined;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [item, onClose]);
  if (!item) return null;
  return createPortal(
    <div className="hr-lightbox" role="dialog" aria-modal="true" aria-label={item.title || tr("پیش‌نمایش تصویر")} onClick={onClose}>
      <div className="hr-lightbox-box" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="hr-lightbox-close" onClick={onClose} aria-label={tr("بستن")}><X size={18} /></button>
        <SecureImage path={item.path} src={item.src} alt={item.title} className="hr-lightbox-img" />
        <div className="hr-lightbox-cap">
          <b>{item.title}</b>
          {item.date && <span>{jdate(item.date)}</span>}
          {item.description && <p>{item.description}</p>}
        </div>
      </div>
    </div>,
    document.body
  );
}

import { tr, trc, tdigits, numLocale } from "../../../../i18n/tr.js";

// ثابت‌ها و توابع کمکی فرم «افزودن پرونده صحی» (پنل داکتر → بیماران من) و نمای فقط‌خواندنیِ بیمار.
// همه‌ی داده‌ها از همان APIهای موجود می‌آیند؛ اینجا فقط برچسب‌ها و تبدیل‌ها (بدون هیچ داده‌ی ساختگی).

export const TABS = trc([
  { key: "visit", label: "اطلاعات مراجعه" },
  { key: "vitals", label: "علائم حیاتی" },
  { key: "history", label: "شرح حال و علائم" },
  { key: "exam", label: "معاینه" },
  { key: "diagnosis", label: "تشخیص" },
  { key: "labs", label: "آزمایش‌ها" },
  { key: "files", label: "تصاویر و فایل‌ها" },
  { key: "recs", label: "توصیه‌ها" },
  { key: "followup", label: "پیگیری و ارسال" },
]);

export const GENERAL_CONDITIONS = ["خوب", "متوسط", "ضعیف", "بحرانی"];

export const SYSTEMS = trc([
  { key: "cardiovascular", label: "قلبی و عروقی" },
  { key: "respiratory", label: "تنفسی" },
  { key: "gastrointestinal", label: "گوارشی" },
  { key: "neurological", label: "عصبی" },
  { key: "musculoskeletal", label: "عضلانی و اسکلتی" },
  { key: "skin", label: "پوست" },
  { key: "ent", label: "گوش، حلق و بینی" },
  { key: "genitourinary", label: "ادراری و تناسلی" },
]);

export const RECOMMENDATION_FIELDS = trc([
  { key: "advice", label: "توصیه‌های داکتر", placeholder: "مثلاً: از فعالیت سنگین پرهیز کنید..." },
  { key: "care", label: "مراقبت‌های لازم", placeholder: "مراقبت‌های روزانه و علائم هشدار..." },
  { key: "diet", label: "رژیم غذایی", placeholder: "مثلاً: رژیم کم‌نمک، پرهیز از غذاهای چرب..." },
  { key: "rest", label: "استراحت", placeholder: "مدت و نوع استراحت..." },
  { key: "tests", label: "توصیه برای انجام آزمایش", placeholder: "آزمایش یا تصویربرداری لازم قبل از مراجعه بعدی..." },
  { key: "other", label: "سایر توصیه‌ها", placeholder: "" },
]);

export const IMAGE_CATEGORIES = trc({ xray: "X-Ray", ct: "CT Scan", mri: "MRI", ultrasound: "سونوگرافی", wound: "تصویر زخم", other: "سایر تصاویر پزشکی" });
export const DOC_CATEGORIES = trc({ medical_report: "گزارش پزشکی", radiology_report: "گزارش رادیولوژی", other: "سایر اسناد" });
export const FOLLOWUP_STATUS = trc({ pending: "در انتظار", scheduled: "زمان‌بندی‌شده", completed: "انجام‌شده", cancelled: "لغوشده" });
export const LAB_STATUS = trc({ completed: "تکمیل‌شده", pending: "در انتظار نتیجه" });

export const DEFAULT_SEND_MESSAGE = "نتایج بررسی شما ثبت گردید. لطفاً توصیه‌های پزشکی را مطالعه کرده و در صورت نیاز برای پیگیری مراجعه نمایید.";

// محدودیت‌های فایل = همان محدودیت‌های فعلی بک‌اند (گزارش آزمایشگاهی): JPG/PNG/WEBP/PDF و حداکثر ۱۰ مگابایت
export const MAX_FILE_SIZE = 10 * 1024 * 1024;
export const IMAGE_TYPES = ["image/jpeg", "image/png", "image/webp"];
export const DOC_TYPES = ["application/pdf", "image/jpeg", "image/png", "image/webp"];

// ---------- قالب‌بندی (ارقام فارسی، تاریخ شمسی) ----------
export const toFa = (s) => tdigits(String(s ?? ""));
// قالب‌دهنده‌ها هنگام فراخوانی ساخته می‌شوند تا با تغییر زبان، تاریخ/ارقام زبان جدید را بگیرند
const dfDate = { format: (d) => new Intl.DateTimeFormat(numLocale(), { year: "numeric", month: "2-digit", day: "2-digit" }).format(d) };
const dfTime = { format: (d) => new Intl.DateTimeFormat(numLocale(), { hour: "2-digit", minute: "2-digit", hour12: false }).format(d) };
// ورودی «YYYY-MM-DD» (یا ISO کامل) → «۱۴۰۴/۰۷/۱۵»
export function fmtDay(v) {
  if (!v) return "—";
  const str = String(v);
  const d = /^\d{4}-\d{2}-\d{2}$/.test(str.slice(0, 10)) ? new Date(`${str.slice(0, 10)}T00:00:00`) : new Date(str);
  return Number.isNaN(d.getTime()) ? "—" : dfDate.format(d);
}
export function fmtDateTime(v) {
  if (!v) return "—";
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? "—" : `${dfDate.format(d)} ${dfTime.format(d)}`;
}
export const todayISO = () => {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
export const isoDay = (v) => (v ? String(v).slice(0, 10) : "");

// ---------- BMI از وزن (kg) و قد (cm؛ اگر ≤ 3 باشد متر فرض می‌شود) ----------
const num = (v) => {
  const m = String(v ?? "").replace(/[٠-٩۰-۹]/g, (c) => String(c.charCodeAt(0) & 15)).match(/\d+(\.\d+)?/);
  return m ? parseFloat(m[0]) : NaN;
};
export function calcBmi(weight, height) {
  const w = num(weight);
  let h = num(height);
  if (!(w > 0) || !(h > 0)) return null;
  if (h > 3) h /= 100;
  const bmi = w / (h * h);
  return Number.isFinite(bmi) && bmi > 5 && bmi < 120 ? Math.round(bmi * 10) / 10 : null;
}
export function bmiCategory(bmi) {
  if (bmi == null) return "";
  if (bmi < 18.5) return tr("کم‌وزن");
  if (bmi < 25) return tr("نرمال");
  if (bmi < 30) return tr("اضافه‌وزن");
  return tr("چاق");
}

// ---------- حالت اولیه‌ی فرم و تبدیل از/به رکورد سرور ----------
export const EMPTY_FORM = () => ({
  visitDate: todayISO(), appointmentId: "", visitReason: "",
  bloodPressure: "", pulse: "", temperature: "", respiratoryRate: "", weight: "", height: "", spo2: "",
  chiefComplaint: "", symptoms: "",
  generalCondition: "", examFindings: "", systemsReview: {}, abnormalFindings: "", examNotes: "",
  primaryDiagnosis: "", diagnosis: "", diagnosisNotes: "",
  recommendations: {},
  followUpRequired: false, followUpDate: "", followUpStatus: "pending", followUpNotes: "",
});

export function formFromRecord(rec) {
  const s = (v) => (v == null ? "" : String(v));
  return {
    visitDate: isoDay(rec.visitDate) || todayISO(), appointmentId: rec.appointmentId ? String(rec.appointmentId) : "", visitReason: s(rec.visitReason),
    bloodPressure: s(rec.bloodPressure), pulse: s(rec.pulse), temperature: s(rec.temperature), respiratoryRate: s(rec.respiratoryRate),
    weight: s(rec.weight), height: s(rec.height), spo2: s(rec.spo2),
    chiefComplaint: s(rec.chiefComplaint), symptoms: s(rec.symptoms),
    generalCondition: s(rec.generalCondition), examFindings: s(rec.examFindings), systemsReview: rec.systemsReview || {}, abnormalFindings: s(rec.abnormalFindings), examNotes: s(rec.examNotes),
    primaryDiagnosis: s(rec.primaryDiagnosis), diagnosis: s(rec.diagnosis), diagnosisNotes: s(rec.diagnosisNotes),
    recommendations: rec.recommendations || {},
    followUpRequired: !!Number(rec.followUpRequired), followUpDate: isoDay(rec.followUpDate), followUpStatus: rec.followUpStatus || "pending", followUpNotes: s(rec.followUpNotes),
  };
}

// بدنه‌ی POST/PUT /medical-records/encounters. رشته‌ی خالی = «پاک کن» (سرور همین قرارداد را دارد)
export function payloadFromForm(f) {
  return {
    visitDate: f.visitDate || undefined,
    appointmentId: f.appointmentId || undefined,
    visitReason: f.visitReason.trim(), chiefComplaint: f.chiefComplaint.trim(), symptoms: f.symptoms.trim(),
    bloodPressure: f.bloodPressure.trim(), pulse: f.pulse.trim(), temperature: f.temperature.trim(), respiratoryRate: f.respiratoryRate.trim(),
    weight: f.weight.trim(), height: f.height.trim(), spo2: f.spo2.trim(),
    generalCondition: f.generalCondition, examFindings: f.examFindings.trim(), systemsReview: f.systemsReview, abnormalFindings: f.abnormalFindings.trim(), examNotes: f.examNotes.trim(),
    primaryDiagnosis: f.primaryDiagnosis.trim(), diagnosis: f.diagnosis.trim(), diagnosisNotes: f.diagnosisNotes.trim(),
    recommendations: f.recommendations,
    followUpRequired: !!f.followUpRequired, followUpDate: f.followUpRequired ? f.followUpDate : "", followUpStatus: f.followUpRequired ? f.followUpStatus : "", followUpNotes: f.followUpRequired ? f.followUpNotes.trim() : "",
  };
}

export function ageFromDob(dob) {
  if (!dob) return null;
  const d = new Date(dob);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  let age = now.getFullYear() - d.getFullYear();
  if (now < new Date(now.getFullYear(), d.getMonth(), d.getDate())) age -= 1;
  return age >= 0 ? age : null;
}
export const GENDER_LABEL = trc({ male: "مرد", female: "زن" });
export const fileSizeLabel = (n) => (n >= 1048576 ? `${toFa((n / 1048576).toFixed(1))} MB` : `${toFa(Math.max(1, Math.round(n / 1024)))} KB`);
export const fileBaseName = (name) => String(name || "").replace(/\.[^.]+$/, "");
let seq = 0;
export const tempId = () => `t${Date.now()}${(seq += 1)}`;

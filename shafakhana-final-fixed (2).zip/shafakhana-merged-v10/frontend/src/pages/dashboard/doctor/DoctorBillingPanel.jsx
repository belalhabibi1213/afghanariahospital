import { useEffect, useRef, useState } from "react";
import {
  FileSpreadsheet, FileText, Printer,
} from "lucide-react";
import GlobalModal from "../../../components/GlobalModal.jsx";
import InvoiceDetail, { INVOICE_STATUS_LABEL, getApprovalStatusKey } from "../../../components/dashboard/InvoiceDetail.jsx";
import { apiRequest } from "../../../utils/api.js";
import useHighlightParam from "../../../hooks/useHighlightParam.js";
import { ListPager } from "./doctorListUi.jsx";
// تب «صورت‌حساب و فاکتورها»ی داکتر — از DoctorDashboard جدا شده تا lazy-load شود.
import "./DoctorPatientsPanel.css";

import { tr, curDir, jdate } from "../../../i18n/tr.js";
// ---------- صورت‌حساب و فاکتورها (پنل داکتر) ----------
// فهرست فاکتورهای بیمارانِ خودِ داکتر (فقط کسانی که با او نوبت گرفته‌اند یا فاکتور
// مستقیماً به نام او صادر شده — RBAC روی سرور در myDoctorInvoices/myDoctorInvoiceDetail
// اعمال می‌شود، اینجا فقط UI است). داکتر فقط خواندنی دسترسی دارد؛ ثبت پرداخت/صدور فاکتور
// همچنان مختص پنل Admin/Super Admin است. جزئیات/چاپ فاکتور با همان کامپوننت مشترک
// InvoiceDetail (که در پنل ادمین و پنل بیمار هم استفاده می‌شود) نمایش داده می‌شود تا
// منطق نمایش/چاپ تکراری نشود.
export default function MyDoctorBilling() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const { highlightRowProps } = useHighlightParam();
  const [statusFilter, setStatusFilter] = useState("all"); // all | approved | pending
  const [printMenuOpen, setPrintMenuOpen] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20); // تعداد فاکتور در هر صفحه (مثل بقیه‌ی فهرست‌های پنل)
  const tableRef = useRef(null);

  function reload() {
    setLoading(true);
    setError("");
    apiRequest("/doctors/me/invoices")
      .then((data) => setInvoices(data.invoices || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(reload, []);

  async function openDetail(id) {
    setError("");
    setDetailLoading(true);
    try {
      const data = await apiRequest(`/doctors/me/invoices/${id}`);
      setSelected(data.invoice);
    } catch (err) {
      setError(err.message);
    } finally {
      setDetailLoading(false);
    }
  }

  const filtered = invoices.filter((inv) => {
    if (statusFilter === "all") return true;
    return getApprovalStatusKey(inv) === statusFilter;
  });

  // صفحه‌بندی سمت کلاینت (API همه‌ی فاکتورها را یک‌جا برمی‌گرداند)
  const totalPages = Math.max(1, Math.ceil(filtered.length / limit));
  const currentPage = Math.min(page, totalPages);
  // هنگام ساخت PDF همه‌ی ردیف‌ها (نه فقط صفحه‌ی جاری) رندر می‌شوند تا خروجی کامل بماند
  const rows = exporting ? filtered : filtered.slice((currentPage - 1) * limit, currentPage * limit);

  async function exportToPDF() {
    setPrintMenuOpen(false);
    if (!tableRef.current || filtered.length === 0) return;
    setExporting(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 80)); // رندر همه‌ی ردیف‌ها
      const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([
        import("html2canvas"),
        import("jspdf"),
      ]);
      const canvas = await html2canvas(tableRef.current, { scale: 2, backgroundColor: "#ffffff" });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pageWidth - 40;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 20;
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight - 40;
      while (heightLeft > 0) {
        position = heightLeft - imgHeight + 20;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
        heightLeft -= pageHeight - 40;
      }
      pdf.save(`invoices-${Date.now()}.pdf`);
    } catch (err) {
      setError(tr("خطا در ساخت فایل PDF"));
    } finally {
      setExporting(false);
    }
  }

  async function exportToExcel() {
    setPrintMenuOpen(false);
    if (filtered.length === 0) return;
    setExporting(true);
    try {
      const { downloadXlsx } = await import("../../../utils/exportXlsx.js");
      const xlsxRows = filtered.map((inv) => ({
        [tr("شماره فاکتور")]: inv.invoiceNumber,
        [tr("بیمار")]: inv.patientName,
        [tr("تاریخ")]: jdate(inv.issueDate, { latin: true }),
        [tr("مبلغ کل")]: inv.totalAmount,
        [tr("پرداخت‌شده")]: inv.paidAmount,
        [tr("وضعیت")]: INVOICE_STATUS_LABEL[getApprovalStatusKey(inv)],
      }));
      await downloadXlsx(`invoices-${Date.now()}.xlsx`, [{ name: tr("فاکتورها"), rows: xlsxRows }]);
    } catch (err) {
      setError(tr("خطا در ساخت فایل Excel"));
    } finally {
      setExporting(false);
    }
  }

  return (
    <div className="dash-card glass">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10, position: "relative" }}>
        <h2>{tr("صورت‌حساب و فاکتورها")}</h2>
        <div style={{ position: "relative" }}>
          <button
            type="button"
            className="btn btn-ghost btn-sm"
            disabled={exporting || filtered.length === 0}
            onClick={() => setPrintMenuOpen((o) => !o)}
          >
            <Printer size={16} /> {exporting ? tr("در حال آماده‌سازی...") : tr("چاپ")}
          </button>
          {printMenuOpen && (
            <div className="print-menu-dark">
              <button type="button" className="btn btn-ghost btn-sm print-menu-dark-item" onClick={exportToPDF}>
                <FileText size={16} /> {tr("خروجی PDF")}
              </button>
              <button type="button" className="btn btn-ghost btn-sm print-menu-dark-item" onClick={exportToExcel}>
                <FileSpreadsheet size={16} /> {tr("خروجی Excel")}
              </button>
            </div>
          )}
        </div>
      </div>
      <p style={{ marginTop: -6, marginBottom: 16, color: "var(--muted, #7a8699)" }}>
        {tr("فهرست فاکتورهای بیمارانی که با شما نوبت گرفته‌اند.")}
      </p>

      <div className="field" style={{ maxWidth: 260, marginBottom: 14 }}>
        <label>{tr("فیلتر بر اساس وضعیت")}</label>
        <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}>
          <option value="all">{tr("همه فاکتورها")}</option>
          <option value="approved">{tr("تایید شده")}</option>
          <option value="pending">{tr("در انتظار تایید")}</option>
        </select>
      </div>

      {error && <div className="form-message error">{error}</div>}
      {loading && <p>{tr("در حال بارگذاری...")}</p>}
      {!loading && filtered.length === 0 && <p>{tr("هیچ فاکتوری موجود نیست. (No invoices available.)")}</p>}
      {!loading && filtered.length > 0 && (
        <table className="dash-table" ref={tableRef} dir={curDir()}>
          <thead>
            <tr>
              <th>{tr("شماره فاکتور")}</th>
              <th>{tr("بیمار")}</th>
              <th>{tr("تاریخ")}</th>
              <th>{tr("مبلغ کل")}</th>
              <th>{tr("پرداخت‌شده")}</th>
              <th>{tr("وضعیت")}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {rows.map((inv) => (
              <tr key={inv.id} {...highlightRowProps(inv.id)}>
                <td>{inv.invoiceNumber}</td>
                <td>{inv.patientName}</td>
                <td>{jdate(inv.issueDate)}</td>
                <td>{inv.totalAmount}</td>
                <td>{inv.paidAmount}</td>
                <td>
                  <span className={`status-badge status-${getApprovalStatusKey(inv)}`}>
                    {INVOICE_STATUS_LABEL[getApprovalStatusKey(inv)]}
                  </span>
                </td>
                <td>
                  <button className="btn btn-ghost btn-sm" type="button" disabled={detailLoading} onClick={() => openDetail(inv.id)}>
                    {detailLoading ? "..." : tr("مشاهده / چاپ 🖨️")}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      {!loading && filtered.length > 0 && (
        <ListPager
          pagination={{ total: filtered.length, page: currentPage, totalPages }}
          limit={limit}
          loading={exporting}
          noun={tr("فاکتور")}
          onPage={setPage}
          onLimit={(n) => { setLimit(n); setPage(1); }}
        />
      )}

      <GlobalModal
        isOpen={!!selected}
        onClose={() => setSelected(null)}
        size="lg"
        title={tr("جزئیات فاکتور")}
        labelledBy="doctor-invoice-detail-title"
      >
        {selected && <InvoiceDetail invoice={selected} onClose={() => setSelected(null)} />}
      </GlobalModal>
    </div>
  );
}

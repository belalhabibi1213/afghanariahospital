import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle, ArrowLeft, Building2, CalendarClock, CalendarDays, CalendarOff, CalendarRange, Hourglass,
  Layers, Lock, RefreshCw, X,
} from "lucide-react";
import { apiRequest } from "../../../utils/api.js";
import { ExportMenu, Kpi, SkeletonKpis, SkeletonTable, cx, errDetail, exportElementToPdf, fmtTime, toFa, dept } from "./doctorWorkspaceUi.jsx";
import { tr, curDir, jdate } from "../../../i18n/tr.js";

// ---------- برنامه کاری من (فقط مشاهده) ----------
// دسترسی داکتر به برنامه کاری «فقط خواندنی» است: می‌تواند برنامه کاری خودش را ببیند اما
// نمی‌تواند بازه‌ی جدیدی اضافه کند، ویرایش کند یا حذف کند (RBAC). ایجاد/ویرایش/حذف برنامه
// کاری فقط از طریق پنل Admin/Super Admin انجام می‌شود؛ به همین دلیل در این صفحه هیچ دکمه‌ی
// «افزودن»، «ویرایش» یا «حذف»ای نمایش داده نمی‌شود.
// همه‌ی اعداد/خلاصه‌ها فقط از همان schedules واقعیِ GET /doctors/me/schedules محاسبه می‌شوند.

const DAY_ORDER = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
const JS_DAY_NAME = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"]; // ترتیب Date.getDay()

// یکسان‌سازی املا (نیم‌فاصله/فاصله، ي/ی، ك/ک) فقط برای مقایسه؛ متن نمایشی همان مقدار اصلی است
const normDay = (s) => String(s || "").replace(/[\u200c\u200f\s]/g, "").replace(/ي/g, "ی").replace(/ك/g, "ک");
const DAY_INDEX = new Map(DAY_ORDER.map((d, i) => [normDay(d), i]));
const splitDays = (value) => String(value || "").split(/[,،;/|]+/).map((d) => d.trim()).filter(Boolean);

function toMinutes(t) {
  const m = /^(\d{1,2}):(\d{2})/.exec(String(t || ""));
  return m ? Number(m[1]) * 60 + Number(m[2]) : null;
}
// مدت بازه (دقیقه)؛ اگر ساعت‌ها نامعتبر یا پایان ≤ شروع باشد، حدس زده نمی‌شود
function durationMinutes(s) {
  const a = toMinutes(s.startTime);
  const b = toMinutes(s.endTime);
  return a !== null && b !== null && b > a ? b - a : null;
}
function formatDuration(min) {
  if (!Number.isFinite(min) || min <= 0) return "";
  const h = Math.floor(min / 60);
  const m = min % 60;
  const parts = [];
  if (h) parts.push(tr("{0} ساعت", [toFa(h)]));
  if (m) parts.push(tr("{0} دقیقه", [toFa(m)]));
  return parts.join(tr(" و "));
}
function dayRank(s) {
  const first = splitDays(s.dayOfWeek)[0];
  const idx = DAY_INDEX.get(normDay(first));
  return idx === undefined ? 99 : idx;
}
function shiftTone(shift) {
  return shift ? "info" : "neutral";
}

function TimeRange({ s }) {
  return (
    <span className="dw-range">
      <bdi>{fmtTime(s.startTime)}</bdi>
      <ArrowLeft size={14} aria-hidden="true" />
      <bdi>{fmtTime(s.endTime)}</bdi>
    </span>
  );
}

export default function DoctorSchedulePanel() {
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null); // خطای دریافت (با امکان تلاش مجدد)
  const [exportError, setExportError] = useState("");
  const [exporting, setExporting] = useState(false);
  const scheduleRef = useRef(null);

  // همان درخواست قبلی؛ «تلاش مجدد» فقط همین API را دوباره می‌فرستد
  function reload() {
    setLoading(true);
    setError(null);
    return apiRequest("/doctors/me/schedules")
      .then((data) => setSchedules(Array.isArray(data && data.schedules) ? data.schedules : []))
      .catch((err) => setError({ detail: errDetail(err) }))
      .finally(() => setLoading(false));
  }
  useEffect(() => { reload(); }, []);

  async function exportToPDF() {
    if (!scheduleRef.current || schedules.length === 0) return;
    setExportError("");
    setExporting(true);
    try {
      await exportElementToPdf(scheduleRef.current, `schedule-${Date.now()}.pdf`);
    } catch (err) {
      setExportError(tr("خطا در ساخت فایل PDF"));
    } finally {
      setExporting(false);
    }
  }

  async function exportToExcel() {
    if (schedules.length === 0) return;
    setExportError("");
    setExporting(true);
    try {
      const { downloadXlsx } = await import("../../../utils/exportXlsx.js");
      const rows = schedules.map((s) => ({
        [tr("شناسه برنامه")]: s.id,
        [tr("بخش")]: dept(s.department) || "—",
        [tr("روزهای کاری")]: splitDays(s.dayOfWeek).map((d) => tr(d)).join(", ") || s.dayOfWeek,
        [tr("ساعت شروع")]: String(s.startTime).slice(0, 5),
        [tr("ساعت پایان")]: String(s.endTime).slice(0, 5),
        [tr("شیفت")]: s.shift ? tr(s.shift) : "—",
        [tr("وضعیت")]: tr(s.status || "فعال"),
      }));
      await downloadXlsx(`schedule-${Date.now()}.xlsx`, [{ name: tr("برنامه کاری"), rows }]);
    } catch (err) {
      setExportError(tr("خطا در ساخت فایل Excel"));
    } finally {
      setExporting(false);
    }
  }

  // ---- محاسبات فقط از داده‌ی واقعی ----
  const now = new Date();
  const todayName = JS_DAY_NAME[now.getDay()];
  const todayKey = normDay(todayName);
  const isTodayRow = (s) => splitDays(s.dayOfWeek).some((d) => normDay(d) === todayKey);

  const sorted = [...schedules].sort((a, b) => dayRank(a) - dayRank(b) || String(a.startTime).localeCompare(String(b.startTime)));
  const todays = schedules.filter(isTodayRow).sort((a, b) => String(a.startTime).localeCompare(String(b.startTime)));

  const dayKeys = new Set(schedules.flatMap((s) => splitDays(s.dayOfWeek).map(normDay)));
  const activeSchedules = schedules.filter((s) => (s.status || "فعال") === "فعال");
  const activeShifts = [...new Set(activeSchedules.map((s) => s.shift).filter(Boolean))];
  const totalMinutes = schedules.reduce((sum, s) => sum + (durationMinutes(s) || 0), 0);

  return (
    <div className="dash-card glass dw-scope">
      <header className="dw-header">
        <div className="dw-header-icon" aria-hidden="true"><CalendarRange size={24} /></div>
        <div className="dw-header-text">
          <h2>{tr("برنامه کاری من")}</h2>
          <p>{tr("برنامه‌ها و ساعات کاری ثبت‌شده برای شما")}</p>
        </div>
        <div className="dw-header-actions">
          <ExportMenu disabled={schedules.length === 0} exporting={exporting} onPdf={exportToPDF} onExcel={exportToExcel} />
        </div>
      </header>

      <div className="dw-note">
        <Lock size={15} aria-hidden="true" />
        <span>{tr("این برنامه کاری توسط بخش مدیریت (ادمین) برای شما تعریف می‌شود و صرفاً قابل‌مشاهده است.")}</span>
      </div>

      {exportError && (
        <div className="dw-notice dw-tone-danger" role="alert">
          <AlertTriangle size={18} aria-hidden="true" />
          <div className="dw-notice-text"><strong>{exportError}</strong></div>
          <button type="button" className="dw-notice-close" aria-label={tr("بستن")} onClick={() => setExportError("")}><X size={16} /></button>
        </div>
      )}

      {loading && (
        <div aria-busy="true" aria-label={tr("در حال بارگذاری برنامه کاری")} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <SkeletonKpis count={4} />
          <div className="dw-skel" style={{ height: 84, borderRadius: 14 }} />
          <SkeletonTable cols={6} rows={4} />
        </div>
      )}

      {!loading && error && (
        <div className="dw-state is-error" role="alert">
          <div className="dw-state-icon"><AlertTriangle size={28} aria-hidden="true" /></div>
          <h3>{tr("دریافت برنامه کاری با مشکل مواجه شد")}</h3>
          {error.detail && <small>{error.detail}</small>}
          <button type="button" className="btn btn-primary btn-sm" onClick={reload}>
            <RefreshCw size={14} aria-hidden="true" /> {tr("تلاش مجدد")}
          </button>
        </div>
      )}

      {!loading && !error && schedules.length === 0 && (
        <div className="dw-state">
          <div className="dw-state-icon"><CalendarOff size={28} aria-hidden="true" /></div>
          <h3>{tr("هنوز برنامه کاری برای شما تعریف نشده است")}</h3>
          <p>{tr("برنامه کاری شما توسط مدیریت شفاخانه (ادمین) تعریف می‌شود. پس از ثبت، روزها و ساعات کاری شما همین‌جا نمایش داده خواهد شد.")}</p>
        </div>
      )}

      {!loading && !error && schedules.length > 0 && (
        <>
          <div className="dw-kpis">
            <Kpi tone="accent" icon={<CalendarDays size={20} />} title={tr("تعداد برنامه‌ها")} value={toFa(schedules.length)} sub={tr("بازه‌های کاری ثبت‌شده")} />
            <Kpi tone="info" icon={<CalendarClock size={20} />} title={tr("روزهای کاری")} value={toFa(dayKeys.size)} sub={tr("روز متمایز در هفته")} />
            {activeShifts.length > 0 && (
              <Kpi tone="ok" icon={<Layers size={20} />} title={tr("شیفت‌های فعال")} value={toFa(activeShifts.length)} sub={activeShifts.map((x) => tr(x)).join(tr("، "))} />
            )}
            {totalMinutes > 0 && (
              <Kpi tone="warn" icon={<Hourglass size={20} />} title={tr("مجموع ساعات کاری")} value={formatDuration(totalMinutes)} sub={tr("جمع مدت بازه‌ها در هفته")} />
            )}
          </div>

          <section className={cx("dw-today", todays.length > 0 && "is-working")} aria-label={tr("برنامه امروز")}>
            <div className="dw-today-head">
              <div className="dw-kpi-icon dw-tone-ok" style={{ background: "rgba(var(--c), 0.14)", color: "rgb(var(--c))" }} aria-hidden="true">
                <CalendarClock size={20} />
              </div>
              <div>
                <h3 className="dw-today-title">{tr("برنامه امروز")}</h3>
                <p className="dw-today-date">{tr(todayName)}{tr("،")} {jdate(now)}</p>
              </div>
            </div>
            <div className="dw-today-body">
              {todays.length === 0 ? (
                <p className="dw-today-empty"><CalendarOff size={18} aria-hidden="true" /> {tr("امروز برنامه کاری ثبت نشده است")}</p>
              ) : (
                <>
                  <div className="dw-today-line"><span className="dw-chip dw-tone-ok"><span className="dw-dot" />{tr("امروز روز کاری است")}</span></div>
                  {todays.map((s) => (
                    <div key={s.id} className="dw-today-line">
                      <TimeRange s={s} />
                      {s.shift && <span className={`dw-chip dw-tone-${shiftTone(s.shift)}`}>{tr(s.shift)}</span>}
                      {durationMinutes(s) && <span className="dw-dur">{formatDuration(durationMinutes(s))}</span>}
                    </div>
                  ))}
                </>
              )}
            </div>
          </section>

          <div className="dw-table-wrap">
            <table className="dw-table" ref={scheduleRef} dir={curDir()} data-dw-export>
              <thead>
                <tr>
                  <th>{tr("شناسه برنامه")}</th>
                  <th>{tr("بخش")}</th>
                  <th>{tr("روزهای کاری")}</th>
                  <th>{tr("ساعت شروع ← پایان")}</th>
                  <th>{tr("شیفت")}</th>
                  <th>{tr("وضعیت")}</th>
                </tr>
              </thead>
              <tbody>
                {sorted.map((s) => {
                  const dur = durationMinutes(s);
                  const days = splitDays(s.dayOfWeek);
                  const status = s.status || "فعال";
                  const hasBreak = s.breakStart && s.breakEnd;
                  return (
                    <tr key={s.id} className={isTodayRow(s) ? "is-today" : undefined}>
                      <td className="dw-id">{toFa(s.id)}</td>
                      <td>{s.department ? <span className="dw-dept"><Building2 size={14} aria-hidden="true" />{dept(s.department)}</span> : "—"}</td>
                      <td>
                        <div className="dw-chips">
                          {(days.length ? days : [s.dayOfWeek || "—"]).map((d) => (
                            <span key={d} className={cx("dw-chip dw-tone-accent", normDay(d) === todayKey && "is-today")}>{tr(d)}</span>
                          ))}
                        </div>
                      </td>
                      <td>
                        <TimeRange s={s} />
                        {(dur || hasBreak) && (
                          <span className="dw-sub">
                            {dur ? tr("مدت: {0}", [formatDuration(dur)]) : ""}
                            {dur && hasBreak ? " — " : ""}
                            {hasBreak ? tr("استراحت: {0} تا {1}", [fmtTime(s.breakStart), fmtTime(s.breakEnd)]) : ""}
                          </span>
                        )}
                      </td>
                      <td>{s.shift ? <span className={`dw-chip dw-tone-${shiftTone(s.shift)}`}>{tr(s.shift)}</span> : "—"}</td>
                      <td><span className={`dw-chip dw-tone-${status === "فعال" ? "ok" : "neutral"}`}><span className="dw-dot" />{tr(status)}</span></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}

import { lazy, Suspense } from "react";
import DashboardShell from "../../../components/dashboard/DashboardShell.jsx";
import SectionErrorBoundary from "../../../components/SectionErrorBoundary.jsx";
import useTabState from "../../../hooks/useTabState.js";
import { useLanguage } from "../../../context/LanguageContext.jsx";
import { tr, trc } from "../../../i18n/tr.js";

// هر تب در فایل جداگانه است و با lazy() بارگذاری می‌شود؛ فقط کد تبِ باز دانلود می‌شود.
const DoctorSchedulePanel = lazy(() => import("./DoctorSchedulePanel.jsx"));
const DoctorAppointmentsPanel = lazy(() => import("./DoctorAppointmentsPanel.jsx"));
const DoctorPatientsPanel = lazy(() => import("./DoctorPatientsPanel.jsx"));
const MedicalSection = lazy(() => import("../../../components/dashboard/MedicalSection.jsx"));
const DoctorTransferPanel = lazy(() => import("./DoctorTransferPanel.jsx"));
const DoctorBillingPanel = lazy(() => import("./DoctorBillingPanel.jsx"));
const ChatWithPatients = lazy(() => import("../../../components/dashboard/ChatWithPatients.jsx"));

// ترتیب تب‌ها بر اساس اهمیت/کاربرد: برنامه و نوبت‌ها ← بیماران و نسخه ← پیام‌ها ← انتقال معلومات ← مالی
const TABS = trc([
  { key: "schedule", label: "برنامه کاری من", icon: "🗓️" },
  { key: "appointments", label: "نوبت‌های من", icon: "📋" },
  { key: "patients", label: "بیماران من", icon: "🧑‍🤝‍🧑" },
  { key: "prescriptions", label: "نسخه و سوابق طبی", icon: "💊" },
  { key: "chat", label: "پیام‌های بیماران", icon: "💬" },
  { key: "transfer", label: "انتقال معلومات بیمار", icon: "📤" },
  { key: "billing", label: "صورت‌حساب و فاکتورها", icon: "🧾" },
]);

export default function DoctorDashboard() {
  const [activeTab, setActiveTab] = useTabState("schedule");
  const { lang } = useLanguage();

  return (
    <DashboardShell key={lang} title={tr("داشبورد داکتر")} tabs={TABS} activeTab={activeTab} onTabChange={setActiveTab}>
      <SectionErrorBoundary key={activeTab} label={activeTab}>
        <Suspense fallback={<div className="pm-state" role="status">{tr("در حال بارگذاری...")}</div>}>
          {activeTab === "schedule" && <DoctorSchedulePanel />}
          {activeTab === "appointments" && <DoctorAppointmentsPanel />}
          {activeTab === "patients" && <DoctorPatientsPanel />}
          {activeTab === "prescriptions" && <MedicalSection role="doctor" />}
          {activeTab === "transfer" && <DoctorTransferPanel />}
          {activeTab === "billing" && <DoctorBillingPanel />}
          {activeTab === "chat" && <ChatWithPatients />}
        </Suspense>
      </SectionErrorBoundary>
    </DashboardShell>
  );
}

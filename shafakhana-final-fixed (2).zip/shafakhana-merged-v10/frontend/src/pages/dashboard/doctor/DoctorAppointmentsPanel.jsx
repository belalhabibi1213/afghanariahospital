import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import {
  AlertTriangle, Building2, CalendarCheck, CalendarDays, CalendarX, CheckCircle2, ClipboardList, Clock, FilterX,
  Hash, Hourglass, Info, Loader2, Phone, RefreshCw, Search, StickyNote, UserRound, X, XCircle, Eye, Stethoscope,
} from "lucide-react";
import { apiRequest } from "../../../utils/api.js";
import useHighlightParam from "../../../hooks/useHighlightParam.js";
import { ExportMenu, SkeletonTable, cx, errDetail, exportElementToPdf, fmtTime, toFa, dept, docName } from "./doctorWorkspaceUi.jsx";
import {
  DateRangeFilter, DetailDrawer, DrawerRow, DrawerSkeleton, InlineError, ListPager, StatCard,
  buildQuery, fmtNum, rangeParams, useFetchList, useFetchOne, useListQuery,
} from "./doctorListUi.jsx";
import { tr, trc, curDir, jdate } from "../../../i18n/tr.js";

// ---------- نوبت‌های من ----------
// داکتر فقط فهرست نوبت‌های بیماران خودش را می‌بیند. تایید / رد / تکمیل (پذیرش) نوبت فقط توسط ادمین و
// از پنل «مدیریت نوبت‌ها» انجام می‌شود؛ پس عملیات ردیف فقط «مشاهده» است (بدون هیچ عملیات تازه).
//
// داده‌ها از این API‌های واقعی (فقط خودِ داکتر واردشده) می‌آیند و هیچ داده‌ای در فرانت ساخته نمی‌شود:
//   GET /doctors/me/appointments/stats   کارت‌های آماری + فهرست بخش‌ها
//   GET /doctors/me/appointments/list    فهرست سروری: جستجو/فیلتر/مرتب‌سازی/صفحه‌بندی (فقط یک صفحه)
//   GET /doctors/me/appointments/:id     جزئیات برای Drawer (هنگام باز شدن)

const STATUS_META = trc({
  pending: { name: "در انتظار تایید", tone: "warn" },
  confirmed: { name: "تایید شده", tone: "ok" },
  completed: { name: "انجام‌شده", tone: "info" },
  cancelled: { name: "لغوشده", tone: "danger" },
});
const JS_DAY_NAME = ["یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه"];
const EXPORT_CAP = 5000; // سقف ردیف‌های «خروجی Excel کل نتایج» (صفحه‌به‌صفحه و ۱۰۰تایی گرفته می‌شود)

const DEFAULT_QUERY = { q: "", status: "", department: "", range: "", from: "", to: "", sort: "newest", page: 1, limit: 20 };

function weekdayOf(isoDate) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(isoDate);
  return m ? tr(JS_DAY_NAME[new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])).getDay()]) : "";
}
function initials(name) {
  const words = String(name || "").trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return tr("؟");
  const first = Array.from(words[0])[0];
  const last = words.length > 1 ? Array.from(words[words.length - 1])[0] : "";
  return `${first}${last ? `‌${last}` : ""}`;
}

function StatusChip({ status }) {
  const meta = STATUS_META[status];
  return (
    <span className={`dw-chip dw-tone-${meta ? meta.tone : "neutral"}`}>
      <span className="dw-dot" />{meta ? meta.name : status}
    </span>
  );
}

function listParams(query, extra = {}) {
  return {
    q: query.q, status: query.status, department: query.department,
    ...rangeParams(query), sort: query.sort, page: query.page, limit: query.limit, ...extra,
  };
}

export default function DoctorAppointmentsPanel() {
  const { highlightId, highlightRowProps } = useHighlightParam();
  const [, setSearchParams] = useSearchParams();
  const { raw, query, typing, set, setPage, reset } = useListQuery(DEFAULT_QUERY);
  const list = useFetchList("/doctors/me/appointments/list", listParams(query));
  const statsReq = useFetchOne("/doctors/me/appointments/stats", "stats");
  const [openId, setOpenId] = useState(() => (highlightId && /^\d+$/.test(highlightId) ? Number(highlightId) : null));
  const detail = useFetchOne(openId ? `/doctors/me/appointments/${openId}` : "", openId);
  const [selected, setSelected] = useState(() => new Set());
  const [notice, setNotice] = useState(null); // { type: "success" | "error", text }
  const [exporting, setExporting] = useState(false);
  const tableRef = useRef(null);

  const appointments = useMemo(() => (list.data && Array.isArray(list.data.appointments) ? list.data.appointments : []), [list.data]);
  const pagination = list.data ? list.data.pagination : null;
  const stats = statsReq.data ? statsReq.data.stats : null;
  const departments = stats ? stats.departments : [];

  // با تغییر صفحه/فیلتر، انتخاب‌ها پاک می‌شوند (انتخاب فقط برای همان صفحه معنا دارد)
  useEffect(() => { setSelected(new Set()); }, [appointments]);

  useEffect(() => {
    if (!notice || notice.type !== "success") return undefined;
    const t = setTimeout(() => setNotice(null), 5000);
    return () => clearTimeout(t);
  }, [notice]);

  const hasFilters = Boolean(raw.q.trim() || raw.status || raw.department || raw.range || raw.sort !== "newest");
  const hasData = list.data !== null;
  const firstLoad = list.loading && !hasData;
  const fatal = Boolean(list.error) && !hasData;
  const noAppointmentsAtAll = !list.loading && !list.error && pagination && pagination.total === 0 && !hasFilters && !typing;

  function refreshAll() {
    list.reload();
    statsReq.reload();
  }

  const allOnPageSelected = appointments.length > 0 && appointments.every((a) => selected.has(a.id));
  function toggleAll() {
    setSelected(allOnPageSelected ? new Set() : new Set(appointments.map((a) => a.id)));
  }
  function toggleOne(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  const exportRows = (rows) => rows.map((a) => ({
    [tr("شماره نوبت")]: a.id,
    [tr("بیمار")]: a.patientName,
    [tr("شماره پرونده")]: a.patientCode,
    [tr("شماره تماس")]: a.patientPhone,
    [tr("بخش")]: dept(a.department),
    [tr("تاریخ")]: jdate(a.appointmentDate, { latin: true }),
    [tr("ساعت")]: a.appointmentTime,
    [tr("وضعیت")]: (STATUS_META[a.status] && STATUS_META[a.status].name) || a.status,
  }));

  // PDF: همان جدولِ صفحه‌ی جاری (یا فقط ردیف‌های انتخاب‌شده)
  async function exportToPDF() {
    if (!tableRef.current || appointments.length === 0) return;
    setNotice(null);
    setExporting(true);
    try {
      await exportElementToPdf(tableRef.current, `appointments-${Date.now()}.pdf`);
    } catch {
      setNotice({ type: "error", text: tr("خطا در ساخت فایل PDF") });
    } finally {
      setExporting(false);
    }
  }

  // Excel: ردیف‌های انتخاب‌شده، وگرنه «همه‌ی نتایج مطابق فیلتر فعلی» (صفحه‌به‌صفحه از سرور، تا سقف EXPORT_CAP)
  async function exportToExcel() {
    if (appointments.length === 0) return;
    setNotice(null);
    setExporting(true);
    try {
      let rows;
      let truncated = false;
      if (selected.size > 0) {
        rows = appointments.filter((a) => selected.has(a.id));
      } else {
        rows = [];
        let page = 1;
        let totalPages = 1;
        do {
          // eslint-disable-next-line no-await-in-loop
          const data = await apiRequest(`/doctors/me/appointments/list?${buildQuery(listParams(query, { page, limit: 100 }))}`);
          rows.push(...(data.appointments || []));
          totalPages = data.pagination ? data.pagination.totalPages : 1;
          page += 1;
        } while (page <= totalPages && rows.length < EXPORT_CAP);
        if (rows.length >= EXPORT_CAP && page <= totalPages) { rows = rows.slice(0, EXPORT_CAP); truncated = true; }
      }
      const { downloadXlsx } = await import("../../../utils/exportXlsx.js");
      await downloadXlsx(`appointments-${Date.now()}.xlsx`, [{ name: tr("نوبت‌های من"), rows: exportRows(rows) }]);
      if (truncated) setNotice({ type: "success", text: tr("فایل Excel با {0} ردیف اول ساخته شد؛ برای کاهش تعداد، فیلتر را محدودتر کنید.", [fmtNum(EXPORT_CAP)]) });
    } catch {
      setNotice({ type: "error", text: tr("خطا در ساخت فایل Excel") });
    } finally {
      setExporting(false);
    }
  }

  function openPatient(patientId) {
    setOpenId(null);
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.set("tab", "patients");
      next.set("patient", String(patientId));
      next.delete("highlight");
      return next;
    });
  }

  const d = detail.data ? detail.data.appointment : null;
  const rowOffset = pagination ? (pagination.page - 1) * query.limit : 0;

  return (
    <div className="dash-card glass dw-scope">
      <header className="dw-header">
        <div className="dw-header-icon" aria-hidden="true"><CalendarCheck size={24} /></div>
        <div className="dw-header-text">
          <h2>{tr("نوبت‌های من")}</h2>
          <p>{tr("مدیریت و مشاهده تمام نوبت‌های دریافتی و پیگیری وضعیت آن‌ها")}</p>
        </div>
        <div className="dw-header-actions">
          <button type="button" className="btn btn-ghost btn-sm" onClick={refreshAll} disabled={list.loading} aria-label={tr("بروزرسانی فهرست نوبت‌ها")}>
            <RefreshCw size={15} className={list.loading ? "dw-spin" : undefined} aria-hidden="true" /> {tr("بروزرسانی")}
          </button>
          <ExportMenu disabled={appointments.length === 0} exporting={exporting} onPdf={exportToPDF} onExcel={exportToExcel} />
        </div>
      </header>

      {notice && (
        <div className={`dw-notice dw-tone-${notice.type === "success" ? "ok" : "danger"}`} role={notice.type === "success" ? "status" : "alert"} aria-live="polite">
          {notice.type === "success" ? <CheckCircle2 size={18} aria-hidden="true" /> : <AlertTriangle size={18} aria-hidden="true" />}
          <div className="dw-notice-text"><strong>{notice.text}</strong></div>
          <button type="button" className="dw-notice-close" aria-label={tr("بستن")} onClick={() => setNotice(null)}><X size={16} /></button>
        </div>
      )}

      <div className="dw-notice dw-tone-info" role="note">
        <Info size={18} aria-hidden="true" />
        <div className="dw-notice-text">
          <strong>{tr("تایید و پذیرش نوبت‌ها توسط ادمین انجام می‌شود.")}</strong>
          {tr("این بخش فقط برای مشاهده‌ی فهرست نوبت‌های شماست.")}
        </div>
      </div>

      <div className="dl-stats" aria-label={tr("آمار نوبت‌ها")}>
        <StatCard tone="info" icon={<ClipboardList size={22} />} title={tr("کل نوبت‌ها")} value={stats ? stats.total : null} loading={statsReq.loading} />
        <StatCard tone="ok" icon={<CheckCircle2 size={22} />} title={tr("تایید شده")} value={stats ? stats.confirmed : null} loading={statsReq.loading} />
        <StatCard tone="warn" icon={<Hourglass size={22} />} title={tr("در انتظار تایید")} value={stats ? stats.pending : null} loading={statsReq.loading} />
        <StatCard tone="danger" icon={<XCircle size={22} />} title={tr("لغو شده")} value={stats ? stats.cancelled : null} loading={statsReq.loading} />
      </div>
      {statsReq.error && (
        <InlineError message={tr("دریافت آمار ناموفق بود. {0}", [errDetail(statsReq.error)])} onRetry={statsReq.reload} />
      )}

      <div className="dl-filters" role="search">
        <div className="dw-field dl-search">
          <label htmlFor="dl-appt-search">{tr("جستجو")}</label>
          <div className="dw-input-icon">
            <Search size={16} aria-hidden="true" />
            <input
              id="dl-appt-search" className="dw-input" type="search" autoComplete="off" value={raw.q} maxLength={100}
              onChange={(e) => set({ q: e.target.value })} placeholder={tr("نام مریض، شماره پرونده، شماره تماس یا شماره نوبت...")}
            />
          </div>
        </div>
        <div className="dw-field">
          <label htmlFor="dl-appt-status">{tr("وضعیت")}</label>
          <select id="dl-appt-status" className="dw-select" value={raw.status} onChange={(e) => set({ status: e.target.value })}>
            <option value="">{tr("همه")}</option>
            {Object.entries(STATUS_META).map(([k, v]) => <option key={k} value={k}>{v.name}</option>)}
          </select>
        </div>
        <div className="dw-field">
          <label htmlFor="dl-appt-dept">{tr("بخش / تخصص")}</label>
          <select id="dl-appt-dept" className="dw-select" value={raw.department} onChange={(e) => set({ department: e.target.value })}>
            <option value="">{tr("همه")}</option>
            {departments.map((dep) => <option key={dep} value={dep}>{dept(dep)}</option>)}
          </select>
        </div>
        <DateRangeFilter id="dl-appt-range" label={tr("تاریخ")} range={raw.range} from={raw.from} to={raw.to} onChange={set} />
        <div className="dw-field">
          <label htmlFor="dl-appt-sort">{tr("مرتب‌سازی")}</label>
          <select id="dl-appt-sort" className="dw-select" value={raw.sort} onChange={(e) => set({ sort: e.target.value })}>
            <option value="newest">{tr("جدیدترین")}</option>
            <option value="oldest">{tr("قدیمی‌ترین")}</option>
          </select>
        </div>
        {hasFilters && (
          <div className="dl-filters-actions">
            <button type="button" className="btn btn-ghost btn-sm" onClick={reset}><FilterX size={15} aria-hidden="true" /> {tr("پاک کردن فیلترها")}</button>
          </div>
        )}
        {(typing || (raw.q.trim() && pagination)) && (
          <div className="dl-search-meta" aria-live="polite">
            {typing || list.loading
              ? <span className="dw-chip dw-tone-neutral"><Loader2 size={13} className="dw-spin" aria-hidden="true" />{tr("در حال جستجو...")}</span>
              : <span className="dw-chip dw-tone-accent"><Search size={13} aria-hidden="true" />{tr("جستجو برای «{0}» — {1} نتیجه", [query.q, fmtNum(pagination.total)])}</span>}
          </div>
        )}
      </div>

      {firstLoad && (
        <div aria-busy="true" aria-label={tr("در حال بارگذاری نوبت‌ها")}><SkeletonTable cols={6} rows={6} /></div>
      )}

      {fatal && (
        <div className="dw-state is-error" role="alert">
          <div className="dw-state-icon"><AlertTriangle size={28} aria-hidden="true" /></div>
          <h3>{tr("دریافت نوبت‌ها با مشکل مواجه شد")}</h3>
          {errDetail(list.error) && <small>{errDetail(list.error)}</small>}
          <button type="button" className="btn btn-primary btn-sm" onClick={refreshAll}><RefreshCw size={14} aria-hidden="true" /> {tr("تلاش مجدد")}</button>
        </div>
      )}

      {hasData && list.error && (
        <InlineError message={tr("بروزرسانی نوبت‌ها با مشکل مواجه شد؛ اطلاعات زیر ممکن است قدیمی باشد. {0}", [errDetail(list.error)])} onRetry={list.reload} />
      )}

      {noAppointmentsAtAll && (
        <div className="dw-state">
          <div className="dw-state-icon"><CalendarX size={28} aria-hidden="true" /></div>
          <h3>{tr("هیچ نوبتی پیدا نشد.")}</h3>
          <p>{tr("وقتی بیماران از طریق سیستم برای شما نوبت بگیرند، نوبت‌ها همین‌جا نمایش داده می‌شوند. تایید و پذیرش نوبت‌ها با ادمین است.")}</p>
        </div>
      )}

      {hasData && pagination && pagination.total === 0 && !noAppointmentsAtAll && !typing && (
        <div className="dw-state">
          <div className="dw-state-icon"><Search size={28} aria-hidden="true" /></div>
          <h3>{tr("هیچ نوبتی پیدا نشد.")}</h3>
          <p>{tr("با فیلترها و جستجوی فعلی نوبتی وجود ندارد.")}</p>
          <button type="button" className="btn btn-ghost btn-sm" onClick={reset}><FilterX size={15} aria-hidden="true" /> {tr("پاک کردن فیلترها")}</button>
        </div>
      )}

      {hasData && appointments.length > 0 && (
        <div className="dl-table-card">
          {selected.size > 0 && (
            <div className="dl-selection-bar" role="status">
              <span>{fmtNum(selected.size)} {tr("نوبت انتخاب شده (خروجی Excel فقط همین‌ها را شامل می‌شود)")}</span>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setSelected(new Set())}>{tr("لغو انتخاب")}</button>
            </div>
          )}
          {list.loading && <div className="dl-refreshing" aria-hidden="true"><span className="dw-chip dw-tone-neutral"><Loader2 size={13} className="dw-spin" />{tr("در حال بروزرسانی...")}</span></div>}
          <div className="dw-table-wrap">
            <table className="dw-table dl-table" ref={tableRef} dir={curDir()} data-dw-export>
              <caption className="sr-only" style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clip: "rect(0 0 0 0)" }}>{tr("فهرست نوبت‌ها")}</caption>
              <thead>
                <tr>
                  <th className="dl-col-check"><input type="checkbox" checked={allOnPageSelected} onChange={toggleAll} aria-label={tr("انتخاب همه‌ی نوبت‌های این صفحه")} /></th>
                  <th className="dl-col-num dl-hide-md">#</th>
                  <th>{tr("نام مریض")}</th>
                  <th>{tr("شماره پرونده")}</th>
                  <th className="dl-hide-md">{tr("بخش / تخصص")}</th>
                  <th>{tr("تاریخ و زمان نوبت")}</th>
                  <th>{tr("وضعیت")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((a, i) => {
                  const weekday = weekdayOf(a.appointmentDate);
                  const hp = highlightRowProps(a.id);
                  return (
                    <tr
                      key={a.id}
                      {...hp}
                      className={cx(hp.className, selected.has(a.id) && "is-selected", openId === a.id && "is-viewing")}
                      tabIndex={0}
                      onClick={() => setOpenId(a.id)}
                      onKeyDown={(e) => { if (e.key === "Enter" && e.target === e.currentTarget) setOpenId(a.id); }}
                    >
                      <td className="dl-col-check" onClick={(e) => e.stopPropagation()}>
                        <input type="checkbox" checked={selected.has(a.id)} onChange={() => toggleOne(a.id)} aria-label={tr("انتخاب نوبت {0}", [a.patientName || a.id])} />
                      </td>
                      <td className="dl-col-num dl-hide-md">{toFa(rowOffset + i + 1)}</td>
                      <td className="dl-col-main">
                        <div className="dw-person">
                          <span className="dw-avatar" aria-hidden="true">{initials(a.patientName)}</span>
                          <span className="dw-person-name">{a.patientName || "—"}</span>
                        </div>
                      </td>
                      <td data-label={tr("شماره پرونده")}>{a.patientCode ? <span className="dl-code">{a.patientCode}</span> : "—"}</td>
                      <td data-label={tr("بخش / تخصص")} className="dl-hide-md">{a.department ? <span className="dw-dept"><Building2 size={14} aria-hidden="true" /><span className="dl-ellipsis" title={dept(a.department)}>{dept(a.department)}</span></span> : "—"}</td>
                      <td data-label={tr("تاریخ و زمان نوبت")}>
                        <div className="dl-datetime">
                          <span><span className="dw-date">{jdate(a.appointmentDate)}</span> <span className="dw-time"><Clock size={13} aria-hidden="true" /><bdi dir="ltr">{fmtTime(a.appointmentTime)}</bdi></span></span>
                          {weekday && <span className="dw-sub">{weekday}</span>}
                        </div>
                      </td>
                      <td data-label={tr("وضعیت")}><StatusChip status={a.status} /></td>
                      <td className="dl-col-actions" onClick={(e) => e.stopPropagation()}>
                        <div className="dl-actions">
                          <button type="button" className="dl-icon-btn is-info dp-tip" data-tip={tr("مشاهده جزئیات")} aria-label={tr("مشاهده جزئیات نوبت {0}", [a.patientName || a.id])} onClick={() => setOpenId(a.id)}>
                            <Eye size={16} aria-hidden="true" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <ListPager pagination={pagination} limit={query.limit} loading={list.loading} noun={tr("نوبت")} onPage={setPage} onLimit={(limit) => set({ limit })} />
        </div>
      )}

      <DetailDrawer
        open={openId !== null}
        title={tr("جزئیات نوبت")}
        icon={<CalendarDays size={18} />}
        onClose={() => setOpenId(null)}
        footer={d && (
          <>
            <button type="button" className="btn btn-primary btn-sm" onClick={() => openPatient(d.patientId)}><UserRound size={15} aria-hidden="true" /> {tr("مشاهده بیمار")}</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => setOpenId(null)}>{tr("بستن")}</button>
          </>
        )}
      >
        {detail.loading && <DrawerSkeleton />}
        {detail.error && (
          <InlineError
            message={detail.error.status === 404 ? tr("این نوبت پیدا نشد یا متعلق به شما نیست.") : tr("دریافت جزئیات نوبت ناموفق بود. {0}", [errDetail(detail.error)])}
            onRetry={detail.error.status === 404 ? undefined : detail.reload}
          />
        )}
        {d && (
          <>
            <div className="dl-who">
              <span className="dw-avatar" aria-hidden="true">{initials(d.patientName)}</span>
              <div className="dl-who-text">
                <strong>{d.patientName}</strong>
                <span>{tr("شماره پرونده:")} <bdi className="dl-code">{d.patientCode || "—"}</bdi></span>
              </div>
            </div>
            <div className="dl-rows">
              <DrawerRow icon={<Phone size={14} />} label={tr("شماره تماس")}>{d.patientPhone ? <bdi>{toFa(d.patientPhone)}</bdi> : null}</DrawerRow>
              <DrawerRow icon={<Stethoscope size={14} />} label={tr("داکتر")}>{docName(d.doctorName)}</DrawerRow>
              <DrawerRow icon={<Building2 size={14} />} label={tr("بخش / تخصص")}>{dept(d.department)}</DrawerRow>
              <DrawerRow icon={<CalendarDays size={14} />} label={tr("تاریخ")}>{jdate(d.appointmentDate)}{weekdayOf(d.appointmentDate) ? ` (${weekdayOf(d.appointmentDate)})` : ""}</DrawerRow>
              <DrawerRow icon={<Clock size={14} />} label={tr("ساعت")}><bdi>{fmtTime(d.appointmentTime)}</bdi></DrawerRow>
              <DrawerRow icon={<Hash size={14} />} label={tr("شماره نوبت")}>{toFa(d.id)}</DrawerRow>
              <DrawerRow icon={<ClipboardList size={14} />} label={tr("وضعیت")}><StatusChip status={d.status} /></DrawerRow>
            </div>
            <h4 className="dl-section-title"><StickyNote size={14} aria-hidden="true" style={{ verticalAlign: "-2px" }} /> {tr("یادداشت‌های مرتبط")}</h4>
            <p className="dl-note">{d.notes && String(d.notes).trim() ? d.notes : tr("یادداشتی ثبت نشده است.")}</p>
            {d.status === "pending" && (
              <div className="dw-notice dw-tone-info" role="note">
                <Info size={18} aria-hidden="true" />
                <div className="dw-notice-text">{tr("تایید یا رد این نوبت توسط ادمین انجام می‌شود.")}</div>
              </div>
            )}
          </>
        )}
      </DetailDrawer>
    </div>
  );
}

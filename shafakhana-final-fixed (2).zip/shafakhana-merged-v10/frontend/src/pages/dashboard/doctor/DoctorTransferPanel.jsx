import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle, CheckCircle2, Download, FileImage, FileSpreadsheet, FileText, FolderOpen, Loader2, Lock, RefreshCw, Send, ShieldCheck, Trash2, UploadCloud, X,
} from "lucide-react";
import GlobalModal from "../../../components/GlobalModal.jsx";
import { apiRequest, apiUpload, apiDownload } from "../../../utils/api.js";
import { SkeletonTable, cx, errDetail, toFa, dpDate, dpInitials } from "./doctorWorkspaceUi.jsx";
import { tr, curDir } from "../../../i18n/tr.js";
// تب «انتقال معلومات بیمار» در داشبورد داکتر — از DoctorDashboard جدا شده تا lazy-load شود.
import "./DoctorPatientsPanel.css";

const ALLOWED_TRANSFER_TYPES = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // xlsx
  "application/vnd.ms-excel", // xls
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // docx
  "image/jpeg",
  "image/png",
];
const MAX_TRANSFER_FILE_SIZE = 15 * 1024 * 1024; // ۱۵ مگابایت برای هر فایل
const MAX_TRANSFER_FILES = 5;

const TRANSFER_TYPE_LABEL = {
  "application/pdf": "PDF",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "Excel",
  "application/vnd.ms-excel": "Excel",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "Word",
  "image/jpeg": "JPG",
  "image/png": "PNG",
};

function formatFileSize(bytes) {
  if (!bytes && bytes !== 0) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// نوع فایل → برچسب (از TRANSFER_TYPE_LABEL فعلی)، رنگ و آیکون. فقط برای نمایش است؛ مقدار fileType سرور دست‌نخورده می‌ماند.
function transferKind(mime) {
  const label = TRANSFER_TYPE_LABEL[mime] || mime || "—";
  const tone = { PDF: "danger", Excel: "ok", Word: "info", JPG: "warn", PNG: "accent" }[label] || "neutral";
  const Icon = { PDF: FileText, Excel: FileSpreadsheet, Word: FileText, JPG: FileImage, PNG: FileImage }[label] || File;
  return { label, tone, Icon };
}

export default function PatientFileTransferPanel() {
  const [patients, setPatients] = useState([]);
  const [loadingPatients, setLoadingPatients] = useState(true);
  const [patientsError, setPatientsError] = useState("");
  const [selectedPatientId, setSelectedPatientId] = useState("");
  const [files, setFiles] = useState([]);
  const [note, setNote] = useState("");
  const [sending, setSending] = useState(false);
  const sendingRef = useRef(false); // جلوگیری قطعی از ارسال دوباره (قبل از اعمال state)
  const [dragOver, setDragOver] = useState(false);
  const [status, setStatus] = useState({ type: "", text: "" });

  const [transfers, setTransfers] = useState([]);
  const [loadingTransfers, setLoadingTransfers] = useState(true);
  const [transfersError, setTransfersError] = useState("");
  const [downloadingId, setDownloadingId] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null); // رکورد در انتظار تایید حذف
  const [deletingId, setDeletingId] = useState(null);

  // فهرست بیمارانِ خودِ داکتر (فقط کسانی که با او نوبت گرفته‌اند) — برای فیلد انتخاب بیمار
  function loadPatients() {
    setLoadingPatients(true);
    setPatientsError("");
    apiRequest("/doctors/me/patients?limit=100")
      .then((data) => setPatients(data.patients || []))
      .catch((err) => setPatientsError(err.message))
      .finally(() => setLoadingPatients(false));
  }

  useEffect(loadPatients, []);

  function reloadTransfers() {
    setLoadingTransfers(true);
    setTransfersError("");
    apiRequest("/doctors/me/file-transfers")
      .then((data) => setTransfers(data.transfers || []))
      .catch((err) => setTransfersError(err.message))
      .finally(() => setLoadingTransfers(false));
  }

  useEffect(reloadTransfers, []);

  // پیام موفقیت پس از چند ثانیه خودکار بسته می‌شود؛ پیام خطا تا بستن دستی می‌ماند
  useEffect(() => {
    if (status.type !== "success") return undefined;
    const timer = setTimeout(() => setStatus({ type: "", text: "" }), 6000);
    return () => clearTimeout(timer);
  }, [status]);

  // اعتبارسنجی فایل‌ها (فرمت/تعداد/حجم) — دقیقاً همان قوانین قبلی؛ هم برای انتخاب فایل و هم برای Drag & Drop
  function acceptFiles(selected) {
    if (selected.length === 0) return;

    if (selected.length > MAX_TRANSFER_FILES) {
      setStatus({ type: "error", text: tr("حداکثر {0} فایل را می‌توانید هم‌زمان انتخاب کنید.", [MAX_TRANSFER_FILES]) });
      return;
    }

    for (const file of selected) {
      if (!ALLOWED_TRANSFER_TYPES.includes(file.type)) {
        setStatus({ type: "error", text: tr("فرمت فایل «{0}» مجاز نیست. فقط PDF، Excel، Word، JPG یا PNG مجاز است.", [file.name]) });
        return;
      }
      if (file.size > MAX_TRANSFER_FILE_SIZE) {
        setStatus({ type: "error", text: tr("حجم فایل «{0}» نباید بیشتر از ۱۵ مگابایت باشد.", [file.name]) });
        return;
      }
    }

    setStatus({ type: "", text: "" });
    setFiles(selected);
  }

  function handleFilesChange(e) {
    const selected = Array.from(e.target.files || []);
    e.target.value = ""; // امکان انتخاب دوباره همان فایل‌ها را فراهم می‌کند
    acceptFiles(selected);
  }

  function handleDrop(e) {
    e.preventDefault();
    setDragOver(false);
    if (sending) return;
    acceptFiles(Array.from(e.dataTransfer?.files || []));
  }

  function removeSelectedFile(index) {
    setFiles((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleSend(e) {
    e.preventDefault();
    if (sendingRef.current) return;
    setStatus({ type: "", text: "" });

    if (!selectedPatientId) {
      setStatus({ type: "error", text: tr("انتخاب بیمار الزامی است.") });
      return;
    }
    if (files.length === 0) {
      setStatus({ type: "error", text: tr("حداقل یک فایل را انتخاب کنید.") });
      return;
    }

    sendingRef.current = true;
    setSending(true);
    try {
      const formData = new FormData();
      formData.append("patientId", selectedPatientId);
      if (note.trim()) formData.append("note", note.trim());
      files.forEach((file) => formData.append("files", file));

      const data = await apiUpload("/doctors/me/file-transfers", formData);
      setStatus({ type: "success", text: data.message });
      setFiles([]);
      setNote("");
      reloadTransfers();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      sendingRef.current = false;
      setSending(false);
    }
  }

  async function handleDownload(id, originalName) {
    setDownloadingId(id);
    try {
      await apiDownload(`/doctors/me/file-transfers/${id}/download`, originalName || `file-${id}`);
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setDownloadingId(null);
    }
  }

  // حذف یک فایل ارسالی — پیش از حذف واقعی، دیالوگ تایید (deleteTarget) نمایش داده می‌شود.
  // با تایید کاربر، رکورد از سرور حذف می‌شود و بلافاصله (بدون رفرش صفحه) از لیست محلی
  // هم حذف می‌گردد. RBAC مالکیت (فقط فایل‌های ارسالی خودِ داکتر) سمت سرور بررسی می‌شود.
  async function confirmDeleteTransfer() {
    if (!deleteTarget) return;
    setDeletingId(deleteTarget.id);
    try {
      await apiRequest(`/doctors/me/file-transfers/${deleteTarget.id}`, { method: "DELETE" });
      setTransfers((prev) => prev.filter((t) => t.id !== deleteTarget.id));
      setStatus({ type: "success", text: tr("فایل ارسالی با موفقیت حذف شد.") });
      setDeleteTarget(null);
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setDeletingId(null);
    }
  }

  // بیمار انتخاب‌شده فعلی، فقط برای نمایش نام او در فورمه (لیست کشویی از قبل patientId/patientName دارد)
  const uniquePatients = [];
  const seenPatientIds = new Set();
  for (const p of patients) {
    if (!seenPatientIds.has(p.patientId)) {
      seenPatientIds.add(p.patientId);
      uniquePatients.push(p);
    }
  }
  const pickedPatient = uniquePatients.find((p) => String(p.patientId) === String(selectedPatientId)) || null;
  const deleteKind = deleteTarget ? transferKind(deleteTarget.fileType) : null;

  return (
    <div className="dash-card glass dw-scope">
      <header className="dw-header">
        <div className="dw-header-icon" aria-hidden="true"><Send size={24} /></div>
        <div className="dw-header-text">
          <h2>{tr("انتقال معلومات بیمار")}</h2>
          <p>{tr("ارسال امن اسناد و فایل‌های صحی برای بیماران خود")}</p>
        </div>
      </header>

      {status.text && (
        <div className={`dw-notice dw-tone-${status.type === "success" ? "ok" : "danger"}`} role={status.type === "success" ? "status" : "alert"} aria-live="polite">
          {status.type === "success" ? <CheckCircle2 size={20} aria-hidden="true" /> : <AlertTriangle size={20} aria-hidden="true" />}
          <div className="dw-notice-text"><strong>{status.text}</strong></div>
          <button type="button" className="dw-notice-close" aria-label={tr("بستن پیام")} onClick={() => setStatus({ type: "", text: "" })}><X size={16} /></button>
        </div>
      )}

      <div className="dw-note">
        <ShieldCheck size={16} aria-hidden="true" />
        <span>{tr("فایل‌ها فقط برای همان بیمار قابل‌مشاهده خواهند بود و تنها بیماران خودتان قابل انتخاب‌اند.")}</span>
      </div>

      <form onSubmit={handleSend} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        <div className="dp-form-grid">
          <div className="dp-col">
            <section className="dp-card">
              <div className="dp-card-head">
                <span className="dp-step" aria-hidden="true">{tr("۱")}</span>
                <h3><label htmlFor="dp-transfer-patient">{tr("انتخاب بیمار")}</label></h3>
              </div>
              <select
                id="dp-transfer-patient"
                className="dw-select"
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                disabled={loadingPatients || sending}
              >
                <option value="">{loadingPatients ? tr("در حال دریافت بیماران...") : tr("— انتخاب کنید —")}</option>
                {uniquePatients.map((p) => (
                  <option key={p.patientId} value={p.patientId}>
                    {tr("{0} (شناسه: {1})", [p.patientName, p.patientId])}
                  </option>
                ))}
              </select>
              {patientsError && (
                <div className="dp-inline-error" role="alert">
                  <AlertTriangle size={14} aria-hidden="true" />
                  <span>{errDetail({ message: patientsError }) || tr("دریافت فهرست بیماران ناموفق بود.")}</span>
                  <button type="button" onClick={loadPatients}>{tr("تلاش مجدد")}</button>
                </div>
              )}
              {pickedPatient ? (
                <div className="dp-picked">
                  <span className="dw-avatar" aria-hidden="true">{dpInitials(pickedPatient.patientName)}</span>
                  <div className="dp-picked-text">
                    <strong>{pickedPatient.patientName}</strong>
                    <span>{tr("شناسه بیمار:")} {toFa(pickedPatient.patientId)}</span>
                  </div>
                </div>
              ) : (
                !loadingPatients && !patientsError && (
                  <p className="dp-hint">
                    {uniquePatients.length === 0 ? tr("هنوز هیچ بیماری به شما تخصیص نیافته است.") : tr("بیماری را که می‌خواهید فایل برایش ارسال شود انتخاب کنید.")}
                  </p>
                )
              )}
            </section>

            <section className="dp-card">
              <div className="dp-card-head">
                <span className="dp-step" aria-hidden="true">{tr("۳")}</span>
                <h3><label htmlFor="dp-transfer-note">{tr("یادداشت (اختیاری)")}</label></h3>
              </div>
              <textarea
                id="dp-transfer-note"
                className="dw-input dp-textarea"
                rows={3}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={tr("توضیح کوتاه درباره فایل یا نتیجه آزمایش...")}
                disabled={sending}
              />
            </section>
          </div>

          <section className="dp-card">
            <div className="dp-card-head">
              <span className="dp-step" aria-hidden="true">{tr("۲")}</span>
              <h3>{tr("فایل‌ها")}</h3>
              {files.length > 0 && <span className="dp-opt">{tr("{0} از {1} فایل", [toFa(files.length), toFa(MAX_TRANSFER_FILES)])}</span>}
            </div>

            <label
              className={cx("dp-drop", dragOver && "is-over", sending && "is-disabled")}
              onDragOver={(e) => { e.preventDefault(); if (!sending) setDragOver(true); }}
              onDragEnter={(e) => { e.preventDefault(); if (!sending) setDragOver(true); }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
            >
              <span className="dp-drop-icon" aria-hidden="true"><UploadCloud size={26} /></span>
              <strong>{tr("فایل‌های صحی را انتخاب کنید")}</strong>
              <span>{tr("PDF، Excel، Word، JPG یا PNG")}</span>
              <small>{tr("حداکثر {0} فایل، هر فایل حداکثر ۱۵ مگابایت", [toFa(MAX_TRANSFER_FILES)])}</small>
              <input
                type="file"
                accept=".pdf,.xlsx,.xls,.docx,.jpg,.jpeg,.png,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.wordprocessingml.document,image/jpeg,image/png"
                multiple
                onChange={handleFilesChange}
                disabled={sending}
                aria-label={tr("انتخاب فایل‌های صحی")}
              />
            </label>

            {files.length > 0 && (
              <ul className="dp-files" aria-label={tr("فایل‌های انتخاب‌شده")}>
                {files.map((file, idx) => {
                  const kind = transferKind(file.type);
                  const Icon = kind.Icon;
                  return (
                    <li key={`${file.name}-${idx}`} className="dp-file">
                      <span className={`dp-ficon dw-tone-${kind.tone}`} aria-hidden="true"><Icon size={20} /></span>
                      <div className="dp-fbody">
                        <span className="dp-fname" title={file.name}>{file.name}</span>
                        <span className="dp-fmeta">
                          <span className={`dp-type dw-tone-${kind.tone}`}>{kind.label}</span>
                          <bdi>{formatFileSize(file.size)}</bdi>
                        </span>
                      </div>
                      <button
                        type="button"
                        className="dw-act is-danger dp-tip"
                        data-tip={tr("حذف از فهرست")}
                        aria-label={tr("حذف فایل {0}", [file.name])}
                        disabled={sending}
                        onClick={() => removeSelectedFile(idx)}
                      >
                        <Trash2 size={14} aria-hidden="true" /> {tr("حذف")}
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>

        <div className="dp-submit-row">
          <p className="dp-hint"><Lock size={13} aria-hidden="true" />{tr("مالکیت بیمار و سطح دسترسی در سرور بررسی می‌شود.")}</p>
          <button className="btn btn-primary dp-submit" type="submit" disabled={sending}>
            {sending ? <Loader2 size={18} className="dw-spin" aria-hidden="true" /> : <Send size={18} aria-hidden="true" />}
            {sending ? tr("در حال ارسال...") : tr("ارسال به بیمار")}
          </button>
        </div>
      </form>

      <section className="dp-history" style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        <div className="dp-section-head">
          <h3>{tr("تاریخچه ارسالی‌های من")}</h3>
          {!loadingTransfers && !transfersError && transfers.length > 0 && <span className="dw-chip dw-tone-accent">{toFa(transfers.length)} {tr("فایل")}</span>}
          <button type="button" className="btn btn-ghost btn-sm" onClick={reloadTransfers} disabled={loadingTransfers} aria-label={tr("بروزرسانی تاریخچه")}>
            <RefreshCw size={15} className={loadingTransfers ? "dw-spin" : undefined} aria-hidden="true" /> {tr("بروزرسانی")}
          </button>
        </div>

        {loadingTransfers && <SkeletonTable cols={7} rows={4} />}

        {!loadingTransfers && transfersError && (
          <div className="dw-state is-error" role="alert">
            <div className="dw-state-icon"><AlertTriangle size={28} aria-hidden="true" /></div>
            <h3>{tr("دریافت تاریخچه ناموفق بود")}</h3>
            {errDetail({ message: transfersError }) && <small>{errDetail({ message: transfersError })}</small>}
            <button type="button" className="btn btn-ghost btn-sm" onClick={reloadTransfers}><RefreshCw size={15} aria-hidden="true" /> {tr("تلاش مجدد")}</button>
          </div>
        )}

        {!loadingTransfers && !transfersError && transfers.length === 0 && (
          <div className="dw-state">
            <div className="dw-state-icon"><FolderOpen size={28} aria-hidden="true" /></div>
            <h3>{tr("هنوز هیچ فایلی ارسال نکرده‌اید.")}</h3>
            <p>{tr("پس از ارسال، فایل‌ها همین‌جا فهرست می‌شوند و می‌توانید آن‌ها را دانلود یا حذف کنید.")}</p>
          </div>
        )}

        {!loadingTransfers && !transfersError && transfers.length > 0 && (
          <div className="dw-table-wrap">
            <table className="dw-table dp-history-table" dir={curDir()}>
              <thead>
                <tr>
                  <th>{tr("بیمار")}</th>
                  <th>{tr("نام فایل")}</th>
                  <th>{tr("نوع")}</th>
                  <th>{tr("حجم")}</th>
                  <th>{tr("یادداشت")}</th>
                  <th>{tr("تاریخ ارسال")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {transfers.map((t) => {
                  const kind = transferKind(t.fileType);
                  const Icon = kind.Icon;
                  return (
                    <tr key={t.id}>
                      <td>
                        <div className="dw-person">
                          <span className="dw-avatar" aria-hidden="true">{dpInitials(t.patientName)}</span>
                          <span className="dw-person-name">{t.patientName || "—"}</span>
                        </div>
                      </td>
                      <td>
                        <div className="dp-fcell">
                          <span className={`dp-ficon dw-tone-${kind.tone}`} aria-hidden="true"><Icon size={17} /></span>
                          <span className="dp-fname" title={t.originalName}>{t.originalName}</span>
                        </div>
                      </td>
                      <td><span className={`dp-type dw-tone-${kind.tone}`}>{kind.label}</span></td>
                      <td><bdi dir="ltr" className="dw-id">{formatFileSize(t.fileSize)}</bdi></td>
                      <td>{t.note ? <div className="dp-note-cell">{t.note}</div> : <span className="dw-none">—</span>}</td>
                      <td><span className="dw-date">{toFa(dpDate(t.createdAt))}</span></td>
                      <td>
                        <div className="dw-actions">
                          <button
                            type="button"
                            className="dw-act is-info dp-tip"
                            data-tip={tr("دانلود فایل")}
                            disabled={downloadingId === t.id}
                            onClick={() => handleDownload(t.id, t.originalName)}
                          >
                            {downloadingId === t.id ? <Loader2 size={14} className="dw-spin" aria-hidden="true" /> : <Download size={14} aria-hidden="true" />} {tr("دانلود")}
                          </button>
                          <button
                            type="button"
                            className="dw-act is-danger dp-tip"
                            data-tip={tr("حذف فایل ارسالی")}
                            disabled={deletingId === t.id}
                            onClick={() => setDeleteTarget(t)}
                          >
                            {deletingId === t.id ? <Loader2 size={14} className="dw-spin" aria-hidden="true" /> : <Trash2 size={14} aria-hidden="true" />} {tr("حذف")}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* دیالوگ تایید حذف فایل انتقالی — از GlobalModal (مودال استاندارد سراسری) استفاده می‌کند */}
      <GlobalModal
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        size="sm"
        className="logout-confirm-modal dp-confirm"
        overlayClassName="logout-confirm-overlay"
        labelledBy="delete-transfer-title"
        closeOnOverlayClick={!deletingId}
        closeOnEsc={!deletingId}
        bare
      >
        {deleteTarget && (
          <>
            <div className="dp-confirm-icon" aria-hidden="true"><Trash2 size={26} /></div>
            <h3 id="delete-transfer-title">{tr("تایید حذف فایل")}</h3>
            <p>{tr("آیا از حذف این فایل ارسالی مطمئن هستید؟ این عملیات قابل بازگشت نیست.")}</p>
            <div className="dp-confirm-file">
              {deleteKind && <deleteKind.Icon size={16} aria-hidden="true" />}
              <bdi>{deleteTarget.originalName}</bdi>
            </div>
            <div className="modal-actions">
              <button type="button" className="btn btn-danger" onClick={confirmDeleteTransfer} disabled={!!deletingId}>
                {deletingId ? <Loader2 size={16} className="dp-spin" aria-hidden="true" /> : <Trash2 size={16} aria-hidden="true" />}
                {deletingId ? tr("در حال حذف...") : tr("بله، حذف کن")}
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setDeleteTarget(null)} disabled={!!deletingId}>
                {tr("انصراف")}
              </button>
            </div>
          </>
        )}
      </GlobalModal>
    </div>
  );
}

// ---------- بیماران من (فقط بیمارانی که با این داکتر نوبت دارند) ----------
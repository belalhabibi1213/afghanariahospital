import { ClipboardList, FilePlus2 } from "lucide-react";
import GlobalModal from "../../../../components/GlobalModal.jsx";
import { apiRequest } from "../../../../utils/api.js";
import { useEffect, useState } from "react";
import { PatientPanelHeader } from "./PatientPanelHeader.jsx";
import { tr, jdate } from "../../../../i18n/tr.js";
import { docName } from "../doctorWorkspaceUi.jsx";

// ---------- پرونده صحی (Medical Records) برای یک بیمار مشخص (ثبت ویزیت جدید + تاریخچه) ----------
// از همان endpoint هایی که برای «ویزیت‌ها» (encounters) از قبل در بک‌اند وجود دارد استفاده می‌کند:
// POST/PUT /api/medical-records/encounters — doctorId/patientId به‌صورت خودکار توسط سرور تعیین می‌شوند
// و ویرایش فقط برای رکوردهایی مجاز است که همین داکتر ثبت کرده (بررسی canManage در کنترلر).
export function PatientMedicalRecords({ patientId, patientName, myDoctorId, onClose, onOpenForm }) {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState({ type: "", text: "" });
  const [recDeleteTarget, setRecDeleteTarget] = useState(null); // ویزیت در انتظار تایید حذف
  const [recDeleting, setRecDeleting] = useState(false);

  function reload() {
    setLoading(true);
    setError("");
    apiRequest(`/medical-records/patient/${patientId}`)
      .then((data) => {
        setRecords(data.encounters || []);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, [patientId]);

  // حذف پرونده صحی (ویزیت) — فقط برای داکترِ ثبت‌کننده؛ پس از تایید در دیالوگ انجام می‌شود
  async function confirmDeleteRecord() {
    if (!recDeleteTarget) return;
    setRecDeleting(true);
    try {
      await apiRequest(`/medical-records/encounters/${recDeleteTarget.id}`, { method: "DELETE" });
      setStatus({ type: "success", text: tr("پرونده صحی حذف شد.") });
      setRecDeleteTarget(null);
      reload();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
      setRecDeleteTarget(null);
    } finally {
      setRecDeleting(false);
    }
  }

  return (
    <div className="dash-card glass dp-panel">
      <PatientPanelHeader icon={<ClipboardList size={22} />} title={tr("پرونده صحی")} patientName={patientName} onClose={onClose} />

      {status.text && <div className={`form-message ${status.type}`}>{status.text}</div>}

      <div className="hr-launch">
        <p>{tr("برای ثبت ویزیت جدید، فرم کامل پرونده صحی (علائم حیاتی، معاینه، تشخیص، آزمایش‌ها، تصاویر، توصیه‌ها و پیگیری) را باز کنید.")}</p>
        <button className="btn btn-primary" type="button" onClick={() => onOpenForm(null)}>
          <FilePlus2 size={16} aria-hidden="true" /> {tr("افزودن پرونده صحی جدید")}
        </button>
      </div>

      {error && <div className="form-message error">{error}</div>}
      {loading && <p>{tr("در حال بارگذاری...")}</p>}
      {!loading && records.length === 0 && <p>{tr("هنوز هیچ پرونده صحی‌ای برای این بیمار ثبت نشده است.")}</p>}
      {!loading && records.length > 0 && (
        <table className="dash-table" style={{ marginTop: 14 }}>
          <thead>
            <tr>
              <th>{tr("وضعیت")}</th>
              <th>{tr("تاریخ ویزیت")}</th>
              <th>{tr("علائم")}</th>
              <th>{tr("تشخیص")}</th>
              <th>{tr("فشار خون")}</th>
              <th>{tr("حرارت")}</th>
              <th>{tr("قد")}</th>
              <th>{tr("وزن")}</th>
              <th>{tr("تداوی")}</th>
              <th>{tr("داکتر")}</th>
              <th>{tr("عملیات")}</th>
            </tr>
          </thead>
          <tbody>
            {records.map((rec) => (
              <tr key={rec.id}>
                <td>
                  {rec.status === "draft" ? <span className="hr-badge hr-badge-draft">{tr("پیش‌نویس")}</span> : rec.sentToPatientAt ? <span className="hr-badge hr-badge-sent">{tr("ارسال‌شده")}</span> : <span className="hr-badge hr-badge-ok">{tr("ثبت‌شده")}</span>}
                </td>
                <td>{jdate(rec.visitDate)}</td>
                <td>{rec.symptoms || "—"}</td>
                <td>{rec.diagnosis || "—"}</td>
                <td>{rec.bloodPressure || "—"}</td>
                <td>{rec.temperature || "—"}</td>
                <td>{rec.height || "—"}</td>
                <td>{rec.weight || "—"}</td>
                <td>{rec.treatment || "—"}</td>
                <td>{docName(rec.doctorName) || "—"}</td>
                <td>
                  {myDoctorId && rec.doctorId === myDoctorId ? (
                    <>
                      <button className="btn btn-ghost btn-sm" onClick={() => onOpenForm(rec.id)}>{tr("ویرایش")}</button>{" "}
                      <button className="btn btn-danger btn-sm" type="button" onClick={() => setRecDeleteTarget(rec)}>{tr("🗑️ حذف")}</button>
                    </>
                  ) : (
                    "—"
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <GlobalModal
        isOpen={!!recDeleteTarget}
        onClose={() => setRecDeleteTarget(null)}
        size="sm"
        className="logout-confirm-modal"
        overlayClassName="logout-confirm-overlay"
        labelledBy="delete-record-title"
        closeOnOverlayClick={!recDeleting}
        closeOnEsc={!recDeleting}
        bare
      >
        {recDeleteTarget && (
          <>
            <h3 id="delete-record-title">{tr("تایید حذف پرونده صحی")}</h3>
            <p>
              {tr("آیا از حذف پرونده صحی مورخ «{0}» مطمئن هستید؟ این عملیات قابل بازگشت نیست. آزمایش‌ها و نسخه‌های ثبت‌شده برای بیمار حذف نمی‌شوند.", [jdate(recDeleteTarget.visitDate)])}
            </p>
            <div className="modal-actions">
              <button type="button" className="btn btn-danger" onClick={confirmDeleteRecord} disabled={recDeleting}>
                {recDeleting ? tr("در حال حذف...") : tr("بله، حذف کن")}
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setRecDeleteTarget(null)} disabled={recDeleting}>
                {tr("انصراف")}
              </button>
            </div>
          </>
        )}
      </GlobalModal>
    </div>
  );
}

import { rangeParams } from "../doctorListUi.jsx";
import { tr, trc, jdate } from "../../../../i18n/tr.js";

export const STATUS_LABEL = trc({
  pending: "در انتظار تایید",
  confirmed: "تایید شده",
  completed: "انجام‌شده",
  cancelled: "لغوشده",
});

export const STATUS_TONE = { pending: "warn", confirmed: "ok", completed: "info", cancelled: "danger" };

export const GENDER_LABEL = trc({ male: "مرد", female: "زن" });

export const DEFAULT_QUERY = { q: "", status: "", gender: "", department: "", range: "", from: "", to: "", sort: "newest", page: 1, limit: 20 };

export const dpDate = (v) => (v ? jdate(v, { latin: true }) : "");

export const needsConfirmed = () => tr("پس از تایید نوبت فعال می‌شود");

export function ActiveChip({ active }) {
  return (
    <span className={`dw-chip dw-tone-${active ? "ok" : "danger"}`}>
      <span className="dw-dot" />{active ? tr("فعال") : tr("غیرفعال")}
    </span>
  );
}

export function listParams(query) {
  return {
    q: query.q, status: query.status, gender: query.gender, department: query.department,
    ...rangeParams(query), sort: query.sort, page: query.page, limit: query.limit,
  };
}

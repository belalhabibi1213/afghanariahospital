import GlobalModal from "../../../../components/GlobalModal.jsx";
import { JalaliDateInput } from "../../../../components/JalaliDateInput.jsx";
import { Pill } from "lucide-react";
import { apiDownload, apiRequest } from "../../../../utils/api.js";
import { groupPrescriptions } from "../../../../utils/prescriptionGroups.js";
import { useEffect, useRef, useState } from "react";
import { PatientPanelHeader } from "./PatientPanelHeader.jsx";
import { tr, jdate } from "../../../../i18n/tr.js";
import { docName } from "../doctorWorkspaceUi.jsx";

// ---------- نسخه‌نویسی برای یک بیمار مشخص (ثبت نسخه جدید + تاریخچه‌ی نسخه‌ها) ----------
export const EMPTY_MEDICINE_ROW = { medicationName: "", dosage: "", duration: "" };

export const EMPTY_PRESCRIPTION_FORM = {
  diagnosis: "", instructions: "", followUpDate: "", notes: "",
};

export function PatientPrescriptions({ patientId, patientName, myDoctorId, onClose }) {
  const [prescriptions, setPrescriptions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState(EMPTY_PRESCRIPTION_FORM);
  // لیست داروها: هر ردیف = یک دارو + دوز + مدت. با زدن Enter در یک ردیفِ پر، ردیف جدید باز می‌شود.
  const [medicines, setMedicines] = useState([{ ...EMPTY_MEDICINE_ROW }]);
  const medicineNameRefs = useRef([]);
  const groupIdRef = useRef(null); // اگر ثبت وسط کار خطا بخورد، تلاش مجدد با همان groupId ادامه می‌یابد
  const [rxDeleteTarget, setRxDeleteTarget] = useState(null); // دارو/نسخه در انتظار تایید حذف
  const [rxDeleting, setRxDeleting] = useState(false);
  const [focusRow, setFocusRow] = useState(null);
  // نسخه‌ای (گروه داروها) که در حال ویرایش است؛ null یعنی فرم «نسخه‌ی جدید»
  const [editingGroup, setEditingGroup] = useState(null);
  const editingId = editingGroup ? editingGroup.id : null;
  const [saving, setSaving] = useState(false);
  const [status, setStatus] = useState({ type: "", text: "" });
  const [pdfError, setPdfError] = useState("");
  // داروهای هم‌نسخه یک ردیف نمایش داده می‌شوند (بیمار هم همین را می‌بیند)
  const groupedPrescriptions = groupPrescriptions(prescriptions);

  // بعد از اضافه شدن ردیف جدید، فوکوس به فیلد نام دارو در همان ردیف می‌رود
  useEffect(() => {
    if (focusRow !== null && medicineNameRefs.current[focusRow]) {
      medicineNameRefs.current[focusRow].focus();
      setFocusRow(null);
    }
  }, [focusRow, medicines.length]);

  function updateMedicine(index, field, value) {
    setMedicines((rows) => rows.map((r, i) => (i === index ? { ...r, [field]: value } : r)));
  }

  function removeMedicineRow(index) {
    setMedicines((rows) => (rows.length <= 1 ? [{ ...EMPTY_MEDICINE_ROW }] : rows.filter((_, i) => i !== index)));
  }

  // Enter داخل ردیف دارو: فرم ارسال نمی‌شود؛ اگر نام دارو پر است ردیف بعدی باز می‌شود (یا به ردیف بعدی می‌رود)
  function handleMedicineKeyDown(e, index) {
    if (e.key !== "Enter") return;
    e.preventDefault();
    if (!medicines[index].medicationName.trim()) return;
    if (index < medicines.length - 1) {
      medicineNameRefs.current[index + 1]?.focus();
      return;
    }
    setMedicines((rows) => [...rows, { ...EMPTY_MEDICINE_ROW }]);
    setFocusRow(index + 1);
  }

  // حذف کل نسخه (همه‌ی داروهای آن) پس از تایید در دیالوگ
  async function confirmDeletePrescription() {
    if (!rxDeleteTarget) return;
    const targets = rxDeleteTarget.medicines;
    setRxDeleting(true);
    try {
      for (const t of targets) {
        await apiRequest(`/medical-records/prescriptions/${t.id}`, { method: "DELETE" });
      }
      if (editingGroup && editingGroup.id === rxDeleteTarget.id) cancelEdit();
      setStatus({ type: "success", text: targets.length > 1 ? tr("نسخه ({0} دارو) حذف شد.", [targets.length]) : tr("نسخه حذف شد.") });
    } catch (err) {
      setStatus({ type: "error", text: err.message });
    } finally {
      setRxDeleteTarget(null);
      setRxDeleting(false);
      reload();
    }
  }

  // چاپ مستقیم نسخه: داکتر نسخه را چاپ می‌کند و به بیمار می‌دهد تا از داروخانه دارو بگیرد
  async function handlePrescriptionPrint(id) {
    setPdfError("");
    try {
      await apiDownload(`/medical-records/prescriptions/${id}/pdf`, `prescription-${id}.pdf`, { print: true });
    } catch (err) {
      setPdfError(err.message);
    }
  }

  // دانلود/نمایش PDF حرفه‌ای نسخه برای داکتر (الزام: چاپ نسخه توسط داکتر).
  // در تب جدید باز می‌شود تا از نمایشگر PDF مرورگر هم بتوان برای چاپ استفاده کرد.
  async function handlePrescriptionPdf(id) {
    setPdfError("");
    try {
      await apiDownload(`/medical-records/prescriptions/${id}/pdf`, `prescription-${id}.pdf`, { openInNewTab: true });
    } catch (err) {
      setPdfError(err.message);
    }
  }

  function reload() {
    setLoading(true);
    setError("");
    apiRequest(`/medical-records/patient/${patientId}`)
      .then((data) => setPrescriptions(data.prescriptions || []))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  // eslint-disable-next-line react-hooks/exhaustive-deps
  useEffect(reload, [patientId]);

  // ویرایش کل نسخه: همه‌ی داروهای آن در فرم بارگذاری می‌شوند
  function startEdit(group) {
    setEditingGroup(group);
    setForm({
      diagnosis: group.diagnosis || "",
      instructions: group.instructions || "",
      followUpDate: group.followUpDate ? String(group.followUpDate).slice(0, 10) : "",
      notes: group.notes || "",
    });
    setMedicines(group.medicines.map((m) => ({
      id: m.id, medicationName: m.medicationName || "", dosage: m.dosage || "", duration: m.duration || "",
    })));
    setStatus({ type: "", text: "" });
  }

  function cancelEdit() {
    setEditingGroup(null);
    groupIdRef.current = null;
    setForm(EMPTY_PRESCRIPTION_FORM);
    setMedicines([{ ...EMPTY_MEDICINE_ROW }]);
    setStatus({ type: "", text: "" });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    // ردیف‌های خالی نادیده گرفته می‌شوند؛ حداقل یک دارو لازم است
    const filled = medicines
      .map((m) => ({ id: m.id, medicationName: m.medicationName.trim(), dosage: m.dosage.trim(), duration: m.duration.trim() }))
      .filter((m) => m.medicationName);
    if (filled.length === 0) {
      setStatus({ type: "error", text: tr("نام دوا الزامی است.") });
      return;
    }

    const shared = { ...form, followUpDate: form.followUpDate || undefined };

    setSaving(true);
    try {
      if (editingGroup) {
        // ویرایش نسخه: داروهای موجود به‌روز می‌شوند، ردیف‌های جدید اضافه و ردیف‌های حذف‌شده پاک می‌شوند
        const groupId = editingGroup.groupId
          || (typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `g${Date.now()}${Math.random().toString(36).slice(2, 10)}`);
        const keptIds = new Set(filled.filter((m) => m.id).map((m) => m.id));
        for (const old of editingGroup.medicines) {
          if (!keptIds.has(old.id)) {
            await apiRequest(`/medical-records/prescriptions/${old.id}`, { method: "DELETE" });
          }
        }
        for (const med of filled.filter((m) => m.id)) {
          const { id, ...fields } = med;
          await apiRequest(`/medical-records/prescriptions/${id}`, { method: "PUT", body: { ...shared, ...fields, groupId } });
        }
        for (const med of filled.filter((m) => !m.id)) {
          const { id, ...fields } = med;
          await apiRequest("/medical-records/prescriptions", { method: "POST", body: { ...shared, ...fields, patientId, groupId } });
        }
        setStatus({ type: "success", text: tr("نسخه به‌روزرسانی شد.") });
      } else {
        // هر دارو یک رکورد نسخه‌ی جداگانه است (با دوز/مدت خودش)؛ تشخیص/دستورالعمل/تاریخ پیگیری/یادداشت بین همه مشترک است
        // groupId مشترک: همه‌ی داروهای این بار ثبت در یک PDF نسخه چاپ می‌شوند و برای بیمار یک نسخه‌اند
        if (!groupIdRef.current) {
          groupIdRef.current = typeof crypto !== "undefined" && crypto.randomUUID
            ? crypto.randomUUID()
            : `g${Date.now()}${Math.random().toString(36).slice(2, 10)}`;
        }
        const groupId = groupIdRef.current;
        let saved = 0;
        try {
          for (const med of filled) {
            const { id, ...fields } = med;
            await apiRequest("/medical-records/prescriptions", { method: "POST", body: { ...shared, ...fields, patientId, groupId } });
            saved += 1;
          }
        } catch (err) {
          // اگر وسط کار خطا شد، داروهای ثبت‌شده از فرم برداشته می‌شوند تا دوباره ثبت نشوند
          setMedicines(filled.slice(saved));
          reload();
          throw new Error(tr("{0} دارو ثبت شد اما ثبت «{1}» ناموفق بود: {2}", [saved, filled[saved].medicationName, err.message]));
        }
        setStatus({ type: "success", text: filled.length > 1 ? tr("نسخه با {0} دارو ثبت شد.", [filled.length]) : tr("نسخه جدید ثبت شد.") });
      }
      cancelEdit();
      reload();
    } catch (err) {
      setStatus({ type: "error", text: err.message });
      if (editingGroup) reload();
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="dash-card glass dp-panel">
      <PatientPanelHeader icon={<Pill size={22} />} title={tr("نسخه‌های ثبت‌شده")} patientName={patientName} onClose={onClose} />

      {status.text && <div className={`form-message ${status.type}`}>{status.text}</div>}

      <form className="login-form inline-edit-form" onSubmit={handleSubmit} style={{ marginTop: 12 }}>
        <div className="field-row">
          <div className="field">
            <label>{tr("تشخیص (Diagnosis)")}</label>
            <textarea
              rows={2}
              value={form.diagnosis}
              onChange={(e) => setForm((f) => ({ ...f, diagnosis: e.target.value }))}
            />
          </div>
        </div>
        <label style={{ display: "block", marginTop: 6 }}>{tr("دارو(ها) (Medicines)")}</label>
        <p style={{ margin: "2px 0 8px", fontSize: 12, color: "var(--muted, #7a8699)" }}>
          {tr("بعد از نوشتن دارو و دوز، کلید Enter را بزنید تا ردیف داروی بعدی باز شود.")}
        </p>
        {medicines.map((m, i) => (
          <div className="field-row" key={i} style={{ alignItems: "flex-end" }}>
            <div className="field">
              {i === 0 && <label>{tr("نام دارو")}</label>}
              <input
                ref={(el) => { medicineNameRefs.current[i] = el; }}
                value={m.medicationName}
                onChange={(e) => updateMedicine(i, "medicationName", e.target.value)}
                onKeyDown={(e) => handleMedicineKeyDown(e, i)}
                placeholder={tr("دارو {0} — مثلاً: پاراسیتامول", [i + 1])}
              />
            </div>
            <div className="field">
              {i === 0 && <label>{tr("دوز (Dosage)")}</label>}
              <input
                value={m.dosage}
                onChange={(e) => updateMedicine(i, "dosage", e.target.value)}
                onKeyDown={(e) => handleMedicineKeyDown(e, i)}
                placeholder={tr("مثلاً: 500mg")}
              />
            </div>
            <div className="field">
              {i === 0 && <label>{tr("مدت (Duration)")}</label>}
              <input
                value={m.duration}
                onChange={(e) => updateMedicine(i, "duration", e.target.value)}
                onKeyDown={(e) => handleMedicineKeyDown(e, i)}
                placeholder={tr("مثلاً: ۷ روز")}
              />
            </div>
            {medicines.length > 1 && (
              <button
                type="button"
                className="btn btn-ghost btn-sm"
                onClick={() => removeMedicineRow(i)}
                aria-label={tr("حذف ردیف دارو {0}", [i + 1])}
                style={{ marginBottom: 6 }}
              >
                ✕
              </button>
            )}
          </div>
        ))}
        <button
          type="button"
          className="btn btn-ghost btn-sm"
          style={{ marginBottom: 10 }}
          onClick={() => { setMedicines((rows) => [...rows, { ...EMPTY_MEDICINE_ROW }]); setFocusRow(medicines.length); }}
        >
          {tr("➕ افزودن دارو")}
        </button>
        <div className="field-row">
          <div className="field">
            <label>{tr("دستورالعمل (Instructions)")}</label>
            <textarea
              rows={2}
              value={form.instructions}
              onChange={(e) => setForm((f) => ({ ...f, instructions: e.target.value }))}
            />
          </div>
        </div>
        <div className="field-row">
          <div className="field">
            <label>{tr("تاریخ پیگیری (Follow-up Date)")}</label>
            <JalaliDateInput
              value={form.followUpDate}
              onChange={(e) => setForm((f) => ({ ...f, followUpDate: e.target.value }))}
            />
          </div>
          <div className="field">
            <label>{tr("یادداشت (Notes)")}</label>
            <textarea
              rows={2}
              value={form.notes}
              onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
            />
          </div>
        </div>
        <div style={{ display: "flex", gap: 10 }}>
          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? tr("در حال ذخیره...") : editingId ? tr("ذخیره تغییرات") : tr("ثبت نسخه")}
          </button>
          {editingId && (
            <button className="btn btn-ghost" type="button" onClick={cancelEdit}>{tr("انصراف")}</button>
          )}
        </div>
      </form>

      {error && <div className="form-message error">{error}</div>}
      {pdfError && <div className="form-message error">{pdfError}</div>}
      {loading && <p>{tr("در حال بارگذاری...")}</p>}
      {!loading && prescriptions.length === 0 && <p>{tr("هنوز هیچ نسخه‌ای برای این بیمار ثبت نشده است.")}</p>}
      {!loading && prescriptions.length > 0 && (
        <table className="dash-table" style={{ marginTop: 14 }}>
          <thead>
            <tr>
              <th>{tr("تشخیص")}</th>
              <th>{tr("دارو(ها)")}</th>
              <th>{tr("دوز")}</th>
              <th>{tr("مدت")}</th>
              <th>{tr("تاریخ پیگیری")}</th>
              <th>{tr("داکتر")}</th>
              <th>{tr("تاریخ ثبت")}</th>
              <th>{tr("عملیات")}</th>
            </tr>
          </thead>
          <tbody>
            {groupedPrescriptions.map((pr) => (
              <tr key={pr.id}>
                <td>{pr.diagnosis || "—"}</td>
                <td>{pr.medicines.map((m, i) => <div key={m.id}>{pr.medicines.length > 1 ? `${i + 1}. ` : ""}{m.medicationName}</div>)}</td>
                <td>{pr.medicines.map((m) => <div key={m.id}>{m.dosage || "—"}</div>)}</td>
                <td>{pr.medicines.map((m) => <div key={m.id}>{m.duration || "—"}</div>)}</td>
                <td>{jdate(pr.followUpDate)}</td>
                <td>{docName(pr.doctorName) || "—"}</td>
                <td>{jdate(pr.createdAt)}</td>
                <td>
                  {myDoctorId && pr.doctorId === myDoctorId ? (
                    <>
                      <button className="btn btn-primary btn-sm" type="button" onClick={() => handlePrescriptionPrint(pr.id)}>{tr("🖨️ چاپ نسخه")}</button>{" "}
                      <button className="btn btn-ghost btn-sm" onClick={() => handlePrescriptionPdf(pr.id)}>{tr("📄 PDF نسخه")}</button>{" "}
                      <button className="btn btn-ghost btn-sm" onClick={() => startEdit(pr)}>{tr("ویرایش")}</button>{" "}
                      <button className="btn btn-danger btn-sm" type="button" onClick={() => setRxDeleteTarget(pr)}>{tr("🗑️ حذف")}</button>
                    </>
                  ) : (
                    "—"
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <GlobalModal
        isOpen={!!rxDeleteTarget}
        onClose={() => setRxDeleteTarget(null)}
        size="sm"
        className="logout-confirm-modal"
        overlayClassName="logout-confirm-overlay"
        labelledBy="delete-rx-title"
        closeOnOverlayClick={!rxDeleting}
        closeOnEsc={!rxDeleting}
        bare
      >
        {rxDeleteTarget && (
          <>
            <h3 id="delete-rx-title">{tr("تایید حذف نسخه")}</h3>
            <p>
              {tr("آیا از حذف این نسخه{0} مطمئن هستید؟ این عملیات قابل بازگشت نیست.", [
                rxDeleteTarget.medicines.length > 1
                  ? tr(" ({0} دارو: {1})", [rxDeleteTarget.medicines.length, rxDeleteTarget.medicines.map((m) => m.medicationName).join(tr("، "))])
                  : ` («${rxDeleteTarget.medicines[0].medicationName}»)`,
              ])}
            </p>
            <div className="modal-actions">
              <button type="button" className="btn btn-danger" onClick={confirmDeletePrescription} disabled={rxDeleting}>
                {rxDeleting ? tr("در حال حذف...") : tr("بله، حذف کن")}
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setRxDeleteTarget(null)} disabled={rxDeleting}>
                {tr("انصراف")}
              </button>
            </div>
          </>
        )}
      </GlobalModal>
    </div>
  );
}

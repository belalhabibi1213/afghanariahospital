import { X } from "lucide-react";
import { tr } from "../../../../i18n/tr.js";

// هدر مشترک پنل نسخه / پرونده‌ی صحی: نام بیمار + دکمه‌ی واضح بستن (فقط ظاهر؛ منطق پنل‌ها دست‌نخورده)
export function PatientPanelHeader({ icon, title, patientName, onClose }) {
  return (
    <div className="dp-panel-head">
      <div className="dp-panel-icon" aria-hidden="true">{icon}</div>
      <div className="dp-panel-titles">
        <h3>{title}</h3>
        <p className="dp-panel-patient">{tr("بیمار:")} <strong>{patientName}</strong></p>
      </div>
      <button className="btn btn-ghost btn-sm dp-panel-close" type="button" onClick={onClose} aria-label={tr("بستن پنل {0}", [title])}>
        <X size={16} aria-hidden="true" /> {tr("بستن")}
      </button>
    </div>
  );
}

// تب «بیماران من» (شامل نسخه‌ها، پرونده‌ها و نتایج آزمایش هر بیمار) — از DoctorDashboard جدا شده تا lazy-load شود.
import { AlertTriangle, Building2, Cake, CalendarCheck, CalendarDays, ClipboardList, Eye, FileHeart, FilePlus2, FilterX, Loader2, Mail, MapPin, Phone, Pill, RefreshCw, Search, UserCheck, UserRound, Users } from "lucide-react";
import { DateRangeFilter, DetailDrawer, DrawerRow, DrawerSkeleton, InlineError, ListPager, StatCard, fmtNum, useFetchList, useFetchOne, useListQuery } from "../doctorListUi.jsx";
import HealthRecordForm from "../healthRecord/HealthRecordForm.jsx";
import { SkeletonTable, cx, dpInitials, errDetail, toFa, dept, docName } from "../doctorWorkspaceUi.jsx";
import { apiRequest } from "../../../../utils/api.js";
import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { ActiveChip, DEFAULT_QUERY, GENDER_LABEL, needsConfirmed, STATUS_LABEL, STATUS_TONE, dpDate, listParams } from "./patientsShared.jsx";
import { PatientMedicalRecords } from "./PatientMedicalRecords.jsx";
import { PatientPrescriptions } from "./PatientPrescriptions.jsx";
import { tr, curDir } from "../../../../i18n/tr.js";

// ---------- بیماران من ----------
// فقط بیمارانی که با این داکتر نوبت دارند (هر بیمار یک ردیف). داده‌ها از API‌های واقعی می‌آیند:
//   GET /doctors/me/patients/stats   کارت‌های آماری + فهرست بخش‌ها
//   GET /doctors/me/patients/list    فهرست سروری: جستجو/فیلتر/مرتب‌سازی/صفحه‌بندی (فقط یک صفحه)
//   GET /doctors/me/patients/:id     جزئیات برای Drawer (هنگام باز شدن)
// نسخه‌ها، پرونده‌های صحی و نتایج آزمایش همان پنل‌های قبلی هستند و به همان بیمارِ واقعی وصل می‌شوند.
export default function MyPatients() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { raw, query, typing, set, setPage, reset } = useListQuery(DEFAULT_QUERY);
  const list = useFetchList("/doctors/me/patients/list", listParams(query));
  const statsReq = useFetchOne("/doctors/me/patients/stats", "stats");
  const [drawerId, setDrawerId] = useState(null);
  const [tab, setTab] = useState("general");
  const detail = useFetchOne(drawerId ? `/doctors/me/patients/${drawerId}` : "", drawerId);
  const [selected, setSelected] = useState(() => new Set());
  const [activePatient, setActivePatient] = useState(null); // { patientId, patientName } — پنل نسخه‌ها
  const [activeRecordPatient, setActiveRecordPatient] = useState(null); // { patientId, patientName } — پنل پرونده‌های صحی
  // فرم کامل «افزودن/ویرایش پرونده صحی» (تمام‌صفحه، جایگزین فهرست تا بسته شدن)
  const [recordForm, setRecordForm] = useState(null);
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState("");
  const firstPanelRender = useRef(true);
  const panelsRef = useRef(null);

  const patients = useMemo(() => (list.data && Array.isArray(list.data.patients) ? list.data.patients : []), [list.data]);
  const pagination = list.data ? list.data.pagination : null;
  const myDoctorId = list.data ? list.data.doctorId || null : null;
  const stats = statsReq.data ? statsReq.data.stats : null;
  const departments = stats ? stats.departments : [];
  const p = detail.data ? detail.data.patient : null;

  useEffect(() => { setSelected(new Set()); }, [patients]);

  // لینک مستقیم از «نوبت‌های من» (?tab=patients&patient=ID): Drawer همان بیمار باز می‌شود
  const linkedPatient = searchParams.get("patient");
  useEffect(() => {
    if (linkedPatient && /^\d+$/.test(linkedPatient)) {
      setDrawerId(Number(linkedPatient));
      setTab("general");
      setSearchParams((prev) => { const next = new URLSearchParams(prev); next.delete("patient"); return next; }, { replace: true });
    }
  }, [linkedPatient, setSearchParams]);

  // وقتی پنل نسخه/پرونده بسته می‌شود، شمارنده‌های Drawer دوباره خوانده می‌شوند
  useEffect(() => {
    if (firstPanelRender.current) { firstPanelRender.current = false; return; }
    if (!activePatient && !activeRecordPatient) { list.reload(); if (drawerId) detail.reload(); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activePatient, activeRecordPatient]);

  // پنل نسخه/پرونده زیر جدول باز می‌شود؛ برای اینکه کاربر آن را گم نکند، به نمایش می‌آوریم
  useEffect(() => {
    if (!(activePatient || activeRecordPatient) || !panelsRef.current) return;
    const reduce = typeof window.matchMedia === "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (typeof panelsRef.current.scrollIntoView === "function") {
      panelsRef.current.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "nearest" });
    }
  }, [activePatient, activeRecordPatient]);

  function openDrawer(id) { setTab("general"); setDrawerId(id); }
  function closeDrawer() { setDrawerId(null); }
  function openPrescriptions(row) {
    closeDrawer();
    setActiveRecordPatient(null);
    setActivePatient({ patientId: row.patientId, patientName: row.patientName });
  }
  function openRecords(row) {
    closeDrawer();
    setActivePatient(null);
    setActiveRecordPatient({ patientId: row.patientId, patientName: row.patientName });
  }

  // فرم پرونده صحی به فهرست نوبت‌های تاییدشده/انجام‌شده‌ی همین بیمار با همین داکتر نیاز دارد؛ از API جزئیات می‌آید
  async function openRecordForm(row, recordId) {
    setFormError("");
    setFormLoading(true);
    try {
      const data = await apiRequest(`/doctors/me/patients/${row.patientId}`);
      const appts = (data.patient.appointments || [])
        .filter((a) => a.status === "confirmed" || a.status === "completed")
        .map((a) => ({ appointmentId: a.id, appointmentDate: a.appointmentDate, appointmentTime: a.appointmentTime, appointmentStatus: a.status }));
      closeDrawer();
      setRecordForm({
        patientId: row.patientId, patientName: row.patientName, recordId: recordId || null,
        defaultAppointmentId: appts[0] ? appts[0].appointmentId : "", appointments: appts,
      });
    } catch (err) {
      setFormError(errDetail(err) || tr("باز کردن فرم پرونده صحی ناموفق بود"));
    } finally {
      setFormLoading(false);
    }
  }

  const hasFilters = Boolean(raw.q.trim() || raw.status || raw.gender || raw.department || raw.range || raw.sort !== "newest");
  const hasData = list.data !== null;
  const firstLoad = list.loading && !hasData;
  const fatal = Boolean(list.error) && !hasData;
  const noPatientsAtAll = !list.loading && !list.error && pagination && pagination.total === 0 && !hasFilters && !typing;
  const rowOffset = pagination ? (pagination.page - 1) * query.limit : 0;
  const allOnPageSelected = patients.length > 0 && patients.every((x) => selected.has(x.patientId));
  const toggleAll = () => setSelected(allOnPageSelected ? new Set() : new Set(patients.map((x) => x.patientId)));
  const toggleOne = (id) => setSelected((prev) => { const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next; });

  // فرم پرونده صحی کل ناحیه‌ی «بیماران من» را می‌گیرد (۹ مرحله‌ی تب‌دار)؛ با بستن، به فهرست برمی‌گردیم
  if (recordForm) {
    return (
      <HealthRecordForm
        patientId={recordForm.patientId}
        patientName={recordForm.patientName}
        recordId={recordForm.recordId || null}
        defaultAppointmentId={recordForm.defaultAppointmentId || ""}
        appointments={recordForm.appointments}
        onClose={(changed) => {
          const form = recordForm;
          setRecordForm(null);
          if (changed) { setActiveRecordPatient({ patientId: form.patientId, patientName: form.patientName }); list.reload(); }
        }}
      />
    );
  }

  return (
    <>
      <div className="dash-card glass dw-scope">
        <header className="dw-header">
          <div className="dw-header-icon" aria-hidden="true"><Users size={24} /></div>
          <div className="dw-header-text">
            <h2>{tr("بیماران من")}</h2>
            <p>{tr("مدیریت و مشاهده بیماران ثبت‌شده و سوابق مراجعه")}</p>
          </div>
          <div className="dw-header-actions">
            <button type="button" className="btn btn-ghost btn-sm dp-tip" data-tip={tr("دریافت دوباره‌ی فهرست")} onClick={() => { list.reload(); statsReq.reload(); }} disabled={list.loading} aria-label={tr("بروزرسانی فهرست بیماران")}>
              <RefreshCw size={15} className={list.loading ? "dw-spin" : undefined} aria-hidden="true" /> {tr("بروزرسانی")}
            </button>
          </div>
        </header>

        <div className="dl-stats" aria-label={tr("آمار بیماران")}>
          <StatCard tone="info" icon={<Users size={22} />} title={tr("کل بیماران")} value={stats ? stats.total : null} loading={statsReq.loading} />
          <StatCard tone="ok" icon={<UserCheck size={22} />} title={tr("بیماران فعال")} value={stats ? stats.active : null} loading={statsReq.loading} />
          <StatCard tone="warn" icon={<CalendarCheck size={22} />} title={tr("مراجعه امروز")} value={stats ? stats.today : null} loading={statsReq.loading} />
          <StatCard tone="accent" icon={<CalendarDays size={22} />} title={tr("مراجعه این هفته")} value={stats ? stats.week : null} loading={statsReq.loading} />
        </div>
        {statsReq.error && <InlineError message={tr("دریافت آمار ناموفق بود. {0}", [errDetail(statsReq.error)])} onRetry={statsReq.reload} />}
        {formError && <InlineError message={formError} onRetry={() => setFormError("")} />}

        <div className="dl-filters" role="search">
          <div className="dw-field dl-search">
            <label htmlFor="dl-pat-search">{tr("جستجو")}</label>
            <div className="dw-input-icon">
              <Search size={16} aria-hidden="true" />
              <input
                id="dl-pat-search" className="dw-input" type="search" autoComplete="off" value={raw.q} maxLength={100}
                onChange={(e) => set({ q: e.target.value })} placeholder={tr("نام، شماره پرونده، شماره تماس یا ایمیل...")}
              />
            </div>
          </div>
          <div className="dw-field">
            <label htmlFor="dl-pat-status">{tr("وضعیت")}</label>
            <select id="dl-pat-status" className="dw-select" value={raw.status} onChange={(e) => set({ status: e.target.value })}>
              <option value="">{tr("همه")}</option>
              <option value="active">{tr("فعال")}</option>
              <option value="inactive">{tr("غیرفعال")}</option>
            </select>
          </div>
          <div className="dw-field">
            <label htmlFor="dl-pat-gender">{tr("جنسیت")}</label>
            <select id="dl-pat-gender" className="dw-select" value={raw.gender} onChange={(e) => set({ gender: e.target.value })}>
              <option value="">{tr("همه")}</option>
              <option value="male">{tr("مرد")}</option>
              <option value="female">{tr("زن")}</option>
            </select>
          </div>
          <div className="dw-field">
            <label htmlFor="dl-pat-dept">{tr("بخش / تخصص")}</label>
            <select id="dl-pat-dept" className="dw-select" value={raw.department} onChange={(e) => set({ department: e.target.value })}>
              <option value="">{tr("همه")}</option>
              {departments.map((dep) => <option key={dep} value={dep}>{dept(dep)}</option>)}
            </select>
          </div>
          <DateRangeFilter id="dl-pat-range" label={tr("تاریخ آخرین مراجعه")} range={raw.range} from={raw.from} to={raw.to} onChange={set} />
          <div className="dw-field">
            <label htmlFor="dl-pat-sort">{tr("مرتب‌سازی")}</label>
            <select id="dl-pat-sort" className="dw-select" value={raw.sort} onChange={(e) => set({ sort: e.target.value })}>
              <option value="newest">{tr("جدیدترین")}</option>
              <option value="oldest">{tr("قدیمی‌ترین")}</option>
              <option value="name">{tr("نام (الفبایی)")}</option>
            </select>
          </div>
          {hasFilters && (
            <div className="dl-filters-actions">
              <button type="button" className="btn btn-ghost btn-sm" onClick={reset}><FilterX size={15} aria-hidden="true" /> {tr("پاک کردن فیلترها")}</button>
            </div>
          )}
          {(typing || (raw.q.trim() && pagination)) && (
            <div className="dl-search-meta" aria-live="polite">
              {typing || list.loading
                ? <span className="dw-chip dw-tone-neutral"><Loader2 size={13} className="dw-spin" aria-hidden="true" />{tr("در حال جستجو...")}</span>
                : <span className="dw-chip dw-tone-accent"><Search size={13} aria-hidden="true" />{tr("جستجو برای «{0}» — {1} نتیجه", [query.q, fmtNum(pagination.total)])}</span>}
            </div>
          )}
        </div>

        {firstLoad && <div aria-busy="true" aria-label={tr("در حال بارگذاری بیماران")}><SkeletonTable cols={7} rows={6} /></div>}

        {fatal && (
          <div className="dw-state is-error" role="alert">
            <div className="dw-state-icon"><AlertTriangle size={28} aria-hidden="true" /></div>
            <h3>{tr("دریافت فهرست بیماران ناموفق بود")}</h3>
            {errDetail(list.error) && <small>{errDetail(list.error)}</small>}
            <button type="button" className="btn btn-primary btn-sm" onClick={() => { list.reload(); statsReq.reload(); }}><RefreshCw size={15} aria-hidden="true" /> {tr("تلاش مجدد")}</button>
          </div>
        )}

        {hasData && list.error && (
          <InlineError message={tr("بروزرسانی فهرست با مشکل مواجه شد؛ اطلاعات زیر ممکن است قدیمی باشد. {0}", [errDetail(list.error)])} onRetry={list.reload} />
        )}

        {noPatientsAtAll && (
          <div className="dw-state">
            <div className="dw-state-icon"><UserRound size={28} aria-hidden="true" /></div>
            <h3>{tr("هنوز هیچ بیماری به شما تخصیص نیافته است.")}</h3>
          </div>
        )}
        {hasData && pagination && pagination.total === 0 && !noPatientsAtAll && !typing && (
          <div className="dw-state">
            <div className="dw-state-icon"><Search size={28} aria-hidden="true" /></div>
            <h3>{tr("هیچ بیماری مطابق فیلترهای انتخاب‌شده پیدا نشد.")}</h3>
            <button type="button" className="btn btn-ghost btn-sm" onClick={reset}><FilterX size={15} aria-hidden="true" /> {tr("پاک کردن فیلترها")}</button>
          </div>
        )}

        {hasData && patients.length > 0 && (
          <div className="dl-table-card">
            {selected.size > 0 && (
              <div className="dl-selection-bar" role="status">
                <span>{fmtNum(selected.size)} {tr("بیمار انتخاب شده")}</span>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setSelected(new Set())}>{tr("لغو انتخاب")}</button>
              </div>
            )}
            {list.loading && <div className="dl-refreshing" aria-hidden="true"><span className="dw-chip dw-tone-neutral"><Loader2 size={13} className="dw-spin" />{tr("در حال بروزرسانی...")}</span></div>}
            <div className="dw-table-wrap">
              <table className="dw-table dl-table" dir={curDir()}>
                <caption style={{ position: "absolute", width: 1, height: 1, overflow: "hidden", clip: "rect(0 0 0 0)" }}>{tr("فهرست بیماران")}</caption>
                <thead>
                  <tr>
                    <th className="dl-col-check"><input type="checkbox" checked={allOnPageSelected} onChange={toggleAll} aria-label={tr("انتخاب همه‌ی بیماران این صفحه")} /></th>
                    <th className="dl-col-num dl-hide-md">#</th>
                    <th>{tr("نام کامل مریض")}</th>
                    <th>{tr("شماره پرونده")}</th>
                    <th className="dl-hide-md">{tr("سن")}</th>
                    <th className="dl-hide-md">{tr("جنسیت")}</th>
                    <th className="dl-hide-md">{tr("شماره تماس")}</th>
                    <th className="dl-hide-md">{tr("بخش / تخصص")}</th>
                    <th>{tr("آخرین مراجعه")}</th>
                    <th>{tr("وضعیت")}</th>
                    <th>{tr("عملیات")}</th>
                  </tr>
                </thead>
                <tbody>
                  {patients.map((r, i) => {
                    const recOpen = !!activeRecordPatient && activeRecordPatient.patientId === r.patientId;
                    const rxOpen = !!activePatient && activePatient.patientId === r.patientId;
                    return (
                      <tr
                        key={r.patientId}
                        className={cx(selected.has(r.patientId) && "is-selected", (drawerId === r.patientId || recOpen || rxOpen) && "is-viewing")}
                        tabIndex={0}
                        onClick={() => openDrawer(r.patientId)}
                        onKeyDown={(e) => { if (e.key === "Enter" && e.target === e.currentTarget) openDrawer(r.patientId); }}
                      >
                        <td className="dl-col-check" onClick={(e) => e.stopPropagation()}>
                          <input type="checkbox" checked={selected.has(r.patientId)} onChange={() => toggleOne(r.patientId)} aria-label={tr("انتخاب {0}", [r.patientName])} />
                        </td>
                        <td className="dl-col-num dl-hide-md">{toFa(rowOffset + i + 1)}</td>
                        <td className="dl-col-main">
                          <div className="dw-person">
                            <span className="dw-avatar" aria-hidden="true">{dpInitials(r.patientName)}</span>
                            <span className="dw-person-name">{r.patientName}</span>
                          </div>
                        </td>
                        <td data-label={tr("شماره پرونده")}>{r.patientCode ? <span className="dl-code">{r.patientCode}</span> : "—"}</td>
                        <td className="dl-hide-md">{r.age != null ? tr("{0} سال", [toFa(r.age)]) : "—"}</td>
                        <td className="dl-hide-md">{GENDER_LABEL[r.gender] || "—"}</td>
                        <td className="dl-hide-md">{r.phone ? <span className="dl-code">{toFa(r.phone)}</span> : "—"}</td>
                        <td className="dl-hide-md">{r.department ? <span className="dw-dept"><Building2 size={14} aria-hidden="true" /><span className="dl-ellipsis" title={dept(r.department)}>{dept(r.department)}</span></span> : "—"}</td>
                        <td data-label={tr("آخرین مراجعه")}>{r.lastVisitDate ? <span className="dw-date">{toFa(r.lastVisitDate)}</span> : <span className="dw-none">—</span>}</td>
                        <td data-label={tr("وضعیت")}><ActiveChip active={r.isActive} /></td>
                        <td className="dl-col-actions" onClick={(e) => e.stopPropagation()}>
                          <div className="dl-actions">
                            <button type="button" className="dl-icon-btn is-info dp-tip" data-tip={tr("مشاهده جزئیات")} aria-label={tr("مشاهده جزئیات {0}", [r.patientName])} onClick={() => openDrawer(r.patientId)}>
                              <Eye size={16} aria-hidden="true" />
                            </button>
                            <button
                              type="button" className={cx("dl-icon-btn dp-tip", recOpen && "is-warn")} disabled={!r.hasConfirmed}
                              data-tip={r.hasConfirmed ? tr("مشاهده پرونده صحی") : needsConfirmed()} aria-label={tr("مشاهده پرونده صحی {0}", [r.patientName])}
                              onClick={() => (recOpen ? setActiveRecordPatient(null) : openRecords(r))}
                            >
                              <FileHeart size={16} aria-hidden="true" />
                            </button>
                            <button
                              type="button" className={cx("dl-icon-btn is-ok dp-tip", rxOpen && "is-warn")} disabled={!r.hasConfirmed}
                              data-tip={r.hasConfirmed ? tr("نسخه‌ها / افزودن نسخه") : needsConfirmed()} aria-label={tr("نسخه‌های {0}", [r.patientName])}
                              onClick={() => (rxOpen ? setActivePatient(null) : openPrescriptions(r))}
                            >
                              <Pill size={16} aria-hidden="true" />
                            </button>
                            <button
                              type="button" className="dl-icon-btn is-info dp-tip" disabled={!r.hasConfirmed || formLoading}
                              data-tip={r.hasConfirmed ? tr("افزودن پرونده صحی") : needsConfirmed()} aria-label={tr("افزودن پرونده صحی برای {0}", [r.patientName])}
                              onClick={() => openRecordForm(r)}
                            >
                              {formLoading ? <Loader2 size={16} className="dw-spin" aria-hidden="true" /> : <FilePlus2 size={16} aria-hidden="true" />}
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <ListPager pagination={pagination} limit={query.limit} loading={list.loading} noun={tr("بیمار")} onPage={setPage} onLimit={(limit) => set({ limit })} />
          </div>
        )}
      </div>

      <DetailDrawer
        open={drawerId !== null}
        title={tr("جزئیات بیمار")}
        icon={<UserRound size={18} />}
        onClose={closeDrawer}
        footer={p && (
          <>
            <button type="button" className="btn btn-primary btn-sm" disabled={!p.hasConfirmed} title={p.hasConfirmed ? undefined : needsConfirmed()} onClick={() => openRecords(p)}>
              <FileHeart size={15} aria-hidden="true" /> {tr("مشاهده پرونده کامل")}
            </button>
            <button type="button" className="btn btn-ghost btn-sm" disabled={!p.hasConfirmed || formLoading} title={p.hasConfirmed ? undefined : needsConfirmed()} onClick={() => openRecordForm(p)}>
              <FilePlus2 size={15} aria-hidden="true" /> {tr("افزودن پرونده صحی")}
            </button>
          </>
        )}
      >
        {detail.loading && <DrawerSkeleton />}
        {detail.error && (
          <InlineError
            message={detail.error.status === 404 ? tr("این بیمار پیدا نشد یا با شما نوبتی ندارد.") : tr("دریافت جزئیات بیمار ناموفق بود. {0}", [errDetail(detail.error)])}
            onRetry={detail.error.status === 404 ? undefined : detail.reload}
          />
        )}
        {p && (
          <>
            <div className="dl-who">
              <span className="dw-avatar" aria-hidden="true">{dpInitials(p.patientName)}</span>
              <div className="dl-who-text">
                <strong>{p.patientName}</strong>
                <span>{tr("شماره پرونده:")} <bdi className="dl-code">{p.patientCode || "—"}</bdi></span>
              </div>
              <ActiveChip active={p.isActive} />
            </div>
            <div className="dl-tabs" role="tablist" aria-label={tr("بخش‌های جزئیات بیمار")}>
              {[["general", tr("اطلاعات عمومی")], ["history", tr("تاریخچه مراجعه")], ["records", tr("پرونده‌های صحی")]].map(([key, label]) => (
                <button key={key} type="button" role="tab" className="dl-tab" aria-selected={tab === key} onClick={() => setTab(key)}>{label}</button>
              ))}
            </div>

            {tab === "general" && (
              <>
                <div className="dl-rows">
                  <DrawerRow icon={<UserRound size={14} />} label={tr("جنسیت")}>{GENDER_LABEL[p.gender]}</DrawerRow>
                  <DrawerRow icon={<CalendarDays size={14} />} label={tr("سن")}>{p.age != null ? tr("{0} سال", [toFa(p.age)]) : null}</DrawerRow>
                  <DrawerRow icon={<Cake size={14} />} label={tr("تاریخ تولد")}>{p.dateOfBirth ? toFa(p.dateOfBirth) : null}</DrawerRow>
                  <DrawerRow icon={<Phone size={14} />} label={tr("شماره تماس")}>{p.phone ? <bdi>{toFa(p.phone)}</bdi> : null}</DrawerRow>
                  <DrawerRow icon={<Mail size={14} />} label={tr("ایمیل")}>{p.email ? <bdi>{p.email}</bdi> : null}</DrawerRow>
                  <DrawerRow icon={<MapPin size={14} />} label={tr("آدرس")}>{p.address}</DrawerRow>
                </div>
                <h4 className="dl-section-title">{tr("اطلاعات درمانی")}</h4>
                <div className="dl-rows">
                  <DrawerRow icon={<CalendarCheck size={14} />} label={tr("آخرین مراجعه")}>{p.lastVisitDate ? toFa(p.lastVisitDate) : null}</DrawerRow>
                  <DrawerRow icon={<Building2 size={14} />} label={tr("بخش")}>{dept(p.department)}</DrawerRow>
                  <DrawerRow icon={<UserRound size={14} />} label={tr("داکتر")}>{docName(p.doctorName)}</DrawerRow>
                  <DrawerRow icon={<ClipboardList size={14} />} label={tr("وضعیت")}><ActiveChip active={p.isActive} /></DrawerRow>
                </div>
                {!p.hasConfirmed && (
                  <div className="dw-notice dw-tone-info" role="note">
                    <AlertTriangle size={18} aria-hidden="true" />
                    <div className="dw-notice-text">{tr("ایمیل، تاریخ تولد، آدرس و سوابق درمانی پس از تایید نوبت بیمار نمایش داده می‌شود.")}</div>
                  </div>
                )}
              </>
            )}

            {tab === "history" && (
              p.appointments.length === 0 ? <p className="dl-note">{tr("نوبتی ثبت نشده است.")}</p> : (
                <>
                  <ul className="dl-visit-list">
                    {p.appointments.map((a) => (
                      <li key={a.id} className="dl-visit">
                        <div className="dl-visit-info">
                          <strong><span className="dw-date">{toFa(a.appointmentDate)}</span> — <bdi dir="ltr">{toFa(a.appointmentTime)}</bdi></strong>
                          <small>{dept(a.department) || "—"}</small>
                        </div>
                        <span className={`dw-chip dw-tone-${STATUS_TONE[a.status] || "neutral"}`}><span className="dw-dot" />{STATUS_LABEL[a.status] || a.status}</span>
                      </li>
                    ))}
                  </ul>
                  {p.appointments.length >= 50 && <small className="dp-hint">{tr("۵۰ نوبت اخیر نمایش داده شده است.")}</small>}
                </>
              )
            )}

            {tab === "records" && (
              !p.hasConfirmed || !p.summary ? (
                <p className="dl-note">{tr("پرونده‌های صحی و نسخه‌ها پس از تایید نوبت بیمار در دسترس خواهد بود.")}</p>
              ) : (
                <>
                  <div className="dl-mini-cards">
                    <div className="dl-mini"><strong>{toFa(p.summary.recordCount)}</strong><span>{tr("پرونده صحی")}{p.summary.lastRecordDate ? tr(" — آخرین: {0}", [toFa(dpDate(p.summary.lastRecordDate))]) : ""}</span></div>
                    <div className="dl-mini"><strong>{toFa(p.summary.prescriptionCount)}</strong><span>{tr("نسخه")}{p.summary.lastPrescriptionDate ? tr(" — آخرین: {0}", [toFa(dpDate(p.summary.lastPrescriptionDate))]) : ""}</span></div>
                  </div>
                  <div className="dp-actions">
                    <button type="button" className="dw-act is-info" onClick={() => openRecords(p)}><FileHeart size={14} aria-hidden="true" /> {tr("مشاهده پرونده‌ها")}</button>
                    <button type="button" className="dw-act" onClick={() => openPrescriptions(p)}><Pill size={14} aria-hidden="true" /> {tr("مشاهده نسخه‌ها")}</button>
                  </div>
                </>
              )
            )}
          </>
        )}
      </DetailDrawer>

      <div ref={panelsRef} style={{ display: activePatient || activeRecordPatient ? "flex" : "none", flexDirection: "column", gap: 20, scrollMarginTop: 16 }}>
        {activePatient && (
          <PatientPrescriptions
            patientId={activePatient.patientId}
            patientName={activePatient.patientName}
            myDoctorId={myDoctorId}
            onClose={() => setActivePatient(null)}
          />
        )}

        {activeRecordPatient && (
          <PatientMedicalRecords
            patientId={activeRecordPatient.patientId}
            patientName={activeRecordPatient.patientName}
            myDoctorId={myDoctorId}
            onClose={() => setActiveRecordPatient(null)}
            onOpenForm={(recordId) => openRecordForm({ patientId: activeRecordPatient.patientId, patientName: activeRecordPatient.patientName }, recordId)}
          />
        )}
      </div>
    </>
  );
}

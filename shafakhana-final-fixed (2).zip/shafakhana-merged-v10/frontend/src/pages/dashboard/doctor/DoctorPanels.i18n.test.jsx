import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, screen, cleanup, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { LanguageProvider } from "../../../context/LanguageContext.jsx";
import { LANG_STORAGE_KEY } from "../../../i18n/languages.js";
import enDict from "../../../i18n/dashboard/en.js";
import psDict from "../../../i18n/dashboard/ps.js";

vi.mock("../../../utils/api.js", async (importOriginal) => ({
  ...(await importOriginal()),
  apiRequest: vi.fn(), apiUpload: vi.fn(), apiDownload: vi.fn(), apiFetchImageUrl: vi.fn(async () => null), resolvePhotoUrl: (u) => u,
}));
vi.mock("../../../context/SettingsContext.jsx", () => ({
  useSiteSettings: () => ({ settings: { hospitalName: "شفاخانه افغان آریا", hospitalAddress: "", hospitalPhone: "0700", logoUrl: "" } }),
}));
import { apiRequest } from "../../../utils/api.js";
import { PatientPrescriptions } from "./patients/PatientPrescriptions.jsx";
import { PatientMedicalRecords } from "./patients/PatientMedicalRecords.jsx";
import HealthRecordForm from "./healthRecord/HealthRecordForm.jsx";

// تست دود برای پنل‌های بازشدنیِ داشبورد داکتر (نسخه‌ها، پرونده‌های صحی، فرم پرونده صحی) در زبان انگلیسی/پشتو.
const PERSIAN = /[؀-ۿ]/;
const PATIENT = { id: 5, fullName: "Ahmad Ahmadi", publicCode: "AAH-000005", gender: "male", dateOfBirth: "1990-01-01", phone: "0799" };
const DOCTOR = { id: 2, fullName: "Dr. Samadi", department: "داخله" };
const DATA = {
  patient: PATIENT, doctor: DOCTOR,
  encounters: [{ id: 9, doctorId: 2, status: "registered", visitDate: "2026-10-10", symptoms: "fever", diagnosis: "flu", doctorName: "Dr. Samadi", sentToPatientAt: null }],
  prescriptions: [{ id: 3, doctorId: 2, diagnosis: "flu", medicationName: "Paracetamol", dosage: "500mg", duration: "3d", followUpDate: "2026-10-20", doctorName: "Dr. Samadi", createdAt: "2026-10-10T09:00:00" }],
};
const APPTS = [{ appointmentId: 11, appointmentDate: "2026-09-01", appointmentTime: "09:00:00", appointmentStatus: "confirmed" }];

function visibleText(root) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const out = [];
  while (walker.nextNode()) {
    const el = walker.currentNode.parentElement;
    if (el && /^(SCRIPT|STYLE)$/.test(el.tagName)) continue;
    out.push(walker.currentNode.nodeValue);
  }
  root.querySelectorAll("[placeholder],[title],[aria-label],[data-tip]").forEach((el) => {
    ["placeholder", "title", "aria-label", "data-tip"].forEach((a) => el.getAttribute(a) && out.push(el.getAttribute(a)));
  });
  return out.join("\n");
}
function untranslated(container, lang) {
  const lines = visibleText(container).split("\n").map((l) => l.trim()).filter((l) => l && l !== "شفاخانه افغان آریا");
  return lang === "en"
    ? lines.filter((l) => PERSIAN.test(l))
    : lines.filter((l) => Object.prototype.hasOwnProperty.call(enDict, l) && psDict[l] !== l);
}
const wrap = (ui) => <LanguageProvider>{ui}</LanguageProvider>;

describe.each(["en", "ps"])("پنل‌های داکتر — زبان %s", (lang) => {
  beforeEach(() => {
    localStorage.setItem(LANG_STORAGE_KEY, lang);
    apiRequest.mockReset();
    apiRequest.mockImplementation(async (url) => (String(url).startsWith("/medical-records/patient/") ? DATA : {}));
    window.print = vi.fn();
  });
  afterEach(() => { cleanup(); localStorage.clear(); });

  it("نسخه‌های بیمار", async () => {
    const { container } = render(wrap(<PatientPrescriptions patientId={5} patientName="Ahmad Ahmadi" myDoctorId={2} onClose={() => {}} />));
    await screen.findByText("Paracetamol");
    expect(untranslated(container, lang)).toEqual([]);
  });

  it("پرونده‌های صحی بیمار", async () => {
    const { container } = render(wrap(<PatientMedicalRecords patientId={5} patientName="Ahmad Ahmadi" myDoctorId={2} onClose={() => {}} onOpenForm={() => {}} />));
    await screen.findByText("fever");
    expect(untranslated(container, lang)).toEqual([]);
  });

  it("فرم پرونده صحی — همه‌ی ۹ مرحله", async () => {
    const { container } = render(wrap(<HealthRecordForm patientId={5} patientName="Ahmad Ahmadi" appointments={APPTS} defaultAppointmentId={11} onClose={() => {}} />));
    await screen.findByText("Ahmad Ahmadi");
    const tabs = screen.getAllByRole("tab");
    expect(tabs).toHaveLength(9);
    for (let i = 0; i < tabs.length; i++) {
      await userEvent.click(screen.getAllByRole("tab")[i]);
      await waitFor(() => expect(screen.getAllByRole("tab")[i]).toHaveAttribute("aria-selected", "true"));
      expect(untranslated(container, lang), `tab ${i}`).toEqual([]);
    }
  });
});

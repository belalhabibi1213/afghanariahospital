import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { render, waitFor, cleanup, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { AuthProvider } from "../../../context/AuthContext.jsx";
import { LanguageProvider } from "../../../context/LanguageContext.jsx";
import { SettingsProvider } from "../../../context/SettingsContext.jsx";
import { ThemeProvider } from "../../../context/ThemeContext.jsx";
import DoctorDashboard from "./DoctorDashboard.jsx";
import { LANG_STORAGE_KEY } from "../../../i18n/languages.js";
import { USER_KEY } from "../../../utils/api.js";
import enDict from "../../../i18n/dashboard/en.js";
import psDict from "../../../i18n/dashboard/ps.js";

// تست دود: داشبورد داکتر با زبان انگلیسی/پشتو نباید هیچ متن دری در رابط (منو، عنوان، دکمه، جدول) نشان بدهد.
// داده‌های نمونه (نام بیمار، بخش، شیفت…) همان مقدارهای دری دیتابیس‌اند که فقط هنگام نمایش ترجمه می‌شوند.
const PERSIAN = /[؀-ۿ]/;
const TABS = ["schedule", "appointments", "patients", "prescriptions", "transfer", "billing", "chat"];

const APPT = {
  id: 5, patientId: 2, patientName: "Ali Karimi", patientCode: "P-0002", patientPhone: "0700000000",
  department: "داخله", doctorName: "Dr. Samadi", appointmentDate: "2026-10-13", appointmentTime: "09:00:00", status: "pending",
};
const PATIENT = {
  patientId: 2, patientName: "Ali Karimi", patientCode: "P-0002", phone: "0700000000", gender: "male", age: 34,
  department: "داخله", doctorName: "Dr. Samadi", hasConfirmed: true, active: true, status: "confirmed",
  lastVisit: "2026-10-10", summary: { recordCount: 1, prescriptionCount: 1, lastRecordDate: "2026-10-10", lastPrescriptionDate: "2026-10-10" },
};
const MOCKS = [
  ["/doctors/me/schedules", { schedules: [{ id: 1, department: "داخله", dayOfWeek: "شنبه، دوشنبه", startTime: "08:00:00", endTime: "14:00:00", shift: "صبح", status: "فعال" }] }],
  ["/doctors/me/appointments/stats", { stats: { total: 1, pending: 1, confirmed: 0, completed: 0, cancelled: 0, departments: ["داخله"] } }],
  ["/doctors/me/appointments/list", { appointments: [APPT], pagination: { total: 1, page: 1, limit: 20, totalPages: 1 } }],
  ["/doctors/me/patients/stats", { stats: { total: 1, active: 1, today: 0, week: 1, departments: ["داخله"] } }],
  ["/doctors/me/patients/list", { patients: [PATIENT], doctorId: 1, pagination: { total: 1, page: 1, limit: 20, totalPages: 1 } }],
  ["/doctors/me/patients?", { patients: [{ patientId: 2, patientName: "Ali Karimi" }] }],
  ["/doctors/me/invoices", { invoices: [] }],
  ["/doctors/me/file-transfers", { transfers: [] }],
  ["/chat/conversations", { conversations: [] }],
];

function visibleText(root) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const out = [];
  while (walker.nextNode()) {
    const el = walker.currentNode.parentElement;
    if (el && /^(SCRIPT|STYLE)$/.test(el.tagName)) continue;
    out.push(walker.currentNode.nodeValue);
  }
  root.querySelectorAll("[placeholder],[title],[aria-label],[data-tip],[data-label]").forEach((el) => {
    ["placeholder", "title", "aria-label", "data-tip", "data-label"].forEach((a) => el.getAttribute(a) && out.push(el.getAttribute(a)));
  });
  return out.join("\n");
}

describe.each(["en", "ps"])("داشبورد داکتر — زبان %s", (lang) => {
  beforeEach(() => {
    localStorage.setItem(LANG_STORAGE_KEY, lang);
    const user = { id: 1, fullName: "Doctor", role: "doctor" };
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    vi.stubGlobal("fetch", vi.fn().mockImplementation(async (url) => {
      const u = String(url);
      const hit = MOCKS.find(([p]) => u.includes(p));
      const body = u.includes("/auth/") ? { user, csrfToken: "c" } : hit ? hit[1] : {};
      return {
        ok: true,
        status: 200,
        json: async () => body,
        clone() { return this; },
        headers: { get: () => "application/json" },
      };
    }));
  });
  afterEach(() => { cleanup(); vi.unstubAllGlobals(); localStorage.clear(); });

  it.each(TABS)("تب %s متن دری ندارد", async (tab) => {
    const { container } = render(
      <MemoryRouter initialEntries={[`/dashboard/doctor?tab=${tab}`]}>
        <LanguageProvider>
          <AuthProvider>
            <SettingsProvider>
              <ThemeProvider>
                <DoctorDashboard />
              </ThemeProvider>
            </SettingsProvider>
          </AuthProvider>
        </LanguageProvider>
      </MemoryRouter>
    );
    await waitFor(() => expect(container.querySelector(".dash-shell")).toBeTruthy());
    await waitFor(() => expect(screen.queryByRole("status", { name: "" })).toBeNull(), { timeout: 4000 }).catch(() => {});
    await new Promise((r) => setTimeout(r, 600));
    const text = visibleText(container);
    // نام شفاخانه یک تنظیم سایت (داده) است، نه متن رابط
    const lines = text.split("\n").map((l) => l.trim()).filter((l) => l && l !== "شفاخانه افغان آریا");
    // انگلیسی: هیچ حرف عربی/فارسی نباید دیده شود. پشتو (هم‌خط دری): هیچ خطی نباید دقیقاً همان کلید دری ترجمه‌نشده باشد.
    const persianLines = lang === "en"
      ? lines.filter((l) => PERSIAN.test(l))
      : lines.filter((l) => Object.prototype.hasOwnProperty.call(enDict, l) && psDict[l] !== l);
    expect(persianLines).toEqual([]);
  });
});

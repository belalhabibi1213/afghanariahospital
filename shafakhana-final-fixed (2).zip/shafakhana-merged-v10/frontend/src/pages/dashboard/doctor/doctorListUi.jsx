// اجزای مشترک دو صفحه‌ی «نوبت‌های من» و «بیماران من» در داشبورد داکتر:
// هوک‌های فهرست سروری (کوئری + Debounce + دریافت با لغو درخواست قدیمی)، کارت آماری، فیلتر تاریخ،
// صفحه‌بندی ۲۰/۵۰/۱۰۰ و Drawer جزئیات. هیچ داده‌ای اینجا ساخته نمی‌شود؛ همه‌چیز از API واقعی می‌آید.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronLeft, ChevronRight, X } from "lucide-react";
import { apiRequest } from "../../../utils/api.js";
import { cx, toFa } from "./doctorWorkspaceUi.jsx";
import "./doctorListUi.css";

import { JalaliDateInput } from "../../../components/JalaliDateInput.jsx";
import { tr, trc, curDir, numLocale } from "../../../i18n/tr.js";
export const fmtNum = (n) => new Intl.NumberFormat(numLocale()).format(Number(n) || 0);

export const PAGE_SIZES = [20, 50, 100];

export function useDebouncedValue(value, delay = 350) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

export function buildQuery(params) {
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== "" && v !== null && v !== undefined) qs.set(k, String(v));
  });
  return qs.toString();
}

// وضعیت فیلترها/مرتب‌سازی/صفحه. جستجو Debounce می‌شود؛ بقیه‌ی فیلترها فوری اعمال می‌شوند.
// هر تغییر فیلتر، صفحه را به ۱ برمی‌گرداند.
export function useListQuery(defaults) {
  const [raw, setRaw] = useState(defaults);
  const debouncedQ = useDebouncedValue(raw.q);
  const query = useMemo(() => ({ ...raw, q: debouncedQ.trim() }), [raw, debouncedQ]);
  const typing = raw.q.trim() !== debouncedQ.trim();
  const set = useCallback((patch) => setRaw((r) => ({ ...r, ...patch, page: 1 })), []);
  const setPage = useCallback((page) => setRaw((r) => ({ ...r, page })), []);
  const reset = useCallback(() => setRaw(defaults), [defaults]);
  return { raw, query, typing, set, setPage, reset };
}

// دریافت یک صفحه از فهرست سروری. دیتای قبلی تا رسیدن پاسخ جدید نگه داشته می‌شود (بدون پرش جدول) و
// پاسخ درخواست‌های منسوخ (مثلاً هنگام تایپ سریع) نادیده گرفته می‌شود.
export function useFetchList(path, params) {
  const [state, setState] = useState({ data: null, loading: true, error: null });
  const [nonce, setNonce] = useState(0);
  const qs = buildQuery(params);
  useEffect(() => {
    let stale = false;
    setState((s) => ({ ...s, loading: true, error: null }));
    apiRequest(`${path}?${qs}`)
      .then((data) => { if (!stale) setState({ data, loading: false, error: null }); })
      .catch((error) => { if (!stale) setState((s) => ({ ...s, loading: false, error })); });
    return () => { stale = true; };
  }, [path, qs, nonce]);
  const reload = useCallback(() => setNonce((n) => n + 1), []);
  return { ...state, reload };
}

// دریافت یک رکورد (آمار یا جزئیات Drawer). key تغییر کند، دوباره دریافت می‌شود؛ key=null یعنی غیرفعال.
export function useFetchOne(path, key) {
  const [state, setState] = useState({ data: null, loading: false, error: null });
  const [nonce, setNonce] = useState(0);
  useEffect(() => {
    if (key === null || key === undefined) {
      setState({ data: null, loading: false, error: null });
      return undefined;
    }
    let stale = false;
    setState({ data: null, loading: true, error: null });
    apiRequest(path)
      .then((data) => { if (!stale) setState({ data, loading: false, error: null }); })
      .catch((error) => { if (!stale) setState({ data: null, loading: false, error }); });
    return () => { stale = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, nonce]);
  const reload = useCallback(() => setNonce((n) => n + 1), []);
  return { ...state, reload };
}

// ---------- کارت آماری ----------
// ترتیب DOM: متن، سپس آیکون؛ در RTL آیکون سمت چپ کارت قرار می‌گیرد (مثل طرح مرجع).
export function StatCard({ tone = "accent", icon, title, value, loading }) {
  return (
    <div className={cx("dl-stat", `dw-tone-${tone}`)}>
      <div className="dl-stat-text">
        <strong className="dl-stat-value">{loading && value == null ? <span className="dw-skel dl-stat-skel" aria-hidden="true" /> : fmtNum(value)}</strong>
        <span className="dl-stat-title">{title}</span>
      </div>
      <div className="dl-stat-icon" aria-hidden="true">{icon}</div>
    </div>
  );
}

// ---------- فیلتر تاریخ: همه / امروز / این هفته / این ماه / بازه دلخواه ----------
export const RANGE_OPTIONS = trc([
  { value: "", label: "همه تاریخ‌ها" },
  { value: "today", label: "امروز" },
  { value: "week", label: "این هفته" },
  { value: "month", label: "این ماه" },
  { value: "custom", label: "بازه دلخواه" },
]);

export function DateRangeFilter({ id, label, range, from, to, onChange }) {
  return (
    <>
      <div className="dw-field">
        <label htmlFor={id}>{label}</label>
        <select id={id} className="dw-select" value={range} onChange={(e) => onChange({ range: e.target.value, from: "", to: "" })}>
          {RANGE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
      </div>
      {range === "custom" && (
        <div className="dw-field dl-range-fields">
          <label htmlFor={`${id}-from`}>{tr("از تاریخ — تا تاریخ")}</label>
          <div className="dl-range-inputs">
            <JalaliDateInput id={`${id}-from`} className="dw-input" value={from} max={to || undefined} aria-label={tr("از تاریخ")} onChange={(e) => onChange({ from: e.target.value })} />
            <JalaliDateInput id={`${id}-to`} className="dw-input" value={to} min={from || undefined} aria-label={tr("تا تاریخ")} onChange={(e) => onChange({ to: e.target.value })} />
          </div>
        </div>
      )}
    </>
  );
}

// پارامتر کوئری فیلتر تاریخ: «بازه دلخواه» فقط from/to می‌فرستد، پیش‌تنظیم‌ها فقط range
export function rangeParams({ range, from, to }) {
  if (range === "custom") return { from, to };
  return { range };
}

// ---------- صفحه‌بندی ----------
function pageWindow(page, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const items = [1];
  const start = Math.max(2, page - 1);
  const end = Math.min(total - 1, page + 1);
  if (start > 2) items.push("…s");
  for (let i = start; i <= end; i += 1) items.push(i);
  if (end < total - 1) items.push("…e");
  items.push(total);
  return items;
}

export function ListPager({ pagination, limit, onPage, onLimit, loading, noun, sizes = PAGE_SIZES }) {
  if (!pagination) return null;
  const { total, page, totalPages } = pagination;
  const from = total === 0 ? 0 : (page - 1) * limit + 1;
  const to = Math.min(total, page * limit);
  return (
    <nav className="dl-pager" aria-label={tr("صفحه‌بندی {0}", [noun])}>
      <span className="dl-pager-info" aria-live="polite">
        {tr("نمایش {0} تا {1} از {2} {3}", [fmtNum(from), fmtNum(to), fmtNum(total), noun])}
      </span>
      <div className="dl-pager-pages">
        <button type="button" className="dl-page-btn" aria-label={tr("صفحه قبل")} disabled={page <= 1 || loading} onClick={() => onPage(page - 1)}>
          <ChevronRight size={16} aria-hidden="true" />
        </button>
        {pageWindow(page, totalPages).map((p) => (typeof p === "number" ? (
          <button
            key={p}
            type="button"
            className={cx("dl-page-btn", p === page && "is-current")}
            aria-label={tr("صفحه {0}", [toFa(p)])}
            aria-current={p === page ? "page" : undefined}
            disabled={loading}
            onClick={() => p !== page && onPage(p)}
          >
            {fmtNum(p)}
          </button>
        ) : <span key={p} className="dl-page-gap" aria-hidden="true">…</span>))}
        <button type="button" className="dl-page-btn" aria-label={tr("صفحه بعد")} disabled={page >= totalPages || loading} onClick={() => onPage(page + 1)}>
          <ChevronLeft size={16} aria-hidden="true" />
        </button>
      </div>
      <label className="dl-pager-size">
        <span>{tr("تعداد در صفحه")}</span>
        <select className="dw-select" value={limit} onChange={(e) => onLimit(Number(e.target.value))} aria-label={tr("تعداد رکورد در هر صفحه")}>
          {sizes.map((n) => <option key={n} value={n}>{fmtNum(n)}</option>)}
        </select>
      </label>
    </nav>
  );
}

// ---------- Drawer جزئیات (از سمت راست؛ در موبایل تمام‌عرض) ----------
// داخل Portal رندر می‌شود تا backdrop-filter کارت‌های شیشه‌ای، موقعیت fixed آن را خراب نکند.
export function DetailDrawer({ open, title, icon, onClose, children, footer }) {
  const closeRef = useRef(null);
  const titleId = useRef(`dl-drawer-${Math.random().toString(36).slice(2, 8)}`).current;

  useEffect(() => {
    if (!open) return undefined;
    const previouslyFocused = document.activeElement;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    document.addEventListener("keydown", onKey);
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    if (closeRef.current) closeRef.current.focus();
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
      if (previouslyFocused && typeof previouslyFocused.focus === "function") previouslyFocused.focus();
    };
  }, [open, onClose]);

  if (!open) return null;
  return createPortal(
    <div className="dw-scope dl-drawer-root" dir={curDir()}>
      <div className="dl-drawer-overlay" onClick={onClose} aria-hidden="true" />
      <aside className="dl-drawer" role="dialog" aria-modal="true" aria-labelledby={titleId}>
        <header className="dl-drawer-head">
          {icon && <span className="dl-drawer-icon" aria-hidden="true">{icon}</span>}
          <h3 id={titleId}>{title}</h3>
          <button ref={closeRef} type="button" className="dl-drawer-close" aria-label={tr("بستن")} onClick={onClose}><X size={18} aria-hidden="true" /></button>
        </header>
        <div className="dl-drawer-body">{children}</div>
        {footer && <footer className="dl-drawer-foot">{footer}</footer>}
      </aside>
    </div>,
    document.body
  );
}

export function DrawerRow({ icon, label, children }) {
  return (
    <div className="dl-row">
      <span className="dl-row-label">{icon}{label}</span>
      <span className="dl-row-value">{children == null || children === "" ? <span className="dw-none">—</span> : children}</span>
    </div>
  );
}

export function DrawerSkeleton() {
  return (
    <div className="dl-drawer-skel" aria-hidden="true">
      <div className="dw-skel" style={{ height: 64, borderRadius: 14 }} />
      {Array.from({ length: 7 }).map((_, i) => <div key={i} className="dw-skel" style={{ height: 18 }} />)}
    </div>
  );
}

// نوار خطای کوچک با دکمه‌ی تلاش مجدد (برای Drawer و بروزرسانی ناموفق فهرست)
export function InlineError({ message, onRetry }) {
  return (
    <div className="dl-inline-error" role="alert">
      <span>{message}</span>
      {onRetry && <button type="button" className="btn btn-ghost btn-sm" onClick={onRetry}>{tr("تلاش مجدد")}</button>}
    </div>
  );
}

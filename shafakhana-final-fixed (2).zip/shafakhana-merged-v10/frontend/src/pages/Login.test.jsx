import { describe, it, expect, vi, beforeEach } from "vitest";
import { screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Route } from "react-router-dom";
import Login from "./Login.jsx";
import { renderWithProviders, jsonResponse } from "../test/renderWithProviders.jsx";
import { USER_KEY } from "../utils/api.js";

let fetchMock;
beforeEach(() => {
  fetchMock = vi.fn();
  vi.stubGlobal("fetch", fetchMock);
});

function renderLogin(route = "/login") {
  return renderWithProviders(null, {
    route,
    routes: (
      <>
        <Route path="/login" element={<Login />} />
        <Route path="/verify-email" element={<div>صفحه تایید ایمیل</div>} />
        <Route path="/dashboard/doctor" element={<div>داشبورد داکتر</div>} />
        <Route path="/dashboard/user" element={<div>داشبورد بیمار</div>} />
        <Route path="/home" element={<div>خانه</div>} />
      </>
    ),
  });
}

const emailInput = () => screen.getByPlaceholderText("you@example.com");
const passInput = () => screen.getByPlaceholderText("••••••••");
const submit = () => userEvent.click(screen.getByRole("button", { name: "ورود" }));

describe("صفحه‌ی ورود", () => {
  it("فرم خالی: خطای فیلدها نمایش داده می‌شود و درخواستی به سرور نمی‌رود", async () => {
    renderLogin();
    await submit();
    expect(await screen.findByText("ایمیل الزامی است.")).toBeInTheDocument();
    expect(screen.getByText("رمز عبور الزامی است.")).toBeInTheDocument();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("ایمیل بدفرمت رد می‌شود", async () => {
    renderLogin();
    await userEvent.type(emailInput(), "not-an-email");
    await userEvent.type(passInput(), "whatever1");
    await submit();
    expect(await screen.findByText(/فرمت ایمیل معتبر نیست/)).toBeInTheDocument();
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("با تایپ در فیلد، خطای همان فیلد پاک می‌شود", async () => {
    renderLogin();
    await submit();
    await screen.findByText("ایمیل الزامی است.");
    await userEvent.type(emailInput(), "a");
    expect(screen.queryByText("ایمیل الزامی است.")).not.toBeInTheDocument();
  });

  it("رمز اشتباه: پیام سرور نمایش داده می‌شود و کاربر وارد نمی‌شود", async () => {
    fetchMock.mockResolvedValue(jsonResponse(401, { message: "ایمیل یا رمز عبور اشتباه است" }));
    renderLogin();
    await userEvent.type(emailInput(), "a@b.com");
    await userEvent.type(passInput(), "wrongpass1");
    await submit();
    expect(await screen.findByText("ایمیل یا رمز عبور اشتباه است")).toBeInTheDocument();
    expect(localStorage.getItem(USER_KEY)).toBeNull();
    expect(screen.getByTestId("location")).toHaveTextContent("/login");
    expect(screen.getByRole("button", { name: "ورود" })).toBeEnabled(); // دکمه بعد از خطا دوباره فعال می‌شود
  });

  it("ایمیل تاییدنشده → هدایت به صفحه‌ی تایید ایمیل", async () => {
    fetchMock.mockResolvedValue(jsonResponse(403, { code: "EMAIL_NOT_VERIFIED", email: "a@b.com", message: "ایمیل تایید نشده" }));
    renderLogin();
    await userEvent.type(emailInput(), "a@b.com");
    await userEvent.type(passInput(), "Password1");
    await submit();
    expect(await screen.findByText("صفحه تایید ایمیل")).toBeInTheDocument();
  });

  it("قطعی شبکه: پیام اتصال نمایش داده می‌شود", async () => {
    fetchMock.mockRejectedValue(new TypeError("Failed to fetch"));
    renderLogin();
    await userEvent.type(emailInput(), "a@b.com");
    await userEvent.type(passInput(), "Password1");
    await submit();
    expect(await screen.findByText(/اتصال به سرور برقرار نشد/)).toBeInTheDocument();
  });

  async function loginAs(user, route = "/login") {
    fetchMock.mockResolvedValue(jsonResponse(200, { user, csrfToken: "csrf-9" }));
    renderLogin(route);
    await userEvent.type(emailInput(), "x@b.com");
    await userEvent.type(passInput(), "Password1");
    await submit();
  }

  it("ورود موفق: بدنه‌ی درست ارسال می‌شود و پروفایل (بدون توکن) ذخیره می‌شود", async () => {
    const user = { id: 3, fullName: "داکتر ب", role: "doctor" };
    await loginAs(user);

    const [url, opts] = fetchMock.mock.calls[0];
    expect(url).toMatch(/\/auth\/login$/);
    expect(opts.method).toBe("POST");
    expect(opts.credentials).toBe("include");
    expect(JSON.parse(opts.body)).toEqual({ email: "x@b.com", password: "Password1" });

    expect(await screen.findByText(/ورود موفقیت‌آمیز بود/)).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(USER_KEY))).toEqual(user);
  });

  it("MFA: بعد از رمز درست فقط مرحله‌ی کد نمایش داده می‌شود و پروفایل ذخیره نمی‌شود", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(200, { mfaRequired: true, mfaToken: "tmp-token" }));
    renderLogin();
    await userEvent.type(emailInput(), "a@b.com");
    await userEvent.type(passInput(), "Password1");
    await submit();
    expect(await screen.findByPlaceholderText("کد ۶ رقمی یا کد بازیابی")).toBeInTheDocument();
    expect(localStorage.getItem(USER_KEY)).toBeNull();

    const user = { id: 3, fullName: "داکتر ب", role: "doctor" };
    fetchMock.mockResolvedValueOnce(jsonResponse(200, { user, csrfToken: "csrf-1" }));
    await userEvent.type(screen.getByPlaceholderText("کد ۶ رقمی یا کد بازیابی"), "123456");
    await userEvent.click(screen.getByRole("button", { name: "تایید و ورود" }));

    const [url, opts] = fetchMock.mock.calls[1];
    expect(url).toMatch(/\/auth\/mfa\/verify$/);
    expect(JSON.parse(opts.body)).toEqual({ mfaToken: "tmp-token", code: "123456" });
    expect(await screen.findByText(/ورود موفقیت‌آمیز بود/)).toBeInTheDocument();
    expect(JSON.parse(localStorage.getItem(USER_KEY))).toEqual(user);
  });

  it("MFA: کد اشتباه پیام سرور را نشان می‌دهد و ورود انجام نمی‌شود", async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse(200, { mfaRequired: true, mfaToken: "tmp-token" }));
    renderLogin();
    await userEvent.type(emailInput(), "a@b.com");
    await userEvent.type(passInput(), "Password1");
    await submit();
    fetchMock.mockResolvedValueOnce(jsonResponse(401, { message: "کد احراز هویت نامعتبر است", code: "MFA_INVALID" }));
    await userEvent.type(await screen.findByPlaceholderText("کد ۶ رقمی یا کد بازیابی"), "000000");
    await userEvent.click(screen.getByRole("button", { name: "تایید و ورود" }));
    expect(await screen.findByText("کد احراز هویت نامعتبر است")).toBeInTheDocument();
    expect(localStorage.getItem(USER_KEY)).toBeNull();
  });

  it("ورود بدون مقصد قبلی → صفحه‌ی خانه", async () => {
    await loginAs({ id: 3, fullName: "داکتر ب", role: "doctor" });
    await waitFor(() => expect(screen.getByText("خانه")).toBeInTheDocument(), { timeout: 3000 });
  });

  it("بازگشت به داشبورد خودِ کاربر که قبل از ورود می‌خواست ببیند", async () => {
    await loginAs(
      { id: 3, fullName: "داکتر ب", role: "doctor" },
      { pathname: "/login", state: { from: { pathname: "/dashboard/doctor" } } }
    );
    await waitFor(() => expect(screen.getByText("داشبورد داکتر")).toBeInTheDocument(), { timeout: 3000 });
  });

  it("مقصد قبلی داشبورد نقش دیگر بوده → به داشبورد درست خودش می‌رود (نه ۴۰۳)", async () => {
    await loginAs(
      { id: 4, fullName: "بیمار", role: "user" },
      { pathname: "/login", state: { from: { pathname: "/dashboard/admin" } } }
    );
    await waitFor(() => expect(screen.getByText("داشبورد بیمار")).toBeInTheDocument(), { timeout: 3000 });
  });

  it("پیام انقضای نشست فقط یک‌بار نمایش داده می‌شود", async () => {
    sessionStorage.setItem("shafakhana_session_expired", "1");
    renderLogin();
    expect(await screen.findByText(/نشست شما منقضی شده است/)).toBeInTheDocument();
    expect(sessionStorage.getItem("shafakhana_session_expired")).toBeNull();
  });
});

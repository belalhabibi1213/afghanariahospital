import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth, consumeSessionExpiredFlag, resolvePostLoginRedirect } from "../context/AuthContext.jsx";
import { API_BASE, authFetch } from "../utils/api.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import LanguageSwitcher from "../components/LanguageSwitcher.jsx";

const API_URL = `${API_BASE}/auth/login`;
const MFA_URL = `${API_BASE}/auth/mfa/verify`;
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const { t, tm } = useLanguage();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [fieldErrors, setFieldErrors] = useState({});
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);
  // مرحله‌ی دوم ورود (MFA): بعد از رمز درست، سرور فقط یک توکن کوتاه‌مدت می‌دهد
  const [mfaToken, setMfaToken] = useState(null);
  const [mfaCode, setMfaCode] = useState("");

  // اگر کاربر به‌خاطر منقضی/نامعتبر شدن توکن به این صفحه هدایت شده (چه در بارگذاری اولیه
  // پس از رفرش، چه حین کار با برنامه)، پیام مناسب را نمایش می‌دهیم.
  useEffect(() => {
    if (consumeSessionExpiredFlag()) {
      setStatus({ type: "error", text: t("login.sessionExpired") });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function completeLogin(data) {
    setStatus({ type: "success", text: t("login.success") });

    login(data.user, data.csrfToken);

    // بعد از ورود موفق، کاربر به صفحه اصلی سایت هدایت می‌شود (نه داشبورد)؛ اما اگر
    // کاربر از یک بخش خاص (مثلاً نوبت‌دهی) به اینجا هدایت شده بود (state.from — همان
    // الگوی ProtectedRoute/LoginRequiredModal)، به همان بخش بازمی‌گردد — به‌شرطی که
    // نقش همین کاربر واقعاً به آن مسیر دسترسی داشته باشد (وگرنه پیام «۴۰۳» می‌گرفت).
    const redirectTo = resolvePostLoginRedirect(location.state?.from, data.user);
    setTimeout(() => navigate(redirectTo, { replace: true }), 900);
  }

  async function handleMfaSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });
    if (!mfaCode.trim()) {
      setStatus({ type: "error", text: t("login.mfaRequired") });
      return;
    }
    setLoading(true);
    try {
      const res = await authFetch(MFA_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mfaToken, code: mfaCode.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (data.code === "MFA_TOKEN_EXPIRED") {
          setMfaToken(null);
          setPassword("");
        }
        setStatus({ type: "error", text: tm(data.message) || t("login.mfaInvalid") });
        return;
      }
      completeLogin(data);
    } catch {
      setStatus({ type: "error", text: t("common.serverUnreachableShort") });
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    const errs = {};
    if (!email.trim()) {
      errs.email = t("login.emailRequired");
    } else if (!EMAIL_REGEX.test(email.trim())) {
      errs.email = t("login.emailInvalid");
    }
    if (!password) errs.password = t("login.passwordRequired");

    setFieldErrors(errs);
    if (Object.keys(errs).length > 0) {
      setStatus({ type: "error", text: t("common.fixFormErrors") });
      return;
    }

    setLoading(true);
    try {
      const res = await authFetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();

      if (!res.ok) {
        if (data.code === "EMAIL_NOT_VERIFIED") {
          navigate("/verify-email", {
            state: { email: data.email || email, notice: data.message },
          });
          return;
        }
        setStatus({ type: "error", text: tm(data.message) || t("login.failed") });
        setLoading(false);
        return;
      }

      if (data.mfaRequired) {
        setMfaToken(data.mfaToken);
        setMfaCode("");
        setStatus({ type: "", text: "" });
        return;
      }

      completeLogin(data);
    } catch (err) {
      setStatus({
        type: "error",
        text: t("common.serverUnreachable"),
      });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-page pub-page">
      <Link to="/home" className="back-home">{t("common.backToSite")}</Link>
      <LanguageSwitcher className="lang-switcher-corner" />

      <div className="login-card pub-card">
        <div className="login-head">
          <div className="brand-mark" style={{ width: 46, height: 46, fontSize: 20, borderRadius: 14 }}>✚</div>
          <h1>{t("login.welcome")}</h1>
          <p>{t("login.subtitle")}</p>
        </div>

        {mfaToken ? (
          <form className="login-form" onSubmit={handleMfaSubmit} noValidate>
            {status.text && <div className={`form-message ${status.type}`}>{status.text}</div>}
            <div className="field">
              <label>{t("login.mfaLabel")}</label>
              <input
                type="text"
                inputMode="text"
                autoComplete="one-time-code"
                placeholder={t("login.mfaPlaceholder")}
                dir="ltr"
                autoFocus
                value={mfaCode}
                onChange={(e) => setMfaCode(e.target.value)}
              />
              <span className="field-hint">{t("login.mfaHint")}</span>
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? t("login.mfaChecking") : t("login.mfaSubmit")}
            </button>
            <button type="button" className="btn" onClick={() => { setMfaToken(null); setMfaCode(""); setStatus({ type: "", text: "" }); }}>
              {t("login.back")}
            </button>
          </form>
        ) : (
        <form className="login-form" onSubmit={handleSubmit} noValidate>
          {status.text && (
            <div className={`form-message ${status.type}`}>{status.text}</div>
          )}

          <div className="field">
            <label>{t("login.email")}</label>
            <input
              type="email"
              placeholder={t("login.emailPlaceholder")}
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (fieldErrors.email) setFieldErrors((f) => ({ ...f, email: "" }));
              }}
              autoComplete="email"
            />
            {fieldErrors.email && <span className="field-error">{fieldErrors.email}</span>}
          </div>

          <div className="field">
            <label>{t("login.password")}</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (fieldErrors.password) setFieldErrors((f) => ({ ...f, password: "" }));
              }}
              autoComplete="current-password"
            />
            {fieldErrors.password && <span className="field-error">{fieldErrors.password}</span>}
          </div>

          <div className="login-options">
            <label className="checkbox-row">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
              />
              {t("login.remember")}
            </label>
            <Link to="/forgot-password">{t("login.forgot")}</Link>
          </div>

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? t("login.submitting") : t("login.submit")}
          </button>
        </form>
        )}

        <p className="login-footer-text">
          {t("login.noAccount")} <Link to="/register">{t("login.registerLink")}</Link>
        </p>
      </div>
    </div>
  );
}

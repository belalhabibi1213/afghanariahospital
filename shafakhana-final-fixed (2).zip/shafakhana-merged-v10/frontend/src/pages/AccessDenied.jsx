import { Link } from "react-router-dom";
import { useAuth, DASHBOARD_PATH } from "../context/AuthContext.jsx";

export default function AccessDenied() {
  const { user } = useAuth();
  const homeLink = user ? DASHBOARD_PATH[user.role] || "/home" : "/home";

  return (
    <div className="login-page pub-page">
      <div className="login-card pub-card" style={{ textAlign: "center" }}>
        <div className="login-head">
          <div className="brand-mark" style={{ width: 46, height: 46, fontSize: 20, borderRadius: 14, background: "var(--warm)" }}>
            ⛔
          </div>
          <h1>۴۰۳ — دسترسی مسدود است</h1>
          <p>شما اجازه دسترسی به این صفحه را ندارید. این بخش فقط برای نقش‌های خاصی از کاربران در دسترس است.</p>
        </div>

        <Link to={homeLink} className="btn btn-primary" style={{ width: "100%", textAlign: "center", display: "block", marginTop: 12 }}>
          بازگشت به داشبورد
        </Link>
        <p className="login-footer-text">
          <Link to="/home">بازگشت به صفحه اصلی سایت</Link>
        </p>
      </div>
    </div>
  );
}

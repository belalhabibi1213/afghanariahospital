import { describe, it, expect, vi, beforeEach } from "vitest";
import { screen, waitFor, act } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { AuthProvider, useAuth, resolvePostLoginRedirect, consumeSessionExpiredFlag } from "./AuthContext.jsx";
import { render } from "@testing-library/react";
import { USER_KEY, LEGACY_TOKEN_KEY, SESSION_EXPIRED_EVENT } from "../utils/api.js";
import { jsonResponse } from "../test/renderWithProviders.jsx";

const doctor = { id: 7, fullName: "داکتر الف", role: "doctor" };

function Probe() {
  const { user, loading, login, logout, hasRole, isAuthenticated } = useAuth();
  return (
    <div>
      <span data-testid="loading">{String(loading)}</span>
      <span data-testid="auth">{String(isAuthenticated)}</span>
      <span data-testid="name">{user?.fullName ?? "-"}</span>
      <span data-testid="isDoctor">{String(hasRole("doctor"))}</span>
      <span data-testid="isAdminOrSuper">{String(hasRole("admin", "superadmin"))}</span>
      <button onClick={() => login(doctor, "csrf-1")}>login</button>
      <button onClick={() => logout()}>logout</button>
    </div>
  );
}

let fetchMock;
beforeEach(() => {
  fetchMock = vi.fn();
  vi.stubGlobal("fetch", fetchMock);
});

describe("resolvePostLoginRedirect", () => {
  const userRole = { role: "user" };
  it("بدون مقصد ذخیره‌شده → /home", () => {
    expect(resolvePostLoginRedirect(undefined, userRole)).toBe("/home");
    expect(resolvePostLoginRedirect({}, userRole)).toBe("/home");
  });
  it("داشبورد خودِ کاربر (با query و hash) حفظ می‌شود", () => {
    expect(resolvePostLoginRedirect({ pathname: "/dashboard/user/x", search: "?a=1", hash: "#h" }, userRole)).toBe("/dashboard/user/x?a=1#h");
  });
  it("داشبورد نقش دیگر به‌جای ۴۰۳ به داشبورد درست خودش هدایت می‌شود", () => {
    expect(resolvePostLoginRedirect({ pathname: "/dashboard/admin" }, userRole)).toBe("/dashboard/user");
    expect(resolvePostLoginRedirect({ pathname: "/dashboard/superadmin" }, { role: "admin" })).toBe("/dashboard/admin");
  });
  it("مسیر عمومی برای همه‌ی نقش‌ها حفظ می‌شود", () => {
    expect(resolvePostLoginRedirect({ pathname: "/news/5", search: "?x=1" }, userRole)).toBe("/news/5?x=1");
  });
  it("کاربر null و مقصد داشبورد → /home", () => {
    expect(resolvePostLoginRedirect({ pathname: "/dashboard/user" }, null)).toBe("/home");
  });
});

describe("consumeSessionExpiredFlag", () => {
  it("فقط یک‌بار مصرف می‌شود", () => {
    sessionStorage.setItem("shafakhana_session_expired", "1");
    expect(consumeSessionExpiredFlag()).toBe(true);
    expect(consumeSessionExpiredFlag()).toBe(false);
  });
});

describe("AuthProvider", () => {
  it("بدون نشانه‌ی ورود قبلی: درخواستی به سرور نمی‌فرستد و کاربر مهمان است", async () => {
    render(<AuthProvider><Probe /></AuthProvider>);
    await waitFor(() => expect(screen.getByTestId("loading")).toHaveTextContent("false"));
    expect(screen.getByTestId("auth")).toHaveTextContent("false");
    expect(fetchMock).not.toHaveBeenCalled();
  });

  it("login و logout: پروفایل در localStorage (بدون توکن) ذخیره و پاک می‌شود", async () => {
    fetchMock.mockResolvedValue(jsonResponse(200, { ok: true })); // POST /auth/logout
    render(<AuthProvider><Probe /></AuthProvider>);
    await waitFor(() => expect(screen.getByTestId("loading")).toHaveTextContent("false"));

    await userEvent.click(screen.getByText("login"));
    expect(screen.getByTestId("name")).toHaveTextContent("داکتر الف");
    expect(screen.getByTestId("isDoctor")).toHaveTextContent("true");
    expect(screen.getByTestId("isAdminOrSuper")).toHaveTextContent("false");
    const stored = JSON.parse(localStorage.getItem(USER_KEY));
    expect(stored.role).toBe("doctor");
    expect(JSON.stringify(stored)).not.toMatch(/token/i);

    await userEvent.click(screen.getByText("logout"));
    await waitFor(() => expect(screen.getByTestId("auth")).toHaveTextContent("false"));
    expect(localStorage.getItem(USER_KEY)).toBeNull();
  });

  it("logout حتی اگر سرور در دسترس نباشد، نشست محلی را پاک می‌کند", async () => {
    fetchMock.mockRejectedValue(new Error("network down"));
    localStorage.setItem(USER_KEY, JSON.stringify(doctor));
    fetchMock.mockResolvedValueOnce(jsonResponse(200, { user: doctor, csrfToken: "c" })); // restoreSession
    render(<AuthProvider><Probe /></AuthProvider>);
    await waitFor(() => expect(screen.getByTestId("auth")).toHaveTextContent("true"));
    await userEvent.click(screen.getByText("logout"));
    await waitFor(() => expect(screen.getByTestId("auth")).toHaveTextContent("false"));
    expect(localStorage.getItem(USER_KEY)).toBeNull();
  });

  it("بازیابی نشست: نقش را از سرور می‌گیرد (نه از داده‌ی محلی دست‌کاری‌شده)", async () => {
    localStorage.setItem(USER_KEY, JSON.stringify({ ...doctor, role: "superadmin" })); // دست‌کاری‌شده
    fetchMock.mockResolvedValue(jsonResponse(200, { user: doctor, csrfToken: "c" }));
    render(<AuthProvider><Probe /></AuthProvider>);
    await waitFor(() => expect(screen.getByTestId("loading")).toHaveTextContent("false"));
    expect(screen.getByTestId("isDoctor")).toHaveTextContent("true");
    expect(screen.getByTestId("isAdminOrSuper")).toHaveTextContent("false");
    expect(JSON.parse(localStorage.getItem(USER_KEY)).role).toBe("doctor");
  });

  it("انقضای نشست (۴۰۱ SESSION_EXPIRED): کاربر خارج و پرچم پیام انقضا ثبت می‌شود", async () => {
    localStorage.setItem(USER_KEY, JSON.stringify(doctor));
    fetchMock.mockResolvedValue(jsonResponse(401, { code: "SESSION_EXPIRED", message: "x" }));
    render(<AuthProvider><Probe /></AuthProvider>);
    await waitFor(() => expect(screen.getByTestId("loading")).toHaveTextContent("false"));
    expect(screen.getByTestId("auth")).toHaveTextContent("false");
    expect(localStorage.getItem(USER_KEY)).toBeNull();
    expect(consumeSessionExpiredFlag()).toBe(true);
  });

  it("قطعی موقت شبکه کاربر واردشده را بیرون نمی‌اندازد", async () => {
    localStorage.setItem(USER_KEY, JSON.stringify(doctor));
    fetchMock.mockRejectedValue(new TypeError("Failed to fetch"));
    render(<AuthProvider><Probe /></AuthProvider>);
    await waitFor(() => expect(screen.getByTestId("loading")).toHaveTextContent("false"));
    expect(screen.getByTestId("auth")).toHaveTextContent("true");
  });

  it("رویداد سراسری انقضای نشست (از لایه‌ی API) کاربر را خارج می‌کند", async () => {
    render(<AuthProvider><Probe /></AuthProvider>);
    await waitFor(() => expect(screen.getByTestId("loading")).toHaveTextContent("false"));
    await userEvent.click(screen.getByText("login"));
    expect(screen.getByTestId("auth")).toHaveTextContent("true");
    act(() => { window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT)); });
    expect(screen.getByTestId("auth")).toHaveTextContent("false");
    expect(consumeSessionExpiredFlag()).toBe(true);
  });

  it("توکن قدیمی JWT در localStorage هنگام بارگذاری پاک می‌شود", async () => {
    localStorage.setItem(LEGACY_TOKEN_KEY, "old.jwt.token");
    vi.resetModules();
    await import("./AuthContext.jsx");
    expect(localStorage.getItem(LEGACY_TOKEN_KEY)).toBeNull();
  });
});

import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { apiRequest } from "../utils/api.js";

const SettingsContext = createContext(null);

// مقادیر پیش‌فرض دقیقاً همان متن‌هایی هستند که قبلاً به‌صورت ثابت (hardcoded) در
// کامپوننت‌های مختلف نوشته شده بودند — تا پیش از رسیدن پاسخ API هیچ چیز خالی/پرش‌دار
// دیده نشود، و اگر سرور در دسترس نبود سایت همچنان محتوای معقول نشان دهد.
const DEFAULT_SETTINGS = {
  hospitalName: "شفاخانه افغان آریا",
  hospitalPhone: "۰۷۰۰ ۱۱ ۲۲ ۳۳",
  hospitalEmail: "info@shafakhana.af",
  hospitalAddress: "هرات، شهر هرات، جاده مرکزی",
  hospitalDescription: "",
  logoUrl: "",
  maintenanceMode: "off",
  defaultLanguage: "fa",
  theme: "light",
};

// این Provider تنظیمات «قابل‌نمایش عمومی» (GET /api/settings/public) را یک‌بار در
// بارگذاری اولیه‌ی برنامه می‌خواند تا هر جای سایت (هدر، فوتر، تماس با ما، فاکتور/نسخه،
// حالت تعمیرات) همیشه با آخرین مقداری که Super Admin در «تنظیمات سیستم» ذخیره کرده
// هم‌خوان باشد؛ به‌جای اینکه هر کامپوننت متن ثابت خودش را نمایش دهد.
export function SettingsProvider({ children }) {
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);

  function load() {
    return apiRequest("/settings/public")
      .then((data) => {
        if (data && data.settings) {
          setSettings((prev) => ({ ...prev, ...data.settings }));
        }
      })
      .catch(() => {
        // سرور در دسترس نبود؛ مقادیر پیش‌فرض بالا همچنان نمایش داده می‌شوند
      });
  }

  useEffect(() => {
    setLoading(true);
    load().finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // refreshSettings: بعد از این‌که Super Admin در «تنظیمات سیستم» چیزی را ذخیره می‌کند
  // (لوگو، نام شفاخانه، تلفن و ...)، این تابع دوباره از سرور می‌خواند تا هدر/فوتر/بقیه‌ی
  // سایت هم بلافاصله به‌روز شوند؛ قبلاً تنظیمات فقط یک‌بار در بارگذاری اولیه‌ی برنامه
  // خوانده می‌شد و تا رفرش کامل صفحه، مقدار قدیمی در همه‌جای سایت باقی می‌ماند.
  const value = useMemo(() => ({ settings, loading, refreshSettings: load }), [settings, loading]);

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSiteSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSiteSettings باید داخل SettingsProvider استفاده شود");
  return ctx;
}

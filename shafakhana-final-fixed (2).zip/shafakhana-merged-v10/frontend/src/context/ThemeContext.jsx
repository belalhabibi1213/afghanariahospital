import { createContext, useContext, useEffect, useState } from "react";
import { useAuth } from "./AuthContext.jsx";
import { apiRequest } from "../utils/api.js";
import { useSiteSettings } from "./SettingsContext.jsx";

const ThemeContext = createContext(null);

// ترجیح تم مهمان (کاربر واردنشده) تا زمان ورود، محلی نگه‌داری می‌شود
const GUEST_THEME_KEY = "shafakhana_theme";

// پالت رنگی (فیروزه‌ای، اقیانوسی، بنفش، ...) مستقل از حالت روشن/تاریک است. برای مهمان
// در localStorage نگه‌داری می‌شود؛ برای کاربر واردشده در دیتابیس (users.palettePreference)
// هم ذخیره می‌شود تا از هر دستگاهی بعد از ورود همان رنگ‌بندی بازیابی شود.
const PALETTE_KEY = "shafakhana_palette";
export const PALETTES = [
  { id: "teal", color: "#2fe6c9", color2: "#1fb7a0" },
  { id: "ocean", color: "#4cc3ff", color2: "#2b8cf0" },
  { id: "violet", color: "#b79bff", color2: "#7b5cf0" },
  { id: "rose", color: "#ff7a9c", color2: "#e0446f" },
  { id: "emerald", color: "#5ee08a", color2: "#2fb862" },
  { id: "sunset", color: "#ffb347", color2: "#f08a1c" },
  { id: "indigo", color: "#8c9bff", color2: "#5b6cf0" },
  { id: "coral", color: "#ff9a7a", color2: "#f0663f" },
  { id: "gold", color: "#f2cc66", color2: "#d9a928" },
  { id: "orchid", color: "#f08cf0", color2: "#c24fd9" },
  { id: "lime", color: "#b8e65c", color2: "#8fc42a" },
  { id: "slate", color: "#9fb6cc", color2: "#6f8cab" },
];
const DEFAULT_PALETTE = "teal";

function readPalette() {
  try {
    const v = localStorage.getItem(PALETTE_KEY);
    return PALETTES.some((p) => p.id === v) ? v : DEFAULT_PALETTE;
  } catch {
    return DEFAULT_PALETTE;
  }
}

// تم پیش‌فرض سایت (تنظیمات سیستم ← ظاهر و زبان): dark | light | auto (auto = تنظیم سیستم‌عامل)
function resolveSiteTheme(value) {
  if (value === "dark" || value === "light") return value;
  if (value === "auto" && typeof window !== "undefined" && window.matchMedia) {
    return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  return "light";
}

// انتخاب خود مهمان اولویت دارد؛ اگر هنوز چیزی انتخاب نکرده، تم پیش‌فرض سایت
function readGuestTheme(fallback = "light") {
  try {
    const saved = localStorage.getItem(GUEST_THEME_KEY);
    if (saved === "dark" || saved === "light") return saved;
  } catch {
    // localStorage در دسترس نیست
  }
  return fallback;
}

export function ThemeProvider({ children }) {
  const { user, updateUser } = useAuth();
  const { settings } = useSiteSettings();
  const siteTheme = resolveSiteTheme(settings.theme);

  // AuthProvider نشست کاربر واردشده را (در صورت وجود) به‌صورت همزمان از localStorage
  // در همان رندر اول بازیابی می‌کند؛ پس user.themePreference از همین ابتدا در دسترس
  // است و نیازی به صبر برای پاسخ سرور یا نمایش موقت تم مهمان نیست.
  const [theme, setThemeState] = useState(() =>
    user ? (user.themePreference === "dark" ? "dark" : "light") : readGuestTheme(siteTheme)
  );

  const [palette, setPaletteState] = useState(() =>
    user?.palettePreference && PALETTES.some((p) => p.id === user.palettePreference)
      ? user.palettePreference
      : readPalette()
  );

  // با ورود/بازیابی نشست، پالت ذخیره‌شده‌ی کاربر در دیتابیس منبع اصلی است
  const userPalette = user?.palettePreference;
  useEffect(() => {
    if (userPalette && PALETTES.some((p) => p.id === userPalette)) {
      setPaletteState(userPalette);
      try {
        localStorage.setItem(PALETTE_KEY, userPalette);
      } catch {
        // ignore
      }
    }
  }, [userPalette]);

  // اعمال پالت رنگی روی <html> — پالت پیش‌فرض (teal) همان توکن‌های tokens.css است
  useEffect(() => {
    const root = document.documentElement;
    if (palette === DEFAULT_PALETTE) root.removeAttribute("data-palette");
    else root.setAttribute("data-palette", palette);
  }, [palette]);

  function setPalette(next) {
    const value = PALETTES.some((p) => p.id === next) ? next : DEFAULT_PALETTE;
    setPaletteState(value);
    try {
      localStorage.setItem(PALETTE_KEY, value);
    } catch {
      // حالت خصوصی مرورگر: پالت فقط برای همین صفحه اعمال می‌شود
    }
    if (user) {
      updateUser({ palettePreference: value });
      apiRequest("/users/theme", { method: "PUT", body: { palette: value } }).catch(() => {});
    }
  }

  // اعمال تم روی <html> — چون تقریباً همه‌ی رنگ‌های سایت (index.css) از طریق
  // متغیرهای CSS تعریف‌شده زیر [data-theme="light"] خوانده می‌شوند، همین یک خط
  // کل رابط کاربری را فوراً (بدون رفرش صفحه) روشن/تاریک می‌کند.
  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);

  // با تغییر وضعیت ورود (ورود موفق، بازیابی نشست از سرور، یا خروج) تم با منبع
  // درست هماهنگ می‌شود: برای کاربر واردشده، ترجیح ذخیره‌شده در دیتابیس همیشه
  // منبع اصلی است؛ بعد از خروج، به آخرین ترجیح محلیِ مهمان بازمی‌گردد.
  // نکته‌ی مهم (رفع باگ): وابستگی افکت فقط «شناسه‌ی کاربر» و «ترجیح تم» است، نه کل شیء
  // user. قبلاً با هر updateUser (مثلاً ذخیره‌ی پروفایل یا عوض‌کردن عکس) شیء user تازه
  // ساخته می‌شد و افکت تم را به themePreference قدیمیِ داخل user برمی‌گرداند؛ یعنی بعد از
  // تغییر پروفایل، تم (مثلاً تاریک) خودبه‌خود به حالت قبلی (روشن) برمی‌گشت.
  const userId = user?.id ?? null;
  const userPref = user?.themePreference;
  useEffect(() => {
    if (userId !== null) {
      setThemeState(userPref === "dark" ? "dark" : "light");
    } else {
      setThemeState(readGuestTheme(siteTheme));
    }
  }, [userId, userPref, siteTheme]);

  function setTheme(next) {
    const value = next === "dark" ? "dark" : "light";
    setThemeState(value);
    try {
      localStorage.setItem(GUEST_THEME_KEY, value);
    } catch {
      // ذخیره‌سازی محلی در دسترس نیست (مثلاً حالت خصوصی مرورگر)؛ تم همچنان در
      // همین صفحه اعمال شده، فقط بین بازدیدها به خاطر سپرده نمی‌شود
    }
    if (user) {
      // ترجیح جدید در نشست محلی هم ثبت می‌شود تا با themePreference داخل user هم‌خوان بماند
      updateUser({ themePreference: value });
      // برای کاربر واردشده، ترجیح در دیتابیس هم ذخیره می‌شود تا بعد از خروج و
      // ورود دوباره (حتی از دستگاه دیگر) بازیابی شود. اگر درخواست ناموفق باشد،
      // تجربه‌ی کاربر مختل نمی‌شود چون تم همین حالا در صفحه اعمال شده است.
      apiRequest("/users/theme", { method: "PUT", body: { theme: value } }).catch(() => {});
    }
  }

  function toggleTheme() {
    setTheme(theme === "dark" ? "light" : "dark");
  }

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme, palette, setPalette, palettes: PALETTES }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme باید داخل ThemeProvider استفاده شود");
  return ctx;
}

import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { apiRequest, hasSessionHint, setCsrfToken, SESSION_EXPIRED_EVENT, USER_KEY, LEGACY_TOKEN_KEY } from "../utils/api.js";

const AuthContext = createContext(null);

// نشست در کوکی httpOnly است؛ در localStorage فقط پروفایل عمومی کاربر می‌ماند (نه توکن).
// اگر از نسخه‌ی قبلی توکنی در localStorage مانده باشد همین‌جا پاک می‌شود.
try {
  localStorage.removeItem(LEGACY_TOKEN_KEY);
} catch {
  // دسترسی به localStorage ممکن نیست؛ مهم نیست
}
// این پرچم موقت در sessionStorage نگه‌داری می‌شود (نه در state رم) چون بعد از
// پاک‌شدن نشست، کاربر به مسیر /login هدایت می‌شود و آن صفحه باید بتواند بعد از
// mount شدنِ خودش (حتی بعد از یک رفرش کامل) بفهمد که علت هدایت، انقضای نشست بوده.
const SESSION_EXPIRED_FLAG = "shafakhana_session_expired";

// مسیر داشبورد هر نقش
export const DASHBOARD_PATH = {
  user: "/dashboard/user",
  doctor: "/dashboard/doctor",
  admin: "/dashboard/admin",
  superadmin: "/dashboard/superadmin",
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    try {
      const raw = localStorage.getItem(USER_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [loading, setLoading] = useState(true);

  // در بارگذاری اولیه، اگر نشانه‌ای از ورود قبلی هست نشست (کوکی httpOnly) را با سرور تایید می‌کنیم
  // (این کار مطمئن می‌شود نقش کاربر همیشه با دیتابیس هم‌خوان است، نه فقط داده‌ی محلی)
  // و توکن CSRF این نشست را هم می‌گیرد؛ چون توکن CSRF فقط در حافظه است، بعد از هر رفرش لازم است.
  useEffect(() => {
    async function restoreSession() {
      if (!hasSessionHint()) {
        setLoading(false);
        return;
      }
      try {
        const data = await apiRequest("/auth/me");
        setCsrfToken(data.csrfToken);
        setUser(data.user);
        localStorage.setItem(USER_KEY, JSON.stringify(data.user));
      } catch (err) {
        // فقط وقتی سرور صراحتاً نشست را رد کرده نشست محلی پاک می‌شود؛ قطعی موقت شبکه
        // کاربر واردشده را بیرون نمی‌اندازد (کوکی هنوز معتبر است و درخواست بعدی کار می‌کند)
        if (err && (err.status === 401 || err.status === 403)) {
          localStorage.removeItem(USER_KEY);
          setCsrfToken(null);
          setUser(null);
          if (err.code === "SESSION_EXPIRED") {
            sessionStorage.setItem(SESSION_EXPIRED_FLAG, "1");
          }
        }
      } finally {
        setLoading(false);
      }
    }
    restoreSession();

    // اگر کاربر در حال کار با برنامه بود (نه فقط در بارگذاری اولیه) و در همان لحظه
    // توکنش منقضی/نامعتبر شد، utils/api.js این رویداد سراسری را پخش می‌کند تا
    // نشست فوراً و به‌صورت امن از بین برود و کاربر به صفحه‌ی ورود هدایت شود.
    function onSessionExpired() {
      setUser(null);
      sessionStorage.setItem(SESSION_EXPIRED_FLAG, "1");
    }
    window.addEventListener(SESSION_EXPIRED_EVENT, onSessionExpired);
    return () => window.removeEventListener(SESSION_EXPIRED_EVENT, onSessionExpired);
  }, []);

  // بعد از ورود موفق: توکن JWT در کوکی httpOnly (تنظیم‌شده توسط سرور) است و جاوااسکریپت آن را
  // نمی‌بیند؛ فقط پروفایل عمومی و توکن CSRF همین نشست (از پاسخ ورود) نگه‌داری می‌شود.
  function login(userData, csrfToken) {
    setCsrfToken(csrfToken);
    localStorage.setItem(USER_KEY, JSON.stringify(userData));
    setUser(userData);
  }

  // برای وقتی که یک صفحه (مثل تغییر رمز عبور اجباری) فقط بخشی از کاربر واردشده را
  // به‌روزرسانی می‌کند و نیازی به ورود دوباره یا دریافت توکن تازه نیست
  function updateUser(partial) {
    setUser((prev) => {
      if (!prev) return prev;
      const next = { ...prev, ...partial };
      localStorage.setItem(USER_KEY, JSON.stringify(next));
      return next;
    });
  }

  async function logout() {
    // ابتدا خروج را در سرور لاگ می‌کنیم (تا زمانی که توکن هنوز معتبر است)،
    // سپس صرف‌نظر از نتیجه، نشست محلی کاربر پاک می‌شود
    // (همین درخواست کوکی نشست را هم در سرور پاک می‌کند)
    try {
      await apiRequest("/auth/logout", { method: "POST" });
    } catch (err) {
      // اگر اتصال قطع بود، همچنان خروج محلی انجام می‌شود
    }
    localStorage.removeItem(USER_KEY);
    setCsrfToken(null);
    setUser(null);
  }

  function hasRole(...roles) {
    return !!user && roles.includes(user.role);
  }

  const value = useMemo(
    () => ({ user, loading, login, logout, updateUser, hasRole, isAuthenticated: !!user }),
    [user, loading]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// محاسبه‌ی مقصد بازگشت بعد از ورود/تایید ایمیل موفق. اگر کاربر پیش از این (بدون ورود)
// سعی کرده بود مستقیم وارد یک داشبورد بشود که به آن دسترسی نداشت، ProtectedRoute.jsx مسیر
// مقصد را در state.from ذخیره می‌کند تا بعد از ورود به همان‌جا برگردد. اما اگر کورکورانه به
// همان from برگردیم و نقشِ کاربریِ واقعاً واردشده با آن داشبورد نخواند (مثلاً from روی
// /dashboard/admin مانده ولی کاربر با نقش «user» وارد شده)، بلافاصله توسط ProtectedRoute به
// صفحه‌ی ۴۰۳ پرت می‌شود. این تابع قبل از بازگشت، مطابقت نقش را بررسی می‌کند تا این اتفاق نیفتد.
export function resolvePostLoginRedirect(from, user) {
  const fallback = "/home";
  if (!from || !from.pathname) return fallback;

  const suffix = `${from.search || ""}${from.hash || ""}`;

  // مسیرهای داشبورد هرکدام مخصوص فقط یک نقش هستند؛ فقط اگر مقصد ذخیره‌شده همان
  // داشبورد خودِ کاربر است اجازه‌ی بازگشت به آن داده می‌شود، وگرنه مستقیم به
  // داشبورد درست خودش هدایت می‌شود (به‌جای رسیدن به صفحه‌ی «دسترسی مسدود است»).
  if (from.pathname.startsWith("/dashboard")) {
    const ownDashboard = user ? DASHBOARD_PATH[user.role] : null;
    if (ownDashboard && from.pathname.startsWith(ownDashboard)) {
      return `${from.pathname}${suffix}`;
    }
    return ownDashboard || fallback;
  }

  // مسیرهای عمومی (مثل صفحه اصلی با state.from از LoginRequiredModal برای نوبت‌دهی)
  // برای همه‌ی نقش‌ها بی‌خطرند و همیشه قابل بازگشت‌اند.
  return `${from.pathname}${suffix}`;
}

// صفحه‌ی ورود این را در mount خودش فراخوانی می‌کند تا اگر کاربر به‌خاطر انقضای
// نشست به اینجا هدایت شده، پیام مناسب را نشان دهد. پرچم فقط یک‌بار مصرف می‌شود.
export function consumeSessionExpiredFlag() {
  const wasExpired = sessionStorage.getItem(SESSION_EXPIRED_FLAG) === "1";
  if (wasExpired) sessionStorage.removeItem(SESSION_EXPIRED_FLAG);
  return wasExpired;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth باید داخل AuthProvider استفاده شود");
  return ctx;
}

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { DICTIONARIES, loadLocale } from "../i18n/locales/registry.js";
import { loadTrDict } from "../i18n/tr.js";
import {
  LANGUAGES,
  LANG_STORAGE_KEY,
  getLanguageMeta,
  isSupportedLang,
  readStoredLang,
  setCurrentLang,
} from "../i18n/languages.js";
import { formatDateLocalized, localizeDigits } from "../i18n/dates.js";
import { translateServerMessage } from "../i18n/serverMessages.js";
import { translateDepartmentName, setAdminDepartmentNames } from "../i18n/departmentNames.js";
import { translateWorkDays, translateDoctorName } from "../i18n/dataTranslate.js";
import { API_BASE } from "../utils/api.js";

// ساخت مقدار context برای یک زبان — هم در Provider و هم برای مقدار پیش‌فرض (بدون Provider) استفاده می‌شود
function buildValue(lang, setLang) {
  const meta = getLanguageMeta(lang);
  return {
    lang,
    setLang,
    dir: meta.dir,
    isRtl: meta.dir === "rtl",
    locale: meta.numberLocale,
    languages: LANGUAGES,
    // t("hero.lead", { hospital }) — اگر کلید در زبان فعلی نبود، از دری و در نهایت خود کلید
    t: (key, params) => translate(lang, key, params),
    // tm(data.message) — ترجمه‌ی پیام‌های ثابت سرور؛ پیام ناشناخته بدون تغییر برمی‌گردد
    tm: (message) => translateServerMessage(message, lang),
    // dept(d.department) — نمایش نام بخش (ذخیره‌شده به دری) در زبان فعلی؛ نام ناشناخته بدون تغییر
    dept: (name) => translateDepartmentName(name, lang),
    // days(d.workDays) — روزهای کاری داکتر (ذخیره‌شده به دری) در زبان فعلی؛ ناشناخته بدون تغییر
    days: (text) => translateWorkDays(text, lang),
    // docName(d.fullName) — نام داکتر در انگلیسی (فقط نام‌های شناخته‌شده)؛ در غیر این صورت بدون تغییر
    docName: (name) => translateDoctorName(name, lang),
    // loc(article, "title") — مقدار انگلیسی (فیلد titleEn) اگر زبان انگلیسی است و پر شده؛ وگرنه متن دری
    loc: (obj, field) => {
      if (!obj) return "";
      const en = lang === "en" ? obj[`${field}En`] : null;
      return typeof en === "string" && en.trim() ? en : obj[field];
    },
    // ارقام (۱۲۳ یا 123) و تاریخ بر اساس زبان
    digits: (v) => localizeDigits(v, lang),
    formatNumber: (n) => Number(n).toLocaleString(meta.numberLocale),
    formatDate: (v, opts) => formatDateLocalized(v, lang, opts),
  };
}

// بدون LanguageProvider (مثلاً در تست‌های واحدِ قدیمی) به‌جای خطا، زبان پیش‌فرض (دری) برمی‌گردد
const LanguageContext = createContext(null);

// کلید «a.b.c» را در دیکشنری نقطه‌به‌نقطه پیدا می‌کند
function resolveKey(dict, key) {
  let node = dict;
  for (const part of key.split(".")) {
    if (node === null || node === undefined || typeof node !== "object") return undefined;
    node = node[part];
  }
  return node;
}

function interpolate(text, params) {
  if (!params || typeof text !== "string") return text;
  return text.replace(/\{(\w+)\}/g, (match, name) => (params[name] !== undefined ? String(params[name]) : match));
}

// ترجمه خارج از React (مثلاً در توابع کمکی): translate("en", "common.loading")
export function translate(lang, key, params) {
  const value = resolveKey(DICTIONARIES[lang], key) ?? resolveKey(DICTIONARIES.fa, key);
  if (value === undefined) return key;
  return typeof value === "string" ? interpolate(value, params) : value;
}

export function LanguageProvider({ children }) {
  const [lang, setLangState] = useState(readStoredLang);
  // همگام‌سازی زبان فعلی ماژولی (برای tr) هم‌زمان با رندر؛ عملیات تکراری و بی‌خطر است
  setCurrentLang(lang);
  const meta = getLanguageMeta(lang);

  // اعمال زبان و جهت روی <html> — همان کاری که ThemeContext با data-theme می‌کند. چون
  // استایل‌های سایت عمدتاً با ویژگی‌های منطقی (margin-inline و ...) نوشته شده‌اند، همین
  // تغییر dir کل چیدمان را برای انگلیسی چپ‌به‌راست می‌کند.
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute("lang", lang);
    root.setAttribute("dir", meta.dir);
    root.setAttribute("data-lang", lang);
    document.title = translate(lang, "meta.title");
    setCurrentLang(lang);
  }, [lang, meta.dir]);

  const setLang = useCallback((next) => {
    if (!isSupportedLang(next)) return;
    try {
      localStorage.setItem(LANG_STORAGE_KEY, next);
    } catch {
      // ذخیره‌سازی محلی در دسترس نیست؛ زبان در همین صفحه اعمال می‌شود ولی بین بازدیدها حفظ نمی‌شود
    }
    // ابتدا دیکشنری زبان جدید (در صورت نیاز) دانلود می‌شود، بعد زبان اعمال می‌شود تا هیچ لحظه‌ای متن دری/کلید خام دیده نشود.
    // همگام و قبل از رندر: متن‌های داشبورد (tr) زبان فعلی را از همین ماژول می‌خوانند
    Promise.all([loadLocale(next), loadTrDict(next)])
      .catch(() => {}) // شکست شبکه: به متن دری برمی‌گردد (translate/tr fallback)
      .then(() => {
        setCurrentLang(next);
        setLangState(next);
      });
  }, []);

  // نام‌های انگلیسی بخش‌ها که ادمین ثبت کرده (departments.nameEn) فقط وقتی زبان انگلیسی است یک‌بار
  // گرفته می‌شوند؛ شکست شبکه بی‌صدا نادیده گرفته می‌شود (نگاشت ثابت/متن دری جایگزین است).
  const [deptNamesVersion, setDeptNamesVersion] = useState(0);
  useEffect(() => {
    if (lang !== "en" || typeof fetch !== "function") return undefined;
    let cancelled = false;
    fetch(`${API_BASE}/departments?public=1`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (cancelled || !data) return;
        setAdminDepartmentNames(data.departments);
        setDeptNamesVersion((v) => v + 1);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [lang]);

  // زبان پیش‌فرض سایت (تنظیمات سیستم ← ظاهر و زبان) فقط برای بازدیدکننده‌ای که خودش هنوز زبانی
  // انتخاب نکرده اعمال می‌شود و در localStorage ذخیره نمی‌شود (تا با تغییر تنظیمات، دوباره اعمال شود)
  const setDefaultLang = useCallback((code) => {
    if (!isSupportedLang(code)) return;
    try {
      if (localStorage.getItem(LANG_STORAGE_KEY)) return;
    } catch {
      // localStorage در دسترس نیست؛ زبان پیش‌فرض اعمال می‌شود
    }
    Promise.all([loadLocale(code), loadTrDict(code)])
      .catch(() => {})
      .then(() => {
        setCurrentLang(code);
        setLangState(code);
      });
  }, []);

  // deptNamesVersion عمداً وابستگی است تا بعد از رسیدن نام‌های انگلیسی، مصرف‌کننده‌ها دوباره رندر شوند
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const value = useMemo(() => ({ ...buildValue(lang, setLang), setDefaultLang }), [lang, setLang, setDefaultLang, deptNamesVersion]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

const FALLBACK_VALUE = buildValue("fa", () => {});

export function useLanguage() {
  return useContext(LanguageContext) || FALLBACK_VALUE;
}

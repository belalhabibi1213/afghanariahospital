import { useCallback, useEffect, useRef, useState } from "react";

import { tr } from "../i18n/tr.js";
// ---------- هوک ضبط پیام صوتی چت (بیمار ↔ داکتر) ----------
// این هوک فقط منطق ضبط (دسترسی به میکروفون، MediaRecorder، تایمر) را نگه می‌دارد؛
// رابط کاربری (دکمه‌ی میکروفون/نوار ضبط) در VoiceRecorderBar.jsx است. هم در
// ChatWithDoctor.jsx و هم ChatWithPatients.jsx استفاده می‌شود.

// باید با محدودیتِ سمت بک‌اند هماهنگ بماند: sendVoiceMessageValidation (فرم فرانت‌اند)
// و بررسی duration در chatController.js (sendVoiceMessage)
export const MAX_VOICE_DURATION_SECONDS = 300; // ۵ دقیقه

// فرمت‌های خروجیِ ضبط که مرورگر ممکن است پشتیبانی کند، به ترتیب اولویت — باید با
// ALLOWED_VOICE_MIME_TO_EXT در backend/middleware/upload.js هماهنگ باشد
const CANDIDATE_MIME_TYPES = [
  "audio/webm;codecs=opus",
  "audio/webm",
  "audio/mp4",
  "audio/ogg;codecs=opus",
  "audio/ogg",
];

function pickSupportedMimeType() {
  if (typeof window === "undefined" || typeof window.MediaRecorder === "undefined") return "";
  if (typeof window.MediaRecorder.isTypeSupported !== "function") return "";
  return CANDIDATE_MIME_TYPES.find((type) => window.MediaRecorder.isTypeSupported(type)) || "";
}

// پسوند فایل مناسب برای یک mimetype ضبط‌شده — فقط برای نام‌گذاری نمایشیِ فایل هنگام
// آپلود؛ نوع واقعی از روی مقدار Blob.type در بک‌اند بررسی می‌شود، نه این پسوند
export function voiceFileExtension(mimeType) {
  const type = (mimeType || "").toLowerCase();
  if (type.includes("webm")) return "webm";
  if (type.includes("mp4")) return "m4a";
  if (type.includes("ogg")) return "ogg";
  if (type.includes("wav")) return "wav";
  return "webm";
}

export default function useVoiceRecorder() {
  const supported =
    typeof navigator !== "undefined" &&
    !!navigator.mediaDevices &&
    typeof navigator.mediaDevices.getUserMedia === "function" &&
    typeof window !== "undefined" &&
    typeof window.MediaRecorder !== "undefined";

  const [isRecording, setIsRecording] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);

  const mediaRecorderRef = useRef(null);
  const streamRef = useRef(null);
  const chunksRef = useRef([]);
  const startTimeRef = useRef(0);
  const timerRef = useRef(null);
  const autoStopRef = useRef(null); // callback موقتی برای وقتی سقف مدت‌زمان می‌رسد

  const releaseStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  }, []);

  // اگر کاربر از صفحه خارج شود در حین ضبط، میکروفون باید بلافاصله آزاد شود
  useEffect(() => releaseStream, [releaseStream]);

  // ضبط را متوقف کرده و {blob, duration, mimeType} نهایی را برمی‌گرداند
  const finishRecording = useCallback(() => {
    return new Promise((resolve) => {
      const recorder = mediaRecorderRef.current;
      if (!recorder || recorder.state === "inactive") {
        releaseStream();
        setIsRecording(false);
        resolve(null);
        return;
      }
      recorder.onstop = () => {
        const duration = (Date.now() - startTimeRef.current) / 1000;
        const mimeType = recorder.mimeType || "audio/webm";
        const blob = new Blob(chunksRef.current, { type: mimeType });
        chunksRef.current = [];
        releaseStream();
        setIsRecording(false);
        resolve({ blob, duration, mimeType });
      };
      recorder.stop();
    });
  }, [releaseStream]);

  // درخواست دسترسی به میکروفون و شروع ضبط. onAutoStop وقتی صدا زده می‌شود که سقف
  // مدت‌زمان مجاز (MAX_VOICE_DURATION_SECONDS) برسد و ضبط خودکار متوقف شود.
  const start = useCallback(
    async (onAutoStop) => {
      if (!supported) {
        return { ok: false, message: tr("ضبط پیام صوتی در این مرورگر یا دستگاه پشتیبانی نمی‌شود") };
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        const mimeType = pickSupportedMimeType();
        const recorder = mimeType ? new window.MediaRecorder(stream, { mimeType }) : new window.MediaRecorder(stream);
        chunksRef.current = [];
        recorder.ondataavailable = (e) => {
          if (e.data && e.data.size > 0) chunksRef.current.push(e.data);
        };
        mediaRecorderRef.current = recorder;
        autoStopRef.current = onAutoStop || null;

        recorder.start();
        startTimeRef.current = Date.now();
        setElapsedSeconds(0);
        setIsRecording(true);

        timerRef.current = setInterval(() => {
          const seconds = (Date.now() - startTimeRef.current) / 1000;
          setElapsedSeconds(seconds);
          if (seconds >= MAX_VOICE_DURATION_SECONDS && mediaRecorderRef.current?.state === "recording") {
            clearInterval(timerRef.current);
            timerRef.current = null;
            finishRecording().then((result) => autoStopRef.current?.(result));
          }
        }, 200);

        return { ok: true };
      } catch (err) {
        releaseStream();
        // نوع خطا را لاگ می‌کنیم تا علت واقعی (رد اجازه / نبودن میکروفون / اشغال‌بودن) قابل تشخیص باشد
        console.error("[voice] getUserMedia failed:", err?.name, err?.message);
        const name = err?.name;
        if (name === "NotFoundError" || name === "OverconstrainedError") {
          return { ok: false, message: tr("هیچ میکروفونی روی این دستگاه یافت نشد.") };
        }
        return { ok: false, message: tr("دسترسی به میکروفون ممکن نشد. لطفاً اجازه‌ی دسترسی را در مرورگر بررسی کنید.") };
      }
    },
    [supported, releaseStream, finishRecording]
  );

  // ضبط را متوقف کرده و فایل صوتیِ نهایی را برای ارسال برمی‌گرداند
  const stop = useCallback(() => finishRecording(), [finishRecording]);

  // ضبط را بدون نگه‌داشتنِ هیچ فایلی لغو می‌کند — استریم میکروفون بلافاصله بسته می‌شود
  const cancel = useCallback(async () => {
    await finishRecording();
  }, [finishRecording]);

  return { supported, isRecording, elapsedSeconds, start, stop, cancel };
}

import { useCallback, useMemo } from "react";
import { useSearchParams } from "react-router-dom";

// این هوک جایگزین ساده‌ی useState برای «تب فعال» داشبوردهاست.
// به‌جای نگه‌داشتن تب فعال فقط در حافظه‌ی کامپوننت (که با رفرش صفحه از بین می‌رود)،
// آن را در query string آدرس (مثلاً ?tab=doctors) ذخیره می‌کند. به این ترتیب:
//   - با فشردن F5 روی هر تب داشبورد، کاربر دقیقاً روی همان تب باقی می‌ماند.
//   - آدرس صفحه قابل اشتراک‌گذاری/بوکمارک‌کردن می‌شود.
//   - React Router به‌طور طبیعی از این رفتار پشتیبانی می‌کند و نیازی به
//     localStorage یا تغییر در معماری مسیریابی نیست.
// امضای خروجی دقیقاً مثل useState است: [activeTab, setActiveTab]
export default function useTabState(defaultTab, paramName = "tab") {
  const [searchParams, setSearchParams] = useSearchParams();

  const activeTab = searchParams.get(paramName) || defaultTab;

  const setActiveTab = useCallback(
    (nextTab) => {
      setSearchParams((prev) => {
        const next = new URLSearchParams(prev);
        if (nextTab && nextTab !== defaultTab) {
          next.set(paramName, nextTab);
        } else {
          next.delete(paramName);
        }
        return next;
      });
      // توجه: عمداً { replace: true } استفاده نشده. با push کردن هر تغییرِ تب
      // به تاریخچه‌ی مرورگر، دکمه‌های عقب/جلوی مرورگر بین تب‌های داشبورد
      // حرکت می‌کنند، به‌جای اینکه کاربر را یک‌باره از کل داشبورد بیرون بیندازند.
    },
    [setSearchParams, defaultTab, paramName]
  );

  return useMemo(() => [activeTab, setActiveTab], [activeTab, setActiveTab]);
}

import { useEffect, useRef } from "react";
import { useSearchParams } from "react-router-dom";

// این هوک برای «دیپ‌لینکینگ اعلان‌ها» استفاده می‌شود: وقتی کاربر از روی یک اعلان
// به یک تب داشبورد هدایت می‌شود (مثلاً ?tab=history&highlight=42)، این هوک همان
// شناسه (highlight) را از آدرس می‌خواند و یک کمک‌تابع برمی‌گرداند که با اتصال به
// هر ردیف/آیتم لیست، در صورت تطابق شناسه آن را به‌صورت خودکار اسکرول و برجسته می‌کند.
export default function useHighlightParam() {
  const [searchParams] = useSearchParams();
  const highlightId = searchParams.get("highlight");
  const scrolledRef = useRef(false);

  // با تغییر شناسه‌ی هایلایت (مثلاً کلیک روی اعلان دیگری)، اجازه‌ی اسکرول دوباره داده می‌شود
  useEffect(() => {
    scrolledRef.current = false;
  }, [highlightId]);

  function highlightRowProps(id) {
    if (!highlightId || id === null || id === undefined || String(id) !== highlightId) return {};
    return {
      className: "notif-highlight-row",
      ref: (el) => {
        if (el && !scrolledRef.current) {
          scrolledRef.current = true;
          el.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      },
    };
  }

  return { highlightId, highlightRowProps };
}

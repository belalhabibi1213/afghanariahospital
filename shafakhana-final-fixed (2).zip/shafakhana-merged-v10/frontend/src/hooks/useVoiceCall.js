import { useCallback, useEffect, useRef, useState } from "react";
import { io } from "socket.io-client";
import { emitChatNew, setChatSocketConnected } from "../utils/chatRealtime.js";
import { apiRequest, hasSessionHint, SERVER_ORIGIN } from "../utils/api.js";

import { tr } from "../i18n/tr.js";
// ---------- هوکِ تماسِ صوتی/تصویریِ بیمار ↔ داکتر ----------
// PART 7-C صوتی + PART 7-D تصویری + PART 7-E کنترل‌ها/وضعیت‌های تماس.
// این هوک هم در ChatWithDoctor.jsx (داشبورد بیمار) و هم در ChatWithPatients.jsx
// (داشبورد داکتر) استفاده می‌شود. فقط منطقِ WebRTC + اتصالِ Socket.IO را نگه
// می‌دارد؛ رابطِ کاربریِ تماس در VoiceCallPanel.jsx است.
//
// مجوزِ برقراریِ تماس کاملاً سمتِ بک‌اند بررسی می‌شود (backend/realtime/callSignaling.js:
// فقط بین بیمار و داکترِ دارای مکالمه‌ی مجاز/نوبتِ مشترک) — این هوک فقط conversationId
// (که خودِ کلاینت از قبل، از یک مکالمه‌ی مجازِ موجود در فهرستِ خودش دارد) می‌فرستد؛
// هیچ شناسه‌ی کاربرِ مقصدی مستقیم انتخاب/ارسال نمی‌شود.
//
// ---------- به‌روزرسانیِ PART 7-D — تماسِ تصویری (بدون تغییرِ رفتارِ تماسِ صوتی) ----------
// همان زیرساختِ سیگنالینگِ فازِ ۷-B/۷-C (call:initiate/accept/reject/end +
// offer/answer/ice-candidate) بدونِ هیچ رویدادِ تازه‌ای برای ویدیو دوباره استفاده
// می‌شود؛ فقط یک پارامترِ اختیاریِ callType ("audio" | "video") به call:initiate
// اضافه شده (پیش‌فرض "audio" — دقیقاً رفتارِ قبلی).
//
// ---------- به‌روزرسانیِ PART 7-E — وضعیت‌ها و کنترل‌های تماس ----------
// معماریِ WebRTC (createPeerConnection، getUserMedia، رله‌ی offer/answer/ICE)
// عیناً دست‌نخورده ماند. آنچه اضافه/بازسازی شد فقط لایه‌ی «کنترل و وضعیت» است:
//   status اکنون یکی از این ۱۰ مقدار است:
//     idle | calling | ringing | connecting | connected
//     | rejected | busy | missed | ended | failed
//   پنجِ موردِ آخر «وضعیت‌های پایانی» هستند: هرکدام (۱) بلافاصله میکروفون/دوربین/
//   RTCPeerConnection را آزاد می‌کنند (نیازمندیِ #۷ و #۸)، (۲) یک پیامِ فارسیِ
//   روشن نشان می‌دهند (VoiceCallPanel.jsx)، و (۳) پس از چند ثانیه خودکار (یا با
//   کلیکِ «بازگشت به گفتگو») کاربر را با خیال راحت به رابطِ عادیِ گفتگو برمی‌گردانند
//   (نیازمندیِ #۹). یک قفلِ (actionInFlightRef) هم از کلیک‌های تکراری/هم‌زمانِ
//   شروع/پذیرشِ تماس جلوگیری می‌کند (نیازمندیِ #۶، علاوه بر بررسیِ سمتِ بک‌اند).

// فهرست پیش‌فرض (فقط STUN). فهرست اصلی، شامل TURN در صورت تنظیم‌شدن روی سرور، از
// GET /api/chat/ice-servers گرفته می‌شود؛ اگر گرفتن آن شکست بخورد همین پیش‌فرض استفاده می‌شود.
const DEFAULT_ICE_SERVERS = [{ urls: "stun:stun.l.google.com:19302" }];
const ICE_REFRESH_INTERVAL_MS = 30 * 60 * 1000; // رمز TURN موقتی است؛ پیش از انقضا تجدید می‌شود
const RETURN_TO_CHAT_DELAY_MS = 3000; // مدتِ نمایشِ کارتِ وضعیتِ پایانی پیش از بازگشتِ خودکار
const DISMISSED_INCOMING_NOTICE_MS = 3500;

export default function useVoiceCall() {
  // idle | calling | ringing | connecting | connected | rejected | busy | missed | ended | failed
  const [status, setStatus] = useState("idle");
  const [incomingCall, setIncomingCall] = useState(null); // { callId, conversationId, callType, from: { userId, role } }
  const [callError, setCallError] = useState("");
  const [micDenied, setMicDenied] = useState(false);
  const [muted, setMuted] = useState(false);
  const [activeConversationId, setActiveConversationId] = useState(null);
  const [callSeconds, setCallSeconds] = useState(0);

  // ---------- وضعیتِ مخصوصِ تماسِ تصویری (PART 7-D) ----------
  const [callType, setCallType] = useState("audio"); // "audio" | "video" — نوعِ تماسِ فعال/درحالِ زنگ‌خوردن
  const [cameraOff, setCameraOff] = useState(false);
  const [cameraUnavailable, setCameraUnavailable] = useState(false); // دوربین در دسترس نبود؛ تماس به‌صورتِ صوتی ادامه یافت

  const socketRef = useRef(null);
  const pcRef = useRef(null);
  const localStreamRef = useRef(null);
  const remoteAudioRef = useRef(null);
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const remoteStreamRef = useRef(null);
  const pendingCandidatesRef = useRef([]);
  const activeCallIdRef = useRef(null);
  const activeCallTypeRef = useRef("audio");
  const isCallerRef = useRef(false);
  const durationTimerRef = useRef(null);
  const statusRef = useRef("idle"); // آینه‌ی status برای خواندنِ همیشه‌به‌روز داخلِ event handlerهای socket
  const actionInFlightRef = useRef(false); // جلوگیری از دوبار-کلیک/شروعِ هم‌زمانِ تماس (نیازمندیِ #۶)
  const returnToChatTimerRef = useRef(null);
  const dismissedIncomingTimerRef = useRef(null);
  const iceServersRef = useRef(DEFAULT_ICE_SERVERS);

  useEffect(() => {
    statusRef.current = status;
  }, [status]);

  // دریافت (و تجدید دوره‌ای) سرورهای STUN/TURN از بک‌اند
  useEffect(() => {
    if (!hasSessionHint()) return undefined;
    let cancelled = false;
    async function loadIceServers() {
      try {
        const data = await apiRequest("/chat/ice-servers");
        if (!cancelled && Array.isArray(data.iceServers) && data.iceServers.length > 0) {
          iceServersRef.current = data.iceServers;
        }
      } catch {
        // در صورت خطا همان فهرست قبلی/پیش‌فرض می‌ماند
      }
    }
    loadIceServers();
    const timer = setInterval(loadIceServers, ICE_REFRESH_INTERVAL_MS);
    return () => {
      cancelled = true;
      clearInterval(timer);
    };
  }, []);

  // ---------- اتصال Socket.IO (یک‌بار، هم‌زمان با بازشدن تبِ گفتگو) ----------
  useEffect(() => {
    if (!hasSessionHint()) return undefined;

    // نشست در کوکی httpOnly است؛ withCredentials باعث می‌شود مرورگر کوکی را همراه handshake بفرستد
    // و سرور هویت کاربر را از همان بخواند (توکنی در جاوااسکریپت وجود ندارد).
    const socket = io(SERVER_ORIGIN, {
      withCredentials: true,
      transports: ["websocket", "polling"],
    });
    socketRef.current = socket;

    // push لحظه‌ای پیام چت (چت به‌جای انتظار برای polling بلافاصله پیام را می‌گیرد)
    socket.on("connect", () => setChatSocketConnected(true));
    socket.on("disconnect", () => setChatSocketConnected(false));
    socket.on("chat:new", ({ conversationId } = {}) => emitChatNew(conversationId));

    socket.on("call:incoming", ({ callId, conversationId, callType: incomingType, from }) => {
      // اگر کاربر همین حالا در یک تماسِ دیگر است، تماسِ ورودیِ تازه نادیده گرفته
      // می‌شود (بک‌اند هم به همین ترتیب اجازه‌ی هم‌پوشانی نمی‌دهد)
      if (activeCallIdRef.current || statusRef.current !== "idle") return;
      setIncomingCall({ callId, conversationId, callType: incomingType === "video" ? "video" : "audio", from });
    });

    socket.on("call:accepted", async ({ callId }) => {
      if (callId !== activeCallIdRef.current || !isCallerRef.current) return;
      setStatus("connecting"); // «تماس در حال برقراری»
      try {
        const pc = pcRef.current;
        if (!pc) return;
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socket.emit("call:offer", { callId, sdp: pc.localDescription });
      } catch (err) {
        endActiveCall("failed", tr("تماس برقرار نشد؛ خطایی در اتصال رخ داد."));
      }
    });

    socket.on("call:offer", async ({ callId, sdp }) => {
      if (callId !== activeCallIdRef.current) return;
      const pc = pcRef.current;
      if (!pc) return;
      try {
        await pc.setRemoteDescription(sdp);
        await flushPendingCandidates();
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        socket.emit("call:answer", { callId, sdp: pc.localDescription });
      } catch (err) {
        endActiveCall("failed", tr("تماس برقرار نشد؛ خطایی در اتصال رخ داد."));
      }
    });

    socket.on("call:answer", async ({ callId, sdp }) => {
      if (callId !== activeCallIdRef.current) return;
      const pc = pcRef.current;
      if (!pc) return;
      try {
        await pc.setRemoteDescription(sdp);
        await flushPendingCandidates();
      } catch (err) {
        endActiveCall("failed", tr("تماس برقرار نشد؛ خطایی در اتصال رخ داد."));
      }
    });

    socket.on("call:ice-candidate", async ({ callId, candidate }) => {
      if (callId !== activeCallIdRef.current) return;
      const pc = pcRef.current;
      if (!pc || !candidate) return;
      if (!pc.remoteDescription || !pc.remoteDescription.type) {
        pendingCandidatesRef.current.push(candidate);
        return;
      }
      try {
        await pc.addIceCandidate(candidate);
      } catch (err) {
        // نادیده گرفتنِ کاندیدهای دیرآمده/نامعتبر — تماس همچنان می‌تواند از
        // مسیرهای دیگرِ ICE برقرار شود
      }
    });

    // ---------- گیرنده رد کرد ----------
    socket.on("call:rejected", ({ callId }) => {
      if (callId !== activeCallIdRef.current) return;
      endActiveCall("rejected", tr("تماس رد شد"), { notifyBackend: false });
    });

    // ---------- تماس‌گیرنده هرگز پاسخی نگرفت (تایم‌اوتِ زنگ‌خوردن) ----------
    socket.on("call:missed", ({ callId }) => {
      if (callId !== activeCallIdRef.current) return;
      endActiveCall("missed", tr("پاسخی دریافت نشد"), { notifyBackend: false });
    });

    // ---------- پایانِ تماس (توسطِ طرفِ مقابل، یا وقفه‌ی زنگ‌خوردنِ گیرنده) ----------
    socket.on("call:ended", ({ callId, reason }) => {
      if (callId === activeCallIdRef.current) {
        const wasConnected = statusRef.current === "connected";
        let message = wasConnected ? tr("تماس پایان یافت") : tr("تماس لغو شد");
        if (reason === "peer-disconnected") message = tr("ارتباط با طرفِ مقابل قطع شد");
        endActiveCall("ended", message, { notifyBackend: false });
        return;
      }
      // ممکن است تماسِ ورودیِ درحالِ زنگ‌خوردن (هنوز پذیرفته‌نشده) لغو یا بی‌پاسخ مانده باشد
      setIncomingCall((cur) => {
        if (!cur || cur.callId !== callId) return cur;
        showDismissedIncomingNotice(reason === "missed" ? tr("این تماس بی‌پاسخ ماند") : tr("تماس‌گیرنده تماس را لغو کرد"));
        return null;
      });
    });

    return () => {
      // اگر تبِ گفتگو درحینِ یک تماسِ فعال بسته شود، بک‌اند را هم مطلع می‌کنیم تا
      // نقشِ userActiveCall برای طرفِ مقابل هم آزاد شود
      if (activeCallIdRef.current) {
        socket.emit("call:end", { callId: activeCallIdRef.current });
      }
      socket.disconnect();
      setChatSocketConnected(false);
      socketRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function flushPendingCandidates() {
    const pc = pcRef.current;
    if (!pc) return;
    const queued = pendingCandidatesRef.current;
    pendingCandidatesRef.current = [];
    for (const candidate of queued) {
      try {
        await pc.addIceCandidate(candidate);
      } catch (err) {
        // نادیده گرفته می‌شود
      }
    }
  }

  function createPeerConnection(callId) {
    const pc = new RTCPeerConnection({ iceServers: iceServersRef.current });

    pc.onicecandidate = (e) => {
      if (e.candidate) {
        socketRef.current?.emit("call:ice-candidate", { callId, candidate: e.candidate });
      }
    };

    pc.ontrack = (e) => {
      if (activeCallTypeRef.current === "video") {
        remoteStreamRef.current = e.streams[0];
        if (remoteVideoRef.current) {
          remoteVideoRef.current.srcObject = e.streams[0];
          remoteVideoRef.current.play().catch(() => {});
        }
      } else if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = e.streams[0];
        remoteAudioRef.current.play().catch(() => {});
      }
    };

    // ---------- PART 7-E — وضعیتِ Failed دیگر بدونِ پاک‌سازی رها نمی‌شود ----------
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === "connected") {
        setStatus("connected");
        startDurationTimer();
      } else if (pc.connectionState === "failed") {
        endActiveCall("failed", tr("تماس برقرار نشد؛ اتصال با شکست مواجه شد."));
      }
    };

    const localStream = localStreamRef.current;
    if (localStream) {
      localStream.getTracks().forEach((track) => pc.addTrack(track, localStream));
    }

    pcRef.current = pc;
    return pc;
  }

  function startDurationTimer() {
    if (durationTimerRef.current) return;
    setCallSeconds(0);
    durationTimerRef.current = setInterval(() => setCallSeconds((s) => s + 1), 1000);
  }

  function stopDurationTimer() {
    if (durationTimerRef.current) {
      clearInterval(durationTimerRef.current);
      durationTimerRef.current = null;
    }
    setCallSeconds(0);
  }

  // ---------- درخواستِ صحیحِ مجوزِ میکروفون (و در تماسِ تصویری، دوربین) ----------
  // رفتارِ تماسِ صوتی (withVideo=false) دقیقاً همان کدِ قبلیِ فازِ ۷-C است —
  // چیزی در آن تغییر نکرد. بخشِ تازه فقط شاخه‌ی withVideo=true را اضافه می‌کند.
  async function requestMedia(withVideo) {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(
        withVideo ? { audio: true, video: { facingMode: "user" } } : { audio: true }
      );
      localStreamRef.current = stream;
      setMicDenied(false);
      setCameraUnavailable(false);
      if (withVideo && localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
        localVideoRef.current.play().catch(() => {});
      }
      return { ok: true };
    } catch (err) {
      // ---------- تماسِ تصویری: اگر مشکل مخصوصِ دوربین بود (نه رد شدنِ مجوز)، به‌جای
      // شکستِ کاملِ تماس، با میکروفونِ تنها ادامه می‌دهیم (بازگشتِ آرام به تماسِ صوتی) ----------
      if (withVideo && ["NotFoundError", "OverconstrainedError", "NotReadableError"].includes(err?.name)) {
        try {
          const audioOnlyStream = await navigator.mediaDevices.getUserMedia({ audio: true });
          localStreamRef.current = audioOnlyStream;
          setMicDenied(false);
          setCameraUnavailable(true);
          setCallError(tr("دوربین در دسترس نیست یا توسطِ برنامه‌ی دیگری استفاده می‌شود؛ تماس به‌صورتِ صوتی ادامه می‌یابد."));
          return { ok: true, downgradedToAudio: true };
        } catch (audioErr) {
          // نه دوربین و نه میکروفون در دسترس نیست — تماس اصلاً ممکن نیست
        }
      }

      setMicDenied(true);
      const message = withVideo
        ? err?.name === "NotFoundError"
          ? tr("دوربین یا میکروفونی روی این دستگاه یافت نشد.")
          : tr("دسترسی به دوربین/میکروفون رد شد. برای تماسِ تصویری، لطفاً از تنظیماتِ مرورگر اجازه‌ی دسترسی را بدهید.")
        : err?.name === "NotFoundError"
          ? tr("هیچ میکروفونی روی این دستگاه یافت نشد.")
          : tr("دسترسی به میکروفون رد شد. برای تماس، لطفاً از تنظیمات مرورگر اجازه‌ی دسترسی به میکروفون را بدهید.");
      setCallError(message);
      return { ok: false, message };
    }
  }

  function releaseLocalStream() {
    localStreamRef.current?.getTracks().forEach((t) => t.stop());
    localStreamRef.current = null;
  }

  // ---------- آزادسازیِ فوریِ همه‌ی منابع (میکروفون/دوربین/RTCPeerConnection) ----------
  // نیازمندیِ #۷ و #۸: همیشه — با هر سرانجامِ تماس — بلافاصله اجرا می‌شود، بدونِ
  // معطلی برای پایانِ نمایشِ کارتِ وضعیت.
  function teardownMediaResources() {
    pcRef.current?.close();
    pcRef.current = null;
    pendingCandidatesRef.current = [];
    releaseLocalStream(); // متوقف‌کردنِ trackهای میکروفون/دوربین
    if (remoteAudioRef.current) remoteAudioRef.current.srcObject = null;
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
    if (remoteVideoRef.current) remoteVideoRef.current.srcObject = null;
    remoteStreamRef.current = null;
    stopDurationTimer();
    setMuted(false);
    setCameraOff(false);
  }

  // ---------- برنامه‌ریزیِ بازگشتِ امن به رابطِ عادیِ گفتگو (نیازمندیِ #۹) ----------
  function scheduleReturnToChat(delay = RETURN_TO_CHAT_DELAY_MS) {
    if (returnToChatTimerRef.current) clearTimeout(returnToChatTimerRef.current);
    returnToChatTimerRef.current = setTimeout(() => {
      returnToChatTimerRef.current = null;
      resetToIdleNow();
    }, delay);
  }

  // ---------- بازگشتِ فوری به گفتگو (هم برای پایانِ خودکارِ تایمر، هم دکمه‌ی «بازگشت») ----------
  const resetToIdleNow = useCallback(() => {
    if (returnToChatTimerRef.current) {
      clearTimeout(returnToChatTimerRef.current);
      returnToChatTimerRef.current = null;
    }
    activeCallIdRef.current = null;
    activeCallTypeRef.current = "audio";
    isCallerRef.current = false;
    setStatus("idle");
    setCallType("audio");
    setActiveConversationId(null);
    setCallError("");
    setMicDenied(false);
    setCameraUnavailable(false);
    setIncomingCall(null);
    actionInFlightRef.current = false;
  }, []);

  function showDismissedIncomingNotice(message) {
    setCallError(message);
    if (dismissedIncomingTimerRef.current) clearTimeout(dismissedIncomingTimerRef.current);
    dismissedIncomingTimerRef.current = setTimeout(() => {
      dismissedIncomingTimerRef.current = null;
      setCallError("");
    }, DISMISSED_INCOMING_NOTICE_MS);
  }

  // ---------- گذار به یکی از وضعیت‌های پایانیِ یک تماسِ فعال/درحالِ زنگ‌خوردن ----------
  // (rejected | busy | missed | ended | failed) — همیشه ابتدا منابع را آزاد می‌کند،
  // سپس پیامِ فارسیِ روشن نشان می‌دهد و بازگشتِ خودکار به چت را برنامه‌ریزی می‌کند.
  function endActiveCall(terminalStatus, message, { notifyBackend = true } = {}) {
    if (notifyBackend && activeCallIdRef.current && socketRef.current) {
      socketRef.current.emit("call:end", { callId: activeCallIdRef.current });
    }
    teardownMediaResources();
    setStatus(terminalStatus);
    setCallError(message || "");
    setIncomingCall(null);
    scheduleReturnToChat();
  }

  // ---------- گذار به وضعیتِ پایانی برای تماسی که اصلاً callId نگرفت (busy/failed در همان initiate) ----------
  function endBeforeCallStarted(terminalStatus, message) {
    teardownMediaResources(); // ممکن است میکروفون/دوربین پیش از دریافتِ پاسخِ سرور گرفته شده باشد
    setStatus(terminalStatus);
    setCallError(message || "");
    scheduleReturnToChat();
  }

  // ---------- تماس‌گیرنده: شروعِ تماس ----------
  // آرگومانِ دومِ اختیاری { video } — نبودنش دقیقاً همان تماسِ صوتیِ قبلی است.
  const startCall = useCallback(async (conversationId, { video = false } = {}) => {
    // نیازمندیِ #۶ — جلوگیری از شروعِ هم‌زمان/تکراریِ تماس، ولو با کلیکِ سریعِ پیاپی
    if (
      !socketRef.current ||
      !conversationId ||
      actionInFlightRef.current ||
      activeCallIdRef.current ||
      statusRef.current !== "idle"
    ) {
      return;
    }
    actionInFlightRef.current = true;
    setCallError("");
    setMicDenied(false);
    setCameraUnavailable(false);
    setStatus("calling"); // «در حال تماس‌گیری» — پیش از حتی درخواستِ مجوزِ میکروفون/دوربین

    const media = await requestMedia(video);
    if (!media.ok) {
      actionInFlightRef.current = false;
      setStatus("idle"); // مجوز رد شد/دستگاه نبود — پیامِ خطا از requestMedia از قبل نمایش داده شده
      return;
    }
    // اگر دوربین در دسترس نبود و به‌صورتِ خودکار به تماسِ صوتی برگشتیم، همان
    // مسیرِ صوتی را ادامه می‌دهیم (callType واقعی، نه چیزی که کاربر خواسته بود)
    const effectiveType = video && !media.downgradedToAudio ? "video" : "audio";
    setCallType(effectiveType);

    socketRef.current.emit("call:initiate", { conversationId, callType: effectiveType }, (ack) => {
      actionInFlightRef.current = false;
      if (!ack?.ok) {
        const terminal = ack?.reason === "self-busy" || ack?.reason === "peer-busy" ? "busy" : "failed";
        endBeforeCallStarted(terminal, ack?.message || tr("برقراریِ تماس ممکن نشد"));
        return;
      }
      activeCallIdRef.current = ack.callId;
      activeCallTypeRef.current = effectiveType;
      isCallerRef.current = true;
      setActiveConversationId(conversationId);
      setStatus("ringing"); // «در حال زنگ‌خوردن» — طرفِ مقابل مطلع شد، منتظرِ پاسخ است
      createPeerConnection(ack.callId);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- گیرنده: پذیرشِ تماسِ ورودی ----------
  const acceptCall = useCallback(async () => {
    const call = incomingCall;
    if (!call || !socketRef.current || actionInFlightRef.current || activeCallIdRef.current) return;
    actionInFlightRef.current = true;
    setCallError("");
    setMicDenied(false);
    setCameraUnavailable(false);

    const wantsVideo = call.callType === "video";
    const media = await requestMedia(wantsVideo);
    if (!media.ok) {
      // اگر میکروفون/دوربین در دسترس نیست، تماس را مودبانه رد می‌کنیم نه اینکه بی‌پاسخ بماند
      socketRef.current.emit("call:reject", { callId: call.callId });
      setIncomingCall(null);
      actionInFlightRef.current = false;
      return;
    }
    const effectiveType = wantsVideo && !media.downgradedToAudio ? "video" : "audio";
    setCallType(effectiveType);

    socketRef.current.emit("call:accept", { callId: call.callId }, (ack) => {
      actionInFlightRef.current = false;
      if (!ack?.ok) {
        teardownMediaResources();
        setCallError(ack?.message || tr("این تماس دیگر معتبر نیست"));
        setIncomingCall(null);
        return;
      }
      activeCallIdRef.current = call.callId;
      activeCallTypeRef.current = effectiveType;
      isCallerRef.current = false;
      setActiveConversationId(call.conversationId);
      setStatus("connecting"); // «تماس در حال برقراری»
      setIncomingCall(null);
      createPeerConnection(call.callId);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [incomingCall]);

  // ---------- گیرنده: ردِ تماسِ ورودی ----------
  const rejectCall = useCallback(() => {
    if (!incomingCall || !socketRef.current) return;
    socketRef.current.emit("call:reject", { callId: incomingCall.callId });
    setIncomingCall(null);
  }, [incomingCall]);

  // ---------- پایانِ تماس به‌دستِ خودِ کاربر (دکمه‌ی «پایان تماس») ----------
  const endCall = useCallback(() => {
    if (!activeCallIdRef.current) return;
    const wasConnected = statusRef.current === "connected";
    endActiveCall("ended", wasConnected ? tr("تماس پایان یافت") : tr("تماس لغو شد"));
    // endActiveCall فقط refها و setterهای پایدار را می‌خواند (state واقعی را نمی‌خواند)، پس closure کهنه‌ای ایجاد نمی‌شود
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- بازگشتِ فوریِ دستی به گفتگو از رویِ کارتِ وضعیتِ پایانی ----------
  const returnToChat = useCallback(() => {
    resetToIdleNow();
  }, [resetToIdleNow]);

  // ---------- قطع/وصلِ میکروفون در حینِ تماس ----------
  const toggleMute = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const nextMuted = !muted;
    stream.getAudioTracks().forEach((t) => (t.enabled = !nextMuted));
    setMuted(nextMuted);
  }, [muted]);

  // ---------- روشن/خاموش‌کردنِ دوربین در حینِ تماسِ تصویری (PART 7-D) ----------
  const toggleCamera = useCallback(() => {
    const stream = localStreamRef.current;
    if (!stream) return;
    const videoTracks = stream.getVideoTracks();
    if (videoTracks.length === 0) return; // تماسِ صوتی یا دوربینِ در دسترس‌نبوده
    const nextOff = !cameraOff;
    videoTracks.forEach((t) => (t.enabled = !nextOff));
    setCameraOff(nextOff);
  }, [cameraOff]);

  // ---------- پاک‌سازی هنگام بستنِ کاملِ کامپوننت (خروج از تبِ گفتگو) ----------
  useEffect(() => {
    return () => {
      pcRef.current?.close();
      releaseLocalStream();
      stopDurationTimer();
      if (returnToChatTimerRef.current) clearTimeout(returnToChatTimerRef.current);
      if (dismissedIncomingTimerRef.current) clearTimeout(dismissedIncomingTimerRef.current);
    };
    // فقط هنگام unmount اجرا می‌شود؛ releaseLocalStream/stopDurationTimer فقط refها و setterهای پایدار را لمس می‌کنند
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ---------- اتصالِ (دوباره‌ی) استریمِ محلی/ریموت به تگ‌های <video> (PART 7-D) ----------
  // چون کارتِ تماس (و درنتیجه خودِ تگ‌های <video>) فقط وقتی status از "idle" خارج
  // شود در DOM ساخته می‌شوند — یعنی *بعد* از لحظه‌ای که getUserMedia/ontrack اجرا
  // شده‌اند — این افکت به‌محضِ آماده‌شدنِ خودِ تگ، استریمِ از قبل گرفته‌شده را به آن
  // وصل می‌کند (بدونِ درخواستِ دوباره‌ی رسانه).
  useEffect(() => {
    if (callType !== "video" || status === "idle") return;
    if (localVideoRef.current && localStreamRef.current && localVideoRef.current.srcObject !== localStreamRef.current) {
      localVideoRef.current.srcObject = localStreamRef.current;
      localVideoRef.current.play().catch(() => {});
    }
    if (remoteVideoRef.current && remoteStreamRef.current && remoteVideoRef.current.srcObject !== remoteStreamRef.current) {
      remoteVideoRef.current.srcObject = remoteStreamRef.current;
      remoteVideoRef.current.play().catch(() => {});
    }
  }, [status, callType]);

  return {
    status,
    incomingCall,
    callError,
    micDenied,
    muted,
    activeConversationId,
    callSeconds,
    remoteAudioRef,
    startCall,
    acceptCall,
    rejectCall,
    endCall,
    toggleMute,
    clearCallError: () => setCallError(""),
    returnToChat,
    // ---------- PART 7-D — تماسِ تصویری ----------
    callType,
    cameraOff,
    cameraUnavailable,
    localVideoRef,
    remoteVideoRef,
    toggleCamera,
  };
}

import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App.jsx";
import SiteDefaults from "./components/SiteDefaults.jsx";
import { AuthProvider } from "./context/AuthContext.jsx";
import { ThemeProvider } from "./context/ThemeContext.jsx";
import { SettingsProvider } from "./context/SettingsContext.jsx";
import { LanguageProvider } from "./context/LanguageContext.jsx";
import { readStoredLang } from "./i18n/languages.js";
import { loadLocale } from "./i18n/locales/registry.js";
import { loadTrDict } from "./i18n/tr.js";
import "./index.css";

// دیکشنری‌های زبان‌های غیردری فقط وقتی لازم باشند (زبان ذخیره‌شده‌ی کاربر) قبل از اولین رندر گرفته می‌شوند.
// برای دری چیزی دانلود نمی‌شود و رندر بلافاصله شروع می‌شود.
const startLang = readStoredLang();
Promise.all([loadLocale(startLang), loadTrDict(startLang)])
  .catch(() => {})
  .then(() => ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <LanguageProvider>
        <AuthProvider>
          <SettingsProvider>
            <ThemeProvider>
              <SiteDefaults />
              <App />
            </ThemeProvider>
          </SettingsProvider>
        </AuthProvider>
      </LanguageProvider>
    </BrowserRouter>
  </React.StrictMode>
));

import { Suspense, lazy } from "react";
import { Routes, Route, useLocation } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Maintenance from "./pages/Maintenance.jsx";
import ChangePasswordRequired from "./pages/ChangePasswordRequired.jsx";
import MfaSetupRequired from "./pages/MfaSetupRequired.jsx";
import ProtectedRoute from "./components/ProtectedRoute.jsx";
import LoginRequiredModal from "./components/LoginRequiredModal.jsx";
import LogoutConfirmModal from "./components/LogoutConfirmModal.jsx";
import ScrollToTop from "./components/ScrollToTop.jsx";
import { useAuth } from "./context/AuthContext.jsx";
import { useSiteSettings } from "./context/SettingsContext.jsx";

// داشبوردها (به‌خصوص ادمین و سوپرادمین) حجیم‌ترین بخش‌های فرانت‌اند هستند، اما فقط برای
// کاربران واردشده با همان نقش مورد نیاز بارگذاری می‌شوند. با lazy() این کدها دیگر داخل
// بسته‌ی اصلی (initial bundle) که همه‌ی بازدیدکنندگان سایت عمومی دانلود می‌کنند نمی‌آیند؛
// هر داشبورد فقط زمانی دانلود می‌شود که کاربر واقعاً به آن مسیر می‌رود (code-splitting).
// صفحه‌های غیر از خانه (ورود، ثبت‌نام، جزئیات خبر/بخش و ...) فقط وقتی کاربر به آن‌ها برود دانلود می‌شوند
const Login = lazy(() => import("./pages/Login.jsx"));
const Register = lazy(() => import("./pages/Register.jsx"));
const VerifyEmail = lazy(() => import("./pages/VerifyEmail.jsx"));
const ForgotPassword = lazy(() => import("./pages/ForgotPassword.jsx"));
const ResetPassword = lazy(() => import("./pages/ResetPassword.jsx"));
const AccessDenied = lazy(() => import("./pages/AccessDenied.jsx"));
const NewsDetail = lazy(() => import("./pages/NewsDetail.jsx"));
const DepartmentsPage = lazy(() => import("./pages/Departments.jsx"));
const DepartmentDetail = lazy(() => import("./pages/DepartmentDetail.jsx"));
// دستیار هوشمند یک دکمه‌ی شناور است و برای نمایش اولیه‌ی صفحه لازم نیست؛ جدا و بعد از صفحه دانلود می‌شود
const AiAssistant = lazy(() => import("./components/AiAssistant.jsx"));

const UserDashboard = lazy(() => import("./pages/dashboard/user/UserDashboard.jsx"));
const DoctorDashboard = lazy(() => import("./pages/dashboard/doctor/DoctorDashboard.jsx"));
const AdminDashboard = lazy(() => import("./pages/dashboard/admin/AdminDashboard.jsx"));
const SuperAdminDashboard = lazy(() => import("./pages/dashboard/superadmin/SuperAdminDashboard.jsx"));

// حالت بارگذاری ساده در زمان دانلود بسته‌ی جاوااسکریپت هر داشبورد
function DashboardLoadingFallback() {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", minHeight: "60vh", fontSize: "1.1rem", color: "#555" }}>
      در حال بارگذاری...
    </div>
  );
}

export default function App() {
  const { hasRole, user } = useAuth();
  const { settings } = useSiteSettings();
  const location = useLocation();

  // حالت تعمیرات (Maintenance Mode) — وقتی Super Admin آن را از «تنظیمات سیستم» روشن
  // می‌کند، کل سایت برای بازدیدکنندگان عادی (مهمان، بیمار، داکتر) قفل می‌شود و به‌جایش
  // این صفحه نمایش داده می‌شود. ادمین و مدیر کل مستثنا هستند تا بتوانند سایت را ببینند
  // و دوباره خاموشش کنند؛ مسیر /login همیشه در دسترس می‌ماند تا آن‌ها بتوانند وارد شوند.
  const isMaintenanceLocked =
    settings.maintenanceMode === "on" && !hasRole("admin", "superadmin") && location.pathname !== "/login";

  if (isMaintenanceLocked) {
    return <Maintenance />;
  }

  // الزام تغییر رمز عبور موقت: هم بلافاصله بعد از ورود (پاسخ login) و هم بعد از هر رفرش
  // صفحه (AuthContext آن را از GET /api/auth/me می‌گیرد) بررسی می‌شود، پس کاربر نمی‌تواند
  // با بستن/بازکردن دوباره‌ی تب از این مرحله فرار کند. کل رابط کاربری (هر مسیری که باشد)
  // با همین صفحه جایگزین می‌شود تا وقتی رمز عوض شود؛ بعد از تغییر موفق (یا خروج از حساب)
  // این پرچم پاک می‌شود و مسیر عادی از سر گرفته می‌شود.
  if (user && user.mustChangePassword) {
    return <ChangePasswordRequired />;
  }

  // الزام احراز هویت دومرحله‌ای (MFA) برای نقش‌های مدیریتی: تا فعال‌سازی، فقط صفحه‌ی راه‌اندازی دیده می‌شود
  // (سرور هم بقیه‌ی مسیرها را با MFA_SETUP_REQUIRED رد می‌کند).
  if (user && user.mfaSetupRequired) {
    return <MfaSetupRequired />;
  }

  return (
    <>
    <ScrollToTop />
    <Suspense fallback={<DashboardLoadingFallback />}>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/home" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/verify-email" element={<VerifyEmail />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/403" element={<AccessDenied />} />
      <Route path="/news/:id" element={<NewsDetail />} />
      <Route path="/departments" element={<DepartmentsPage />} />
      <Route path="/departments/:id" element={<DepartmentDetail />} />

      {/* داشبورد بیمار — فقط نقش user */}
      <Route
        path="/dashboard/user"
        element={
          <ProtectedRoute allowedRoles={["user"]}>
            <UserDashboard />
          </ProtectedRoute>
        }
      />

      {/* داشبورد داکتر — فقط نقش doctor (مدیریت برنامه کاری و نوبت‌های خودش) */}
      <Route
        path="/dashboard/doctor"
        element={
          <ProtectedRoute allowedRoles={["doctor"]}>
            <DoctorDashboard />
          </ProtectedRoute>
        }
      />

      {/* داشبورد ادمین — نقش‌های admin و superadmin (سوپرادمین به همه‌چیز دسترسی دارد) */}
      <Route
        path="/dashboard/admin"
        element={
          <ProtectedRoute allowedRoles={["admin", "superadmin"]}>
            <AdminDashboard />
          </ProtectedRoute>
        }
      />

      {/* داشبورد مدیر کل — فقط نقش superadmin */}
      <Route
        path="/dashboard/superadmin"
        element={
          <ProtectedRoute allowedRoles={["superadmin"]}>
            <SuperAdminDashboard />
          </ProtectedRoute>
        }
      />
    </Routes>
    </Suspense>
    <LoginRequiredModal />
    <LogoutConfirmModal />
    <Suspense fallback={null}><AiAssistant /></Suspense>
    </>
  );
}

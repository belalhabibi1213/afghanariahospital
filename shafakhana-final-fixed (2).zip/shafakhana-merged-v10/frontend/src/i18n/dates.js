// قالب‌بندی تاریخ و ارقام بر اساس زبان انتخاب‌شده.
// قرارداد پروژه بدون تغییر می‌ماند: مقدار ذخیره‌شده/ارسالی به API همیشه «میلادی ISO» است؛
// این فایل فقط «نمایش» را زبان‌محور می‌کند:
//   دری  → هجری شمسی با نام ماه‌های دری و ارقام فارسی (همان رفتار قبلی)
//   پشتو → هجری شمسی با نام ماه‌های پشتو و ارقام فارسی
//   English → میلادی با ارقام لاتین

import { formatJalaliDate, gregorianToJalali, jalaliWeekday, parseDateValue, toFaDigits } from "../utils/jalali.js";

export const MONTH_NAMES_PS = ["وری", "غويی", "غبرګولی", "چنګاښ", "زمری", "وږی", "تله", "لړم", "لیندۍ", "مرغومی", "سلواغه", "کب"];
export const WEEKDAY_NAMES_PS = ["شنبه", "یکشنبه", "دوشنبه", "درېشنبه", "څلورشنبه", "پنجشنبه", "جمعه"];
export const WEEKDAY_SHORT_PS = ["ش", "ی", "د", "در", "څ", "پ", "ج"];

const EN_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const EN_WEEKDAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

const pad2 = (n) => String(n).padStart(2, "0");

// ارقام لاتین (0-9) را برای زبان‌های دری/پشتو به ارقام فارسی تبدیل می‌کند؛ برای انگلیسی دست‌نخورده.
export function localizeDigits(value, lang) {
  return lang === "en" ? String(value) : toFaDigits(value);
}

// formatDateLocalized("2026-10-09", "ps", { month: "long" }) → «۱۷ لړم ۱۴۰۵»
// formatDateLocalized("2026-10-09", "en", { month: "long" }) → «October 9, 2026»
export function formatDateLocalized(value, lang, { month = "numeric", weekday = false, empty = "—" } = {}) {
  if (lang === "fa") return formatJalaliDate(value, { month, weekday, empty });

  const p = parseDateValue(value);
  if (!p) return empty;

  if (lang === "en") {
    const dow = new Date(Date.UTC(p.gy, p.gm - 1, p.gd)).getUTCDay();
    let text;
    if (month === "long") text = `${EN_MONTHS[p.gm - 1]} ${p.gd}, ${p.gy}`;
    else if (month === "short") text = `${EN_MONTHS[p.gm - 1].slice(0, 3)} ${p.gd}`;
    else text = `${p.gy}-${pad2(p.gm)}-${pad2(p.gd)}`;
    return weekday ? `${EN_WEEKDAYS[dow]}, ${text}` : text;
  }

  // پشتو: هجری شمسی با نام ماه‌های پشتو
  const j = gregorianToJalali(p.gy, p.gm, p.gd);
  let text;
  if (month === "long") text = `${j.jd} ${MONTH_NAMES_PS[j.jm - 1]} ${j.jy}`;
  else if (month === "short") text = `${j.jd} ${MONTH_NAMES_PS[j.jm - 1]}`;
  else text = `${j.jy}/${pad2(j.jm)}/${pad2(j.jd)}`;
  if (weekday) text = `${WEEKDAY_NAMES_PS[jalaliWeekday(j.jy, j.jm, j.jd)]} ${text}`;
  return toFaDigits(text);
}

// تاریخ یک رویداد (مثلاً زمان انتشار خبر) از رشته‌ی ISO/Date — جایگزین toLocaleDateString ثابت «fa-IR».
export function formatDateFromIso(iso, lang, opts) {
  if (!iso) return "";
  try {
    return formatDateLocalized(iso, lang, opts);
  } catch {
    return "";
  }
}

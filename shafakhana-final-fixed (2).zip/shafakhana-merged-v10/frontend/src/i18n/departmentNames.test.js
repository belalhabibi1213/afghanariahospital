import { describe, it, expect } from "vitest";
import { translateDepartmentName } from "./departmentNames.js";

describe("translateDepartmentName", () => {
  it("نام بخش را به انگلیسی و پشتو ترجمه می‌کند", () => {
    expect(translateDepartmentName("اطفال", "en")).toBe("Pediatrics");
    expect(translateDepartmentName("چشم", "en")).toBe("Ophthalmology");
    expect(translateDepartmentName("قلب و عروق", "ps")).toBe("زړه او رګونه");
  });
  it("در دری نام اصلی را برمی‌گرداند", () => {
    expect(translateDepartmentName("اطفال", "fa")).toBe("اطفال");
  });
  it("نام ناشناخته یا خالی را بدون تغییر برمی‌گرداند", () => {
    expect(translateDepartmentName("بخش تازه", "en")).toBe("بخش تازه");
    expect(translateDepartmentName("", "en")).toBe("");
    expect(translateDepartmentName(null, "en")).toBe(null);
  });
  it("تفاوت ی/ک عربی و فارسی مانع تطبیق نمی‌شود", () => {
    expect(translateDepartmentName("ارتوپيدي", "en")).toBe("Orthopedics"); // با «ي» عربی
    expect(translateDepartmentName("  دندان ", "en")).toBe("Dentistry");
  });
});

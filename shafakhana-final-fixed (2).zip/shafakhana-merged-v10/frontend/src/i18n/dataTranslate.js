// ترجمه‌ی «داده‌های ذخیره‌شده در دیتابیس» (که فقط به دری نوشته می‌شوند) برای نمایش در انگلیسی/پشتو:
//   • عبارت‌های تخصص/بخش (مثلاً «متخصص پیوند کلیه» → "Kidney Transplant Specialist")
//   • روزهای کاری (مثلاً «شنبه، یکشنبه، دوشنبه» → "Saturday, Sunday, Monday")
//   • نام داکتران (فقط نام‌های شناخته‌شده؛ در غیر این صورت بدون تغییر)
// اگر عبارتی کامل قابل ترجمه نباشد، متن اصلی بدون تغییر برمی‌گردد (هرگز ترجمه‌ی ناقص/مخلوط نمی‌سازد).
// برای افزودن واژه: یک ردیف به WORDS یا NAMES اضافه کنید.

function norm(s) {
  return String(s)
    .replace(/ي/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[‌‏‎]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

// ---------------- روزهای هفته ----------------
const DAYS = {
  "شنبه": { en: "Saturday", ps: "شنبه" },
  "یکشنبه": { en: "Sunday", ps: "یکشنبه" },
  "دوشنبه": { en: "Monday", ps: "دوشنبه" },
  "سهشنبه": { en: "Tuesday", ps: "درېشنبه" },
  "درېشنبه": { en: "Tuesday", ps: "درېشنبه" },
  "چهارشنبه": { en: "Wednesday", ps: "څلورشنبه" },
  "څلورشنبه": { en: "Wednesday", ps: "څلورشنبه" },
  "پنجشنبه": { en: "Thursday", ps: "پنجشنبه" },
  "جمعه": { en: "Friday", ps: "جمعه" },
};
// حالت «به‌اضافه‌ی ه/ې» در پشتو برای الگوی «له X تر Y»
const PS_FROM_TO = { "شنبه": "شنبې", "یکشنبه": "یکشنبې", "دوشنبه": "دوشنبې", "سهشنبه": "درېشنبې", "درېشنبه": "درېشنبې", "چهارشنبه": "څلورشنبې", "څلورشنبه": "څلورشنبې", "پنجشنبه": "پنجشنبې", "جمعه": "جمعې" };
const dayKey = (w) => norm(w).replace(/ /g, "");

export function translateWorkDays(text, lang) {
  if (!text || (lang !== "en" && lang !== "ps")) return text;
  const src = norm(text);

  // «شنبه تا چهارشنبه»
  const range = src.match(/^(\S+)\s+(?:تا|الی|الى)\s+(\S+)$/);
  if (range && DAYS[dayKey(range[1])] && DAYS[dayKey(range[2])]) {
    const a = dayKey(range[1]);
    const b = dayKey(range[2]);
    return lang === "en" ? `${DAYS[a].en} to ${DAYS[b].en}` : `له ${PS_FROM_TO[a]} تر ${PS_FROM_TO[b]}`;
  }

  if (/^(همه\s*روزها|همه\s*روز|روزانه|هر\s*روز)$/.test(src)) return lang === "en" ? "Every day" : "هره ورځ";

  // فهرست روزها با جداکننده‌ی «،» «,» «و» یا فاصله
  const tokens = src.split(/\s*[،,/]\s*|\s+و\s+|\s+/).filter(Boolean);
  // اگر «سه شنبه» با فاصله نوشته شده باشد، توکن‌ها را دوباره ترکیب می‌کنیم
  const merged = [];
  for (let i = 0; i < tokens.length; i++) {
    const two = i + 1 < tokens.length ? dayKey(tokens[i] + tokens[i + 1]) : null;
    if (two && DAYS[two]) {
      merged.push(two);
      i++;
    } else {
      merged.push(dayKey(tokens[i]));
    }
  }
  if (merged.length === 0 || !merged.every((d) => DAYS[d])) return text;
  const names = merged.map((d) => DAYS[d][lang]);
  return lang === "en" ? names.join(", ") : names.join("، ");
}

// ---------------- واژه‌های تخصص/بخش ----------------
const ROLES = {
  "متخصص": { en: "Specialist", ps: "متخصص" },
  "فوق تخصص": { en: "Sub-specialist", ps: "فوق تخصص" },
  "فوقتخصص": { en: "Sub-specialist", ps: "فوق تخصص" },
  "جراح": { en: "Surgeon", ps: "جراح" },
  "داکتر": { en: "Doctor", ps: "ډاکټر" },
  "دکتر": { en: "Doctor", ps: "ډاکټر" },
  "مشاور": { en: "Consultant", ps: "مشاور" },
};

const WORDS = {
  "پیوند": { en: "Transplant", ps: "پیوند" },
  "کلیه": { en: "Kidney", ps: "پښتورګي" },
  "کلیوی": { en: "Renal", ps: "پښتورګو" },
  "قلب": { en: "Heart", ps: "زړه" },
  "قلبی": { en: "Cardiac", ps: "زړه" },
  "عروق": { en: "Vascular", ps: "رګونه" },
  "رگ": { en: "Vascular", ps: "رګ" },
  "جراحی": { en: "Surgery", ps: "جراحي" },
  "عمومی": { en: "General", ps: "عمومي" },
  "داخله": { en: "Internal Medicine", ps: "داخله" },
  "داخلی": { en: "Internal Medicine", ps: "داخله" },
  "اطفال": { en: "Pediatrics", ps: "ماشومان" },
  "نوزادان": { en: "Neonatal", ps: "نوزیزونکي" },
  "زنان": { en: "Gynecology", ps: "ښځینه" },
  "زایمان": { en: "Obstetrics", ps: "ولادي" },
  "ارتوپیدی": { en: "Orthopedics", ps: "ارتوپیدي" },
  "استخوان": { en: "Bone", ps: "هډوکي" },
  "مفاصل": { en: "Joint", ps: "مفاصل" },
  "ستون فقرات": { en: "Spine", ps: "ملا تیر" },
  "دندان": { en: "Dental", ps: "غاښونه" },
  "دندانپزشکی": { en: "Dentistry", ps: "د غاښونو درملنه" },
  "چشم": { en: "Eye", ps: "سترګې" },
  "چشمی": { en: "Eye", ps: "سترګې" },
  "اعصاب": { en: "Neurology", ps: "اعصاب" },
  "مغز": { en: "Brain", ps: "مغز" },
  "پوست": { en: "Dermatology", ps: "پوستکی" },
  "گوش": { en: "Ear", ps: "غوږ" },
  "حلق": { en: "Throat", ps: "ستونی" },
  "بینی": { en: "Nose", ps: "پوزه" },
  "ارولوژی": { en: "Urology", ps: "یورولوژي" },
  "مجاری ادراری": { en: "Urinary Tract", ps: "مثانه" },
  "روانشناسی": { en: "Psychology", ps: "ارواپوهنه" },
  "روانپزشکی": { en: "Psychiatry", ps: "رواني ناروغۍ" },
  "رادیولوژی": { en: "Radiology", ps: "رادیولوژي" },
  "لابراتوار": { en: "Laboratory", ps: "لابراتوار" },
  "اورژانس": { en: "Emergency", ps: "بیړنی" },
  "فزیوتراپی": { en: "Physiotherapy", ps: "فزیوتراپي" },
  "تغذیه": { en: "Nutrition", ps: "تغذیه" },
  "ریه": { en: "Lung", ps: "سږي" },
  "سینه": { en: "Chest", ps: "سینه" },
  "هضمی": { en: "Digestive", ps: "هاضمه" },
  "معده": { en: "Stomach", ps: "معده" },
  "کبد": { en: "Liver", ps: "ينه" },
  "غدد": { en: "Endocrine", ps: "غدې" },
  "دیابت": { en: "Diabetes", ps: "شکر" },
  "سرطان": { en: "Cancer", ps: "سرطان" },
  "خون": { en: "Hematology", ps: "وینه" },
  "بیهوشی": { en: "Anesthesia", ps: "بیهوشي" },
  "پلاستیک": { en: "Plastic", ps: "پلاستیک" },
  "ترمیمی": { en: "Reconstructive", ps: "ترمیمي" },
  "زیبایی": { en: "Cosmetic", ps: "ښکلا" },
  "عفونی": { en: "Infectious Disease", ps: "ساري ناروغۍ" },
  "روماتیسم": { en: "Rheumatology", ps: "روماتیزم" },
  "ورزشی": { en: "Sports", ps: "سپورټي" },
  "سونوگرافی": { en: "Ultrasound", ps: "سونوګرافي" },
  "جنرال": { en: "General", ps: "عمومي" },
  "طب": { en: "Medicine", ps: "طب" },
  "خانواده": { en: "Family", ps: "کورنۍ" },
  "کودکان": { en: "Children", ps: "ماشومان" },
  "ماما": { en: "Midwifery", ps: "قابله" },
  "گوشحلقبینی": { en: "ENT", ps: "غوږ، ستونی او پوزه" },
  "حلق و بینی": { en: "Throat & Nose", ps: "ستونی او پوزه" },
};

const ROLE_KEYS = Object.keys(ROLES).sort((a, b) => b.length - a.length);
const WORD_KEYS = Object.keys(WORDS).sort((a, b) => b.length - a.length);

// یک قطعه‌ی چندکلمه‌ای (مثل «پیوند کلیه» یا «ستون فقرات») را به دنباله‌ی واژه‌های ترجمه‌شده تبدیل می‌کند؛ در صورت ناشناس‌بودن null
function translateSegment(segment, lang) {
  let rest = norm(segment);
  const out = [];
  while (rest) {
    const key = WORD_KEYS.find((k) => rest === norm(k) || rest.startsWith(norm(k) + " "));
    if (!key) return null;
    out.push(WORDS[key][lang]);
    rest = rest.slice(norm(key).length).trim();
  }
  return out;
}

export function translateSpecialty(text, lang) {
  if (!text || (lang !== "en" && lang !== "ps")) return text;
  let src = norm(text);

  // نقش اول عبارت («متخصص»، «جراح»، ...)
  let role = null;
  const roleKey = ROLE_KEYS.find((k) => src === norm(k) || src.startsWith(norm(k) + " "));
  if (roleKey) {
    role = ROLES[roleKey][lang];
    src = src.slice(norm(roleKey).length).trim();
  }
  src = src.replace(/گوش\s*[،و]?\s*حلق\s*[،و]?\s*بینی/, "گوشحلقبینی");
  if (!src && role) return role;

  // قطعه‌ها با «و»/«،» جدا می‌شوند
  const segments = src.split(/\s*[،,]\s*|\s+و\s+/).filter(Boolean);
  const translated = [];
  for (const seg of segments) {
    const words = translateSegment(seg, lang);
    if (!words) return text;
    // انگلیسی: ترتیب صفت/موصوف دری (مضاف‌الیه) معکوس می‌شود: «پیوند کلیه» → "Kidney Transplant"
    translated.push(lang === "en" ? [...words].reverse().join(" ") : words.join(" "));
  }
  if (translated.length === 0) return text;

  const body = translated.join(lang === "en" ? " & " : " او ");
  if (!role) return body;
  return lang === "en" ? `${body} ${role}` : `${body} ${role}`;
}

// ---------------- نام اشخاص ----------------
const NAMES = {
  "محمد": "Mohammad", "احمد": "Ahmad", "محسن": "Mohsen", "علی": "Ali", "حسین": "Hussain", "حسن": "Hassan",
  "عبدالله": "Abdullah", "عبدالرحمن": "Abdul Rahman", "عزیزالرحمن": "Azizurrahman", "عبدالکریم": "Abdul Karim",
  "عبدالرحیم": "Abdul Rahim", "عبدالقادر": "Abdul Qadir", "عبدالواحد": "Abdul Wahid", "نصرالله": "Nasrullah",
  "بصیر": "Basir", "بشیر": "Bashir", "سید": "Sayed", "سیدی": "Sayedi", "شریف": "Sharif", "حامد": "Hamed",
  "داریوش": "Dariush", "ادریس": "Idris", "ابراهیم": "Ibrahim", "اسماعیل": "Ismail", "یوسف": "Yusuf",
  "عمر": "Omar", "عثمان": "Osman", "خالد": "Khalid", "طارق": "Tariq", "فرید": "Farid", "نبی": "Nabi",
  "رحیم": "Rahim", "کریم": "Karim", "جمیل": "Jamil", "بلال": "Bilal", "حبیبی": "Habibi", "حبیب": "Habib",
  "پرسیلا": "Priscilla", "مریم": "Maryam", "فاطمه": "Fatima", "زهرا": "Zahra", "سمیرا": "Samira",
  "نرگس": "Narges", "لیلا": "Laila", "شکریه": "Shukria", "رقیه": "Roqia", "عایشه": "Aisha", "ثریا": "Soraya",
  "طاهری": "Taheri", "امیری": "Amiri", "عثمانی": "Osmani", "شفیق": "Shafiq", "شفیقی": "Shafiqi",
  "فروتن": "Forotan", "خیراندیش": "Khairandish", "نوری": "Noori", "احمدی": "Ahmadi", "رحیمی": "Rahimi",
  "کریمی": "Karimi", "حسینی": "Hosseini", "رضایی": "Rezaie", "صدیقی": "Sediqi", "محمدی": "Mohammadi",
  "نظری": "Nazari", "فیضی": "Faizi", "سلطانی": "Soltani", "قادری": "Qaderi", "حیدری": "Heidari",
  "یوسفی": "Yousofi", "هاشمی": "Hashemi", "رسولی": "Rasouli", "امین": "Amin", "امینی": "Amini",
  "ستانکزی": "Stanikzai", "نیازی": "Niazi", "وردک": "Wardak", "غفوری": "Ghafoori", "سروری": "Sarwari",
};
const TITLES = { "داکتر": "Dr.", "دکتر": "Dr.", "داکتره": "Dr.", "دکتره": "Dr." };

export function translateDoctorName(name, lang) {
  if (!name || lang !== "en") return name;
  const words = norm(name).split(" ").filter(Boolean);
  const out = [];
  for (const w of words) {
    if (TITLES[w]) out.push(TITLES[w]);
    else if (NAMES[w]) out.push(NAMES[w]);
    else return name;
  }
  return out.join(" ");
}

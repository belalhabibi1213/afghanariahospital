// ترجمه‌ی پیام‌های ثابتِ پاسخ سرور (data.message) برای صفحه‌های عمومی/ورود/ثبت‌نام/نوبت‌دهی.
// بک‌اند هنوز فقط دری می‌فرستد؛ تا زمانی که بک‌اند خودش بر اساس هدر Accept-Language پاسخ
// محلی‌شده بدهد، فرانت‌اند پیام را با «تطبیق دقیق متن» ترجمه می‌کند. پیام ناشناخته همان
// متن اصلی دری را نشان می‌دهد (هیچ‌وقت خالی یا خراب نمی‌شود).
// برای پیام‌های پویا (دارای عدد) در PATTERNS بنویسید (گروه‌های regex با m[1] خوانده می‌شوند).

const EXACT = {
  "نام باید فقط شامل حروف (دری، پشتو یا انگلیسی) و فاصله بین کلمات باشد (عدد و نمادهای دیگر مجاز نیست)": {
    en: "The name must contain only letters (Dari, Pashto or English) and spaces between words (digits and other symbols are not allowed).",
    ps: "نوم باید یوازې توري (دري، پښتو یا انګلیسي) او د کلمو ترمنځ تشه ولري (عددونه او نورې نښې اجازه نه لري)",
  },
  "ایمیل و رمز عبور الزامی است": {
    en: "Email and password are required",
    ps: "بریښنالیک او پټنوم اړین دي",
  },
  "ایمیل یا رمز عبور اشتباه است": {
    en: "Incorrect email or password",
    ps: "بریښنالیک یا پټنوم ناسم دی",
  },
  "ایمیل شما هنوز تایید نشده است. لطفاً کد ارسال‌شده به ایمیل خود را وارد کنید.": {
    en: "Your email has not been verified yet. Please enter the code sent to your email.",
    ps: "ستاسو بریښنالیک لا تایید شوی نه دی. مهرباني وکړئ هغه کوډ داخل کړئ چې ستاسو بریښنالیک ته لېږل شوی.",
  },
  "ایمیل شما با موفقیت تایید شد": {
    en: "Your email was verified successfully",
    ps: "ستاسو بریښنالیک په بریالیتوب سره تایید شو",
  },
  "حساب کاربری شما غیرفعال شده است. با مدیر سیستم تماس بگیرید.": {
    en: "Your account has been deactivated. Please contact the system administrator.",
    ps: "ستاسو حساب غیر فعال شوی دی. مهرباني وکړئ له سیستم مدیر سره اړیکه ونیسئ.",
  },
  "ورود موفقیت‌آمیز بود": { en: "Login successful", ps: "ننوتل بریالی و" },
  "خروج با موفقیت ثبت شد": { en: "Logout recorded successfully", ps: "وتل په بریالیتوب سره ثبت شو" },
  "کاربر یافت نشد": { en: "User not found", ps: "کاروونکی ونه موندل شو" },
  "همه فیلدها الزامی است": { en: "All fields are required", ps: "ټولې ساحې اړینې دي" },
  "کد احراز هویت دومرحله‌ای را وارد کنید": {
    en: "Enter the two-factor authentication code",
    ps: "دوه پړاوه تصدیق کوډ داخل کړئ",
  },
  "رمز عبور شما با موفقیت تغییر کرد. اکنون می‌توانید وارد شوید.": {
    en: "Your password was changed successfully. You can now log in.",
    ps: "ستاسو پټنوم په بریالیتوب سره بدل شو. اوس کولای شئ ننوځئ.",
  },
  "اگر این ایمیل ثبت شده و هنوز تایید نشده باشد، کد تایید جدید به آن ارسال می‌شود.": {
    en: "If this email is registered and not yet verified, a new verification code will be sent to it.",
    ps: "که دا بریښنالیک ثبت وي او لا تایید شوی نه وي، نوی تایید کوډ به ورته ولېږل شي.",
  },
  "اگر این ایمیل در سیستم ثبت باشد، کد بازیابی رمز عبور برای آن ارسال می‌شود.": {
    en: "If this email is registered in the system, a password recovery code will be sent to it.",
    ps: "که دا بریښنالیک په سیستم کې ثبت وي، د پټنوم بیا رغونې کوډ به ورته ولېږل شي.",
  },
  "خطای سرور در اتصال به دیتابیس": {
    en: "Server error while connecting to the database",
    ps: "له ډیټابیس سره د نښلېدو پر مهال د سرور تېروتنه",
  },
  "نام و متن پیام الزامی است": { en: "Name and message are required", ps: "نوم او د پیغام متن اړین دي" },
  "پیام شما با موفقیت ارسال شد": { en: "Your message was sent successfully", ps: "ستاسو پیغام په بریالیتوب سره ولېږل شو" },
  "وقت شما با موفقیت در سیستم ثبت شد": {
    en: "Your appointment was booked successfully",
    ps: "ستاسو وخت په بریالیتوب سره په سیستم کې ثبت شو",
  },
  "لطفاً فیلدهای ضروری فورمه را تکمیل کنید": {
    en: "Please complete the required fields of the form",
    ps: "مهرباني وکړئ د فورمې اړین ساحې بشپړې کړئ",
  },
  "تاریخ نوبت نمی‌تواند در گذشته باشد": {
    en: "The appointment date cannot be in the past",
    ps: "د وخت نېټه نشي کولای تېره وي",
  },
  "داکتر انتخاب‌شده یافت نشد": { en: "The selected doctor was not found", ps: "ټاکل شوی ډاکټر ونه موندل شو" },
  "داکتر انتخاب‌شده در این روز از هفته فعالیت ندارد. لطفاً روز دیگری انتخاب کنید": {
    en: "The selected doctor does not work on this day of the week. Please choose another day",
    ps: "ټاکل شوی ډاکټر د اونۍ په دې ورځ فعالیت نه لري. مهرباني وکړئ بله ورځ وټاکئ",
  },
  "این ساعت امروز گذشته است. لطفاً یکی از ساعت‌های باقی‌مانده را انتخاب کنید": {
    en: "This time has already passed today. Please choose one of the remaining times",
    ps: "دا ساعت نن تېر شوی دی. مهرباني وکړئ له پاتې ساعتونو یو وټاکئ",
  },
  "این ساعت در برنامه کاری داکتر برای این روز وجود ندارد. لطفاً از فهرست ساعت‌های قابل‌رزرو انتخاب کنید": {
    en: "This time is not in the doctor's schedule for this day. Please choose from the list of available times",
    ps: "دا ساعت د ډاکټر په کاري مهالویش کې د دې ورځې لپاره نشته. مهرباني وکړئ له شته ساعتونو وټاکئ",
  },
  "شما یک درخواست نوبت در این ساعت برای این داکتر در جریان دارید": {
    en: "You already have an appointment request at this time for this doctor",
    ps: "تاسو دمخه د دې ډاکټر لپاره په دې ساعت کې د وخت غوښتنه لرئ",
  },
  "برای این عملیات باید وارد حساب کاربری شوید": {
    en: "You must log in to perform this action",
    ps: "د دې کار لپاره باید حساب ته ننوځئ",
  },
  "شما اجازه دسترسی به این بخش را ندارید": {
    en: "You do not have permission to access this section",
    ps: "تاسو ته د دې برخې د لاسرسي اجازه نشته",
  },
  "نشست شما منقضی شده، دوباره وارد شوید": {
    en: "Your session has expired, please log in again",
    ps: "ستاسو ناسته پای ته رسېدلې ده، مهرباني وکړئ بیا ننوځئ",
  },
  "تعداد درخواست‌های شما بیش از حد مجاز است. لطفاً کمی بعد دوباره تلاش کنید.": {
    en: "You have made too many requests. Please try again shortly.",
    ps: "ستاسو غوښتنې له اجازه شوې کچې ډیرې دي. مهرباني وکړئ لږ وروسته بیا هڅه وکړئ.",
  },
  "درخواست نامعتبر است (توکن امنیتی CSRF). صفحه را دوباره بارگذاری کنید.": {
    en: "Invalid request (CSRF security token). Please reload the page.",
    ps: "غوښتنه ناسمه ده (د CSRF امنیتي ټوکن). مهرباني وکړئ پاڼه بیا بار کړئ.",
  },
  "مسیر درخواستی یافت نشد": { en: "The requested route was not found", ps: "غوښتل شوې لار ونه موندل شوه" },
  "ایمیل وارد شده معتبر نیست. لطفاً ایمیل خود را بررسی کنید.": {
    en: "The email you entered is not valid. Please check your email.",
    ps: "ننوتل شوی بریښنالیک سم نه دی. مهرباني وکړئ خپل بریښنالیک وګورئ.",
  },
};

// پیام‌های دارای عدد — اولین گروه regex مقدار پویا را می‌گیرد
const PATTERNS = [
  {
    re: /^به‌دلیل چند تلاش ناموفق، ورود موقتاً قفل شده است\. لطفاً حدود (\d+) دقیقه‌ی دیگر دوباره تلاش کنید یا رمز عبور خود را بازیابی کنید\.$/,
    en: (m) =>
      `Login is temporarily locked after several failed attempts. Please try again in about ${m[1]} minutes or recover your password.`,
    ps: (m) =>
      `د څو ناکامو هڅو له امله ننوتل په ګړیال ډول بند شوی دی. مهرباني وکړئ نژدې ${m[1]} دقیقې وروسته بیا هڅه وکړئ یا خپل پټنوم بیرته ترلاسه کړئ.`,
  },
  {
    re: /^تاریخ نوبت باید بین امروز و حداکثر (\d+) روز آینده باشد$/,
    en: (m) => `The appointment date must be between today and at most ${m[1]} days ahead`,
    ps: (m) => `د وخت نېټه باید د نن او تر ډیره ${m[1]} ورځو ترمنځ وي`,
  },
  {
    re: /^ظرفیت این ساعت برای داکتر انتخاب‌شده تکمیل شده است \(حداکثر (\d+) بیمار\)\. لطفاً ساعت دیگری انتخاب کنید$/,
    en: (m) => `This time slot is full for the selected doctor (maximum ${m[1]} patients). Please choose another time`,
    ps: (m) => `د ټاکل شوي ډاکټر لپاره د دې ساعت ظرفیت ډک شوی دی (تر ډیره ${m[1]} ناروغان). مهرباني وکړئ بل ساعت وټاکئ`,
  },
  {
    re: /^ظرفیت این ساعت هم‌زمان توسط بیماران دیگر تکمیل شد \(حداکثر (\d+) بیمار\)\. لطفاً ساعت دیگری انتخاب کنید$/,
    en: (m) => `This time slot was just filled by other patients (maximum ${m[1]} patients). Please choose another time`,
    ps: (m) => `د دې ساعت ظرفیت همدا اوس د نورو ناروغانو له خوا ډک شو (تر ډیره ${m[1]} ناروغان). مهرباني وکړئ بل ساعت وټاکئ`,
  },
];

// پیام سرور را به زبان داده‌شده برمی‌گرداند؛ برای دری یا پیام ناشناخته، همان متن اصلی.
export function translateServerMessage(message, lang) {
  if (!message || typeof message !== "string" || lang === "fa") return message;
  const exact = EXACT[message];
  if (exact && exact[lang]) return exact[lang];
  for (const p of PATTERNS) {
    const m = p.re.exec(message);
    if (m && p[lang]) return p[lang](m);
  }
  return message;
}

// ترجمه‌ی نام بخش‌های شفاخانه (departments.name) — در دیتابیس فقط نام دری ذخیره می‌شود، پس برای
// نمایش در زبان‌های دیگر از این نگاشت استفاده می‌شود. کلید = نام دری (نرمال‌شده).
// نام ناشناخته (مثلاً بخشی که ادمین جدید ساخته) بدون تغییر و به همان شکل ذخیره‌شده نمایش داده می‌شود.
// برای بخش جدید: یک ردیف به DEPARTMENT_NAMES اضافه کنید.
import { translateSpecialty } from "./dataTranslate.js";

const DEPARTMENT_NAMES = {
  "قلب و عروق": { en: "Cardiology", ps: "زړه او رګونه" },
  "اطفال": { en: "Pediatrics", ps: "ماشومان" },
  "زنان و زایمان": { en: "Obstetrics & Gynecology", ps: "ښځینه او ولادي" },
  "ارتوپیدی": { en: "Orthopedics", ps: "ارتوپیدي" },
  "دندان": { en: "Dentistry", ps: "غاښونه" },
  "داخله": { en: "Internal Medicine", ps: "داخله" },
  "چشم": { en: "Ophthalmology", ps: "سترګې" },
  "اعصاب": { en: "Neurology", ps: "اعصاب" },
  "جراحی": { en: "Surgery", ps: "جراحي" },
  "جراحی عمومی": { en: "General Surgery", ps: "عمومي جراحي" },
  "پوست": { en: "Dermatology", ps: "پوستکی" },
  "گوش حلق و بینی": { en: "ENT (Ear, Nose & Throat)", ps: "غوږ، ستونی او پوزه" },
  "گوش، حلق و بینی": { en: "ENT (Ear, Nose & Throat)", ps: "غوږ، ستونی او پوزه" },
  "ارولوژی": { en: "Urology", ps: "یورولوژي" },
  "روانشناسی": { en: "Psychology", ps: "ارواپوهنه" },
  "روان‌پزشکی": { en: "Psychiatry", ps: "رواني ناروغۍ" },
  "رادیولوژی": { en: "Radiology", ps: "رادیولوژي" },
  "لابراتوار": { en: "Laboratory", ps: "لابراتوار" },
  "اورژانس": { en: "Emergency", ps: "بیړنی حالت" },
  "فزیوتراپی": { en: "Physiotherapy", ps: "فزیوتراپي" },
  "تغذیه": { en: "Nutrition", ps: "تغذیه" },
  "داخلی": { en: "Internal Medicine", ps: "داخله" },
  "جنرال": { en: "General Medicine", ps: "عمومي ډاکټر" },
  "عمومی": { en: "General Medicine", ps: "عمومي" },
  "ریه": { en: "Pulmonology", ps: "سږي" },
  "کلیه": { en: "Nephrology", ps: "پښتورګي" },
  "هضمی": { en: "Gastroenterology", ps: "هاضمه" },
  "غدد": { en: "Endocrinology", ps: "غدې" },
  "سرطان": { en: "Oncology", ps: "سرطان" },
  "بیهوشی": { en: "Anesthesiology", ps: "بیهوشي" },
};

// یکسان‌سازی املا: ی/ک عربی، ZWNJ، فاصله‌های اضافه
function normalize(name) {
  return String(name)
    .replace(/\u064A/g, "\u06CC")
    .replace(/\u0643/g, "\u06A9")
    .replace(/[\u200c\u200f]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const INDEX = new Map(Object.entries(DEPARTMENT_NAMES).map(([k, v]) => [normalize(k), v]));

// نام انگلیسی ثبت‌شده توسط ادمین در پنل «مدیریت بخش‌ها» (ستون departments.nameEn) —
// از API عمومی بخش‌ها بارگذاری می‌شود و بر نگاشت ثابت بالا اولویت دارد.
let adminEnglishNames = new Map();
export function setAdminDepartmentNames(departments) {
  const next = new Map();
  for (const d of Array.isArray(departments) ? departments : []) {
    const en = typeof d?.nameEn === "string" ? d.nameEn.trim() : "";
    if (d?.name && en) next.set(normalize(d.name), en);
  }
  adminEnglishNames = next;
}

export function translateDepartmentName(name, lang) {
  if (name === null || name === undefined || name === "") return name;
  if (lang !== "en" && lang !== "ps") return name;
  const key = normalize(name);
  if (lang === "en" && adminEnglishNames.has(key)) return adminEnglishNames.get(key);
  const hit = INDEX.get(key);
  if (hit && hit[lang]) return hit[lang];
  // عبارت‌هایی مثل «متخصص پیوند کلیه» که در جدول ثابت نیستند: ترجمه‌ی واژه‌به‌واژه (در صورت ناشناس‌بودن، متن اصلی)
  return translateSpecialty(name, lang);
}

import { useMemo } from "react";
import { useSiteSettings } from "../context/SettingsContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { toLatinDigits } from "../utils/jalali.js";

// مقدارهای پیش‌فرضِ دری که قبل از شخصی‌سازی توسط Super Admin در «تنظیمات سیستم» وجود دارند.
// فقط وقتی مقدار ذخیره‌شده دقیقاً یکی از این‌هاست، برای زبان‌های دیگر ترجمه‌ی آماده نشان داده
// می‌شود؛ اگر Super Admin متن دیگری نوشته باشد، همان متنِ او بدون تغییر نمایش داده می‌شود
// (تا وقتی که تنظیمات چندزبانه در بک‌اند اضافه شود).
const DEFAULT_FA = {
  hospitalName: ["شفاخانه افغان آریا", "شفاخانه آریا افغان"],
  hospitalAddress: ["هرات، شهر هرات، جاده مرکزی"],
};

// همان useSiteSettings است، اما نام و آدرس پیش‌فرض را به زبان انتخاب‌شده برمی‌گرداند و
// برای انگلیسی ارقام شماره تلفن را لاتین می‌کند.
export function useLocalizedSettings() {
  const { settings, loading, refreshSettings } = useSiteSettings();
  const { lang, t } = useLanguage();

  const localized = useMemo(() => {
    if (lang === "fa") return settings;
    const next = { ...settings };
    if (DEFAULT_FA.hospitalName.includes(settings.hospitalName)) next.hospitalName = t("brand.hospitalName");
    if (DEFAULT_FA.hospitalAddress.includes(settings.hospitalAddress)) next.hospitalAddress = t("brand.hospitalAddress");
    if (lang === "en" && typeof settings.hospitalPhone === "string") next.hospitalPhone = toLatinDigits(settings.hospitalPhone);
    return next;
  }, [settings, lang, t]);

  return { settings: localized, loading, refreshSettings };
}

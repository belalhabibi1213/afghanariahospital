import { describe, it, expect } from "vitest";
import fa from "./locales/fa.js";
import en from "./locales/en.js";
import ps from "./locales/ps.js";
import { translateServerMessage } from "./serverMessages.js";

// همه‌ی کلیدها را به‌صورت «a.b.c» (و آرایه‌ها با اندیس) فهرست می‌کند
function flatten(obj, prefix = "") {
  return Object.entries(obj).flatMap(([k, v]) => {
    const key = prefix ? `${prefix}.${k}` : k;
    return v && typeof v === "object" ? flatten(v, key) : [[key, v]];
  });
}
const placeholders = (s) => (typeof s === "string" ? (s.match(/\{\w+\}/g) || []).sort().join(",") : "");

describe("i18n locales", () => {
  const base = new Map(flatten(fa));
  for (const [name, dict] of [["en", en], ["ps", ps]]) {
    it(`${name}: همان کلیدها و همان متغیرهای {…} را دارد`, () => {
      const other = new Map(flatten(dict));
      expect([...other.keys()].sort()).toEqual([...base.keys()].sort());
      for (const [key, value] of base) expect(placeholders(other.get(key)), key).toBe(placeholders(value));
    });
  }

  it("پیام ثابت سرور ترجمه می‌شود و پیام ناشناخته دست‌نخورده می‌ماند", () => {
    expect(translateServerMessage("ایمیل یا رمز عبور اشتباه است", "en")).toBe("Incorrect email or password");
    expect(translateServerMessage("ایمیل یا رمز عبور اشتباه است", "fa")).toBe("ایمیل یا رمز عبور اشتباه است");
    expect(translateServerMessage("پیام ناشناخته", "ps")).toBe("پیام ناشناخته");
  });
});

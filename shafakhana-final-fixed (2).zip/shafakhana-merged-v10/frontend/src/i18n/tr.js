// ترجمه‌ی متن‌های داشبورد (ادمین و بخش‌های مشترک).
// کلید ترجمه همان متن دری است: tr("ذخیره") ؛ برای متن‌های دارای مقدار پویا از {0} و {1} استفاده می‌شود:
//   tr("صفحه {0} از {1}", [page, total])
// متنی که در فایل ترجمه نباشد (یا زبان دری باشد) همان متن اصلی را برمی‌گرداند؛ پس هرگز خالی/خراب نمی‌شود.
// زبان فعلی از getCurrentLang() خوانده می‌شود؛ داشبورد با تغییر زبان دوباره ساخته می‌شود (key={lang}).

import { createElement, Fragment } from "react";
import { getCurrentLang, getLanguageMeta } from "./languages.js";
import { translateServerMessage } from "./serverMessages.js";
import { localizeDigits, formatDateLocalized } from "./dates.js";
import {
  MONTH_NAMES as FA_MONTHS,
  WEEKDAY_NAMES as FA_WEEKDAYS,
  WEEKDAY_SHORT as FA_WEEKDAY_SHORT,
  formatJalaliDate,
  formatTime,
  parseDateValue,
  toLatinDigits,
} from "../utils/jalali.js";
// دیکشنری‌های ترجمه‌ی داشبورد (هرکدام حدود ۱۰۰KB) فقط وقتی دانلود می‌شوند که کاربر زبان انگلیسی/پشتو
// را انتخاب کرده باشد؛ بازدیدکننده‌ی دری‌زبان هرگز آن‌ها را نمی‌گیرد. قبل از رندر (main.jsx) و
// قبل از تغییر زبان (LanguageContext) loadTrDict(lang) صدا زده می‌شود؛ تا آن موقع tr همان متن دری را برمی‌گرداند.
const DICTS = {};
const LOADERS = {
  en: () => import("./dashboard/en.js"),
  ps: () => import("./dashboard/ps.js"),
};

export async function loadTrDict(lang) {
  if (DICTS[lang] || !LOADERS[lang]) return;
  DICTS[lang] = (await LOADERS[lang]()).default;
}
const PERSIAN = /[\u0600-\u06FF]/;

function lookup(text, lang) {
  const dict = DICTS[lang];
  if (!dict) return text;
  if (Object.prototype.hasOwnProperty.call(dict, text)) return dict[text];
  // پیام‌های ثابت سرور (مثلاً خطای اعتبارسنجی) از فایل serverMessages ترجمه می‌شوند.
  try {
    const viaServer = translateServerMessage(text, lang);
    if (viaServer) return viaServer;
  } catch { /* بی‌اثر */ }
  return text;
}

function format(text, params) {
  if (!params || !params.length) return text;
  const parts = text.split(/(\{\d+\})/);
  const nodes = parts.map((part) => {
    const m = part.match(/^\{(\d+)\}$/);
    return m ? params[Number(m[1])] ?? "" : part;
  });
  const allPrimitive = nodes.every((n) => n === null || ["string", "number", "boolean", "undefined"].includes(typeof n));
  if (allPrimitive) return nodes.join("");
  return createElement(Fragment, null, ...nodes.map((n, i) => createElement(Fragment, { key: i }, n)));
}

export function tr(text, params) {
  if (typeof text !== "string") return text;
  const lang = getCurrentLang();
  return format(lang === "fa" ? text : lookup(text, lang), params);
}

// تابع دری→زبان فعلی برای مقادیری که از یک ثابت یا پایگاه‌داده می‌آیند (مثل روزهای هفته).
export const trText = tr;

// قالب ارقام/تاریخ Intl بر اساس زبان فعلی (دری/پشتو: هجری شمسی با ارقام فارسی، English: میلادی با ارقام لاتین).
export function numLocale() {
  return getLanguageMeta(getCurrentLang()).numberLocale;
}

// ثابت‌های سطح ماژول (مثل TABS یا STATUS_LABEL): هر بار که خوانده شوند، رشته‌های دری آن به زبان فعلی ترجمه می‌شوند.
const cache = new WeakMap();
export function trc(value) {
  if (!value || typeof value !== "object") return value;
  if (value.$$typeof) return value; // المان React
  const proto = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && proto !== Object.prototype && proto !== null) return value;
  if (cache.has(value)) return cache.get(value);
  const proxy = new Proxy(value, {
    get(target, prop, receiver) {
      const v = Reflect.get(target, prop, receiver);
      if (typeof prop === "symbol") return v;
      if (typeof v === "string") return PERSIAN.test(v) ? tr(v) : v;
      if (v && typeof v === "object") return trc(v);
      return v;
    },
  });
  cache.set(value, proxy);
  return proxy;
}

// نام ماه‌ها و روزهای هفته (برای تقویم‌ها): همان آرایه‌های jalali.js ولی ترجمه‌شده به زبان فعلی.
export const MONTH_NAMES = trc(FA_MONTHS);
export const WEEKDAY_NAMES = trc(FA_WEEKDAYS);
export const WEEKDAY_SHORT = trc(FA_WEEKDAY_SHORT);

// ارقام: دری/پشتو → فارسی، انگلیسی → لاتین.
export function tdigits(value) {
  return localizeDigits(value, getCurrentLang());
}

// تاریخ/ساعت زبان‌محور (جایگزین formatJalaliDate / formatTime / formatJalaliDateTime).
//   دری → هجری شمسی (رفتار قبلی)، پشتو → هجری شمسی با نام ماه پشتو، English → میلادی با ارقام لاتین
export function jdate(value, opts = {}) {
  const lang = getCurrentLang();
  if (lang === "fa") return formatJalaliDate(value, opts);
  const { month = "numeric", weekday = false, empty = "—", latin = false } = opts;
  const text = formatDateLocalized(value, lang, { month, weekday, empty });
  return latin ? toLatinDigits(text) : text;
}

export function jtime(value, opts = {}) {
  const lang = getCurrentLang();
  return formatTime(value, lang === "en" ? { ...opts, latin: true } : opts);
}

export function jdatetime(value, opts = {}) {
  const p = parseDateValue(value);
  if (!p) return opts.empty ?? "—";
  const date = jdate(value, opts);
  return p.hasTime ? `${date} ${jtime(value, opts)}` : date;
}

// جهت متن زبان فعلی ("rtl" برای دری/پشتو، "ltr" برای انگلیسی) — برای المان‌هایی که dir را دستی می‌گذارند (جدول‌ها، برگه‌های چاپ)
export function curDir() {
  return getLanguageMeta(getCurrentLang()).dir;
}

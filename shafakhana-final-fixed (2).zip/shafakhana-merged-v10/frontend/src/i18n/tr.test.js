import { describe, it, expect, beforeEach } from "vitest";
import { tr, trc, tdigits } from "./tr.js";
import { setCurrentLang } from "./languages.js";
import en from "./dashboard/en.js";
import ps from "./dashboard/ps.js";

// همه‌ی فایل‌های سورس به‌صورت متن خام (برای پیدا کردن tr("...") ها)
const sources = import.meta.glob("../**/*.{js,jsx}", { query: "?raw", import: "default", eager: true });
const TR_CALL = /\btr\(\s*("(?:[^"\\\n]|\\.)*")/g;

const placeholders = (s) => (s.match(/\{\d+\}/g) || []).sort().join(",");

describe("tr() — ترجمه‌ی داشبورد", () => {
  beforeEach(() => setCurrentLang("fa"));

  it("در دری همان متن را برمی‌گرداند و مقدارها را جایگزین می‌کند", () => {
    expect(tr("ذخیره")).toBe("ذخیره");
    expect(tr("صفحه {0} از {1}", [2, 5])).toBe("صفحه 2 از 5");
  });

  it("در انگلیسی و پشتو ترجمه می‌کند", () => {
    setCurrentLang("en");
    expect(tr("ذخیره")).toBe("Save");
    expect(tr("صفحه {0} از {1} ({2} نسخه)", [2, 5, 40])).toBe("Page 2 of 5 (40 prescriptions)");
    setCurrentLang("ps");
    expect(tr("ذخیره")).toBe("ثبتول");
  });

  it("متن ناشناخته بدون خطا به همان متن برمی‌گردد", () => {
    setCurrentLang("en");
    expect(tr("یک متن که هرگز ترجمه نمی‌شود")).toBe("یک متن که هرگز ترجمه نمی‌شود");
  });

  it("trc ثابت‌های سطح ماژول را هنگام خواندن ترجمه می‌کند", () => {
    const LABELS = trc({ a: "ذخیره", list: [{ label: "حذف" }] });
    expect(LABELS.a).toBe("ذخیره");
    setCurrentLang("en");
    expect(LABELS.a).toBe("Save");
    expect(LABELS.list.map((x) => x.label)).toEqual(["Delete"]);
  });

  it("ارقام: انگلیسی لاتین، دری فارسی", () => {
    expect(tdigits("12")).toBe("۱۲");
    setCurrentLang("en");
    expect(tdigits("12")).toBe("12");
  });

  it("هر tr(\"...\") در سورس در فایل‌های en و ps ترجمه دارد و {n} ها یکسان‌اند", () => {
    const missing = [];
    const badPlaceholders = [];
    for (const [file, code] of Object.entries(sources)) {
      if (file.includes(".test.") || file.includes("/i18n/") || file.startsWith("./")) continue;
      for (const m of code.matchAll(TR_CALL)) {
        let key;
        try { key = JSON.parse(m[1]); } catch { continue; }
        if (!/[\u0600-\u06FF]/.test(key)) continue;
        if (!(key in en) || !(key in ps)) missing.push(`${file}: ${key}`);
        else if (placeholders(key) !== placeholders(en[key]) || placeholders(key) !== placeholders(ps[key])) badPlaceholders.push(key);
      }
    }
    expect(missing).toEqual([]);
    expect(badPlaceholders).toEqual([]);
  });
});

// دیکشنری‌های متن سایت عمومی. فقط دری (زبان پیش‌فرض) داخل بسته‌ی اصلی است؛ انگلیسی و پشتو فقط وقتی
// کاربر آن زبان را انتخاب کرده باشد دانلود می‌شوند (بسته‌ی اصلی سبک‌تر ⇒ صفحه‌ی اصلی سریع‌تر).
import fa from "./fa.js";

export const DICTIONARIES = { fa };

const loaders = {
  en: () => import("./en.js"),
  ps: () => import("./ps.js"),
};

// دیکشنری زبان را (در صورت نیاز) بارگذاری می‌کند؛ برای دری چیزی برای دانلود نیست.
export async function loadLocale(lang) {
  if (DICTIONARIES[lang] || !loaders[lang]) return;
  DICTIONARIES[lang] = (await loaders[lang]()).default;
}

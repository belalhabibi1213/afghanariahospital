import { describe, it, expect } from "vitest";
import { translateSpecialty, translateWorkDays, translateDoctorName } from "./dataTranslate.js";
import { translateDepartmentName } from "./departmentNames.js";

describe("dataTranslate", () => {
  it("عبارت تخصص", () => {
    expect(translateDepartmentName("متخصص پیوند کلیه", "en")).toBe("Kidney Transplant Specialist");
    expect(translateDepartmentName("متخصص جراحی", "en")).toBe("Surgery Specialist");
    expect(translateSpecialty("متخصص جراحی ارتوپیدی", "fa")).toBe("متخصص جراحی ارتوپیدی");
    expect(translateSpecialty("چیز ناشناخته", "en")).toBe("چیز ناشناخته");
  });
  it("روزهای کاری", () => {
    expect(translateWorkDays("شنبه، یکشنبه، دوشنبه", "en")).toBe("Saturday, Sunday, Monday");
    expect(translateWorkDays("شنبه تا چهارشنبه", "en")).toBe("Saturday to Wednesday");
    expect(translateWorkDays("شنبه تا چهارشنبه", "ps")).toBe("له شنبې تر څلورشنبې");
    expect(translateWorkDays("شنبه، سه‌شنبه، پنج‌شنبه، جمعه", "en")).toBe("Saturday, Tuesday, Thursday, Friday");
    expect(translateWorkDays("شنبه، سه شنبه", "en")).toBe("Saturday, Tuesday");
  });
  it("نام داکتر", () => {
    expect(translateDoctorName("داکتر محسن فروتن", "en")).toBe("Dr. Mohsen Forotan");
    expect(translateDoctorName("داکتره پرسیلا طاهری", "en")).toBe("Dr. Priscilla Taheri");
    expect(translateDoctorName("داکتر ناشناخته", "en")).toBe("داکتر ناشناخته");
  });
});

// فهرست زبان‌های پشتیبانی‌شده‌ی سایت — تنها منبع تعریف زبان‌ها.
// برای افزودن زبان جدید: ۱) یک ردیف به LANGUAGES اضافه کنید، ۲) فایل ترجمه‌ی آن را در
// i18n/locales بسازید و در context/LanguageContext.jsx ثبت کنید، ۳) (اختیاری) ترجمه‌ی
// پیام‌های سرور را در i18n/serverMessages.js اضافه کنید.

export const LANGUAGES = [
  // numberLocale: قالب ارقام/تاریخ در Intl — دری/پشتو با تقویم هجری شمسی (رسمی افغانستان)
  { code: "fa", name: "دری / فارسی", short: "دری", dir: "rtl", numberLocale: "fa-IR-u-ca-persian", calendar: "jalali" },
  { code: "ps", name: "پښتو", short: "پښتو", dir: "rtl", numberLocale: "ps-AF-u-ca-persian", calendar: "jalali" },
  { code: "en", name: "English", short: "EN", dir: "ltr", numberLocale: "en-US", calendar: "gregorian" },
];

export const DEFAULT_LANG = "fa";
export const LANG_STORAGE_KEY = "shafakhana_lang";

export function isSupportedLang(code) {
  return LANGUAGES.some((l) => l.code === code);
}

export function getLanguageMeta(code) {
  return LANGUAGES.find((l) => l.code === code) || LANGUAGES[0];
}

// خواندن زبان ذخیره‌شده — بدون وابستگی به React تا کدهای غیرکامپوننتی (مثل api.js) هم
// بتوانند زبان فعلی را بدانند. اگر localStorage در دسترس نباشد، زبان پیش‌فرض (دری) برمی‌گردد.
export function readStoredLang() {
  try {
    const saved = localStorage.getItem(LANG_STORAGE_KEY);
    return isSupportedLang(saved) ? saved : DEFAULT_LANG;
  } catch {
    return DEFAULT_LANG;
  }
}

// زبان «فعلی» برای ماژول‌های غیر React؛ LanguageProvider آن را همگام نگه می‌دارد.
let currentLang = readStoredLang();
export function getCurrentLang() {
  return currentLang;
}
export function setCurrentLang(code) {
  if (isSupportedLang(code)) currentLang = code;
}

import { useEffect, useLayoutEffect, useRef, useState, useCallback } from "react";
import { createPortal } from "react-dom";
import { useNavigate } from "react-router-dom";
import { X } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import { apiRequest } from "../utils/api.js";
import { isScrollbarClick } from "../utils/scrollbarClick.js";

import { tr } from "../i18n/tr.js";
const POLL_INTERVAL_MS = 30000; // هر ۳۰ ثانیه تعداد اعلان‌های خوانده‌نشده را بررسی می‌کند

const TYPE_ICON = {
  appointment: "📅",
  general: "🔔",
  medical_record: "🗂️",
  prescription: "💊",
  lab_result: "🧪",
  file_transfer: "📥",
  billing: "🧾",
  news: "📰",
  news_comment: "💬",
  chat_message: "✉️",
  contact_message: "📩",
};

function timeAgo(dateStr) {
  const diffMs = Date.now() - new Date(dateStr).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 1) return tr("همین الان");
  if (minutes < 60) return tr("{0} دقیقه پیش", [minutes]);
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return tr("{0} ساعت پیش", [hours]);
  const days = Math.floor(hours / 24);
  return tr("{0} روز پیش", [days]);
}

const PANEL_WIDTH = 368;
const PANEL_MARGIN = 12; // حداقل فاصله از لبه‌های viewport
const PANEL_GAP = 10; // فاصله‌ی عمودی پنل از دکمه‌ی زنگوله

// ============================================================================
// پنل اعلان‌ها — رندر با React Portal مستقیماً روی document.body
// ============================================================================
// چرا Portal؟ دکمه‌ی زنگوله ممکن است داخل هدر عمومی سایت یا داخل نوار بالای
// داشبورد (که خودش داخل .dash-shell / .dash-content قرار دارد) رندر شود. اگر
// پنل به‌صورت position:absolute فرزند همان wrapper می‌ماند، هر عنصر اجدادی که
// overflow محدود، transform یا backdrop-filter داشته باشد (مثل کارت‌های .glass
// در داشبورد) یک «containing block» جدید می‌سازد و پنل را به‌جای کل صفحه، فقط
// داخل همان ظرف محدود نگه می‌دارد — دقیقاً همان باگی که باعث می‌شد پنل پشت
// سایدبار/هدر یا نیمه‌پنهان دیده شود.
// با createPortal، پنل مستقیماً زیر document.body مانت می‌شود (خارج از کل
// درخت DOM داشبورد/سایدبار/کارت‌ها) و موقعیت آن با position: fixed و مختصات
// محاسبه‌شده از getBoundingClientRect دکمه‌ی زنگوله (نه CSS نسبی) تعیین می‌شود؛
// بنابراین هرگز توسط هیچ container ای کلیپ نمی‌شود.
// آیکون زنگوله اعلان‌ها با نشان تعداد خوانده‌نشده — فقط وقتی کاربر وارد شده باشد نمایش داده می‌شود
export default function NotificationBell() {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [closing, setClosing] = useState(false); // در حال اجرای انیمیشن بسته‌شدن (پنل هنوز mount است)
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(false);
  const [navigatingId, setNavigatingId] = useState(null);
  const [unavailableId, setUnavailableId] = useState(null); // اعلانی که آیتم مرتبطش دیگر وجود ندارد
  const [anchorPos, setAnchorPos] = useState(null); // { top, left } — مختصات محاسبه‌شده نسبت به viewport
  const bellBtnRef = useRef(null); // دکمه‌ی زنگوله (برای محاسبه‌ی موقعیت پنل)
  const panelRef = useRef(null); // پنل پورتال‌شده (برای تشخیص کلیک بیرون)
  const closeTimerRef = useRef(null);
  const PANEL_CLOSE_ANIM_MS = 180; // باید با مدت انیمیشن notif-panel-out در index.css هماهنگ باشد

  useEffect(() => {
    if (!isAuthenticated) return undefined;

    let cancelled = false;
    async function fetchUnreadCount() {
      try {
        const data = await apiRequest("/users/notifications/unread-count");
        if (!cancelled) setUnreadCount(data.unreadCount || 0);
      } catch (err) {
        // خطای شبکه هنگام بررسی دوره‌ای نباید رابط کاربری را مختل کند
      }
    }

    fetchUnreadCount();
    const interval = setInterval(() => {
      if (!document.hidden) fetchUnreadCount(); // تب پس‌زمینه درخواست نمی‌فرستد
    }, POLL_INTERVAL_MS);
    const onVisible = () => { if (!document.hidden) fetchUnreadCount(); };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      cancelled = true;
      clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [isAuthenticated]);

  // محاسبه‌ی موقعیت پنل درست زیر دکمه‌ی زنگوله، با در نظر گرفتن مختصات واقعی آن در
  // viewport (نه نسبت به یک ظرف محدود) و کلمپ‌کردن در محدوده‌ی صفحه تا از سرریز
  // افقی/عمودی جلوگیری شود.
  const updateAnchorPos = useCallback(() => {
    const btn = bellBtnRef.current;
    if (!btn) return;
    const rect = btn.getBoundingClientRect();
    // بعد از اولین رندر پنل، عرض واقعی آن (که می‌تواند در موبایل با calc(100vw - 24px)
    // متفاوت از PANEL_WIDTH ثابت باشد) برای محاسبه‌ی دقیق‌تر کلمپ استفاده می‌شود
    const panelWidth = panelRef.current ? panelRef.current.offsetWidth : PANEL_WIDTH;

    // هم‌راستا با لبه‌ی سمت «پایان» دکمه (در RTL یعنی لبه‌ی چپ) — همان جهتی که پنل
    // پیش از این با inset-inline-end: 0 باز می‌شد — و سپس کلمپ در بازه‌ی امن صفحه.
    let left = rect.left;
    const maxLeft = window.innerWidth - panelWidth - PANEL_MARGIN;
    if (left > maxLeft) left = maxLeft;
    if (left < PANEL_MARGIN) left = PANEL_MARGIN;

    let top = rect.bottom + PANEL_GAP;
    const maxTop = window.innerHeight - PANEL_MARGIN;
    if (top > maxTop) top = maxTop;

    setAnchorPos({ top, left });
  }, []);

  // وقتی پنل باز است: موقعیت را بلافاصله محاسبه کن و روی تغییر اندازه/اسکرول
  // (حتی اسکرول داخل کانتینرهای تودرتوی داشبورد، به‌لطف فاز capture) به‌روز نگه دار
  useLayoutEffect(() => {
    if (!open) return undefined;
    updateAnchorPos();
    window.addEventListener("resize", updateAnchorPos);
    window.addEventListener("scroll", updateAnchorPos, true);
    return () => {
      window.removeEventListener("resize", updateAnchorPos);
      window.removeEventListener("scroll", updateAnchorPos, true);
    };
  }, [open, updateAnchorPos]);

  // بستن پنل با کلیک بیرون از آن (چون پنل اکنون پورتال‌شده، هم دکمه و هم خود پنل
  // پورتال‌شده باید از این بررسی مستثنی شوند)
  useEffect(() => {
    if (!open) return undefined;
    function handleClickOutside(e) {
      if (isScrollbarClick(e)) return;
      if (bellBtnRef.current && bellBtnRef.current.contains(e.target)) return;
      if (panelRef.current && panelRef.current.contains(e.target)) return;
      closePanel();
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [open]);

  // بستن پنل با کلید Escape
  useEffect(() => {
    if (!open) return undefined;
    function handleKeyDown(e) {
      if (e.key === "Escape") closePanel();
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [open]);

  // پاک‌سازی تایمر انیمیشن هنگام unmount شدن کامپوننت
  useEffect(() => {
    return () => {
      if (closeTimerRef.current) clearTimeout(closeTimerRef.current);
    };
  }, []);

  // بستن پنل همراه با اجرای انیمیشن fade/slide خروج پیش از حذف آن از DOM
  function closePanel() {
    setOpen((wasOpen) => {
      if (!wasOpen) return wasOpen;
      if (closeTimerRef.current) clearTimeout(closeTimerRef.current);
      setClosing(true);
      closeTimerRef.current = setTimeout(() => setClosing(false), PANEL_CLOSE_ANIM_MS);
      return false;
    });
  }

  async function openPanel() {
    if (closeTimerRef.current) {
      clearTimeout(closeTimerRef.current);
      closeTimerRef.current = null;
    }
    setClosing(false);
    setOpen(true);
    setLoading(true);
    try {
      const data = await apiRequest("/users/notifications");
      setNotifications(data.notifications);
      setUnreadCount(data.unreadCount || 0);
    } catch (err) {
      // اگر بارگذاری لیست ناموفق بود، پنل خالی نمایش داده می‌شود
    } finally {
      setLoading(false);
    }
  }

  function togglePanel() {
    if (open) {
      closePanel();
    } else {
      openPanel();
    }
  }

  // با کلیک روی یک اعلان: مقصد آن (صفحه/تب مرتبط) از بک‌اند گرفته می‌شود، اعلان
  // به‌صورت خودکار خوانده‌شده علامت می‌خورد و تعداد خوانده‌نشده‌ها به‌روز می‌شود.
  // اگر آیتم مرتبط دیگر وجود نداشته باشد، به‌جای هدایت، پیام مناسب نمایش داده می‌شود.
  async function handleNotificationClick(notification) {
    setUnavailableId(null);
    setNavigatingId(notification.id);
    try {
      const data = await apiRequest(`/users/notifications/${notification.id}/target`);

      // در هر صورت اعلان اکنون خوانده‌شده است؛ وضعیت محلی و شمارنده به‌روز می‌شود
      setNotifications((prev) => prev.map((n) => (n.id === notification.id ? { ...n, isRead: 1 } : n)));
      setUnreadCount(data.unreadCount || 0);

      if (!data.exists || !data.route) {
        setUnavailableId(notification.id);
        return;
      }

      const { path, tab, highlightId } = data.route;
      const params = new URLSearchParams();
      if (tab) params.set("tab", tab);
      if (highlightId) params.set("highlight", String(highlightId));
      const qs = params.toString();

      closePanel();
      navigate(qs ? `${path}?${qs}` : path);
    } catch (err) {
      // نادیده گرفته می‌شود؛ کاربر می‌تواند دوباره تلاش کند
    } finally {
      setNavigatingId(null);
    }
  }

  async function handleMarkAllRead() {
    try {
      await apiRequest("/users/notifications/read-all", { method: "PUT" });
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: 1 })));
      setUnreadCount(0);
    } catch (err) {
      // نادیده گرفته می‌شود
    }
  }

  if (!isAuthenticated) return null;

  const panelVisible = open || closing;

  return (
    <div className="notif-bell-wrapper">
      <button
        type="button"
        className="notif-bell-btn"
        onClick={togglePanel}
        aria-label={tr("اعلان‌ها")}
        aria-expanded={open}
        ref={bellBtnRef}
      >
        🔔
        {unreadCount > 0 && <span className="notif-badge">{unreadCount > 99 ? "99+" : unreadCount}</span>}
      </button>

      {panelVisible &&
        anchorPos &&
        createPortal(
          <>
            {/* پوشش نیمه‌شفاف تیره پشت پنل — علاوه بر گرفتن کلیک بیرون، تمرکز بصری
                کاربر را روی پنل نگه می‌دارد؛ کاملاً شفاف نیست اما محتوای پشت را کاملاً
                هم پنهان نمی‌کند (متفاوت از overlay مودال‌های مرکزی سایت) */}
            <div className="notif-overlay" onClick={closePanel} role="presentation" />
            <div
              ref={panelRef}
              className={`notif-panel glass ${closing ? "notif-panel-closing" : "notif-panel-opening"}`}
              role="menu"
              style={{ top: anchorPos.top, left: anchorPos.left }}
            >
              <div className="notif-panel-head">
                <h3>{tr("اعلان‌ها")}</h3>
                <div className="notif-panel-head-actions">
                  {unreadCount > 0 && (
                    <button type="button" className="notif-mark-all" onClick={handleMarkAllRead}>{tr("علامت‌گذاری همه به‌عنوان خوانده‌شده")}</button>
                  )}
                  <button type="button" className="notif-panel-close" onClick={closePanel} aria-label={tr("بستن")}>
                    <X size={16} />
                  </button>
                </div>
              </div>

              <div className="notif-list">
                {loading && <p className="notif-empty">{tr("در حال بارگذاری...")}</p>}
                {!loading && notifications.length === 0 && <p className="notif-empty">{tr("اعلانی وجود ندارد.")}</p>}
                {!loading &&
                  notifications.map((n) => (
                    <div key={n.id}>
                      <button
                        type="button"
                        className={`notif-item ${n.isRead ? "" : "unread"}`}
                        disabled={navigatingId === n.id}
                        onClick={() => handleNotificationClick(n)}
                      >
                        <span className="notif-icon">{TYPE_ICON[n.type] || TYPE_ICON.general}</span>
                        <span className="notif-body">
                          <strong>{n.title}</strong>
                          <span>{n.message}</span>
                          <span className="notif-time">{timeAgo(n.createdAt)}</span>
                        </span>
                        {!n.isRead && <span className="notif-dot" />}
                      </button>
                      {unavailableId === n.id && (
                        <div className="notif-unavailable">This item is no longer available.</div>
                      )}
                    </div>
                  ))}
              </div>
            </div>
          </>,
          document.body
        )}
    </div>
  );
}

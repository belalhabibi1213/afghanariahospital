import { useState } from "react";
import { Clock, Mail, MapPin, Phone, Send } from "lucide-react";
import { API_BASE, authFetch } from "../utils/api.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../i18n/useLocalizedSettings.js";

const API_URL = `${API_BASE}/contacts`;

export default function Contact() {
  const { settings } = useLocalizedSettings();
  const { t, tm } = useLanguage();
  const [form, setForm] = useState({ fullName: "", phone: "", email: "", type: "other", subject: "", message: "" });
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ type: "", text: "" });

    if (!form.fullName || !form.message) {
      setStatus({ type: "error", text: t("contact.required") });
      return;
    }

    setLoading(true);
    try {
      const res = await authFetch(API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!res.ok) {
        setStatus({ type: "error", text: tm(data.message) || t("contact.failed") });
        return;
      }

      setStatus({ type: "success", text: t("contact.success") });
      setForm({ fullName: "", phone: "", email: "", type: "other", subject: "", message: "" });
    } catch (err) {
      setStatus({
        type: "error",
        text: t("common.serverUnreachable"),
      });
    } finally {
      setLoading(false);
    }
  }

  const info = [
    { key: "address", Icon: MapPin, label: t("contact.address"), value: settings.hospitalAddress },
    { key: "phone", Icon: Phone, label: t("contact.phone"), value: settings.hospitalPhone, ltr: true },
    { key: "email", Icon: Mail, label: t("contact.email"), value: settings.hospitalEmail, ltr: true },
    { key: "hours", Icon: Clock, label: t("contact.hours"), value: t("contact.hoursValue") },
  ].filter((row) => row.value);

  return (
    <section id="contact" className="pub-section pub-section--alt ct">
      <div className="container">
        <div className="pub-head">
          <div className="pub-head-text">
            <span className="pub-eyebrow">{t("contact.eyebrow")}</span>
            <h2>{t("contact.title")}</h2>
          </div>
        </div>

        <div className="ct-grid">
          <ul className="ct-info pub-card">
            {info.map(({ key, Icon, label, value, ltr }) => (
              <li className="ct-row" key={key}>
                <span className="pub-icon"><Icon size={20} strokeWidth={1.8} aria-hidden="true" /></span>
                <div>
                  <b>{label}</b>
                  <span dir={ltr ? "ltr" : undefined} className={ltr ? "ct-ltr" : undefined}>{value}</span>
                </div>
              </li>
            ))}
          </ul>

          <form className="ct-form pub-card" onSubmit={handleSubmit}>
            {status.text && (
              <div className={`form-message ${status.type}`} role={status.type === "error" ? "alert" : "status"}>{status.text}</div>
            )}

            <div className="field-row">
              <div className="field">
                <label htmlFor="ct-fullName">{t("contact.fullName")}</label>
                <input id="ct-fullName" type="text" placeholder={t("contact.fullNamePlaceholder")} value={form.fullName} onChange={(e) => update("fullName", e.target.value)} />
              </div>
              <div className="field">
                <label htmlFor="ct-phone">{t("contact.phoneLabel")}</label>
                <input id="ct-phone" type="tel" placeholder={t("contact.phonePlaceholder")} value={form.phone} onChange={(e) => update("phone", e.target.value)} />
              </div>
            </div>
            <div className="field">
              <label htmlFor="ct-email">{t("contact.email")}</label>
              <input id="ct-email" type="email" placeholder={t("contact.emailPlaceholder")} value={form.email} onChange={(e) => update("email", e.target.value)} />
            </div>
            <div className="field-row">
              <div className="field">
                <label htmlFor="ct-type">{t("contact.type")}</label>
                <select id="ct-type" value={form.type} onChange={(e) => update("type", e.target.value)}>
                  <option value="question">{t("contact.types.question")}</option>
                  <option value="suggestion">{t("contact.types.suggestion")}</option>
                  <option value="criticism">{t("contact.types.criticism")}</option>
                  <option value="complaint">{t("contact.types.complaint")}</option>
                  <option value="other">{t("contact.types.other")}</option>
                </select>
              </div>
              <div className="field">
                <label htmlFor="ct-subject">{t("contact.subject")}</label>
                <input id="ct-subject" type="text" maxLength={200} placeholder={t("contact.subjectPlaceholder")} value={form.subject} onChange={(e) => update("subject", e.target.value)} />
              </div>
            </div>
            <div className="field">
              <label htmlFor="ct-message">{t("contact.message")}</label>
              <textarea id="ct-message" rows="4" placeholder={t("contact.messagePlaceholder")} value={form.message} onChange={(e) => update("message", e.target.value)} />
            </div>
            <button type="submit" className="pub-btn pub-btn--primary ct-submit" disabled={loading}>
              <Send size={16} className="pub-flip" aria-hidden="true" />
              {loading ? t("contact.sending") : t("contact.send")}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

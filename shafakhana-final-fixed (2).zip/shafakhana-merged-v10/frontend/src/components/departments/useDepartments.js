import { useEffect, useState } from "react";
import { API_BASE } from "../../utils/api.js";

// فقط بخش‌های فعال و «نمایش در سایت اصلی»=۱؛ فیلتر و ترتیب در بک‌اند انجام می‌شود
// (همان دیتای واقعی پنل «مدیریت بخش‌ها»، بدون هیچ داده‌ی ثابت در فرانت‌اند)
const API_URL = `${API_BASE}/departments?public=1`;

export default function useDepartments() {
  const [departments, setDepartments] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ok | error

  useEffect(() => {
    let cancelled = false;
    fetch(API_URL)
      .then((res) => {
        if (!res.ok) throw new Error("bad response");
        return res.json();
      })
      .then((data) => {
        if (cancelled) return;
        setDepartments(Array.isArray(data.departments) ? data.departments : []);
        setStatus("ok");
      })
      .catch(() => {
        if (!cancelled) setStatus("error");
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return { departments, status };
}

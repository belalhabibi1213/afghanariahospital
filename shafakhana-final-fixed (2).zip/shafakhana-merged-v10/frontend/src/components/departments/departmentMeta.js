import { resolvePhotoUrl } from "../../utils/api.js";

// ظاهر (رنگ تأکیدی + آیکون پیش‌فرض + عکس پیش‌فرض) هر بخش در کارت‌های عمومی «بخش‌های تخصصی».
// فقط ظاهر است؛ نام، توضیح و آیکون ثبت‌شده‌ی بخش همیشه از دیتابیس می‌آید و این نگاشت
// هیچ بخشی را اضافه یا حذف نمی‌کند. بخش ناشناخته (مثلاً بخش جدیدی که ادمین ساخته)
// با یک ظاهر پیش‌فرض و رنگ چرخشی نمایش داده می‌شود.
// رنگ‌ها مطابق طرح جدید: صورتی، قرمز، آبی، سبز-فیروزه‌ای، بنفش، فیروزه‌ای، نیلی.
export const ACCENTS = ["blue", "teal", "cyan", "purple", "pink", "red", "navy"];

// ترتیب مهم است: اولین کلمه‌ی کلیدیِ منطبق برنده است.
const RULES = [
  { match: ["قلب", "cardio"], accent: "red", icon: "HeartPulse" },
  { match: ["اطفال", "کودک", "pediat"], accent: "blue", icon: "Stethoscope" },
  { match: ["زنان", "زایمان", "نسا", "ولادی", "obstet", "gynec"], accent: "pink", icon: "Baby" },
  { match: ["جراح", "surg"], accent: "teal", icon: "Scissors" },
  { match: ["رادیو", "سونو", "تصویربرداری", "radiol"], accent: "cyan", icon: "Scan" },
  { match: ["لابراتوار", "آزمایش", "lab"], accent: "purple", icon: "FlaskConical" },
  { match: ["داخل", "internal"], accent: "navy", icon: "BedDouble" },
  { match: ["گوش", "حلق", "بینی", "otolaryng", "ear nose"], accent: "purple", icon: "Ear" },
  { match: ["چشم", "ophthal"], accent: "cyan", icon: "Eye" },
  { match: ["اعصاب", "مغز", "neuro"], accent: "purple", icon: "Brain" },
  { match: ["ارتوپ", "استخوان", "ortho"], accent: "blue", icon: "Bone" },
  { match: ["دندان", "dent"], accent: "cyan", icon: "ShieldPlus" },
  { match: ["پوست", "derma"], accent: "pink", icon: "HandHeart" },
  { match: ["اورژانس", "emerg"], accent: "red", icon: "Ambulance" },
  { match: ["فزیو", "physio"], accent: "teal", icon: "Accessibility" },
  { match: ["تغذیه", "nutri"], accent: "teal", icon: "Droplet" },
  { match: ["روان", "psych"], accent: "purple", icon: "Brain" },
];

// عکس پیش‌فرض هر تخصص (کلید = اولین کلمه‌ی کلیدی قاعده، یعنی match[0]).
// اگر ادمین برای یک بخش «عکس کاور» آپلود کند (department.coverImage)، همان بر این عکس‌ها اولویت دارد.
// برای تعویض با عکس باکیفیت‌تر: فایل را در public/images/departments/ بگذارید و مسیرش را اینجا عوض کنید.
export const COVER_PHOTOS = {
  "قلب": "/images/departments/cardiology.jpg",
  "اطفال": "/images/departments/pediatrics.jpg",
  "زنان": "/images/departments/obstetrics.jpg",
  "جراح": "/images/departments/surgery.jpg",
  "رادیو": "/images/departments/radiology.jpg",
  "لابراتوار": "/images/departments/laboratory.jpg",
  "داخل": "/images/departments/internal.jpg",
  "گوش": "/images/departments/ent.jpg",
};

function normalize(s) {
  return String(s || "")
    .replace(/ي/g, "ی").replace(/ك/g, "ک").replace(/\u200c/g, " ")
    .replace(/\s+/g, " ").trim().toLowerCase();
}

export function getDepartmentMeta(department) {
  const hay = `${normalize(department?.name)} ${normalize(department?.nameEn)}`;
  // عکس کاور آپلودشده توسط ادمین، بر عکس پیش‌فرض تخصص اولویت دارد
  const uploadedCover = resolvePhotoUrl(department?.coverImage);
  for (const rule of RULES) {
    if (rule.match.some((k) => hay.includes(normalize(k)))) {
      return { accent: rule.accent, icon: rule.icon, photo: uploadedCover || COVER_PHOTOS[rule.match[0]] || null };
    }
  }
  const id = Number(department?.id) || 0;
  return { accent: ACCENTS[id % ACCENTS.length], icon: "Stethoscope", photo: uploadedCover || null };
}

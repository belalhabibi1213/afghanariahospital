import { describe, it, expect } from "vitest";
import { getDepartmentMeta, ACCENTS } from "./departmentMeta.js";

describe("departmentMeta", () => {
  it("تخصص‌های شناخته‌شده را به آیکون و رنگ مناسب می‌رساند (املای عربی هم)", () => {
    expect(getDepartmentMeta({ id: 1, name: "قلب و عروق" })).toMatchObject({ accent: "red", icon: "HeartPulse" });
    expect(getDepartmentMeta({ id: 2, name: "اطفال" }).icon).toBe("Stethoscope");
    expect(getDepartmentMeta({ id: 3, name: "زنان و زایمان" }).accent).toBe("pink");
    expect(getDepartmentMeta({ id: 4, name: "گوش، حلق و بینی" }).icon).toBe("Ear");
    expect(getDepartmentMeta({ id: 5, name: "داخلي" }).icon).toBe("BedDouble"); // «ي» عربی
  });

  it("بخش ناشناخته ظاهر پیش‌فرض و رنگ چرخشی معتبر می‌گیرد و بدون عکس است", () => {
    const m = getDepartmentMeta({ id: 7, name: "بخش کاملاً جدید" });
    expect(m.icon).toBe("Stethoscope");
    expect(ACCENTS).toContain(m.accent);
    expect(m.photo).toBeNull();
  });

  it("عکس پیش‌فرض تخصص‌های شناخته‌شده را می‌دهد و عکس کاور آپلودی ادمین بر آن اولویت دارد", () => {
    expect(getDepartmentMeta({ id: 1, name: "قلب و عروق" }).photo).toBe("/images/departments/cardiology.jpg");
    const custom = getDepartmentMeta({ id: 1, name: "قلب و عروق", coverImage: "https://cdn.example.com/c.jpg" });
    expect(custom.photo).toBe("https://cdn.example.com/c.jpg");
    // بخش ناشناخته هم با عکس کاور آپلودی عکس می‌گیرد
    expect(getDepartmentMeta({ id: 9, name: "بخش کاملاً جدید", coverImage: "https://cdn.example.com/n.jpg" }).photo).toBe("https://cdn.example.com/n.jpg");
  });

  it("با ورودی خالی خطا نمی‌دهد", () => {
    expect(() => getDepartmentMeta(undefined)).not.toThrow();
  });
});

import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { resolvePhotoUrl } from "../../utils/api.js";
import { useLanguage } from "../../context/LanguageContext.jsx";
import { DepartmentLucideIcon, DEPARTMENT_ICONS } from "../dashboard/DepartmentIconPicker.jsx";
import { getDepartmentMeta } from "./departmentMeta.js";

// آیکون شناور کارت: ۱) آیکون آپلودی ادمین  ۲) آیکون Lucide انتخاب‌شده‌ی ادمین
// ۳) در نبود هر دو، آیکون پیش‌فرض متناسب با تخصص (فقط نمایشی؛ رکورد بخش تغییر نمی‌کند)
export function DepartmentIcon({ department, fallbackName, size = 28 }) {
  const [broken, setBroken] = useState(false); // فایل آیکون آپلودی در دسترس نیست → آیکون پیش‌فرض
  const uploaded = department.iconType === "upload" && !broken ? resolvePhotoUrl(department.icon) : null;
  if (uploaded) return <img src={uploaded} alt="" width={size} height={size} loading="lazy" onError={() => setBroken(true)} />;
  if (department.iconType === "lucide" && DEPARTMENT_ICONS[department.icon]) {
    return <DepartmentLucideIcon name={department.icon} size={size} />;
  }
  return <DepartmentLucideIcon name={fallbackName} size={size} />;
}

// ناحیه‌ی تصویری (عکس اختیاری از COVER_PHOTOS یا طرح گرادیانی با آیکون بزرگ)
export function DepartmentCover({ meta, eager = false, className = "dpt-media" }) {
  const BigIcon = DEPARTMENT_ICONS[meta.icon];
  return (
    <div
      className={`${className}${meta.photo ? " dpt-has-photo" : ""}`}
      style={meta.photo ? { "--dpt-photo": `url("${String(meta.photo).replace(/"/g, "%22")}")` } : undefined}
      aria-hidden="true"
    >
      {meta.photo ? (
        <img src={meta.photo} alt="" width="640" height="360" loading={eager ? "eager" : "lazy"} decoding="async" />
      ) : (
        <>
          <span className="dpt-pattern" />
          {BigIcon && <BigIcon className="dpt-media-icon" size={120} strokeWidth={1.1} />}
        </>
      )}
    </div>
  );
}

export default function DepartmentCard({ department, index = 0 }) {
  const { t, dept, loc } = useLanguage();
  const meta = getDepartmentMeta(department);
  const name = dept(department.name);
  const hasUploadedIcon = department.iconType === "upload" && !!department.icon;

  return (
    <li className="dpt-item">
      <article className={`dpt-card dpt-accent-${meta.accent}`}>
        {/* ناحیه‌ی تصویر + دایره‌ی رنگی آیکون که روی لبه‌ی پایین عکس می‌نشیند */}
        <div className="dpt-top">
          <DepartmentCover meta={meta} eager={index < 4} />
          <span className={`dpt-icon${hasUploadedIcon ? " dpt-icon--upload" : ""}`} aria-hidden="true">
            <DepartmentIcon department={department} fallbackName={meta.icon} size={32} />
          </span>
        </div>
        <div className="dpt-body">
          <h3>{name}</h3>
          <p>{loc(department, "description") || t("services.defaultDescription")}</p>
          <Link to={`/departments/${department.id}`} className="dpt-link">
            <span aria-hidden="true">{t("services.viewDetails")}</span>
            <span className="dpt-sr">{t("services.viewDetailsFor", { name })}</span>
            <ArrowLeft className="dpt-arrow" size={16} aria-hidden="true" />
          </Link>
        </div>
      </article>
    </li>
  );
}

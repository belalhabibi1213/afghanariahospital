import { useState } from "react";
import { Eye, EyeOff } from "lucide-react";

// فیلد رمز عبور با دکمه‌ی «نمایش/پنهان‌کردن رمز». همه‌ی propهای input را می‌پذیرد.
export default function PasswordInput(props) {
  const [show, setShow] = useState(false);
  const label = show ? "پنهان‌کردن رمز عبور / Hide password" : "نمایش رمز عبور / Show password";
  return (
    <div className="pw-wrap">
      <input {...props} type={show ? "text" : "password"} />
      <button type="button" className="pw-toggle" onClick={() => setShow((s) => !s)} aria-label={label} title={label} tabIndex={-1}>
        {show ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  );
}

import { useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";

import { tr } from "../i18n/tr.js";
// ============================================================================
// GlobalModal — سیستم مودال استاندارد و یکپارچه‌ی کل سایت
// ============================================================================
// این کامپوننت تنها نسخه‌ی رسمی «پنجره‌ی بازشو» (Popup/Dialog) در کل پروژه است.
// همه‌ی پاپ‌آپ‌های موجود (اعلان‌ها، پیام‌های تماس، سوابق طبی، نسخه‌ها، انتقال
// فایل بیماران، فاکتورها، اخبار، پروفایل کاربر و هر مودال آینده‌ای) باید از همین
// کامپوننت استفاده کنند تا رفتار و ظاهر یکدست باشد.
//
// چرا Portal؟
// کارت‌های داشبورد از کلاس .glass با backdrop-filter استفاده می‌کنند و برخی
// container ها overflow محدود دارند. filter/backdrop-filter روی یک عنصر
// اجدادی، «containing block» جدیدی برای فرزندان position:fixed می‌سازد؛ یعنی
// بدون Portal، مودال به‌جای کل صفحه فقط داخل همان container محدود می‌ماند و
// بخشی از آن زیر سایدبار/هدر پنهان می‌شود. با createPortal مستقیماً به
// document.body وصل می‌شود و همیشه بالاترین لایه‌ی کل سایت باقی می‌ماند.
//
// نحوه استفاده:
//   ۱) حالت استاندارد (هدر + بدنه‌ی اسکرول‌شونده + فوتر اختیاری):
//        <GlobalModal isOpen={open} onClose={close} title="جزئیات">
//          ...محتوا...
//        </GlobalModal>
//
//   ۲) حالت آزاد (raw) — وقتی محتوا هدر/دکمه‌ی بستن اختصاصی خودش را دارد و فقط
//      لایه‌ی Portal/Overlay/انیمیشن/تم لازم است (title را ندهید):
//        <GlobalModal isOpen={open} onClose={close} labelledBy="my-title" bare>
//          <div className="gmodal-header">...</div>
//          <div className="gmodal-body">...</div>
//        </GlobalModal>
export default function GlobalModal({
  isOpen = true,
  onClose,
  title,
  children,
  footer,
  size = "md", // sm | md | lg | xl
  className = "",
  overlayClassName = "",
  closeOnOverlayClick = true,
  closeOnEsc = true,
  hideCloseButton = false,
  bare = false, // اگر true باشد، هدر/بدنه/فوتر خودکار ساخته نمی‌شود و children عیناً رندر می‌شود
  labelledBy,
}) {
  const titleId = useRef(`gmodal-title-${Math.random().toString(36).slice(2, 9)}`).current;

  // بستن با کلید Escape — استاندارد تجربه‌کاربری برای همه‌ی دیالوگ‌ها
  useEffect(() => {
    if (!isOpen || !closeOnEsc) return undefined;
    function handleKeyDown(e) {
      if (e.key === "Escape") onClose && onClose();
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, closeOnEsc, onClose]);

  // وقتی مودال باز است، اسکرول پس‌زمینه‌ی صفحه قفل می‌شود تا فقط بدنه‌ی مودال اسکرول شود
  useEffect(() => {
    if (!isOpen) return undefined;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prevOverflow;
    };
  }, [isOpen]);

  if (!isOpen) return null;

  function handleOverlayClick() {
    if (closeOnOverlayClick && onClose) onClose();
  }

  const content = (
    <div
      className={`gmodal-overlay ${overlayClassName}`}
      role="presentation"
      onClick={handleOverlayClick}
    >
      <div
        className={`gmodal gmodal-${size} ${className}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy || (title ? titleId : undefined)}
        onClick={(e) => e.stopPropagation()}
      >
        {bare ? (
          children
        ) : (
          <>
            <div className="gmodal-header">
              {title ? <h3 id={titleId}>{title}</h3> : <span />}
              {!hideCloseButton && (
                <button type="button" className="gmodal-close" onClick={onClose} aria-label={tr("بستن")}>
                  <X size={18} />
                </button>
              )}
            </div>
            <div className="gmodal-body">{children}</div>
            {footer && <div className="gmodal-footer">{footer}</div>}
          </>
        )}
      </div>
    </div>
  );

  return createPortal(content, document.body);
}

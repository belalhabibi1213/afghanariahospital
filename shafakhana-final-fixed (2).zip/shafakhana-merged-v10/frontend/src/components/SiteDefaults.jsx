import { useEffect } from "react";
import { useSiteSettings } from "../context/SettingsContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";

// زبان پیش‌فرض سایت را (تنظیمات سیستم ← ظاهر و زبان) بعد از رسیدن تنظیمات اعمال می‌کند؛
// فقط برای بازدیدکننده‌ای که خودش زبانی انتخاب نکرده. چیزی رندر نمی‌کند.
export default function SiteDefaults() {
  const { settings, loading } = useSiteSettings();
  const { setDefaultLang } = useLanguage();
  useEffect(() => {
    if (!loading && setDefaultLang) setDefaultLang(settings.defaultLanguage);
  }, [loading, settings.defaultLanguage, setDefaultLang]);
  return null;
}

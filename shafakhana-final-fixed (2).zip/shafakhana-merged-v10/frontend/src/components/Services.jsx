import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Clock, HeartPulse, Hospital, LayoutGrid, ShieldCheck, Stethoscope, UsersRound } from "lucide-react";
import { API_BASE } from "../utils/api.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import { photos } from "../data/photos.js";
import DepartmentCard from "./departments/DepartmentCard.jsx";
import useDepartments from "./departments/useDepartments.js";
import "./departments/Departments.css";

const DOCTORS_URL = `${API_BASE}/doctors`;
// در صفحه‌ی اصلی حداکثر این تعداد کارت (دو ردیف ۴تایی) نمایش داده می‌شود؛ بقیه در صفحه‌ی «همه بخش‌ها»
const HOME_DEPARTMENTS_LIMIT = 8;

// پنل آمار شناور داخل هیرو؛ فقط آمارهایی که واقعاً از سرور رسیده‌اند نمایش داده می‌شوند
// (تعداد بخش‌ها از همان لیست بخش‌ها، تعداد داکتران از GET /api/doctors)
export function DepartmentsStats({ departmentCount }) {
  const { t, formatNumber } = useLanguage();
  const [doctorCount, setDoctorCount] = useState(null);

  useEffect(() => {
    let cancelled = false;
    fetch(DOCTORS_URL)
      .then((res) => (res.ok ? res.json() : Promise.reject(new Error("bad response"))))
      .then((data) => {
        if (!cancelled && Array.isArray(data.doctors) && data.doctors.length > 0) setDoctorCount(data.doctors.length);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, []);

  const stats = [];
  if (doctorCount) stats.push({ key: "doctors", Icon: Stethoscope, value: doctorCount, label: t("services.statDoctors") });
  if (departmentCount > 0) stats.push({ key: "departments", Icon: Hospital, value: departmentCount, label: t("services.statDepartments") });
  if (stats.length === 0) return null;

  return (
    <ul className="dpt-stats" aria-label={t("services.statsLabel")}>
      {stats.map(({ key, Icon, value, label }) => (
        <li key={key} className="dpt-stat">
          <span className="dpt-stat-icon" aria-hidden="true"><Icon size={26} strokeWidth={1.6} /></span>
          <strong>{formatNumber(value)}</strong>
          <span className="dpt-stat-label">{label}</span>
        </li>
      ))}
    </ul>
  );
}

// هیروی مشترک بخش‌ها (صفحه‌ی اصلی و صفحه‌ی «همه بخش‌ها»): متن + پنل آمار
export function DepartmentsHero({ headingTag: Heading = "h2", departmentCount = 0 }) {
  const { t } = useLanguage();
  return (
    <div className="dpt-hero">
      <img className="dpt-hero-img" src={photos.heroBuilding} alt="" width="1080" height="592" loading="lazy" decoding="async" />
      <div className="dpt-hero-overlay" aria-hidden="true" />
      <div className="container dpt-hero-inner">
        <div className="dpt-hero-text">
          <span className="dpt-eyebrow">{t("services.eyebrow")}</span>
          <Heading id="dpt-title">{t("services.title")}</Heading>
          <p>{t("services.subtitle")}</p>
        </div>
        <DepartmentsStats departmentCount={departmentCount} />
      </div>
    </div>
  );
}

// نوار ویژگی‌های پایین بخش (کیفیت، دسترسی، تیم، تجهیزات)
export function DepartmentsFeatures() {
  const { t } = useLanguage();
  const items = [
    { key: "quality", Icon: ShieldCheck },
    { key: "access", Icon: Clock },
    { key: "team", Icon: UsersRound },
    { key: "equip", Icon: HeartPulse },
  ];
  return (
    <ul className="dpt-features" aria-label={t("services.featuresLabel")}>
      {items.map(({ key, Icon }) => (
        <li key={key} className="dpt-feature">
          <span className="dpt-feature-icon" aria-hidden="true"><Icon size={34} strokeWidth={1.5} /></span>
          <span className="dpt-feature-text">
            <strong>{t(`services.feature${key[0].toUpperCase()}${key.slice(1)}Title`)}</strong>
            <span>{t(`services.feature${key[0].toUpperCase()}${key.slice(1)}Text`)}</span>
          </span>
        </li>
      ))}
    </ul>
  );
}

// نمایش وضعیت‌های loading / error / empty + شبکه‌ی کارت‌ها
export function DepartmentsGrid({ departments, status, limit }) {
  const { t } = useLanguage();
  const shown = limit ? departments.slice(0, limit) : departments;
  return (
    <>
      {status === "loading" && <p className="dpt-state" role="status">{t("services.loading")}</p>}
      {status === "error" && <p className="dpt-state" role="alert">{t("common.serverUnreachableDb")}</p>}
      {status === "ok" && departments.length === 0 && <p className="dpt-state">{t("services.empty")}</p>}
      {status === "ok" && departments.length > 0 && (
        <ul className="dpt-grid">
          {shown.map((d, i) => (
            <DepartmentCard key={d.id} department={d} index={i} />
          ))}
        </ul>
      )}
    </>
  );
}

export default function Services() {
  const { t } = useLanguage();
  const { departments, status } = useDepartments();

  return (
    <section id="services" className="dpt" aria-labelledby="dpt-title">
      <DepartmentsHero departmentCount={status === "ok" ? departments.length : 0} />
      <div className="container dpt-main">
        <DepartmentsGrid departments={departments} status={status} limit={HOME_DEPARTMENTS_LIMIT} />
        {status === "ok" && departments.length > 0 && (
          <div className="dpt-more">
            <Link to="/departments" className="dpt-more-btn">
              <LayoutGrid className="dpt-more-icon" size={17} aria-hidden="true" />
              <span>{t("departmentPage.viewAll")}</span>
            </Link>
          </div>
        )}
        <DepartmentsFeatures />
      </div>
    </section>
  );
}

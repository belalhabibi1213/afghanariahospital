import { Component } from "react";

import { tr } from "../i18n/tr.js";
export default class SectionErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.error("خطا در بخش:", this.props.label || "", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="container" style={{ padding: "40px 0", textAlign: "center" }}>
          <p style={{ color: "var(--text-2)" }}>{tr("بارگذاری این بخش با مشکل مواجه شد. لطفاً صفحه را دوباره بارگذاری کنید.")}</p>
        </div>
      );
    }
    return this.props.children;
  }
}

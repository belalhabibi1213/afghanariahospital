import { describe, it, expect, vi } from "vitest";
import { screen, waitFor } from "@testing-library/react";
import { Route } from "react-router-dom";
import ProtectedRoute from "./ProtectedRoute.jsx";
import { renderWithProviders, jsonResponse } from "../test/renderWithProviders.jsx";
import { USER_KEY } from "../utils/api.js";

function setup(route, allowedRoles, loggedInAs) {
  if (loggedInAs) {
    const user = { id: 1, fullName: "x", role: loggedInAs };
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue(jsonResponse(200, { user, csrfToken: "c" })));
  } else {
    vi.stubGlobal("fetch", vi.fn());
  }
  return renderWithProviders(null, {
    route,
    routes: (
      <>
        <Route path="/login" element={<div>صفحه ورود</div>} />
        <Route path="/403" element={<div>دسترسی مسدود</div>} />
        <Route
          path="/dashboard/admin"
          element={<ProtectedRoute allowedRoles={allowedRoles}><div>داشبورد ادمین</div></ProtectedRoute>}
        />
      </>
    ),
  });
}

describe("ProtectedRoute", () => {
  it("مهمان به /login هدایت می‌شود", async () => {
    setup("/dashboard/admin", ["admin"], null);
    await screen.findByText("صفحه ورود");
    expect(screen.getByTestId("location")).toHaveTextContent("/login");
  });

  it("نقش نامناسب به /403 هدایت می‌شود و محتوا نمایش داده نمی‌شود", async () => {
    setup("/dashboard/admin", ["admin"], "user");
    await screen.findByText("دسترسی مسدود");
    expect(screen.queryByText("داشبورد ادمین")).not.toBeInTheDocument();
  });

  it("نقش مجاز محتوا را می‌بیند", async () => {
    setup("/dashboard/admin", ["admin", "superadmin"], "admin");
    expect(await screen.findByText("داشبورد ادمین")).toBeInTheDocument();
  });

  it("allowedRoles خالی: هر کاربر واردشده‌ای مجاز است", async () => {
    setup("/dashboard/admin", [], "user");
    expect(await screen.findByText("داشبورد ادمین")).toBeInTheDocument();
  });

  it("در زمان بررسی نشست، محتوای محافظت‌شده لو نمی‌رود", async () => {
    const user = { id: 1, fullName: "x", role: "admin" };
    localStorage.setItem(USER_KEY, JSON.stringify(user));
    let release;
    vi.stubGlobal("fetch", vi.fn(() => new Promise((r) => { release = () => r(jsonResponse(200, { user, csrfToken: "c" })); })));
    renderWithProviders(null, {
      route: "/dashboard/admin",
      routes: <Route path="/dashboard/admin" element={<ProtectedRoute allowedRoles={["admin"]}><div>داشبورد ادمین</div></ProtectedRoute>} />,
    });
    expect(screen.getByText("در حال بررسی نشست کاربری...")).toBeInTheDocument();
    expect(screen.queryByText("داشبورد ادمین")).not.toBeInTheDocument();
    release();
    await waitFor(() => expect(screen.getByText("داشبورد ادمین")).toBeInTheDocument());
  });
});

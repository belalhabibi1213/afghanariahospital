import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import { useState } from "react";
import { JalaliDateInput, JalaliDateTimeInput } from "./JalaliDateInput.jsx";

function Harness({ initial = "2026-10-09", onChangeSpy, ...props }) {
  const [v, setV] = useState(initial);
  return <JalaliDateInput aria-label="تاریخ" value={v} onChange={(e) => { onChangeSpy?.(e.target.value); setV(e.target.value); }} {...props} />;
}

describe("JalaliDateInput", () => {
  it("مقدار میلادی را شمسی نشان می‌دهد", () => {
    render(<Harness />);
    expect(screen.getByLabelText("تاریخ").value).toBe("۱۴۰۵/۰۷/۱۷");
  });
  it("تقویم شمسی با نام ماه افغانی باز می‌شود و انتخاب روز مقدار میلادی می‌دهد", () => {
    const spy = vi.fn();
    render(<Harness onChangeSpy={spy} />);
    fireEvent.focus(screen.getByLabelText("تاریخ"));
    expect(screen.getByRole("dialog")).toBeTruthy();
    expect(screen.getByLabelText("ماه").value).toBe("7"); // میزان
    fireEvent.click(screen.getByLabelText(/۲۰ میزان ۱۴۰۵/));
    expect(spy).toHaveBeenCalledWith("2026-10-12");
    expect(screen.getByLabelText("تاریخ").value).toBe("۱۴۰۵/۰۷/۲۰");
  });
  it("تایپ تاریخ شمسی (ارقام لاتین) پس از blur ثبت می‌شود؛ نامعتبر برمی‌گردد", () => {
    const spy = vi.fn();
    render(<Harness onChangeSpy={spy} />);
    const input = screen.getByLabelText("تاریخ");
    fireEvent.change(input, { target: { value: "1405/08/01" } });
    fireEvent.blur(input);
    expect(spy).toHaveBeenLastCalledWith("2026-10-23");
    fireEvent.change(input, { target: { value: "1404/12/30" } }); // ۱۴۰۴ کبیسه نیست
    fireEvent.blur(input);
    expect(input.value).toBe("۱۴۰۵/۰۸/۰۱");
  });
  it("min/max را رعایت می‌کند", () => {
    const spy = vi.fn();
    render(<Harness onChangeSpy={spy} min="2026-10-01" max="2026-10-31" />);
    const input = screen.getByLabelText("تاریخ");
    fireEvent.change(input, { target: { value: "1405/09/01" } }); // ۲۲ نوامبر → خارج از بازه
    fireEvent.blur(input);
    expect(spy).not.toHaveBeenCalled();
    expect(input.value).toBe("۱۴۰۵/۰۷/۱۷");
  });
  it("پاک کردن مقدار", () => {
    const spy = vi.fn();
    render(<Harness onChangeSpy={spy} />);
    const input = screen.getByLabelText("تاریخ");
    fireEvent.change(input, { target: { value: "" } });
    fireEvent.blur(input);
    expect(spy).toHaveBeenLastCalledWith("");
  });
  it("JalaliDateTimeInput: مقدار datetime-local میلادی می‌ماند", () => {
    const spy = vi.fn();
    render(<JalaliDateTimeInput aria-label="زمان" value="2026-10-09T14:35" onChange={(e) => spy(e.target.value)} />);
    expect(screen.getByLabelText("زمان (تاریخ)").value).toBe("۱۴۰۵/۰۷/۱۷");
    fireEvent.change(screen.getByLabelText("زمان (ساعت)"), { target: { value: "09:10" } });
    expect(spy).toHaveBeenCalledWith("2026-10-09T09:10");
  });
});

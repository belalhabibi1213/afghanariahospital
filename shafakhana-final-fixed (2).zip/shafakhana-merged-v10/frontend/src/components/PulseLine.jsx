export default function PulseLine() {
  return (
    <div className="pulse-line">
      <svg viewBox="0 0 500 90" preserveAspectRatio="none" width="100%" height="100%">
        <polyline
          className="pulse-path"
          points="0,45 60,45 80,45 95,15 110,75 125,20 140,45 180,45 220,45 240,30 255,60 270,45 320,45 360,45 380,20 395,70 410,45 500,45"
        />
      </svg>
    </div>
  );
}

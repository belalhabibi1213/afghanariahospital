import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { AUTH_REQUIRED_EVENT } from "../utils/authGuard.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import GlobalModal from "./GlobalModal.jsx";

// این کامپوننت یک‌بار در ریشه‌ی برنامه (App.jsx) مانت می‌شود. هر جای سایت که تلاش یک
// مهمان (کاربر واردنشده) برای گرفتن نوبت را تشخیص می‌دهد، کافی است رویداد سراسری
// AUTH_REQUIRED_EVENT را پخش کند تا این مودال باز شود — بدون نیاز به انتقال state
// بین کامپوننت‌های مختلف (Navbar، Hero، Doctors، Footer، AppointmentSection).
// نمایش این مودال از طریق GlobalModal (مودال استاندارد سراسری) انجام می‌شود.
export default function LoginRequiredModal() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { t } = useLanguage();

  useEffect(() => {
    function handleAuthRequired() {
      setOpen(true);
    }
    window.addEventListener(AUTH_REQUIRED_EVENT, handleAuthRequired);
    return () => window.removeEventListener(AUTH_REQUIRED_EVENT, handleAuthRequired);
  }, []);

  function handleLogin() {
    setOpen(false);
    // همان الگوی ProtectedRoute/Login.jsx: مسیر فعلی در state ذخیره می‌شود تا بعد از
    // ورود موفق، کاربر دقیقاً به همان بخش نوبت‌دهی بازگردد (نه صرفاً بالای صفحه اصلی)
    navigate("/login", {
      state: { from: { pathname: location.pathname, search: location.search, hash: "#appointment" } },
    });
  }

  return (
    <GlobalModal
      isOpen={open}
      onClose={() => setOpen(false)}
      size="sm"
      className="login-required-modal"
      overlayClassName="login-required-overlay"
      labelledBy="login-required-title"
      bare
    >
      <h3 id="login-required-title">{t("modals.loginRequired.title")}</h3>
      <p>{t("modals.loginRequired.text")}</p>
      <div className="modal-actions">
        <button type="button" className="btn btn-primary" onClick={handleLogin}>{t("modals.loginRequired.confirm")}</button>
        <button type="button" className="btn btn-ghost" onClick={() => setOpen(false)}>{t("modals.loginRequired.cancel")}</button>
      </div>
    </GlobalModal>
  );
}

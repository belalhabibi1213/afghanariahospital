// labelKey: کلید ترجمه در i18n/locales (متن برچسب با t(labelKey) در Navbar/MobileMenu ساخته می‌شود).
// پیکربندی مشترک لینک‌های ناوبری — هم در نوار دسکتاپ (Navbar) و هم در منوی
// موبایل (MobileMenu) استفاده می‌شود تا فهرست بخش‌ها فقط یک‌بار تعریف شود.
// href باید دقیقاً با id بخش‌های متناظر در pages/Home.jsx هم‌خوان باشد تا هم
// اسکرول به بخش و هم شاخص‌گذاری خودکار «لینک فعال» (Header.jsx) درست کار کند.
export const NAV_LINKS = [
  { href: "#about", labelKey: "nav.about" },
  { href: "#doctors", labelKey: "nav.doctors" },
  { href: "#services", labelKey: "nav.services" },
  { href: "#appointment", labelKey: "nav.appointment", guarded: true },
  { href: "#news", labelKey: "nav.news" },
  { href: "#contact", labelKey: "nav.contact" },
];

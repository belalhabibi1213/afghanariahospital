import NotificationBell from "../NotificationBell.jsx";

// پوسته‌ی هدر برای زنگوله‌ی اعلان‌ها. منطق بررسی دوره‌ای، پنل و علامت‌گذاری
// خوانده‌شده همگی از NotificationBell (که در سایدبار داشبوردها هم استفاده
// می‌شود) بازاستفاده می‌شود؛ این کامپوننت فقط جای‌گذاری و فاصله‌بندی آن را در
// چیدمان جدید هدر مدیریت می‌کند تا منطق در دو جا تکرار نشود.
export default function NotificationMenu() {
  return (
    <div className="header-notification-menu">
      <NotificationBell />
    </div>
  );
}

import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { HeartPulse, Search } from "lucide-react";
import { useAuth } from "../../context/AuthContext.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../../i18n/useLocalizedSettings.js";
import { resolvePhotoUrl } from "../../utils/api.js";
import Navbar from "./Navbar.jsx";
import UserMenu from "./UserMenu.jsx";
import NotificationMenu from "./NotificationMenu.jsx";
import MobileMenu from "./MobileMenu.jsx";
import SearchBar from "../search/SearchBar.jsx";
import ThemeToggle from "../ThemeToggle.jsx";
import LanguageSwitcher from "../LanguageSwitcher.jsx";
import { NAV_LINKS } from "./navLinks.js";

// SearchModal (پنل تمام‌صفحه‌ی جستجو در موبایل) فقط با کلیک روی دکمه‌ی جستجوی
// موبایل لازم می‌شود؛ با code-splitting/lazy-loading جدا از بسته‌ی اصلی هدر بارگذاری
// می‌شود تا حجم اولیه‌ی JS که در هر صفحه (برای همه‌ی کاربران، حتی دسکتاپ) لود
// می‌شود کاهش یابد.
const SearchModal = lazy(() => import("../search/SearchModal.jsx"));

const SCROLL_THRESHOLD = 12; // بیشتر از این مقدار اسکرول، هدر حالت «فشرده/بلر‌شده» می‌گیرد

// هدر عمومی سایت — پوسته‌ی sticky که چیدمان کلی (لوگو + ناوبری دسکتاپ + جستجوی
// سراسری در وسط + اکشن‌های کاربر + دکمه‌ی منوی موبایل) را مدیریت می‌کند و وضعیت
// مشترک (اسکرول، بخش فعال، باز/بسته‌بودن منوی موبایل و مودال جستجوی موبایل) را
// بین زیرکامپوننت‌ها هماهنگ نگه می‌دارد.
export default function Header() {
  const { user, isAuthenticated } = useAuth();
  const { settings } = useLocalizedSettings();
  const { t } = useLanguage();
  const location = useLocation();

  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("");
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  // وقتی هدر شلوغ است (نام کاربر بلند، زبان پشتو/دری، منوی ناوبری بزرگ) جای وسط هدر برای
  // نوار جستجو کم می‌شود و ورودی به اندازه‌ی یک آیکن باریک می‌شد (نوشته دیده نمی‌شد و
  // نمی‌شد روی آن کلیک کرد). در این حالت به‌جای نوار، یک دکمه‌ی جستجو نشان می‌دهیم که
  // پنجره‌ی کامل جستجو را باز می‌کند.
  const searchSlotRef = useRef(null);
  const [searchCompact, setSearchCompact] = useState(false);

  useEffect(() => {
    const el = searchSlotRef.current;
    if (!el || typeof ResizeObserver === "undefined") return undefined;
    const update = () => setSearchCompact(el.clientWidth < 200);
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const isHome = location.pathname === "/" || location.pathname === "/home";

  // افزودن سایه/بلر بیشتر به هدر پس از عبور از آستانه‌ی اسکرول
  useEffect(() => {
    function handleScroll() {
      setScrolled(window.scrollY > SCROLL_THRESHOLD);
    }
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Home بخش‌های زیر Hero را بعد از اولین نمایش رندر می‌کند؛ با این رویداد scroll-spy دوباره وصل می‌شود
  const [sectionsVersion, setSectionsVersion] = useState(0);
  useEffect(() => {
    const onReady = () => setSectionsVersion((v) => v + 1);
    window.addEventListener("shafakhana:sections-ready", onReady);
    return () => window.removeEventListener("shafakhana:sections-ready", onReady);
  }, []);

  // شاخص‌گذاری خودکار لینک فعال با IntersectionObserver — فقط در صفحه‌ی اصلی
  // که بخش‌های about/doctors/services/... واقعاً در DOM وجود دارند
  useEffect(() => {
    if (!isHome) {
      setActiveSection("");
      return undefined;
    }

    const sections = NAV_LINKS.map((link) => document.querySelector(link.href)).filter(Boolean);
    if (sections.length === 0) return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActiveSection(`#${entry.target.id}`);
        });
      },
      { rootMargin: "-45% 0px -50% 0px", threshold: 0 }
    );
    sections.forEach((section) => observer.observe(section));
    return () => observer.disconnect();
  }, [isHome, location.pathname, sectionsVersion]);

  // تغییر مسیر → بستن خودکار منوی موبایل
  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  // وقتی منوی موبایل باز است، اسکرول پس‌زمینه قفل می‌شود
  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileOpen]);

  // وقتی مودال جستجوی موبایل باز است، اسکرول پس‌زمینه قفل می‌شود (مشابه منوی موبایل)
  useEffect(() => {
    if (mobileOpen) return undefined;
    document.body.style.overflow = searchModalOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [searchModalOpen, mobileOpen]);

  return (
    <header className={`site-header pub-dark${scrolled ? " is-scrolled" : ""}`}>
      <div className="container">
        <div className="site-header-inner">
          <Link to="/home" className="brand" onClick={() => setMobileOpen(false)}>
            {settings.logoUrl ? (
              <img className="brand-logo" src={resolvePhotoUrl(settings.logoUrl)} alt="" />
            ) : (
              <span className="brand-mark" aria-hidden="true"><HeartPulse size={22} strokeWidth={2.2} /></span>
            )}
            <span className="brand-text">
              <span className="brand-name">{settings.hospitalName}</span>
              <span className="brand-tagline">{t("header.tagline")}</span>
            </span>
          </Link>

          <Navbar activeSection={activeSection} />

          <div className="header-search-slot" ref={searchSlotRef}>
            {!searchCompact && !searchModalOpen && <SearchBar variant="desktop" />}
          </div>

          <div className="header-actions">
            <LanguageSwitcher />
            <ThemeToggle />
            <button
              type="button"
              className={`header-search-mobile-trigger${searchCompact ? " is-compact" : ""}`}
              aria-label={t("header.openSearch")}
              onClick={() => setSearchModalOpen(true)}
            >
              <Search size={19} strokeWidth={2.2} aria-hidden="true" />
            </button>

            {isAuthenticated ? (
              <>
                <NotificationMenu />
                <UserMenu user={user} />
              </>
            ) : (
              <div className="header-auth-actions">
                <Link to="/login" className="pub-btn pub-btn--ghost pub-btn--sm hdr-login">
                  {t("header.login")}
                </Link>
                <Link to="/register" className="pub-btn pub-btn--light pub-btn--sm">
                  {t("header.register")}
                </Link>
              </div>
            )}

            <button
              type="button"
              className={`mobile-menu-toggle${mobileOpen ? " is-open" : ""}`}
              aria-label={mobileOpen ? t("header.closeMenu") : t("header.openMenu")}
              aria-expanded={mobileOpen}
              onClick={() => setMobileOpen((v) => !v)}
            >
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
      </div>

      <MobileMenu open={mobileOpen} onClose={() => setMobileOpen(false)} activeSection={activeSection} />

      {/* فقط وقتی کاربر واقعاً روی دکمه‌ی جستجوی موبایل کلیک کرده رندر/import
          می‌شود — تا chunk جدا شده‌ی SearchModal اصلاً دانلود نشود مگر لازم شود. */}
      {searchModalOpen && (
        <Suspense fallback={null}>
          <SearchModal open={searchModalOpen} onClose={() => setSearchModalOpen(false)} />
        </Suspense>
      )}
    </header>
  );
}

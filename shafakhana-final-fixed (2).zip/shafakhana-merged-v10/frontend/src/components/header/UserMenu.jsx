import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { DASHBOARD_PATH } from "../../context/AuthContext.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";
import { requestLogout } from "../../utils/logoutGuard.js";
import { isScrollbarClick } from "../../utils/scrollbarClick.js";

function getInitials(fullName) {
  if (!fullName) return "؟";
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "؟";
  const first = parts[0][0] || "";
  const last = parts.length > 1 ? parts[parts.length - 1][0] : "";
  return (first + last).toUpperCase();
}

// منوی کاربر واردشده در هدر عمومی سایت: نمایش آواتار/نام/نقش و دسترسی سریع به
// داشبورد و خروج از حساب. باز/بسته‌شدن دقیقاً مشابه الگوی NotificationBell است
// (کلیک بیرون یا کلید Escape پنل را می‌بندد) تا رفتار در سراسر هدر یکسان باشد.
export default function UserMenu({ user }) {
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef(null);
  const { t } = useLanguage();

  useEffect(() => {
    function handleClickOutside(e) {
      if (isScrollbarClick(e)) return;
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    function handleEscape(e) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, []);

  if (!user) return null;

  const roleLabel = ["user", "doctor", "admin", "superadmin"].includes(user.role) ? t(`roles.${user.role}`) : "";
  const initials = getInitials(user.fullName);

  return (
    <div className="user-menu-wrapper" ref={wrapperRef}>
      <button
        type="button"
        className={`user-menu-trigger${open ? " is-open" : ""}`}
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-haspopup="true"
      >
        <span className="user-avatar">{initials}</span>
        <span className="user-menu-label">
          <span className="user-menu-name">{user.fullName || t("common.user")}</span>
          {roleLabel && <span className="user-menu-role">{roleLabel}</span>}
        </span>
        <svg
          className={`user-menu-chevron${open ? " is-open" : ""}`}
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2.3"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <polyline points="6 9 12 15 18 9" />
        </svg>
      </button>

      {open && (
        <div className="user-menu-panel glass" role="menu">
          <div className="user-menu-head">
            <span className="user-avatar user-avatar-lg">{initials}</span>
            <div className="user-menu-head-info">
              <strong>{user.fullName || t("common.user")}</strong>
              {roleLabel && <span className="user-menu-role-badge">{roleLabel}</span>}
            </div>
          </div>

          <div className="user-menu-divider" />

          <div className="user-menu-actions">
            <Link
              to={DASHBOARD_PATH[user.role] || "/home"}
              className="user-menu-item"
              role="menuitem"
              onClick={() => setOpen(false)}
            >
              <DashboardIcon />
              {t("userMenu.dashboard")}
            </Link>
            <button
              type="button"
              className="user-menu-item danger"
              role="menuitem"
              onClick={() => {
                setOpen(false);
                requestLogout();
              }}
            >
              <LogoutIcon />
              {t("userMenu.logout")}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function DashboardIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <rect x="3" y="3" width="7" height="9" rx="1.5" />
      <rect x="14" y="3" width="7" height="5" rx="1.5" />
      <rect x="14" y="12" width="7" height="9" rx="1.5" />
      <rect x="3" y="16" width="7" height="5" rx="1.5" />
    </svg>
  );
}

function LogoutIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
      <polyline points="16 17 21 12 16 7" />
      <line x1="21" y1="12" x2="9" y2="12" />
    </svg>
  );
}

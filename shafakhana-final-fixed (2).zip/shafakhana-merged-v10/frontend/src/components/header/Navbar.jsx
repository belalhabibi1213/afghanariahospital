import { useAuth } from "../../context/AuthContext.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";
import { ensureAuthenticated } from "../../utils/authGuard.js";
import HashSectionLink from "../HashSectionLink.jsx";
import { NAV_LINKS } from "./navLinks.js";

// ردیف ناوبری دسکتاپ: لینک‌های بخش‌ها. در اندازه‌های تبلت/موبایل با CSS مخفی
// می‌شود و MobileMenu جایگزین آن است (Header.jsx هر دو را رندر می‌کند). جستجوی
// سراسری دیگر بخشی از Navbar نیست؛ Header.jsx آن را جداگانه در وسط هدر رندر می‌کند.
export default function Navbar({ activeSection }) {
  const { isAuthenticated } = useAuth();
  const { t } = useLanguage();

  return (
    <nav className="nav-links" aria-label={t("nav.ariaMain")}>
      {NAV_LINKS.map((link) => (
        <HashSectionLink
          key={link.href}
          hash={link.href}
          className={`nav-link${activeSection === link.href ? " active" : ""}`}
          onClick={
            link.guarded
              ? (e) => {
                  if (!ensureAuthenticated(isAuthenticated)) e.preventDefault();
                }
              : undefined
          }
        >
          {t(link.labelKey)}
        </HashSectionLink>
      ))}
    </nav>
  );
}

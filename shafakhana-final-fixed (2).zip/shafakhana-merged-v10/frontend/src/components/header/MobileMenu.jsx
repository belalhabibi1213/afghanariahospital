import { Link } from "react-router-dom";
import { useAuth, DASHBOARD_PATH } from "../../context/AuthContext.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";
import { ensureAuthenticated } from "../../utils/authGuard.js";
import { requestLogout } from "../../utils/logoutGuard.js";
import HashSectionLink from "../HashSectionLink.jsx";
import LanguageSwitcher from "../LanguageSwitcher.jsx";
import { NAV_LINKS } from "./navLinks.js";

function getInitials(fullName) {
  if (!fullName) return "؟";
  const parts = fullName.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "؟";
  const first = parts[0][0] || "";
  const last = parts.length > 1 ? parts[parts.length - 1][0] : "";
  return (first + last).toUpperCase();
}

// منوی کشویی موبایل/تبلت — جایگزین نوار ناوبری دسکتاپ در صفحه‌های کوچک.
// همان لینک‌ها و اکشن‌های ورود/داشبورد/خروج را با چیدمان عمودی و اهداف لمسی
// بزرگ‌تر ارائه می‌دهد. باز/بسته‌شدن آن از Header.jsx کنترل می‌شود. جستجوی
// سراسری در موبایل جدا مدیریت می‌شود: آیکن جستجو در هدر، مودال تمام‌صفحه
// (components/search/SearchModal.jsx) را باز می‌کند.
export default function MobileMenu({ open, onClose, activeSection }) {
  const { user, isAuthenticated } = useAuth();
  const { t } = useLanguage();
  const roleLabel = user?.role && ["user", "doctor", "admin", "superadmin"].includes(user.role) ? t(`roles.${user.role}`) : "";

  return (
    <>
      <div
        className={`mobile-menu-overlay${open ? " is-open" : ""}`}
        onClick={onClose}
        aria-hidden={!open}
      />

      <div
        className={`mobile-menu-panel pub-dark${open ? " is-open" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-label={t("nav.menuDialog")}
        aria-hidden={!open}
      >
        <nav className="mobile-nav-links" aria-label={t("nav.ariaMobile")}>
          {NAV_LINKS.map((link) => (
            <HashSectionLink
              key={link.href}
              hash={link.href}
              className={`mobile-nav-link${activeSection === link.href ? " active" : ""}`}
              onClick={(e) => {
                if (link.guarded && !ensureAuthenticated(isAuthenticated)) {
                  e.preventDefault();
                  return;
                }
                onClose();
              }}
            >
              {t(link.labelKey)}
            </HashSectionLink>
          ))}
        </nav>

        <LanguageSwitcher variant="inline" className="mobile-menu-lang" />

        <div className="mobile-menu-auth">
          {isAuthenticated ? (
            <>
              <div className="mobile-menu-user">
                <span className="user-avatar">{getInitials(user?.fullName)}</span>
                <div className="mobile-menu-user-info">
                  <strong>{user?.fullName || t("common.user")}</strong>
                  {roleLabel && <span>{roleLabel}</span>}
                </div>
              </div>
              <Link to={DASHBOARD_PATH[user?.role] || "/home"} className="pub-btn pub-btn--ghost" onClick={onClose}>
                {t("userMenu.dashboard")}
              </Link>
              <button
                type="button"
                className="pub-btn pub-btn--danger"
                onClick={() => {
                  onClose();
                  requestLogout();
                }}
              >
                {t("userMenu.logout")}
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="pub-btn pub-btn--ghost" onClick={onClose}>
                {t("header.login")}
              </Link>
              <Link to="/register" className="pub-btn pub-btn--light" onClick={onClose}>
                {t("header.register")}
              </Link>
            </>
          )}
        </div>
      </div>
    </>
  );
}

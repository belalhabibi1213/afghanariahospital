import { Navigate, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

// این کامپوننت مسیرها را بر اساس ورود و نقش کاربر محافظت می‌کند.
// allowedRoles خالی یعنی فقط ورود کافی است (هر نقشی مجاز است).
export default function ProtectedRoute({ children, allowedRoles = [] }) {
  const { user, loading, isAuthenticated } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="dash-loading">
        <div className="spinner" />
        <p>در حال بررسی نشست کاربری...</p>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (allowedRoles.length > 0 && !allowedRoles.includes(user.role)) {
    return <Navigate to="/403" replace />;
  }

  return children;
}

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useTheme } from "../context/ThemeContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { isScrollbarClick } from "../utils/scrollbarClick.js";
import "./ThemeToggle.css";

// انتخاب‌گر ظاهر سایت — در هدر عمومی و نوار بالای هر چهار داشبورد (بیمار/داکتر/ادمین/مدیر کل)
// استفاده می‌شود. با کلیک روی دکمه، یک منوی کشویی باز می‌شود که شامل دو بخش است:
//   ۱) حالت نمایش: روشن / تاریک
//   ۲) رنگ‌بندی: فیروزه‌ای (پیش‌فرض)، اقیانوسی، بنفش، گل‌سرخی، زمردی، غروب
// تغییرها فوری (بدون رفرش) اعمال می‌شوند؛ هر پالت هم در حالت روشن و هم تاریک کار می‌کند.
//
// مثل پنل «اعلان‌ها» (NotificationBell)، منو با createPortal مستقیماً زیر document.body رندر می‌شود و
// با position: fixed و مختصات getBoundingClientRect دکمه جای می‌گیرد. قبلاً منو فرزند absolute همین
// wrapper داخل هدر داشبورد بود و چون هدر/کارت‌های شیشه‌ای (backdrop-filter) هرکدام یک stacking context
// می‌سازند، z-index داخلی منو کار نمی‌کرد و کارت‌ها/فیلترهای پایین (مثل فیلد تاریخ) روی منو می‌افتادند
// و انتخاب رنگ ممکن نبود.
const MENU_WIDTH = 250;
const MENU_GAP = 10;
const MENU_MARGIN = 12;

export default function ThemeToggle({ className = "" }) {
  const { theme, setTheme, palette, setPalette, palettes } = useTheme();
  const { t, dir } = useLanguage();
  const [open, setOpen] = useState(false);
  const [anchorPos, setAnchorPos] = useState(null); // { top, left } نسبت به viewport
  const btnRef = useRef(null);
  const menuRef = useRef(null);
  const isDark = theme === "dark";
  const activePalette = palettes.find((p) => p.id === palette) || palettes[0];

  const updateAnchorPos = useCallback(() => {
    const btn = btnRef.current;
    if (!btn) return;
    const rect = btn.getBoundingClientRect();
    const width = menuRef.current ? menuRef.current.offsetWidth : MENU_WIDTH;
    // در RTL لبه‌ی چپ دکمه، در LTR لبه‌ی راست آن با منو هم‌راستا می‌شود؛ سپس در محدوده‌ی امن صفحه کلمپ می‌شود
    let left = dir === "rtl" ? rect.left : rect.right - width;
    const maxLeft = window.innerWidth - width - MENU_MARGIN;
    if (left > maxLeft) left = maxLeft;
    if (left < MENU_MARGIN) left = MENU_MARGIN;
    let top = rect.bottom + MENU_GAP;
    const maxTop = window.innerHeight - MENU_MARGIN;
    if (top > maxTop) top = maxTop;
    setAnchorPos({ top, left });
  }, [dir]);

  // موقعیت را هنگام باز بودن منو، روی تغییر اندازه و اسکرول (حتی داخل کانتینرهای تودرتو، فاز capture) به‌روز نگه می‌دارد
  useLayoutEffect(() => {
    if (!open) return undefined;
    updateAnchorPos();
    window.addEventListener("resize", updateAnchorPos);
    window.addEventListener("scroll", updateAnchorPos, true);
    return () => {
      window.removeEventListener("resize", updateAnchorPos);
      window.removeEventListener("scroll", updateAnchorPos, true);
    };
  }, [open, updateAnchorPos]);

  useEffect(() => {
    if (!open) return undefined;
    function handleClickOutside(e) {
      if (isScrollbarClick(e)) return;
      // منو پورتال‌شده است: هم دکمه و هم خودِ منو باید از بررسی «کلیک بیرون» مستثنی شوند
      if (btnRef.current && btnRef.current.contains(e.target)) return;
      if (menuRef.current && menuRef.current.contains(e.target)) return;
      setOpen(false);
    }
    function handleEscape(e) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [open]);

  return (
    <div className="theme-switcher">
      <button
        type="button"
        ref={btnRef}
        className={`theme-toggle-btn${open ? " is-open" : ""}${className ? ` ${className}` : ""}`}
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-label={t("theme.menuLabel")}
        title={t("theme.menuLabel")}
      >
        <span aria-hidden="true">{isDark ? "🌙" : "☀️"}</span>
        <i
          className="theme-toggle-dot"
          aria-hidden="true"
          style={{ background: `linear-gradient(135deg, ${activePalette.color}, ${activePalette.color2})` }}
        />
      </button>

      {open && anchorPos && createPortal(
        <div
          ref={menuRef}
          className="theme-switcher-menu"
          role="dialog"
          aria-label={t("theme.menuLabel")}
          dir={dir}
          style={{ top: anchorPos.top, left: anchorPos.left }}
        >
          <div className="theme-menu-title">{t("theme.modeLabel")}</div>
          <div className="theme-mode-row" role="group" aria-label={t("theme.modeLabel")}>
            <button
              type="button"
              className={`theme-mode-btn${!isDark ? " is-active" : ""}`}
              aria-pressed={!isDark}
              onClick={() => setTheme("light")}
            >
              <span aria-hidden="true">☀️</span> {t("theme.lightShort")}
            </button>
            <button
              type="button"
              className={`theme-mode-btn${isDark ? " is-active" : ""}`}
              aria-pressed={isDark}
              onClick={() => setTheme("dark")}
            >
              <span aria-hidden="true">🌙</span> {t("theme.darkShort")}
            </button>
          </div>

          <div className="theme-menu-title">{t("theme.paletteLabel")}</div>
          <div className="theme-palette-grid" role="radiogroup" aria-label={t("theme.paletteLabel")}>
            {palettes.map((p) => (
              <button
                key={p.id}
                type="button"
                role="radio"
                aria-checked={p.id === palette}
                className={`theme-palette-btn${p.id === palette ? " is-active" : ""}`}
                onClick={() => setPalette(p.id)}
              >
                <span
                  className="theme-swatch"
                  aria-hidden="true"
                  style={{ background: `linear-gradient(135deg, ${p.color}, ${p.color2})` }}
                >
                  {p.id === palette ? "✓" : ""}
                </span>
                <span className="theme-palette-name">{t(`theme.palettes.${p.id}`)}</span>
              </button>
            ))}
          </div>
        </div>,
        document.body
      )}
    </div>
  );
}

import { useEffect, useState } from "react";
import { HeartPulse } from "lucide-react";
import PulseLine from "./PulseLine.jsx";
import HeroSearch from "./HeroSearch.jsx";
import { photos } from "../data/photos.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../i18n/useLocalizedSettings.js";
import { ensureAuthenticated } from "../utils/authGuard.js";
import { apiRequest, resolvePhotoUrl } from "../utils/api.js";

// مقدار یک فیلد چندزبانه برای زبان فعلی؛ در نبودِ آن، دری و بعد هر زبان دیگری که پر باشد
const pickAny = (obj, lang) => {
  const v = obj?.[lang]?.trim();
  if (v) return v;
  return obj?.fa?.trim() || obj?.ps?.trim() || obj?.en?.trim() || "";
};

// آخرین محتوای Hero که از سرور آمده در localStorage نگه‌داری می‌شود تا بازدید بعدی از همان لحظه‌ی اول
// متن/عکس درست را نشان بدهد (بدون پرش از پیش‌فرض به محتوای ادمین و بدون صبر برای شبکه).
const HERO_CACHE_KEY = "shafakhana_hero_v1";
function readHeroCache() {
  try {
    const raw = localStorage.getItem(HERO_CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
function writeHeroCache(hero) {
  try {
    if (hero) localStorage.setItem(HERO_CACHE_KEY, JSON.stringify(hero));
    else localStorage.removeItem(HERO_CACHE_KEY);
  } catch {
    // localStorage در دسترس نیست؛ فقط کش نمی‌شود
  }
}

const isExternal = (href) => /^https?:\/\//i.test(href);

// متن‌ها و دکمه‌ها به‌طور پیش‌فرض از دیکشنری زبان (hero.*) خوانده می‌شوند؛ اگر ادمین در «مدیریت بخش اصلی»
// محتوا ذخیره کرده باشد، آن محتوا جایگزین می‌شود. آمارها و کارت ضربان فقط وقتی نمایش داده می‌شوند که
// ادمین خودش آن‌ها را ثبت کرده باشد — عددهای نمونه‌ی پیش‌فرض (مثل «۴۰+ داکتر») دیگر ساخته نمی‌شوند.

export default function Hero() {
  const { isAuthenticated } = useAuth();
  const { settings } = useLocalizedSettings();
  const { t, lang } = useLanguage();
  const [custom, setCustom] = useState(readHeroCache);

  useEffect(() => {
    let alive = true;
    apiRequest("/settings/hero")
      .then((data) => {
        if (!alive) return;
        const hero = data?.hero || null;
        writeHeroCache(hero);
        setCustom(hero);
      })
      .catch(() => {}); // بدون سرور، متن‌های پیش‌فرض نمایش داده می‌شوند
    return () => { alive = false; };
  }, []);

  const hospital = settings.hospitalName;
  const fill = (s) => s.replace(/\{hospital\}/g, hospital);
  // اگر ادمین برای همین زبان چیزی نوشته همان، وگرنه متن پیش‌فرض همین زبان
  const field = (name, params) => {
    const own = custom?.[name]?.[lang]?.trim();
    return own ? fill(own) : t(`hero.${name}`, params);
  };

  // عکس پیش‌فرض: webp سبک با دو اندازه (موبایل/دسکتاپ)؛ عکس آپلودشده‌ی ادمین: همان یک آدرس
  const customBg = custom?.imageUrl ? resolvePhotoUrl(custom.imageUrl) : null;
  const bgImage = customBg || photos.heroBuilding;
  const bgSrcSet = customBg ? undefined : `${photos.heroBuilding640} 640w, ${photos.heroBuilding} 1080w`;

  const showEyebrow = custom?.eyebrowVisible !== false;
  const showSecondary = custom?.secondaryVisible !== false;

  const primaryLink = custom?.primaryButton?.link || "#appointment";
  const primaryText = custom?.primaryButton?.text?.[lang]?.trim() || t("hero.book");
  const secondaryLink = custom?.secondaryButton?.link || "#doctors";
  const secondaryText = custom?.secondaryButton?.text?.[lang]?.trim() || t("hero.seeDoctors");

  const stats = Array.isArray(custom?.stats)
    ? custom.stats.map((s) => ({ key: s.id, value: fill(pickAny(s.value, lang)), label: fill(pickAny(s.label, lang)) }))
    : [];
  const pulse = Array.isArray(custom?.pulse)
    ? custom.pulse.map((s) => ({ key: s.id, value: fill(pickAny(s.value, lang)), label: fill(pickAny(s.label, lang)) }))
    : [];
  const showStats = custom?.statsVisible !== false && stats.length > 0;
  const showPulse = custom?.pulseVisible !== false && pulse.length > 0;

  return (
    <section className="hero">
      <div className="container hero-grid">
        <div className="hero-copy">
          {showEyebrow && (
            <span className="hero-eyebrow">
              <HeartPulse size={16} aria-hidden="true" />
              {field("eyebrow")}
            </span>
          )}

          <h1>
            {field("titleBefore")} <span>{field("titleAccent")}</span> {field("titleAfter")}
          </h1>

          <p className="hero-lead">{field("lead", { hospital })}</p>

          <div className="hero-actions">
            <a
              href={primaryLink}
              className="pub-btn pub-btn--primary"
              {...(isExternal(primaryLink) ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              onClick={(e) => {
                // فقط دکمه‌ی گرفتن وقت (لنگر #appointment) نیاز به ورود دارد
                if (primaryLink === "#appointment" && !ensureAuthenticated(isAuthenticated)) e.preventDefault();
              }}
            >
              {primaryText}
            </a>
            {showSecondary && (
              <a
                href={secondaryLink}
                className="pub-btn pub-btn--ghost"
                {...(isExternal(secondaryLink) ? { target: "_blank", rel: "noopener noreferrer" } : {})}
              >
                {secondaryText}
              </a>
            )}
          </div>

          {showStats && (
            <dl className="hero-stats">
              {stats.map((s) => (
                <div className="hero-stat" key={s.key}>
                  <dt>{s.label}</dt>
                  <dd>{s.value}</dd>
                </div>
              ))}
            </dl>
          )}
        </div>

        <div className="hero-media">
          {/* <img> به‌جای background-image: مرورگر آن را زودتر پیدا و با اولویت بالا دانلود می‌کند (بهبود LCP) */}
          <img
            className="hero-img"
            src={bgImage}
            srcSet={bgSrcSet}
            sizes="(max-width: 900px) 100vw, 560px"
            width="1080"
            height="592"
            alt={t("about.imageAlt", { hospital })}
            decoding="async"
            {...{ fetchpriority: "high" }} // React 18 هنوز fetchPriority را نمی‌شناسد؛ attribute استاندارد HTML مستقیم گذاشته می‌شود
          />
          {showPulse && (
            <div className="hero-pulse pub-card">
              <PulseLine />
              <div className="hero-pulse-meta">
                {pulse.map((p) => (
                  <div key={p.key}>
                    <b>{p.value}</b>
                    <span>{p.label}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="container hero-search-wrap">
        <HeroSearch />
      </div>
    </section>
  );
}

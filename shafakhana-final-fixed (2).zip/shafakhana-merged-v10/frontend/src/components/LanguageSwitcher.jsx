import { useEffect, useRef, useState } from "react";
import { useLanguage } from "../context/LanguageContext.jsx";
import { isScrollbarClick } from "../utils/scrollbarClick.js";
import "./LanguageSwitcher.css";

// انتخاب‌گر زبان سایت. دو حالت دارد:
//   variant="dropdown" (پیش‌فرض) — دکمه‌ی کروی با منوی کشویی؛ برای هدر و صفحه‌های ورود/ثبت‌نام
//   variant="inline"            — ردیف دکمه‌های کنار هم؛ برای منوی موبایل
// انتخاب کاربر در localStorage نگه‌داری می‌شود و فوراً (بدون رفرش) روی کل سایت اعمال می‌شود.
export default function LanguageSwitcher({ variant = "dropdown", className = "" }) {
  const { lang, setLang, languages, t } = useLanguage();
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef(null);
  const current = languages.find((l) => l.code === lang) || languages[0];

  useEffect(() => {
    if (!open) return undefined;
    function handleClickOutside(e) {
      if (isScrollbarClick(e)) return;
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) setOpen(false);
    }
    function handleEscape(e) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [open]);

  if (variant === "inline") {
    return (
      <div className={`lang-inline${className ? ` ${className}` : ""}`} role="group" aria-label={t("lang.menuLabel")}>
        {languages.map((l) => (
          <button
            key={l.code}
            type="button"
            lang={l.code}
            className={`lang-inline-btn${l.code === lang ? " is-active" : ""}`}
            aria-pressed={l.code === lang}
            onClick={() => setLang(l.code)}
          >
            {l.name}
          </button>
        ))}
      </div>
    );
  }

  return (
    <div className={`lang-switcher${className ? ` ${className}` : ""}`} ref={wrapperRef}>
      <button
        type="button"
        className={`lang-switcher-trigger${open ? " is-open" : ""}`}
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={t("lang.current", { name: current.name })}
        title={t("lang.menuLabel")}
      >
        <GlobeIcon />
        <span className="lang-switcher-code">{current.short}</span>
      </button>

      {open && (
        <ul className="lang-switcher-menu glass" role="listbox" aria-label={t("lang.menuLabel")}>
          {languages.map((l) => (
            <li key={l.code} role="presentation">
              <button
                type="button"
                lang={l.code}
                role="option"
                aria-selected={l.code === lang}
                className={`lang-switcher-option${l.code === lang ? " is-active" : ""}`}
                onClick={() => {
                  setLang(l.code);
                  setOpen(false);
                }}
              >
                <span>{l.name}</span>
                {l.code === lang && <span aria-hidden="true">✓</span>}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function GlobeIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <line x1="3" y1="12" x2="21" y2="12" />
      <path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18z" />
    </svg>
  );
}

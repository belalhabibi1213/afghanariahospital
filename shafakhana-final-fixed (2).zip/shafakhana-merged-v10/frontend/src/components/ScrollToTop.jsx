import { useEffect } from "react";
import { useLocation, useNavigationType } from "react-router-dom";

// وقتی کاربر از طریق یک لینک (هدر/فوتر/هرجای دیگر) به یک صفحه‌ی کاملاً متفاوت
// می‌رود، صفحه‌ی جدید باید از بالا شروع شود، نه اینکه موقعیت اسکرول صفحه‌ی
// قبلی را حفظ کند (چون React Router برخلاف لود کامل صفحه، اسکرول را خودش
// ریست نمی‌کند). این کامپوننت سراسری (یک‌بار در App.jsx مانت می‌شود) دقیقاً
// همین را انجام می‌دهد — با دو استثنای عمدی تا رفتارهای دیگر خراب نشوند:
//   ۱) وقتی ناوبری از نوع POP است (دکمه‌ی Back/Forward مرورگر)، دست نمی‌زنیم؛
//      رفتار طبیعی مرورگر (بازگرداندن موقعیت اسکرول قبلی) حفظ می‌شود.
//   ۲) وقتی آدرس شامل هش است (مثلاً /home#doctors)، دست نمی‌زنیم؛ اسکرول به
//      بخش موردنظر از قبل توسط Home.jsx (و برای بالای خبر توسط NewsDetail.jsx)
//      مدیریت می‌شود.
export default function ScrollToTop() {
  const { pathname, hash, state } = useLocation();
  const navigationType = useNavigationType();

  useEffect(() => {
    if (navigationType === "POP") return;
    if (hash) return;
    // جابه‌جایی بین مراحل ویزارد نوبت‌دهی (AppointmentSection) فقط یک رکورد تاریخچه است،
    // نه صفحه‌ی جدید؛ اگر اینجا به بالا اسکرول کنیم کاربر بعد از «مرحله بعد» به اول صفحه می‌پرد.
    if (typeof state?.appointmentStep === "number") return;
    window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
  }, [pathname, hash, state, navigationType]);

  return null;
}

import { useEffect } from "react";

// انیمیشن ظاهرشدن هنگام اسکرول برای بخش‌های صفحه‌ی اصلی.
// بهبود تدریجی است: کلاس‌های pub-reveal فقط با JavaScript اضافه می‌شوند، پس اگر JS یا
// IntersectionObserver در دسترس نباشد (یا کاربر کاهش حرکت را فعال کرده باشد) همه‌چیز عادی دیده می‌شود.
// بخش‌هایی که بعداً با داده‌ی API رندر می‌شوند با MutationObserver شناسایی می‌شوند.
const TARGETS = [
  ".pub-head",
  ".qa-grid > li",
  ".dr-tabs",
  ".dr-item",
  ".dpt-card",
  ".about-figure",
  ".about-copy",
  ".nw-item",
  ".ct-info",
  ".ct-form",
].join(",");

export default function useScrollReveal() {
  useEffect(() => {
    if (typeof IntersectionObserver === "undefined") return undefined;
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return undefined;

    const io = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          entry.target.classList.add("is-in");
          io.unobserve(entry.target);
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -6% 0px" }
    );

    const seen = new WeakSet();
    function scan() {
      document.querySelectorAll(TARGETS).forEach((el) => {
        if (seen.has(el)) return;
        seen.add(el);
        const siblings = el.parentElement ? Array.from(el.parentElement.children) : [el];
        el.style.setProperty("--reveal-delay", `${Math.min(siblings.indexOf(el), 5) * 70}ms`);
        el.classList.add("pub-reveal");
        io.observe(el);
      });
    }

    scan();
    const mo = new MutationObserver(scan);
    mo.observe(document.body, { childList: true, subtree: true });
    return () => {
      mo.disconnect();
      io.disconnect();
    };
  }, []);
}

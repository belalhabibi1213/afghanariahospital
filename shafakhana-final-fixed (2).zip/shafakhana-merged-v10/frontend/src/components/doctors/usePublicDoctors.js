import { useEffect, useState } from "react";
import { API_BASE } from "../../utils/api.js";

const API_URL = `${API_BASE}/doctors`;

// فهرست عمومی داکتران (GET /api/doctors) برای چند بخش صفحه‌ی اصلی (جستجوی هیرو، داکتران منتخب،
// آمار بخش‌ها). درخواست بین کامپوننت‌ها مشترک است تا هر بار ورود به صفحه، یک درخواست شبکه‌ای انجام شود.
// اگر درخواست شکست بخورد، نتیجه کش نمی‌شود تا بار بعد دوباره تلاش شود.
let inflight = null;
let cached = null;
let cachedAt = 0;
const TTL_MS = 30 * 1000;

function loadDoctors() {
  if (cached && Date.now() - cachedAt < TTL_MS) return Promise.resolve(cached);
  if (inflight) return inflight;
  inflight = fetch(API_URL)
    .then((res) => {
      if (!res.ok) throw new Error("bad response");
      return res.json();
    })
    .then((data) => {
      cached = Array.isArray(data.doctors) ? data.doctors : [];
      cachedAt = Date.now();
      return cached;
    })
    .finally(() => {
      inflight = null;
    });
  return inflight;
}

export default function usePublicDoctors() {
  const [state, setState] = useState(() => ({
    doctors: cached || [],
    status: cached ? "ok" : "loading", // loading | ok | error
  }));

  useEffect(() => {
    let cancelled = false;
    loadDoctors()
      .then((doctors) => {
        if (!cancelled) setState({ doctors, status: "ok" });
      })
      .catch(() => {
        if (!cancelled) setState({ doctors: [], status: "error" });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  return state;
}

import { useEffect, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, X, Users, Stethoscope, CalendarDays, ArrowLeft, LoaderCircle } from "lucide-react";
import { apiRequest } from "../../utils/api.js";
import { PageHead, StateBlock, Badge, fa, useDebounced, buildQs } from "./AdminPro.jsx";

import { tr, trc, jdate, jtime } from "../../i18n/tr.js";
const STATUS_LABEL = trc({ pending: "در انتظار", confirmed: "تایید شده", completed: "انجام‌شده", cancelled: "لغوشده" });
const STATUS_TONE = { pending: "warn", confirmed: "success", completed: "info", cancelled: "danger" };
const EMPTY = { patients: [], doctors: [], appointments: [] };

// جستجوی کلی ادمین — همان endpoint قبلی (GET /admin/search?q=) و همان Scope (بیماران، داکتران، نوبت‌ها).
// بک‌اند برای هر دسته حداکثر ۵ نتیجه و تعداد کل را برمی‌گرداند؛ همان‌ها نمایش داده می‌شود.
// کلیک روی «رفتن به بخش» از همان مکانیزم موجود ?tab= داشبورد استفاده می‌کند (برای نوبت‌ها highlight هم
// پشتیبانی می‌شود). هیچ مسیر یا قابلیت جدیدی ساخته نشده است.
export default function AdminGlobalSearch() {
  const [, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState("");
  const debounced = useDebounced(query);
  const [results, setResults] = useState(EMPTY);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [retryTick, setRetryTick] = useState(0);
  const reqId = useRef(0);

  useEffect(() => {
    const term = debounced.trim();
    if (!term) {
      setResults(EMPTY);
      setError("");
      setLoading(false);
      return;
    }
    const id = ++reqId.current;
    setLoading(true);
    setError("");
    apiRequest(`/admin/search${buildQs({ q: term })}`)
      .then((data) => { if (id === reqId.current) setResults({ ...EMPTY, ...data }); })
      .catch((err) => { if (id === reqId.current) setError(err.message || tr("خطا در جستجو")); })
      .finally(() => { if (id === reqId.current) setLoading(false); });
  }, [debounced, retryTick]);

  const term = query.trim();
  const settled = term && term === debounced.trim() && !loading;
  const hasAny = results.patients?.length || results.doctors?.length || results.appointments?.length;

  function goTo(tab, highlight) {
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.set("tab", tab);
      if (highlight) next.set("highlight", String(highlight)); else next.delete("highlight");
      return next;
    });
  }

  const groups = [
    {
      key: "patients", title: tr("بیماران"), section: tr("مدیریت بیماران"), tab: "patients", Icon: Users,
      rows: results.patients, total: results.patientsTotal,
      render: (p) => ({ title: p.fullName, meta: [p.phone, p.email].filter(Boolean).join(" • ") }),
    },
    {
      key: "doctors", title: tr("داکتران"), section: tr("مدیریت داکتران"), tab: "doctors", Icon: Stethoscope,
      rows: results.doctors, total: results.doctorsTotal,
      render: (d) => ({ title: d.fullName, meta: [d.department, d.yearsExperience ? tr("{0} سال سابقه", [fa(d.yearsExperience)]) : ""].filter(Boolean).join(" • ") }),
    },
    {
      key: "appointments", title: tr("نوبت‌ها"), section: tr("مدیریت نوبت‌ها"), tab: "appointments", Icon: CalendarDays,
      rows: results.appointments, total: results.appointmentsTotal, highlight: true,
      render: (a) => ({
        title: `${a.patientName} ← ${a.doctorName}`,
        meta: [a.department, `${jdate(a.appointmentDate)} ${a.appointmentTime ? jtime(String(a.appointmentTime)) : ""}`.trim()].filter(Boolean).join(" • "),
        badge: <Badge tone={STATUS_TONE[a.status] || "muted"}>{STATUS_LABEL[a.status] || a.status}</Badge>,
      }),
    },
  ];

  return (
    <div className="pm-page">
      <PageHead title={tr("جستجوی کلی")} subtitle={tr("جستجوی هم‌زمان در بیماران (نام، تلفن، ایمیل، شناسه)، داکتران (نام، بخش، تخصص) و نوبت‌ها")} />

      <div className="ap-searchbox">
        <div className="pm-search">
          <Search size={18} />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={tr("نام بیمار، داکتر، بخش، شماره تماس یا شناسه...")}
            aria-label={tr("عبارت جستجو")}
            autoFocus
          />
        </div>
        {loading && <LoaderCircle size={18} className="ap-spin ap-searchbox-status" aria-label={tr("در حال جستجو")} />}
        {query && !loading && (
          <button type="button" className="pm-iconbtn" onClick={() => setQuery("")} aria-label={tr("پاک کردن عبارت")}><X size={16} /></button>
        )}
      </div>

      {!term && (
        <div className="pm-tablewrap">
          <StateBlock title={tr("برای شروع، عبارتی را جستجو کنید")} message={tr("نتایج بیماران، داکتران و نوبت‌ها به‌صورت دسته‌بندی‌شده اینجا نمایش داده می‌شود.")} />
        </div>
      )}

      {term && error && (
        <div className="pm-tablewrap">
          <StateBlock kind="error" title={tr("جستجو انجام نشد")} message={error} onRetry={() => setRetryTick((n) => n + 1)} />
        </div>
      )}

      {term && !error && loading && !hasAny && (
        <div className="ap-skeleton" aria-busy="true">
          {[0, 1, 2].map((i) => <div key={i} className="pm-skel dm-skel-line" />)}
        </div>
      )}

      {settled && !error && !hasAny && (
        <div className="pm-tablewrap">
          <StateBlock title={tr("نتیجه‌ای یافت نشد")} message={tr("برای «{0}» در بیماران، داکتران و نوبت‌ها موردی پیدا نشد. عبارت دیگری را امتحان کنید.", [term])} />
        </div>
      )}

      {term && !error && hasAny ? (
        <div className={`ap-groups ${loading ? "is-busy" : ""}`}>
          {groups.filter((g) => g.rows?.length).map((g) => (
            <section key={g.key} className="ap-group" aria-label={g.title}>
              <header className="ap-group-head">
                <span className="pm-stat-icon"><g.Icon size={18} /></span>
                <h3>{g.title}</h3>
                <Badge tone="muted">{tr("{0} نتیجه", [fa(g.total || g.rows.length)])}</Badge>
                <button type="button" className="btn btn-ghost btn-sm ap-group-link" onClick={() => goTo(g.tab)}>
                  {g.section} <ArrowLeft size={14} />
                </button>
              </header>
              <ul className="ap-results">
                {g.rows.map((row) => {
                  const r = g.render(row);
                  return (
                    <li key={`${g.key}-${row.id}`}>
                      <button type="button" className="ap-result" onClick={() => goTo(g.tab, g.highlight ? row.id : undefined)}>
                        <span className="ap-result-main">
                          <span className="ap-result-title">{r.title}</span>
                          {r.meta && <span className="ap-result-meta">{r.meta}</span>}
                        </span>
                        {r.badge}
                        <span className="ap-result-tag">{g.section}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
              {g.total > g.rows.length && (
                <footer className="ap-group-foot">{tr("نمایش {0} مورد از {1} نتیجه — برای دیدن همه به «{2}» بروید.", [fa(g.rows.length), fa(g.total), g.section])}</footer>
              )}
            </section>
          ))}
        </div>
      ) : null}
    </div>
  );
}

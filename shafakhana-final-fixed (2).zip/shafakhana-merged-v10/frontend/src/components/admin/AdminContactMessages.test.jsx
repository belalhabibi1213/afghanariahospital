import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, useLocation } from "react-router-dom";

vi.mock("../../utils/api.js", () => ({ apiRequest: vi.fn() }));
import { apiRequest } from "../../utils/api.js";
import AdminContactMessages from "./AdminContactMessages.jsx";

const mk = (i, extra = {}) => ({ id: i, fullName: `فرستنده ${i}`, email: `u${i}@x.com`, phone: null, subject: null, type: "question", status: "unread", isImportant: false, isAnswered: false, createdAt: "2026-09-01T10:00:00Z", preview: `خلاصه ${i}`, ...extra });
const STATS = { total: 45, unread: 38, read: 7, important: 12, answered: 3 };

function Loc() { return <div data-testid="loc">{useLocation().search}</div>; }

function setup(handler, route = "/") {
  apiRequest.mockImplementation(async (url, opts = {}) => {
    if (url === "/admin/contacts/stats") return { stats: STATS };
    return handler(url, opts);
  });
  return render(<MemoryRouter initialEntries={[route]}><AdminContactMessages /><Loc /></MemoryRouter>);
}
const listCalls = () => apiRequest.mock.calls.map((c) => c[0]).filter((u) => u.startsWith("/admin/contacts?"));

// بدنه‌ی آکولادی: اگر mockReset برگردانده شود، vitest آن را به‌عنوان تابع cleanup صدا می‌زند
beforeEach(() => { apiRequest.mockReset(); });

describe("AdminContactMessages (صندوق پیام‌ها)", () => {
  it("آمار واقعی، جدول فشرده، و صفحه‌بندی سمت سرور را نشان می‌دهد (بدون متن کامل)", async () => {
    setup(async () => ({ messages: [mk(1), mk(2, { subject: "موضوع دو", isImportant: true })], pagination: { page: 1, limit: 20, total: 45, totalPages: 3 } }));
    expect(await screen.findByText("فرستنده 1")).toBeInTheDocument();
    expect(screen.getByText(/نمایش ۱ – ۲۰ از ۴۵ پیام/)).toBeInTheDocument();
    expect(screen.getByText("۳۸")).toBeInTheDocument(); // جدید از stats
    expect(screen.getByText("۱۲")).toBeInTheDocument(); // مهم
    expect(screen.getByText("موضوع دو")).toBeInTheDocument(); // موضوع به‌جای خلاصه
    expect(screen.getByText("خلاصه 1")).toBeInTheDocument();
    expect(listCalls()[0]).toContain("page=1");
    expect(listCalls()[0]).toContain("limit=20");
  });

  it("رفتن به صفحه‌ی بعد، فقط همان صفحه را از سرور می‌خواهد", async () => {
    setup(async (url) => ({ messages: [mk(url.includes("page=2") ? 21 : 1)], pagination: { page: url.includes("page=2") ? 2 : 1, limit: 20, total: 45, totalPages: 3 } }));
    await screen.findByText("فرستنده 1");
    await userEvent.click(screen.getByRole("button", { name: "صفحه بعد" }));
    expect(await screen.findByText("فرستنده 21")).toBeInTheDocument();
    expect(listCalls().some((u) => u.includes("page=2"))).toBe(true);
  });

  it("فیلتر نوع/وضعیت و جستجو با پارامترهای سرور و بازگشت به صفحه‌ی ۱", async () => {
    setup(async () => ({ messages: [mk(1)], pagination: { page: 1, limit: 20, total: 1, totalPages: 1 } }));
    await screen.findByText("فرستنده 1");
    await userEvent.selectOptions(screen.getByLabelText("فیلتر نوع پیام"), "complaint");
    await userEvent.selectOptions(screen.getByLabelText("فیلتر وضعیت"), "important");
    await waitFor(() => expect(listCalls().at(-1)).toMatch(/type=complaint/));
    expect(listCalls().at(-1)).toMatch(/status=important/);
    await userEvent.type(screen.getByLabelText("جستجوی پیام‌ها"), "علی");
    await waitFor(() => expect(decodeURIComponent(listCalls().at(-1))).toMatch(/q=علی/), { timeout: 2000 });
    expect(listCalls().at(-1)).toMatch(/page=1/);
  });

  it("انتخاب همه + عملیات گروهی خوانده‌شده/مهم", async () => {
    setup(async (url, opts) => {
      if (url === "/admin/contacts/bulk") return { message: "ok", affected: 2 };
      return { messages: [mk(1), mk(2)], pagination: { page: 1, limit: 20, total: 2, totalPages: 1 } };
    });
    await screen.findByText("فرستنده 1");
    await userEvent.click(screen.getByLabelText("انتخاب همه‌ی پیام‌های این صفحه"));
    expect(screen.getByText(/۲ پیام انتخاب‌شده/)).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: /علامت‌گذاری به‌عنوان خوانده‌شده/ }));
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("/admin/contacts/bulk", { method: "POST", body: { ids: [1, 2], action: "read" } }));
    await waitFor(() => expect(screen.queryByText(/پیام انتخاب‌شده/)).not.toBeInTheDocument());
    await userEvent.click(screen.getByLabelText("انتخاب همه‌ی پیام‌های این صفحه"));
    await userEvent.click(screen.getByRole("button", { name: /علامت‌گذاری مهم/ }));
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("/admin/contacts/bulk", { method: "POST", body: { ids: [1, 2], action: "important" } }));
  });

  it("حذف گروهی ابتدا تأییدیه می‌خواهد و با انصراف چیزی حذف نمی‌شود", async () => {
    setup(async (url) => {
      if (url === "/admin/contacts/bulk") return { message: "ok" };
      return { messages: [mk(1), mk(2)], pagination: { page: 1, limit: 20, total: 2, totalPages: 1 } };
    });
    await screen.findByText("فرستنده 1");
    await userEvent.click(screen.getByLabelText("انتخاب همه‌ی پیام‌های این صفحه"));
    await userEvent.click(screen.getByRole("button", { name: /^حذف$/ }));
    expect(await screen.findByText(/آیا از حذف ۲ پیام انتخاب‌شده مطمئن هستید/)).toBeInTheDocument();
    expect(apiRequest).not.toHaveBeenCalledWith("/admin/contacts/bulk", expect.anything());
    await userEvent.click(screen.getByRole("button", { name: "انصراف" }));
    expect(apiRequest).not.toHaveBeenCalledWith("/admin/contacts/bulk", expect.anything());
    await userEvent.click(screen.getByRole("button", { name: /^حذف$/ }));
    await userEvent.click(await screen.findByRole("button", { name: "بله، حذف کن" }));
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("/admin/contacts/bulk", { method: "POST", body: { ids: [1, 2], action: "delete" } }));
  });

  it("«مشاهده» پنل جزئیات را باز می‌کند، متن کامل را نشان می‌دهد و با بستن در همان صفحه می‌ماند", async () => {
    setup(async (url, opts) => {
      if (url === "/admin/contacts/7") return { contact: { ...mk(7, { phone: "0799", subject: "ورزش", status: "read" }), message: "متن کامل و بلند پیام" } };
      if (url.endsWith("/flags")) return { contact: { ...mk(7, { status: "read", isImportant: true }), message: "متن کامل و بلند پیام" } };
      return { messages: [mk(7)], pagination: { page: 3, limit: 20, total: 45, totalPages: 3 } };
    });
    await screen.findByText("فرستنده 7");
    await userEvent.click(screen.getByRole("button", { name: /مشاهده پیام فرستنده 7/ }));
    const dialog = await screen.findByLabelText("جزئیات پیام");
    expect(within(dialog).getByText("متن کامل و بلند پیام")).toBeInTheDocument();
    expect(within(dialog).getByText("0799")).toBeInTheDocument();
    await userEvent.click(within(dialog).getByRole("button", { name: /علامت‌گذاری مهم/ }));
    await waitFor(() => expect(apiRequest).toHaveBeenCalledWith("/admin/contacts/7/flags", { method: "PUT", body: { isImportant: true } }));
    await userEvent.click(within(dialog).getByRole("button", { name: "بستن" }));
    expect(screen.queryByText("متن کامل و بلند پیام")).not.toBeInTheDocument();
    expect(screen.getByText("پیامی انتخاب نشده است")).toBeInTheDocument();
    expect(screen.getByText(/نمایش ۴۱ – ۴۵ از ۴۵ پیام/)).toBeInTheDocument();
  });

  it("حالت خالی با فیلتر، دکمه‌ی پاک کردن فیلتر دارد", async () => {
    setup(async () => ({ messages: [], pagination: { page: 1, limit: 20, total: 0, totalPages: 1 } }));
    await screen.findByText("هنوز پیامی ثبت نشده است.");
  });

  it("پیام بازشده از اعلان، پارامتر highlight را از آدرس پاک می‌کند تا پنل دوباره خودکار باز نشود", async () => {
    setup(async (url) => {
      if (url === "/admin/contacts/7") return { contact: { ...mk(7, { status: "read" }), message: "متن کامل" } };
      return { messages: [mk(7)], pagination: { page: 1, limit: 20, total: 1, totalPages: 1 } };
    }, "/dashboard?tab=contactMessages&highlight=7");
    const dialog = await screen.findByLabelText("جزئیات پیام");
    expect(within(dialog).getByText("متن کامل")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("?tab=contactMessages"));
    await userEvent.click(within(dialog).getByRole("button", { name: "بستن" }));
    expect(screen.queryByText("متن کامل")).not.toBeInTheDocument();
  });

  it("ترتیب کارت‌های آمار مثل طرح است (راست‌چین: پاسخ‌داده‌شده ← مهم ← جدید ← کل) و عددها واقعی‌اند", async () => {
    setup(async () => ({ messages: [mk(1)], pagination: { page: 1, limit: 20, total: 45, totalPages: 3 } }));
    await screen.findByText("فرستنده 1");
    const labels = Array.from(document.querySelectorAll(".cm-stat-label")).map((n) => n.textContent);
    expect(labels).toEqual(["پاسخ‌داده‌شده", "مهم", "جدید", "کل پیام‌ها"]);
    expect(screen.getByText("۴۵")).toBeInTheDocument(); // کل = stats.total
  });

  it("تاریخ‌ها شمسی و با ارقام فارسی نمایش داده می‌شوند؛ نوار ابزار گروهی بدون انتخاب غیرفعال است", async () => {
    setup(async () => ({ messages: [mk(1, { createdAt: "2026-10-07T10:45:00" })], pagination: { page: 1, limit: 20, total: 1, totalPages: 1 } }));
    await screen.findByText("فرستنده 1");
    expect(document.querySelector(".cm-date").textContent).toMatch(/^۱۴۰۵\/۰۷\/۱۵ ۱۰:۴۵$/);
    expect(screen.getByRole("button", { name: /علامت‌گذاری مهم/ })).toBeDisabled();
    expect(screen.getByRole("button", { name: /^حذف$/ })).toBeDisabled();
  });

  it("فقط یک نشان وضعیت در جدول: مهم > پاسخ‌داده‌شده > جدید/خوانده‌شده", async () => {
    setup(async () => ({ messages: [mk(1, { isImportant: true, isAnswered: true }), mk(2, { isAnswered: true, status: "read" }), mk(3), mk(4, { status: "read" })], pagination: { page: 1, limit: 20, total: 4, totalPages: 1 } }));
    await screen.findByText("فرستنده 1");
    const rows = Array.from(document.querySelectorAll(".cm-table tbody tr"));
    expect(rows.map((r) => r.querySelector(".cm-st").textContent)).toEqual(["مهم", "پاسخ‌داده‌شده", "جدید", "خوانده‌شده"]);
    expect(rows.every((r) => r.querySelectorAll(".cm-st").length === 1)).toBe(true);
  });
});

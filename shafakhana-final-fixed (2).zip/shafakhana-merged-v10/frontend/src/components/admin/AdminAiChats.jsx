import { useCallback, useEffect, useState } from "react";
import { Bot, Flag, Siren, MessagesSquare, CalendarDays, Trash2, Search } from "lucide-react";
import { apiRequest } from "../../utils/api.js";
import { useDepartmentToasts, DepartmentToastContainer } from "../dashboard/DepartmentToast.jsx";
import { PageHead, StatCards, StateBlock, SkeletonRows, ConfirmDialog, Badge, fa, buildQs, useDebounced } from "./AdminPro.jsx";

import { tr, trc, jdatetime } from "../../i18n/tr.js";
const KINDS = trc([["all", "همه"], ["normal", "پاسخ‌های عادی"], ["emergency", "هشدار اورژانس"], ["flagged", "علامت‌گذاری‌شده"]]);
const PAGE_SIZES = [10, 20, 50, 100];
const LANGS = trc({ fa: "دری", ps: "پشتو", en: "English" });

function pageNumbers(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const set = new Set([1, total, current - 1, current, current + 1]);
  if (current <= 3) [2, 3, 4, 5].forEach((n) => set.add(n));
  if (current >= total - 2) [total - 4, total - 3, total - 2, total - 1].forEach((n) => set.add(n));
  const sorted = [...set].filter((n) => n >= 1 && n <= total).sort((a, b) => a - b);
  const out = [];
  sorted.forEach((n, i) => {
    if (i > 0 && n - sorted[i - 1] > 1) out.push("gap");
    out.push(n);
  });
  return out;
}

// بازبینی گفتگوهای «دستیار هوشمند صحی» (جدول ai_chat_logs) — ادمین می‌تواند پاسخ نادرست/خطرناک را
// علامت بزند تا بعداً قوانین دستیار (aiController.js) اصلاح شود، یا گفتگو را حذف کند.
export default function AdminAiChats() {
  const [q, setQ] = useState("");
  const [kind, setKind] = useState("all");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [selected, setSelected] = useState(() => new Set());
  const [allMatching, setAllMatching] = useState(false); // «انتخاب همه‌ی نتایج فیلتر فعلی» (در همه‌ی صفحه‌ها)
  const { toasts, showToast, dismissToast } = useDepartmentToasts();
  const [data, setData] = useState({ logs: [], pagination: { page: 1, totalPages: 1, total: 0, limit: 20 } });
  const [stats, setStats] = useState(null);
  const [status, setStatus] = useState("loading"); // loading | ok | error
  const [openId, setOpenId] = useState(null);
  const [toDelete, setToDelete] = useState(null);
  const [busy, setBusy] = useState(false);
  const dq = useDebounced(q, 400);

  const load = useCallback(async () => {
    setStatus((s) => (s === "ok" ? s : "loading"));
    try {
      const [list, st] = await Promise.all([
        apiRequest(`/admin/ai-chats${buildQs({ q: dq, kind: kind === "all" ? "" : kind, page, limit })}`),
        apiRequest("/admin/ai-chats/stats"),
      ]);
      setData(list);
      setStats(st);
      setStatus("ok");
    } catch {
      setStatus("error");
    }
  }, [dq, kind, page, limit]);

  useEffect(() => {
    load();
  }, [load]);

  // با تغییر فیلتر/جستجو/تعداد در صفحه، به صفحه‌ی اول برگرد و انتخاب را پاک کن
  useEffect(() => {
    setPage(1);
    setSelected(new Set());
    setAllMatching(false);
  }, [dq, kind, limit]);

  async function toggleFlag(log) {
    const flagged = !log.flagged;
    setData((d) => ({ ...d, logs: d.logs.map((l) => (l.id === log.id ? { ...l, flagged: flagged ? 1 : 0 } : l)) }));
    try {
      await apiRequest(`/admin/ai-chats/${log.id}/flag`, { method: "PUT", body: { flagged } });
      apiRequest("/admin/ai-chats/stats").then(setStats).catch(() => {});
    } catch {
      load();
    }
  }

  async function confirmDelete() {
    if (!toDelete) return;
    setBusy(true);
    try {
      if (toDelete.bulk) {
        const body = allMatching
          ? { selectAll: true, q: dq, kind: kind === "all" ? "" : kind }
          : { ids: [...selected] };
        const r = await apiRequest("/admin/ai-chats/bulk-delete", { method: "POST", body });
        showToast(tr("{0} گفتگو حذف شد.", [fa(r.deleted ?? 0)]));
        setSelected(new Set());
        setAllMatching(false);
        setToDelete(null);
        if (page === 1) await load(); else setPage(1);
      } else {
        await apiRequest(`/admin/ai-chats/${toDelete.id}`, { method: "DELETE" });
        setSelected((prev) => { const next = new Set(prev); next.delete(toDelete.id); return next; });
        setToDelete(null);
        // اگر آخرین ردیف یک صفحه حذف شد، به صفحه‌ی قبل برگرد
        if (data.logs.length === 1 && page > 1) setPage(page - 1); else await load();
      }
    } catch (err) {
      showToast(err?.message || tr("حذف انجام نشد."), "error");
      setToDelete(null);
    } finally {
      setBusy(false);
    }
  }

  function toggleRow(id) {
    if (allMatching) {
      // خروج از حالت «همه‌ی نتایج»: فقط ردیف‌های همین صفحه (به‌جز این ردیف) انتخاب می‌مانند
      setAllMatching(false);
      setSelected(new Set(data.logs.map((l) => l.id).filter((x) => x !== id)));
      return;
    }
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }

  const logs = Array.isArray(data?.logs) ? data.logs : [];
  const pagination = { total: 0, page: 1, totalPages: 1, limit: 20, ...(data?.pagination || {}) };
  const allOnPageSelected = logs.length > 0 && (allMatching || logs.every((l) => selected.has(l.id)));
  const selectedCount = allMatching ? pagination.total : selected.size;
  const from = pagination.total === 0 ? 0 : (pagination.page - 1) * pagination.limit + 1;
  const to = Math.min(pagination.page * pagination.limit, pagination.total);

  function toggleAll() {
    if (allOnPageSelected) {
      setSelected(new Set());
      setAllMatching(false);
    } else {
      setSelected((prev) => new Set([...prev, ...logs.map((l) => l.id)]));
    }
  }

  return (
    <div className="pm-page ap-aichat">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      <PageHead
        title={tr("گفتگوهای دستیار هوشمند")}
        subtitle={tr("پرسش‌های بیماران و پاسخ‌های دستیار؛ پاسخ نادرست را علامت بزنید تا قوانین دستیار بهتر شود.")}
        onRefresh={load}
        refreshing={status === "loading"}
      />

      <StatCards
        items={[
          { key: "total", tone: "total", label: tr("کل گفتگوها"), value: stats?.total, Icon: MessagesSquare },
          { key: "today", tone: "active", label: tr("امروز"), value: stats?.today, Icon: CalendarDays },
          { key: "em", tone: "danger", label: tr("هشدار اورژانس"), value: stats?.emergency, Icon: Siren, active: kind === "emergency", onClick: () => setKind(kind === "emergency" ? "all" : "emergency") },
          { key: "fl", tone: "inactive", label: tr("علامت‌گذاری‌شده"), value: stats?.flagged, Icon: Flag, active: kind === "flagged", onClick: () => setKind(kind === "flagged" ? "all" : "flagged") },
        ]}
      />

      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="pm-search">
            <Search size={16} aria-hidden="true" />
            <input type="search" dir="auto" value={q} onChange={(e) => setQ(e.target.value)} placeholder={tr("جستجو در پرسش، پاسخ یا نام بیمار...")} aria-label={tr("جستجو در گفتگوها")} />
          </div>
          <select className="pm-select dash-select" value={kind} onChange={(e) => setKind(e.target.value)} aria-label={tr("نوع گفتگو")}>
            {KINDS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </div>
      </div>

      {status === "loading" && <SkeletonRows rows={6} />}
      {status === "error" && <StateBlock kind="error" title={tr("خطا در دریافت گفتگوها")} message={tr("ارتباط با سرور برقرار نشد.")} onRetry={load} />}
      {status === "ok" && logs.length === 0 && <StateBlock title={tr("گفتگویی یافت نشد")} message={tr("هنوز بیماری از دستیار سؤالی نپرسیده یا فیلتر شما نتیجه‌ای ندارد.")} />}

      {status === "ok" && logs.length > 0 && (
        <div className="ap-aichat-bulkbar" role="toolbar" aria-label={tr("عملیات گروهی")}>
          <label className="ap-aichat-selall">
            <input type="checkbox" checked={allOnPageSelected} onChange={toggleAll} aria-label={tr("انتخاب همه‌ی گفتگوهای این صفحه")} />
            <span>{tr("انتخاب همه")}</span>
          </label>
          {selectedCount > 0 && <span className="ap-aichat-selcount">{tr("{0} گفتگو انتخاب شده", [fa(selectedCount)])}</span>}
          <button type="button" className="btn btn-sm btn-ghost ap-aichat-bulkdel" disabled={busy || selectedCount === 0} onClick={() => setToDelete({ bulk: true })}>
            <Trash2 size={14} />{" "}{tr("حذف انتخاب‌شده‌ها")}
          </button>
        </div>
      )}

      {status === "ok" && logs.length > 0 && allOnPageSelected && pagination.total > logs.length && (
        <div className="ap-aichat-selbanner" role="status">
          {allMatching ? (
            <>
              <span>{tr("همه‌ی {0} گفتگو انتخاب شده‌اند.", [fa(pagination.total)])}</span>
              <button type="button" className="ap-linkbtn" onClick={() => { setAllMatching(false); setSelected(new Set()); }}>{tr("لغو انتخاب")}</button>
            </>
          ) : (
            <>
              <span>{tr("{0} گفتگوی این صفحه انتخاب شد.", [fa(logs.length)])}</span>
              <button type="button" className="ap-linkbtn" onClick={() => setAllMatching(true)}>{tr("انتخاب همه‌ی {0} گفتگو در تمام صفحه‌ها", [fa(pagination.total)])}</button>
            </>
          )}
        </div>
      )}

      {status === "ok" && logs.length > 0 && (
        <ul className="ap-aichat-list">
          {logs.map((l) => {
            const open = openId === l.id;
            const isSel = allMatching || selected.has(l.id);
            return (
              <li key={l.id} className={`ap-aichat-item${l.flagged ? " is-flagged" : ""}${l.emergency ? " is-emergency" : ""}${isSel ? " is-selected" : ""}`}>
                <div className="ap-aichat-row">
                <label className="ap-aichat-check">
                  <input type="checkbox" checked={isSel} onChange={() => toggleRow(l.id)} aria-label={tr("انتخاب گفتگو")} />
                </label>
                <button type="button" className="ap-aichat-head" onClick={() => setOpenId(open ? null : l.id)} aria-expanded={open}>
                  <Bot size={18} aria-hidden="true" />
                  <span className="ap-aichat-q" dir="auto">{l.question}</span>
                  <span className="ap-aichat-meta">
                    {l.emergency ? <Badge tone="danger">{tr("اورژانس")}</Badge> : null}
                    {l.flagged ? <Badge tone="warn">{tr("علامت‌خورده")}</Badge> : null}
                    <Badge tone="muted">{LANGS[l.lang] || l.lang}</Badge>
                    <small>{l.userName || "—"} · {jdatetime(l.createdAt)}</small>
                  </span>
                </button>
                </div>
                {open && (
                  <div className="ap-aichat-body">
                    <div>
                      <strong>{tr("پرسش بیمار")}</strong>
                      <p dir="auto">{l.question}</p>
                    </div>
                    <div>
                      <strong>{tr("پاسخ دستیار")}</strong>
                      <p dir="auto">{l.answer}</p>
                    </div>
                    <div className="ap-aichat-actions">
                      <button type="button" className={`btn btn-sm ${l.flagged ? "btn-primary" : "btn-ghost"}`} onClick={() => toggleFlag(l)}>
                        <Flag size={14} /> {l.flagged ? tr("برداشتن علامت") : tr("پاسخ نادرست / نیازمند اصلاح")}
                      </button>
                      <button type="button" className="btn btn-sm btn-ghost" onClick={() => setToDelete(l)}>
                        <Trash2 size={14} />{" "}{tr("حذف")}</button>
                    </div>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}

      {status === "ok" && pagination.total > 0 && (
        <nav className="pm-pager" aria-label={tr("صفحه‌بندی")}>
          <label className="ap-cmc-size">
            <span className="pm-muted">{tr("در صفحه:")}</span>
            <select className="pm-select dash-select" value={limit} onChange={(e) => setLimit(Number(e.target.value))} aria-label={tr("تعداد گفتگو در هر صفحه")}>
              {PAGE_SIZES.map((n) => <option key={n} value={n}>{fa(n)}</option>)}
            </select>
          </label>
          <span>{tr("نمایش {0} تا {1} از {2} گفتگو", [fa(from), fa(to), fa(pagination.total)])}</span>
          {pagination.totalPages > 1 && (
            <div className="pm-pages">
              <button type="button" className="pm-page-btn" disabled={pagination.page <= 1} onClick={() => setPage(pagination.page - 1)} aria-label={tr("صفحه‌ی قبلی")}>{tr("قبلی")}</button>
              {pageNumbers(pagination.page, pagination.totalPages).map((n, idx) => (
                n === "gap"
                  ? <span key={`gap-${idx}`} className="pm-muted">…</span>
                  : <button key={n} type="button" className="pm-page-btn" aria-current={n === pagination.page ? "page" : undefined} onClick={() => setPage(n)}>{fa(n)}</button>
              ))}
              <button type="button" className="pm-page-btn" disabled={pagination.page >= pagination.totalPages} onClick={() => setPage(pagination.page + 1)} aria-label={tr("صفحه‌ی بعدی")}>{tr("بعدی")}</button>
            </div>
          )}
        </nav>
      )}

      <ConfirmDialog
        open={!!toDelete}
        danger
        busy={busy}
        title={toDelete?.bulk ? tr("حذف گروهی گفتگوها") : tr("حذف گفتگو")}
        message={toDelete?.bulk ? tr("آیا مطمئن هستید می‌خواهید {0} گفتگوی انتخاب‌شده را برای همیشه حذف کنید؟", [fa(selectedCount)]) : tr("این گفتگو برای همیشه از گزارش حذف می‌شود.")}
        note={toDelete?.bulk ? tr("این کار قابل بازگشت نیست.") : undefined}
        confirmLabel={tr("حذف")}
        busyLabel={tr("در حال حذف...")}
        onConfirm={confirmDelete}
        onCancel={() => setToDelete(null)}
      />
    </div>
  );
}

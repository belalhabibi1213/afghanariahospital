import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useSearchParams } from "react-router-dom";
import {
  Search, X, Mail, Trash2, Phone, Eye, Star, CheckCircle2, Tag, Calendar, User, Circle, MailOpen, Inbox,
  Lightbulb, MessageSquareWarning, TriangleAlert, CircleHelp, MessageCircle, ChevronRight, ChevronLeft,
} from "lucide-react";
import { apiRequest } from "../../utils/api.js";
import useHighlightParam from "../../hooks/useHighlightParam.js";
import { useDepartmentToasts, DepartmentToastContainer } from "../dashboard/DepartmentToast.jsx";
import { PageHead, StateBlock, SkeletonRows, ConfirmDialog, useDebounced, buildQs } from "./AdminPro.jsx";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, numLocale, tdigits } from "../../i18n/tr.js";
const TYPE_META = trc({
  suggestion: { label: "پیشنهاد", Icon: Lightbulb },
  criticism: { label: "انتقاد", Icon: MessageSquareWarning },
  complaint: { label: "شکایت", Icon: TriangleAlert },
  question: { label: "سوال", Icon: CircleHelp },
  other: { label: "سایر", Icon: MessageCircle },
});
const STATUS_OPTIONS = trc([["all", "همه"], ["new", "جدید"], ["read", "خوانده‌شده"], ["important", "مهم"], ["answered", "پاسخ‌داده‌شده"]]);
const PAGE_SIZES = [20, 50, 100];

// ---------- قالب‌بندی (ارقام فارسی، تاریخ شمسی، بدون به‌هم‌ریختگی جهت متن) ----------
const toFa = (s) => tdigits(String(s));
const faNum = (n) => toFa(Number(n || 0).toLocaleString("en-US"));
const dfDate = { format: (d) => new Intl.DateTimeFormat(numLocale(), { year: "numeric", month: "2-digit", day: "2-digit" }).format(d) };
const dfTime = { format: (d) => new Intl.DateTimeFormat(numLocale(), { hour: "2-digit", minute: "2-digit", hour12: false }).format(d) };
const fmtDT = (v) => {
  if (!v) return "—";
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? "—" : `${dfDate.format(d)} ${dfTime.format(d)}`;
};

// یک نشان وضعیت اصلی (مثل طرح): مهم > پاسخ‌داده‌شده > جدید/خوانده‌شده
function primaryStatus(m) {
  if (m.isImportant) return { tone: "important", label: tr("مهم"), Icon: Star };
  if (m.isAnswered) return { tone: "answered", label: tr("پاسخ‌داده‌شده"), Icon: null };
  return m.status === "unread" ? { tone: "new", label: tr("جدید"), Icon: null } : { tone: "read", label: tr("خوانده‌شده"), Icon: null };
}
function StatusBadge({ m }) {
  const { tone, label, Icon } = primaryStatus(m);
  return <span className={`cm-st cm-st-${tone}`}>{Icon && <Icon size={12} fill="currentColor" />}{label}</span>;
}
function TypeBadge({ type }) {
  const { label, Icon } = TYPE_META[type] || TYPE_META.other;
  return <span className={`cm-ty cm-ty-${TYPE_META[type] ? type : "other"}`}><Icon size={12} />{label}</span>;
}

function useNarrow() {
  const query = "(max-width: 1180px)";
  const [narrow, setNarrow] = useState(() => typeof window !== "undefined" && !!window.matchMedia && window.matchMedia(query).matches);
  useEffect(() => {
    if (!window.matchMedia) return undefined;
    const mq = window.matchMedia(query);
    const onChange = (e) => setNarrow(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return narrow;
}

// صندوق پیام‌های «تماس با ما»: آمار → جستجو/فیلتر → [جدول | پنل جزئیات چسبیده] → صفحه‌بندی.
// جستجو، فیلتر و صفحه‌بندی همه سمت سرور است (فقط ردیف‌های صفحه‌ی جاری دریافت می‌شود).
export default function AdminContactMessages() {
  const { highlightId } = useHighlightParam();
  const [, setSearchParams] = useSearchParams();
  const { toasts, showToast, dismissToast } = useDepartmentToasts();
  const narrow = useNarrow();
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [search, setSearch] = useState("");
  const debouncedSearch = useDebounced(search);
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(20);
  const [messages, setMessages] = useState(null);
  const [pagination, setPagination] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedIds, setSelectedIds] = useState([]);
  const [panelId, setPanelId] = useState(null);
  const [panelMsg, setPanelMsg] = useState(null);
  const [panelLoading, setPanelLoading] = useState(false);
  const [actioning, setActioning] = useState(false);
  const [deleteIds, setDeleteIds] = useState(null); // آرایه‌ی شناسه‌های در انتظار تأیید حذف
  const reqSeq = useRef(0);

  const query = { status: statusFilter === "all" ? undefined : statusFilter, type: typeFilter === "all" ? undefined : typeFilter, q: debouncedSearch, dateFrom, dateTo, page, limit };
  const queryKey = JSON.stringify(query);

  const reload = useCallback(() => {
    const seq = ++reqSeq.current;
    setLoading(true);
    setError("");
    apiRequest(`/admin/contacts${buildQs(JSON.parse(queryKey))}`)
      .then((data) => {
        if (seq !== reqSeq.current) return; // پاسخ کهنه‌ی درخواست قبلی
        setMessages(data.messages || []);
        setPagination(data.pagination || null);
        if (data.pagination && data.pagination.page > data.pagination.totalPages) setPage(data.pagination.totalPages);
      })
      .catch((err) => { if (seq === reqSeq.current) setError(err.message || tr("خطا در بارگذاری پیام‌ها")); })
      .finally(() => { if (seq === reqSeq.current) setLoading(false); });
  }, [queryKey]);
  const reloadStats = useCallback(() => {
    apiRequest("/admin/contacts/stats").then((d) => setStats(d.stats)).catch(() => setStats(null));
  }, []);

  useEffect(() => { reload(); }, [reload]);
  useEffect(() => { reloadStats(); }, [reloadStats]);
  // با عوض شدن فیلتر/جستجو/اندازه‌ی صفحه: برگشت به صفحه‌ی ۱ و پاک شدن انتخاب‌ها
  useEffect(() => { setPage(1); }, [statusFilter, typeFilter, debouncedSearch, dateFrom, dateTo, limit]);
  useEffect(() => { setSelectedIds([]); }, [queryKey]);

  async function openMessage(id) {
    setPanelId(id);
    setPanelLoading(true);
    try {
      const data = await apiRequest(`/admin/contacts/${id}`); // بک‌اند خودکار «خوانده‌شده» می‌کند
      setPanelMsg(data.contact);
      setMessages((list) => (list ? list.map((m) => (m.id === id ? { ...m, status: data.contact.status } : m)) : list));
      reloadStats();
    } catch (err) {
      showToast(err.message || tr("باز کردن پیام انجام نشد."), "error");
      setPanelId(null);
    } finally {
      setPanelLoading(false);
    }
  }
  // پارامتر highlight (از اعلان) فقط یک‌بار مصرف می‌شود و بلافاصله از آدرس پاک می‌شود؛ وگرنه بعد از بستن
  // پنل و رفتن به تب دیگر (که بقیه‌ی پارامترهای URL را نگه می‌دارد) با برگشتن، پنل دوباره خودکار باز می‌شد.
  useEffect(() => {
    if (!highlightId) return;
    openMessage(highlightId);
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.delete("highlight");
      return next;
    }, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [highlightId]);

  const closePanel = useCallback(() => { setPanelId(null); setPanelMsg(null); }, []);
  function afterChange() { reload(); reloadStats(); }

  async function setFlags(m, flags, okText) {
    setActioning(true);
    try {
      const data = await apiRequest(`/admin/contacts/${m.id}/flags`, { method: "PUT", body: flags });
      setPanelMsg((p) => (p && p.id === m.id ? { ...p, ...data.contact } : p));
      showToast(okText);
      afterChange();
    } catch (err) { showToast(err.message || tr("انجام نشد."), "error"); } finally { setActioning(false); }
  }
  async function setReadState(m, status) {
    setActioning(true);
    try {
      await apiRequest(`/admin/contacts/${m.id}/status`, { method: "PUT", body: { status } });
      setPanelMsg((p) => (p && p.id === m.id ? { ...p, status } : p));
      showToast(status === "read" ? tr("پیام «خوانده‌شده» شد.") : tr("پیام «جدید» شد."));
      afterChange();
    } catch (err) { showToast(err.message || tr("تغییر وضعیت انجام نشد."), "error"); } finally { setActioning(false); }
  }

  async function bulk(action, okText) {
    if (selectedIds.length === 0) return;
    setActioning(true);
    try {
      const data = await apiRequest("/admin/contacts/bulk", { method: "POST", body: { ids: selectedIds, action } });
      showToast(okText || data.message);
      setSelectedIds([]);
      afterChange();
    } catch (err) { showToast(err.message || tr("عملیات گروهی انجام نشد."), "error"); } finally { setActioning(false); }
  }

  async function confirmDelete() {
    if (!deleteIds || deleteIds.length === 0) return;
    setActioning(true);
    try {
      if (deleteIds.length === 1) await apiRequest(`/admin/contacts/${deleteIds[0]}`, { method: "DELETE" });
      else await apiRequest("/admin/contacts/bulk", { method: "POST", body: { ids: deleteIds, action: "delete" } });
      if (deleteIds.includes(panelId)) closePanel();
      setSelectedIds((s) => s.filter((id) => !deleteIds.includes(id)));
      showToast(deleteIds.length === 1 ? tr("پیام حذف شد.") : tr("{0} پیام حذف شد.", [faNum(deleteIds.length)]));
      setDeleteIds(null);
      afterChange();
    } catch (err) {
      showToast(err.message || tr("حذف انجام نشد."), "error");
      setDeleteIds(null);
    } finally { setActioning(false); }
  }

  const items = messages || [];
  const noneSelected = selectedIds.length === 0;
  const allOnPageSelected = items.length > 0 && items.every((m) => selectedIds.includes(m.id));
  const toggleAll = () => setSelectedIds(allOnPageSelected ? [] : items.map((m) => m.id));
  const toggleOne = (id) => setSelectedIds((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));

  const hasFilter = statusFilter !== "all" || typeFilter !== "all" || !!debouncedSearch || !!dateFrom || !!dateTo;
  function clearFilters() { setStatusFilter("all"); setTypeFilter("all"); setSearch(""); setDateFrom(""); setDateTo(""); }

  // ترتیب DOM: در صفحه‌ی راست‌چین اولین کارت سمت راست قرار می‌گیرد (مثل طرح: پاسخ‌داده‌شده ← کل پیام‌ها)
  const cards = [
    { key: "answered", label: tr("پاسخ‌داده‌شده"), value: stats?.answered, Icon: CheckCircle2, filter: "answered" },
    { key: "important", label: tr("مهم"), value: stats?.important, Icon: Star, filter: "important" },
    { key: "new", label: tr("جدید"), value: stats?.unread, Icon: Circle, filter: "new" },
    { key: "total", label: tr("کل پیام‌ها"), value: stats?.total, Icon: Mail, filter: "all" },
  ];

  return (
    <div className="pm-page cm-page">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      <PageHead
        title={tr("پیام‌های تماس با ما")}
        subtitle={tr("مدیریت پیام‌های ارسال‌شده توسط بازدیدکنندگان از طریق فرم تماس با ما در صفحه اصلی سایت")}
      />

      <div className="cm-stats">
        {cards.map(({ key, label, value, Icon, filter }) => (
          <button key={key} type="button" className={`cm-stat cm-stat-${key} ${statusFilter === filter ? "is-active" : ""}`} aria-pressed={statusFilter === filter} onClick={() => setStatusFilter(filter)}>
            <span className="cm-stat-text">
              <span className="cm-stat-label">{label}</span>
              <span className="cm-stat-num">{value === undefined || value === null ? "—" : faNum(value)}</span>
            </span>
            <span className="cm-stat-icon"><Icon size={key === "new" ? 14 : 19} fill={key === "new" || key === "important" ? "currentColor" : "none"} /></span>
          </button>
        ))}
      </div>

      <div className="pm-filterbar cm-filterbar">
        <div className="cm-filter-row">
          <div className="pm-search cm-search">
            <Search size={16} />
            <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder={tr("جستجو در نام، ایمیل، تلفن، موضوع و متن پیام...")} aria-label={tr("جستجوی پیام‌ها")} />
          </div>
          <label className="cm-select"><span>{tr("نوع پیام")}</span>
            <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} aria-label={tr("فیلتر نوع پیام")}>
              <option value="all">{tr("همه")}</option>
              {Object.entries(TYPE_META).map(([v, { label }]) => <option key={v} value={v}>{label}</option>)}
            </select>
          </label>
          <label className="cm-select"><span>{tr("وضعیت")}</span>
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={tr("فیلتر وضعیت")}>
              {STATUS_OPTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </label>
          <DateField label={tr("از")} value={dateFrom} max={dateTo} onChange={setDateFrom} aria={tr("از تاریخ")} />
          <DateField label={tr("تا")} value={dateTo} min={dateFrom} onChange={setDateTo} aria={tr("تا تاریخ")} />
          {hasFilter && <button type="button" className="btn btn-ghost btn-sm pm-clear cm-clear" onClick={clearFilters}><X size={14} />{" "}{tr("پاک کردن فیلترها")}</button>}
        </div>
      </div>

      <div className="cm-main">
        <section className="cm-box" aria-label={tr("فهرست پیام‌ها")}>
          <div className="cm-toolbar">
            <label className="cm-checkall">
              <input type="checkbox" checked={allOnPageSelected} onChange={toggleAll} disabled={items.length === 0} aria-label={tr("انتخاب همه‌ی پیام‌های این صفحه")} />
              <span>{tr("انتخاب همه")}</span>
            </label>
            <button type="button" className="cm-tbtn cm-tbtn-gold" disabled={noneSelected || actioning} onClick={() => bulk("important", tr("پیام‌ها «مهم» شدند."))}><Star size={14} />{" "}{tr("علامت‌گذاری مهم")}</button>
            <button type="button" className="cm-tbtn cm-tbtn-green" disabled={noneSelected || actioning} onClick={() => bulk("read", tr("پیام‌ها «خوانده‌شده» شدند."))}><MailOpen size={14} />{" "}{tr("علامت‌گذاری به‌عنوان خوانده‌شده")}</button>
            <button type="button" className="cm-tbtn cm-tbtn-red" disabled={noneSelected || actioning} onClick={() => setDeleteIds(selectedIds)}><Trash2 size={14} />{" "}{tr("حذف")}</button>
            {!noneSelected && <span className="cm-selcount" role="status">{tr("{0} پیام انتخاب‌شده", [faNum(selectedIds.length)])}</span>}
          </div>

          {error && !messages && <StateBlock kind="error" title={tr("بارگذاری پیام‌ها انجام نشد")} message={error} onRetry={reload} />}
          {error && messages && <div className="form-message error" role="alert">{error}</div>}
          {loading && !messages && !error && <SkeletonRows rows={6} />}
          {messages && messages.length === 0 && (
            hasFilter
              ? <StateBlock title={tr("برای این فیلتر نتیجه‌ای پیدا نشد.")} message={tr("فیلتر یا عبارت جستجو را تغییر دهید.")} action={<button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button>} />
              : <StateBlock title={tr("هنوز پیامی ثبت نشده است.")} message={tr("پیام‌های فرم تماس با ما اینجا نمایش داده می‌شود.")} />
          )}

          {items.length > 0 && (
            <div className={`cm-scroll ${loading ? "is-busy" : ""}`}>
              <table className="pm-table cm-table">
                <thead>
                  <tr>
                    <th className="cm-col-check"><input type="checkbox" checked={allOnPageSelected} onChange={toggleAll} aria-label={tr("انتخاب همه (سرستون)")} /></th>
                    <th>{tr("وضعیت")}</th>
                    <th>{tr("نوع")}</th>
                    <th>{tr("فرستنده")}</th>
                    <th>{tr("موضوع")}</th>
                    <th>{tr("تاریخ ارسال")}</th>
                    <th>{tr("عملیات")}</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map((m) => (
                    <tr key={m.id} className={`${m.status === "unread" ? "is-unread" : ""} ${panelId === m.id ? "is-selected" : ""}`}>
                      <td className="pm-cell-check cm-col-check"><input type="checkbox" checked={selectedIds.includes(m.id)} onChange={() => toggleOne(m.id)} aria-label={tr("انتخاب پیام {0}", [m.fullName])} /></td>
                      <td data-label={tr("وضعیت")}><StatusBadge m={m} /></td>
                      <td data-label={tr("نوع")}><TypeBadge type={m.type} /></td>
                      <td className="pm-cell-name" data-label={tr("فرستنده")}>
                        <span className="cm-name">{m.fullName}</span>
                        {(m.email || m.phone) && <span className="cm-sub" dir="ltr">{m.email || m.phone}</span>}
                      </td>
                      <td data-label={tr("موضوع")} className="cm-summary-cell">
                        <span className="cm-summary" title={m.subject || m.preview}>{m.subject || m.preview}</span>
                      </td>
                      <td data-label={tr("تاریخ ارسال")} className="cm-date"><bdi dir="ltr">{fmtDT(m.createdAt)}</bdi></td>
                      <td className="pm-cell-actions">
                        <button type="button" className="cm-view" onClick={() => openMessage(m.id)} aria-label={tr("مشاهده پیام {0}", [m.fullName])}><Eye size={14} />{" "}{tr("مشاهده")}</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {pagination && pagination.total > 0 && <Pager pagination={pagination} onPage={setPage} limit={limit} onLimit={setLimit} />}
        </section>

        <DetailPanel
          narrow={narrow}
          open={!!panelId}
          loading={panelLoading && !panelMsg}
          msg={panelMsg}
          busy={actioning}
          onClose={closePanel}
          onRead={(m) => setReadState(m, m.status === "read" ? "unread" : "read")}
          onImportant={(m) => setFlags(m, { isImportant: !m.isImportant }, m.isImportant ? tr("علامت «مهم» برداشته شد.") : tr("پیام «مهم» شد."))}
          onAnswered={(m) => setFlags(m, { isAnswered: !m.isAnswered }, m.isAnswered ? tr("علامت «پاسخ‌داده‌شده» برداشته شد.") : tr("پیام «پاسخ‌داده‌شده» شد."))}
          onDelete={(m) => setDeleteIds([m.id])}
        />
      </div>

      <ConfirmDialog
        open={!!deleteIds}
        danger
        title={deleteIds && deleteIds.length > 1 ? tr("حذف گروهی پیام‌ها") : tr("حذف پیام")}
        message={deleteIds && deleteIds.length > 1 ? tr("آیا از حذف {0} پیام انتخاب‌شده مطمئن هستید؟", [faNum(deleteIds.length)]) : tr("آیا از حذف این پیام مطمئن هستید؟")}
        note={tr("این عملیات غیرقابل بازگشت است.")}
        confirmLabel={tr("بله، حذف کن")}
        busyLabel={tr("در حال حذف...")}
        busy={actioning}
        onConfirm={confirmDelete}
        onCancel={() => setDeleteIds(null)}
      />
    </div>
  );
}

// فیلد تاریخ: مقدار به‌صورت شمسی نمایش داده می‌شود ولی مقدار واقعی همان ISO میلادی است که API می‌خواهد.
// input اصلی شفاف روی کادر قرار دارد تا کلیک روی کل کادر، انتخابگر تاریخ مرورگر را باز کند.
function DateField({ label, value, min, max, onChange, aria }) {
  return (
    <label className="cm-datef">
      <span>{label}</span>
      <span className="cm-datebox">
        <JalaliDateInput
          value={value}
          min={min || undefined}
          max={max || undefined}
          placeholder={tr("انتخاب تاریخ")}
          onChange={(e) => onChange(e.target.value)}
          aria-label={aria}
        />
      </span>
    </label>
  );
}

function pageWindow(page, totalPages) {
  const set = new Set([1, totalPages, page - 1, page, page + 1]);
  const nums = [...set].filter((n) => n >= 1 && n <= totalPages).sort((a, b) => a - b);
  const out = [];
  nums.forEach((n, i) => {
    if (i > 0 && n - nums[i - 1] > 1) out.push("gap");
    out.push(n);
  });
  return out;
}

// ترتیب DOM در RTL: تعداد در هر صفحه (راست) ← شماره صفحه‌ها (وسط) ← بازه‌ی نمایش (چپ)
function Pager({ pagination, onPage, limit, onLimit }) {
  const { page, total, totalPages } = pagination;
  const from = (page - 1) * pagination.limit + 1;
  const to = Math.min(page * pagination.limit, total);
  return (
    <nav className="cm-pager" aria-label={tr("صفحه‌بندی")}>
      <label className="cm-pagesize"><span>{tr("تعداد در هر صفحه:")}</span>
        <select value={limit} onChange={(e) => onLimit(Number(e.target.value))} aria-label={tr("تعداد در هر صفحه")}>
          {PAGE_SIZES.map((s) => <option key={s} value={s}>{toFa(s)}</option>)}
        </select>
      </label>
      {totalPages > 1 && (
        <div className="cm-pages">
          <button type="button" className="cm-pbtn" disabled={page <= 1} onClick={() => onPage(page - 1)} aria-label={tr("صفحه قبل")}><ChevronRight size={15} /></button>
          {pageWindow(page, totalPages).map((n, i) => (n === "gap"
            ? <span key={`g${i}`} className="cm-dots">…</span>
            : <button key={n} type="button" className="cm-pbtn" aria-current={n === page ? "page" : undefined} onClick={() => onPage(n)}>{faNum(n)}</button>))}
          <button type="button" className="cm-pbtn" disabled={page >= totalPages} onClick={() => onPage(page + 1)} aria-label={tr("صفحه بعد")}><ChevronLeft size={15} /></button>
        </div>
      )}
      <span className="cm-range">{tr("نمایش {0} – {1} از {2} پیام", [faNum(from), faNum(to), faNum(total)])}</span>
    </nav>
  );
}

// پنل جزئیات: در دسکتاپ کنار جدول چسبیده است (مثل طرح)؛ در صفحه‌ی باریک از سمت راست روی صفحه باز می‌شود.
function DetailPanel({ narrow, open, loading, msg, busy, onClose, onRead, onImportant, onAnswered, onDelete }) {
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  const inner = (
    <>
      <header className="cm-dock-head">
        <h3>{tr("جزئیات پیام")}</h3>
        {open && <button type="button" className="cm-dock-close" onClick={onClose} aria-label={tr("بستن")}><X size={18} /></button>}
      </header>
      {!open && (
        <div className="cm-dock-empty">
          <Inbox size={30} />
          <strong>{tr("پیامی انتخاب نشده است")}</strong>
          <span>{tr("برای دیدن متن کامل، روی «مشاهده» یکی از پیام‌ها بزنید.")}</span>
        </div>
      )}
      {open && loading && <div className="cm-dock-body"><SkeletonRows rows={4} /></div>}
      {open && msg && (
        <>
          <div className="cm-dock-body">
            <div className="cm-prows">
              <div className="cm-prow"><span className="cm-pico"><User size={15} /></span><div className="cm-pcol"><span className="cm-plabel">{tr("نام فرستنده")}</span><span className="cm-pval">{msg.fullName}</span></div></div>
              <div className="cm-prow"><span className="cm-pico"><Mail size={15} /></span><div className="cm-pcol"><span className="cm-plabel">{tr("ایمیل")}</span><span className="cm-pval" dir="ltr">{msg.email || "—"}</span></div></div>
              <div className="cm-prow"><span className="cm-pico"><Phone size={15} /></span><div className="cm-pcol"><span className="cm-plabel">{tr("شماره تلفن")}</span><span className="cm-pval" dir="ltr">{msg.phone || "—"}</span></div></div>
            </div>
            <div className="cm-mrows">
              <div className="cm-mrow"><span className="cm-pico"><Tag size={15} /></span><span className="cm-mlabel">{tr("نوع پیام")}</span><TypeBadge type={msg.type} /></div>
              <div className="cm-mrow">
                <span className="cm-pico"><Eye size={15} /></span><span className="cm-mlabel">{tr("وضعیت")}</span>
                <span className="cm-mstatus">
                  <span className={`cm-st ${msg.status === "unread" ? "cm-st-new" : "cm-st-read"}`}>{msg.status === "unread" ? tr("جدید") : tr("خوانده‌شده")}</span>
                  {msg.isImportant && <span className="cm-st cm-st-important"><Star size={12} fill="currentColor" />{tr("مهم")}</span>}
                  {msg.isAnswered && <span className="cm-st cm-st-answered">{tr("پاسخ‌داده‌شده")}</span>}
                </span>
              </div>
              <div className="cm-mrow"><span className="cm-pico"><Calendar size={15} /></span><span className="cm-mlabel">{tr("تاریخ ارسال")}</span><bdi className="cm-mdate" dir="ltr">{fmtDT(msg.createdAt)}</bdi></div>
              {msg.subject && <div className="cm-mrow"><span className="cm-pico"><MessageCircle size={15} /></span><span className="cm-mlabel">{tr("موضوع")}</span><span className="cm-msubject">{msg.subject}</span></div>}
            </div>
            <div className="cm-text">
              <span className="cm-text-label">{tr("متن کامل پیام")}</span>
              <p>{msg.message}</p>
            </div>
          </div>
          <footer className="cm-dock-foot">
            <div className="cm-dock-btns">
              <button type="button" className="cm-fbtn cm-fbtn-green" disabled={busy} onClick={() => onRead(msg)}>
                {msg.status === "read" ? <><Mail size={14} />{" "}{tr("علامت جدید")}</> : <><CheckCircle2 size={14} />{" "}{tr("خوانده شد")}</>}
              </button>
              <button type="button" className="cm-fbtn cm-fbtn-gold" disabled={busy} onClick={() => onImportant(msg)}><Star size={14} /> {msg.isImportant ? tr("برداشتن مهم") : tr("علامت‌گذاری مهم")}</button>
              <button type="button" className="cm-fbtn cm-fbtn-red" disabled={busy} onClick={() => onDelete(msg)}><Trash2 size={14} />{" "}{tr("حذف")}</button>
            </div>
            <button type="button" className="cm-answered-btn" disabled={busy} onClick={() => onAnswered(msg)}><CheckCircle2 size={14} /> {msg.isAnswered ? tr("برداشتن علامت پاسخ‌داده‌شده") : tr("علامت‌گذاری پاسخ‌داده‌شده")}</button>
          </footer>
        </>
      )}
    </>
  );

  if (!narrow) return <aside className="cm-dock" aria-label={tr("جزئیات پیام")}>{inner}</aside>;
  if (!open) return null;
  return createPortal(
    <div className="cm-overlay" role="presentation" onClick={onClose}>
      <aside className="cm-dock cm-dock-float" role="dialog" aria-modal="true" aria-label={tr("جزئیات پیام")} onClick={(e) => e.stopPropagation()}>{inner}</aside>
    </div>,
    document.body
  );
}

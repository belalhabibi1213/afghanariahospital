import { useEffect, useState } from "react";
import { RefreshCw, TriangleAlert } from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";

import { tr, numLocale } from "../../i18n/tr.js";
// ============================================================================
// اجزای مشترک «Design System» هفت بخش مدیریتی (جستجوی کلی، نظرات، پیام‌های تماس،
// فاکتورها، گزارش‌ها و آمار، سیستم گزارش‌گیری). فقط ظاهر/ساختار؛ هیچ منطق داده‌ای
// یا API اینجا نیست. استایل‌ها از pm-* / dm-* (موجود) و ap-* (adminPro.css) می‌آیند.
// ============================================================================

export const fa = (n) => Number(n || 0).toLocaleString(numLocale());

export function fmtMoney(n) {
  return Number(n || 0).toLocaleString("en-US", { maximumFractionDigits: 2 });
}

// تاخیر کوتاه پیش از ارسال درخواست جستجو (همان رفتار useDebouncedValue داخل AdminDashboard)
export function useDebounced(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

export function buildQs(params) {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") usp.set(key, value);
  });
  const s = usp.toString();
  return s ? `?${s}` : "";
}

// سربرگ صفحه: عنوان، توضیح کوتاه، دکمه‌ی «به‌روزرسانی» (فقط اگر onRefresh داده شود) و اکشن‌های اضافه
export function PageHead({ title, subtitle, onRefresh, refreshing, children }) {
  return (
    <div className="pm-head">
      <div>
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      <div className="pm-head-actions">
        {children}
        {onRefresh && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={onRefresh} disabled={refreshing} aria-label={tr("به‌روزرسانی")}>
            <RefreshCw size={14} className={refreshing ? "ap-spin" : undefined} />{" "}{tr("به‌روزرسانی")}</button>
        )}
      </div>
    </div>
  );
}

// کارت‌های KPI. اگر item.onClick داده شود، کارت دکمه‌ی فیلتر است؛ وگرنه فقط نمایشی.
// value === undefined/null => هنوز بارگذاری نشده و «—» نمایش داده می‌شود (عدد ساختگی نداریم).
export function StatCards({ items, columns }) {
  return (
    <div className="pm-stats" style={columns ? { gridTemplateColumns: `repeat(${columns}, minmax(0, 1fr))` } : undefined}>
      {items.map(({ key, tone, label, value, Icon, active, onClick, hint }) => {
        const loaded = value !== undefined && value !== null;
        const body = (
          <>
            <span className="pm-stat-icon"><Icon size={20} /></span>
            <span>
              <span className="pm-stat-num">{loaded ? (typeof value === "number" ? fa(value) : value) : "—"}</span>
              <span className="pm-stat-label">{label}</span>
              {hint && <span className="ap-stat-hint">{hint}</span>}
            </span>
          </>
        );
        const cls = `pm-stat pm-tone-${tone} ${loaded ? "" : "is-loading"}`;
        return onClick ? (
          <button key={key || label} type="button" className={cls} aria-pressed={!!active} onClick={onClick}>{body}</button>
        ) : (
          <div key={key || label} className={`${cls} dm-stat`}>{body}</div>
        );
      })}
    </div>
  );
}

// حالت خطا / خالی با دکمه‌ی تلاش دوباره
export function StateBlock({ kind = "empty", title, message, onRetry, action }) {
  return (
    <div className={`pm-state ap-state ${kind === "error" ? "is-error" : ""}`} role={kind === "error" ? "alert" : "status"}>
      {kind === "error" && <TriangleAlert size={22} aria-hidden="true" />}
      {title && <strong>{title}</strong>}
      {message && <span>{message}</span>}
      {(onRetry || action) && (
        <div className="ap-state-actions">
          {onRetry && <button type="button" className="btn btn-ghost btn-sm" onClick={onRetry}>{tr("تلاش دوباره")}</button>}
          {action}
        </div>
      )}
    </div>
  );
}

export function SkeletonRows({ rows = 5 }) {
  return (
    <div className="ap-skeleton" aria-busy="true" aria-label={tr("در حال بارگذاری")}>
      {Array.from({ length: rows }).map((_, i) => <div key={i} className="pm-skel dm-skel-line" />)}
    </div>
  );
}

// پنجره‌ی تایید عملیات حساس (جایگزین window.confirm) — همان الگوی مودال تایید فاکتور/خروج
export function ConfirmDialog({ open, title, message, note, confirmLabel, busyLabel, busy, danger, onConfirm, onCancel }) {
  return (
    <GlobalModal
      isOpen={!!open}
      onClose={onCancel}
      size="sm"
      className="logout-confirm-modal"
      overlayClassName="logout-confirm-overlay"
      labelledBy="ap-confirm-title"
      closeOnOverlayClick={!busy}
      closeOnEsc={!busy}
      bare
    >
      {open && (
        <>
          <h3 id="ap-confirm-title">{title}</h3>
          <p>{message}</p>
          {note && <p className="ap-confirm-note">{note}</p>}
          <div className="modal-actions">
            <button type="button" className={`btn ${danger ? "btn-danger" : "btn-primary"}`} onClick={onConfirm} disabled={busy}>
              {busy ? busyLabel || tr("در حال انجام...") : confirmLabel}
            </button>
            <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={busy}>{tr("انصراف")}</button>
          </div>
        </>
      )}
    </GlobalModal>
  );
}

// نشان وضعیت یکدست؛ tone: success | warn | danger | info | muted
export function Badge({ tone = "muted", children }) {
  return <span className={`ap-badge ap-badge-${tone}`}>{children}</span>;
}

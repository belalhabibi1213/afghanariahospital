import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  Search, X, MessageSquare, Clock, CheckCircle2, XCircle, Trash2, Check, Eye, Pencil, Star, Send,
  RotateCcw, SlidersHorizontal, Calendar, Image as ImageIcon,
} from "lucide-react";
import { apiRequest, resolvePhotoUrl } from "../../utils/api.js";
import useHighlightParam from "../../hooks/useHighlightParam.js";
import { useDepartmentToasts, DepartmentToastContainer } from "../dashboard/DepartmentToast.jsx";
import { todayISO, currentWeekRange, currentJalaliMonthRange } from "../../utils/jalali.js";
import { PageHead, StatCards, StateBlock, SkeletonRows, ConfirmDialog, Badge, fa, buildQs, useDebounced } from "./AdminPro.jsx";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, jdatetime } from "../../i18n/tr.js";
const STATUS_LABEL = trc({ pending: "در انتظار", approved: "تأیید شده", rejected: "رد شده", deleted: "حذف شده" });
const STATUS_TONE = { pending: "warn", approved: "success", rejected: "danger", deleted: "muted" };
const SORT_OPTIONS = trc([
  { value: "newest", label: "مرتب‌سازی: جدیدترین" },
  { value: "oldest", label: "قدیمی‌ترین" },
  { value: "highest", label: "بیشترین امتیاز" },
  { value: "lowest", label: "کمترین امتیاز" },
  { value: "pending_first", label: "در انتظار تأیید اول" },
]);
const DATE_PRESETS = trc([
  { value: "all", label: "همه‌ی تاریخ‌ها" },
  { value: "today", label: "امروز" },
  { value: "week", label: "این هفته" },
  { value: "month", label: "این ماه" },
  { value: "custom", label: "بازه‌ی دلخواه" },
]);
const PAGE_SIZES = [20, 50, 100];
const REPLY_MAX = 1000;

// بازه‌ی تاریخ (میلادی YYYY-MM-DD برای API)؛ هفته از شنبه و ماه بر اساس تقویم شمسی
function presetRange(preset, custom) {
  if (preset === "today") { const t = todayISO(); return { dateFrom: t, dateTo: t }; }
  if (preset === "week") { const r = currentWeekRange(); return { dateFrom: r.from, dateTo: r.to }; }
  if (preset === "month") { const r = currentJalaliMonthRange(); return { dateFrom: r.from, dateTo: r.to }; }
  if (preset === "custom") return { dateFrom: custom.from || "", dateTo: custom.to || "" };
  return { dateFrom: "", dateTo: "" };
}

const formatDateTime = (value) => jdatetime(value);

function pageNumbers(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);
  const set = new Set([1, total, current - 1, current, current + 1]);
  if (current <= 3) [2, 3, 4, 5].forEach((n) => set.add(n));
  if (current >= total - 2) [total - 4, total - 3, total - 2, total - 1].forEach((n) => set.add(n));
  const sorted = [...set].filter((n) => n >= 1 && n <= total).sort((a, b) => a - b);
  const out = [];
  sorted.forEach((n, i) => {
    if (i > 0 && n - sorted[i - 1] > 1) out.push("gap");
    out.push(n);
  });
  return out;
}

function Avatar({ name, photoUrl, large }) {
  const src = photoUrl ? resolvePhotoUrl(photoUrl) : null;
  const cls = `ap-avatar ${large ? "ap-avatar-lg" : ""}`;
  if (src) return <img className={`${cls} ap-avatar-img`} src={src} alt="" loading="lazy" />;
  return <span className={cls}>{(name || "؟").trim().charAt(0)}</span>;
}

// ستاره‌های امتیاز (فقط نمایش)؛ نظر بدون امتیاز → «—»
function Stars({ value, showNumber }) {
  if (!value) return <span className="ap-cmc-norating" title={tr("بدون امتیاز")}>—</span>;
  return (
    <span className="ap-cmc-stars" role="img" aria-label={tr("امتیاز {0} از ۵", [value])}>
      {showNumber && <span className="ap-cmc-ratingnum">{tr("{0}٫۰", [fa(value)])}</span>}
      {[1, 2, 3, 4, 5].map((n) => <Star key={n} size={showNumber ? 16 : 14} className={n <= value ? "is-on" : ""} />)}
    </span>
  );
}

// «مرکز مدیریت نظرات» — نظرات کاربران روی اخبار. جدول + پنل جزئیات ثابت کنار آن (مطابق طرح).
// APIها: GET /admin/comments (+stats, news-options, :id)، PUT /admin/comments/:id (متن/پاسخ/یادداشت)،
// PUT /:id/status، DELETE /:id (حذف نرم)، POST /:id/restore، POST /bulk. همه‌ی صفحه‌بندی/فیلتر/جستجو سمت سرور.
export default function AdminComments() {
  const { highlightId, highlightRowProps } = useHighlightParam();
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  const [statusFilter, setStatusFilter] = useState("all");
  const [ratingFilter, setRatingFilter] = useState("");
  const [search, setSearch] = useState("");
  const [newsId, setNewsId] = useState(highlightId && /^\d+$/.test(highlightId) ? highlightId : "");
  const [datePreset, setDatePreset] = useState("all");
  const [customRange, setCustomRange] = useState({ from: "", to: "" });
  const [sort, setSort] = useState("newest");
  const [showMore, setShowMore] = useState(false);
  const [limit, setLimit] = useState(20);
  const [page, setPage] = useState(1);

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [stats, setStats] = useState(null);
  const [newsOptions, setNewsOptions] = useState([]);

  const [selected, setSelected] = useState(() => new Set());
  const [busyIds, setBusyIds] = useState(() => new Set());
  const [bulkBusy, setBulkBusy] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null); // { ids: [] }

  // پنل جزئیات
  const [activeId, setActiveId] = useState(null);
  const [detail, setDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState("");
  const [editing, setEditing] = useState(false);
  const wantEdit = useRef(false); // «ویرایش» از ردیف جدول: پس از بارگذاری جزئیات، پنل در حالت ویرایش باز شود
  const [contentDraft, setContentDraft] = useState("");
  const [replyDraft, setReplyDraft] = useState("");
  const [noteDraft, setNoteDraft] = useState("");
  const [panelBusy, setPanelBusy] = useState(false);

  const debouncedSearch = useDebounced(search, 400);
  const reqSeq = useRef(0);

  const range = presetRange(datePreset, customRange);
  const queryString = buildQs({
    status: statusFilter === "all" ? "" : statusFilter,
    rating: ratingFilter, newsId, q: debouncedSearch.trim(), dateFrom: range.dateFrom, dateTo: range.dateTo, sort, page, limit,
  });

  const loadStats = useCallback(() => {
    apiRequest("/admin/comments/stats").then((r) => setStats(r.stats)).catch(() => {});
  }, []);
  const loadNewsOptions = useCallback(() => {
    apiRequest("/admin/comments/news-options").then((r) => setNewsOptions(r.news || [])).catch(() => {});
  }, []);

  const loadList = useCallback(() => {
    const seq = ++reqSeq.current;
    setLoading(true);
    setError("");
    apiRequest(`/admin/comments${queryString}`)
      .then((res) => {
        if (seq !== reqSeq.current) return;
        const total = res.pagination?.totalPages || 1;
        if (res.comments.length === 0 && page > 1 && page > total) { setPage(total); return; }
        setData(res);
      })
      .catch((err) => { if (seq === reqSeq.current) setError(err.message || tr("خطا در بارگذاری نظرات")); })
      .finally(() => { if (seq === reqSeq.current) setLoading(false); });
  }, [queryString, page]);

  const loadDetail = useCallback((id) => {
    setDetailError("");
    setDetailLoading(true);
    return apiRequest(`/admin/comments/${id}`)
      .then((r) => r.comment)
      .catch((err) => { setDetailError(err.message || tr("بارگذاری جزئیات انجام نشد")); return null; })
      .finally(() => setDetailLoading(false));
  }, []);

  useEffect(() => { loadList(); }, [loadList]);
  useEffect(() => { loadStats(); loadNewsOptions(); }, [loadStats, loadNewsOptions]);

  // با تغییر هر فیلتر/جستجو/مرتب‌سازی/اندازه‌ی صفحه: برگشت به صفحه‌ی ۱
  const filterSig = `${statusFilter}|${ratingFilter}|${newsId}|${debouncedSearch.trim()}|${range.dateFrom}|${range.dateTo}|${sort}|${limit}`;
  const lastSig = useRef(filterSig);
  useEffect(() => {
    if (lastSig.current !== filterSig) {
      lastSig.current = filterSig;
      setPage(1);
    }
  }, [filterSig]);
  useEffect(() => { setSelected(new Set()); }, [queryString]);

  // جزئیات کامل نظر هنگام انتخاب (دریافت جدا از لیست)
  useEffect(() => {
    if (!activeId) { setDetail(null); return undefined; }
    let cancelled = false;
    setDetail(null);
    setEditing(false);
    loadDetail(activeId).then((c) => {
      if (cancelled || !c) return;
      setDetail(c);
      setContentDraft(c.content);
      setReplyDraft(c.adminReply || "");
      setNoteDraft(c.internalNote || "");
      if (wantEdit.current) { setEditing(true); wantEdit.current = false; }
    });
    return () => { cancelled = true; };
  }, [activeId, loadDetail]);

  function refreshAll() {
    loadList();
    loadStats();
    loadNewsOptions();
  }
  function openComment(id, edit = false) {
    wantEdit.current = edit;
    setActiveId(id);
  }
  function closePanel() { setActiveId(null); }

  function applyDetail(c) {
    setDetail(c);
    setContentDraft(c.content);
    setReplyDraft(c.adminReply || "");
    setNoteDraft(c.internalNote || "");
  }
  async function reloadDetail() {
    if (!activeId) return;
    const c = await loadDetail(activeId);
    if (c) applyDetail(c);
  }

  function markBusy(ids, on) {
    setBusyIds((prev) => {
      const next = new Set(prev);
      ids.forEach((id) => (on ? next.add(id) : next.delete(id)));
      return next;
    });
  }

  async function changeStatus(id, status) {
    if (busyIds.has(id)) return;
    markBusy([id], true);
    try {
      await apiRequest(`/admin/comments/${id}/status`, { method: "PUT", body: { status } });
      showToast(status === "approved" ? tr("نظر تأیید شد و در صفحه عمومی خبر نمایش داده می‌شود.") : tr("نظر رد شد."));
      refreshAll();
      if (activeId === id) await reloadDetail();
    } catch (err) {
      showToast(err.message || tr("تغییر وضعیت انجام نشد."), "error");
    } finally {
      markBusy([id], false);
    }
  }

  async function restore(id) {
    if (busyIds.has(id)) return;
    markBusy([id], true);
    try {
      await apiRequest(`/admin/comments/${id}/restore`, { method: "POST" });
      showToast(tr("نظر بازگردانده شد."));
      refreshAll();
      if (activeId === id) await reloadDetail();
    } catch (err) {
      showToast(err.message || tr("بازگردانی انجام نشد."), "error");
    } finally {
      markBusy([id], false);
    }
  }

  async function confirmDelete() {
    if (!deleteTarget) return;
    const { ids } = deleteTarget;
    setBulkBusy(true);
    try {
      if (ids.length === 1) {
        await apiRequest(`/admin/comments/${ids[0]}`, { method: "DELETE" });
        showToast(tr("نظر حذف شد."));
      } else {
        const r = await apiRequest("/admin/comments/bulk", { method: "POST", body: { ids, action: "delete" } });
        showToast(r.message || tr("نظرهای انتخاب‌شده حذف شدند."));
      }
      setSelected(new Set());
      refreshAll();
      if (activeId && ids.includes(activeId)) await reloadDetail();
    } catch (err) {
      showToast(err.message || tr("حذف انجام نشد."), "error");
    } finally {
      setBulkBusy(false);
      setDeleteTarget(null);
    }
  }

  async function bulkChange(action) {
    const ids = [...selected];
    if (!ids.length) return;
    setBulkBusy(true);
    try {
      const r = await apiRequest("/admin/comments/bulk", { method: "POST", body: { ids, action } });
      showToast(r.message || tr("انجام شد."));
      setSelected(new Set());
      refreshAll();
      if (activeId && ids.includes(activeId)) await reloadDetail();
    } catch (err) {
      showToast(err.message || tr("عملیات گروهی انجام نشد."), "error");
    } finally {
      setBulkBusy(false);
    }
  }

  // ذخیره‌ی بخش‌های پنل (متن / پاسخ / یادداشت) با همان endpoint ویرایش
  async function savePanel(fields, okMessage) {
    if (!activeId) return;
    setPanelBusy(true);
    try {
      await apiRequest(`/admin/comments/${activeId}`, { method: "PUT", body: fields });
      showToast(okMessage);
      setEditing(false);
      await reloadDetail();
      loadList();
    } catch (err) {
      showToast(err.message || tr("ذخیره انجام نشد."), "error");
    } finally {
      setPanelBusy(false);
    }
  }

  const comments = data?.comments || [];
  const pagination = data?.pagination || { page: 1, limit, total: 0, totalPages: 1 };
  const hasFilter = statusFilter !== "all" || !!ratingFilter || !!newsId || !!search.trim() || datePreset !== "all";
  const allOnPageSelected = comments.length > 0 && comments.every((c) => selected.has(c.id));
  const onlyDeleted = statusFilter === "deleted";

  function clearFilters() {
    setStatusFilter("all");
    setRatingFilter("");
    setSearch("");
    setNewsId("");
    setDatePreset("all");
    setCustomRange({ from: "", to: "" });
  }
  function toggleRow(id) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  }
  function toggleAll() {
    setSelected(allOnPageSelected ? new Set() : new Set(comments.map((c) => c.id)));
  }

  const totalHint = stats ? tr("از کل {0}", [fa(stats.total)]) : undefined;
  const cards = [
    { key: "all", tone: "total", label: tr("مجموع نظرات"), value: stats?.total, Icon: MessageSquare, active: statusFilter === "all", onClick: () => setStatusFilter("all") },
    { key: "pending", tone: "inactive", label: tr("در انتظار تأیید"), value: stats?.pending, hint: totalHint, Icon: Clock, active: statusFilter === "pending", onClick: () => setStatusFilter("pending") },
    { key: "approved", tone: "active", label: tr("نظرات تأیید شده"), value: stats?.approved, hint: totalHint, Icon: CheckCircle2, active: statusFilter === "approved", onClick: () => setStatusFilter("approved") },
    { key: "rejected", tone: "guest", label: tr("نظرات رد شده"), value: stats?.rejected, hint: totalHint, Icon: XCircle, active: statusFilter === "rejected", onClick: () => setStatusFilter("rejected") },
    { key: "deleted", tone: "danger", label: tr("نظرات حذف شده"), value: stats?.deleted, hint: totalHint, Icon: Trash2, active: statusFilter === "deleted", onClick: () => setStatusFilter("deleted") },
  ];

  const from = pagination.total === 0 ? 0 : (pagination.page - 1) * pagination.limit + 1;
  const to = Math.min(pagination.page * pagination.limit, pagination.total);
  const newsOptionMissing = newsId && !newsOptions.some((n) => String(n.id) === String(newsId));
  const deleteCount = deleteTarget ? deleteTarget.ids.length : 0;
  const detailBusy = !!detail && (busyIds.has(detail.id) || panelBusy);
  const replyDirty = detail && replyDraft.trim() !== (detail.adminReply || "");
  const noteDirty = detail && noteDraft.trim() !== (detail.internalNote || "");

  return (
    <div className="pm-page ap-cmc">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      <PageHead
        title={tr("نظرات کاربران")}
        subtitle={tr("مدیریت نظرات کاربران در بخش اخبار، اعلانات و مطالب سایت")}
        onRefresh={refreshAll}
        refreshing={loading}
      />

      <StatCards items={cards} columns={5} />

      <div className={`ap-cmc-layout ${activeId ? "has-active" : ""}`}>
        {/* ستون کناری: جستجو + پنل جزئیات (در RTL سمت راست جدول) */}
        <aside className="ap-cmc-side">
          <div className="pm-search ap-cmc-search">
            <Search size={16} />
            <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder={tr("جستجوی نام کاربر، ایمیل، متن نظر یا عنوان خبر...")} aria-label={tr("جستجوی نظرات")} />
          </div>

          {activeId && <button type="button" className="ap-cmc-backdrop" aria-label={tr("بستن جزئیات")} onClick={closePanel} />}
          <section className={`ap-cmc-panel ${activeId ? "is-open" : ""}`} aria-label={tr("جزئیات نظر")}>
            <header className="ap-cmc-panel-head">
              <h3>{tr("جزئیات نظر")}</h3>
              {activeId && <button type="button" className="ap-cmc-panel-close" onClick={closePanel} aria-label={tr("بستن")}><X size={18} /></button>}
            </header>

            {!activeId && (
              <div className="ap-cmc-panel-empty">
                <MessageSquare size={28} />
                <p>{tr("برای مشاهده‌ی جزئیات، یک نظر را از جدول انتخاب کنید.")}</p>
              </div>
            )}
            {activeId && detailLoading && !detail && <SkeletonRows rows={5} />}
            {activeId && detailError && !detail && <StateBlock kind="error" title={tr("جزئیات نظر بارگذاری نشد")} message={detailError} onRetry={reloadDetail} />}

            {detail && (
              <div className="ap-cmc-panel-body">
                <div className="ap-cmc-usercard">
                  <Avatar name={detail.authorName} photoUrl={detail.authorPhotoUrl} large />
                  <div className="ap-cmc-usercard-info">
                    <strong>{detail.authorName}</strong>
                    <span className="pm-sub" dir="ltr">{detail.authorEmail}</span>
                    <Stars value={detail.rating} showNumber />
                  </div>
                </div>

                <dl className="ap-cmc-meta">
                  <div><dt><Calendar size={13} />{" "}{tr("تاریخ نظر:")}</dt><dd>{formatDateTime(detail.createdAt)}</dd></div>
                  <div><dt>{tr("وضعیت:")}</dt><dd><Badge tone={STATUS_TONE[detail.status] || "muted"}>{STATUS_LABEL[detail.status] || detail.status}</Badge></dd></div>
                </dl>

                <div className="ap-cmc-box">
                  <span className="ap-cmc-box-label">{tr("خبر / اعلان مربوطه")}</span>
                  <div className="ap-cmc-news">
                    {detail.newsImageUrl
                      ? <img className="ap-cmc-news-thumb" src={resolvePhotoUrl(detail.newsImageUrl)} alt="" loading="lazy" />
                      : <span className="ap-cmc-news-thumb ap-cmc-news-thumb-empty"><ImageIcon size={18} /></span>}
                    <div>
                      <strong>{detail.newsTitle}</strong>
                      {detail.newsStatus === "published" && (
                        <Link className="ap-linkbtn" to={`/news/${detail.newsId}`} target="_blank" rel="noopener noreferrer">{tr("مشاهده خبر")}</Link>
                      )}
                    </div>
                  </div>
                </div>

                <div>
                  <span className="ap-cmc-label">{tr("متن نظر")}</span>
                  {editing ? (
                    <div className="ap-cmc-edit">
                      <textarea rows={5} maxLength={REPLY_MAX} value={contentDraft} onChange={(e) => setContentDraft(e.target.value)} aria-label={tr("ویرایش متن نظر")} />
                      <div className="ap-cmc-edit-actions">
                        <button type="button" className="btn btn-primary btn-sm" disabled={panelBusy || contentDraft.trim().length < 2} onClick={() => savePanel({ content: contentDraft.trim() }, tr("متن نظر ذخیره شد."))}>{tr("ذخیره")}</button>
                        <button type="button" className="btn btn-ghost btn-sm" disabled={panelBusy} onClick={() => { setEditing(false); setContentDraft(detail.content); }}>{tr("انصراف")}</button>
                      </div>
                    </div>
                  ) : (
                    <p className="ap-cmc-text">{detail.content}</p>
                  )}
                </div>

                <div>
                  <label className="ap-cmc-label" htmlFor="ap-cmc-reply">{tr("پاسخ شما (اختیاری)")}</label>
                  <div className="ap-cmc-replybox">
                    <textarea id="ap-cmc-reply" rows={2} maxLength={REPLY_MAX} value={replyDraft} onChange={(e) => setReplyDraft(e.target.value)} placeholder={tr("پاسخ به نظر کاربر...")} />
                    <button type="button" className="ap-cmc-send" disabled={detailBusy || !replyDirty} onClick={() => savePanel({ adminReply: replyDraft.trim() }, replyDraft.trim() ? tr("پاسخ ذخیره شد و به کاربر اعلان رفت.") : tr("پاسخ پاک شد."))} aria-label={tr("ثبت پاسخ")} title={tr("ثبت پاسخ")}><Send size={16} /></button>
                  </div>
                  {detail.adminReplyAt && !replyDirty && <span className="pm-sub">{tr("آخرین پاسخ: {0}", [formatDateTime(detail.adminReplyAt)])}</span>}
                </div>

                <div className="ap-cmc-panel-actions">
                  {detail.status === "deleted" ? (
                    <button type="button" className="btn btn-primary btn-sm" disabled={detailBusy} onClick={() => restore(detail.id)}><RotateCcw size={14} />{" "}{tr("بازگردانی")}</button>
                  ) : (
                    <>
                      <button type="button" className="ap-cmc-btn is-approve" disabled={detailBusy || detail.status === "approved"} onClick={() => changeStatus(detail.id, "approved")}><Check size={14} />{" "}{tr("تأیید")}</button>
                      <button type="button" className="ap-cmc-btn is-reject" disabled={detailBusy || detail.status === "rejected"} onClick={() => changeStatus(detail.id, "rejected")}><X size={14} />{" "}{tr("رد")}</button>
                      <button type="button" className="ap-cmc-btn is-edit" disabled={detailBusy || editing} onClick={() => setEditing(true)}><Pencil size={14} />{" "}{tr("ویرایش")}</button>
                      <button type="button" className="ap-cmc-btn is-delete" disabled={detailBusy} onClick={() => setDeleteTarget({ ids: [detail.id] })}><Trash2 size={14} />{" "}{tr("حذف")}</button>
                    </>
                  )}
                </div>

                <div>
                  <label className="ap-cmc-label" htmlFor="ap-cmc-note">{tr("یادداشت داخلی (اختیاری)")}</label>
                  <textarea id="ap-cmc-note" className="ap-cmc-note" rows={3} maxLength={REPLY_MAX} value={noteDraft} onChange={(e) => setNoteDraft(e.target.value)} placeholder={tr("یادداشت داخلی برای تیم مدیریت...")} />
                  {noteDirty && (
                    <button type="button" className="btn btn-ghost btn-sm" disabled={detailBusy} onClick={() => savePanel({ internalNote: noteDraft.trim() }, tr("یادداشت ذخیره شد."))}>{tr("ذخیره‌ی یادداشت")}</button>
                  )}
                </div>
              </div>
            )}
          </section>
        </aside>

        {/* ستون اصلی: فیلترها + جدول */}
        <section className="ap-cmc-main">
          <div className="pm-filterbar">
            <div className="pm-filter-row ap-cmc-filters">
              <select className="pm-select dash-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={tr("وضعیت نظر")}>
                <option value="all">{tr("وضعیت: همه")}</option>
                {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
              <select className="pm-select dash-select ap-cmc-news-select" value={newsId} onChange={(e) => setNewsId(e.target.value)} aria-label={tr("فیلتر خبر / اعلان")}>
                <option value="">{tr("خبر / اعلان: همه")}</option>
                {newsOptionMissing && <option value={newsId}>{tr("خبر انتخاب‌شده")}</option>}
                {newsOptions.map((n) => <option key={n.id} value={n.id}>{n.title} ({fa(n.commentsCount)})</option>)}
              </select>
              <select className="pm-select dash-select" value={datePreset} onChange={(e) => setDatePreset(e.target.value)} aria-label={tr("بازه‌ی زمانی")}>
                {DATE_PRESETS.map((p) => <option key={p.value} value={p.value}>{p.value === "all" ? tr("بازه زمانی: همه") : p.label}</option>)}
              </select>
              <select className="pm-select dash-select" value={ratingFilter} onChange={(e) => setRatingFilter(e.target.value)} aria-label={tr("امتیاز")}>
                <option value="">{tr("امتیاز: همه")}</option>
                {[5, 4, 3, 2, 1].map((n) => <option key={n} value={n}>{tr("{0} ستاره", [fa(n)])}</option>)}
              </select>
              <button type="button" className={`btn btn-ghost btn-sm ap-cmc-more ${showMore ? "is-on" : ""}`} aria-expanded={showMore} onClick={() => setShowMore((v) => !v)}>
                <SlidersHorizontal size={14} />{" "}{tr("بیشتر فیلترها")}</button>
            </div>
            {(showMore || datePreset === "custom") && (
              <div className="pm-filter-row ap-cmc-range">
                {datePreset === "custom" && (
                  <>
                    <label className="ap-datefield">{tr("از")}{" "}<JalaliDateInput value={customRange.from} max={customRange.to || undefined} onChange={(e) => setCustomRange((r) => ({ ...r, from: e.target.value }))} /></label>
                    <label className="ap-datefield">{tr("تا")}{" "}<JalaliDateInput value={customRange.to} min={customRange.from || undefined} onChange={(e) => setCustomRange((r) => ({ ...r, to: e.target.value }))} /></label>
                  </>
                )}
                {showMore && (
                  <select className="pm-select dash-select" value={sort} onChange={(e) => setSort(e.target.value)} aria-label={tr("مرتب‌سازی")}>
                    {SORT_OPTIONS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                  </select>
                )}
                {hasFilter && (
                  <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={clearFilters}><X size={14} />{" "}{tr("پاک کردن فیلترها")}</button>
                )}
              </div>
            )}
          </div>

          <div className="pm-tablewrap">
            <div className="ap-cmc-bulkbar" role="toolbar" aria-label={tr("عملیات گروهی")}>
              <button type="button" className="ap-cmc-btn is-selectall" disabled={comments.length === 0} onClick={toggleAll}>
                <input type="checkbox" readOnly tabIndex={-1} checked={allOnPageSelected} aria-hidden="true" />{" "}{tr("انتخاب همه")}</button>
              <button type="button" className="ap-cmc-btn is-approve" disabled={bulkBusy || selected.size === 0 || onlyDeleted} onClick={() => bulkChange("approve")}><Check size={14} />{" "}{tr("تأیید کردن")}</button>
              <button type="button" className="ap-cmc-btn is-reject" disabled={bulkBusy || selected.size === 0 || onlyDeleted} onClick={() => bulkChange("reject")}><X size={14} />{" "}{tr("رد کردن")}</button>
              <button type="button" className="ap-cmc-btn is-delete" disabled={bulkBusy || selected.size === 0 || onlyDeleted} onClick={() => setDeleteTarget({ ids: [...selected] })}><Trash2 size={14} />{" "}{tr("حذف")}</button>
              {selected.size > 0 && <span className="ap-cmc-selcount">{tr("{0} نظر انتخاب شده", [fa(selected.size)])}</span>}
            </div>

            {error && !data && <StateBlock kind="error" title={tr("بارگذاری نظرات انجام نشد")} message={error} onRetry={loadList} />}
            {error && data && <div className="form-message error" role="alert">{error} <button type="button" className="ap-linkbtn" onClick={loadList}>{tr("تلاش دوباره")}</button></div>}
            {loading && !data && !error && <SkeletonRows rows={6} />}

            {data && comments.length === 0 && !error && (
              hasFilter
                ? <StateBlock title={tr("با فیلترهای انتخاب‌شده نظری پیدا نشد.")} message={tr("فیلتر یا عبارت جستجو را تغییر دهید.")} action={<button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button>} />
                : <StateBlock title={tr("هنوز نظری ثبت نشده است.")} message={tr("با ثبت نظر توسط کاربران، اینجا نمایش داده می‌شود.")} />
            )}

            {comments.length > 0 && (
              <div className={`ap-tablescroll ${loading ? "is-busy" : ""}`}>
                <table className="pm-table ap-cmc-table">
                  <thead>
                    <tr>
                      <th className="pm-cell-check"><input type="checkbox" checked={allOnPageSelected} onChange={toggleAll} aria-label={tr("انتخاب همه‌ی نظرهای این صفحه")} /></th>
                      <th className="ap-cmc-col-id">#</th>
                      <th>{tr("کاربر")}</th>
                      <th>{tr("نظر")}</th>
                      <th className="ap-cmc-col-news">{tr("خبر / اعلان")}</th>
                      <th className="ap-cmc-col-date">{tr("تاریخ و زمان")}</th>
                      <th>{tr("امتیاز")}</th>
                      <th>{tr("وضعیت")}</th>
                      <th>{tr("عملیات")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {comments.map((c, i) => {
                      const hl = highlightRowProps(c.newsId);
                      const busy = busyIds.has(c.id);
                      const isSel = selected.has(c.id);
                      const isDeleted = c.status === "deleted";
                      return (
                        <tr
                          key={c.id}
                          ref={hl.ref}
                          className={`${hl.className || ""} ${isSel ? "is-selected" : ""} ${activeId === c.id ? "is-active" : ""} ${isDeleted ? "is-deleted" : ""}`}
                          onClick={(e) => { if (!e.target.closest("button, input, a, label")) openComment(c.id); }}
                        >
                          <td className="pm-cell-check"><input type="checkbox" checked={isSel} onChange={() => toggleRow(c.id)} aria-label={tr("انتخاب نظر {0}", [c.authorName])} /></td>
                          <td className="pm-cell-id ap-cmc-col-id ap-num-cell" data-label="#">{fa((pagination.page - 1) * pagination.limit + i + 1)}</td>
                          <td className="pm-cell-name" data-label={tr("کاربر")}>
                            <div className="pm-person">
                              <Avatar name={c.authorName} photoUrl={c.authorPhotoUrl} />
                              <span className="ap-cmc-person">
                                <span className="pm-person-name">{c.authorName}</span>
                                <span className="pm-sub" dir="ltr">{c.authorEmail}</span>
                              </span>
                            </div>
                          </td>
                          <td className="ap-cmc-text-cell" data-label={tr("نظر")}>
                            <button type="button" className="ap-cmc-preview" onClick={() => openComment(c.id)} title={tr("مشاهده‌ی متن کامل")}>
                              {c.preview}{c.contentLength > c.preview.length ? "…" : ""}
                            </button>
                          </td>
                          <td className="ap-cmc-col-news" data-label={tr("خبر / اعلان")}><span className="ap-cmc-newstitle" title={c.newsTitle}>{c.newsTitle || "—"}</span></td>
                          <td className="ap-num-cell ap-cmc-col-date" data-label={tr("تاریخ و زمان")}>{formatDateTime(c.createdAt)}</td>
                          <td className="ap-num-cell" data-label={tr("امتیاز")}>
                            {c.rating ? <span className="ap-cmc-rate"><Star size={14} className="is-on" /> {fa(c.rating)}</span> : <span className="ap-cmc-norating">—</span>}
                          </td>
                          <td data-label={tr("وضعیت")}><Badge tone={STATUS_TONE[c.status] || "muted"}>{STATUS_LABEL[c.status] || c.status}</Badge></td>
                          <td className="pm-cell-actions" data-label={tr("عملیات")}>
                            <div className="ap-cmc-actions">
                              <button type="button" className="ap-cmc-icon is-view" onClick={() => openComment(c.id)} aria-label={tr("مشاهده")} title={tr("مشاهده")}><Eye size={15} /></button>
                              {isDeleted ? (
                                <button type="button" className="ap-cmc-icon is-edit" disabled={busy} onClick={() => restore(c.id)} aria-label={tr("بازگردانی")} title={tr("بازگردانی")}><RotateCcw size={15} /></button>
                              ) : (
                                <>
                                  <button type="button" className="ap-cmc-icon is-edit" onClick={() => openComment(c.id, true)} aria-label={tr("ویرایش")} title={tr("ویرایش")}><Pencil size={15} /></button>
                                  <button type="button" className="ap-cmc-icon is-delete" disabled={busy} onClick={() => setDeleteTarget({ ids: [c.id] })} aria-label={tr("حذف")} title={tr("حذف")}><Trash2 size={15} /></button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {data && pagination.total > 0 && (
              <nav className="pm-pager" aria-label={tr("صفحه‌بندی")}>
                <label className="ap-cmc-size">
                  <span className="pm-muted">{tr("در صفحه:")}</span>
                  <select className="pm-select dash-select" value={limit} onChange={(e) => setLimit(Number(e.target.value))} aria-label={tr("تعداد نظر در هر صفحه")}>
                    {PAGE_SIZES.map((n) => <option key={n} value={n}>{fa(n)}</option>)}
                  </select>
                </label>
                <span>{tr("نمایش {0} تا {1} از {2} نظر", [fa(from), fa(to), fa(pagination.total)])}</span>
                <div className="pm-pages">
                  <button type="button" className="pm-page-btn" disabled={pagination.page <= 1} onClick={() => setPage(pagination.page - 1)} aria-label={tr("صفحه‌ی قبلی")}>{tr("قبلی")}</button>
                  {pageNumbers(pagination.page, pagination.totalPages).map((n, idx) => (
                    n === "gap"
                      ? <span key={`gap-${idx}`} className="pm-muted">…</span>
                      : <button key={n} type="button" className="pm-page-btn" aria-current={n === pagination.page ? "page" : undefined} onClick={() => setPage(n)}>{fa(n)}</button>
                  ))}
                  <button type="button" className="pm-page-btn" disabled={pagination.page >= pagination.totalPages} onClick={() => setPage(pagination.page + 1)} aria-label={tr("صفحه‌ی بعدی")}>{tr("بعدی")}</button>
                </div>
              </nav>
            )}
          </div>
        </section>
      </div>

      <ConfirmDialog
        open={!!deleteTarget}
        danger
        title={deleteCount > 1 ? tr("حذف گروهی نظرها") : tr("حذف نظر")}
        message={deleteCount > 1 ? tr("آیا مطمئن هستید می‌خواهید {0} نظر انتخاب‌شده را حذف کنید؟", [fa(deleteCount)]) : tr("آیا مطمئن هستید می‌خواهید این نظر را حذف کنید؟")}
        note={tr("نظر از بخش نظرات صفحه عمومی برداشته می‌شود (در پنل با وضعیت «حذف شده» می‌ماند و قابل بازگردانی است)؛ خبر یا اعلان مربوطه حذف نمی‌شود.")}
        confirmLabel={deleteCount > 1 ? tr("حذف نظرها") : tr("حذف نظر")}
        busyLabel={tr("در حال حذف...")}
        busy={bulkBusy}
        onConfirm={confirmDelete}
        onCancel={() => setDeleteTarget(null)}
      />
    </div>
  );
}

import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

vi.mock("../../utils/api.js", () => ({ apiRequest: vi.fn() }));
import { apiRequest } from "../../utils/api.js";
import AdminAiChats from "./AdminAiChats.jsx";

const mk = (i) => ({ id: i, userId: 1, userName: `بیمار ${i}`, lang: "fa", question: `پرسش ${i}`, answer: `پاسخ ${i}`, emergency: 0, flagged: 0, createdAt: "2026-09-01T10:00:00Z" });
const STATS = { total: 45, today: 2, emergency: 1, flagged: 0 };

function setup(extra) {
  apiRequest.mockImplementation(async (url, opts = {}) => {
    if (url === "/admin/ai-chats/stats") return STATS;
    if (url.startsWith("/admin/ai-chats?")) return { logs: [mk(1), mk(2)], pagination: { page: 1, limit: 20, total: 45, totalPages: 3 } };
    if (extra) return extra(url, opts);
    return {};
  });
  return render(<AdminAiChats />);
}
const listCalls = () => apiRequest.mock.calls.map((c) => c[0]).filter((u) => u.startsWith("/admin/ai-chats?"));

beforeEach(() => { apiRequest.mockReset(); });

describe("AdminAiChats (صفحه‌بندی و حذف گروهی)", () => {
  it("تعداد در هر صفحه و بازه‌ی نمایش را نشان می‌دهد و با تغییر آن دوباره از سرور می‌گیرد", async () => {
    setup();
    expect(await screen.findByText("پرسش 1")).toBeInTheDocument();
    expect(screen.getByText(/نمایش ۱ تا ۲۰ از ۴۵ گفتگو/)).toBeInTheDocument();
    expect(listCalls()[0]).toContain("limit=20");
    await userEvent.selectOptions(screen.getByLabelText("تعداد گفتگو در هر صفحه"), "50");
    await waitFor(() => expect(listCalls().some((u) => u.includes("limit=50"))).toBe(true));
  });

  it("انتخاب همه‌ی صفحه ← «انتخاب همه‌ی نتایج» ← حذف با selectAll و فیلتر فعلی", async () => {
    setup();
    await screen.findByText("پرسش 1");
    await userEvent.click(screen.getByLabelText("انتخاب همه‌ی گفتگوهای این صفحه"));
    expect(screen.getByText("۲ گفتگو انتخاب شده")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: /انتخاب همه‌ی ۴۵ گفتگو در تمام صفحه‌ها/ }));
    expect(screen.getByText("۴۵ گفتگو انتخاب شده")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: /حذف انتخاب‌شده‌ها/ }));
    expect(screen.getByText(/۴۵ گفتگوی انتخاب‌شده را برای همیشه حذف کنید/)).toBeInTheDocument();
    await userEvent.click(screen.getByRole("button", { name: "حذف" }));
    await waitFor(() => {
      const call = apiRequest.mock.calls.find((c) => c[0] === "/admin/ai-chats/bulk-delete");
      expect(call).toBeTruthy();
      expect(call[1].method).toBe("POST");
      expect(call[1].body).toMatchObject({ selectAll: true, q: "", kind: "" });
    });
  });

  it("انتخاب چند ردیف فقط شناسه‌های همان ردیف‌ها را برای حذف می‌فرستد", async () => {
    setup();
    await screen.findByText("پرسش 1");
    await userEvent.click(screen.getAllByLabelText("انتخاب گفتگو")[1]);
    await userEvent.click(screen.getByRole("button", { name: /حذف انتخاب‌شده‌ها/ }));
    await userEvent.click(screen.getByRole("button", { name: "حذف" }));
    await waitFor(() => {
      const call = apiRequest.mock.calls.find((c) => c[0] === "/admin/ai-chats/bulk-delete");
      expect(call[1].body).toEqual({ ids: [2] });
    });
  });
});

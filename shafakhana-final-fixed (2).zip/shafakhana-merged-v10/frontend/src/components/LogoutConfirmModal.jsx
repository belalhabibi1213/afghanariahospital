import { useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { LOGOUT_REQUIRED_EVENT } from "../utils/logoutGuard.js";
import { useEffect } from "react";
import GlobalModal from "./GlobalModal.jsx";

// این کامپوننت یک‌بار در ریشه‌ی برنامه (App.jsx) مانت می‌شود. دکمه‌ی «خروج» در سایدبار
// همه‌ی داشبوردها (بیمار، داکتر، ادمین، مدیر کل) و همچنین نوار بالای سایت عمومی، به‌جای
// خروج فوری، رویداد سراسری LOGOUT_REQUIRED_EVENT را پخش می‌کنند تا این مودال باز شود.
// نمایش این مودال از طریق GlobalModal (مودال استاندارد سراسری) انجام می‌شود.
export default function LogoutConfirmModal() {
  const { logout } = useAuth();
  const { t } = useLanguage();
  const [open, setOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    function handleLogoutRequest() {
      setOpen(true);
    }
    window.addEventListener(LOGOUT_REQUIRED_EVENT, handleLogoutRequest);
    return () => window.removeEventListener(LOGOUT_REQUIRED_EVENT, handleLogoutRequest);
  }, []);

  function handleClose() {
    if (loggingOut) return; // حین پردازش خروج، مودال بسته نمی‌شود (نه با کلیک بیرون، نه با Esc)
    setOpen(false);
  }

  async function handleConfirmLogout() {
    setLoggingOut(true);
    try {
      // logout() در AuthContext ابتدا سرور را از خروج مطلع می‌کند (لاگ فعالیت) و سپس
      // توکن/نشست محلی را پاک می‌کند؛ همین یک تابع موجود عیناً استفاده می‌شود، بدون
      // هیچ تغییری در منطق احراز هویت. بعد از پاک‌شدن نشست، مسیرهای محافظت‌شده
      // (ProtectedRoute) خودشان کاربر را به صفحه ورود هدایت می‌کنند.
      await logout();
    } finally {
      setLoggingOut(false);
      setOpen(false);
    }
  }

  return (
    <GlobalModal
      isOpen={open}
      onClose={handleClose}
      size="sm"
      className="logout-confirm-modal"
      overlayClassName="logout-confirm-overlay"
      labelledBy="logout-confirm-title"
      closeOnOverlayClick={!loggingOut}
      closeOnEsc={!loggingOut}
      bare
    >
      <h3 id="logout-confirm-title">{t("modals.logout.title")}</h3>
      <p>{t("modals.logout.text")}</p>
      <div className="modal-actions">
        <button type="button" className="btn btn-primary" onClick={handleConfirmLogout} disabled={loggingOut}>
          {loggingOut ? t("modals.logout.confirming") : t("modals.logout.confirm")}
        </button>
        <button type="button" className="btn btn-ghost" onClick={handleClose} disabled={loggingOut}>
          {t("modals.logout.cancel")}
        </button>
      </div>
    </GlobalModal>
  );
}

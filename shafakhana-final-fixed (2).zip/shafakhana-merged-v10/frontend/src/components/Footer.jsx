import { Link } from "react-router-dom";
import { Clock, HeartPulse, Mail, MapPin, Phone } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../i18n/useLocalizedSettings.js";
import { resolvePhotoUrl } from "../utils/api.js";
import { ensureAuthenticated } from "../utils/authGuard.js";
import HashSectionLink from "./HashSectionLink.jsx";
import useDepartments from "./departments/useDepartments.js";
import "./Footer.css";

// حداکثر تعداد بخش‌هایی که در فوتر فهرست می‌شوند؛ بقیه با «همه بخش‌ها» در دسترس‌اند
const FOOTER_DEPARTMENTS = 5;

export default function Footer() {
  const { isAuthenticated } = useAuth();
  const { settings } = useLocalizedSettings();
  const { t, digits, dept } = useLanguage();
  const { departments, status } = useDepartments();

  const guardBooking = (e) => {
    if (!ensureAuthenticated(isAuthenticated)) e.preventDefault();
  };

  const contactRows = [
    { key: "address", Icon: MapPin, value: settings.hospitalAddress },
    { key: "phone", Icon: Phone, value: settings.hospitalPhone, ltr: true },
    { key: "email", Icon: Mail, value: settings.hospitalEmail, ltr: true },
    { key: "hours", Icon: Clock, value: t("contact.hoursValue") },
  ].filter((r) => r.value);

  return (
    <footer className="site-footer pub-dark">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col footer-brand-col">
            <div className="brand">
              {settings.logoUrl ? (
                <img className="brand-logo" src={resolvePhotoUrl(settings.logoUrl)} alt="" />
              ) : (
                <span className="brand-mark" aria-hidden="true"><HeartPulse size={22} strokeWidth={2.2} /></span>
              )}
              <span className="brand-name">{settings.hospitalName}</span>
            </div>
            <p>{settings.hospitalDescription?.trim() || t("footer.about")}</p>
          </div>

          <nav className="footer-col" aria-label={t("footer.links")}>
            <h4>{t("footer.links")}</h4>
            <HashSectionLink hash="#about">{t("footer.aboutLink")}</HashSectionLink>
            <HashSectionLink hash="#doctors">{t("footer.doctors")}</HashSectionLink>
            <HashSectionLink hash="#services">{t("footer.services")}</HashSectionLink>
            <HashSectionLink hash="#appointment" onClick={guardBooking}>{t("footer.appointment")}</HashSectionLink>
            <HashSectionLink hash="#news">{t("footer.news")}</HashSectionLink>
            <HashSectionLink hash="#contact">{t("footer.contact")}</HashSectionLink>
          </nav>

          {/* بخش‌های واقعی از همان API صفحه‌ی خدمات؛ در نبود داده، ستون نمایش داده نمی‌شود */}
          {status === "ok" && departments.length > 0 && (
            <nav className="footer-col" aria-label={t("footer.specialties")}>
              <h4>{t("footer.specialties")}</h4>
              {departments.slice(0, FOOTER_DEPARTMENTS).map((d) => (
                <Link key={d.id} to={`/departments/${d.id}`}>{dept(d.name)}</Link>
              ))}
              {departments.length > FOOTER_DEPARTMENTS && <Link to="/departments">{t("footer.allDepartments")}</Link>}
            </nav>
          )}

          <div className="footer-col">
            <h4>{t("footer.account")}</h4>
            <Link to="/login">{t("footer.login")}</Link>
            <Link to="/register">{t("footer.register")}</Link>
            <HashSectionLink hash="#appointment" onClick={guardBooking}>{t("footer.bookOnline")}</HashSectionLink>
          </div>

          {contactRows.length > 0 && (
            <div className="footer-col footer-contact">
              <h4>{t("footer.contactTitle")}</h4>
              <ul>
                {contactRows.map(({ key, Icon, value, ltr }) => (
                  <li key={key}>
                    <Icon size={16} aria-hidden="true" />
                    <span dir={ltr ? "ltr" : undefined} className={ltr ? "footer-ltr" : undefined}>{value}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="footer-bottom">
          {t("footer.copyright", { year: digits(new Date().getFullYear()), hospital: settings.hospitalName })}
        </div>
      </div>
    </footer>
  );
}

import { Link } from "react-router-dom";
import { CalendarCheck, Headset, LayoutGrid, Newspaper, Stethoscope } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { ensureAuthenticated } from "../utils/authGuard.js";
import "./QuickAccess.css";

// نوار دسترسی سریع زیر هیرو — فقط به امکاناتی که واقعاً در سایت وجود دارند لینک می‌دهد:
// داکتران، نوبت‌دهی آنلاین (نیازمند ورود)، بخش‌ها (/departments)، اخبار و تماس.
const ITEMS = [
  { key: "doctors", Icon: Stethoscope, href: "#doctors" },
  { key: "appointment", Icon: CalendarCheck, href: "#appointment", guarded: true },
  { key: "departments", Icon: LayoutGrid, to: "/departments" },
  { key: "news", Icon: Newspaper, href: "#news" },
  { key: "contact", Icon: Headset, href: "#contact" },
];

export default function QuickAccess() {
  const { isAuthenticated } = useAuth();
  const { t } = useLanguage();

  return (
    <section className="qa" aria-label={t("quick.ariaLabel")}>
      <div className="container">
        <ul className="qa-grid">
          {ITEMS.map(({ key, Icon, href, to, guarded }) => {
            const inner = (
              <>
                <span className="pub-icon"><Icon size={22} strokeWidth={1.8} aria-hidden="true" /></span>
                <span className="qa-text">
                  <strong>{t(`quick.${key}.title`)}</strong>
                  <span>{t(`quick.${key}.text`)}</span>
                </span>
              </>
            );
            return (
              <li key={key}>
                {to ? (
                  <Link to={to} className="qa-card pub-card">{inner}</Link>
                ) : (
                  <a
                    href={href}
                    className="qa-card pub-card"
                    onClick={guarded ? (e) => { if (!ensureAuthenticated(isAuthenticated)) e.preventDefault(); } : undefined}
                  >
                    {inner}
                  </a>
                )}
              </li>
            );
          })}
        </ul>
      </div>
    </section>
  );
}

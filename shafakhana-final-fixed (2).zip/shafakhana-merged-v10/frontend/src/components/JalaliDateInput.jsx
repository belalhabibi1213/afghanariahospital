import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronRight, ChevronLeft } from "lucide-react";
import {
  MONTH_NAMES as MONTH_NAMES_FA, WEEKDAY_SHORT as WEEKDAY_SHORT_FA, gregorianToJalali, jalaliToGregorian, jalaliMonthLength, jalaliWeekday,
  toISODate, todayISO, parseJalaliInput, isoToJalaliInput, toFaDigits,
} from "../utils/jalali.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import { MONTH_NAMES_PS, WEEKDAY_SHORT_PS } from "../i18n/dates.js";
import "./JalaliDateInput.css";

// ورودی تاریخ «هجری شمسی» — جایگزین مستقیم <input type="date"> مرورگر (که میلادی است).
// value / min / max / onChange همگی «ISO میلادی» (YYYY-MM-DD) می‌مانند؛ پس API و فیلترها بدون تغییرند.
// onChange مثل input واقعی فراخوانی می‌شود: onChange({ target: { value, name, id } }).
// کاربر می‌تواند تاریخ را تایپ کند (مثلاً ۱۴۰۵/۰۷/۱۷) یا از تقویم باز‌شده انتخاب کند.
const MIN_YEAR = 1300;
const MAX_YEAR = 1500;
const YEARS = Array.from({ length: MAX_YEAR - MIN_YEAR + 1 }, (_, i) => MIN_YEAR + i);

function useCalendarPopup(open, anchorRef, popupRef, onClose) {
  const [pos, setPos] = useState({ top: 0, left: 0 });
  const place = useCallback(() => {
    const a = anchorRef.current;
    const p = popupRef.current;
    if (!a) return;
    const r = a.getBoundingClientRect();
    const h = p?.offsetHeight || 340;
    const w = p?.offsetWidth || 300;
    const below = window.innerHeight - r.bottom;
    const top = below < h + 8 && r.top > h + 8 ? r.top - h - 6 : r.bottom + 6;
    let left = r.right - w; // راست‌چین: لبه‌ی راست تقویم با لبه‌ی راست فیلد هم‌تراز
    left = Math.max(8, Math.min(left, window.innerWidth - w - 8));
    setPos({ top: Math.max(8, top), left });
  }, [anchorRef, popupRef]);

  useLayoutEffect(() => { if (open) place(); }, [open, place]);
  useEffect(() => {
    if (!open) return undefined;
    const onDown = (e) => {
      if (popupRef.current?.contains(e.target) || anchorRef.current?.contains(e.target)) return;
      onClose();
    };
    const onKey = (e) => {
      if (e.key === "Escape") { e.stopPropagation(); onClose(); anchorRef.current?.focus(); }
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey, true);
    window.addEventListener("resize", place);
    window.addEventListener("scroll", place, true);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey, true);
      window.removeEventListener("resize", place);
      window.removeEventListener("scroll", place, true);
    };
  }, [open, onClose, place, anchorRef, popupRef]);
  return pos;
}

function Calendar({ value, min, max, onPick, onClear, required }) {
  const { lang, t, formatDate } = useLanguage();
  const MONTH_NAMES = lang === "ps" ? MONTH_NAMES_PS : MONTH_NAMES_FA;
  const WEEKDAY_SHORT = lang === "ps" ? WEEKDAY_SHORT_PS : WEEKDAY_SHORT_FA;
  const today = todayISO();
  const seed = value || today;
  const init = gregorianToJalali(+seed.slice(0, 4), +seed.slice(5, 7), +seed.slice(8, 10));
  const [view, setView] = useState({ jy: init.jy, jm: init.jm });

  const monthLen = jalaliMonthLength(view.jy, view.jm);
  const lead = jalaliWeekday(view.jy, view.jm, 1); // خانه‌های خالی ابتدای ماه (هفته از شنبه)
  const cells = [];
  for (let i = 0; i < lead; i += 1) cells.push(null);
  for (let d = 1; d <= monthLen; d += 1) {
    const g = jalaliToGregorian(view.jy, view.jm, d);
    cells.push({ d, iso: toISODate(g.gy, g.gm, g.gd) });
  }

  function go(delta) {
    setView((v) => {
      let jm = v.jm + delta;
      let jy = v.jy;
      if (jm < 1) { jm = 12; jy -= 1; }
      if (jm > 12) { jm = 1; jy += 1; }
      return { jy: Math.min(MAX_YEAR, Math.max(MIN_YEAR, jy)), jm };
    });
  }
  const isOut = (iso) => (min && iso < min) || (max && iso > max);
  const years = YEARS.includes(view.jy) ? YEARS : [...YEARS, view.jy].sort((a, b) => a - b);

  return (
    <div className="jdp-cal">
      <div className="jdp-head">
        <button type="button" className="jdp-nav" onClick={() => go(-1)} aria-label={t("datePicker.prevMonth")}><ChevronRight size={16} /></button>
        <select aria-label={t("datePicker.month")} value={view.jm} onChange={(e) => setView((v) => ({ ...v, jm: Number(e.target.value) }))}>
          {MONTH_NAMES.map((name, i) => <option key={name} value={i + 1}>{name}</option>)}
        </select>
        <select aria-label={t("datePicker.year")} value={view.jy} onChange={(e) => setView((v) => ({ ...v, jy: Number(e.target.value) }))}>
          {years.map((y) => <option key={y} value={y}>{toFaDigits(y)}</option>)}
        </select>
        <button type="button" className="jdp-nav" onClick={() => go(1)} aria-label={t("datePicker.nextMonth")}><ChevronLeft size={16} /></button>
      </div>
      <div className="jdp-grid jdp-weekdays" aria-hidden="true">
        {WEEKDAY_SHORT.map((w, i) => <span key={i} className={i === 6 ? "is-fri" : ""}>{w}</span>)}
      </div>
      <div className="jdp-grid" role="grid" aria-label={`${MONTH_NAMES[view.jm - 1]} ${toFaDigits(view.jy)}`}>
        {cells.map((c, i) => c ? (
          <button
            key={c.iso}
            type="button"
            role="gridcell"
            className={`jdp-day ${c.iso === value ? "is-selected" : ""} ${c.iso === today ? "is-today" : ""} ${(lead + c.d - 1) % 7 === 6 ? "is-fri" : ""}`}
            disabled={isOut(c.iso)}
            aria-selected={c.iso === value}
            aria-label={formatDate(c.iso, { month: "long", weekday: true })}
            onClick={() => onPick(c.iso)}
          >
            {toFaDigits(c.d)}
          </button>
        ) : <span key={`e${i}`} />)}
      </div>
      <div className="jdp-foot">
        <button type="button" disabled={isOut(today)} onClick={() => onPick(today)}>{t("datePicker.today")}</button>
        {!required && <button type="button" onClick={onClear}>{t("datePicker.clear")}</button>}
      </div>
    </div>
  );
}

export function JalaliDateInput({ value, onChange, min, max, className, disabled, required, placeholder, name, id, onBlur, onClick, "aria-label": ariaLabel, ...rest }) {
  const autoId = useId();
  const inputRef = useRef(null);
  const popupRef = useRef(null);
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState(null); // null = نمایش مقدار فعلی؛ رشته = در حال تایپ
  const close = useCallback(() => setOpen(false), []);
  const pos = useCalendarPopup(open, inputRef, popupRef, close);
  const { lang, t } = useLanguage();

  // انگلیسی: تاریخ میلادی با ورودی استاندارد مرورگر (مقدار همان ISO میلادی است)
  if (lang === "en") {
    return (
      <input
        {...rest}
        id={id}
        name={name}
        type="date"
        className={`jdp-input ${className || ""}`}
        value={value || ""}
        min={min}
        max={max}
        disabled={disabled}
        required={required}
        aria-label={ariaLabel}
        onClick={onClick}
        onBlur={onBlur}
        onChange={(e) => onChange?.({ target: { value: e.target.value, name, id: id || autoId, type: "date" } })}
      />
    );
  }

  const shown = draft ?? isoToJalaliInput(value);
  const emit = (iso) => onChange?.({ target: { value: iso, name, id: id || autoId, type: "date" } });
  const inRange = (iso) => !((min && iso < min) || (max && iso > max));

  function commit() {
    if (draft === null) return;
    const text = draft.trim();
    setDraft(null);
    if (!text) { if (value) emit(""); return; }
    const iso = parseJalaliInput(text);
    if (iso && inRange(iso)) { if (iso !== value) emit(iso); }
    // نامعتبر یا خارج از بازه → به مقدار قبلی برمی‌گردد
  }

  return (
    <>
      <input
        {...rest}
        ref={inputRef}
        id={id}
        name={name}
        type="text"
        dir="ltr"
        inputMode="numeric"
        autoComplete="off"
        className={`jdp-input ${className || ""}`}
        value={shown}
        placeholder={placeholder ?? t("datePicker.placeholder")}
        disabled={disabled}
        required={required}
        aria-label={ariaLabel}
        aria-haspopup="dialog"
        aria-expanded={open}
        onChange={(e) => setDraft(e.target.value)}
        onFocus={() => !disabled && setOpen(true)}
        onClick={(e) => { onClick?.(e); if (!disabled) setOpen(true); }}
        onBlur={(e) => { commit(); onBlur?.(e); }}
        onKeyDown={(e) => {
          if (e.key === "Enter") { if (draft !== null) { e.preventDefault(); commit(); } }
          else if (e.key === "ArrowDown") setOpen(true);
        }}
      />
      {open && createPortal(
        <div ref={popupRef} className="jdp-popup" role="dialog" aria-label={t("datePicker.dialog")} style={{ top: pos.top, left: pos.left }} onMouseDown={(e) => { if (!e.target.closest("select")) e.preventDefault(); }}>
          <Calendar
            value={value || ""}
            min={min}
            max={max}
            required={required}
            onPick={(iso) => { setDraft(null); emit(iso); setOpen(false); }}
            onClear={() => { setDraft(null); emit(""); setOpen(false); }}
          />
        </div>,
        document.body
      )}
    </>
  );
}

// جایگزین <input type="datetime-local">: تاریخ شمسی + ساعت. مقدار «YYYY-MM-DDTHH:mm» (میلادی، به وقت محلی)
export function JalaliDateTimeInput({ value, onChange, min, max, className, disabled, required, name, id, "aria-label": ariaLabel }) {
  const { t } = useLanguage();
  const date = value ? String(value).slice(0, 10) : "";
  const time = value && String(value).length >= 16 ? String(value).slice(11, 16) : "";
  const minDate = min ? String(min).slice(0, 10) : undefined;
  const maxDate = max ? String(max).slice(0, 10) : undefined;
  const emit = (d, t) => onChange?.({ target: { value: d ? `${d}T${t || "00:00"}` : "", name, id, type: "datetime-local" } });
  return (
    <span className="jdp-dt">
      <JalaliDateInput value={date} min={minDate} max={maxDate} className={className} disabled={disabled} required={required} id={id} name={name} aria-label={ariaLabel ? `${ariaLabel} (${t("datePicker.dateWord")})` : t("datePicker.dateWord")} onChange={(e) => emit(e.target.value, time)} />
      <input type="time" className={className} value={time} disabled={disabled || !date} aria-label={ariaLabel ? `${ariaLabel} (${t("datePicker.timeWord")})` : t("datePicker.timeWord")} onChange={(e) => emit(date, e.target.value)} />
    </span>
  );
}

export default JalaliDateInput;

import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Heart, MessageCircle, Pin } from "lucide-react";
import { apiRequest, resolvePhotoUrl } from "../utils/api.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../i18n/useLocalizedSettings.js";
import { ensureAuthenticated } from "../utils/authGuard.js";

export function formatDate(iso) {
  try {
    return new Date(iso).toLocaleDateString("fa-IR-u-ca-persian");
  } catch {
    return "";
  }
}

export function resolveNewsImage(imageUrl) {
  return resolvePhotoUrl(imageUrl) || imageUrl || null;
}

// در صفحه‌ی اصلی ابتدا این تعداد خبر نمایش داده می‌شود؛ بقیه با دکمه‌ی «نمایش مطالب بیشتر» باز می‌شوند
// (هیچ خبری پنهان یا حذف نمی‌شود — صفحه‌ی مستقلی برای آرشیو اخبار وجود ندارد).
const HOME_NEWS_LIMIT = 6;

// ---------- بخش اخبار در صفحه‌ی اصلی — طراحی ساده‌شده ----------
// فیلترهای دسته‌بندی/تاریخ، سایدبار «آخرین اخبار» و سایدبار «آرشیو» حذف شده‌اند.
// جستجوی متنی اخبار قبلاً از طریق پارامتر آدرس «newsSearch» (که Navbar.jsx تنظیم
// می‌کرد) انجام می‌شد؛ آن سازوکار حذف شده و با جستجوی سراسری جدید در هدر
// (components/search) جایگزین شده است. این بخش اکنون فقط یک شبکه‌ی ساده و
// واکنش‌گرا از کارت‌های خبر نمایش می‌دهد.
export default function News() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const { settings } = useLocalizedSettings();
  const { t, lang, loc, formatDate: formatLocalizedDate } = useLanguage();

  const [articles, setArticles] = useState([]);
  const [status, setStatus] = useState("loading");
  // وضعیت لایک هر خبر جداگانه نگه‌داری می‌شود تا بعد از کلیک روی لایک، فوراً (بدون
  // رفرش صفحه و بدون نیاز به دوباره گرفتن کل فهرست) در همان کارت به‌روزرسانی شود.
  const [likeState, setLikeState] = useState({});
  const [likeSubmittingId, setLikeSubmittingId] = useState(null);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    apiRequest("/news")
      .then((data) => {
        const list = data.news || [];
        setArticles(list);
        setLikeState(
          Object.fromEntries(list.map((a) => [a.id, { liked: !!a.liked, count: a.likesCount || 0 }]))
        );
        setStatus("ok");
      })
      .catch(() => setStatus("error"));
  }, []);

  function openArticle(id) {
    navigate(`/news/${id}`);
  }

  // لایک/برداشتن لایک — به‌روزرسانی خوش‌بینانه (Optimistic) برای واکنش آنی؛ اگر
  // درخواست سرور ناموفق شود، به حالت قبلی برمی‌گردد. کاربر مهمان به فورمه‌ی ورود
  // هدایت می‌شود (همان الگوی «نوبت‌دهی» در Navbar.jsx).
  async function handleToggleLike(e, id) {
    e.stopPropagation();
    if (!ensureAuthenticated(isAuthenticated) || likeSubmittingId === id) return;

    const current = likeState[id] || { liked: false, count: 0 };
    setLikeSubmittingId(id);
    setLikeState((prev) => ({
      ...prev,
      [id]: { liked: !current.liked, count: current.liked ? current.count - 1 : current.count + 1 },
    }));
    try {
      const data = await apiRequest(`/news/${id}/like`, { method: "POST" });
      setLikeState((prev) => ({ ...prev, [id]: { liked: !!data.liked, count: data.likesCount } }));
    } catch (err) {
      setLikeState((prev) => ({ ...prev, [id]: current }));
    } finally {
      setLikeSubmittingId(null);
    }
  }

  const visible = expanded ? articles : articles.slice(0, HOME_NEWS_LIMIT);

  return (
    <section id="news" className="pub-section nw">
      <div className="container">
        <div className="pub-head">
          <div className="pub-head-text">
            <span className="pub-eyebrow">{t("news.eyebrow")}</span>
            <h2>{t("news.title")}</h2>
            <p>{t("news.subtitle", { hospital: settings.hospitalName })}</p>
          </div>
        </div>

        {status === "loading" && <p className="pub-state" role="status">{t("news.loading")}</p>}
        {status === "error" && <p className="pub-state" role="alert">{t("common.serverUnreachable")}</p>}

        {status === "ok" && (
          <>
            {articles.length === 0 && <p className="pub-state">{t("news.empty")}</p>}

            {articles.length > 0 && (
              <ul className="nw-grid">
                {visible.map((a) => {
                  const like = likeState[a.id] || { liked: false, count: a.likesCount || 0 };
                  return (
                    <li key={a.id} className="nw-item">
                      <article
                        className="nw-card pub-card"
                        onClick={() => openArticle(a.id)}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            openArticle(a.id);
                          }
                        }}
                      >
                        <div className="nw-thumb">
                          <img src={resolveNewsImage(a.imageUrl)} alt={loc(a, "title")} loading="lazy" />
                          {a.isPinned && (
                            <span className="nw-pin" aria-hidden="true"><Pin size={13} /></span>
                          )}
                        </div>
                        <div className="nw-body">
                          <time className="nw-date" dateTime={a.publishedAt}>
                            {lang === "fa" ? formatDate(a.publishedAt) : formatLocalizedDate(a.publishedAt, { month: "long" })}
                          </time>
                          <h3 className="nw-title">{loc(a, "title")}</h3>
                          <p className="nw-excerpt">{loc(a, "excerpt")}</p>

                          <div className="nw-actions">
                            <button
                              type="button"
                              className={`nw-btn${like.liked ? " is-liked" : ""}`}
                              onClick={(e) => handleToggleLike(e, a.id)}
                              disabled={likeSubmittingId === a.id}
                              aria-pressed={like.liked}
                              title={isAuthenticated ? (like.liked ? t("news.unlike") : t("news.like")) : t("news.loginToLike")}
                            >
                              <Heart size={15} fill={like.liked ? "currentColor" : "none"} aria-hidden="true" />
                              <span>{like.count}</span>
                            </button>
                            <span className="nw-btn nw-btn--static">
                              <MessageCircle size={15} aria-hidden="true" />
                              <span>{a.commentsCount || 0}</span>
                            </span>
                          </div>
                        </div>
                      </article>
                    </li>
                  );
                })}
              </ul>
            )}

            {articles.length > HOME_NEWS_LIMIT && (
              <div className="nw-more">
                <button type="button" className="pub-btn pub-btn--ghost" onClick={() => setExpanded((v) => !v)} aria-expanded={expanded}>
                  {expanded ? t("news.showLess") : t("news.showMore")}
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}

import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  Search, X, Eye, Printer, Download, RefreshCw, Pill, CheckCircle2, Clock, XCircle, MoreVertical,
  ClipboardList, AlertTriangle, FilterX,
} from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import { useDepartmentToasts, DepartmentToastContainer } from "./DepartmentToast.jsx";
import { apiRequest, apiDownload } from "../../utils/api.js";
import { groupPrescriptions } from "../../utils/prescriptionGroups.js";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, numLocale, curDir } from "../../i18n/tr.js";
// ============================================================================
// پنل ادمین «نسخه و سوابق طبی»
// ----------------------------------------------------------------------------
// APIهای استفاده‌شده:
//   GET  /api/admin/prescriptions            (فهرست + جستجو + فیلتر + صفحه‌بندی)   — جدید
//   GET  /api/admin/prescriptions/stats      (کارت‌های آماری)                        — جدید
//   PUT  /api/admin/prescriptions/:id/status (تکمیل / لغو / فعال‌سازی مجدد)         — جدید
//   GET  /api/admin/doctors                  (گزینه‌های فیلتر داکتر)                 — موجود
//   GET  /api/admin/patients/:id/full-profile (اطلاعات مریض، اقلام نسخه، سوابق طبی)  — موجود
//   GET  /api/medical-records/prescriptions/:id/pdf (چاپ / PDF)                      — موجود
//   GET  /api/medical-records/lab-results/:id/report (گزارش آزمایش)                   — موجود
// استایل‌ها: components/dashboard/AdminPrescriptionsPanel.css (کلاس‌های rxp-*، روی توکن‌های تم موجود)
// ============================================================================

const STATUS_LABEL = trc({ active: "در حال اجرا", completed: "تکمیل‌شده", cancelled: "لغوشده" });
const GENDER_LABEL = trc({ male: "مرد", female: "زن" });
const SEVERITY_LABEL = trc({ mild: "خفیف", moderate: "متوسط", severe: "شدید" });
const DIAGNOSIS_STATUS_LABEL = trc({ active: "در حال جریان", resolved: "بهبودیافته" });
const LAB_STATUS_LABEL = trc({ pending: "در انتظار نتیجه", completed: "تکمیل‌شده" });
const EMPTY_FILTERS = { dateFrom: "", dateTo: "", status: "", doctorId: "" };

function fmtDate(v) {
  return v ? new Date(v).toLocaleDateString(numLocale()) : "—";
}

function rxNumberOf(row) {
  return row.rxNumber || `RX-${String(row.id).padStart(6, "0")}`;
}

function useDebounced(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

function StatusBadge({ status }) {
  const key = STATUS_LABEL[status] ? status : "active";
  return <span className={`rxp-badge rxp-badge-${key}`}>{STATUS_LABEL[key]}</span>;
}

// ---------- منوی «گزینه‌های بیشتر» ----------
// منو با Portal و موقعیت fixed رندر می‌شود تا داخل جدول (overflow) بریده نشود
function RowMenu({ items }) {
  const [pos, setPos] = useState(null);
  const btnRef = useRef(null);

  function toggle(e) {
    e.stopPropagation();
    if (pos) return setPos(null);
    const rect = btnRef.current.getBoundingClientRect();
    const menuWidth = 190;
    const left = Math.max(8, Math.min(rect.left, window.innerWidth - menuWidth - 8));
    const openUp = rect.bottom + 150 > window.innerHeight;
    setPos({ left, top: openUp ? undefined : rect.bottom + 6, bottom: openUp ? window.innerHeight - rect.top + 6 : undefined });
  }

  useEffect(() => {
    if (!pos) return undefined;
    const close = () => setPos(null);
    const onKey = (e) => { if (e.key === "Escape") close(); };
    window.addEventListener("click", close);
    window.addEventListener("scroll", close, true);
    window.addEventListener("resize", close);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("scroll", close, true);
      window.removeEventListener("resize", close);
      window.removeEventListener("keydown", onKey);
    };
  }, [pos]);

  return (
    <>
      <button ref={btnRef} type="button" className="rxp-icon-btn" title={tr("گزینه‌های بیشتر")} aria-label={tr("گزینه‌های بیشتر")} aria-haspopup="menu" aria-expanded={!!pos} onClick={toggle}>
        <MoreVertical size={16} />
      </button>
      {pos && createPortal(
        <div className="rxp-menu glass" role="menu" style={{ left: pos.left, top: pos.top, bottom: pos.bottom }} onClick={(e) => e.stopPropagation()}>
          {items.map((it) => (
            <button
              key={it.key}
              type="button"
              role="menuitem"
              className={`rxp-menu-item ${it.danger ? "danger" : ""}`}
              onClick={() => { setPos(null); it.onClick(); }}
            >
              {it.icon}{it.label}
            </button>
          ))}
        </div>,
        document.body
      )}
    </>
  );
}

// ---------- پنل اصلی ----------
export default function AdminPrescriptionsPanel() {
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [stats, setStats] = useState(null);
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [reloadTick, setReloadTick] = useState(0);
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  const debouncedSearch = useDebounced(search);
  const hasFilters = !!(search || filters.dateFrom || filters.dateTo || filters.status || filters.doctorId);

  // با تغییر جستجو یا هر فیلتر، به صفحه‌ی اول برمی‌گردیم
  useEffect(() => setPage(1), [debouncedSearch, filters.dateFrom, filters.dateTo, filters.status, filters.doctorId]);

  // فهرست داکتران برای فیلتر (همان مسیر موجودِ پنل «مدیریت بیماران»)
  useEffect(() => {
    apiRequest("/admin/doctors").then((d) => setDoctors(d.doctors || [])).catch(() => {});
  }, []);

  // فهرست نسخه‌ها — درخواست‌های قدیمی‌تر که دیر برسند نادیده گرفته می‌شوند
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    const usp = new URLSearchParams({ page, limit: 10 });
    if (debouncedSearch.trim()) usp.set("q", debouncedSearch.trim());
    Object.entries(filters).forEach(([k, v]) => { if (v) usp.set(k, v); });
    apiRequest(`/admin/prescriptions?${usp.toString()}`)
      .then((data) => {
        if (cancelled) return;
        setItems(data.prescriptions || []);
        setPagination(data.pagination || null);
      })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, filters.dateFrom, filters.dateTo, filters.status, filters.doctorId, page, reloadTick]);

  // آمار کل
  const [statsError, setStatsError] = useState(false);
  useEffect(() => {
    setStatsError(false);
    apiRequest("/admin/prescriptions/stats")
      .then((d) => setStats(d.stats))
      .catch(() => setStatsError(true));
  }, [reloadTick]);

  function setFilter(key, value) {
    setFilters((f) => ({ ...f, [key]: value }));
  }
  function clearAll() {
    setSearch("");
    setFilters(EMPTY_FILTERS);
  }

  async function printRx(row) {
    setBusyId(`print-${row.id}`);
    try {
      await apiDownload(`/medical-records/prescriptions/${row.id}/pdf`, `prescription-${row.id}.pdf`, { print: true });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyId(null);
    }
  }
  async function pdfRx(row) {
    setBusyId(`pdf-${row.id}`);
    try {
      await apiDownload(`/medical-records/prescriptions/${row.id}/pdf`, `prescription-${row.id}.pdf`, { openInNewTab: true });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyId(null);
    }
  }

  // تغییر وضعیت نسخه (از جدول یا از پنجره‌ی جزئیات)
  async function changeStatus(row, status) {
    const confirmText = {
      cancelled: tr("نسخه {0} لغو شود؟ نسخه حذف نمی‌شود و فقط وضعیت آن «لغوشده» می‌شود.", [rxNumberOf(row)]),
      completed: tr("نسخه {0} به‌عنوان «تکمیل‌شده» ثبت شود؟", [rxNumberOf(row)]),
    }[status];
    if (confirmText && !window.confirm(confirmText)) return false;
    try {
      const res = await apiRequest(`/admin/prescriptions/${row.id}/status`, { method: "PUT", body: { status } });
      showToast(res.message || tr("وضعیت نسخه تغییر کرد"), "success");
      setItems((list) => list.map((it) => (it.id === row.id ? { ...it, status } : it)));
      setSelected((cur) => (cur && cur.id === row.id ? { ...cur, status } : cur));
      setReloadTick((t) => t + 1);
      return true;
    } catch (err) {
      showToast(err.message, "error");
      return false;
    }
  }

  function menuItemsFor(row) {
    const list = [];
    if (row.status !== "completed") list.push({ key: "complete", label: tr("ثبت به‌عنوان تکمیل‌شده"), icon: <CheckCircle2 size={15} />, onClick: () => changeStatus(row, "completed") });
    if (row.status !== "active") list.push({ key: "reactivate", label: tr("بازگردانی به «در حال اجرا»"), icon: <Clock size={15} />, onClick: () => changeStatus(row, "active") });
    if (row.status !== "cancelled") list.push({ key: "cancel", label: tr("لغو نسخه"), icon: <XCircle size={15} />, danger: true, onClick: () => changeStatus(row, "cancelled") });
    return list;
  }

  const statCards = [
    { key: "total", label: tr("کل نسخه‌ها"), icon: <ClipboardList size={22} />, tone: "total" },
    { key: "completed", label: tr("نسخه‌های تکمیل‌شده"), icon: <CheckCircle2 size={22} />, tone: "completed" },
    { key: "active", label: tr("نسخه‌های در حال اجرا"), icon: <Clock size={22} />, tone: "active" },
    { key: "cancelled", label: tr("نسخه‌های لغوشده"), icon: <XCircle size={22} />, tone: "cancelled" },
  ];

  return (
    <div className="rxp">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* هدر */}
      <div className="rxp-header glass">
        <div className="rxp-header-main">
          <span className="rxp-header-icon"><Pill size={26} /></span>
          <div>
            <h2>{tr("نسخه و سوابق طبی")}</h2>
            <p>{tr("مشاهده و مدیریت نسخه‌ها و سوابق پزشکی بیماران")}</p>
          </div>
        </div>
        <div className="rxp-header-actions">
          {hasFilters && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>
              <FilterX size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("پاک‌کردن فیلترها")}</button>
          )}
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setReloadTick((t) => t + 1)} disabled={loading}>
            <RefreshCw size={14} className={loading ? "rxp-spin" : ""} style={{ verticalAlign: "-2px" }} />{" "}{tr("بازخوانی")}</button>
        </div>
      </div>

      {/* کارت‌های آماری */}
      <div className="rxp-stats">
        {statCards.map((c) => (
          <div key={c.key} className={`rxp-stat rxp-stat-${c.tone} glass`}>
            <span className="rxp-stat-icon">{c.icon}</span>
            <div>
              <span className="rxp-stat-label">{c.label}</span>
              {stats
                ? <strong>{Number(stats[c.key] || 0).toLocaleString(numLocale())}</strong>
                : statsError ? <strong>—</strong> : <span className="rxp-skeleton rxp-skeleton-num" />}
            </div>
          </div>
        ))}
      </div>

      {/* جستجو و فیلتر */}
      <div className="rxp-toolbar glass">
        <div className="rxp-search">
          <Search size={17} />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tr("جستجو: نام مریض، نام داکتر یا شماره نسخه (مثلاً RX-000012)")}
            aria-label={tr("جستجوی نسخه")}
          />
          {search && (
            <button type="button" className="rxp-search-clear" onClick={() => setSearch("")} aria-label={tr("پاک‌کردن جستجو")}><X size={15} /></button>
          )}
        </div>
        <div className="rxp-filters">
          <div className="field">
            <label>{tr("از تاریخ")}</label>
            <JalaliDateInput value={filters.dateFrom} max={filters.dateTo || undefined} onChange={(e) => setFilter("dateFrom", e.target.value)} />
          </div>
          <div className="field">
            <label>{tr("تا تاریخ")}</label>
            <JalaliDateInput value={filters.dateTo} min={filters.dateFrom || undefined} onChange={(e) => setFilter("dateTo", e.target.value)} />
          </div>
          <div className="field">
            <label>{tr("وضعیت نسخه")}</label>
            <select value={filters.status} onChange={(e) => setFilter("status", e.target.value)}>
              <option value="">{tr("همه وضعیت‌ها")}</option>
              {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
          <div className="field">
            <label>{tr("داکتر")}</label>
            <select value={filters.doctorId} onChange={(e) => setFilter("doctorId", e.target.value)}>
              <option value="">{tr("همه داکتران")}</option>
              {doctors.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
            </select>
          </div>
        </div>
      </div>

      {/* جدول */}
      <div className="rxp-table-card glass">
        {error && (
          <div className="rxp-state rxp-state-error" role="alert">
            <AlertTriangle size={34} />
            <h4>{tr("بارگذاری نسخه‌ها ناموفق بود")}</h4>
            <p>{error}</p>
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setReloadTick((t) => t + 1)}>{tr("تلاش دوباره")}</button>
          </div>
        )}

        {!error && (
          <div className="rxp-table-wrap">
            <table className="rxp-table">
              <thead>
                <tr>
                  <th>{tr("شماره نسخه")}</th>
                  <th>{tr("تاریخ")}</th>
                  <th>{tr("نام مریض")}</th>
                  <th>{tr("داکتر")}</th>
                  <th>{tr("تعداد دارو")}</th>
                  <th>{tr("وضعیت")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {loading && items.length === 0 && Array.from({ length: 6 }).map((_, i) => (
                  <tr key={`sk-${i}`} className="rxp-row-skeleton" aria-hidden="true">
                    {Array.from({ length: 7 }).map((__, j) => <td key={j}><span className="rxp-skeleton" /></td>)}
                  </tr>
                ))}
                {items.map((row) => (
                  <tr key={row.id} className={`rxp-row ${loading ? "is-loading" : ""}`} onClick={() => setSelected(row)}>
                    <td data-label={tr("شماره نسخه")}><span className="rxp-rxnum">{rxNumberOf(row)}</span></td>
                    <td data-label={tr("تاریخ")}>{fmtDate(row.createdAt)}</td>
                    <td data-label={tr("نام مریض")}>
                      <b>{row.patientName || "—"}</b>
                      {row.patientCode && <small className="rxp-sub">{row.patientCode}</small>}
                    </td>
                    <td data-label={tr("داکتر")}>
                      {row.doctorName || <span className="rxp-muted">{tr("بدون داکتر")}</span>}
                      {row.doctorDepartment && <small className="rxp-sub">{row.doctorDepartment}</small>}
                    </td>
                    <td data-label={tr("تعداد دارو")}>
                      <span className="rxp-count" title={row.medicineNames || undefined}>{Number(row.itemCount).toLocaleString(numLocale())}</span>
                    </td>
                    <td data-label={tr("وضعیت")}><StatusBadge status={row.status} /></td>
                    <td data-label={tr("عملیات")} onClick={(e) => e.stopPropagation()}>
                      <div className="rxp-actions">
                        <button type="button" className="rxp-icon-btn rxp-view" title={tr("مشاهده")} aria-label={tr("مشاهده")} onClick={() => setSelected(row)}><Eye size={16} /></button>
                        <button type="button" className="rxp-icon-btn" title={tr("چاپ")} aria-label={tr("چاپ")} disabled={busyId === `print-${row.id}`} onClick={() => printRx(row)}><Printer size={16} /></button>
                        <button type="button" className="rxp-icon-btn" title={tr("دانلود PDF")} aria-label={tr("دانلود PDF")} disabled={busyId === `pdf-${row.id}`} onClick={() => pdfRx(row)}><Download size={16} /></button>
                        <RowMenu items={menuItemsFor(row)} />
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {!loading && items.length === 0 && (
              <div className="rxp-state">
                <ClipboardList size={38} />
                <h4>{hasFilters ? tr("نسخه‌ای با این مشخصات یافت نشد") : tr("هنوز نسخه‌ای ثبت نشده است")}</h4>
                <p>{hasFilters ? tr("جستجو یا فیلترها را تغییر دهید.") : tr("نسخه‌هایی که داکتران ثبت می‌کنند در این فهرست نمایش داده می‌شوند.")}</p>
                {hasFilters && <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>{tr("پاک‌کردن فیلترها")}</button>}
              </div>
            )}
          </div>
        )}

        {!error && pagination && pagination.totalPages > 1 && (
          <div className="rxp-pagination">
            <button type="button" className="btn btn-ghost btn-sm" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>{tr("صفحه قبل")}</button>
            <span>{tr("صفحه {0} از {1} ({2} نسخه)", [pagination.page.toLocaleString(numLocale()), pagination.totalPages.toLocaleString(numLocale()), pagination.total.toLocaleString(numLocale())])}</span>
            <button type="button" className="btn btn-ghost btn-sm" disabled={page >= pagination.totalPages || loading} onClick={() => setPage(page + 1)}>{tr("صفحه بعد")}</button>
          </div>
        )}
      </div>

      <GlobalModal
        isOpen={!!selected}
        onClose={() => setSelected(null)}
        size="xl"
        title={selected ? tr("جزئیات نسخه {0}", [rxNumberOf(selected)]) : ""}
        className="rxp-modal"
      >
        {selected && (
          <PrescriptionDetailView
            row={selected}
            onPrint={() => printRx(selected)}
            onPdf={() => pdfRx(selected)}
            onChangeStatus={(status) => changeStatus(selected, status)}
            onError={(msg) => showToast(msg, "error")}
          />
        )}
      </GlobalModal>
    </div>
  );
}

// ---------- جزئیات نسخه + سوابق طبی ----------
function PrescriptionDetailView({ row, onPrint, onPdf, onChangeStatus, onError }) {
  const [tab, setTab] = useState("details");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadTick, setReloadTick] = useState(0);

  // پرونده‌ی کامل بیمار (مسیر موجود) — اطلاعات مریض، اقلام نسخه و سوابق طبی از همین یک درخواست
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    apiRequest(`/admin/patients/${row.patientId}/full-profile`)
      .then((res) => { if (!cancelled) setData(res); })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [row.patientId, reloadTick]);

  // نسخه‌ی کامل (همه‌ی داروهای همین نسخه) از روی groupId
  const rx = useMemo(() => {
    if (!data) return null;
    const groups = groupPrescriptions(data.prescriptions || []);
    return groups.find((g) => g.medicines.some((m) => m.id === row.id)) || null;
  }, [data, row.id]);

  const otherPrescriptions = useMemo(() => {
    if (!data) return [];
    return groupPrescriptions(data.prescriptions || []).filter((g) => !g.medicines.some((m) => m.id === row.id));
  }, [data, row.id]);

  const meds = rx?.medicines || [];
  const hasFrequency = meds.some((m) => m.frequency);
  const patient = data?.patient;
  const allergies = data?.allergies || [];
  const profileAllergies = [patient?.drugAllergies, patient?.allergies].filter(Boolean);

  async function downloadLab(id) {
    try {
      await apiDownload(`/medical-records/lab-results/${id}/report`, `lab-report-${id}`, { openInNewTab: true });
    } catch (err) {
      onError(err.message);
    }
  }

  return (
    <div className="rxp-detail" dir={curDir()}>
      <div className="rxp-detail-top">
        <div className="rxp-detail-meta">
          <StatusBadge status={row.status} />
          <span>{tr("تاریخ نسخه:")}{" "}<b>{fmtDate(row.createdAt)}</b></span>
          <span>{tr("تعداد دارو:")}{" "}<b>{Number(row.itemCount).toLocaleString(numLocale())}</b></span>
        </div>
        <div className="rxp-detail-actions">
          <button type="button" className="btn btn-ghost btn-sm" onClick={onPrint}><Printer size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("چاپ")}</button>
          <button type="button" className="btn btn-primary btn-sm" onClick={onPdf}><Download size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("دانلود PDF")}</button>
          {row.status !== "completed" && <button type="button" className="btn btn-ghost btn-sm" onClick={() => onChangeStatus("completed")}>{tr("تکمیل‌شده")}</button>}
          {row.status !== "active" && <button type="button" className="btn btn-ghost btn-sm" onClick={() => onChangeStatus("active")}>{tr("در حال اجرا")}</button>}
          {row.status !== "cancelled" && <button type="button" className="btn btn-ghost btn-sm danger" onClick={() => onChangeStatus("cancelled")}>{tr("لغو نسخه")}</button>}
        </div>
      </div>

      <div className="rxp-tabs" role="tablist">
        <button type="button" role="tab" aria-selected={tab === "details"} className={tab === "details" ? "active" : ""} onClick={() => setTab("details")}>{tr("💊 جزئیات نسخه")}</button>
        <button type="button" role="tab" aria-selected={tab === "history"} className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>{tr("🗂️ سوابق طبی مریض")}</button>
      </div>

      {loading && (
        <div className="rxp-detail-loading" aria-busy="true">
          <span className="rxp-skeleton rxp-skeleton-block" />
          <span className="rxp-skeleton rxp-skeleton-block" />
          <span className="rxp-skeleton rxp-skeleton-block tall" />
        </div>
      )}

      {!loading && error && (
        <div className="rxp-state rxp-state-error" role="alert">
          <AlertTriangle size={30} />
          <h4>{tr("بارگذاری اطلاعات ناموفق بود")}</h4>
          <p>{error}</p>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setReloadTick((t) => t + 1)}>{tr("تلاش دوباره")}</button>
        </div>
      )}

      {!loading && !error && data && tab === "details" && (
        <>
          <div className="rxp-info-grid">
            <section className="rxp-card">
              <h4>{tr("اطلاعات مریض")}</h4>
              <dl>
                <div><dt>{tr("نام مریض")}</dt><dd>{patient.fullName}</dd></div>
                <div><dt>{tr("کد مریض")}</dt><dd>{row.patientCode || `#${patient.id}`}</dd></div>
                <div><dt>{tr("جنسیت")}</dt><dd>{GENDER_LABEL[patient.gender] || "—"}</dd></div>
                <div><dt>{tr("تاریخ تولد")}</dt><dd>{fmtDate(patient.dateOfBirth)}</dd></div>
                <div><dt>{tr("گروه خونی")}</dt><dd>{patient.bloodGroup || "—"}</dd></div>
                <div><dt>{tr("شماره تماس")}</dt><dd dir="ltr">{patient.phone || "—"}</dd></div>
              </dl>
            </section>
            <section className="rxp-card">
              <h4>{tr("اطلاعات داکتر")}</h4>
              <dl>
                <div><dt>{tr("نام داکتر")}</dt><dd>{row.doctorName || "—"}</dd></div>
                <div><dt>{tr("شناسه داکتر")}</dt><dd>{row.doctorCode || (row.doctorId ? `#${row.doctorId}` : "—")}</dd></div>
                <div><dt>{tr("بخش")}</dt><dd>{row.doctorDepartment || "—"}</dd></div>
                <div><dt>{tr("شماره نسخه")}</dt><dd><span className="rxp-rxnum">{rxNumberOf(row)}</span></dd></div>
                <div><dt>{tr("تاریخ نسخه")}</dt><dd>{fmtDate(row.createdAt)}</dd></div>
                {rx?.followUpDate && <div><dt>{tr("تاریخ پیگیری")}</dt><dd>{fmtDate(rx.followUpDate)}</dd></div>}
              </dl>
            </section>
          </div>

          {(allergies.length > 0 || profileAllergies.length > 0) && (
            <div className="rxp-alert" role="note">
              <AlertTriangle size={18} />
              <div>
                <b>{tr("حساسیت‌های ثبت‌شده‌ی مریض")}</b>
                <p>
                  {[...allergies.map((a) => `${a.allergen}${a.severity ? ` (${SEVERITY_LABEL[a.severity] || a.severity})` : ""}`), ...profileAllergies].join(tr("، "))}
                </p>
              </div>
            </div>
          )}

          <section className="rxp-card rxp-block">
            <h4>{tr("تشخیص")}</h4>
            <p>{rx?.diagnosis || row.diagnosis || tr("تشخیصی برای این نسخه ثبت نشده است.")}</p>
          </section>

          <section className="rxp-card rxp-block">
            <h4>{tr("داروهای نسخه ({0})", [meds.length.toLocaleString(numLocale())])}</h4>
            {meds.length === 0 ? (
              <p className="rxp-muted">{tr("اقلام این نسخه در پرونده‌ی بیمار یافت نشد.")}</p>
            ) : (
              <div className="rxp-table-wrap">
                <table className="rxp-table rxp-table-compact">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>{tr("نام دارو")}</th>
                      <th>{tr("دوز")}</th>
                      {hasFrequency && <th>{tr("تکرار مصرف")}</th>}
                      <th>{tr("مدت مصرف")}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {meds.map((m, i) => (
                      <tr key={m.id}>
                        <td data-label="#">{(i + 1).toLocaleString(numLocale())}</td>
                        <td data-label={tr("نام دارو")}><b>{m.medicationName}</b></td>
                        <td data-label={tr("دوز")}>{m.dosage || "—"}</td>
                        {hasFrequency && <td data-label={tr("تکرار مصرف")}>{m.frequency || "—"}</td>}
                        <td data-label={tr("مدت مصرف")}>{m.duration || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <div className="rxp-info-grid">
            <section className="rxp-card rxp-block">
              <h4>{tr("دستور مصرف")}</h4>
              <p>{rx?.instructions || "—"}</p>
            </section>
            <section className="rxp-card rxp-block">
              <h4>{tr("توضیحات")}</h4>
              <p>{rx?.notes || "—"}</p>
            </section>
          </div>
        </>
      )}

      {!loading && !error && data && tab === "history" && (
        <div className="rxp-history">
          <HistorySection title={tr("ویزیت‌ها")} icon="📋" count={(data.encounters || []).length} emptyText={tr("ویزیتی ثبت نشده است.")}>
            {(data.encounters || []).map((e) => (
              <li key={e.id}>
                <div className="rxp-hist-head"><b>{fmtDate(e.visitDate || e.createdAt)}</b><span>{e.doctorName || "—"}</span></div>
                {e.diagnosis && <p><em>{tr("تشخیص:")}</em> {e.diagnosis}</p>}
                {e.symptoms && <p><em>{tr("علائم:")}</em> {e.symptoms}</p>}
                {e.treatment && <p><em>{tr("تداوی:")}</em> {e.treatment}</p>}
              </li>
            ))}
          </HistorySection>

          <HistorySection title={tr("تشخیص‌ها")} icon="🩺" count={(data.diagnoses || []).length} emptyText={tr("تشخیصی ثبت نشده است.")}>
            {(data.diagnoses || []).map((d) => (
              <li key={d.id}>
                <div className="rxp-hist-head"><b>{d.title}</b><span>{DIAGNOSIS_STATUS_LABEL[d.status] || d.status}</span></div>
                <p>{[d.icdCode && `ICD: ${d.icdCode}`, d.doctorName, fmtDate(d.createdAt)].filter(Boolean).join(" — ")}</p>
              </li>
            ))}
          </HistorySection>

          <HistorySection title={tr("حساسیت‌ها")} icon="⚠️" count={allergies.length} emptyText={tr("حساسیتی در پرونده‌ی الکترونیک ثبت نشده است.")}>
            {allergies.map((a) => (
              <li key={a.id}>
                <div className="rxp-hist-head"><b>{a.allergen}</b><span>{SEVERITY_LABEL[a.severity] || a.severity}</span></div>
                {a.reaction && <p><em>{tr("واکنش:")}</em> {a.reaction}</p>}
              </li>
            ))}
          </HistorySection>

          <HistorySection title={tr("آزمایش‌ها")} icon="🧪" count={(data.labResults || []).length} emptyText={tr("نتیجه‌ی آزمایشی ثبت نشده است.")}>
            {(data.labResults || []).map((l) => (
              <li key={l.id}>
                <div className="rxp-hist-head"><b>{l.testName}</b><span>{LAB_STATUS_LABEL[l.status] || l.status}</span></div>
                <p>
                  {[l.result && tr("نتیجه: {0}{1}", [l.result, l.unit ? ` ${l.unit}` : ""]), l.referenceRange && tr("محدوده‌ی نرمال: {0}", [l.referenceRange]), fmtDate(l.testDate || l.createdAt)].filter(Boolean).join(" — ")}
                </p>
                {l.reportUrl && <button type="button" className="btn btn-ghost btn-sm" onClick={() => downloadLab(l.id)}><Download size={13} style={{ verticalAlign: "-2px" }} />{" "}{tr("گزارش آزمایش")}</button>}
              </li>
            ))}
          </HistorySection>

          <HistorySection title={tr("رادیولوژی")} icon="🩻" count={(data.radiologyReports || []).length} emptyText={tr("گزارش رادیولوژی ثبت نشده است.")}>
            {(data.radiologyReports || []).map((r) => (
              <li key={r.id}>
                <div className="rxp-hist-head"><b>{r.examType}</b><span>{fmtDate(r.examDate || r.createdAt)}</span></div>
                {r.findings && <p><em>{tr("یافته‌ها:")}</em> {r.findings}</p>}
                {r.impression && <p><em>{tr("نتیجه‌گیری:")}</em> {r.impression}</p>}
              </li>
            ))}
          </HistorySection>

          <HistorySection title={tr("سایر نسخه‌های مریض")} icon="💊" count={otherPrescriptions.length} emptyText={tr("نسخه‌ی دیگری برای این مریض ثبت نشده است.")}>
            {otherPrescriptions.map((g) => (
              <li key={g.id}>
                <div className="rxp-hist-head">
                  <b>{`RX-${String(g.id).padStart(6, "0")}`}</b>
                  <span>{fmtDate(g.createdAt)}</span>
                </div>
                <p>{g.medicines.map((m) => [m.medicationName, m.dosage].filter(Boolean).join(" ")).join(tr("، "))}</p>
                <p className="rxp-muted">{[g.doctorName, g.diagnosis].filter(Boolean).join(" — ")}</p>
              </li>
            ))}
          </HistorySection>
        </div>
      )}
    </div>
  );
}

function HistorySection({ title, icon, count, emptyText, children }) {
  return (
    <details className="rxp-hist" open={count > 0 && count <= 3}>
      <summary>
        <span>{icon} {title}</span>
        <span className="rxp-hist-count">{Number(count).toLocaleString(numLocale())}</span>
      </summary>
      {count === 0 ? <p className="rxp-muted rxp-hist-empty">{emptyText}</p> : <ul>{children}</ul>}
    </details>
  );
}

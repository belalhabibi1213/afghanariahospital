import { useState } from "react";
import { apiRequest, resolvePhotoUrl } from "../../utils/api.js";
import { useSiteSettings } from "../../context/SettingsContext.jsx";

import { tr, trc, jdate, curDir } from "../../i18n/tr.js";
// ---------- وضعیت یکپارچه‌ی فاکتور (Invoice Status Workflow) ----------
// به‌جای دو ستون/نشانِ جداگانه‌ی قبلی («وضعیت پرداخت» و «وضعیت تایید»)، یک وضعیت
// واحد نمایش داده می‌شود: در انتظار تایید (Pending) / تایید شده (Approved) / لغوشده
// (Cancelled). داخلیِ دیتابیس همچنان status (وضعیت پرداخت: unpaid/partial/paid/
// cancelled) و approvalStatus را جدا نگه می‌دارد — فقط در UI یکپارچه نمایش داده می‌شود.
export const INVOICE_STATUS_LABEL = trc({
  pending: "در انتظار تایید",
  approved: "تایید شده",
  cancelled: "لغوشده",
});

// نگه‌داری‌شده برای سازگاری با کدهای قبلی که همین نام را وارد می‌کردند
export const APPROVAL_STATUS_LABEL = INVOICE_STATUS_LABEL;

export function getApprovalStatusKey(invoice) {
  if (invoice.status === "cancelled") return "cancelled";
  return invoice.approvalStatus === "approved" ? "approved" : "pending";
}

export const PAYMENT_METHOD_LABEL = trc({
  cash: "نقدی",
  card: "کارت",
  bank_transfer: "حواله بانکی",
  insurance: "بیمه",
  other: "سایر",
});

function money(n) {
  return Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 });
}

// تاریخ هجری شمسی (مثل ۱۴۰۵/۰۷/۱۷)؛ مقدار نامعتبر → رشته‌ی خالی
function fmtDate(value) {
  return value ? jdate(value, { empty: "" }) : "";
}

// اطلاعات ثابت سربرگ/پاورقی فاکتور (هویت شفاخانه). نام شفاخانه از تنظیمات سیستم می‌آید؛
// بقیه طبق الزام طراحی فاکتور اینجا یکجا تعریف شده تا در صورت تغییر فقط همین‌جا ویرایش شود.
const INVOICE_HEADER = trc({
  tagline: "سلامت شما، اولویت ما",
  address: "هرات، جاده قوماندانی",
  phone: "0783429510",
  hours: "8:00 صبح الی 5:00 عصر",
  footerWish: "با آرزوی سلامتی برای شما",
});

// آیکون‌های خطی ساده (SVG درون‌خطی، بدون وابستگی بیرونی)
const ICON_PATHS = {
  pin: "M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21Zm0-8.5a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z",
  phone: "M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z",
  clock: "M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm0-14v5l3 2",
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 9a7 7 0 0 1 14 0",
  doctor: "M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm-7 10a7 7 0 0 1 14 0M12 15v4m-2-2h4",
  calendar: "M7 3v3m10-3v3M4 8h16M5 5h14a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Zm3 7h2m3 0h2m-7 4h2m3 0h2",
  hash: "M9 4 7 20M17 4l-2 16M4 9h16M3 15h16",
  file: "M7 3h7l5 5v12a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm6 0v6h6M9 13h6m-6 4h6",
  steth: "M6 3v6a4 4 0 0 0 8 0V3M10 13v2a4 4 0 0 0 8 0v-1m0 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z",
  list: "M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01",
  coins: "M12 8c4.4 0 8-1.3 8-3s-3.6-3-8-3-8 1.3-8 3 3.6 3 8 3Zm8 0v4c0 1.7-3.6 3-8 3s-8-1.3-8-3V8m16 4v4c0 1.7-3.6 3-8 3s-8-1.3-8-3v-4",
  cash: "M3 7h18v10H3V7Zm9 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4ZM6 10h.01M18 14h.01",
  percent: "M19 5 5 19M7 9a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm10 10a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z",
  check: "m5 12 5 5 9-10",
  receipt: "M6 3h12v18l-3-2-3 2-3-2-3 2V3Zm3 5h6m-6 4h6",
};
function Icon({ name, size = 18 }) {
  return (
    <svg className="inv-icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={ICON_PATHS[name]} />
    </svg>
  );
}

// نمای جزئیات یک فاکتور: ردیف‌های کالا/خدمت، پرداخت‌های ثبت‌شده، وضعیت پرداخت،
// دکمه‌ی چاپ فاکتور (الزام شماره ۴) و — در صورت فعال بودن canRecordPayment —
// فورمه‌ی ثبت پرداخت جدید (الزام شماره ۲) برای پنل ادمین.
// این کامپوننت هم در داشبورد ادمین (بخش صورت‌حساب) و هم در داشبورد بیمار
// (سوابق صورت‌حساب) استفاده می‌شود تا منطق نمایش/چاپ فاکتور تکراری نشود.
export default function InvoiceDetail({ invoice, onClose, onChanged, canRecordPayment = false, recordPaymentPath }) {
  const { settings } = useSiteSettings();
  const [paying, setPaying] = useState(false);
  const [payForm, setPayForm] = useState({ amount: "", method: "cash", reference: "", notes: "" });
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  const remaining = Math.max(0, Number(invoice.totalAmount) - Number(invoice.paidAmount));

  async function submitPayment(e) {
    e.preventDefault();
    setError("");
    if (!payForm.amount || Number(payForm.amount) <= 0) {
      setError(tr("مبلغ پرداختی باید بزرگ‌تر از صفر باشد"));
      return;
    }
    setSaving(true);
    try {
      await apiRequest(recordPaymentPath, { method: "POST", body: { ...payForm, amount: Number(payForm.amount) } });
      setPaying(false);
      setPayForm({ amount: "", method: "cash", reference: "", notes: "" });
      onChanged && onChanged();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="no-print" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <button className="btn btn-ghost btn-sm" type="button" onClick={onClose}>{tr("← بازگشت به فهرست")}</button>
        <div style={{ display: "flex", gap: 8 }}>
          {canRecordPayment && invoice.status !== "paid" && invoice.status !== "cancelled" && (
            <button className="btn btn-ghost btn-sm" type="button" onClick={() => setPaying((p) => !p)}>
              {paying ? tr("انصراف از ثبت پرداخت") : tr("ثبت پرداخت")}
            </button>
          )}
          <button className="btn btn-primary btn-sm" type="button" onClick={() => window.print()}>{tr("🖨️ چاپ فاکتور")}</button>
        </div>
      </div>

      {canRecordPayment && paying && (
        <form className="login-form inline-edit-form no-print" onSubmit={submitPayment} style={{ marginBottom: 18 }}>
          {error && <div className="form-message error">{error}</div>}
          <p style={{ marginTop: 0 }}>{tr("مبلغ باقیمانده:")}{" "}<strong>{money(remaining)}</strong></p>
          <div className="field-row">
            <div className="field"><label>{tr("مبلغ پرداختی")}</label>
              <input type="number" min="0" step="0.01" value={payForm.amount} onChange={(e) => setPayForm((f) => ({ ...f, amount: e.target.value }))} />
            </div>
            <div className="field"><label>{tr("روش پرداخت")}</label>
              <select value={payForm.method} onChange={(e) => setPayForm((f) => ({ ...f, method: e.target.value }))}>
                {Object.entries(PAYMENT_METHOD_LABEL).map(([k, label]) => <option key={k} value={k}>{label}</option>)}
              </select>
            </div>
            <div className="field"><label>{tr("شماره مرجع (اختیاری)")}</label>
              <input value={payForm.reference} onChange={(e) => setPayForm((f) => ({ ...f, reference: e.target.value }))} />
            </div>
          </div>
          <button className="btn btn-primary" type="submit" disabled={saving}>{saving ? tr("در حال ثبت...") : tr("ثبت پرداخت")}</button>
        </form>
      )}

      {/* برگه‌ی رسمی فاکتور (A4، راست‌به‌چپ) — همه‌ی مقادیر از همان داده‌های فاکتور می‌آید؛
          امضا و «سابقه پرداخت‌ها» عمداً در برگه‌ی فاکتور وجود ندارد. */}
      <div className="invoice-print-sheet inv-sheet" dir={curDir()}>
        <header className="inv-header">
          <div className="inv-brand">
            {settings.logoUrl ? (
              <img className="inv-logo" src={resolvePhotoUrl(settings.logoUrl)} alt="" />
            ) : (
              <svg className="inv-logo inv-logo-mark" viewBox="0 0 64 64" aria-hidden="true">
                <path d="M32 58S6 42 6 22a13 13 0 0 1 26-3 13 13 0 0 1 26 3c0 20-26 36-26 36Z" fill="#1e6fc0" />
                <path d="M28 20h8v8h8v8h-8v8h-8v-8h-8v-8h8v-8Z" fill="#fff" />
              </svg>
            )}
            <div>
              <h2>{settings.hospitalName}</h2>
              <p>{INVOICE_HEADER.tagline}</p>
            </div>
          </div>
          <ul className="inv-contact">
            <li><Icon name="pin" size={16} /><span>{INVOICE_HEADER.address}</span></li>
            <li><Icon name="phone" size={16} /><span dir="ltr">{INVOICE_HEADER.phone}</span></li>
            <li><Icon name="clock" size={16} /><span>{tr("ساعات کاری: {0}", [INVOICE_HEADER.hours])}</span></li>
          </ul>
        </header>

        <table className="inv-layout">
          <tfoot><tr><td className="inv-foot-space" /></tr></tfoot>
          <tbody><tr><td>
            <div className="inv-title"><span><Icon name="file" size={26} /><b>{tr("فاکتور خدمات صحی")}</b></span></div>

            <div className="inv-info">
              <div className="inv-info-people">
                <div className="inv-row"><Icon name="user" /><span>{tr("بیمار:")}</span><b>{invoice.patientName || "—"}</b></div>
                {invoice.doctorName && (
                  <div className="inv-row inv-row-doctor">
                    <Icon name="doctor" /><span>{tr("داکتر معالج:")}</span>
                    <div className="inv-val"><b>{invoice.doctorName}</b>{invoice.department && <small>{invoice.department}</small>}</div>
                  </div>
                )}
                {invoice.patientPhone && (
                  <div className="inv-row"><Icon name="phone" /><span>{tr("شماره تماس:")}</span><b dir="ltr">{invoice.patientPhone}</b></div>
                )}
              </div>
              <div className="inv-info-meta">
                <span className={`inv-status inv-status-${getApprovalStatusKey(invoice)}`}>
                  {getApprovalStatusKey(invoice) === "approved" && <Icon name="check" size={14} />}
                  {INVOICE_STATUS_LABEL[getApprovalStatusKey(invoice)]}
                </span>
                {invoice.createdAt && <div className="inv-row"><Icon name="calendar" /><span>{tr("تاریخ ثبت:")}</span><b>{fmtDate(invoice.createdAt)}</b></div>}
                <div className="inv-row"><Icon name="calendar" /><span>{tr("تاریخ صدور:")}</span><b>{fmtDate(invoice.issueDate)}</b></div>
                {invoice.dueDate && <div className="inv-row"><Icon name="calendar" /><span>{tr("تاریخ سررسید:")}</span><b>{fmtDate(invoice.dueDate)}</b></div>}
                <div className="inv-row"><Icon name="hash" /><span>{tr("شماره فاکتور:")}</span><b dir="ltr">{invoice.invoiceNumber}</b></div>
                {invoice.approvalStatus === "approved" && invoice.approvedByName && (
                  <small className="inv-approved-by">{tr("تاییدشده توسط: {0}", [invoice.approvedByName])}</small>
                )}
              </div>
            </div>

            <div className="inv-table-wrap">
              <table className="inv-table">
                <thead>
                  <tr>
                    <th className="inv-c-desc"><Icon name="steth" size={16} />{tr("شرح")}</th>
                    <th><Icon name="list" size={16} />{tr("تعداد")}</th>
                    <th><Icon name="coins" size={16} />{tr("قیمت واحد")}</th>
                    <th><Icon name="cash" size={16} />{tr("مبلغ")}</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items.map((it) => (
                    <tr key={it.id}>
                      <td className="inv-c-desc">{it.description}</td>
                      <td>{it.quantity}</td>
                      <td>{money(it.unitPrice)}</td>
                      <td>{money(it.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="inv-bottom">
              <div className="inv-totals">
                <div><span><Icon name="coins" />{tr("جمع جزو")}</span><b>{money(invoice.subtotal)}</b></div>
                <div><span><Icon name="percent" />{tr("تخفیف")}</span><b>{money(invoice.discount)}</b></div>
                <div><span><Icon name="receipt" />{tr("مالیات")}</span><b>{money(invoice.tax)}</b></div>
                <div className="inv-grand"><span><Icon name="cash" />{tr("مبلغ کل")}</span><b>{money(invoice.totalAmount)}</b></div>
                <div><span><Icon name="check" />{tr("پرداخت‌شده")}</span><b>{money(invoice.paidAmount)}</b></div>
                <div className={remaining > 0 ? "inv-remaining" : ""}><span>{tr("باقیمانده")}</span><b>{money(remaining)}</b></div>
              </div>
              {invoice.notes && (
                <div className="inv-notes"><span>{tr("یادداشت")}</span><p>{invoice.notes}</p></div>
              )}
            </div>
          </td></tr></tbody>
        </table>

        <footer className="inv-footer">
          <p><b>{settings.hospitalName}</b><i>|</i>{INVOICE_HEADER.address}</p>
          <p>{INVOICE_HEADER.footerWish}</p>
        </footer>
      </div>
    </div>
  );
}

import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

// ============================================================================
// FloatingMenu — منوی بازشوی ⋮ ردیف‌های جدول که هرگز بریده نمی‌شود
// ----------------------------------------------------------------------------
// منوی قبلی با position:absolute داخل سلول جدول رندر می‌شد و کارت/جدول (با
// border-radius و container های glass) آن را می‌برید؛ مثلاً وقتی فقط یک ردیف
// داشتیم، منو از پایین کارت بیرون می‌زد و نصفش دیده نمی‌شد.
// این کامپوننت منو را با Portal مستقیماً زیر document.body و با position:fixed
// می‌گذارد و موقعیتش را با اندازه‌ی واقعی پنجره می‌سنجد:
//   • پایین دکمه جا نبود ← رو به بالا باز می‌شود (یا در بالاترین جای ممکن)
//   • از لبه‌ی راست/چپ بیرون می‌زد ← به داخل جابه‌جا می‌شود
//   • با اسکرول یا تغییر اندازه‌ی پنجره بسته می‌شود تا از دکمه جدا نماند
// باید داخل همان <div className="pm-menu-wrap"> دکمه‌ی ⋮ قرار بگیرد (موقعیت از
// همان والد گرفته می‌شود). بستن با کلیک بیرون/Escape بر عهده‌ی صفحه است و باید
// کلیک روی ".pm-menu" را «بیرون» حساب نکند.
// ============================================================================
export default function FloatingMenu({ onClose, children }) {
  const markerRef = useRef(null);
  const menuRef = useRef(null);
  const [pos, setPos] = useState(null);

  useLayoutEffect(() => {
    const anchor = markerRef.current?.parentElement;
    const menu = menuRef.current;
    if (!anchor || !menu) return;
    const GAP = 8;
    const r = anchor.getBoundingClientRect();
    const mw = menu.offsetWidth;
    const mh = menu.offsetHeight;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    let top = r.bottom + 6;
    if (top + mh > vh - GAP) {
      const up = r.top - 6 - mh;
      top = up >= GAP ? up : Math.max(GAP, vh - GAP - mh);
    }
    let left = r.left; // مثل قبل: لبه‌ی چپ منو هم‌تراز دکمه و باز شدن به سمت راست
    if (left + mw > vw - GAP) left = r.right - mw;
    left = Math.min(Math.max(GAP, left), Math.max(GAP, vw - GAP - mw));
    setPos({ top, left });
  }, []);

  useEffect(() => {
    const close = (e) => {
      if (e && e.type === "scroll" && menuRef.current && menuRef.current.contains(e.target)) return;
      if (onClose) onClose();
    };
    window.addEventListener("resize", close);
    window.addEventListener("scroll", close, true);
    return () => {
      window.removeEventListener("resize", close);
      window.removeEventListener("scroll", close, true);
    };
  }, [onClose]);

  return (
    <>
      <span ref={markerRef} aria-hidden="true" style={{ display: "none" }} />
      {createPortal(
        <div
          ref={menuRef}
          className="pm-menu"
          role="menu"
          style={{
            position: "fixed",
            top: pos ? pos.top : 0,
            left: pos ? pos.left : 0,
            zIndex: 1000,
            visibility: pos ? "visible" : "hidden",
            maxHeight: "calc(100vh - 16px)",
            overflowY: "auto",
          }}
        >
          {children}
        </div>,
        document.body
      )}
    </>
  );
}

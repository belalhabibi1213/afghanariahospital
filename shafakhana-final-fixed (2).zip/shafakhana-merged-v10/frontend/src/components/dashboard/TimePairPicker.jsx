import { useEffect, useRef, useState } from "react";
import { Clock, X, Check } from "lucide-react";
import { isScrollbarClick } from "../../utils/scrollbarClick.js";

import { tr, tdigits } from "../../i18n/tr.js";
// ============================================================================
// TimePairPicker — انتخاب‌گر ساعت ساده و سریع (۲۴ ساعته) برای فرم برنامه کاری
// ----------------------------------------------------------------------------
// جایگزین <input type="time"> مرورگر که ستون‌های AM/PM آن برای انتخاب سخت بود.
//  • دو فیلد (شروع / پایان) کنار هم؛ با کلیک روی هرکدام یک پنل زیر آن‌ها باز می‌شود.
//  • ساعت: شبکه‌ی ۰۰ تا ۲۳ — دقیقه: گام‌های ۵ دقیقه‌ای — چند ساعت پرکاربرد با یک کلیک.
//  • امکان تایپ مستقیم (مثلاً 1430 یا ۱۴:۳۰) هم هست.
//  • مقدار همیشه رشته‌ی "HH:MM" است؛ دقیقاً مثل خروجی قبلی input type=time،
//    پس منطق اعتبارسنجی و ارسال به API بدون تغییر کار می‌کند.
// پنل داخل جریان صفحه (بدون position:absolute) رندر می‌شود تا داخل بدنه‌ی
// اسکرول‌شونده‌ی مودال بریده نشود.
// ============================================================================

const HOURS = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0"));
const MINUTES = Array.from({ length: 12 }, (_, i) => String(i * 5).padStart(2, "0"));
const QUICK = ["06:00", "08:00", "12:00", "14:00", "16:00", "20:00"];

const faDigits = (v) => tdigits(String(v ?? ""));
const enDigits = (v) => String(v ?? "")
  .replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
  .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d));

// ورودی تایپی: "1430" | "14:30" | "930" | "9:5" ... → "HH:MM" یا null
function parseTyped(raw) {
  const s = enDigits(raw).replace(/[^\d:]/g, "");
  let h; let m;
  if (s.includes(":")) {
    const [a, b = ""] = s.split(":");
    if (!a || a.length > 2 || b.length > 2) return null;
    h = Number(a); m = b === "" ? 0 : Number(b.length === 1 ? `${b}0` : b);
  } else if (s.length === 4) { h = Number(s.slice(0, 2)); m = Number(s.slice(2)); }
  else if (s.length === 3) { h = Number(s.slice(0, 1)); m = Number(s.slice(1)); }
  else if (s.length === 1 || s.length === 2) { h = Number(s); m = 0; }
  else return null;
  if (!Number.isInteger(h) || !Number.isInteger(m) || h < 0 || h > 23 || m < 0 || m > 59) return null;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

export default function TimePairPicker({
  startId, endId, startLabel, endLabel, startValue, endValue,
  onStartChange, onEndChange, clearable = false, placeholder = tr("انتخاب ساعت"),
}) {
  const [active, setActive] = useState(null); // "start" | "end" | null
  const [typed, setTyped] = useState("");
  const rootRef = useRef(null);
  const panelRef = useRef(null);

  const value = active === "start" ? startValue : active === "end" ? endValue : "";
  const setValue = (v) => (active === "start" ? onStartChange(v) : onEndChange(v));
  const [curH, curM] = value ? value.split(":") : ["", ""];

  // با تغییر مقدار از بیرون (انتخاب با کلیک)، کادر تایپ هم به‌روز شود
  useEffect(() => { setTyped(value ? faDigits(value) : ""); }, [value, active]);

  // کلیک بیرون از کل کامپوننت پنل را می‌بندد
  useEffect(() => {
    if (!active) return undefined;
    const onDown = (e) => { if (isScrollbarClick(e)) return; if (rootRef.current && !rootRef.current.contains(e.target)) setActive(null); };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [active]);

  // با باز شدن پنل، خودکار تا حدی اسکرول می‌شود که کل پنل (ساعت + دقیقه + تایید) دیده شود
  useEffect(() => {
    if (!active || !panelRef.current) return;
    panelRef.current.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [active]);

  const toggle = (which) => setActive((a) => (a === which ? null : which));
  const pickHour = (h) => setValue(`${h}:${curM || "00"}`);
  const pickMinute = (m) => {
    const hadHour = !!curH;
    setValue(`${curH || "08"}:${m}`);
    if (hadHour) setActive(null); // ساعت قبلاً انتخاب شده بود → با انتخاب دقیقه کار تمام است
  };
  const pickQuick = (q) => { setValue(q); setActive(null); };
  const commitTyped = () => {
    if (!typed.trim()) return;
    const parsed = parseTyped(typed);
    if (parsed) { setValue(parsed); setTyped(faDigits(parsed)); } else setTyped(value ? faDigits(value) : "");
  };

  const field = (which, id, label, val) => (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      <button
        id={id}
        type="button"
        className={`wsch-time-trigger${active === which ? " is-open" : ""}${val ? "" : " is-empty"}`}
        aria-haspopup="dialog"
        aria-expanded={active === which}
        onClick={() => toggle(which)}
      >
        <span className="wsch-time-val">{val ? faDigits(val) : placeholder}</span>
        <Clock size={16} aria-hidden="true" />
      </button>
    </div>
  );

  return (
    <div className="wsch-timepair" ref={rootRef}>
      <div className="field-row">
        {field("start", startId, startLabel, startValue)}
        {field("end", endId, endLabel, endValue)}
      </div>

      {active && (
        <div
          ref={panelRef}
          className="wsch-timepanel"
          role="dialog"
          aria-label={active === "start" ? startLabel : endLabel}
          onKeyDown={(e) => { if (e.key === "Escape") { e.stopPropagation(); setActive(null); } }}
        >
          <div className="wsch-timepanel-head">
            <strong>{active === "start" ? startLabel : endLabel}</strong>
            <input
              className="wsch-time-typed"
              dir="ltr"
              inputMode="numeric"
              autoComplete="off"
              aria-label={tr("تایپ مستقیم ساعت")}
              placeholder={tr("۱۴:۳۰")}
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              onBlur={commitTyped}
              onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); commitTyped(); setActive(null); } }}
            />
          </div>

          <div className="wsch-quick" role="group" aria-label={tr("ساعت‌های پرکاربرد")}>
            {QUICK.map((q) => (
              <button type="button" key={q} className={value === q ? "is-on" : ""} onClick={() => pickQuick(q)}>{faDigits(q)}</button>
            ))}
          </div>

          <div className="wsch-timepanel-label">{tr("ساعت")}</div>
          <div className="wsch-time-grid wsch-hours" role="group" aria-label={tr("ساعت")}>
            {HOURS.map((h) => (
              <button type="button" key={h} aria-pressed={curH === h} className={curH === h ? "is-on" : ""} onClick={() => pickHour(h)}>{faDigits(h)}</button>
            ))}
          </div>

          <div className="wsch-timepanel-label">{tr("دقیقه")}</div>
          <div className="wsch-time-grid wsch-minutes" role="group" aria-label={tr("دقیقه")}>
            {MINUTES.map((m) => (
              <button type="button" key={m} aria-pressed={curM === m} className={curM === m ? "is-on" : ""} onClick={() => pickMinute(m)}>{faDigits(m)}</button>
            ))}
          </div>

          <div className="wsch-timepanel-foot">
            {clearable && value ? (
              <button type="button" className="wsch-time-clear" onClick={() => { setValue(""); setActive(null); }}><X size={13} />{" "}{tr("پاک کردن")}</button>
            ) : <span />}
            <button type="button" className="wsch-time-ok" onClick={() => { commitTyped(); setActive(null); }}><Check size={14} />{" "}{tr("تایید")}</button>
          </div>
        </div>
      )}
    </div>
  );
}

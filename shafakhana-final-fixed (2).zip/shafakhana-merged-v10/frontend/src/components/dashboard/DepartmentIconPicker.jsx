import { useMemo, useState } from "react";
import {
  Stethoscope, HeartPulse, Heart, Brain, Bone, Eye, Ear, Baby, Syringe, Pill, PillBottle,
  Microscope, TestTube, TestTubes, FlaskConical, Activity, Ambulance, Cross, ShieldPlus,
  Hospital, BriefcaseMedical, Thermometer, Bandage, Droplet, Droplets, Dna, Radiation,
  Scan, ScanLine, ScanHeart, Bed, Accessibility, UserRound, ClipboardList, ClipboardPlus,
  ClipboardPen, FileHeart, HeartHandshake, Biohazard, CirclePlus, HandHeart,
  Scissors, BedDouble,
  Search, X,
} from "lucide-react";
import { resolvePhotoUrl } from "../../utils/api.js";

import { tr } from "../../i18n/tr.js";
// مجموعه‌ی منتخب آیکون‌های Lucide برای «مدیریت بخش‌ها» — فقط آیکون‌های مرتبط با حوزه‌ی
// درمانی/پزشکی/بیمارستانی (بدون آیکون‌های عمومی/تزئینی/غیرمرتبط مثل آب‌وهوا، ابزار یا
// وسایل نقلیه). عمداً کل کتابخانه‌ی Lucide (بیش از ۱۷۰۰ آیکون) وارد نمی‌شود تا حجم باندل
// غیرضروری افزایش نیابد؛ در صورت نیاز به آیکون پزشکی بیشتر، همین‌جا اضافه شود.
export const DEPARTMENT_ICONS = {
  Stethoscope, HeartPulse, Heart, Brain, Bone, Eye, Ear, Baby, Syringe, Pill, PillBottle,
  Microscope, TestTube, TestTubes, FlaskConical, Activity, Ambulance, Cross, ShieldPlus,
  Hospital, BriefcaseMedical, Thermometer, Bandage, Droplet, Droplets, Dna, Radiation,
  Scan, ScanLine, ScanHeart, Bed, Accessibility, UserRound, ClipboardList, ClipboardPlus,
  ClipboardPen, FileHeart, HeartHandshake, Biohazard, CirclePlus, HandHeart,
  Scissors, BedDouble,
};

// رندر یک آیکون Lucide از روی نام ذخیره‌شده در دیتابیس (department.icon). اگر نام در
// مجموعه‌ی منتخب بالا نباشد (مثلاً از قبل با نام دیگری ثبت شده)، چیزی رندر نمی‌شود و
// کامپوننت فراخواننده باید یک جایگزین (حرف اول نام بخش و ...) نمایش دهد.
export function DepartmentLucideIcon({ name, size = 18, style }) {
  const IconComp = name ? DEPARTMENT_ICONS[name] : null;
  if (!IconComp) return null;
  return <IconComp size={size} style={style} />;
}

// نمایش آیکون بخش (آپلودی → عکس، Lucide → آیکون برداری، در غیر این صورت حرف اول نام
// بخش به‌عنوان جایگزین). هم در جدول/پیش‌نمایش پنل «مدیریت بخش‌ها» و هم در کارت‌های
// عمومی صفحه‌ی «خدمات ما» استفاده می‌شود تا نمایش آیکون در هر دو جا یکسان بماند.
// رنگ‌بندی (پس‌زمینه/رنگ آیکون) همیشه از تم پیش‌فرض سایت (CSS) گرفته می‌شود؛ هیچ رنگ
// سفارشی‌ای از داده‌ی بخش خوانده یا اعمال نمی‌شود.
export function DepartmentIconThumb({ department, size = 18 }) {
  const iconSrc = department.iconType === "upload" ? resolvePhotoUrl(department.icon) : null;
  return (
    <div className="department-icon-thumb">
      {iconSrc ? (
        <img src={iconSrc} alt={department.name} />
      ) : department.iconType === "lucide" && department.icon ? (
        <DepartmentLucideIcon name={department.icon} size={size} />
      ) : (
        <span className="avatar-fallback">{department.name?.charAt(0) || "🏥"}</span>
      )}
    </div>
  );
}

// انتخاب‌گر بصری آیکون Lucide: پیش‌نمایش آیکون انتخاب‌شده + جستجو + شبکه‌ی آیکون‌های قابل انتخاب
export default function DepartmentIconPicker({ value, onChange }) {
  const [query, setQuery] = useState("");

  const names = useMemo(() => {
    const term = query.trim().toLowerCase();
    const all = Object.keys(DEPARTMENT_ICONS);
    if (!term) return all;
    return all.filter((n) => n.toLowerCase().includes(term));
  }, [query]);

  const SelectedIcon = value ? DEPARTMENT_ICONS[value] : null;

  return (
    <div className="icon-picker">
      <div className="icon-picker-header">
        <div className="icon-picker-preview">
          {SelectedIcon ? <SelectedIcon size={20} /> : <Search size={16} />}
          <span>{value || tr("آیکونی انتخاب نشده")}</span>
          {value && (
            <button
              type="button"
              className="icon-picker-clear"
              onClick={() => onChange("")}
              aria-label={tr("پاک کردن آیکون انتخاب‌شده")}
            >
              <X size={14} />
            </button>
          )}
        </div>
        <div className="icon-picker-search-row">
          <Search size={14} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={tr("جستجوی آیکون... مثلاً Stethoscope")}
          />
        </div>
      </div>
      <div className="icon-picker-grid">
        {names.length === 0 && <p className="icon-picker-empty">{tr("آیکونی با این نام یافت نشد")}</p>}
        {names.map((name) => {
          const IconComp = DEPARTMENT_ICONS[name];
          const active = value === name;
          return (
            <button
              key={name}
              type="button"
              className={`icon-picker-btn${active ? " active" : ""}`}
              onClick={() => onChange(name)}
              title={name}
              aria-label={name}
              aria-pressed={active}
            >
              <IconComp size={18} />
            </button>
          );
        })}
      </div>
    </div>
  );
}

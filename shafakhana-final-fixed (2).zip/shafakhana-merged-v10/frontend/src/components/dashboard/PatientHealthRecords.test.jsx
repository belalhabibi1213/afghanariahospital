import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter, useLocation } from "react-router-dom";

vi.mock("../../utils/api.js", () => ({ apiRequest: vi.fn(), apiDownload: vi.fn(), apiFetchImageUrl: vi.fn(async () => null) }));
import { apiRequest } from "../../utils/api.js";
import PatientHealthRecords from "./PatientHealthRecords.jsx";

const LIST = { records: [
  { id: 1, visitDate: "2026-10-01", visitReason: "درد", diagnosis: "آنژین", doctorName: "صمدی", department: "داخله", released: true, fileCount: 2, sentToPatientAt: "2026-10-02T08:00:00Z" },
  { id: 2, visitDate: "2026-09-01", visitReason: "تب", diagnosis: "", doctorName: "صمدی", department: "داخله", released: false, fileCount: 0, sentToPatientAt: null },
] };
const base = { id: 1, visitDate: "2026-10-01", visitReason: "درد", diagnosis: "آنژین", primaryDiagnosis: "آنژین مشکوک", doctorName: "صمدی", department: "داخله", patientName: "مریض ۱", patientCode: "AAH-000001", pulse: "72" };
function Loc() { return <div data-testid="loc">{useLocation().search}</div>; }
const mount = (route = "/") => render(<MemoryRouter initialEntries={[route]}><PatientHealthRecords /><Loc /></MemoryRouter>);

beforeEach(() => { apiRequest.mockReset(); });

describe("PatientHealthRecords (فقط‌خواندنی)", () => {
  it("فهرست پرونده‌ها با نشان ارسال‌شده/ثبت‌شده؛ بدون دکمه‌ی ساخت/ویرایش/حذف", async () => {
    apiRequest.mockResolvedValue(LIST);
    mount();
    expect(await screen.findByText("آنژین")).toBeInTheDocument();
    expect(screen.getByText("گزارش ارسال‌شده")).toBeInTheDocument();
    expect(screen.getByText("ثبت‌شده")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /افزودن|ویرایش|حذف|ثبت پرونده/ })).not.toBeInTheDocument();
  });

  it("جزئیات ارسال‌شده: توصیه‌ها و پیگیری و توضیح داکتر دیده می‌شود، معاینه‌ی داخلی نه", async () => {
    apiRequest.mockImplementation(async (url) => (url === "/users/health-records" ? LIST : {
      record: { ...base, released: true, sentToPatientAt: "2026-10-02T08:00:00Z", sentNote: "نتایج شما ثبت شد", recommendations: { advice: "استراحت کافی" }, followUpRequired: 1, followUpDate: "2026-11-01", followUpStatus: "pending" },
      labResults: [{ id: 3, testName: "CBC", result: "12", unit: "g/dL", referenceRange: "12-16", status: "completed", testDate: "2026-10-01" }],
      files: [{ id: 9, kind: "document", title: "گزارش رادیولوژی", category: "radiology_report", fileDate: "2026-10-01", originalName: "r.pdf" }],
    }));
    mount();
    await userEvent.click(await screen.findByText("آنژین"));
    expect(await screen.findByText("استراحت کافی")).toBeInTheDocument();
    expect(screen.getByText("نتایج شما ثبت شد")).toBeInTheDocument();
    expect(screen.getByText("CBC")).toBeInTheDocument();
    expect(screen.getByText("گزارش رادیولوژی")).toBeInTheDocument();
    expect(screen.queryByText("معاینه پزشکی")).not.toBeInTheDocument();
    expect(screen.queryByText("سایر توضیحات پزشکی")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /ویرایش|حذف|ثبت/ })).not.toBeInTheDocument();
    expect(apiRequest).toHaveBeenCalledWith("/users/health-records/1");
  });

  it("پرونده‌ی ارسال‌نشده: بخش‌های توصیه/پیگیری/فایل مخفی و پیام توضیحی نشان داده می‌شود", async () => {
    apiRequest.mockImplementation(async (url) => (url === "/users/health-records" ? LIST : { record: { ...base, id: 2, released: false }, labResults: [], files: [] }));
    mount();
    await userEvent.click(await screen.findByText("تب"));
    expect(await screen.findByText(/پس از ارسال گزارش توسط داکتر/)).toBeInTheDocument();
    expect(screen.queryByText("توصیه‌های پزشکی")).not.toBeInTheDocument();
    expect(screen.queryByText("پیگیری (Follow-up)")).not.toBeInTheDocument();
  });

  it("لینک اعلان (?highlight=) پرونده را یک‌بار باز و پارامتر را پاک می‌کند", async () => {
    apiRequest.mockImplementation(async (url) => (url === "/users/health-records" ? LIST : { record: { ...base, released: true, recommendations: {} }, labResults: [], files: [] }));
    mount("/d?tab=healthRecords&highlight=1");
    expect(await screen.findByText("پرونده صحی")).toBeInTheDocument();
    await waitFor(() => expect(screen.getByTestId("loc").textContent).toBe("?tab=healthRecords"));
  });

  it("خطای شبکه پیام خطا نشان می‌دهد", async () => {
    apiRequest.mockRejectedValue(new Error("خطای سرور"));
    mount();
    expect(await screen.findByText("خطای سرور")).toBeInTheDocument();
  });
});

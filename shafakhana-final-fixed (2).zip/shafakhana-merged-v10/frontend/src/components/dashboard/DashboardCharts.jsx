
import { tr } from "../../i18n/tr.js";// نمودارهای سبک و بدون وابستگی خارجی (SVG خالص) برای داشبورد آنالیتیکس.
// چون این پروژه هیچ کتابخانه نموداری از قبل نصب نداشت، به‌جای افزودن یک
// وابستگی جدید (که ریسک نصب/باندل را بالا می‌برد)، این کامپوننت‌های ساده و
// واکنش‌گرا (responsive) با SVG ساخته شده‌اند و از رنگ‌های تم موجود پروژه استفاده می‌کنند.

const AXIS_COLOR = "rgba(183, 205, 209, 0.35)"; // var(--text-2) با شفافیت کم

// نمودار میله‌ای ساده — برای روند ماهانه نوبت‌ها
// data: [{ label: string, count: number }]
export function BarChart({ data, color = "var(--pulse)", height = 220 }) {
  const width = 600; // فقط برای محاسبه مقیاس؛ با viewBox واکنش‌گرا می‌شود
  const paddingX = 28;
  const paddingBottom = 34;
  const paddingTop = 16;
  const max = Math.max(1, ...data.map((d) => d.count));
  const chartHeight = height - paddingBottom - paddingTop;
  const barSlot = (width - paddingX * 2) / Math.max(1, data.length);
  const barWidth = Math.min(42, barSlot * 0.55);

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="chart-svg"
      role="img"
      aria-label={tr("نمودار روند ماهانه نوبت‌ها")}
      preserveAspectRatio="xMidYMid meet"
    >
      {/* خط پایه محور افقی */}
      <line
        x1={paddingX}
        y1={height - paddingBottom}
        x2={width - paddingX}
        y2={height - paddingBottom}
        stroke={AXIS_COLOR}
        strokeWidth="1"
      />

      {data.map((d, i) => {
        const barHeight = max === 0 ? 0 : (d.count / max) * chartHeight;
        const x = paddingX + i * barSlot + (barSlot - barWidth) / 2;
        const y = height - paddingBottom - barHeight;
        return (
          <g key={d.label}>
            <rect
              x={x}
              y={y}
              width={barWidth}
              height={barHeight}
              rx={6}
              fill={color}
              opacity={0.9}
            >
              <title>{`${d.label}: ${d.count}`}</title>
            </rect>
            {d.count > 0 && (
              <text
                x={x + barWidth / 2}
                y={y - 8}
                textAnchor="middle"
                fontSize="13"
                fill="#f1f8f7"
              >
                {d.count}
              </text>
            )}
            <text
              x={x + barWidth / 2}
              y={height - paddingBottom + 18}
              textAnchor="middle"
              fontSize="11"
              fill="#7f9aa0"
            >
              {d.label}
            </text>
          </g>
        );
      })}
    </svg>
  );
}

// نمودار دونات (Donut) ساده — برای توزیع وضعیت نوبت‌ها
// data: [{ label: string, value: number, color: string }]
export function DonutChart({ data, size = 200, thickness = 26 }) {
  const total = data.reduce((sum, d) => sum + d.value, 0);
  const radius = size / 2 - thickness / 2;
  const circumference = 2 * Math.PI * radius;
  let cumulative = 0;

  return (
    <div className="donut-chart-wrap">
      <svg
        viewBox={`0 0 ${size} ${size}`}
        className="chart-svg donut-svg"
        role="img"
        aria-label={tr("نمودار توزیع وضعیت نوبت‌ها")}
      >
        <g transform={`rotate(-90 ${size / 2} ${size / 2})`}>
          {total === 0 ? (
            <circle
              cx={size / 2}
              cy={size / 2}
              r={radius}
              fill="none"
              stroke={AXIS_COLOR}
              strokeWidth={thickness}
            />
          ) : (
            data.map((d) => {
              const fraction = d.value / total;
              const dash = fraction * circumference;
              const gap = circumference - dash;
              const offset = -((cumulative / total) * circumference);
              cumulative += d.value;
              if (d.value === 0) return null;
              return (
                <circle
                  key={d.label}
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  fill="none"
                  stroke={d.color}
                  strokeWidth={thickness}
                  strokeDasharray={`${dash} ${gap}`}
                  strokeDashoffset={offset}
                >
                  <title>{`${d.label}: ${d.value}`}</title>
                </circle>
              );
            })
          )}
        </g>
        <text
          x={size / 2}
          y={size / 2 - 4}
          textAnchor="middle"
          fontSize="22"
          fontWeight="700"
          fill="#f1f8f7"
        >
          {total}
        </text>
        <text
          x={size / 2}
          y={size / 2 + 16}
          textAnchor="middle"
          fontSize="11"
          fill="#7f9aa0"
        >{tr("مجموع")}</text>
      </svg>

      <ul className="chart-legend">
        {data.map((d) => (
          <li key={d.label}>
            <span className="legend-dot" style={{ background: d.color }} />
            {d.label}
            <b>{d.value}</b>
          </li>
        ))}
      </ul>
    </div>
  );
}

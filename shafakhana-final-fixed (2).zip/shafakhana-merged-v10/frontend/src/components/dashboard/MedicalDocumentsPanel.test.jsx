import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";

vi.mock("../../utils/api.js", () => ({ apiRequest: vi.fn(), apiDownload: vi.fn() }));
import { apiRequest, apiDownload } from "../../utils/api.js";
import MedicalDocumentsPanel from "./MedicalDocumentsPanel.jsx";

const STATS = { patients: 4892, record: 856, prescription: 1203, lab: 40, imaging: 482, total: 2581 };
const row = (docType, id, extra = {}) => ({
  docType, id, patientId: 7, doctorId: 3, docDate: "2026-10-01T09:30:00Z", status: docType === "prescription" ? "active" : "registered",
  docNumber: `${{ prescription: "RX", record: "MR", lab: "LAB", imaging: "IMG" }[docType]}-00000${id}`, title: "عنوان",
  patientName: `مریض ${docType}`, patientCode: "AAH-000007", patientPhone: "0791", doctorName: "داکتر الف", canDownload: false, ...extra,
});
const LIST = {
  documents: [row("prescription", 1, { canDownload: true }), row("record", 2), row("lab", 3, { status: "completed" }), row("imaging", 4)],
  pagination: { total: 2581, page: 1, limit: 10, totalPages: 259 },
};

function setup(role = "admin", { detail } = {}) {
  apiRequest.mockImplementation(async (url) => {
    if (url.endsWith("/stats")) return { stats: STATS };
    if (url === "/admin/doctors") return { doctors: [{ id: 3, fullName: "داکتر الف" }] };
    if (/medical-documents\/\w+\/\d+$/.test(url)) return detail;
    return LIST;
  });
  return render(<MedicalDocumentsPanel role={role} />);
}
const listCalls = () => apiRequest.mock.calls.map((c) => c[0]).filter((u) => /medical-documents\?/.test(u));

beforeEach(() => { apiRequest.mockReset(); apiDownload.mockReset(); });

describe("MedicalDocumentsPanel (نسخه و سوابق طبی)", () => {
  it("آمار، چهار نوع سند و شمار کل رکوردها را نشان می‌دهد؛ فقط یک صفحه از سرور خواسته می‌شود", async () => {
    setup();
    expect(await screen.findByText("مریض prescription")).toBeInTheDocument();
    for (const t of ["مریض record", "مریض lab", "مریض imaging"]) expect(screen.getByText(t)).toBeInTheDocument();
    expect(screen.getByText("۴٬۸۹۲")).toBeInTheDocument();
    expect(screen.getByText(/نمایش ۱ تا ۱۰ از ۲٬۵۸۱ رکورد/)).toBeInTheDocument();
    expect(listCalls()[0]).toContain("/admin/medical-documents?");
    expect(listCalls()[0]).toContain("limit=10");
  });

  it("دکمه‌ی چاپ/دانلود فقط برای ردیفی که canDownload دارد نمایش داده می‌شود", async () => {
    setup();
    await screen.findByText("مریض prescription");
    expect(screen.getAllByRole("button", { name: "چاپ" })).toHaveLength(1);
    expect(screen.getAllByRole("button", { name: "دریافت فایل" })).toHaveLength(1);
  });

  it("مرتب‌سازی، فیلتر نوع و تعداد در صفحه، همگی از سرور می‌خواهند و به صفحه‌ی اول برمی‌گردند", async () => {
    const user = userEvent.setup();
    setup();
    await screen.findByText("مریض prescription");
    await user.click(screen.getByRole("button", { name: /مرتب‌سازی بر اساس نام مریض/ }));
    await waitFor(() => expect(listCalls().at(-1)).toContain("sort=patient&order=asc"));
    await user.selectOptions(screen.getByLabelText("نوع سند"), "lab");
    await waitFor(() => expect(listCalls().at(-1)).toContain("type=lab"));
    await user.selectOptions(screen.getByLabelText("تعداد در صفحه"), "50");
    await waitFor(() => expect(listCalls().at(-1)).toContain("limit=50"));
    expect(listCalls().at(-1)).toContain("page=1");
  });

  it("جستجو با تأخیر (debounce) به سرور می‌رود", async () => {
    const user = userEvent.setup();
    setup();
    await screen.findByText("مریض prescription");
    await user.type(screen.getByLabelText("جستجوی اسناد طبی"), "AAH-000007");
    await waitFor(() => expect(listCalls().at(-1)).toContain("q=AAH-000007"));
  });

  it("فیلتر داکتر فقط برای ادمین است و در داکتر نه فهرست داکتران خوانده می‌شود نه پارامتر می‌رود", async () => {
    setup("doctor");
    await screen.findByText("مریض prescription");
    expect(screen.queryByLabelText("داکتر")).not.toBeInTheDocument();
    expect(apiRequest.mock.calls.some((c) => c[0] === "/admin/doctors")).toBe(false);
    expect(listCalls()[0]).toContain("/doctors/me/medical-documents?");
  });

  it("خطای سرور حالت خطا با «تلاش دوباره» نشان می‌دهد و حالت بدون نتیجه پیام مناسب", async () => {
    apiRequest.mockImplementation(async (url) => {
      if (url.endsWith("/stats")) return { stats: STATS };
      if (url === "/admin/doctors") return { doctors: [] };
      throw new Error("خطای سرور");
    });
    const { unmount } = render(<MedicalDocumentsPanel role="admin" />);
    expect(await screen.findByText("بارگذاری اسناد ناموفق بود")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "تلاش دوباره" })).toBeInTheDocument();
    unmount();

    apiRequest.mockReset();
    apiRequest.mockImplementation(async (url) => (url.endsWith("/stats") ? { stats: STATS } : url === "/admin/doctors" ? { doctors: [] } : { documents: [], pagination: { total: 0, page: 1, limit: 10, totalPages: 1 } }));
    render(<MedicalDocumentsPanel role="admin" />);
    expect(await screen.findByText("هنوز سندی ثبت نشده است")).toBeInTheDocument();
  });

  it("پنل جزئیات نسخه را با داروها نشان می‌دهد و دکمه‌های مجاز را از permissions می‌گیرد", async () => {
    const user = userEvent.setup();
    const detail = {
      document: {
        type: "prescription", id: 1, docNumber: "RX-000001", status: "active", createdAt: "2026-10-01T09:30:00Z",
        patient: { fullName: "احمد کریمی", publicCode: "AAH-000007", phone: "0791", gender: "male", dateOfBirth: "1980-01-01" },
        doctor: { name: "داکتر الف", department: "داخلی" }, diagnosis: "عفونت",
        items: [{ id: 1, medicationName: "آموکسی‌سیلین", dosage: "500mg", quantity: "21 عدد", duration: "۷ روز" }],
      },
      permissions: { pdf: true, labReport: false, files: false, canEdit: false },
    };
    setup("admin", { detail });
    const rowEl = (await screen.findByText("مریض prescription")).closest("tr");
    await user.click(within(rowEl).getByRole("button", { name: "مشاهده جزئیات" }));
    const panel = await screen.findByLabelText("جزئیات سند");
    expect(await within(panel).findByText("آموکسی‌سیلین")).toBeInTheDocument();
    expect(within(panel).getByText("عفونت")).toBeInTheDocument();
    expect(within(panel).getByRole("button", { name: /چاپ/ })).toBeInTheDocument();
    // ادمین برای نسخه‌ی در حال اجرا گزینه‌های «تکمیل‌شده» و «لغو» را دارد، «در حال اجرا» را نه
    expect(within(panel).getByRole("button", { name: /تکمیل‌شده/ })).toBeInTheDocument();
    expect(within(panel).queryByRole("button", { name: /در حال اجرا/ })).not.toBeInTheDocument();
    await user.click(within(panel).getByRole("button", { name: /چاپ/ }));
    expect(apiDownload).toHaveBeenCalledWith("/medical-records/prescriptions/1/pdf", "prescription-1.pdf", { print: true });
  });

  it("برای سند بدون مجوز دانلود (permissions خالی) در پنل هیچ دکمه‌ی چاپ/دریافتی نیست", async () => {
    const user = userEvent.setup();
    const detail = {
      document: {
        type: "lab", id: 3, docNumber: "LAB-000003", status: "completed", createdAt: "2026-10-01T09:30:00Z",
        patient: { fullName: "زهرا" }, doctor: { name: "داکتر ب" }, testName: "CBC", result: "12", unit: "g/dL", hasReport: true,
      },
      permissions: { pdf: false, labReport: false, files: false, canEdit: false },
    };
    setup("doctor", { detail });
    const rowEl = (await screen.findByText("مریض lab")).closest("tr");
    await user.click(within(rowEl).getByRole("button", { name: "مشاهده جزئیات" }));
    const panel = await screen.findByLabelText("جزئیات سند");
    expect(await within(panel).findByText("CBC")).toBeInTheDocument();
    expect(within(panel).queryByRole("button", { name: /چاپ|PDF|دریافت/ })).not.toBeInTheDocument();
  });
});

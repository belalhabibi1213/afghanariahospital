import { useEffect, useRef, useState } from "react";
import { Play, Pause, Loader2 } from "lucide-react";
import { apiFetchImageUrl } from "../../utils/api.js";

import { tr } from "../../i18n/tr.js";
// ---------- پخش‌کننده‌ی پیام صوتی چت (بیمار ↔ داکتر) ----------
// همان الگوی امنیتیِ ChatAttachment.jsx: فایل صوتی هرگز با یک <audio src="..."> مستقیم به
// آدرس API بارگذاری نمی‌شود (چون نیاز به نشست (کوکی) دارد و مسیر واقعی سرور هم نباید
// به کلاینت درز کند)؛ به‌جای آن با fetch احرازهویت‌شده گرفته و به یک Blob URL موقتِ
// درون‌حافظه‌ای تبدیل می‌شود. دسترسی امن (فقط طرفینِ همان مکالمه) در بک‌اند بررسی می‌شود
// (backend/controllers/chatController.js → downloadMessageAttachment).

function formatDuration(totalSeconds) {
  if (!Number.isFinite(totalSeconds) || totalSeconds < 0) return "٠٠:٠٠";
  const s = Math.round(totalSeconds);
  const m = Math.floor(s / 60).toString().padStart(2, "0");
  const sec = (s % 60).toString().padStart(2, "0");
  return `${m}:${sec}`;
}

export default function VoiceMessagePlayer({ conversationId, message }) {
  const attachmentPath = `/chat/conversations/${conversationId}/messages/${message.id}/attachment`;
  const audioRef = useRef(null);

  const [audioUrl, setAudioUrl] = useState(null);
  const [loadFailed, setLoadFailed] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  // مدت‌زمانِ ثبت‌شده در دیتابیس (هنگام ارسال، توسط مرورگرِ فرستنده محاسبه شده) به‌عنوان
  // مقدار اولیه/جایگزین استفاده می‌شود، چون فایل‌های webm در برخی مرورگرها متادیتای
  // duration را تا پخش کامل گزارش نمی‌دهند (Infinity)
  const [duration, setDuration] = useState(message.attachmentDurationSeconds || 0);

  useEffect(() => {
    let cancelled = false;
    let createdUrl = null;

    apiFetchImageUrl(attachmentPath)
      .then((url) => {
        if (cancelled) return;
        if (!url) {
          setLoadFailed(true);
          return;
        }
        createdUrl = url;
        setAudioUrl(url);
      })
      .catch(() => {
        if (!cancelled) setLoadFailed(true);
      });

    return () => {
      cancelled = true;
      if (createdUrl) URL.revokeObjectURL(createdUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attachmentPath]);

  function togglePlay() {
    const audio = audioRef.current;
    if (!audio) return;
    if (isPlaying) {
      audio.pause();
    } else {
      audio.play().catch(() => {});
    }
  }

  function handleSeek(e) {
    const audio = audioRef.current;
    const value = Number(e.target.value);
    setCurrentTime(value);
    if (audio) audio.currentTime = value;
  }

  const effectiveDuration = duration || message.attachmentDurationSeconds || 0;
  const progressPercent = effectiveDuration > 0 ? Math.min(100, (currentTime / effectiveDuration) * 100) : 0;

  return (
    <div className="chat-voice-player">
      <button
        type="button"
        className="chat-voice-play-btn"
        onClick={togglePlay}
        disabled={!audioUrl}
        title={isPlaying ? tr("توقف پخش") : tr("پخش پیام صوتی")}
      >
        {!audioUrl && !loadFailed ? (
          <Loader2 size={16} className="chat-attachment-spin" />
        ) : isPlaying ? (
          <Pause size={16} />
        ) : (
          <Play size={16} />
        )}
      </button>

      <div className="chat-voice-player-body">
        <input
          type="range"
          className="chat-voice-progress"
          min={0}
          max={effectiveDuration || 0}
          step={0.1}
          value={Math.min(currentTime, effectiveDuration || 0)}
          onChange={handleSeek}
          disabled={!audioUrl}
          style={{ "--voice-progress": `${progressPercent}%` }}
          aria-label={tr("پیشرفت پخش پیام صوتی")}
        />
        <span className="chat-voice-duration">
          {loadFailed ? tr("پیام صوتی در دسترس نیست") : formatDuration(currentTime > 0 ? currentTime : effectiveDuration)}
        </span>
      </div>

      {audioUrl && (
        <audio
          ref={audioRef}
          src={audioUrl}
          preload="metadata"
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onEnded={() => {
            setIsPlaying(false);
            setCurrentTime(0);
          }}
          onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
          onLoadedMetadata={(e) => {
            const d = e.currentTarget.duration;
            if (Number.isFinite(d) && d > 0) setDuration(d);
          }}
        />
      )}
    </div>
  );
}

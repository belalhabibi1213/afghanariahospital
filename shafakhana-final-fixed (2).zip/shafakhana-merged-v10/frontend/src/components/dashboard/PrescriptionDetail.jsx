import { useState } from "react";
import { apiDownload, resolvePhotoUrl } from "../../utils/api.js";
import { useSiteSettings } from "../../context/SettingsContext.jsx";

import { tr, jdate, curDir } from "../../i18n/tr.js";
// نمای جزئیات یک نسخه، همراه با دکمه‌ی چاپ نسخه (پیش‌نمایش صفحه) و دانلود PDF واقعی
// (الزام: چاپ نسخه توسط بیمار/داکتر + تولید PDF حرفه‌ای). این کامپوننت هم در داشبورد
// بیمار و هم در داشبورد داکتر استفاده می‌شود؛ فقط مسیر endpoint دانلود PDF (pdfPath)
// بین این دو فرق دارد چون مالکیت/دسترسی هرکدام سمت بک‌اند جدا بررسی می‌شود.
// دکمه‌ی چاپ صفحه‌ای از الگوی InvoiceDetail.jsx (چاپ فاکتور) پیروی می‌کند:
// window.print() + کلاس no-print برای پنهان‌کردن رابط کاربری هنگام چاپ.
export default function PrescriptionDetail({ prescription: pr, patientName, patientPhone, pdfPath, onClose }) {
  const { settings } = useSiteSettings();
  const [pdfError, setPdfError] = useState("");
  const [downloadingPdf, setDownloadingPdf] = useState(false);

  async function handleDownloadPdf() {
    if (!pdfPath) return;
    setPdfError("");
    setDownloadingPdf(true);
    try {
      await apiDownload(pdfPath, `prescription-${pr.id}.pdf`, { openInNewTab: true });
    } catch (err) {
      setPdfError(err.message);
    } finally {
      setDownloadingPdf(false);
    }
  }

  return (
    <div>
      <div className="no-print" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <button className="btn btn-ghost btn-sm" type="button" onClick={onClose}>{tr("← بازگشت به فهرست")}</button>
        <div style={{ display: "flex", gap: 8 }}>
          {pdfPath && (
            <button className="btn btn-primary btn-sm" type="button" onClick={handleDownloadPdf} disabled={downloadingPdf}>
              {downloadingPdf ? tr("در حال آماده‌سازی...") : tr("📄 دانلود / چاپ PDF")}
            </button>
          )}
          <button className="btn btn-ghost btn-sm" type="button" onClick={() => window.print()}>{tr("🖨️ چاپ این صفحه")}</button>
        </div>
      </div>

      {pdfError && <div className="no-print form-message error">{pdfError}</div>}

      {/* برگه‌ی رسمی نسخه (A4) — همه‌ی مقادیر از همان داده‌های نسخه و تنظیمات سیستم می‌آیند */}
      <div className="prescription-print-sheet rx-sheet" dir={curDir()}>
        <header className="rx-header">
          {settings.logoUrl ? <img className="rx-logo" src={resolvePhotoUrl(settings.logoUrl)} alt="" /> : null}
          <div className="rx-header-text">
            <h2>{settings.hospitalName}</h2>
            <p dir="ltr">Afghan Arya Hospital</p>
          </div>
        </header>

        <table className="rx-layout">
          <tfoot><tr><td className="rx-foot-space" /></tr></tfoot>
          <tbody><tr><td>
            <div className="rx-title"><span><b>{tr("نسخه طبی")}</b><small>Prescription Medical</small></span></div>

            <div className="rx-card">
              <div className="rx-col">
                <h4>{tr("اطلاعات داکتر")}</h4>
                <div className="rx-field"><span>{tr("نام داکتر (Doctor Name)")}</span><b>{pr.doctorName || "—"}</b></div>
                <div className="rx-field"><span>{tr("شناسه داکتر (Doctor ID)")}</span><b>{pr.doctorCode || (pr.doctorId ? `#${pr.doctorId}` : "—")}</b></div>
              </div>
              <div className="rx-col">
                <h4>{tr("اطلاعات مریض")}</h4>
                <div className="rx-field"><span>{tr("نام مریض (Patient Name)")}</span><b>{patientName || pr.patientName || "—"}</b></div>
                <div className="rx-field"><span>{tr("شناسه مریض (Patient ID)")}</span><b>{pr.patientId ? `#${pr.patientId}` : "—"}</b></div>
                <div className="rx-field"><span>{tr("تاریخ صدور")}</span><b>{jdate(pr.createdAt)}</b></div>
              </div>
            </div>

            {pr.diagnosis && (
              <div className="rx-box rx-diagnosis">
                <span>{tr("تشخیص (Diagnosis)")}</span>
                <b>{pr.diagnosis}</b>
              </div>
            )}

            <div className="rx-symbol">Rx</div>
            {/* نسخه‌ی چنددارویی: pr.medicines همه‌ی داروهای همین نسخه است */}
            {(() => {
              const meds = pr.medicines && pr.medicines.length > 1 ? pr.medicines : [pr];
              const hasFrequency = meds.some((m) => m.frequency);
              return (
                <table className="rx-table">
                  <thead>
                    <tr>
                      <th className="rx-c-idx">#</th>
                      <th className="rx-c-name">{tr("نام دارو")}<small>(Medicine Name)</small></th>
                      <th>{tr("دوز")}<small>(Dosage)</small></th>
                      {hasFrequency && <th>{tr("تکرار")}<small>(Frequency)</small></th>}
                      <th>{tr("مدت مصرف")}<small>(Duration)</small></th>
                    </tr>
                  </thead>
                  <tbody>
                    {meds.map((m, i) => (
                      <tr key={m.id ?? i}>
                        <td className="rx-c-idx">{i + 1}</td>
                        <td className="rx-c-name"><b>{m.medicationName}</b></td>
                        <td>{m.dosage || "—"}</td>
                        {hasFrequency && <td>{m.frequency || "—"}</td>}
                        <td>{m.duration || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              );
            })()}

            {pr.instructions && (
              <div className="rx-box"><span>{tr("دستورالعمل (Instructions)")}</span><p>{pr.instructions}</p></div>
            )}
            {pr.followUpDate && (
              <div className="rx-box"><span>{tr("تاریخ پیگیری (Follow-up)")}</span><p>{jdate(pr.followUpDate)}</p></div>
            )}
            {pr.notes && (
              <div className="rx-box"><span>{tr("یادداشت (Notes)")}</span><p>{pr.notes}</p></div>
            )}

            {/* فقط جای خالی برای امضا و مهر فیزیکی داکتر — هیچ امضا/مهر ساختگی چاپ نمی‌شود */}
            <div className="rx-signature">
              <b>{tr("امضا و مهر داکتر")}</b>
              <small>Doctor Signature &amp; Stamp</small>
              <div className="rx-signature-space" />
              {pr.doctorName && <span>{pr.doctorName}</span>}
            </div>
          </td></tr></tbody>
        </table>

        <footer className="rx-footer">
          <p>{tr("آدرس: {0}", [settings.hospitalAddress || tr("هرات، جاده قوماندانی")])}{settings.hospitalPhone ? <>{tr("{0}تلفن:", ["  |  "])}{" "}<span dir="ltr">{settings.hospitalPhone}</span></> : null}
          </p>
          <p>{tr("این نسخه به صورت الکترونیکی از سامانه {0} صادر شده است.", [settings.hospitalName])}</p>
          <p>{tr("تاریخ صدور: {0}", [jdate(pr.createdAt)])}</p>
        </footer>
      </div>
    </div>
  );
}

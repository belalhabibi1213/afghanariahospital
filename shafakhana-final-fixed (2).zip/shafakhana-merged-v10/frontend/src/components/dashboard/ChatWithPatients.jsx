import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Send, User, Check, CheckCheck, Pencil, Trash2, X, SmilePlus, Paperclip, Loader2, MoreVertical, Phone, Video } from "lucide-react";
import { apiRequest, apiUpload } from "../../utils/api.js";
import GlobalModal from "../GlobalModal.jsx";
import ChatAttachment from "./ChatAttachment.jsx";
import VoiceMessagePlayer from "./VoiceMessagePlayer.jsx";
import VoiceRecorderBar from "./VoiceRecorderBar.jsx";
import useVoiceRecorder, { voiceFileExtension } from "../../hooks/useVoiceRecorder.js";
import useVoiceCall from "../../hooks/useVoiceCall.js";
import VoiceCallPanel from "./VoiceCallPanel.jsx";
import { isScrollbarClick } from "../../utils/scrollbarClick.js";
import { tr, numLocale } from "../../i18n/tr.js";
import { isChatSocketConnected, onChatNew } from "../../utils/chatRealtime.js";

// ---------- پیام‌های بیماران (Chat with Patients) — داشبورد داکتر ----------
// این کامپوننت فقط رابط کاربری (UI) است و به APIهای موجود چت (backend/routes/chat.js)
// وصل می‌شود (همان API که در گفتگوی بیمار با داکتر استفاده شده). کنترل دسترسی واقعی
// (اینکه داکتر فقط با بیمارانِ خودش گفتگو کند) در بک‌اند انجام می‌شود (doctorHasPatient)؛
// اینجا فقط فهرست بیمارانی که حداقل یک نوبت با این داکتر دارند ساخته می‌شود.

const POLL_INTERVAL_MS = 8000; // فاصله‌ی polling پشتیبان (push اصلی از Socket.IO می‌آید)

// زمان یک پیام را به‌صورت ساعت:دقیقه فارسی نمایش می‌دهد
function formatMessageTime(dateStr) {
  return new Date(dateStr).toLocaleTimeString(numLocale(), { hour: "2-digit", minute: "2-digit" });
}

// جداکننده‌ی روز بین پیام‌ها (امروز / دیروز / تاریخ کامل)
function formatDayDivider(dateStr) {
  const d = new Date(dateStr);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);
  const sameDay = (a, b) => a.toDateString() === b.toDateString();
  if (sameDay(d, today)) return tr("امروز");
  if (sameDay(d, yesterday)) return tr("دیروز");
  return d.toLocaleDateString(numLocale());
}

function initials(name) {
  if (!name) return tr("ب");
  return name.trim().charAt(0);
}

// مجموعه‌ی ثابت واکنش‌های ایموجی مجاز — باید با ALLOWED_MESSAGE_REACTIONS در بک‌اند
// (backend/middleware/formValidators.js) هماهنگ باشد
const MESSAGE_REACTIONS = ["👍", "❤️", "😂", "😮", "😢", "😡"];

// فرمت‌های مجاز پیوست چت — باید با ALLOWED_CHAT_ATTACHMENT_MIME_TO_EXT در بک‌اند
// (backend/middleware/upload.js) هماهنگ باشد. این فقط یک بررسی سریع سمت کلاینت است؛
// اعتبارسنجی واقعی (پسوند/نوع/حجم/محتوای فایل) در بک‌اند انجام می‌شود.
const ALLOWED_ATTACHMENT_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp", ".pdf", ".doc", ".docx", ".xls", ".xlsx"];
const ALLOWED_ATTACHMENT_ACCEPT =
  ".jpg,.jpeg,.png,.webp,.pdf,.doc,.docx,.xls,.xlsx,image/jpeg,image/png,image/webp,application/pdf," +
  "application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document," +
  "application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
const MAX_ATTACHMENT_SIZE = 15 * 1024 * 1024; // ۱۵ مگابایت — هماهنگ با محدودیت بک‌اند

export default function ChatWithPatients() {
  // شناسه‌ی مکالمه‌ای که باید طبق دیپ‌لینکِ اعلان (کلیک روی «پیام جدید») به‌صورت
  // خودکار باز شود: /dashboard/doctor?tab=chat&highlight=CONVERSATION_ID
  const [searchParams] = useSearchParams();
  const highlightConversationId = searchParams.get("highlight");

  const [patients, setPatients] = useState([]); // فهرست بیمارانِ مجاز، همراه با آخرین پیام/تعداد نخوانده
  const [loadingPatients, setLoadingPatients] = useState(true);
  const [listError, setListError] = useState("");

  const [selectedPatientId, setSelectedPatientId] = useState(null);
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [loadingOlder, setLoadingOlder] = useState(false);
  const [messagesError, setMessagesError] = useState("");

  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState("");

  // ---------- ویرایش/حذف پیام‌های خودِ داکتر ----------
  const [editingMessageId, setEditingMessageId] = useState(null);
  const [editDraft, setEditDraft] = useState("");
  const [editSaving, setEditSaving] = useState(false);
  const [editError, setEditError] = useState("");
  const [deletingMessageId, setDeletingMessageId] = useState(null);

  // ---------- منوی کنش‌های پیام (ویرایش/حذف/واکنش) ----------
  const [openMenuMessageId, setOpenMenuMessageId] = useState(null);

  // ---------- واکنش ایموجی به پیام‌ها ----------
  const [reactionPickerMessageId, setReactionPickerMessageId] = useState(null);
  const [reactingMessageId, setReactingMessageId] = useState(null);

  // ---------- پیوست عکس/سند ----------
  const [attachmentSending, setAttachmentSending] = useState(false);
  const attachmentInputRef = useRef(null);
  // فایل انتخاب‌شده که هنوز ارسال نشده و منتظر تایید/لغو کاربر در پنجره‌ی پیش‌نمایش است
  const [pendingAttachment, setPendingAttachment] = useState(null); // { file, previewUrl, isImage }

  // ---------- پیام صوتی ----------
  const voiceRecorder = useVoiceRecorder();
  const [voiceSending, setVoiceSending] = useState(false);

  const [showThreadOnMobile, setShowThreadOnMobile] = useState(false);

  // ---------- تماسِ صوتی ----------
  const voiceCall = useVoiceCall();

  const messagesEndRef = useRef(null);
  const pollTimerRef = useRef(null);

  // ---------- بارگذاری اولیه: بیماران این داکتر (برای فهرست بیمارانِ مجاز) + مکالمه‌های موجود ----------
  useEffect(() => {
    let cancelled = false;

    async function loadPatientList() {
      setLoadingPatients(true);
      setListError("");
      try {
        const [patientsData, conversationsData] = await Promise.all([
          apiRequest("/doctors/me/patients?limit=100"),
          apiRequest("/chat/conversations"),
        ]);
        if (cancelled) return;

        const patientRows = patientsData.patients || [];
        const conversations = conversationsData.conversations || [];
        const conversationByPatientId = new Map(conversations.map((c) => [c.patientId, c]));

        // فهرست یکتای بیمارانی که این داکتر حداقل یک نوبتِ «انجام‌شده» با
        // آن‌ها دارد — همان معیار تازه‌ی اجازه‌ی گفتگو در بک‌اند (doctorHasConfirmedPatient).
        // نوبتِ «در انتظار تایید» عمداً اینجا حساب نمی‌شود. هر بیمار ممکن است چند نوبت
        // داشته باشد، پس فقط اولین موردِ واجدِ شرایط نگه داشته می‌شود.
        const uniquePatients = new Map();
        for (const row of patientRows) {
          if (!row.patientId || uniquePatients.has(row.patientId)) continue;
          if (row.appointmentStatus !== "completed") continue;
          uniquePatients.set(row.patientId, {
            id: row.patientId,
            fullName: row.patientName,
          });
        }

        // اطلاعات تکمیلی (شماره تماس/آخرین پیام) از یک مکالمه‌ی موجود در صورت وجود گرفته می‌شود
        const merged = Array.from(uniquePatients.values()).map((p) => {
          const conv = conversationByPatientId.get(p.id);
          return {
            ...p,
            phone: conv?.patientPhone || null,
            conversationId: conv?.id || null,
            lastMessage: conv?.lastMessage || null,
            lastMessageAt: conv?.lastMessageAt || null,
            unreadCount: conv?.unreadCount || 0,
          };
        });

        // مرتب‌سازی: مکالمه‌هایی که پیامی دارند بر اساس آخرین پیام (جدیدترین اول)،
        // سپس بیمارانی که هنوز گفتگویی شروع نشده بر اساس نام
        merged.sort((a, b) => {
          if (a.lastMessageAt && b.lastMessageAt) return new Date(b.lastMessageAt) - new Date(a.lastMessageAt);
          if (a.lastMessageAt) return -1;
          if (b.lastMessageAt) return 1;
          return (a.fullName || "").localeCompare(b.fullName || "", "fa");
        });

        setPatients(merged);
      } catch (err) {
        if (!cancelled) setListError(err.message);
      } finally {
        if (!cancelled) setLoadingPatients(false);
      }
    }

    loadPatientList();
    return () => {
      cancelled = true;
    };
  }, []);

  const selectedPatient = useMemo(
    () => patients.find((p) => p.id === selectedPatientId) || null,
    [patients, selectedPatientId]
  );

  // مجموع پیام‌های خوانده‌نشده در همه‌ی مکالمه‌ها (برای نشان کنار عنوان تب)
  const totalUnread = useMemo(() => patients.reduce((sum, p) => sum + (p.unreadCount || 0), 0), [patients]);

  // ---------- نامِ نمایشیِ طرفِ تماس (از روی conversationId، نه شناسه‌ی کاربرِ سوکت) ----------
  const incomingCallerLabel = useMemo(() => {
    if (!voiceCall.incomingCall) return "";
    const match = patients.find((p) => p.conversationId === voiceCall.incomingCall.conversationId);
    return match ? match.fullName : tr("بیمار");
  }, [voiceCall.incomingCall, patients]);

  const activeCallPeerLabel = useMemo(() => {
    if (!voiceCall.activeConversationId) return "";
    const match = patients.find((p) => p.conversationId === voiceCall.activeConversationId);
    return match ? match.fullName : selectedPatient?.fullName || "";
  }, [voiceCall.activeConversationId, patients, selectedPatient]);

  // ---------- دیپ‌لینکینگ اعلان «پیام جدید»: مکالمه‌ی مرتبط را خودکار باز می‌کند ----------
  // وقتی داکتر از روی یک اعلان چت وارد این تب شده (?highlight=CONVERSATION_ID)، همان
  // مکالمه به‌محض بارگذاری فهرست بیماران انتخاب/باز می‌شود (که خودش پیام‌ها را
  // خوانده‌شده علامت می‌زند). با تغییر highlight (مثلاً کلیک روی اعلان دیگری در حالی
  // که این تب هنوز باز است) دوباره اجرا می‌شود.
  useEffect(() => {
    if (!highlightConversationId || patients.length === 0) return;
    const match = patients.find((p) => p.conversationId && String(p.conversationId) === highlightConversationId);
    if (match && match.id !== selectedPatientId) {
      openConversationWithPatient(match.id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [highlightConversationId, patients]);

  // ---------- انتخاب بیمار: شروع/بازکردن مکالمه و دریافت پیام‌ها ----------
  async function openConversationWithPatient(patientId) {
    setSelectedPatientId(patientId);
    setShowThreadOnMobile(true);
    setMessages([]);
    setConversation(null);
    setPagination(null);
    setMessagesError("");
    setSendError("");
    setLoadingMessages(true);

    try {
      const { conversation: conv } = await apiRequest("/chat/conversations", {
        method: "POST",
        body: { patientId },
      });
      setConversation(conv);

      const data = await apiRequest(`/chat/conversations/${conv.id}/messages`);
      setMessages(data.messages || []);
      setPagination(data.pagination || null);

      // فهرست کناری را هم به‌روزرسانی می‌کند (تعداد نخوانده صفر می‌شود و conversationId ست می‌شود)
      setPatients((prev) =>
        prev.map((p) => (p.id === patientId ? { ...p, conversationId: conv.id, unreadCount: 0 } : p))
      );
    } catch (err) {
      setMessagesError(err.message);
    } finally {
      setLoadingMessages(false);
    }
  }

  // ---------- بارگذاری پیام‌های قدیمی‌تر (صفحه‌بندی) ----------
  async function loadOlderMessages() {
    if (!conversation || !pagination || pagination.page >= pagination.totalPages) return;
    setLoadingOlder(true);
    try {
      const nextPage = pagination.page + 1;
      const data = await apiRequest(`/chat/conversations/${conversation.id}/messages?page=${nextPage}`);
      setMessages((prev) => [...(data.messages || []), ...prev]);
      setPagination(data.pagination || null);
    } catch (err) {
      setMessagesError(err.message);
    } finally {
      setLoadingOlder(false);
    }
  }

  // ---------- ارسال پیام متنی ----------
  async function handleSend(e) {
    e.preventDefault();
    const content = draft.trim();
    if (!content || !conversation) return;

    setSendError("");
    setSending(true);
    try {
      const { data: message } = await apiRequest(`/chat/conversations/${conversation.id}/messages`, {
        method: "POST",
        body: { content },
      });
      setMessages((prev) => [...prev, message]);
      setDraft("");
      setPatients((prev) =>
        prev
          .map((p) =>
            p.id === selectedPatientId
              ? { ...p, lastMessage: message.content, lastMessageAt: message.createdAt }
              : p
          )
          .sort((a, b) => {
            if (a.lastMessageAt && b.lastMessageAt) return new Date(b.lastMessageAt) - new Date(a.lastMessageAt);
            if (a.lastMessageAt) return -1;
            if (b.lastMessageAt) return 1;
            return 0;
          })
      );
    } catch (err) {
      setSendError(err.message);
    } finally {
      setSending(false);
    }
  }

  // ---------- شروع/لغو ویرایش یک پیام (فقط پیام‌های خودِ داکتر) ----------
  function startEditMessage(m) {
    setEditingMessageId(m.id);
    setEditDraft(m.content || "");
    setEditError("");
  }

  function cancelEditMessage() {
    setEditingMessageId(null);
    setEditDraft("");
    setEditError("");
  }

  // ---------- ذخیره‌ی ویرایش یک پیام ----------
  async function submitEditMessage(e, messageId) {
    e.preventDefault();
    const content = editDraft.trim();
    if (!content || !conversation) return;

    setEditSaving(true);
    setEditError("");
    try {
      const { data: updated } = await apiRequest(`/chat/conversations/${conversation.id}/messages/${messageId}`, {
        method: "PUT",
        body: { content },
      });
      setMessages((prev) => prev.map((m) => (m.id === messageId ? updated : m)));
      setEditingMessageId(null);
      setEditDraft("");
    } catch (err) {
      setEditError(err.message);
    } finally {
      setEditSaving(false);
    }
  }

  // ---------- حذف (نرم) یک پیام ----------
  async function handleDeleteMessage(messageId) {
    if (!conversation) return;
    if (!window.confirm(tr("این پیام حذف شود؟"))) return;

    setDeletingMessageId(messageId);
    try {
      const { data: updated } = await apiRequest(`/chat/conversations/${conversation.id}/messages/${messageId}`, {
        method: "DELETE",
      });
      setMessages((prev) => prev.map((m) => (m.id === messageId ? updated : m)));
      if (editingMessageId === messageId) cancelEditMessage();
    } catch (err) {
      setMessagesError(err.message);
    } finally {
      setDeletingMessageId(null);
    }
  }

  // ---------- افزودن/تغییر/حذف واکنش ایموجی روی یک پیام ----------
  async function handleToggleReaction(messageId, emoji) {
    if (!conversation) return;
    setReactionPickerMessageId(null);
    setReactingMessageId(messageId);
    try {
      const { data } = await apiRequest(`/chat/conversations/${conversation.id}/messages/${messageId}/reactions`, {
        method: "POST",
        body: { emoji },
      });
      setMessages((prev) => prev.map((m) => (m.id === messageId ? { ...m, reactions: data.reactions } : m)));
    } catch (err) {
      setMessagesError(err.message);
    } finally {
      setReactingMessageId(null);
    }
  }

  // ---------- انتخاب/ارسال پیوست (عکس یا سند) ----------
  function handleAttachmentButtonClick() {
    attachmentInputRef.current?.click();
  }

  // انتخاب فایل هنوز آن را ارسال نمی‌کند — فقط اعتبارسنجی می‌شود و پنجره‌ی
  // پیش‌نمایش/تایید باز می‌شود. ارسال واقعی فقط با کلیک روی «ارسال» در آن پنجره
  // انجام می‌شود (handleConfirmSendAttachment)، و با «لغو» کاملاً منتفی می‌شود.
  function handleAttachmentSelected(e) {
    const file = e.target.files?.[0];
    e.target.value = ""; // اجازه‌ی انتخاب دوباره‌ی همان فایل در آینده
    if (!file || !conversation) return;

    const ext = `.${file.name.split(".").pop() || ""}`.toLowerCase();
    if (!ALLOWED_ATTACHMENT_EXTENSIONS.includes(ext)) {
      setSendError(tr("فرمت فایل مجاز نیست. فقط عکس (JPG/PNG/WEBP) یا سند (PDF/DOC/DOCX/XLS/XLSX) مجاز است."));
      return;
    }
    if (file.size > MAX_ATTACHMENT_SIZE) {
      setSendError(tr("حجم فایل نباید بیشتر از ۱۵ مگابایت باشد"));
      return;
    }

    setSendError("");
    const isImage = [".jpg", ".jpeg", ".png", ".webp"].includes(ext);
    setPendingAttachment({
      file,
      previewUrl: isImage ? URL.createObjectURL(file) : null,
      isImage,
    });
  }

  // لغو پیوستِ در حال پیش‌نمایش — هیچ درخواستی به سرور ارسال نمی‌شود
  function handleCancelAttachment() {
    if (pendingAttachment?.previewUrl) URL.revokeObjectURL(pendingAttachment.previewUrl);
    setPendingAttachment(null);
  }

  // تایید نهایی و ارسال واقعی پیوست به سرور
  async function handleConfirmSendAttachment() {
    if (!pendingAttachment || !conversation) return;
    setSendError("");
    setAttachmentSending(true);
    try {
      const formData = new FormData();
      formData.append("file", pendingAttachment.file);
      const content = draft.trim();
      if (content) formData.append("content", content);
      const { data: message } = await apiUpload(`/chat/conversations/${conversation.id}/attachments`, formData);
      setMessages((prev) => [...prev, message]);
      setDraft("");
      if (pendingAttachment.previewUrl) URL.revokeObjectURL(pendingAttachment.previewUrl);
      setPendingAttachment(null);
    } catch (err) {
      setSendError(err.message);
    } finally {
      setAttachmentSending(false);
    }
  }

  // ---------- ضبط/ارسال/لغو پیام صوتی ----------
  async function handleStartVoiceRecording() {
    if (!conversation || sending || attachmentSending || voiceSending) return;
    setSendError("");
    // اگر سقف مدت‌زمان مجاز (۵ دقیقه) در حین ضبط برسد، ضبط خودکار متوقف و همان لحظه ارسال می‌شود
    const result = await voiceRecorder.start((autoStopped) => {
      if (autoStopped) uploadVoiceMessage(autoStopped);
    });
    if (!result.ok) setSendError(result.message);
  }

  async function handleCancelVoiceRecording() {
    await voiceRecorder.cancel();
  }

  async function handleSendVoiceRecording() {
    const recorded = await voiceRecorder.stop();
    if (recorded) await uploadVoiceMessage(recorded);
  }

  async function uploadVoiceMessage(recorded) {
    if (!conversation || !recorded?.blob) return;
    setSendError("");
    setVoiceSending(true);
    try {
      const formData = new FormData();
      formData.append("file", recorded.blob, `voice-message.${voiceFileExtension(recorded.mimeType)}`);
      formData.append("duration", String(recorded.duration));
      const { data: message } = await apiUpload(`/chat/conversations/${conversation.id}/voice`, formData);
      setMessages((prev) => [...prev, message]);
    } catch (err) {
      setSendError(err.message);
    } finally {
      setVoiceSending(false);
    }
  }

  // اگر کاربر مکالمه‌ی دیگری را باز کند در حالی که هنوز در حال ضبط بود، ضبط لغو می‌شود
  // (ادامه‌ی ضبط برای مقصد قبلی گیج‌کننده و ناخواسته است)
  useEffect(() => {
    if (voiceRecorder.isRecording) voiceRecorder.cancel();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [conversation?.id]);

  // ---------- بستن منوی کنش‌ها/باکس انتخاب ایموجی با کلیک بیرون از آن‌ها ----------
  useEffect(() => {
    if (!reactionPickerMessageId && !openMenuMessageId) return undefined;
    function handleClickOutside(e) {
      if (isScrollbarClick(e)) return;
      if (!e.target.closest?.(".chat-message-menu-wrap")) {
        setReactionPickerMessageId(null);
        setOpenMenuMessageId(null);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [reactionPickerMessageId, openMenuMessageId]);

  // ---------- دریافت پیام‌های تازه در مکالمه‌ی باز ----------
  // اصلی: push لحظه‌ای Socket.IO (رویداد chat:new). پشتیبان: polling دوره‌ای — هر ۸ ثانیه وقتی
  // اتصال زنده نیست، و فقط هر ۴ تیک (حدود ۳۲ ثانیه) وقتی اتصال زنده است.
  useEffect(() => {
    if (!conversation) return undefined;

    async function fetchLatest() {
      try {
        const data = await apiRequest(`/chat/conversations/${conversation.id}/messages`);
        setMessages((prevMessages) => {
          const incoming = data.messages || [];
          const merged = new Map(prevMessages.map((m) => [m.id, m]));
          for (const m of incoming) merged.set(m.id, m);
          return Array.from(merged.values()).sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        });
      } catch (err) {
        // خطای شبکه در بررسی دوره‌ای نباید رابط کاربری را مختل کند
      }
    }

    let tick = 0;
    pollTimerRef.current = setInterval(() => {
      tick += 1;
      if (isChatSocketConnected() && tick % 4 !== 0) return;
      fetchLatest();
    }, POLL_INTERVAL_MS);

    const offPush = onChatNew((conversationId) => {
      if (conversationId === undefined || Number(conversationId) === Number(conversation.id)) fetchLatest();
    });

    return () => {
      clearInterval(pollTimerRef.current);
      offPush();
    };
  }, [conversation]);

  // ---------- اسکرول خودکار به آخرین پیام ----------
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ block: "end" });
  }, [messages, selectedPatientId]);

  return (
    <div className="dash-card glass chat-shell">
      <VoiceCallPanel
        status={voiceCall.status}
        incomingCall={voiceCall.incomingCall}
        callerLabel={incomingCallerLabel}
        peerLabel={activeCallPeerLabel}
        callError={voiceCall.callError}
        micDenied={voiceCall.micDenied}
        muted={voiceCall.muted}
        callSeconds={voiceCall.callSeconds}
        remoteAudioRef={voiceCall.remoteAudioRef}
        onAccept={voiceCall.acceptCall}
        onReject={voiceCall.rejectCall}
        onEnd={voiceCall.endCall}
        onToggleMute={voiceCall.toggleMute}
        onDismissError={voiceCall.clearCallError}
        onReturnToChat={voiceCall.returnToChat}
        callType={voiceCall.callType}
        cameraOff={voiceCall.cameraOff}
        cameraUnavailable={voiceCall.cameraUnavailable}
        localVideoRef={voiceCall.localVideoRef}
        remoteVideoRef={voiceCall.remoteVideoRef}
        onToggleCamera={voiceCall.toggleCamera}
      />
      <h2>
        {tr("پیام‌های بیماران")}
        {totalUnread > 0 && <span className="chat-unread-badge chat-unread-badge-title">{totalUnread}</span>}
      </h2>
      <p style={{ marginTop: -6, marginBottom: 16, color: "var(--muted, #7a8699)" }}>
        {tr("فقط با بیمارانی که با شما نوبت دارند می‌توانید گفتگوی خصوصی داشته باشید.")}
      </p>

      {listError && <div className="form-message error">{listError}</div>}

      <div className={`chat-layout ${showThreadOnMobile ? "show-thread" : ""}`}>
        {/* ---------- فهرست بیماران مجاز ---------- */}
        <div className="chat-doctor-list">
          {loadingPatients && <p style={{ padding: "12px 6px" }}>{tr("در حال بارگذاری...")}</p>}

          {!loadingPatients && patients.length === 0 && !listError && (
            <p style={{ padding: "12px 6px", color: "var(--text-3)" }}>
              {tr("هنوز هیچ بیماری با شما نوبت ثبت نکرده، بنابراین امکان گفتگو وجود ندارد.")}
            </p>
          )}

          {patients.map((p) => (
            <button
              type="button"
              key={p.id}
              className={`chat-doctor-item ${selectedPatientId === p.id ? "active" : ""}`}
              onClick={() => openConversationWithPatient(p.id)}
            >
              <span className="chat-avatar">
                <span className="chat-avatar-fallback">{initials(p.fullName)}</span>
              </span>
              <span className="chat-doctor-info">
                <span className="chat-doctor-name">
                  {p.fullName}
                  {p.unreadCount > 0 && <span className="chat-unread-badge">{p.unreadCount}</span>}
                </span>
                <span className="chat-doctor-sub">
                  {p.lastMessage ? p.lastMessage : p.phone ? p.phone : tr("شروع گفتگو")}
                </span>
              </span>
            </button>
          ))}
        </div>

        {/* ---------- پنجره‌ی گفتگو ---------- */}
        <div className="chat-thread">
          {!selectedPatient && (
            <div className="chat-empty-state">
              <User size={34} />
              <p>{tr("یک بیمار را از فهرست انتخاب کنید تا گفتگو را ببینید.")}</p>
            </div>
          )}

          {selectedPatient && (
            <>
              <div className="chat-thread-header">
                <button type="button" className="btn btn-ghost btn-sm chat-back-btn" onClick={() => setShowThreadOnMobile(false)}>
                  {tr("← بازگشت")}
                </button>
                <span className="chat-avatar">
                  <span className="chat-avatar-fallback">{initials(selectedPatient.fullName)}</span>
                </span>
                <div>
                  <div className="chat-thread-name">{selectedPatient.fullName}</div>
                  {selectedPatient.phone && <div className="chat-thread-dept">{selectedPatient.phone}</div>}
                </div>
                <div className="chat-call-actions">
                  <button
                    type="button"
                    className="chat-call-trigger-btn"
                    title={tr("تماس صوتی")}
                    disabled={!conversation || voiceCall.status !== "idle" || !!voiceCall.incomingCall}
                    onClick={() => voiceCall.startCall(conversation.id)}
                  >
                    <Phone size={18} />
                  </button>
                  <button
                    type="button"
                    className="chat-call-trigger-btn"
                    title={tr("تماس تصویری")}
                    disabled={!conversation || voiceCall.status !== "idle" || !!voiceCall.incomingCall}
                    onClick={() => voiceCall.startCall(conversation.id, { video: true })}
                  >
                    <Video size={18} />
                  </button>
                </div>
              </div>

              <div className="chat-messages">
                {messagesError && <div className="form-message error">{messagesError}</div>}

                {pagination && pagination.page < pagination.totalPages && (
                  <div style={{ textAlign: "center", marginBottom: 10 }}>
                    <button type="button" className="btn btn-ghost btn-sm" disabled={loadingOlder} onClick={loadOlderMessages}>
                      {loadingOlder ? "..." : tr("بارگذاری پیام‌های قدیمی‌تر")}
                    </button>
                  </div>
                )}

                {loadingMessages && <p style={{ textAlign: "center" }}>{tr("در حال بارگذاری گفتگو...")}</p>}

                {!loadingMessages && messages.length === 0 && !messagesError && (
                  <p style={{ textAlign: "center", color: "var(--text-3)" }}>{tr("هنوز پیامی رد و بدل نشده. اولین پیام را بفرستید.")}</p>
                )}

                {!loadingMessages &&
                  messages
                    .filter((m) => !m.isDeleted)
                    .map((m, idx, visibleMessages) => {
                    const prev = visibleMessages[idx - 1];
                    const showDivider = !prev || new Date(prev.createdAt).toDateString() !== new Date(m.createdAt).toDateString();
                    const isMine = m.senderRole === "doctor";
                    const isEditingThis = editingMessageId === m.id;
                    return (
                      <div key={m.id}>
                        {showDivider && <div className="chat-day-divider">{formatDayDivider(m.createdAt)}</div>}
                        <div className={`chat-bubble-row ${isMine ? "mine" : "theirs"}`}>
                          {!m.isDeleted && !isEditingThis && (
                            <span className="chat-message-menu-wrap">
                              <button
                                type="button"
                                className="chat-message-menu-trigger"
                                title={tr("گزینه‌های پیام")}
                                onClick={() => setOpenMenuMessageId((cur) => (cur === m.id ? null : m.id))}
                              >
                                <MoreVertical size={15} />
                              </button>
                              {openMenuMessageId === m.id && (
                                <div className="chat-message-menu">
                                  {isMine && (
                                    <button
                                      type="button"
                                      className="chat-message-menu-item"
                                      onClick={() => {
                                        setOpenMenuMessageId(null);
                                        startEditMessage(m);
                                      }}
                                    >
                                      <Pencil size={14} />
                                      <span>{tr("ویرایش")}</span>
                                    </button>
                                  )}
                                  <button
                                    type="button"
                                    className="chat-message-menu-item"
                                    onClick={() => {
                                      setOpenMenuMessageId(null);
                                      setReactionPickerMessageId(m.id);
                                    }}
                                  >
                                    <SmilePlus size={14} />
                                    <span>{tr("واکنش")}</span>
                                  </button>
                                  {isMine && (
                                    <button
                                      type="button"
                                      className="chat-message-menu-item danger"
                                      disabled={deletingMessageId === m.id}
                                      onClick={() => {
                                        setOpenMenuMessageId(null);
                                        handleDeleteMessage(m.id);
                                      }}
                                    >
                                      <Trash2 size={14} />
                                      <span>{tr("حذف")}</span>
                                    </button>
                                  )}
                                </div>
                              )}
                              {reactionPickerMessageId === m.id && (
                                <div className="chat-reaction-picker">
                                  {MESSAGE_REACTIONS.map((emoji) => (
                                    <button
                                      key={emoji}
                                      type="button"
                                      className="chat-reaction-picker-option"
                                      disabled={reactingMessageId === m.id}
                                      onClick={() => handleToggleReaction(m.id, emoji)}
                                    >
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                              )}
                            </span>
                          )}
                          <div className={`chat-bubble ${isMine ? "mine" : "theirs"}`}>
                            {m.isDeleted ? (
                              <span className="chat-bubble-text chat-bubble-deleted">{tr("این پیام حذف شده است")}</span>
                            ) : isEditingThis ? (
                              <form className="chat-bubble-edit-row" onSubmit={(e) => submitEditMessage(e, m.id)}>
                                <textarea
                                  className="chat-bubble-edit-input"
                                  value={editDraft}
                                  maxLength={4000}
                                  rows={1}
                                  autoFocus
                                  onChange={(e) => setEditDraft(e.target.value)}
                                  onKeyDown={(e) => {
                                    if (e.key === "Enter" && !e.shiftKey) {
                                      e.preventDefault();
                                      submitEditMessage(e, m.id);
                                    } else if (e.key === "Escape") {
                                      cancelEditMessage();
                                    }
                                  }}
                                />
                                <button
                                  type="submit"
                                  className="chat-bubble-action-btn"
                                  title={tr("ذخیره")}
                                  disabled={editSaving || !editDraft.trim()}
                                >
                                  <Check size={14} />
                                </button>
                                <button
                                  type="button"
                                  className="chat-bubble-action-btn"
                                  title={tr("لغو")}
                                  onClick={cancelEditMessage}
                                >
                                  <X size={14} />
                                </button>
                              </form>
                            ) : (
                              <>
                                {m.attachmentOriginalName && (m.attachmentFileType || "").startsWith("audio/") && (
                                  <VoiceMessagePlayer conversationId={conversation.id} message={m} />
                                )}
                                {m.attachmentOriginalName && !(m.attachmentFileType || "").startsWith("audio/") && (
                                  <ChatAttachment conversationId={conversation.id} message={m} />
                                )}
                                {m.content && <span className="chat-bubble-text">{m.content}</span>}
                              </>
                            )}
                            <span className="chat-bubble-meta">
                              {m.isEdited && !m.isDeleted && <span className="chat-bubble-edited">{tr("ویرایش‌شده")}</span>}
                              <span className="chat-bubble-time">{formatMessageTime(m.createdAt)}</span>
                              {isMine && !m.isDeleted && (() => {
                                const status = m.isRead ? "read" : m.isDelivered ? "delivered" : "sent";
                                const statusLabel =
                                  status === "read" ? tr("خوانده شد") : status === "delivered" ? tr("تحویل شد") : tr("ارسال شد");
                                return (
                                  <span className={`chat-bubble-status ${status}`} title={statusLabel}>
                                    {status === "sent" ? <Check size={14} /> : <CheckCheck size={14} />}
                                  </span>
                                );
                              })()}
                            </span>
                          </div>
                        </div>
                        {!m.isDeleted && !!m.reactions?.length && (
                          <div className={`chat-bubble-reactions ${isMine ? "mine" : "theirs"}`}>
                            {m.reactions.map((r) => (
                              <button
                                key={r.emoji}
                                type="button"
                                className={`chat-reaction-chip ${r.mine ? "mine" : ""}`}
                                disabled={reactingMessageId === m.id}
                                title={r.mine ? tr("برداشتن واکنش") : tr("تغییر واکنش به این")}
                                onClick={() => handleToggleReaction(m.id, r.emoji)}
                              >
                                <span>{r.emoji}</span>
                                {r.count > 1 && <span className="chat-reaction-chip-count">{r.count}</span>}
                              </button>
                            ))}
                          </div>
                        )}
                        {isEditingThis && editError && (
                          <div className="form-message error" style={{ margin: "4px 16px 0" }}>{editError}</div>
                        )}
                      </div>
                    );
                  })}
                <div ref={messagesEndRef} />
              </div>

              {sendError && <div className="form-message error" style={{ margin: "0 16px 10px" }}>{sendError}</div>}

              {voiceRecorder.isRecording ? (
                <div className="chat-input-row">
                  <VoiceRecorderBar
                    supported={voiceRecorder.supported}
                    isRecording={voiceRecorder.isRecording}
                    elapsedSeconds={voiceRecorder.elapsedSeconds}
                    sending={voiceSending}
                    triggerDisabled={sending || attachmentSending || voiceSending || !conversation || !!pendingAttachment}
                    onStartRecording={handleStartVoiceRecording}
                    onCancelRecording={handleCancelVoiceRecording}
                    onSendRecording={handleSendVoiceRecording}
                  />
                </div>
              ) : (
                <form className="chat-input-row" onSubmit={handleSend}>
                  <input
                    type="file"
                    ref={attachmentInputRef}
                    accept={ALLOWED_ATTACHMENT_ACCEPT}
                    hidden
                    onChange={handleAttachmentSelected}
                  />
                  <button
                    type="button"
                    className="chat-attachment-trigger-btn"
                    title={tr("پیوست عکس یا سند")}
                    disabled={sending || attachmentSending || voiceSending || !conversation || !!pendingAttachment}
                    onClick={handleAttachmentButtonClick}
                  >
                    {attachmentSending ? <Loader2 size={18} className="chat-attachment-spin" /> : <Paperclip size={18} />}
                  </button>
                  <VoiceRecorderBar
                    supported={voiceRecorder.supported}
                    isRecording={voiceRecorder.isRecording}
                    elapsedSeconds={voiceRecorder.elapsedSeconds}
                    sending={voiceSending}
                    triggerDisabled={sending || attachmentSending || voiceSending || !conversation || !!pendingAttachment}
                    onStartRecording={handleStartVoiceRecording}
                    onCancelRecording={handleCancelVoiceRecording}
                    onSendRecording={handleSendVoiceRecording}
                  />
                  <textarea
                    className="chat-input"
                    placeholder={tr("متن پیام...")}
                    value={draft}
                    maxLength={4000}
                    rows={1}
                    onChange={(e) => setDraft(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        handleSend(e);
                      }
                    }}
                  />
                  <button type="submit" className="btn btn-primary chat-send-btn" disabled={sending || !draft.trim()}>
                    <Send size={18} />
                  </button>
                </form>
              )}
            </>
          )}
        </div>
      </div>

      <GlobalModal
        isOpen={!!pendingAttachment}
        onClose={attachmentSending ? undefined : handleCancelAttachment}
        title={tr("ارسال پیوست")}
        size="sm"
        closeOnOverlayClick={!attachmentSending}
        closeOnEsc={!attachmentSending}
        footer={
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", width: "100%" }}>
            <button type="button" className="btn btn-ghost" disabled={attachmentSending} onClick={handleCancelAttachment}>
              {tr("لغو")}
            </button>
            <button type="button" className="btn btn-primary" disabled={attachmentSending} onClick={handleConfirmSendAttachment}>
              {attachmentSending ? tr("در حال ارسال...") : tr("ارسال")}
            </button>
          </div>
        }
      >
        {pendingAttachment && (
          <div style={{ textAlign: "center" }}>
            {pendingAttachment.isImage ? (
              <img
                src={pendingAttachment.previewUrl}
                alt={tr("پیش‌نمایش پیوست")}
                style={{ maxWidth: "100%", maxHeight: 320, borderRadius: 10, objectFit: "contain" }}
              />
            ) : (
              <div style={{ padding: "24px 12px" }}>
                <Paperclip size={32} />
                <p style={{ marginTop: 8, wordBreak: "break-all" }}>{pendingAttachment.file.name}</p>
              </div>
            )}
            <p style={{ marginTop: 10, color: "var(--text-3)", fontSize: 13 }}>
              {tr("آیا این فایل ارسال شود؟")}
            </p>
          </div>
        )}
      </GlobalModal>
    </div>
  );
}

import { useCallback, useRef, useState } from "react";

import { tr } from "../../i18n/tr.js";
let toastIdCounter = 0;

// سیستم اعلان توست سبک، مخصوص پنل «مدیریت بخش‌ها» — بدون وابستگی به کتابخانه‌ی خارجی و
// بدون هیچ تغییری در سایر بخش‌های داشبورد. useDepartmentToasts پیام‌ها را نگه می‌دارد و
// بعد از چند ثانیه به‌صورت خودکار حذف می‌کند.
export function useDepartmentToasts() {
  const [toasts, setToasts] = useState([]);
  const timers = useRef({});

  const dismissToast = useCallback((id) => {
    setToasts((list) => list.filter((t) => t.id !== id));
    clearTimeout(timers.current[id]);
    delete timers.current[id];
  }, []);

  const showToast = useCallback((message, type = "success") => {
    if (!message) return;
    const id = ++toastIdCounter;
    setToasts((list) => [...list, { id, message, type }]);
    timers.current[id] = setTimeout(() => dismissToast(id), 4500);
  }, [dismissToast]);

  return { toasts, showToast, dismissToast };
}

export function DepartmentToastContainer({ toasts, onDismiss }) {
  if (!toasts.length) return null;
  return (
    <div className="dept-toast-container" role="status" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`dept-toast dept-toast-${t.type}`}>
          <span>{t.message}</span>
          <button
            type="button"
            className="dept-toast-close"
            onClick={() => onDismiss(t.id)}
            aria-label={tr("بستن پیام")}
          >
            ×
          </button>
        </div>
      ))}
    </div>
  );
}

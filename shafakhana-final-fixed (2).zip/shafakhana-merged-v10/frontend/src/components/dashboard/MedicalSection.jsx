import { lazy, Suspense, useState } from "react";
import MedicalDocumentsPanel from "./MedicalDocumentsPanel.jsx";

import { tr } from "../../i18n/tr.js";
// بخش «نسخه و سوابق طبی» برای داشبورد ادمین و داکتر.
// نمای پیش‌فرض: فهرست یکپارچه‌ی اسناد (نسخه / سابقه صحی / آزمایش / تصویر پزشکی).
// نمای «نسخه‌ها»: همان پنل قبلی بدون تغییر — برای ادمین مدیریت وضعیت نسخه + پرونده‌ی کامل مریض،
// برای داکتر ثبت و ویرایش نسخه‌ی چنددارویی. هیچ قابلیت موجودی حذف نشده است.
const AdminPrescriptionsPanel = lazy(() => import("./AdminPrescriptionsPanel.jsx"));
const DoctorPrescriptionsPanel = lazy(() => import("./DoctorPrescriptionsPanel.jsx"));

export default function MedicalSection({ role = "admin" }) {
  const [view, setView] = useState("documents");
  const Legacy = role === "doctor" ? DoctorPrescriptionsPanel : AdminPrescriptionsPanel;

  return (
    <div className="rxp" style={{ gap: 14 }}>
      <div className="mdoc-segmented" role="tablist" aria-label={tr("نمای نسخه و سوابق طبی")}>
        <button type="button" role="tab" aria-selected={view === "documents"} className={view === "documents" ? "active" : ""} onClick={() => setView("documents")}>{tr("همه اسناد")}</button>
        <button type="button" role="tab" aria-selected={view === "prescriptions"} className={view === "prescriptions" ? "active" : ""} onClick={() => setView("prescriptions")}>
          {role === "doctor" ? tr("نسخه‌ها (ثبت و ویرایش)") : tr("نسخه‌ها (مدیریت وضعیت)")}
        </button>
      </div>

      {view === "documents" ? (
        <MedicalDocumentsPanel role={role} onNewPrescription={role === "doctor" ? () => setView("prescriptions") : undefined} />
      ) : (
        <Suspense fallback={<div className="rxp-detail-loading" aria-busy="true"><span className="rxp-skeleton rxp-skeleton-block tall" /></div>}>
          <Legacy />
        </Suspense>
      )}
    </div>
  );
}

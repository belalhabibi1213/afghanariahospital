import { useEffect, useState } from "react";
import {
  Search, X, Eye, Printer, Download, RefreshCw, Pill, ClipboardList, AlertTriangle, FilterX, Lock,
} from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import { apiRequest, apiDownload } from "../../utils/api.js";
import useHighlightParam from "../../hooks/useHighlightParam.js";
import { HealthRecordDetailView } from "./PatientHealthRecords.jsx";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, numLocale } from "../../i18n/tr.js";
// ============================================================================
// پنل بیمار «نسخه و سوابق طبی» — کاملاً فقط‌خواندنی (Read-only)
// ----------------------------------------------------------------------------
// هیچ دکمه یا فرمی برای ساخت/ویرایش/حذف وجود ندارد، و حتی اگر کسی مستقیم API را صدا بزند،
// مسیرهای نوشتن (/api/medical-records/*) برای نقش بیمار ۴۰۳ می‌دهند.
// همه‌ی داده‌ها از مسیرهای مخصوص بیمار می‌آیند که مالکیت را سمت سرور از روی توکن بررسی می‌کنند
// (شناسه‌ی بیمار هیچ‌جا از کلاینت فرستاده نمی‌شود، پس تغییر ID در URL/درخواست چیزی را باز نمی‌کند):
//   GET /api/users/documents                    «همه اسناد» (نسخه + پرونده صحی) با جستجو/فیلتر نوع/صفحه‌بندی سمت سرور
//   GET /api/users/prescription-list            فهرست گروه‌بندی‌شده‌ی نسخه‌های خودِ بیمار (تب‌های نسخه‌های من/قبلی)
//   GET /api/users/prescriptions/:id/detail     جزئیات یک نسخه (۴۰۴ اگر مال بیمار دیگری باشد)
//   GET /api/users/prescriptions/:id/pdf        چاپ / PDF (همان بررسی مالکیت)
//   GET /api/users/health-records/:id           جزئیات پرونده‌ی صحیِ ثبت/ارسال‌شده (فقط خواندنی)
//   GET /api/users/emr                          سوابق، تشخیص‌ها، آزمایش‌های تکمیل‌شده، رادیولوژی، حساسیت‌ها
//   GET /api/users/lab-results/:id/report       فایل گزارش آزمایش (فقط آزمایش خودش)
// استایل: components/dashboard/AdminPrescriptionsPanel.css (rxp-*) + components/dashboard/PatientRecordsPanel.css (prc-*)
// ============================================================================

const STATUS_LABEL = trc({ active: "در حال اجرا", completed: "تکمیل‌شده", cancelled: "لغوشده" });
const SEVERITY_LABEL = trc({ mild: "خفیف", moderate: "متوسط", severe: "شدید" });
const DIAGNOSIS_STATUS_LABEL = trc({ active: "در حال جریان", resolved: "بهبودیافته" });
const LAB_STATUS_LABEL = trc({ pending: "در انتظار نتیجه", completed: "تکمیل‌شده" });
const EMPTY_FILTERS = { dateFrom: "", dateTo: "" };

const SECTIONS = trc([
  { key: "all", label: "همه اسناد", icon: "📚" },
  { key: "current", label: "نسخه‌های من", icon: "💊" },
  { key: "past", label: "نسخه‌های قبلی", icon: "🕘" },
  { key: "encounters", label: "سوابق طبی من", icon: "📋" },
  { key: "diagnoses", label: "تشخیص‌های من", icon: "🩺" },
  { key: "labs", label: "نتایج آزمایش", icon: "🧪" },
  { key: "radiology", label: "رادیولوژی", icon: "🩻" },
  { key: "allergies", label: "حساسیت‌ها", icon: "⚠️" },
]);

function fmtDate(v) {
  return v ? new Date(v).toLocaleDateString(numLocale()) : "—";
}
function useDebounced(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}
function StatusBadge({ status }) {
  const key = STATUS_LABEL[status] ? status : "active";
  return <span className={`rxp-badge rxp-badge-${key}`}>{STATUS_LABEL[key]}</span>;
}

export default function PatientRecordsPanel() {
  const [section, setSection] = useState("all");
  const [emr, setEmr] = useState(null);
  const [emrLoading, setEmrLoading] = useState(false);
  const [emrError, setEmrError] = useState("");
  const [emrTick, setEmrTick] = useState(0);
  const [actionError, setActionError] = useState("");

  // سوابق/تشخیص/آزمایش/رادیولوژی/حساسیت با یک درخواست و فقط وقتی یکی از این بخش‌ها باز شد خوانده می‌شود
  const needsEmr = !["all", "current", "past"].includes(section);
  useEffect(() => {
    if (!needsEmr || (emr && emrTick === 0)) return;
    let cancelled = false;
    setEmrLoading(true);
    setEmrError("");
    apiRequest("/users/emr")
      .then((d) => { if (!cancelled) { setEmr(d); setEmrTick(0); } })
      .catch((err) => { if (!cancelled) setEmrError(err.message); })
      .finally(() => { if (!cancelled) setEmrLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [needsEmr, emrTick]);

  const counts = emr ? {
    encounters: (emr.encounters || []).length,
    diagnoses: (emr.diagnoses || []).length,
    labs: (emr.labResults || []).length,
    radiology: (emr.radiologyReports || []).length,
    allergies: (emr.allergies || []).length,
  } : {};

  async function openLabReport(id) {
    setActionError("");
    try {
      await apiDownload(`/users/lab-results/${id}/report`, `lab-report-${id}`, { openInNewTab: true });
    } catch (err) { setActionError(err.message); }
  }

  return (
    <div className="rxp prc">
      <div className="rxp-header glass">
        <div className="rxp-header-main">
          <span className="rxp-header-icon"><Pill size={26} /></span>
          <div>
            <h2>{tr("نسخه و سوابق طبی")}</h2>
            <p>{tr("نسخه‌ها و اطلاعات پزشکی شما؛ فقط برای مشاهده، چاپ و دانلود")}</p>
          </div>
        </div>
        <span className="prc-readonly" title={tr("اطلاعات پزشکی را فقط داکتر ثبت و ویرایش می‌کند")}>
          <Lock size={14} /> {tr("فقط مشاهده")}
        </span>
      </div>

      <nav className="prc-tabs" role="tablist" aria-label={tr("بخش‌های سوابق طبی")}>
        {SECTIONS.map((s) => (
          <button
            key={s.key}
            type="button"
            role="tab"
            aria-selected={section === s.key}
            className={section === s.key ? "active" : ""}
            onClick={() => setSection(s.key)}
          >
            <span aria-hidden="true">{s.icon}</span> {s.label}
            {counts[s.key] != null && <em className="prc-tab-count">{Number(counts[s.key]).toLocaleString(numLocale())}</em>}
          </button>
        ))}
      </nav>

      {actionError && <div className="form-message error" role="alert">{actionError}</div>}

      {section === "all" && <AllDocuments onActionError={setActionError} />}

      {(section === "current" || section === "past") && (
        <PrescriptionList key={section} mode={section} onActionError={setActionError} />
      )}

      {needsEmr && (
        <div className="rxp-table-card glass prc-section">
          {emrLoading && !emr && (
            <div className="rxp-detail-loading" aria-busy="true">
              <span className="rxp-skeleton rxp-skeleton-block" />
              <span className="rxp-skeleton rxp-skeleton-block" />
              <span className="rxp-skeleton rxp-skeleton-block tall" />
            </div>
          )}
          {emrError && (
            <div className="rxp-state rxp-state-error" role="alert">
              <AlertTriangle size={34} />
              <h4>{tr("بارگذاری اطلاعات ناموفق بود")}</h4>
              <p>{emrError}</p>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => setEmrTick((t) => t + 1)}>{tr("تلاش دوباره")}</button>
            </div>
          )}
          {emr && !emrError && <EmrSection section={section} emr={emr} onOpenLab={openLabReport} />}
        </div>
      )}
    </div>
  );
}

// ---------- «همه اسناد»: نسخه‌ها + پرونده‌های صحی در یک فهرست (مثل داشبورد داکتر) ----------
// جستجو، فیلتر نوع و صفحه‌بندی سمت سرور و در SQL انجام می‌شود: GET /api/users/documents (مالکیت از روی توکن).
const ALL_PAGE_SIZE = 10;
const TYPE_META = trc({ prescription: { label: "نسخه", Icon: Pill, cls: "rx" }, record: { label: "پرونده صحی", Icon: ClipboardList, cls: "record" } });

function AllDocuments({ onActionError }) {
  const [docs, setDocs] = useState([]);
  const [counts, setCounts] = useState({ prescription: 0, record: 0 });
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [tick, setTick] = useState(0);
  const [type, setType] = useState("");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [openDoc, setOpenDoc] = useState(null); // { type, id }
  const [busyId, setBusyId] = useState(null);
  const debounced = useDebounced(search);

  useEffect(() => setPage(1), [type, debounced]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    const usp = new URLSearchParams({ page, limit: ALL_PAGE_SIZE });
    if (type) usp.set("type", type);
    if (debounced.trim()) usp.set("q", debounced.trim());
    apiRequest(`/users/documents?${usp.toString()}`)
      .then((d) => {
        if (cancelled) return;
        setDocs((d.documents || []).map((r) => ({ ...r, key: `${r.type}-${r.id}` })));
        setCounts(d.counts || { prescription: 0, record: 0 });
        setPagination(d.pagination || null);
      })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [type, debounced, page, tick]);

  const totalAll = counts.prescription + counts.record;
  const hasFilter = !!(type || debounced.trim());
  const totalPages = pagination?.totalPages || 1;
  const faNum = (n) => Number(n).toLocaleString(numLocale());

  async function rxFile(id, mode) {
    setBusyId(`${mode}-${id}`);
    onActionError("");
    try { await apiDownload(`/users/prescriptions/${id}/pdf`, `prescription-${id}.pdf`, mode === "print" ? { print: true } : { openInNewTab: true }); }
    catch (err) { onActionError(err.message); } finally { setBusyId(null); }
  }

  return (
    <>
      <div className="rxp-toolbar glass">
        <div className="rxp-search">
          <Search size={17} />
          <input type="search" value={search} onChange={(e) => setSearch(e.target.value)} placeholder={tr("جستجو: نام داکتر، تشخیص یا شماره سند (RX-… / MR-…)")} aria-label={tr("جستجوی اسناد")} />
          {search && <button type="button" className="rxp-search-clear" onClick={() => setSearch("")} aria-label={tr("پاک‌کردن جستجو")}><X size={15} /></button>}
        </div>
        <div className="prc-seg" role="tablist" aria-label={tr("نوع سند")}>
          {[["", tr("همه"), totalAll], ["prescription", tr("نسخه‌ها"), counts.prescription], ["record", tr("پرونده‌های صحی"), counts.record]].map(([k, label, n]) => (
            <button key={k || "all"} type="button" role="tab" aria-selected={type === k} className={type === k ? "active" : ""} onClick={() => setType(k)}>
              {label} <em className="prc-tab-count">{faNum(n)}</em>
            </button>
          ))}
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setTick((t) => t + 1)} disabled={loading}>
            <RefreshCw size={14} className={loading ? "rxp-spin" : ""} style={{ verticalAlign: "-2px" }} /> {tr("بازخوانی")}
          </button>
        </div>
      </div>

      <div className="rxp-table-card glass">
        {error && (
          <div className="rxp-state rxp-state-error" role="alert">
            <AlertTriangle size={34} />
            <h4>{tr("بارگذاری اسناد ناموفق بود")}</h4>
            <p>{error}</p>
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setTick((t) => t + 1)}>{tr("تلاش دوباره")}</button>
          </div>
        )}

        {!error && (
          <div className="rxp-table-wrap">
            <table className="rxp-table">
              <thead>
                <tr><th>{tr("نوع")}</th><th>{tr("شماره")}</th><th>{tr("تاریخ")}</th><th>{tr("نام داکتر")}</th><th>{tr("تشخیص / موضوع")}</th><th>{tr("وضعیت")}</th><th>{tr("عملیات")}</th></tr>
              </thead>
              <tbody>
                {loading && docs.length === 0 && Array.from({ length: 5 }).map((_, i) => (
                  <tr key={`sk-${i}`} className="rxp-row-skeleton" aria-hidden="true">
                    {Array.from({ length: 7 }).map((__, j) => <td key={j}><span className="rxp-skeleton" /></td>)}
                  </tr>
                ))}
                {docs.map((d) => {
                  const meta = TYPE_META[d.type];
                  return (
                    <tr key={d.key} className={`rxp-row ${loading ? "is-loading" : ""}`} onClick={() => setOpenDoc({ type: d.type, id: d.id })}>
                      <td data-label={tr("نوع")}><span className={`prc-type prc-type-${meta.cls}`}><meta.Icon size={14} /> {meta.label}</span></td>
                      <td data-label={tr("شماره")}><span className="rxp-rxnum">{d.number}</span></td>
                      <td data-label={tr("تاریخ")}>{fmtDate(d.date)}</td>
                      <td data-label={tr("نام داکتر")}>{d.doctorName || "—"}</td>
                      <td data-label={tr("تشخیص / موضوع")}><span className="prc-clip">{d.title || "—"}</span></td>
                      <td data-label={tr("وضعیت")}>
                        {d.type === "prescription"
                          ? <StatusBadge status={d.status} />
                          : <span className={`prc-pill ${d.released ? "prc-pill-sent" : "prc-pill-ok"}`}>{d.released ? tr("ارسال‌شده") : tr("ثبت‌شده")}</span>}
                      </td>
                      <td data-label={tr("عملیات")} onClick={(e) => e.stopPropagation()}>
                        <div className="prc-actions">
                          <button type="button" className="btn btn-primary btn-sm" onClick={() => setOpenDoc({ type: d.type, id: d.id })}>
                            <Eye size={14} style={{ verticalAlign: "-2px" }} /> {d.type === "prescription" ? tr("مشاهده نسخه") : tr("مشاهده پرونده")}
                          </button>
                          {d.type === "prescription" && (
                            <>
                              <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === `print-${d.id}`} onClick={() => rxFile(d.id, "print")}>
                                <Printer size={14} style={{ verticalAlign: "-2px" }} /> {tr("چاپ")}
                              </button>
                              <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === `pdf-${d.id}`} onClick={() => rxFile(d.id, "pdf")}>
                                <Download size={14} style={{ verticalAlign: "-2px" }} /> {tr("دانلود PDF")}
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {!loading && docs.length === 0 && (
              <div className="rxp-state">
                <ClipboardList size={38} />
                <h4>{!hasFilter && totalAll === 0 ? tr("هنوز سندی برای شما ثبت نشده است") : tr("سندی با این مشخصات یافت نشد")}</h4>
                <p>{!hasFilter && totalAll === 0 ? tr("نسخه‌ها و پرونده‌های صحی که داکتر برای شما ثبت یا ارسال می‌کند اینجا نمایش داده می‌شود.") : tr("جستجو یا نوع سند را تغییر دهید.")}</p>
              </div>
            )}
          </div>
        )}


        {!error && totalPages > 1 && (
          <div className="rxp-pagination">
            <button type="button" className="btn btn-ghost btn-sm" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>{tr("صفحه قبل")}</button>
            <span>{tr("صفحه {0} از {1} ({2} سند)", [faNum(pagination.page), faNum(totalPages), faNum(pagination.total)])}</span>
            <button type="button" className="btn btn-ghost btn-sm" disabled={page >= totalPages || loading} onClick={() => setPage(page + 1)}>{tr("صفحه بعد")}</button>
          </div>
        )}
      </div>

      <GlobalModal
        isOpen={openDoc != null}
        onClose={() => setOpenDoc(null)}
        size={openDoc?.type === "record" ? "xl" : "lg"}
        title={openDoc?.type === "record" ? tr("پرونده صحی") : tr("جزئیات نسخه")}
        className="rxp-modal"
      >
        {openDoc?.type === "prescription" && (
          <PrescriptionDetailView id={openDoc.id} busyId={busyId} onPrint={() => rxFile(openDoc.id, "print")} onPdf={() => rxFile(openDoc.id, "pdf")} />
        )}
        {openDoc?.type === "record" && <HealthRecordDetailView id={openDoc.id} />}
      </GlobalModal>
    </>
  );
}

// ---------- فهرست نسخه‌ها (نسخه‌های من = در حال اجرا، نسخه‌های قبلی = تکمیل‌شده/لغوشده) ----------
function PrescriptionList({ mode, onActionError }) {
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedId, setSelectedId] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [reloadTick, setReloadTick] = useState(0);
  const { highlightRowProps } = useHighlightParam();

  const debouncedSearch = useDebounced(search);
  const hasFilters = !!(search || filters.dateFrom || filters.dateTo);

  useEffect(() => setPage(1), [debouncedSearch, filters.dateFrom, filters.dateTo]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    const usp = new URLSearchParams({ page, limit: 10, status: mode === "current" ? "active" : "past" });
    if (debouncedSearch.trim()) usp.set("q", debouncedSearch.trim());
    if (filters.dateFrom) usp.set("dateFrom", filters.dateFrom);
    if (filters.dateTo) usp.set("dateTo", filters.dateTo);
    apiRequest(`/users/prescription-list?${usp.toString()}`)
      .then((d) => {
        if (cancelled) return;
        setItems(d.prescriptions || []);
        setPagination(d.pagination || null);
      })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [mode, debouncedSearch, filters.dateFrom, filters.dateTo, page, reloadTick]);

  const reload = () => setReloadTick((t) => t + 1);
  function clearAll() { setSearch(""); setFilters(EMPTY_FILTERS); }

  async function printRx(id) {
    setBusyId(`print-${id}`);
    onActionError("");
    try { await apiDownload(`/users/prescriptions/${id}/pdf`, `prescription-${id}.pdf`, { print: true }); }
    catch (err) { onActionError(err.message); } finally { setBusyId(null); }
  }
  async function pdfRx(id) {
    setBusyId(`pdf-${id}`);
    onActionError("");
    try { await apiDownload(`/users/prescriptions/${id}/pdf`, `prescription-${id}.pdf`, { openInNewTab: true }); }
    catch (err) { onActionError(err.message); } finally { setBusyId(null); }
  }

  const emptyTitle = hasFilters
    ? tr("نسخه‌ای با این مشخصات یافت نشد")
    : mode === "current" ? tr("نسخه‌ی در حال اجرایی ندارید") : tr("نسخه‌ی قبلی‌ای ثبت نشده است");

  return (
    <>
      <div className="rxp-toolbar glass">
        <div className="rxp-search">
          <Search size={17} />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tr("جستجو: نام داکتر یا شماره نسخه (مثلاً RX-000012)")}
            aria-label={tr("جستجوی نسخه")}
          />
          {search && (
            <button type="button" className="rxp-search-clear" onClick={() => setSearch("")} aria-label={tr("پاک‌کردن جستجو")}><X size={15} /></button>
          )}
        </div>
        <div className="rxp-filters prc-filters">
          <div className="field">
            <label>{tr("از تاریخ")}</label>
            <JalaliDateInput value={filters.dateFrom} max={filters.dateTo || undefined} onChange={(e) => setFilters((f) => ({ ...f, dateFrom: e.target.value }))} />
          </div>
          <div className="field">
            <label>{tr("تا تاریخ")}</label>
            <JalaliDateInput value={filters.dateTo} min={filters.dateFrom || undefined} onChange={(e) => setFilters((f) => ({ ...f, dateTo: e.target.value }))} />
          </div>
          <div className="prc-filter-actions">
            {hasFilters && (
              <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>
                <FilterX size={14} style={{ verticalAlign: "-2px" }} /> {tr("پاک‌کردن")}
              </button>
            )}
            <button type="button" className="btn btn-ghost btn-sm" onClick={reload} disabled={loading}>
              <RefreshCw size={14} className={loading ? "rxp-spin" : ""} style={{ verticalAlign: "-2px" }} /> {tr("بازخوانی")}
            </button>
          </div>
        </div>
      </div>

      <div className="rxp-table-card glass">
        {error && (
          <div className="rxp-state rxp-state-error" role="alert">
            <AlertTriangle size={34} />
            <h4>{tr("بارگذاری نسخه‌ها ناموفق بود")}</h4>
            <p>{error}</p>
            <button type="button" className="btn btn-primary btn-sm" onClick={reload}>{tr("تلاش دوباره")}</button>
          </div>
        )}

        {!error && (
          <div className="rxp-table-wrap">
            <table className="rxp-table">
              <thead>
                <tr>
                  <th>{tr("شماره نسخه")}</th>
                  <th>{tr("تاریخ")}</th>
                  <th>{tr("نام داکتر")}</th>
                  <th>{tr("تشخیص")}</th>
                  <th>{tr("تعداد دارو")}</th>
                  <th>{tr("وضعیت")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {loading && items.length === 0 && Array.from({ length: 5 }).map((_, i) => (
                  <tr key={`sk-${i}`} className="rxp-row-skeleton" aria-hidden="true">
                    {Array.from({ length: 7 }).map((__, j) => <td key={j}><span className="rxp-skeleton" /></td>)}
                  </tr>
                ))}
                {items.map((row) => {
                  const hp = highlightRowProps(row.id);
                  return (
                    <tr key={row.id} className={`rxp-row ${loading ? "is-loading" : ""} ${hp.className || ""}`} ref={hp.ref} onClick={() => setSelectedId(row.id)}>
                      <td data-label={tr("شماره نسخه")}><span className="rxp-rxnum">{row.rxNumber}</span></td>
                      <td data-label={tr("تاریخ")}>{fmtDate(row.createdAt)}</td>
                      <td data-label={tr("نام داکتر")}>{row.doctorName || "—"}</td>
                      <td data-label={tr("تشخیص")}><span className="prc-clip">{row.diagnosis || "—"}</span></td>
                      <td data-label={tr("تعداد دارو")}><span className="rxp-count" title={row.medicineNames || undefined}>{Number(row.itemCount).toLocaleString(numLocale())}</span></td>
                      <td data-label={tr("وضعیت")}><StatusBadge status={row.status} /></td>
                      <td data-label={tr("عملیات")} onClick={(e) => e.stopPropagation()}>
                        <div className="prc-actions">
                          <button type="button" className="btn btn-primary btn-sm" onClick={() => setSelectedId(row.id)}>
                            <Eye size={14} style={{ verticalAlign: "-2px" }} /> {tr("مشاهده نسخه")}
                          </button>
                          <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === `print-${row.id}`} onClick={() => printRx(row.id)}>
                            <Printer size={14} style={{ verticalAlign: "-2px" }} /> {tr("چاپ")}
                          </button>
                          <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === `pdf-${row.id}`} onClick={() => pdfRx(row.id)}>
                            <Download size={14} style={{ verticalAlign: "-2px" }} /> {tr("دانلود PDF")}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {!loading && items.length === 0 && (
              <div className="rxp-state">
                <ClipboardList size={38} />
                <h4>{emptyTitle}</h4>
                <p>{hasFilters ? tr("جستجو یا فیلترها را تغییر دهید.") : tr("نسخه‌هایی که داکتر برای شما می‌نویسد اینجا نمایش داده می‌شود.")}</p>
                {hasFilters && <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>{tr("پاک‌کردن فیلترها")}</button>}
              </div>
            )}
          </div>
        )}

        {!error && pagination && pagination.totalPages > 1 && (
          <div className="rxp-pagination">
            <button type="button" className="btn btn-ghost btn-sm" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>{tr("صفحه قبل")}</button>
            <span>{tr("صفحه {0} از {1} ({2} نسخه)", [pagination.page.toLocaleString(numLocale()), pagination.totalPages.toLocaleString(numLocale()), pagination.total.toLocaleString(numLocale())])}</span>
            <button type="button" className="btn btn-ghost btn-sm" disabled={page >= pagination.totalPages || loading} onClick={() => setPage(page + 1)}>{tr("صفحه بعد")}</button>
          </div>
        )}
      </div>

      <GlobalModal
        isOpen={selectedId != null}
        onClose={() => setSelectedId(null)}
        size="lg"
        title={tr("جزئیات نسخه")}
        className="rxp-modal"
      >
        {selectedId != null && (
          <PrescriptionDetailView
            id={selectedId}
            busyId={busyId}
            onPrint={() => printRx(selectedId)}
            onPdf={() => pdfRx(selectedId)}
          />
        )}
      </GlobalModal>
    </>
  );
}

// ---------- جزئیات یک نسخه ----------
export function PrescriptionDetailView({ id, busyId, onPrint, onPdf }) {
  const [rx, setRx] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    apiRequest(`/users/prescriptions/${id}/detail`)
      .then((d) => { if (!cancelled) setRx(d.prescription); })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [id, tick]);

  if (loading) {
    return (
      <div className="rxp-detail-loading" aria-busy="true">
        <span className="rxp-skeleton rxp-skeleton-block" />
        <span className="rxp-skeleton rxp-skeleton-block tall" />
      </div>
    );
  }
  if (error || !rx) {
    return (
      <div className="rxp-state rxp-state-error" role="alert">
        <AlertTriangle size={30} />
        <h4>{tr("بارگذاری نسخه ناموفق بود")}</h4>
        <p>{error || tr("نسخه یافت نشد")}</p>
        <button type="button" className="btn btn-primary btn-sm" onClick={() => setTick((t) => t + 1)}>{tr("تلاش دوباره")}</button>
      </div>
    );
  }

  return (
    <div className="rxp-detail" dir="rtl">
      <div className="rxp-detail-top">
        <div className="rxp-detail-meta">
          <span className="rxp-rxnum">{rx.rxNumber}</span>
          <StatusBadge status={rx.status} />
          <span>{tr("تاریخ نسخه:")} <b>{fmtDate(rx.createdAt)}</b></span>
          <span>{tr("داکتر:")} <b>{rx.doctorName || "—"}</b></span>
        </div>
        <div className="rxp-detail-actions">
          <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === `print-${id}`} onClick={onPrint}>
            <Printer size={14} style={{ verticalAlign: "-2px" }} /> {tr("چاپ")}
          </button>
          <button type="button" className="btn btn-primary btn-sm" disabled={busyId === `pdf-${id}`} onClick={onPdf}>
            <Download size={14} style={{ verticalAlign: "-2px" }} /> {tr("دانلود PDF")}
          </button>
        </div>
      </div>

      <section className="rxp-card rxp-block">
        <h4>{tr("تشخیص")}</h4>
        <p>{rx.diagnosis || tr("تشخیصی برای این نسخه ثبت نشده است.")}</p>
      </section>

      <section className="rxp-card rxp-block">
        <h4>{tr("داروهای نسخه ({0})", [rx.medicines.length.toLocaleString(numLocale())])}</h4>
        <div className="rxp-table-wrap">
          <table className="rxp-table rxp-table-compact">
            <thead>
              <tr><th>#</th><th>{tr("نام دارو")}</th><th>{tr("دوز")}</th><th>{tr("تعداد")}</th><th>{tr("مدت مصرف")}</th><th>{tr("نحوه مصرف")}</th><th>{tr("توضیحات")}</th></tr>
            </thead>
            <tbody>
              {rx.medicines.map((m, i) => (
                <tr key={m.id}>
                  <td data-label="#">{(i + 1).toLocaleString(numLocale())}</td>
                  <td data-label={tr("نام دارو")}><b>{m.medicationName}</b></td>
                  <td data-label={tr("دوز")}>{m.dosage || "—"}</td>
                  <td data-label={tr("تعداد")}>{m.quantity || "—"}</td>
                  <td data-label={tr("مدت مصرف")}>{m.duration || "—"}</td>
                  <td data-label={tr("نحوه مصرف")}>{m.frequency || "—"}</td>
                  <td data-label={tr("توضیحات")}>{m.medicineNotes || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <div className="rxp-info-grid">
        <section className="rxp-card rxp-block"><h4>{tr("دستور مصرف کلی")}</h4><p>{rx.instructions || "—"}</p></section>
        <section className="rxp-card rxp-block"><h4>{tr("توضیحات داکتر")}</h4><p>{rx.notes || "—"}</p></section>
      </div>
      {rx.followUpDate && <p className="rxp-muted">{tr("تاریخ پیگیری:")} <b>{fmtDate(rx.followUpDate)}</b></p>}
    </div>
  );
}

// ---------- بخش‌های سوابق (فقط نمایش) ----------
function EmrSection({ section, emr, onOpenLab }) {
  if (section === "encounters") {
    const list = emr.encounters || [];
    return (
      <RecordList title={tr("سوابق طبی من")} list={list} empty={tr("هیچ سابقه‌ی طبی برای شما ثبت نشده است.")}>
        {(r) => (
          <>
            <RecordHead title={r.doctorName || tr("بدون داکتر مشخص")} date={r.visitDate || r.createdAt} />
            {r.symptoms && <p><b>{tr("علائم:")}</b> {r.symptoms}</p>}
            {r.diagnosis && <p><b>{tr("تشخیص:")}</b> {r.diagnosis}</p>}
            {(r.bloodPressure || r.temperature || r.height || r.weight) && (
              <p>
                <b>{tr("علائم حیاتی:")}</b>{" "}
                {[r.bloodPressure && tr("فشار خون: {0}", [r.bloodPressure]), r.temperature && tr("حرارت: {0}", [r.temperature]), r.height && tr("قد: {0}", [r.height]), r.weight && tr("وزن: {0}", [r.weight])].filter(Boolean).join(" — ")}
              </p>
            )}
            {r.treatment && <p><b>{tr("تداوی:")}</b> {r.treatment}</p>}
            {r.notes && <p><b>{tr("یادداشت:")}</b> {r.notes}</p>}
          </>
        )}
      </RecordList>
    );
  }
  if (section === "diagnoses") {
    return (
      <RecordList title={tr("تشخیص‌های من")} list={emr.diagnoses || []} empty={tr("هیچ تشخیصی برای شما ثبت نشده است.")}>
        {(d) => (
          <>
            <RecordHead title={d.title} date={d.createdAt} badge={DIAGNOSIS_STATUS_LABEL[d.status] || d.status} />
            <p className="rxp-muted">{[d.doctorName, d.icdCode && `ICD: ${d.icdCode}`].filter(Boolean).join(" — ")}</p>
            {d.description && <p>{d.description}</p>}
          </>
        )}
      </RecordList>
    );
  }
  if (section === "labs") {
    return (
      <RecordList title={tr("نتایج آزمایش")} list={emr.labResults || []} empty={tr("نتیجه‌ی آزمایشِ تکمیل‌شده‌ای برای شما ثبت نشده است.")}>
        {(l) => (
          <>
            <RecordHead title={l.testName} date={l.testDate || l.createdAt} badge={LAB_STATUS_LABEL[l.status] || l.status} />
            <p>
              {l.result ? <><b>{tr("نتیجه:")}</b> {l.result}{l.unit ? ` ${l.unit}` : ""}</> : "—"}
              {l.referenceRange ? <> — <b>{tr("محدوده‌ی نرمال:")}</b> {l.referenceRange}</> : null}
            </p>
            {l.doctorName && <p className="rxp-muted">{tr("داکتر:")} {l.doctorName}</p>}
            {l.reportUrl && (
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => onOpenLab(l.id)}>
                <Download size={14} style={{ verticalAlign: "-2px" }} /> {tr("مشاهده / دانلود گزارش")}
              </button>
            )}
          </>
        )}
      </RecordList>
    );
  }
  if (section === "radiology") {
    return (
      <RecordList title={tr("رادیولوژی")} list={emr.radiologyReports || []} empty={tr("گزارش رادیولوژی‌ای برای شما ثبت نشده است.")}>
        {(r) => (
          <>
            <RecordHead title={r.examType} date={r.examDate || r.createdAt} />
            {r.findings && <p><b>{tr("یافته‌ها:")}</b> {r.findings}</p>}
            {r.impression && <p><b>{tr("نتیجه‌گیری:")}</b> {r.impression}</p>}
            {r.doctorName && <p className="rxp-muted">{tr("داکتر:")} {r.doctorName}</p>}
          </>
        )}
      </RecordList>
    );
  }
  return (
    <RecordList title={tr("حساسیت‌های ثبت‌شده")} list={emr.allergies || []} empty={tr("هیچ حساسیتی برای شما ثبت نشده است.")}>
      {(a) => (
        <>
          <RecordHead title={a.allergen} date={a.createdAt} badge={SEVERITY_LABEL[a.severity] || a.severity} />
          {a.reaction && <p><b>{tr("واکنش:")}</b> {a.reaction}</p>}
          {a.notes && <p>{a.notes}</p>}
          {a.doctorName && <p className="rxp-muted">{tr("ثبت‌کننده:")} {a.doctorName}</p>}
        </>
      )}
    </RecordList>
  );
}

function RecordHead({ title, date, badge }) {
  return (
    <div className="prc-rec-head">
      <strong>{title}</strong>
      <span className="prc-rec-meta">
        {badge && <span className="prc-chip">{badge}</span>}
        {fmtDate(date)}
      </span>
    </div>
  );
}

function RecordList({ title, list, empty, children }) {
  const { highlightRowProps } = useHighlightParam();
  return (
    <>
      <h3 className="prc-section-title">{title} <em>({list.length.toLocaleString(numLocale())})</em></h3>
      {list.length === 0 ? (
        <div className="rxp-state">
          <ClipboardList size={36} />
          <h4>{empty}</h4>
        </div>
      ) : (
        <ul className="prc-records">
          {list.map((item) => {
            const hp = highlightRowProps(item.id);
            return <li key={item.id} className={`prc-rec ${hp.className || ""}`} ref={hp.ref}>{children(item)}</li>;
          })}
        </ul>
      )}
    </>
  );
}

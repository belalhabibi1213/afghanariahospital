import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { MemoryRouter } from "react-router-dom";

vi.mock("../../utils/api.js", () => ({ apiRequest: vi.fn(), apiDownload: vi.fn(), apiFetchImageUrl: vi.fn(async () => null) }));
import { apiRequest } from "../../utils/api.js";
import PatientRecordsPanel from "./PatientRecordsPanel.jsx";

const RX_DOC = { type: "prescription", id: 5, number: "RX-000005", date: "2026-10-03T08:00:00Z", title: "سرماخوردگی", doctorName: "داکتر صمدی", status: "active", itemCount: 2 };
const REC_DOC = { type: "record", id: 9, number: "MR-000009", date: "2026-10-01T00:00:00Z", title: "آنژین", doctorName: "داکتر صمدی", released: true };

// شبیه‌ساز سرور: نوع/جستجو/صفحه‌بندی را همان‌طور که بک‌اند انجام می‌دهد اعمال می‌کند
function fakeServer(all) {
  return async (url) => {
    if (!url.startsWith("/users/documents")) return {};
    const usp = new URLSearchParams(url.split("?")[1]);
    const type = usp.get("type") || "";
    const q = (usp.get("q") || "").toLowerCase();
    const page = Number(usp.get("page") || 1);
    const limit = Number(usp.get("limit") || 10);
    const filtered = all.filter((d) => (!type || d.type === type) && (!q || `${d.number} ${d.title} ${d.doctorName}`.toLowerCase().includes(q)));
    return {
      documents: filtered.slice((page - 1) * limit, page * limit),
      counts: { prescription: all.filter((d) => d.type === "prescription").length, record: all.filter((d) => d.type === "record").length },
      pagination: { total: filtered.length, page, limit, totalPages: Math.max(1, Math.ceil(filtered.length / limit)) },
    };
  };
}

beforeEach(() => { apiRequest.mockReset(); });

describe("PatientRecordsPanel — همه اسناد", () => {
  it("نسخه و پرونده صحی هر دو در یک فهرست نمایش داده می‌شوند و فیلتر نوع از سرور خوانده می‌شود", async () => {
    apiRequest.mockImplementation(fakeServer([RX_DOC, REC_DOC]));
    render(<MemoryRouter><PatientRecordsPanel /></MemoryRouter>);
    expect(await screen.findByText("RX-000005")).toBeInTheDocument();
    expect(screen.getByText("MR-000009")).toBeInTheDocument();
    expect(screen.getByText("آنژین")).toBeInTheDocument();
    await userEvent.click(screen.getByRole("tab", { name: /پرونده‌های صحی/ }));
    await waitFor(() => expect(screen.queryByText("RX-000005")).not.toBeInTheDocument());
    expect(screen.getByText("MR-000009")).toBeInTheDocument();
    expect(apiRequest.mock.calls.some(([u]) => u.startsWith("/users/documents") && u.includes("type=record"))).toBe(true);
    expect(screen.queryByRole("button", { name: /افزودن|ویرایش|حذف/ })).not.toBeInTheDocument();
  });

  it("صفحه‌بندی و جستجو سمت سرور انجام می‌شود (نه فیلتر کلاینت) و شناسه‌ی بیمار فرستاده نمی‌شود", async () => {
    const many = Array.from({ length: 23 }, (_, i) => ({ ...RX_DOC, id: i + 1, number: `RX-${String(i + 1).padStart(6, "0")}`, title: i === 14 ? "تشخیص ویژه" : "عمومی" }));
    apiRequest.mockImplementation(fakeServer(many));
    render(<MemoryRouter><PatientRecordsPanel /></MemoryRouter>);
    expect(await screen.findByText("RX-000001")).toBeInTheDocument();
    expect(screen.queryByText("RX-000011")).not.toBeInTheDocument(); // فقط ۱۰ ردیف در هر صفحه
    await userEvent.click(screen.getByRole("button", { name: "صفحه بعد" }));
    expect(await screen.findByText("RX-000011")).toBeInTheDocument();
    expect(apiRequest.mock.calls.some(([u]) => u.includes("page=2"))).toBe(true);

    await userEvent.type(screen.getByLabelText("جستجوی اسناد"), "ویژه");
    expect(await screen.findByText("RX-000015")).toBeInTheDocument();
    await waitFor(() => expect(screen.queryByText("RX-000011")).not.toBeInTheDocument());
    const urls = apiRequest.mock.calls.map(([u]) => u).filter((u) => u.startsWith("/users/documents"));
    expect(urls.some((u) => u.includes("q="))).toBe(true);
    expect(urls.every((u) => !/patientId|userId|doctorId/.test(u))).toBe(true);
    expect(urls.every((u) => !u.startsWith("/users/health-records") && !u.startsWith("/users/prescription-list"))).toBe(true);
  });
});

import { useEffect, useMemo, useRef, useState } from "react";
import {
  Search, Eye, Trash2, ChevronRight, ChevronLeft, CalendarDays, Clock, CircleCheck, CircleX,
  FileText, FileSpreadsheet, RotateCcw, Phone, Stethoscope, Building2, History,
} from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import { apiRequest } from "../../utils/api.js";
import useHighlightParam from "../../hooks/useHighlightParam.js";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, numLocale, MONTH_NAMES, WEEKDAY_NAMES, jdate, tdigits, curDir } from "../../i18n/tr.js";
// ============================================================================
// مدیریت نوبت‌ها (Admin Dashboard) — رابط حرفه‌ای‌شده
// فقط لایه‌ی UI تغییر کرده است؛ همه‌ی داده‌ها از APIهای موجود می‌آیند:
//   GET    /admin/appointments            (فیلتر + صفحه‌بندی)
//   PUT    /admin/appointments/:id/status (تغییر وضعیت / لغو)
//   DELETE /admin/appointments/:id        (حذف)
//   GET    /admin/appointments/:id/history (تاریخچه‌ی وضعیت)
//   GET    /admin/reports                 (آمار: نوبت‌های امروز و تفکیک وضعیت)
//   GET    /admin/departments, /admin/doctors (گزینه‌های فیلتر)
// ============================================================================

const STATUS_LABEL = trc({ pending: "در انتظار", confirmed: "تایید شده", completed: "انجام‌شده", cancelled: "لغوشده" });
const PAGE_SIZE = 10;
const CAL_PAGE_LIMIT = 100; // سقف limit در بک‌اند
const CAL_MAX_PAGES = 10; // حداکثر ۱۰۰۰ نوبت برای تقویم
const DEFAULT_HOUR_FROM = 8;
const DEFAULT_HOUR_TO = 16;

// ---------- ابزارهای تاریخ (شمسی با Intl، شروع هفته: شنبه) ----------
const faDigits = (v) => tdigits(String(v ?? ""));
const hhmm = (v) => (v ? String(v).slice(0, 5) : "");
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const noon = (d) => { const x = new Date(d); x.setHours(12, 0, 0, 0); return x; };
const dayIndex = (d) => (d.getDay() + 1) % 7; // شنبه = ۰
const weekStart = (d) => addDays(noon(d), -dayIndex(d));
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
const pad2 = (n) => String(n).padStart(2, "0");
const toKey = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
const fromKey = (k) => { const [y, m, d] = String(k).slice(0, 10).split("-").map(Number); return new Date(y, m - 1, d, 12); };
const faFmt = (d, opts) => new Intl.DateTimeFormat(numLocale(), opts).format(d);
const jalali = (d) => {
  const parts = new Intl.DateTimeFormat("en-US-u-ca-persian", { year: "numeric", month: "numeric", day: "numeric" }).formatToParts(d);
  const g = (t) => Number(parts.find((p) => p.type === t)?.value);
  return { y: g("year"), m: g("month"), d: g("day") };
};
// نام ماه‌ها/روزهای هفته از ماژول مرکزی jalali.js (حمل … حوت)
const dateLong = (d) => jdate(d, { month: "long" });
const dateShort = (d) => jdate(d, { month: "short" });
const weekdayName = (d) => WEEKDAY_NAMES[(d.getDay() + 1) % 7];
const monthTitle = (d) => { const j = jalali(d); return `${MONTH_NAMES[j.m - 1]} ${tdigits(j.y)}`; };
const fmtDateKey = (k) => (k ? dateLong(fromKey(k)) : "—");

function monthStart(d) {
  let s = noon(d);
  while (jalali(s).d > 1) s = addDays(s, -1);
  return s;
}
function nextMonthStart(d) { return monthStart(addDays(monthStart(d), 32)); }
function prevMonthStart(d) { return monthStart(addDays(monthStart(d), -1)); }
// همه‌ی روزهای شبکه‌ی ماه (از شنبه‌ی هفته‌ی اول تا جمعه‌ی هفته‌ی آخر) + مرز ماه جاری
function monthGrid(anchor) {
  const first = monthStart(anchor);
  const next = nextMonthStart(anchor);
  const lastDay = addDays(next, -1);
  const gridStart = weekStart(first);
  const gridEnd = addDays(weekStart(lastDay), 6);
  const days = [];
  for (let c = gridStart; c <= gridEnd; c = addDays(c, 1)) days.push(c);
  return { first, lastDay, gridStart, gridEnd, days };
}

function buildQuery(params) {
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") usp.set(k, v);
  });
  const qs = usp.toString();
  return qs ? `?${qs}` : "";
}

function useDebounced(value, delay = 400) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return v;
}

function StatusBadge({ status, className = "" }) {
  return <span className={`am-badge is-${status} ${className}`}>{STATUS_LABEL[status] || status}</span>;
}

// ---------- یک نوبت داخل تقویم ----------
function CalChip({ a, onOpen, showDept = false }) {
  return (
    <button type="button" className={`am-chip is-${a.status}`} onClick={() => onOpen(a)} title={`${a.patientName} — ${a.doctorName} — ${faDigits(hhmm(a.appointmentTime))}`}>
      <span className="am-chip-name">{a.patientName}</span>
      <span className="am-chip-sub">{a.doctorName}</span>
      <span className="am-chip-meta">
        <span className="am-chip-time">{faDigits(hhmm(a.appointmentTime))}</span>
        {showDept && <span className="am-chip-dept">{a.department}</span>}
        <span className="am-chip-status">{STATUS_LABEL[a.status] || a.status}</span>
      </span>
    </button>
  );
}

export default function AppointmentsManagement() {
  const { highlightRowProps } = useHighlightParam();
  const today = useMemo(() => noon(new Date()), []);

  // ---- فیلترها (مشترک بین تقویم و جدول، به‌جز بازه‌ی تاریخ که فقط برای جدول است) ----
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("");
  const [doctorFilter, setDoctorFilter] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const debouncedSearch = useDebounced(search);
  const [page, setPage] = useState(1);

  // ---- تقویم ----
  const [view, setView] = useState("week"); // day | week | month
  const [anchor, setAnchor] = useState(today);

  // ---- داده‌ها ----
  const [departments, setDepartments] = useState([]);
  const [doctors, setDoctors] = useState([]);
  const [stats, setStats] = useState(null);
  const [statsFailed, setStatsFailed] = useState(false);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [listLoading, setListLoading] = useState(true);
  const [calItems, setCalItems] = useState([]);
  const [calLoading, setCalLoading] = useState(true);
  const [calTruncated, setCalTruncated] = useState(false);
  const [error, setError] = useState("");
  const [tick, setTick] = useState(0); // با هر تغییر (وضعیت/حذف) همه‌ی بخش‌ها دوباره بارگذاری می‌شوند

  // ---- پنل جزئیات و عملیات ----
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [drawerError, setDrawerError] = useState("");
  const [exporting, setExporting] = useState(false);
  const tableRef = useRef(null);

  const reloadAll = () => setTick((t) => t + 1);

  // گزینه‌های فیلتر — همان APIهای قبلی
  useEffect(() => {
    apiRequest("/admin/departments").then((d) => setDepartments(d.departments || [])).catch(() => {});
    apiRequest("/admin/doctors").then((d) => setDoctors(d.doctors || [])).catch(() => {});
  }, []);

  // کارت‌های آماری — از همان API گزارش‌ها (بدون داده‌ی ساختگی)
  useEffect(() => {
    let cancelled = false;
    apiRequest("/admin/reports")
      .then((d) => { if (!cancelled) { setStats(d); setStatsFailed(false); } })
      .catch(() => { if (!cancelled) setStatsFailed(true); });
    return () => { cancelled = true; };
  }, [tick]);

  const sharedFilters = useMemo(
    () => ({ status: statusFilter, department: departmentFilter, doctorId: doctorFilter, q: debouncedSearch }),
    [statusFilter, departmentFilter, doctorFilter, debouncedSearch]
  );
  const sharedKey = JSON.stringify(sharedFilters);

  useEffect(() => setPage(1), [sharedKey, dateFrom, dateTo]);

  // ---- لیست (جدول) ----
  const listKey = JSON.stringify([sharedFilters, dateFrom, dateTo, page]);
  useEffect(() => {
    let cancelled = false;
    setListLoading(true);
    apiRequest(`/admin/appointments${buildQuery({ ...sharedFilters, dateFrom, dateTo, page, limit: PAGE_SIZE })}`)
      .then((data) => {
        if (cancelled) return;
        setItems(data.appointments || []);
        setPagination(data.pagination || null);
        setError("");
      })
      .catch((err) => { if (!cancelled) setError(err.message || tr("خطا در دریافت نوبت‌ها")); })
      .finally(() => { if (!cancelled) setListLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [listKey, tick]);

  // ---- داده‌ی تقویم: همه‌ی نوبت‌های شبکه‌ی ماهِ تاریخ انتخاب‌شده (روزانه/هفتهٔ همان ماه هم داخل آن است) ----
  const grid = useMemo(() => monthGrid(anchor), [anchor]);
  const gridFromKey = toKey(grid.gridStart);
  const gridToKey = toKey(grid.gridEnd);
  useEffect(() => {
    let cancelled = false;
    setCalLoading(true);
    (async () => {
      const all = [];
      let p = 1;
      let totalPages = 1;
      do {
        const data = await apiRequest(`/admin/appointments${buildQuery({ ...sharedFilters, dateFrom: gridFromKey, dateTo: gridToKey, page: p, limit: CAL_PAGE_LIMIT })}`);
        all.push(...(data.appointments || []));
        totalPages = data.pagination?.totalPages || 1;
        p += 1;
      } while (p <= totalPages && p <= CAL_MAX_PAGES);
      if (!cancelled) {
        setCalItems(all);
        setCalTruncated(totalPages > CAL_MAX_PAGES);
      }
    })()
      .catch((err) => { if (!cancelled) setError(err.message || tr("خطا در دریافت اطلاعات تقویم")); })
      .finally(() => { if (!cancelled) setCalLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sharedKey, gridFromKey, gridToKey, tick]);

  const byDay = useMemo(() => {
    const map = new Map();
    calItems.forEach((a) => {
      const k = String(a.appointmentDate).slice(0, 10);
      if (!map.has(k)) map.set(k, []);
      map.get(k).push(a);
    });
    map.forEach((list) => list.sort((x, y) => String(x.appointmentTime).localeCompare(String(y.appointmentTime))));
    return map;
  }, [calItems]);

  // ---- جزئیات نوبت ----
  function openDetails(a) {
    setSelected(a);
    setDrawerError("");
    setHistory([]);
    setHistoryLoading(true);
    apiRequest(`/admin/appointments/${a.id}/history`)
      .then((d) => setHistory(d.history || []))
      .catch(() => setHistory([]))
      .finally(() => setHistoryLoading(false));
  }
  function closeDetails() { setSelected(null); setDrawerError(""); }

  async function changeStatus(a, status) {
    if (!a || status === a.status) return;
    setBusy(true);
    setDrawerError("");
    try {
      await apiRequest(`/admin/appointments/${a.id}/status`, { method: "PUT", body: { status } });
      if (selected && selected.id === a.id) {
        setSelected({ ...selected, status });
        apiRequest(`/admin/appointments/${a.id}/history`).then((d) => setHistory(d.history || [])).catch(() => {});
      }
      reloadAll();
    } catch (err) {
      const msg = err.message || tr("تغییر وضعیت انجام نشد");
      if (selected) setDrawerError(msg); else setError(msg);
    } finally {
      setBusy(false);
    }
  }

  async function confirmDelete() {
    if (!deleting) return;
    setBusy(true);
    try {
      await apiRequest(`/admin/appointments/${deleting.id}`, { method: "DELETE" });
      if (selected && selected.id === deleting.id) closeDetails();
      setDeleting(null);
      reloadAll();
    } catch (err) {
      setError(err.message || tr("حذف نوبت انجام نشد"));
      setDeleting(null);
    } finally {
      setBusy(false);
    }
  }

  // ---- خروجی‌ها (همان منطق قبلی: نوبت‌های صفحه‌ی جاری لیست) ----
  async function exportToPDF() {
    if (!tableRef.current || items.length === 0) return;
    setExporting(true);
    try {
      // یک فریم صبر می‌کنیم تا کلاس is-exporting (نسخه‌ی روشن و بدون ستون عملیات) روی جدول اعمال شود
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
      const canvas = await html2canvas(tableRef.current, { scale: 2, backgroundColor: "#ffffff" });
      const imgData = canvas.toDataURL("image/png");
      const pdf = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const imgWidth = pageWidth - 40;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 20;
      pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
      heightLeft -= pageHeight - 40;
      while (heightLeft > 0) {
        position = heightLeft - imgHeight + 20;
        pdf.addPage();
        pdf.addImage(imgData, "PNG", 20, position, imgWidth, imgHeight);
        heightLeft -= pageHeight - 40;
      }
      pdf.save(`appointments-${Date.now()}.pdf`);
    } catch {
      setError(tr("خطا در ساخت فایل PDF"));
    } finally {
      setExporting(false);
    }
  }

  async function exportToExcel() {
    if (items.length === 0) return;
    setExporting(true);
    try {
      const { downloadXlsx } = await import("../../utils/exportXlsx.js");
      const rows = items.map((a) => ({
        "شماره نوبت": a.id,
        "بیمار": a.patientName,
        "شماره تماس": a.patientPhone || "",
        "داکتر": a.doctorName,
        "بخش": a.department,
        "تاریخ": `${jdate(a.appointmentDate, { latin: true })} - ${hhmm(a.appointmentTime)}`,
        "وضعیت": STATUS_LABEL[a.status] || a.status,
      }));
      await downloadXlsx(`appointments-${Date.now()}.xlsx`, [{ name: "نوبت‌ها", rows }]);
    } catch {
      setError(tr("خطا در ساخت فایل Excel"));
    } finally {
      setExporting(false);
    }
  }

  // ---- کارت‌های آماری ----
  const statusCount = (s) => {
    const row = (stats?.appointmentsByStatus || []).find((r) => r.status === s);
    return Number(row?.count) || 0;
  };
  const todayKey = toKey(today);
  const isTodayFilter = dateFrom === todayKey && dateTo === todayKey;
  const kpis = [
    { key: "today", label: tr("نوبت‌های امروز"), icon: CalendarDays, tone: "today", value: stats ? Number(stats.todayAppointments) || 0 : null, active: isTodayFilter,
      onClick: () => { if (isTodayFilter) { setDateFrom(""); setDateTo(""); } else { setDateFrom(todayKey); setDateTo(todayKey); } } },
    { key: "completed", label: tr("نوبت‌های انجام‌شده"), icon: CircleCheck, tone: "completed", value: stats ? statusCount("completed") : null, active: statusFilter === "completed",
      onClick: () => setStatusFilter((s) => (s === "completed" ? "" : "completed")) },
    { key: "pending", label: tr("نوبت‌های در انتظار"), icon: Clock, tone: "pending", value: stats ? statusCount("pending") : null, active: statusFilter === "pending",
      onClick: () => setStatusFilter((s) => (s === "pending" ? "" : "pending")) },
    { key: "cancelled", label: tr("نوبت‌های لغوشده"), icon: CircleX, tone: "cancelled", value: stats ? statusCount("cancelled") : null, active: statusFilter === "cancelled",
      onClick: () => setStatusFilter((s) => (s === "cancelled" ? "" : "cancelled")) },
  ];

  const hasFilters = !!(search || statusFilter || departmentFilter || doctorFilter || dateFrom || dateTo);
  function clearFilters() {
    setSearch(""); setStatusFilter(""); setDepartmentFilter(""); setDoctorFilter(""); setDateFrom(""); setDateTo("");
  }

  // ---- ناوبری تقویم ----
  function shift(dir) {
    if (view === "day") setAnchor((a) => addDays(a, dir));
    else if (view === "week") setAnchor((a) => addDays(a, dir * 7));
    else setAnchor((a) => (dir > 0 ? nextMonthStart(a) : prevMonthStart(a)));
  }
  function openDay(d) { setAnchor(noon(d)); setView("day"); }

  const wStart = weekStart(anchor);
  const weekDays = useMemo(() => Array.from({ length: 7 }, (_, i) => addDays(wStart, i)), [wStart.getTime()]); // eslint-disable-line react-hooks/exhaustive-deps
  const calTitle = view === "day"
    ? `${weekdayName(anchor)} ${dateLong(anchor)}`
    : view === "week"
      ? tr("{0} تا {1} {2}", [dateShort(weekDays[0]), dateShort(weekDays[6]), faFmt(weekDays[6], { year: "numeric" })])
      : monthTitle(anchor);

  // بازه‌ی ساعت‌های نمایشی در حالت روزانه/هفتگی (بر اساس نوبت‌های واقعی همان بازه)
  const visibleKeys = view === "day" ? [toKey(anchor)] : weekDays.map(toKey);
  const hours = useMemo(() => {
    let lo = DEFAULT_HOUR_FROM;
    let hi = DEFAULT_HOUR_TO;
    visibleKeys.forEach((k) => (byDay.get(k) || []).forEach((a) => {
      const h = Number(String(a.appointmentTime).slice(0, 2));
      if (Number.isFinite(h)) { lo = Math.min(lo, h); hi = Math.max(hi, h); }
    }));
    return Array.from({ length: hi - lo + 1 }, (_, i) => lo + i);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [byDay, view, anchor.getTime()]);

  const cellItems = (key, h) => (byDay.get(key) || []).filter((a) => Number(String(a.appointmentTime).slice(0, 2)) === h);
  const hourLabel = (h) => faDigits(`${pad2(h)}:00`);

  // ---- تقویم کوچک ----
  const miniDays = grid.days.filter((d) => d >= grid.first && d <= grid.lastDay);
  const lead = dayIndex(grid.first);
  const WEEK_LETTERS = [tr("ش"), tr("ی"), tr("د"), tr("س"), tr("چ"), tr("پ"), tr("ج")];

  const visibleTotal = visibleKeys.reduce((n, k) => n + (byDay.get(k) || []).length, 0);

  return (
    <div className="am-page">
      {/* ---------- سربرگ ---------- */}
      <div className="am-head">
        <div className="am-head-title">
          <span className="am-head-icon"><CalendarDays size={22} /></span>
          <div>
            <h2>{tr("مدیریت نوبت‌ها")}</h2>
            <p>{tr("مدیریت و پیگیری نوبت‌های بیماران و وقت داکتران")}</p>
          </div>
        </div>
        <div className="am-head-actions">
          <button type="button" className="btn btn-ghost btn-sm" disabled={exporting || items.length === 0} onClick={exportToPDF}>
            <FileText size={15} /> {exporting ? tr("در حال آماده‌سازی...") : tr("خروجی PDF")}
          </button>
          <button type="button" className="btn btn-ghost btn-sm" disabled={exporting || items.length === 0} onClick={exportToExcel}>
            <FileSpreadsheet size={15} />{" "}{tr("خروجی Excel")}</button>
        </div>
      </div>

      {error && <div className="form-message error" role="alert">{error}</div>}

      {/* ---------- کارت‌های آماری ---------- */}
      <div className="am-kpis">
        {kpis.map((k) => {
          const Icon = k.icon;
          return (
            <button key={k.key} type="button" className={`am-kpi tone-${k.tone}${k.value === null ? " is-loading" : ""}`} aria-pressed={k.active} onClick={k.onClick}>
              <span className="am-kpi-icon"><Icon size={20} /></span>
              <span className="am-kpi-body">
                <span className="am-kpi-label">{k.label}</span>
                <span className="am-kpi-num">{k.value === null ? (statsFailed ? "—" : "…") : k.value.toLocaleString(numLocale())}</span>
              </span>
            </button>
          );
        })}
      </div>

      {/* ---------- جستجو و فیلتر ---------- */}
      <div className="am-toolbar">
        <div className="am-search">
          <Search size={16} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tr("جستجوی نام بیمار، نام داکتر، بخش، تاریخ یا شماره تماس")}
            aria-label={tr("جستجوی نوبت‌ها")}
          />
        </div>
        <label className="am-filter">
          <span>{tr("داکتر")}</span>
          <select value={doctorFilter} onChange={(e) => setDoctorFilter(e.target.value)}>
            <option value="">{tr("همه داکتران")}</option>
            {doctors.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
          </select>
        </label>
        <label className="am-filter">
          <span>{tr("بخش")}</span>
          <select value={departmentFilter} onChange={(e) => setDepartmentFilter(e.target.value)}>
            <option value="">{tr("همه بخش‌ها")}</option>
            {departments.map((dep) => <option key={dep.id} value={dep.name}>{dep.name}</option>)}
          </select>
        </label>
        <label className="am-filter">
          <span>{tr("وضعیت نوبت")}</span>
          <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
            <option value="">{tr("همه وضعیت‌ها")}</option>
            {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </label>
        <label className="am-filter am-filter-date">
          <span>{tr("از تاریخ")}</span>
          <JalaliDateInput value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
        </label>
        <label className="am-filter am-filter-date">
          <span>{tr("تا تاریخ")}</span>
          <JalaliDateInput value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
        </label>
        <button type="button" className="btn btn-ghost btn-sm am-clear" onClick={clearFilters} disabled={!hasFilters}>
          <RotateCcw size={14} />{" "}{tr("پاک کردن فیلترها")}</button>
      </div>

      {/* ---------- تقویم ---------- */}
      <div className="am-calendar-layout">
        <div className="am-mini" role="region" aria-label={tr("تقویم کوچک")}>
          <div className="am-mini-head">
            <button type="button" className="am-iconbtn" aria-label={tr("ماه قبل")} onClick={() => setAnchor(prevMonthStart(anchor))}><ChevronRight size={16} /></button>
            <strong>{monthTitle(anchor)}</strong>
            <button type="button" className="am-iconbtn" aria-label={tr("ماه بعد")} onClick={() => setAnchor(nextMonthStart(anchor))}><ChevronLeft size={16} /></button>
          </div>
          <div className="am-mini-grid">
            {WEEK_LETTERS.map((w) => <span key={w} className="am-mini-wd">{w}</span>)}
            {Array.from({ length: lead }, (_, i) => <span key={`b${i}`} />)}
            {miniDays.map((d) => {
              const k = toKey(d);
              const n = (byDay.get(k) || []).length;
              const cls = ["am-mini-day", sameDay(d, today) ? "is-today" : "", sameDay(d, anchor) ? "is-selected" : "", n ? "has-appts" : ""].filter(Boolean).join(" ");
              return (
                <button key={k} type="button" className={cls} onClick={() => setAnchor(noon(d))} title={n ? tr("{0} نوبت", [n.toLocaleString(numLocale())]) : undefined} aria-label={`${dateLong(d)}${n ? tr("، {0} نوبت", [n.toLocaleString(numLocale())]) : ""}`} aria-current={sameDay(d, anchor) ? "date" : undefined}>
                  {jalali(d).d.toLocaleString(numLocale())}
                </button>
              );
            })}
          </div>
          <div className="am-legend">
            <span className="am-legend-title">{tr("راهنمای وضعیت")}</span>
            {Object.entries(STATUS_LABEL).map(([k, v]) => (
              <span key={k} className="am-legend-item"><i className={`am-dot is-${k}`} /> {v}</span>
            ))}
            <span className="am-legend-note"><i className="am-mini-dot" />{" "}{tr("روز دارای نوبت")}</span>
          </div>
        </div>

        <div className="am-cal" role="region" aria-label={tr("تقویم نوبت‌ها")}>
          <div className="am-cal-head">
            <div className="am-cal-nav">
              <button type="button" className="am-iconbtn" aria-label={tr("قبلی")} onClick={() => shift(-1)}><ChevronRight size={16} /></button>
              <button type="button" className="am-iconbtn" aria-label={tr("بعدی")} onClick={() => shift(1)}><ChevronLeft size={16} /></button>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setAnchor(today)}>{tr("امروز")}</button>
              <strong className="am-cal-title">{calTitle}</strong>
            </div>
            <div className="am-seg" role="tablist" aria-label={tr("نوع نمایش تقویم")}>
              {[["day", tr("روزانه")], ["week", tr("هفتگی")], ["month", tr("ماهانه")]].map(([k, l]) => (
                <button key={k} type="button" role="tab" aria-selected={view === k} className={view === k ? "is-on" : ""} onClick={() => setView(k)}>{l}</button>
              ))}
            </div>
          </div>

          {calTruncated && <div className="am-note">{tr("تعداد نوبت‌های این ماه زیاد است؛ فقط بخشی از آن‌ها در تقویم نمایش داده می‌شود. برای دیدن بقیه از فیلترها یا جدول پایین استفاده کنید.")}</div>}

          <div className={`am-cal-body${calLoading ? " is-busy" : ""}`}>
            {view === "week" && (
              <div className="am-scroll">
                <div className="am-week">
                  <div className="am-week-corner" />
                  {weekDays.map((d) => (
                    <button key={toKey(d)} type="button" className={`am-week-dayhead${sameDay(d, today) ? " is-today" : ""}${sameDay(d, anchor) ? " is-selected" : ""}`} onClick={() => openDay(d)} title={tr("نمایش روزانه")}>
                      <span>{weekdayName(d)}</span>
                      <small>{dateShort(d)}</small>
                    </button>
                  ))}
                  {hours.map((h) => (
                    <WeekRow key={h} h={h} label={hourLabel(h)} days={weekDays} today={today} cellItems={cellItems} onOpen={openDetails} onMore={openDay} />
                  ))}
                </div>
              </div>
            )}

            {view === "day" && (
              <div className="am-day">
                {hours.map((h) => {
                  const list = cellItems(toKey(anchor), h);
                  return (
                    <div key={h} className="am-day-row">
                      <div className="am-hour">{hourLabel(h)}</div>
                      <div className="am-day-cell">
                        {list.length === 0 ? <span className="am-empty-slot">—</span> : list.map((a) => <CalChip key={a.id} a={a} onOpen={openDetails} showDept />)}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {view === "month" && (
              <div className="am-scroll">
                <div className="am-month">
                  {WEEK_LETTERS.map((w, i) => <div key={w} className="am-month-wd">{weekdayName(addDays(grid.gridStart, i))}</div>)}
                  {grid.days.map((d) => {
                    const k = toKey(d);
                    const list = byDay.get(k) || [];
                    const inMonth = d >= grid.first && d <= grid.lastDay;
                    return (
                      <div key={k} className={`am-month-cell${inMonth ? "" : " is-out"}${sameDay(d, today) ? " is-today" : ""}`}>
                        <button type="button" className="am-month-num" onClick={() => openDay(d)} aria-label={tr("نمایش روزانه {0}", [dateLong(d)])}>
                          {jalali(d).d.toLocaleString(numLocale())}
                          {list.length > 0 && <em>{list.length.toLocaleString(numLocale())}</em>}
                        </button>
                        {list.slice(0, 2).map((a) => (
                          <button key={a.id} type="button" className={`am-mini-chip is-${a.status}`} onClick={() => openDetails(a)} title={`${a.patientName} — ${a.doctorName}`}>
                            <b>{faDigits(hhmm(a.appointmentTime))}</b> {a.patientName}
                          </button>
                        ))}
                        {list.length > 2 && <button type="button" className="am-more" onClick={() => openDay(d)}>{tr("+{0} نوبت دیگر", [(list.length - 2).toLocaleString(numLocale())])}</button>}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {!calLoading && view !== "month" && visibleTotal === 0 && (
              <div className="am-cal-empty">{tr("در این {0} نوبتی با فیلترهای فعلی ثبت نشده است.", [view === "day" ? tr("روز") : tr("هفته")])}</div>
            )}
          </div>
        </div>
      </div>

      {/* ---------- لیست نوبت‌ها ---------- */}
      <div className="am-listwrap">
        <div className="am-list-head">
          <h3>{tr("لیست نوبت‌ها")}</h3>
          {pagination && <span className="am-muted">{tr("{0} نوبت", [pagination.total.toLocaleString(numLocale())])}</span>}
        </div>
        {listLoading && items.length === 0 ? (
          <div className="am-skels" aria-busy="true">
            {Array.from({ length: 5 }, (_, i) => <div key={i} className="am-skel" />)}
          </div>
        ) : items.length === 0 ? (
          <div className="am-state">
            <strong>{tr("هیچ نوبتی با این مشخصات یافت نشد.")}</strong>
            {hasFilters && <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button>}
          </div>
        ) : (
          <div className={`am-tablescroll${listLoading ? " is-busy" : ""}`}>
            <table className={`am-table${exporting ? " is-exporting" : ""}`} ref={tableRef} dir={curDir()}>
              <thead>
                <tr>
                  <th>{tr("شماره نوبت")}</th><th>{tr("بیمار")}</th><th>{tr("داکتر")}</th><th>{tr("بخش")}</th><th>{tr("تاریخ")}</th><th>{tr("ساعت")}</th><th>{tr("وضعیت")}</th><th className="am-noprint">{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {items.map((a) => {
                  const hl = highlightRowProps(a.id);
                  return (
                    <tr key={a.id} ref={hl.ref} className={`${hl.className || ""}${selected?.id === a.id ? " is-selected" : ""}`}>
                      <td data-label={tr("شماره نوبت")} className="am-num">#{a.id.toLocaleString(numLocale(), { useGrouping: false })}</td>
                      <td data-label={tr("بیمار")}>
                        <span className="am-strong">{a.patientName}</span>
                        {a.patientPhone && <span className="am-sub am-ltr">{a.patientPhone}</span>}
                      </td>
                      <td data-label={tr("داکتر")}>{a.doctorName}</td>
                      <td data-label={tr("بخش")}>{a.department}</td>
                      <td data-label={tr("تاریخ")}>
                        <span>{fmtDateKey(String(a.appointmentDate).slice(0, 10))}</span>
                        <span className="am-sub am-ltr">{jdate(a.appointmentDate)}</span>
                      </td>
                      <td data-label={tr("ساعت")} className="am-num">{faDigits(hhmm(a.appointmentTime))}</td>
                      <td data-label={tr("وضعیت")}><StatusBadge status={a.status} /></td>
                      <td data-label={tr("عملیات")} className="am-noprint">
                        <div className="am-actions">
                          <button type="button" className="am-iconbtn" title={tr("مشاهده جزئیات")} aria-label={tr("مشاهده نوبت {0}", [a.patientName])} onClick={() => openDetails(a)}><Eye size={16} /></button>
                          <select
                            className={`am-statusselect is-${a.status}`}
                            value={a.status}
                            disabled={busy}
                            aria-label={tr("تغییر وضعیت نوبت {0}", [a.patientName])}
                            onChange={(e) => changeStatus(a, e.target.value)}
                          >
                            {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
                          </select>
                          <button type="button" className="am-iconbtn is-danger" title={tr("حذف نوبت")} aria-label={tr("حذف نوبت {0}", [a.patientName])} onClick={() => setDeleting(a)}><Trash2 size={16} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {pagination && pagination.totalPages > 1 && (
          <div className="am-pager">
            <span>{tr("صفحه {0} از {1} (مجموع {2} نتیجه)", [pagination.page.toLocaleString(numLocale()), pagination.totalPages.toLocaleString(numLocale()), pagination.total.toLocaleString(numLocale())])}</span>
            <div className="am-pages">
              <button type="button" className="am-pagebtn" disabled={page <= 1} onClick={() => setPage(page - 1)}>{tr("صفحه قبل")}</button>
              <button type="button" className="am-pagebtn" disabled={page >= pagination.totalPages} onClick={() => setPage(page + 1)}>{tr("صفحه بعد")}</button>
            </div>
          </div>
        )}
      </div>

      {/* ---------- پنل جزئیات (مودال وسط صفحه) ---------- */}
      <GlobalModal
        isOpen={!!selected}
        onClose={closeDetails}
        title={tr("جزئیات نوبت")}
        size="sm"
        footer={selected && (
          <>
            <button type="button" className="btn btn-ghost danger" disabled={busy || selected.status === "cancelled"} onClick={() => changeStatus(selected, "cancelled")}>
              <CircleX size={14} />{" "}{tr("لغو نوبت")}</button>
            <button type="button" className="btn btn-ghost danger" disabled={busy} onClick={() => setDeleting(selected)}>
              <Trash2 size={14} />{" "}{tr("حذف نوبت")}</button>
          </>
        )}
      >
        {selected && (
          <div className="am-detail">
            {drawerError && <div className="form-message error" role="alert">{drawerError}</div>}
            <div className="am-detail-top">
              <span className="am-detail-id">#{faDigits(selected.id)}</span>
              <StatusBadge status={selected.status} />
            </div>

            <h4 className="am-detail-title">{tr("اطلاعات بیمار")}</h4>
            <dl className="am-info">
              <div><dt>{tr("نام بیمار")}</dt><dd>{selected.patientName}</dd></div>
              <div><dt>{tr("شماره بیمار")}</dt><dd className="am-num">{faDigits(selected.patientId)}</dd></div>
              <div><dt><Phone size={13} />{" "}{tr("شماره تماس")}</dt><dd className="am-ltr">{selected.patientPhone || "—"}</dd></div>
            </dl>

            <h4 className="am-detail-title">{tr("اطلاعات نوبت")}</h4>
            <dl className="am-info">
              <div><dt>{tr("شماره نوبت")}</dt><dd className="am-num">{faDigits(selected.id)}</dd></div>
              <div><dt>{tr("تاریخ")}</dt><dd>{fmtDateKey(String(selected.appointmentDate).slice(0, 10))}</dd></div>
              <div><dt>{tr("ساعت")}</dt><dd className="am-num">{faDigits(hhmm(selected.appointmentTime))}</dd></div>
              <div><dt><Stethoscope size={13} />{" "}{tr("داکتر")}</dt><dd>{selected.doctorName}</dd></div>
              <div><dt><Building2 size={13} />{" "}{tr("بخش")}</dt><dd>{selected.department}</dd></div>
              <div><dt>{tr("توضیحات")}</dt><dd className="am-plain">{selected.notes || "—"}</dd></div>
            </dl>

            <h4 className="am-detail-title">{tr("تغییر وضعیت")}</h4>
            <div className="am-status-pick" role="group" aria-label={tr("تغییر وضعیت نوبت")}>
              {Object.entries(STATUS_LABEL).map(([k, v]) => (
                <button key={k} type="button" className={`am-pick is-${k}${selected.status === k ? " is-on" : ""}`} disabled={busy} aria-pressed={selected.status === k} onClick={() => changeStatus(selected, k)}>
                  {v}
                </button>
              ))}
            </div>

            <h4 className="am-detail-title"><History size={14} />{" "}{tr("تاریخچه‌ی وضعیت")}</h4>
            {historyLoading ? (
              <div className="am-skel" />
            ) : history.length === 0 ? (
              <p className="am-muted">{tr("تاریخچه‌ای ثبت نشده است.")}</p>
            ) : (
              <ol className="am-history">
                {history.map((h) => (
                  <li key={h.id}>
                    <div>
                      {h.oldStatus ? <><StatusBadge status={h.oldStatus} /> ← </> : null}
                      <StatusBadge status={h.newStatus} />
                    </div>
                    <small className="am-muted">
                      {h.createdAt ? tr("{0}، {1}", [dateLong(new Date(h.createdAt)), faDigits(new Date(h.createdAt).toTimeString().slice(0, 5))]) : ""}
                      {h.changedByName ? ` — ${h.changedByName}` : ""}
                    </small>
                    {h.note && <small className="am-muted">{h.note}</small>}
                  </li>
                ))}
              </ol>
            )}
          </div>
        )}
      </GlobalModal>

      {/* ---------- تایید حذف ---------- */}
      <GlobalModal
        isOpen={!!deleting}
        onClose={() => !busy && setDeleting(null)}
        title={tr("حذف نوبت")}
        size="sm"
        footer={(
          <>
            <button type="button" className="btn btn-ghost" disabled={busy} onClick={() => setDeleting(null)}>{tr("انصراف")}</button>
            <button type="button" className="btn btn-primary" disabled={busy} onClick={confirmDelete}>{busy ? tr("در حال حذف...") : tr("بله، حذف شود")}</button>
          </>
        )}
      >
        {deleting && (
          <p className="am-confirm">{tr("آیا از حذف نوبت «{0}» نزد {1} ({2}، ساعت {3}) مطمئن هستید؟ بیمار از حذف این نوبت مطلع می‌شود و این عملیات قابل بازگشت نیست.", [deleting.patientName, deleting.doctorName, fmtDateKey(String(deleting.appointmentDate).slice(0, 10)), faDigits(hhmm(deleting.appointmentTime))])}</p>
        )}
      </GlobalModal>
    </div>
  );
}

function WeekRow({ h, label, days, today, cellItems, onOpen, onMore }) {
  return (
    <>
      <div className="am-hour">{label}</div>
      {days.map((d) => {
        const list = cellItems(toKey(d), h);
        return (
          <div key={toKey(d)} className={`am-week-cell${sameDay(d, today) ? " is-today" : ""}`}>
            {list.slice(0, 2).map((a) => <CalChip key={a.id} a={a} onOpen={onOpen} />)}
            {list.length > 2 && (
              <button type="button" className="am-more" onClick={() => onMore(d)}>{tr("+{0} نوبت دیگر", [(list.length - 2).toLocaleString(numLocale())])}</button>
            )}
          </div>
        );
      })}
    </>
  );
}

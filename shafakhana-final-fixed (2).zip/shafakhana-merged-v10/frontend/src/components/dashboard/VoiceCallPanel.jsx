import {
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  PhoneIncoming,
  PhoneMissed,
  Video,
  VideoOff,
  X,
  AlertTriangle,
  RotateCcw,
} from "lucide-react";

import { tr, trc } from "../../i18n/tr.js";
// ---------- رابطِ کاربریِ تماسِ صوتی/تصویری ----------
// PART 7-C صوتی + PART 7-D تصویری + PART 7-E وضعیت‌ها/کنترل‌ها.
// این کامپوننت فقط نمایش است؛ کل منطقِ WebRTC/سیگنالینگ در هوکِ useVoiceCall.js
// است. هم در ChatWithDoctor.jsx و هم در ChatWithPatients.jsx استفاده می‌شود.
//
// به‌روزرسانیِ PART 7-D: شاخه‌ی تماسِ صوتیِ فعال (callType !== "video") دقیقاً
// همان JSXِ قبلی است — چیزی در ظاهر/رفتارِ تماسِ صوتی تغییر نکرد. فقط یک شاخه‌ی
// تازه برای callType === "video" اضافه شده (ویدیوی محلی/ریموت + دکمه‌ی دوربین).
//
// به‌روزرسانیِ PART 7-E: برچسبِ وضعیت دیگر همیشه «تماس در حال برقراری» نیست —
// بر اساسِ status واقعی (calling/ringing/connecting) تغییر می‌کند، و یک شاخه‌ی
// تازه («کارتِ وضعیتِ پایانی») برای rejected/busy/missed/ended/failed اضافه شده
// که پیامِ فارسیِ روشن + دکمه‌ی «بازگشت به گفتگو» نشان می‌دهد (بازگشتِ خودکار هم
// در خودِ هوک برنامه‌ریزی شده است).

const ACTIVE_STATUS_LABELS = trc({
  calling: "در حال تماس‌گیری…",
  ringing: "در حال زنگ‌خوردن…",
  connecting: "تماس در حال برقراری",
});

const TERMINAL_STATUS_LABELS = trc({
  rejected: "تماس رد شد",
  busy: "کاربرِ مقابل مصروف است",
  missed: "پاسخی دریافت نشد",
  ended: "تماس پایان یافت",
  failed: "تماس برقرار نشد",
});

const TERMINAL_ICONS = {
  rejected: PhoneOff,
  busy: PhoneOff,
  missed: PhoneMissed,
  ended: PhoneOff,
  failed: AlertTriangle,
};

const ONGOING_STATUSES = ["calling", "ringing", "connecting", "connected"];
const TERMINAL_STATUSES = ["rejected", "busy", "missed", "ended", "failed"];

function formatDuration(totalSeconds) {
  const m = Math.floor(totalSeconds / 60)
    .toString()
    .padStart(2, "0");
  const s = (totalSeconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function VoiceCallPanel({
  status, // idle | calling | ringing | connecting | connected | rejected | busy | missed | ended | failed
  incomingCall,
  callerLabel,
  peerLabel,
  callError,
  micDenied,
  muted,
  callSeconds,
  remoteAudioRef,
  onAccept,
  onReject,
  onEnd,
  onToggleMute,
  onDismissError,
  onReturnToChat,
  // ---------- PART 7-D — تماسِ تصویری ----------
  callType,
  cameraOff,
  cameraUnavailable,
  localVideoRef,
  remoteVideoRef,
  onToggleCamera,
}) {
  const showIncoming = !!incomingCall && status === "idle";
  const isOngoing = ONGOING_STATUSES.includes(status);
  const isTerminal = TERMINAL_STATUSES.includes(status);
  const isVideoCall = isOngoing && callType === "video";
  const isAudioCall = isOngoing && callType !== "video";
  const incomingIsVideo = incomingCall?.callType === "video";
  const ongoingLabel = status === "connected" ? formatDuration(callSeconds) : ACTIVE_STATUS_LABELS[status] || "";
  const TerminalIcon = TERMINAL_ICONS[status] || PhoneOff;

  if (!showIncoming && !isOngoing && !isTerminal && !callError) return null;

  return (
    <>
      {/* صدای طرفِ مقابل در تماسِ صوتی — همیشه در DOM (حتی وقتی پنل نمایش داده نمی‌شود) */}
      <audio ref={remoteAudioRef} autoPlay hidden />

      {showIncoming && (
        <div className="voice-call-overlay">
          <div className="voice-call-card">
            <div className="voice-call-ring-icon pulsing">
              {incomingIsVideo ? <Video size={26} /> : <PhoneIncoming size={26} />}
            </div>
            <div className="voice-call-status-label">
              {incomingIsVideo ? tr("تماس تصویریِ ورودی") : tr("تماس ورودی")}
            </div>
            <div className="voice-call-peer-name">{callerLabel || tr("کاربر ناشناس")}</div>
            <div className="voice-call-actions">
              <button type="button" className="voice-call-btn reject" title={tr("رد تماس")} onClick={onReject}>
                <PhoneOff size={20} />
                <span>{tr("رد تماس")}</span>
              </button>
              <button type="button" className="voice-call-btn accept" title={tr("قبول تماس")} onClick={onAccept}>
                <Phone size={20} />
                <span>{tr("قبول تماس")}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- تماسِ تصویریِ فعال (PART 7-D) ---------- */}
      {isVideoCall && (
        <div className="voice-call-overlay video-call-overlay">
          <div className="video-call-card">
            <div className="video-call-remote-wrap">
              <video ref={remoteVideoRef} className="video-call-remote" autoPlay playsInline />
              {status !== "connected" && (
                <div className="video-call-waiting">
                  <div className="voice-call-ring-icon pulsing">
                    <Video size={22} />
                  </div>
                  <span>{ongoingLabel}</span>
                </div>
              )}
              <div className="video-call-topbar">
                <span className="video-call-peer-name">{peerLabel || ""}</span>
                <span className="video-call-duration">
                  {status === "connected" ? formatDuration(callSeconds) : ""}
                </span>
              </div>
              <video
                ref={localVideoRef}
                className={`video-call-local ${cameraOff ? "camera-off" : ""}`}
                autoPlay
                playsInline
                muted
              />
              {cameraUnavailable && (
                <div className="video-call-camera-note">{tr("دوربین در دسترس نیست — تماس به‌صورتِ صوتی ادامه دارد")}</div>
              )}
            </div>
            <div className="video-call-actions">
              <button
                type="button"
                className={`voice-call-btn ${muted ? "muted" : "neutral"}`}
                title={muted ? tr("روشن‌کردنِ میکروفون") : tr("خاموش‌کردنِ میکروفون")}
                onClick={onToggleMute}
              >
                {muted ? <MicOff size={20} /> : <Mic size={20} />}
                <span>{muted ? tr("روشن‌کردن میکروفون") : tr("قطعِ میکروفون")}</span>
              </button>
              <button type="button" className="voice-call-btn reject" title={tr("پایان تماس")} onClick={onEnd}>
                <PhoneOff size={20} />
                <span>{tr("پایان تماس")}</span>
              </button>
              <button
                type="button"
                className={`voice-call-btn ${cameraOff ? "muted" : "neutral"}`}
                title={cameraOff ? tr("روشن‌کردنِ دوربین") : tr("خاموش‌کردنِ دوربین")}
                onClick={onToggleCamera}
                disabled={cameraUnavailable}
              >
                {cameraOff ? <VideoOff size={20} /> : <Video size={20} />}
                <span>{cameraOff ? tr("روشن‌کردن دوربین") : tr("قطعِ دوربین")}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- تماسِ صوتیِ فعال — بدون هیچ تغییری در ساختار نسبت به PART 7-C ---------- */}
      {isAudioCall && (
        <div className="voice-call-overlay">
          <div className="voice-call-card">
            <div className={`voice-call-ring-icon ${status === "connected" ? "connected" : "pulsing"}`}>
              <Phone size={26} />
            </div>
            <div className="voice-call-status-label">{ongoingLabel}</div>
            <div className="voice-call-peer-name">{peerLabel || ""}</div>
            <div className="voice-call-actions">
              <button
                type="button"
                className={`voice-call-btn ${muted ? "muted" : "neutral"}`}
                title={muted ? tr("روشن‌کردنِ میکروفون") : tr("خاموش‌کردنِ میکروفون")}
                onClick={onToggleMute}
              >
                {muted ? <MicOff size={20} /> : <Mic size={20} />}
                <span>{muted ? tr("روشن‌کردن میکروفون") : tr("قطعِ میکروفون")}</span>
              </button>
              <button type="button" className="voice-call-btn reject" title={tr("پایان تماس")} onClick={onEnd}>
                <PhoneOff size={20} />
                <span>{tr("پایان تماس")}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ---------- کارتِ وضعیتِ پایانی (PART 7-E) — Rejected/Busy/Missed/Ended/Failed ---------- */}
      {isTerminal && (
        <div className="voice-call-overlay">
          <div className="voice-call-card terminal-card">
            <div className={`voice-call-ring-icon terminal-icon-${status}`}>
              <TerminalIcon size={26} />
            </div>
            <div className="voice-call-status-label">{callError || TERMINAL_STATUS_LABELS[status]}</div>
            {peerLabel && <div className="voice-call-peer-name">{peerLabel}</div>}
            <button type="button" className="voice-call-return-btn" onClick={onReturnToChat}>
              <RotateCcw size={15} />
              <span>{tr("بازگشت به گفتگو")}</span>
            </button>
          </div>
        </div>
      )}

      {callError && !showIncoming && !isTerminal && (
        <div className="voice-call-toast">
          <span>{micDenied ? tr("دسترسی به میکروفون/دوربین رد شد") : callError}</span>
          <button type="button" className="voice-call-toast-close" onClick={onDismissError} title={tr("بستن")}>
            <X size={14} />
          </button>
        </div>
      )}
    </>
  );
}

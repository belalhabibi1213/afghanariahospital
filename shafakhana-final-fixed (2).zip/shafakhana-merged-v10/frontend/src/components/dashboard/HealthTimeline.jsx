import { useEffect, useState } from "react";
import {
  Search, X, Eye, RefreshCw, Stethoscope, Pill, FlaskConical, ScanLine, CalendarCheck, ClipboardList,
  AlertTriangle, Download, Clock3, FilterX,
} from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import { PrescriptionDetailView } from "./PatientRecordsPanel.jsx";
import { apiRequest, apiDownload } from "../../utils/api.js";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, tdigits, numLocale } from "../../i18n/tr.js";
// ============================================================================
// «خط زمانی خدمات صحی» — پنل بیمار (فقط‌خواندنی)
// ----------------------------------------------------------------------------
// همه‌ی رویدادها از داده‌ی واقعیِ همین بیمار می‌آید و در بک‌اند با هم ادغام می‌شود:
//   GET /api/users/medical-history?type=&q=&dateFrom=&dateTo=&page=&limit=
//       نسخه‌ها، ویزیت‌ها، آزمایش‌های تکمیل‌شده، رادیولوژی، نوبت‌ها، تشخیص‌ها و حساسیت‌ها
//   GET /api/users/medical-history/:type/:id        جزئیات یک رویداد (بارگذاری تنبل)
// جزئیات نسخه و دانلود گزارش آزمایش از مسیرهای موجود می‌آید (بازاستفاده، بدون کپی):
//   GET /api/users/prescriptions/:id/detail|pdf ، GET /api/users/lab-results/:id/report
// مالکیت همه‌ی این مسیرها سمت سرور از روی توکن بررسی می‌شود؛ هیچ شناسه‌ی بیمار از کلاینت
// فرستاده نمی‌شود، پس تغییر ID در URL/درخواست داده‌ی بیمار دیگر را باز نمی‌کند.
// استایل: components/dashboard/HealthTimeline.css (کلاس‌های ht-*)
// ============================================================================

const FILTERS = trc([
  { key: "", label: "همه" },
  { key: "encounter", label: "ویزیت‌ها" },
  { key: "prescription", label: "نسخه‌ها" },
  { key: "lab", label: "آزمایش‌ها" },
  { key: "radiology", label: "رادیولوژی‌ها" },
  { key: "appointment", label: "نوبت‌ها" },
  { key: "record", label: "سوابق طبی" },
]);

// هویت بصری هر نوع رویداد (آیکن، برچسب نوع، رنگ تأکیدی از CSS)
const EVENT_META = trc({
  encounter: { Icon: Stethoscope, badge: "ویزیت", tone: "encounter", action: "مشاهده جزئیات" },
  prescription: { Icon: Pill, badge: "نسخه", tone: "prescription", action: "مشاهده نسخه" },
  lab: { Icon: FlaskConical, badge: "آزمایش", tone: "lab", action: "مشاهده نتیجه" },
  radiology: { Icon: ScanLine, badge: "رادیولوژی", tone: "radiology", action: "مشاهده جزئیات" },
  appointment: { Icon: CalendarCheck, badge: "نوبت", tone: "appointment", action: "مشاهده جزئیات" },
  diagnosis: { Icon: ClipboardList, badge: "سوابق طبی", tone: "record", action: "مشاهده جزئیات" },
  allergy: { Icon: AlertTriangle, badge: "سوابق طبی", tone: "record", action: "مشاهده جزئیات" },
});

const APPOINTMENT_STATUS = trc({ pending: "در انتظار تایید", confirmed: "تایید شده", completed: "تکمیل شده", cancelled: "لغو شده", rejected: "رد شده" });
const RX_STATUS = trc({ active: "در حال اجرا", completed: "تکمیل‌شده", cancelled: "لغوشده" });
const DIAGNOSIS_STATUS = trc({ active: "در حال جریان", resolved: "بهبودیافته" });
const SEVERITY = trc({ mild: "خفیف", moderate: "متوسط", severe: "شدید" });

const fa = (n) => Number(n || 0).toLocaleString(numLocale());
const faDigits = (s) => tdigits(String(s));

// تاریخ از سرور به‌صورت رشته‌ی ساده‌ی YYYY-MM-DD می‌آید؛ با ساعت محلی ساخته می‌شود تا روز جابه‌جا نشود
function fmtDate(v) {
  if (!v) return "—";
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(v));
  const d = m ? new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])) : new Date(v);
  return Number.isNaN(d.getTime()) ? "—" : d.toLocaleDateString(numLocale());
}
const fmtTime = (t) => (t ? faDigits(String(t).slice(0, 5)) : "");

function useDebounced(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}

// عنوان/توضیح/وضعیت هر رویداد — فقط از فیلدهای واقعی رکورد ساخته می‌شود
function describeEvent(it) {
  const meta = EVENT_META[it.type] || EVENT_META.encounter;
  const lines = [];
  let title = meta.badge;
  let status = null;
  switch (it.type) {
    case "encounter":
      title = tr("ویزیت داکتر");
      if (it.diagnosis) lines.push([tr("تشخیص"), it.diagnosis]);
      else if (it.description) lines.push([tr("علائم"), it.description]);
      break;
    case "prescription":
      title = tr("نسخه جدید");
      lines.push([tr("تعداد داروها"), tr("{0} قلم", [fa(it.itemCount)])]);
      if (it.diagnosis) lines.push([tr("تشخیص"), it.diagnosis]);
      status = RX_STATUS[it.status] || null;
      break;
    case "lab":
      title = it.title || tr("آزمایش");
      if (it.description) lines.push([tr("نتیجه"), it.description]);
      status = tr("نتیجه آماده");
      break;
    case "radiology":
      title = it.title || tr("رادیولوژی");
      if (it.description) lines.push([tr("شرح"), it.description]);
      break;
    case "appointment":
      title = tr("نوبت ملاقات");
      if (it.description) lines.push([tr("توضیح"), it.description]);
      status = APPOINTMENT_STATUS[it.status] || it.status || null;
      break;
    case "diagnosis":
      title = tr("ثبت تشخیص: {0}", [it.title]);
      if (it.description) lines.push([tr("شرح"), it.description]);
      status = DIAGNOSIS_STATUS[it.status] || null;
      break;
    case "allergy":
      title = tr("ثبت حساسیت: {0}", [it.title]);
      if (it.description) lines.push([tr("واکنش"), it.description]);
      status = it.status ? tr("شدت {0}", [SEVERITY[it.status] || it.status]) : null;
      break;
    default:
      break;
  }
  return { meta, title, lines, status };
}

export default function HealthTimeline() {
  const [type, setType] = useState("");
  const [search, setSearch] = useState("");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadTick, setReloadTick] = useState(0);
  const [selected, setSelected] = useState(null); // رویدادی که جزئیاتش باز است
  const [actionError, setActionError] = useState("");
  const [busyId, setBusyId] = useState(null);

  const debouncedSearch = useDebounced(search);
  const hasFilters = !!(type || search.trim() || dateFrom || dateTo);

  // با تغییر هر فیلتر/جستجو همیشه به صفحه‌ی اول برمی‌گردیم
  useEffect(() => setPage(1), [type, debouncedSearch, dateFrom, dateTo]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    const usp = new URLSearchParams({ page, limit: 8 });
    if (type) usp.set("type", type);
    if (debouncedSearch.trim()) usp.set("q", debouncedSearch.trim());
    if (dateFrom) usp.set("dateFrom", dateFrom);
    if (dateTo) usp.set("dateTo", dateTo);
    apiRequest(`/users/medical-history?${usp.toString()}`)
      .then((d) => {
        if (cancelled) return;
        setItems(d.items || []);
        setPagination(d.pagination || null);
      })
      .catch(() => { if (!cancelled) setError(tr("دریافت اطلاعات خدمات صحی با مشکل مواجه شد.")); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [type, debouncedSearch, dateFrom, dateTo, page, reloadTick]);

  function clearFilters() {
    setType(""); setSearch(""); setDateFrom(""); setDateTo("");
  }

  async function runDownload(key, path, name, opts) {
    setBusyId(key);
    setActionError("");
    try { await apiDownload(path, name, opts); }
    catch (err) { setActionError(err.message); }
    finally { setBusyId(null); }
  }

  return (
    <div className="dash-card glass ht-page">
      <header className="ht-head">
        <span className="ht-head-icon" aria-hidden="true"><Clock3 size={22} /></span>
        <div>
          <h2>{tr("خط زمانی خدمات صحی")}</h2>
          <p>{tr("مروری بر تمام رویدادهای پزشکی، نسخه‌ها، آزمایش‌ها و خدمات دریافت‌شده")}</p>
        </div>
      </header>

      <div className="ht-filters">
        <div className="ht-chips" role="group" aria-label={tr("نوع رویداد")}>
          {FILTERS.map((f) => (
            <button
              key={f.key || "all"}
              type="button"
              className="ht-chip"
              aria-pressed={type === f.key}
              onClick={() => setType(f.key)}
            >
              {f.label}
            </button>
          ))}
        </div>
        <div className="ht-filter-row">
          <div className="ht-search">
            <Search size={16} aria-hidden="true" />
            <input
              type="search"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={tr("جستجو در عنوان، تشخیص، داکتر یا بخش...")}
              aria-label={tr("جستجو در خط زمانی")}
            />
          </div>
          <label className="ht-date">
            <span>{tr("از تاریخ")}</span>
            <JalaliDateInput value={dateFrom} max={dateTo || undefined} onChange={(e) => setDateFrom(e.target.value)} />
          </label>
          <label className="ht-date">
            <span>{tr("تا تاریخ")}</span>
            <JalaliDateInput value={dateTo} min={dateFrom || undefined} onChange={(e) => setDateTo(e.target.value)} />
          </label>
          {hasFilters && (
            <button type="button" className="btn btn-ghost btn-sm ht-clear" onClick={clearFilters}>
              <X size={14} /> {tr("پاک کردن فیلترها")}
            </button>
          )}
        </div>
      </div>

      {actionError && <div className="form-message error" role="alert">{actionError}</div>}

      {error && (
        <div className="ht-state" role="alert">
          <AlertTriangle size={34} />
          <strong>{error}</strong>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setReloadTick((t) => t + 1)}>
            <RefreshCw size={14} /> {tr("تلاش دوباره")}
          </button>
        </div>
      )}

      {!error && loading && items.length === 0 && (
        <ol className="ht-list" aria-busy="true" aria-label={tr("در حال بارگذاری")}>
          {[0, 1, 2, 3].map((i) => (
            <li key={i} className="ht-item">
              <span className="ht-node ht-skel-node" />
              <div className="ht-when"><span className="ht-skel" style={{ width: 80 }} /><span className="ht-skel" style={{ width: 48 }} /></div>
              <div className="ht-card ht-card-skel"><span className="ht-skel" style={{ width: "40%" }} /><span className="ht-skel" style={{ width: "65%" }} /></div>
            </li>
          ))}
        </ol>
      )}

      {!error && !loading && items.length === 0 && (
        <div className="ht-state">
          {hasFilters ? <FilterX size={34} /> : <ClipboardList size={34} />}
          <strong>{hasFilters ? tr("رویدادی مطابق با جستجو یا فیلتر شما یافت نشد.") : tr("هنوز هیچ رویداد صحی برای شما ثبت نشده است.")}</strong>
          {hasFilters && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>{tr("پاک کردن فیلترها")}</button>
          )}
        </div>
      )}

      {!error && items.length > 0 && (
        <ol className={`ht-list ${loading ? "is-busy" : ""}`}>
          {items.map((it) => {
            const { meta, title, lines, status } = describeEvent(it);
            const { Icon } = meta;
            return (
              <li key={`${it.type}-${it.id}`} className={`ht-item ht-tone-${meta.tone}`}>
                <span className="ht-node" aria-hidden="true"><Icon size={14} /></span>
                <div className="ht-when">
                  <time>{fmtDate(it.eventDate)}</time>
                  {it.eventTime && <span className="ht-time">{fmtTime(it.eventTime)}</span>}
                </div>
                <article className="ht-card">
                  <div className="ht-card-icon" aria-hidden="true"><Icon size={22} /></div>
                  <div className="ht-card-body">
                    <div className="ht-card-title">
                      <h3>{title}</h3>
                      <span className="ht-badge">{meta.badge}</span>
                    </div>
                    {(it.doctorName || it.department) && (
                      <p className="ht-meta">
                        {it.doctorName && <span>{tr("داکتر:")} {it.doctorName}</span>}
                        {it.department && <span>{tr("بخش:")} {it.department}</span>}
                      </p>
                    )}
                    {lines.map(([k, v]) => (
                      <p key={k} className="ht-line"><b>{k}:</b> {k === tr("نتیجه") ? <bdi dir="ltr">{v}</bdi> : <span>{v}</span>}</p>
                    ))}
                    {status && <p className="ht-line"><b>{tr("وضعیت:")}</b> <span className="ht-status">{status}</span></p>}
                  </div>
                  <div className="ht-card-action">
                    <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setActionError(""); setSelected(it); }}>
                      <Eye size={15} /> {meta.action}
                    </button>
                  </div>
                </article>
              </li>
            );
          })}
        </ol>
      )}

      {!error && pagination && pagination.total > 0 && (
        <TimelinePager pagination={pagination} page={page} onPageChange={setPage} />
      )}

      <GlobalModal
        isOpen={!!selected}
        onClose={() => setSelected(null)}
        size="lg"
        title={selected?.type === "prescription" ? tr("جزئیات نسخه") : tr("جزئیات رویداد")}
        className={selected?.type === "prescription" ? "rxp-modal" : undefined}
      >
        {selected?.type === "prescription" && (
          <PrescriptionDetailView
            id={selected.id}
            busyId={busyId}
            onPrint={() => runDownload(`print-${selected.id}`, `/users/prescriptions/${selected.id}/pdf`, `prescription-${selected.id}.pdf`, { print: true })}
            onPdf={() => runDownload(`pdf-${selected.id}`, `/users/prescriptions/${selected.id}/pdf`, `prescription-${selected.id}.pdf`, { openInNewTab: true })}
          />
        )}
        {selected && selected.type !== "prescription" && (
          <EventDetail
            event={selected}
            busy={busyId === `lab-${selected.id}`}
            onOpenReport={() => runDownload(`lab-${selected.id}`, `/users/lab-results/${selected.id}/report`, `lab-report-${selected.id}`, { openInNewTab: true })}
          />
        )}
        {actionError && selected && <div className="form-message error" role="alert">{actionError}</div>}
      </GlobalModal>
    </div>
  );
}

// ---------- جزئیات یک رویداد (بجز نسخه) — بارگذاری تنبل از سرور ----------
function EventDetail({ event, busy, onOpenReport }) {
  const [d, setD] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    apiRequest(`/users/medical-history/${event.type}/${event.id}`)
      .then((r) => { if (!cancelled) setD(r.detail); })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [event.type, event.id, tick]);

  if (loading) return <p>{tr("در حال بارگذاری...")}</p>;
  if (error) {
    return (
      <div className="ht-state">
        <strong>{error}</strong>
        <button type="button" className="btn btn-ghost btn-sm" onClick={() => setTick((t) => t + 1)}><RefreshCw size={14} /> {tr("تلاش دوباره")}</button>
      </div>
    );
  }
  if (!d) return null;

  const rows = [];
  const add = (label, value) => { if (value !== null && value !== undefined && String(value).trim() !== "") rows.push([label, value]); };
  const doctorRows = () => { add(tr("داکتر"), d.doctorName); add(tr("بخش"), d.department); };

  switch (event.type) {
    case "encounter":
      add(tr("تاریخ ویزیت"), fmtDate(d.visitDate));
      doctorRows();
      add(tr("علائم"), d.symptoms);
      add(tr("تشخیص"), d.diagnosis);
      add(tr("علائم حیاتی"), [d.bloodPressure && tr("فشار خون: {0}", [d.bloodPressure]), d.temperature && tr("حرارت: {0}", [d.temperature]), d.height && tr("قد: {0}", [d.height]), d.weight && tr("وزن: {0}", [d.weight])].filter(Boolean).join(" — "));
      add(tr("تداوی"), d.treatment || d.prescription);
      add(tr("یادداشت"), d.notes);
      break;
    case "lab":
      add(tr("نام آزمایش"), d.testName);
      add(tr("تاریخ"), fmtDate(d.testDate || d.createdAt));
      doctorRows();
      add(tr("نتیجه"), d.result ? `${d.result}${d.unit ? ` ${d.unit}` : ""}` : null);
      add(tr("محدوده‌ی نرمال"), d.referenceRange);
      add(tr("وضعیت"), tr("نتیجه آماده"));
      break;
    case "radiology":
      add(tr("نوع تصویربرداری"), d.examType);
      add(tr("تاریخ"), fmtDate(d.examDate || d.createdAt));
      doctorRows();
      add(tr("یافته‌ها"), d.findings);
      add(tr("نتیجه‌گیری"), d.impression);
      break;
    case "appointment":
      add(tr("تاریخ نوبت"), fmtDate(d.appointmentDate));
      add(tr("ساعت"), fmtTime(d.appointmentTime));
      add(tr("داکتر"), d.doctorName);
      add(tr("بخش"), d.department);
      add(tr("وضعیت"), APPOINTMENT_STATUS[d.status] || d.status);
      add(tr("توضیح"), d.notes);
      break;
    case "diagnosis":
      add(tr("تشخیص"), d.title);
      add(tr("تاریخ ثبت"), fmtDate(d.createdAt));
      doctorRows();
      add(tr("شرح"), d.description);
      add(tr("کد ICD"), d.icdCode);
      add(tr("وضعیت"), DIAGNOSIS_STATUS[d.status] || d.status);
      break;
    case "allergy":
      add(tr("حساسیت"), d.allergen);
      add(tr("تاریخ ثبت"), fmtDate(d.createdAt));
      doctorRows();
      add(tr("واکنش"), d.reaction);
      add(tr("شدت"), SEVERITY[d.severity] || d.severity);
      add(tr("یادداشت"), d.notes);
      break;
    default:
      break;
  }

  return (
    <div className="ht-detail">
      <dl>
        {rows.map(([k, v]) => (
          <div key={k} className="ht-detail-row"><dt>{k}</dt><dd>{k === tr("محدوده‌ی نرمال") || (event.type === "lab" && k === tr("نتیجه")) ? <bdi dir="ltr">{v}</bdi> : v}</dd></div>
        ))}
      </dl>
      {event.type === "lab" && !!d.hasFile && (
        <button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={onOpenReport}>
          <Download size={14} /> {tr("مشاهده / دانلود گزارش")}
        </button>
      )}
    </div>
  );
}

// ---------- صفحه‌بندی ----------
function TimelinePager({ pagination, page, onPageChange }) {
  const { total, limit, totalPages } = pagination;
  const from = (page - 1) * limit + 1;
  const to = Math.min(page * limit, total);
  const start = Math.max(1, Math.min(page - 2, totalPages - 4));
  const nums = [];
  for (let n = start; n <= Math.min(totalPages, start + 4); n += 1) nums.push(n);
  return (
    <nav className="ht-pager" aria-label={tr("صفحه‌بندی")}>
      <span>{tr("نمایش {0} تا {1} از {2} مورد", [fa(from), fa(to), fa(total)])}</span>
      {totalPages > 1 && (
        <div className="ht-pages">
          <button type="button" className="ht-page-btn" disabled={page <= 1} onClick={() => onPageChange(page - 1)} aria-label={tr("صفحه قبل")}>›</button>
          {nums.map((n) => (
            <button key={n} type="button" className="ht-page-btn" aria-current={n === page ? "page" : undefined} onClick={() => onPageChange(n)}>{fa(n)}</button>
          ))}
          <button type="button" className="ht-page-btn" disabled={page >= totalPages} onClick={() => onPageChange(page + 1)} aria-label={tr("صفحه بعد")}>‹</button>
        </div>
      )}
    </nav>
  );
}

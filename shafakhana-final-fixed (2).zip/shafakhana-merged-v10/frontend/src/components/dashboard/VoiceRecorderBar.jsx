import { Mic, Trash2, Send, Loader2 } from "lucide-react";

import { tr } from "../../i18n/tr.js";
// ---------- نوار ضبط پیام صوتی چت (بیمار ↔ داکتر) ----------
// وقتی در حال ضبط نیستیم: فقط دکمه‌ی میکروفون (جایگزین/کنار دکمه‌ی پیوست) نمایش داده
// می‌شود. وقتی در حال ضبط هستیم: کل ردیف ورودی پیام با این نوار جایگزین می‌شود —
// [لغو (زباله‌دان)] --- [نقطه‌ی چشمک‌زن + تایمر mm:ss] --- [ارسال].
// هم در ChatWithDoctor.jsx و هم ChatWithPatients.jsx استفاده می‌شود.

function formatTimer(seconds) {
  const total = Math.max(0, Math.floor(seconds));
  const m = Math.floor(total / 60).toString().padStart(2, "0");
  const s = (total % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function VoiceRecorderBar({
  supported,
  isRecording,
  elapsedSeconds,
  sending,
  triggerDisabled,
  onStartRecording,
  onCancelRecording,
  onSendRecording,
}) {
  if (isRecording) {
    return (
      <div className="chat-voice-recording-bar" role="group" aria-label={tr("در حال ضبط پیام صوتی")}>
        <button
          type="button"
          className="chat-voice-cancel-btn"
          title={tr("لغو ضبط")}
          onClick={onCancelRecording}
          disabled={sending}
        >
          <Trash2 size={18} />
        </button>

        <div className="chat-voice-recording-indicator">
          <span className="chat-voice-recording-dot" />
          <span className="chat-voice-recording-timer">{formatTimer(elapsedSeconds)}</span>
          <span className="chat-voice-recording-label">{tr("در حال ضبط...")}</span>
        </div>

        <button
          type="button"
          className="chat-voice-send-btn"
          title={tr("ارسال پیام صوتی")}
          onClick={onSendRecording}
          disabled={sending || elapsedSeconds < 0.5}
        >
          {sending ? <Loader2 size={18} className="chat-attachment-spin" /> : <Send size={18} />}
        </button>
      </div>
    );
  }

  return (
    <button
      type="button"
      className="chat-voice-trigger-btn"
      title={supported ? tr("ضبط پیام صوتی") : tr("ضبط صدا در این مرورگر یا دستگاه پشتیبانی نمی‌شود")}
      disabled={triggerDisabled}
      onClick={onStartRecording}
    >
      <Mic size={18} />
    </button>
  );
}

import { useEffect, useState } from "react";
import { FileText, Download, Loader2 } from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import { apiFetchImageUrl, apiDownload } from "../../utils/api.js";

import { tr, numLocale } from "../../i18n/tr.js";
// ---------- پیوست یک پیام چت (عکس یا سند) ----------
// این کامپوننت هم در ChatWithPatients.jsx (داشبورد داکتر) و هم در ChatWithDoctor.jsx
// (داشبورد بیمار) استفاده می‌شود تا منطق نمایش پیوست (thumbnail عکس + پیش‌نمایش بزرگ،
// یا کارت سند با دکمه‌ی دانلود) در یک‌جا باشد. دسترسی امن (اینکه کاربر واقعاً عضو همان
// مکالمه است) در بک‌اند بررسی می‌شود (backend/controllers/chatController.js)؛ این
// کامپوننت فقط رابط کاربری است.

const DOCUMENT_TYPE_LABELS = {
  "application/pdf": "PDF",
  "application/msword": "DOC",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "DOCX",
  "application/vnd.ms-excel": "XLS",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "XLSX",
};

function attachmentTypeLabel(fileType, originalName) {
  if (DOCUMENT_TYPE_LABELS[fileType]) return DOCUMENT_TYPE_LABELS[fileType];
  const ext = (originalName || "").split(".").pop();
  return ext ? ext.toUpperCase() : tr("فایل");
}

function formatFileSize(bytes) {
  if (bytes === null || bytes === undefined) return "";
  if (bytes < 1024) return tr("{0} بایت", [bytes]);
  if (bytes < 1024 * 1024) return tr("{0} کیلوبایت", [(bytes / 1024).toFixed(1)]);
  return tr("{0} مگابایت", [(bytes / (1024 * 1024)).toFixed(1)]);
}

function formatAttachmentDate(dateStr) {
  return new Date(dateStr).toLocaleDateString(numLocale());
}

export default function ChatAttachment({ conversationId, message }) {
  const isImage = (message.attachmentFileType || "").startsWith("image/");
  const attachmentPath = `/chat/conversations/${conversationId}/messages/${message.id}/attachment`;

  const [imageUrl, setImageUrl] = useState(null);
  const [imageFailed, setImageFailed] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [downloading, setDownloading] = useState(false);

  // ---------- دریافت عکس پیوست به‌صورت Blob (نیاز به نشست (کوکی) دارد، پس
  // نمی‌توان مستقیماً از <img src="..."> با آدرس API استفاده کرد) ----------
  useEffect(() => {
    if (!isImage) return undefined;
    let cancelled = false;
    let createdUrl = null;

    apiFetchImageUrl(attachmentPath)
      .then((url) => {
        if (cancelled) return;
        if (!url) {
          setImageFailed(true);
          return;
        }
        createdUrl = url;
        setImageUrl(url);
      })
      .catch(() => {
        if (!cancelled) setImageFailed(true);
      });

    return () => {
      cancelled = true;
      if (createdUrl) URL.revokeObjectURL(createdUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [attachmentPath, isImage]);

  async function handleDownloadDocument() {
    setDownloading(true);
    try {
      await apiDownload(attachmentPath, message.attachmentOriginalName || "file");
    } catch (err) {
      // پیام خطای مجزا لازم نیست؛ این فقط یک المان کوچک داخل حباب پیام است
    } finally {
      setDownloading(false);
    }
  }

  if (isImage) {
    return (
      <>
        <button
          type="button"
          className="chat-attachment-image-btn"
          onClick={() => imageUrl && setPreviewOpen(true)}
          disabled={!imageUrl}
        >
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={message.attachmentOriginalName || tr("پیوست عکس")}
              className="chat-attachment-image"
            />
          ) : imageFailed ? (
            <span className="chat-attachment-image-placeholder">{tr("عکس در دسترس نیست")}</span>
          ) : (
            <span className="chat-attachment-image-placeholder">
              <Loader2 size={16} className="chat-attachment-spin" /> {tr("در حال بارگذاری...")}
            </span>
          )}
        </button>

        <GlobalModal
          isOpen={previewOpen}
          onClose={() => setPreviewOpen(false)}
          bare
          size="lg"
          overlayClassName="chat-attachment-preview-overlay"
        >
          <div className="chat-attachment-preview" role="dialog" aria-label={tr("پیش‌نمایش عکس")}>
            <button
              type="button"
              className="chat-attachment-preview-close"
              onClick={() => setPreviewOpen(false)}
              aria-label={tr("بستن")}
            >
              ✕
            </button>
            {imageUrl && (
              <img src={imageUrl} alt={message.attachmentOriginalName || tr("پیش‌نمایش عکس")} />
            )}
          </div>
        </GlobalModal>
      </>
    );
  }

  return (
    <div className="chat-attachment-doc">
      <span className="chat-attachment-doc-icon">
        <FileText size={20} />
      </span>
      <div className="chat-attachment-doc-info">
        <span className="chat-attachment-doc-name">{message.attachmentOriginalName}</span>
        <span className="chat-attachment-doc-meta">
          {attachmentTypeLabel(message.attachmentFileType, message.attachmentOriginalName)}
          {" · "}
          {formatFileSize(message.attachmentFileSize)}
          {" · "}
          {formatAttachmentDate(message.createdAt)}
        </span>
      </div>
      <button
        type="button"
        className="chat-attachment-doc-download"
        title={tr("دانلود / باز کردن")}
        disabled={downloading}
        onClick={handleDownloadDocument}
      >
        <Download size={16} />
      </button>
    </div>
  );
}

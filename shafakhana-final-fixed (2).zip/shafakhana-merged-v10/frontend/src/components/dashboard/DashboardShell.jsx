import { Link } from "react-router-dom";
import { useAuth } from "../../context/AuthContext.jsx";
import { useSiteSettings } from "../../context/SettingsContext.jsx";
import { requestLogout } from "../../utils/logoutGuard.js";
import NotificationBell from "../NotificationBell.jsx";
import ThemeToggle from "../ThemeToggle.jsx";
import LanguageSwitcher from "../LanguageSwitcher.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";

import { tr, trc } from "../../i18n/tr.js";
const ROLE_LABEL = trc({
  user: "بیمار",
  doctor: "داکتر",
  admin: "ادمین",
  superadmin: "مدیر کل (Super Admin)",
});

// چارچوب مشترک همه‌ی داشبوردها: سایدبار + هدر + محتوا.
// tabs: [{ key, label, icon }]  — منوهایی که فقط برای همان نقش قابل مشاهده است
// variant (اختیاری): فقط یک کلاس اضافه روی ریشه می‌گذارد (مثلاً "patient") تا استایل اختصاصی همان نقش
// بدون تأثیر بر سایر داشبوردها اعمال شود. اگر داده نشود، رفتار قبلی دقیقاً حفظ می‌شود.
export default function DashboardShell({ title, tabs, activeTab, onTabChange, children, variant }) {
  const { user } = useAuth();
  const { settings } = useSiteSettings();
  useLanguage(); // با تغییر زبان، منو و عنوان‌ها دوباره رندر می‌شوند

  return (
    <div className={variant ? `dash-shell dash-shell--${variant}` : "dash-shell"}>
      <aside className="dash-sidebar glass">
        <Link to="/home" className="brand" style={{ marginBottom: 24 }}>
          <span className="brand-mark">✚</span>
          {settings.hospitalName}
        </Link>

        <nav className="dash-nav">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              className={`dash-nav-item ${activeTab === tab.key ? "active" : ""}`}
              onClick={() => onTabChange(tab.key)}
              type="button"
            >
              <span className="dash-nav-icon">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </nav>

        <button className="btn btn-ghost dash-logout" onClick={requestLogout} type="button">{tr("خروج از حساب")}</button>
      </aside>

      <main className="dash-content">
        <header className="dash-topbar glass">
          <div>
            <h1>{title}</h1>
            <p className="dash-role-badge">{ROLE_LABEL[user?.role] || ""} — {user?.fullName}</p>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
            <LanguageSwitcher />
            <ThemeToggle />
            <NotificationBell />
            <Link to="/home" className="btn btn-ghost">{tr("بازگشت به سایت")}</Link>
          </div>
        </header>

        <div className="dash-body">{children}</div>
      </main>
    </div>
  );
}

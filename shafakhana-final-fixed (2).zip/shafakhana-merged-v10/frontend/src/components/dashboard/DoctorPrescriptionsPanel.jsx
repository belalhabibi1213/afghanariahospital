import { useEffect, useMemo, useRef, useState } from "react";
import {
  Search, X, Eye, Printer, Download, RefreshCw, Pill, CheckCircle2, Clock, XCircle,
  ClipboardList, AlertTriangle, FilterX, Plus, Pencil, Trash2,
} from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import { useDepartmentToasts, DepartmentToastContainer } from "./DepartmentToast.jsx";
import { apiRequest, apiDownload } from "../../utils/api.js";
import { groupPrescriptions } from "../../utils/prescriptionGroups.js";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, numLocale, curDir } from "../../i18n/tr.js";
// ============================================================================
// پنل داکتر «نسخه و سوابق طبی»
// ----------------------------------------------------------------------------
// APIهای استفاده‌شده (همه سمت سرور RBAC/مالکیت دارند؛ مخفی‌کردن دکمه فقط UX است):
//   GET    /api/doctors/me/prescriptions            فهرست نسخه‌های خودِ داکتر            — جدید
//   GET    /api/doctors/me/prescriptions/stats      آمار نسخه‌های خودِ داکتر              — جدید
//   GET    /api/doctors/me/patients                 بیماران مرتبط با داکتر (انتخاب بیمار) — موجود
//   GET    /api/medical-records/patient/:id         پرونده‌ی بیمار (فقط بیماران خودش)     — موجود
//   POST   /api/medical-records/prescriptions       ثبت دارو در نسخه                      — موجود
//   PUT    /api/medical-records/prescriptions/:id   ویرایش (فقط مالک و نسخه‌ی در حال اجرا) — موجود + قفل جدید
//   DELETE /api/medical-records/prescriptions/:id   حذف دارو از نسخه (هنگام ویرایش)       — موجود
//   GET    /api/medical-records/prescriptions/:id/pdf  چاپ / PDF                         — موجود
// استایل: components/dashboard/AdminPrescriptionsPanel.css (rxp-*) + components/dashboard/DoctorPrescriptionsPanel.css (dxp-*)
// ============================================================================

const STATUS_LABEL = trc({ active: "در حال اجرا", completed: "تکمیل‌شده", cancelled: "لغوشده" });
const GENDER_LABEL = trc({ male: "مرد", female: "زن" });
const SEVERITY_LABEL = trc({ mild: "خفیف", moderate: "متوسط", severe: "شدید" });
const DIAGNOSIS_STATUS_LABEL = trc({ active: "در حال جریان", resolved: "بهبودیافته" });
const LAB_STATUS_LABEL = trc({ pending: "در انتظار نتیجه", completed: "تکمیل‌شده" });
const EMPTY_FILTERS = { dateFrom: "", dateTo: "", status: "" };
const EMPTY_MEDICINE = { medicationName: "", dosage: "", quantity: "", frequency: "", duration: "", medicineNotes: "" };
const EMPTY_FORM = { diagnosis: "", instructions: "", followUpDate: "", notes: "" };

function fmtDate(v) {
  return v ? new Date(v).toLocaleDateString(numLocale()) : "—";
}
function rxNumberOf(row) {
  return row.rxNumber || `RX-${String(row.id).padStart(6, "0")}`;
}
function newGroupId() {
  return typeof crypto !== "undefined" && crypto.randomUUID
    ? crypto.randomUUID()
    : `g${Date.now()}${Math.random().toString(36).slice(2, 10)}`;
}
function useDebounced(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(t);
  }, [value, delay]);
  return debounced;
}
function StatusBadge({ status }) {
  const key = STATUS_LABEL[status] ? status : "active";
  return <span className={`rxp-badge rxp-badge-${key}`}>{STATUS_LABEL[key]}</span>;
}

export default function DoctorPrescriptionsPanel() {
  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [stats, setStats] = useState(null);
  const [statsError, setStatsError] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [formTarget, setFormTarget] = useState(null); // { row? } — null یعنی بسته
  const [busyId, setBusyId] = useState(null);
  const [reloadTick, setReloadTick] = useState(0);
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  const debouncedSearch = useDebounced(search);
  const hasFilters = !!(search || filters.dateFrom || filters.dateTo || filters.status);

  useEffect(() => setPage(1), [debouncedSearch, filters.dateFrom, filters.dateTo, filters.status]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    const usp = new URLSearchParams({ page, limit: 10 });
    if (debouncedSearch.trim()) usp.set("q", debouncedSearch.trim());
    Object.entries(filters).forEach(([k, v]) => { if (v) usp.set(k, v); });
    apiRequest(`/doctors/me/prescriptions?${usp.toString()}`)
      .then((data) => {
        if (cancelled) return;
        setItems(data.prescriptions || []);
        setPagination(data.pagination || null);
      })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch, filters.dateFrom, filters.dateTo, filters.status, page, reloadTick]);

  useEffect(() => {
    setStatsError(false);
    apiRequest("/doctors/me/prescriptions/stats")
      .then((d) => setStats(d.stats))
      .catch(() => setStatsError(true));
  }, [reloadTick]);

  const reload = () => setReloadTick((t) => t + 1);
  const setFilter = (key, value) => setFilters((f) => ({ ...f, [key]: value }));
  function clearAll() { setSearch(""); setFilters(EMPTY_FILTERS); }

  async function printRx(row) {
    setBusyId(`print-${row.id}`);
    try {
      await apiDownload(`/medical-records/prescriptions/${row.id}/pdf`, `prescription-${row.id}.pdf`, { print: true });
    } catch (err) { showToast(err.message, "error"); } finally { setBusyId(null); }
  }
  async function pdfRx(row) {
    setBusyId(`pdf-${row.id}`);
    try {
      await apiDownload(`/medical-records/prescriptions/${row.id}/pdf`, `prescription-${row.id}.pdf`, { openInNewTab: true });
    } catch (err) { showToast(err.message, "error"); } finally { setBusyId(null); }
  }

  const statCards = [
    { key: "total", label: tr("کل نسخه‌های من"), icon: <ClipboardList size={22} />, tone: "total" },
    { key: "completed", label: tr("نسخه‌های تکمیل‌شده"), icon: <CheckCircle2 size={22} />, tone: "completed" },
    { key: "active", label: tr("نسخه‌های در حال اجرا"), icon: <Clock size={22} />, tone: "active" },
    { key: "cancelled", label: tr("نسخه‌های لغوشده"), icon: <XCircle size={22} />, tone: "cancelled" },
  ];

  return (
    <div className="rxp">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />

      <div className="rxp-header glass">
        <div className="rxp-header-main">
          <span className="rxp-header-icon"><Pill size={26} /></span>
          <div>
            <h2>{tr("نسخه و سوابق طبی")}</h2>
            <p>{tr("نوشتن نسخه و مشاهده‌ی سوابق طبی بیماران شما")}</p>
          </div>
        </div>
        <div className="rxp-header-actions">
          {hasFilters && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>
              <FilterX size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("پاک‌کردن فیلترها")}</button>
          )}
          <button type="button" className="btn btn-ghost btn-sm" onClick={reload} disabled={loading}>
            <RefreshCw size={14} className={loading ? "rxp-spin" : ""} style={{ verticalAlign: "-2px" }} />{" "}{tr("بازخوانی")}</button>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setFormTarget({})}>
            <Plus size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("نسخه جدید")}</button>
        </div>
      </div>

      <div className="rxp-stats">
        {statCards.map((c) => (
          <div key={c.key} className={`rxp-stat rxp-stat-${c.tone} glass`}>
            <span className="rxp-stat-icon">{c.icon}</span>
            <div>
              <span className="rxp-stat-label">{c.label}</span>
              {stats
                ? <strong>{Number(stats[c.key] || 0).toLocaleString(numLocale())}</strong>
                : statsError ? <strong>—</strong> : <span className="rxp-skeleton rxp-skeleton-num" />}
            </div>
          </div>
        ))}
      </div>

      <div className="rxp-toolbar glass">
        <div className="rxp-search">
          <Search size={17} />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tr("جستجو: نام بیمار یا شماره نسخه (مثلاً RX-000012)")}
            aria-label={tr("جستجوی نسخه")}
          />
          {search && (
            <button type="button" className="rxp-search-clear" onClick={() => setSearch("")} aria-label={tr("پاک‌کردن جستجو")}><X size={15} /></button>
          )}
        </div>
        <div className="rxp-filters dxp-filters">
          <div className="field">
            <label>{tr("از تاریخ")}</label>
            <JalaliDateInput value={filters.dateFrom} max={filters.dateTo || undefined} onChange={(e) => setFilter("dateFrom", e.target.value)} />
          </div>
          <div className="field">
            <label>{tr("تا تاریخ")}</label>
            <JalaliDateInput value={filters.dateTo} min={filters.dateFrom || undefined} onChange={(e) => setFilter("dateTo", e.target.value)} />
          </div>
          <div className="field">
            <label>{tr("وضعیت نسخه")}</label>
            <select value={filters.status} onChange={(e) => setFilter("status", e.target.value)}>
              <option value="">{tr("همه وضعیت‌ها")}</option>
              {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="rxp-table-card glass">
        {error && (
          <div className="rxp-state rxp-state-error" role="alert">
            <AlertTriangle size={34} />
            <h4>{tr("بارگذاری نسخه‌ها ناموفق بود")}</h4>
            <p>{error}</p>
            <button type="button" className="btn btn-primary btn-sm" onClick={reload}>{tr("تلاش دوباره")}</button>
          </div>
        )}

        {!error && (
          <div className="rxp-table-wrap">
            <table className="rxp-table">
              <thead>
                <tr>
                  <th>{tr("شماره نسخه")}</th>
                  <th>{tr("تاریخ")}</th>
                  <th>{tr("نام بیمار")}</th>
                  <th>{tr("تشخیص")}</th>
                  <th>{tr("تعداد دارو")}</th>
                  <th>{tr("وضعیت")}</th>
                  <th>{tr("عملیات")}</th>
                </tr>
              </thead>
              <tbody>
                {loading && items.length === 0 && Array.from({ length: 6 }).map((_, i) => (
                  <tr key={`sk-${i}`} className="rxp-row-skeleton" aria-hidden="true">
                    {Array.from({ length: 7 }).map((__, j) => <td key={j}><span className="rxp-skeleton" /></td>)}
                  </tr>
                ))}
                {items.map((row) => (
                  <tr key={row.id} className={`rxp-row ${loading ? "is-loading" : ""}`} onClick={() => setSelected(row)}>
                    <td data-label={tr("شماره نسخه")}><span className="rxp-rxnum">{rxNumberOf(row)}</span></td>
                    <td data-label={tr("تاریخ")}>{fmtDate(row.createdAt)}</td>
                    <td data-label={tr("نام بیمار")}>
                      <b>{row.patientName || "—"}</b>
                      {row.patientCode && <small className="rxp-sub">{row.patientCode}</small>}
                    </td>
                    <td data-label={tr("تشخیص")}><span className="dxp-clip">{row.diagnosis || "—"}</span></td>
                    <td data-label={tr("تعداد دارو")}>
                      <span className="rxp-count" title={row.medicineNames || undefined}>{Number(row.itemCount).toLocaleString(numLocale())}</span>
                    </td>
                    <td data-label={tr("وضعیت")}><StatusBadge status={row.status} /></td>
                    <td data-label={tr("عملیات")} onClick={(e) => e.stopPropagation()}>
                      <div className="rxp-actions">
                        <button type="button" className="rxp-icon-btn rxp-view" title={tr("مشاهده")} aria-label={tr("مشاهده")} onClick={() => setSelected(row)}><Eye size={16} /></button>
                        {row.status === "active" && (
                          <button type="button" className="rxp-icon-btn" title={tr("ویرایش")} aria-label={tr("ویرایش")} onClick={() => setFormTarget({ row })}><Pencil size={16} /></button>
                        )}
                        <button type="button" className="rxp-icon-btn" title={tr("چاپ")} aria-label={tr("چاپ")} disabled={busyId === `print-${row.id}`} onClick={() => printRx(row)}><Printer size={16} /></button>
                        <button type="button" className="rxp-icon-btn" title={tr("دانلود PDF")} aria-label={tr("دانلود PDF")} disabled={busyId === `pdf-${row.id}`} onClick={() => pdfRx(row)}><Download size={16} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {!loading && items.length === 0 && (
              <div className="rxp-state">
                <ClipboardList size={38} />
                <h4>{hasFilters ? tr("نسخه‌ای با این مشخصات یافت نشد") : tr("هنوز نسخه‌ای ثبت نکرده‌اید")}</h4>
                <p>{hasFilters ? tr("جستجو یا فیلترها را تغییر دهید.") : tr("با دکمه‌ی «نسخه جدید» اولین نسخه را برای یکی از بیماران خود بنویسید.")}</p>
                {hasFilters && <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>{tr("پاک‌کردن فیلترها")}</button>}
              </div>
            )}
          </div>
        )}

        {!error && pagination && pagination.totalPages > 1 && (
          <div className="rxp-pagination">
            <button type="button" className="btn btn-ghost btn-sm" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)}>{tr("صفحه قبل")}</button>
            <span>{tr("صفحه {0} از {1} ({2} نسخه)", [pagination.page.toLocaleString(numLocale()), pagination.totalPages.toLocaleString(numLocale()), pagination.total.toLocaleString(numLocale())])}</span>
            <button type="button" className="btn btn-ghost btn-sm" disabled={page >= pagination.totalPages || loading} onClick={() => setPage(page + 1)}>{tr("صفحه بعد")}</button>
          </div>
        )}
      </div>

      <GlobalModal
        isOpen={!!selected}
        onClose={() => setSelected(null)}
        size="xl"
        title={selected ? tr("نسخه {0}", [rxNumberOf(selected)]) : ""}
        className="rxp-modal"
      >
        {selected && (
          <DoctorPrescriptionDetail
            row={selected}
            onPrint={() => printRx(selected)}
            onPdf={() => pdfRx(selected)}
            onEdit={() => { const r = selected; setSelected(null); setFormTarget({ row: r }); }}
            onError={(msg) => showToast(msg, "error")}
          />
        )}
      </GlobalModal>

      <GlobalModal
        isOpen={!!formTarget}
        onClose={() => setFormTarget(null)}
        size="xl"
        title={formTarget?.row ? tr("ویرایش نسخه {0}", [rxNumberOf(formTarget.row)]) : tr("نسخه جدید")}
        className="rxp-modal"
        closeOnOverlayClick={false}
      >
        {formTarget && (
          <PrescriptionForm
            row={formTarget.row}
            onCancel={() => setFormTarget(null)}
            onSaved={(msg) => { setFormTarget(null); showToast(msg, "success"); reload(); }}
          />
        )}
      </GlobalModal>
    </div>
  );
}

// ---------- فرم ثبت / ویرایش نسخه ----------
function PrescriptionForm({ row, onCancel, onSaved }) {
  const editing = !!row;
  const [patients, setPatients] = useState([]);
  const [patientId, setPatientId] = useState(row ? String(row.patientId) : "");
  const [form, setForm] = useState(EMPTY_FORM);
  const [medicines, setMedicines] = useState([{ ...EMPTY_MEDICINE }]);
  const [group, setGroup] = useState(null); // نسخه‌ی در حال ویرایش (با آرایه‌ی medicines)
  const [loading, setLoading] = useState(editing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const groupIdRef = useRef(null);
  const nameRefs = useRef([]);
  const [focusRow, setFocusRow] = useState(null);

  // بیماران مرتبط با همین داکتر (سرور فقط بیماران خودش را برمی‌گرداند)
  useEffect(() => {
    if (editing) return;
    apiRequest("/doctors/me/patients?limit=100")
      .then((d) => {
        const seen = new Map();
        // سرور فقط برای نوبت تأییدشده/انجام‌شده اجازه‌ی ثبت نسخه می‌دهد؛ بقیه را در لیست نشان نمی‌دهیم
        (d.patients || [])
          .filter((p) => ["confirmed", "completed"].includes(p.appointmentStatus))
          .forEach((p) => { if (!seen.has(p.patientId)) seen.set(p.patientId, p); });
        setPatients([...seen.values()]);
      })
      .catch((err) => setError(err.message));
  }, [editing]);

  // ویرایش: داروهای کل نسخه از پرونده‌ی بیمار خوانده می‌شوند
  useEffect(() => {
    if (!editing) return;
    let cancelled = false;
    apiRequest(`/medical-records/patient/${row.patientId}`)
      .then((data) => {
        if (cancelled) return;
        const g = groupPrescriptions(data.prescriptions || []).find((x) => x.medicines.some((m) => m.id === row.id));
        if (!g) { setError(tr("اقلام این نسخه یافت نشد.")); return; }
        setGroup(g);
        setForm({
          diagnosis: g.diagnosis || "",
          instructions: g.instructions || "",
          followUpDate: g.followUpDate ? String(g.followUpDate).slice(0, 10) : "",
          notes: g.notes || "",
        });
        setMedicines(g.medicines.map((m) => ({
          id: m.id,
          medicationName: m.medicationName || "",
          dosage: m.dosage || "",
          quantity: m.quantity || "",
          frequency: m.frequency || "",
          duration: m.duration || "",
          medicineNotes: m.medicineNotes || "",
        })));
      })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [editing, row]);

  useEffect(() => {
    if (focusRow !== null && nameRefs.current[focusRow]) {
      nameRefs.current[focusRow].focus();
      setFocusRow(null);
    }
  }, [focusRow, medicines.length]);

  const updateMed = (i, field, value) => setMedicines((rows) => rows.map((r, k) => (k === i ? { ...r, [field]: value } : r)));
  const addMed = () => { setMedicines((rows) => [...rows, { ...EMPTY_MEDICINE }]); setFocusRow(medicines.length); };
  const removeMed = (i) => setMedicines((rows) => (rows.length <= 1 ? [{ ...EMPTY_MEDICINE }] : rows.filter((_, k) => k !== i)));

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    if (!editing && !patientId) { setError(tr("بیمار را انتخاب کنید.")); return; }

    const filled = medicines
      .map((m) => ({
        id: m.id,
        medicationName: m.medicationName.trim(),
        dosage: m.dosage.trim(),
        quantity: m.quantity.trim(),
        frequency: m.frequency.trim(),
        duration: m.duration.trim(),
        medicineNotes: m.medicineNotes.trim(),
      }))
      .filter((m) => m.medicationName);
    if (filled.length === 0) { setError(tr("حداقل یک دارو (نام دارو) لازم است.")); return; }

    const shared = { ...form, followUpDate: form.followUpDate || undefined };
    const pid = editing ? row.patientId : Number(patientId);

    setSaving(true);
    try {
      if (editing) {
        const groupId = group.groupId || newGroupId();
        const keptIds = new Set(filled.filter((m) => m.id).map((m) => m.id));
        for (const old of group.medicines) {
          if (!keptIds.has(old.id)) await apiRequest(`/medical-records/prescriptions/${old.id}`, { method: "DELETE" });
        }
        for (const med of filled.filter((m) => m.id)) {
          const { id, ...fields } = med;
          await apiRequest(`/medical-records/prescriptions/${id}`, { method: "PUT", body: { ...shared, ...fields, groupId } });
        }
        for (const med of filled.filter((m) => !m.id)) {
          const { id, ...fields } = med;
          await apiRequest("/medical-records/prescriptions", { method: "POST", body: { ...shared, ...fields, patientId: pid, groupId } });
        }
        onSaved(tr("نسخه به‌روزرسانی شد."));
      } else {
        if (!groupIdRef.current) groupIdRef.current = newGroupId();
        let saved = 0;
        try {
          for (const med of filled) {
            const { id, ...fields } = med;
            await apiRequest("/medical-records/prescriptions", { method: "POST", body: { ...shared, ...fields, patientId: pid, groupId: groupIdRef.current } });
            saved += 1;
          }
        } catch (err) {
          // داروهای ثبت‌شده از فرم برداشته می‌شوند تا تلاش مجدد، تکراری ثبت نکند
          setMedicines(filled.slice(saved));
          throw new Error(tr("{0} دارو ثبت شد اما ثبت «{1}» ناموفق بود: {2}", [saved, filled[saved].medicationName, err.message]));
        }
        onSaved(filled.length > 1 ? tr("نسخه با {0} دارو ثبت شد.", [filled.length]) : tr("نسخه جدید ثبت شد."));
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <div className="rxp-detail-loading" aria-busy="true"><span className="rxp-skeleton rxp-skeleton-block" /><span className="rxp-skeleton rxp-skeleton-block tall" /></div>;

  return (
    <form className="dxp-form" dir={curDir()} onSubmit={handleSubmit}>
      {error && <div className="form-message error" role="alert">{error}</div>}

      <div className="field-row">
        <div className="field">
          <label>{tr("بیمار")}</label>
          {editing ? (
            <input value={row.patientName || ""} disabled />
          ) : (
            <select value={patientId} onChange={(e) => setPatientId(e.target.value)} required>
              <option value="">{tr("— انتخاب بیمار —")}</option>
              {patients.map((p) => (
                <option key={p.patientId} value={p.patientId}>
                  {p.patientName}{p.age != null ? tr(" ({0} ساله)", [p.age]) : ""}
                </option>
              ))}
            </select>
          )}
        </div>
        <div className="field">
          <label>{tr("تاریخ پیگیری")}</label>
          <JalaliDateInput value={form.followUpDate} onChange={(e) => setForm((f) => ({ ...f, followUpDate: e.target.value }))} />
        </div>
      </div>

      <div className="field">
        <label>{tr("تشخیص بیمار (Diagnosis)")}</label>
        <textarea rows={2} maxLength={1000} value={form.diagnosis} onChange={(e) => setForm((f) => ({ ...f, diagnosis: e.target.value }))} />
      </div>

      <div className="dxp-meds-head">
        <h4>{tr("داروها ({0})", [medicines.length.toLocaleString(numLocale())])}</h4>
        <button type="button" className="btn btn-ghost btn-sm" onClick={addMed}><Plus size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("افزودن دارو")}</button>
      </div>

      {medicines.map((m, i) => (
        <div className="dxp-med" key={m.id || `new-${i}`}>
          <div className="dxp-med-top">
            <span className="dxp-med-no">{(i + 1).toLocaleString(numLocale())}</span>
            <button type="button" className="rxp-icon-btn dxp-med-remove" onClick={() => removeMed(i)} aria-label={tr("حذف دارو {0}", [i + 1])} title={tr("حذف دارو")}>
              <Trash2 size={15} />
            </button>
          </div>
          <div className="dxp-med-grid">
            <div className="field dxp-wide">
              <label>{tr("نام دارو")}</label>
              <input
                ref={(el) => { nameRefs.current[i] = el; }}
                value={m.medicationName}
                maxLength={150}
                onChange={(e) => updateMed(i, "medicationName", e.target.value)}
                placeholder={tr("مثلاً: آموکسی‌سیلین")}
              />
            </div>
            <div className="field">
              <label>{tr("مقدار / دوز")}</label>
              <input value={m.dosage} maxLength={100} onChange={(e) => updateMed(i, "dosage", e.target.value)} placeholder={tr("۵۰۰mg")} />
            </div>
            <div className="field">
              <label>{tr("تعداد")}</label>
              <input value={m.quantity} maxLength={50} onChange={(e) => updateMed(i, "quantity", e.target.value)} placeholder={tr("۲۱ عدد")} />
            </div>
            <div className="field">
              <label>{tr("مدت مصرف")}</label>
              <input value={m.duration} maxLength={100} onChange={(e) => updateMed(i, "duration", e.target.value)} placeholder={tr("۷ روز")} />
            </div>
            <div className="field dxp-wide">
              <label>{tr("نحوه مصرف")}</label>
              <input value={m.frequency} maxLength={100} onChange={(e) => updateMed(i, "frequency", e.target.value)} placeholder={tr("هر ۸ ساعت ۱ عدد")} />
            </div>
            <div className="field dxp-full">
              <label>{tr("توضیحات دارو")}</label>
              <input value={m.medicineNotes} maxLength={500} onChange={(e) => updateMed(i, "medicineNotes", e.target.value)} placeholder={tr("مثلاً: بعد از غذا")} />
            </div>
          </div>
        </div>
      ))}

      <div className="field-row">
        <div className="field">
          <label>{tr("دستور مصرف کلی")}</label>
          <textarea rows={2} maxLength={1000} value={form.instructions} onChange={(e) => setForm((f) => ({ ...f, instructions: e.target.value }))} />
        </div>
        <div className="field">
          <label>{tr("توضیحات داکتر")}</label>
          <textarea rows={2} maxLength={1000} value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} />
        </div>
      </div>

      <div className="dxp-form-actions">
        <button type="submit" className="btn btn-primary" disabled={saving}>
          {saving ? tr("در حال ذخیره...") : editing ? tr("ذخیره تغییرات") : tr("ثبت نسخه")}
        </button>
        <button type="button" className="btn btn-ghost" onClick={onCancel} disabled={saving}>{tr("انصراف")}</button>
      </div>
    </form>
  );
}

// ---------- جزئیات نسخه + پرونده‌ی بیمار + Timeline ----------
function DoctorPrescriptionDetail({ row, onPrint, onPdf, onEdit, onError }) {
  const [tab, setTab] = useState("details");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [reloadTick, setReloadTick] = useState(0);

  // سرور مالکیت بیمار را بررسی می‌کند؛ برای بیمار غیرمرتبط ۴۰۳ برمی‌گردد
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    apiRequest(`/medical-records/patient/${row.patientId}`)
      .then((res) => { if (!cancelled) setData(res); })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [row.patientId, reloadTick]);

  const allGroups = useMemo(() => groupPrescriptions(data?.prescriptions || []), [data]);
  const rx = useMemo(() => allGroups.find((g) => g.medicines.some((m) => m.id === row.id)) || null, [allGroups, row.id]);
  const meds = rx?.medicines || [];
  const patient = data?.patient;
  const allergies = data?.allergies || [];
  const profileAllergies = [patient?.drugAllergies, patient?.allergies].filter(Boolean);
  const canEdit = row.status === "active";

  async function downloadLab(id) {
    try {
      await apiDownload(`/medical-records/lab-results/${id}/report`, `lab-report-${id}`, { openInNewTab: true });
    } catch (err) { onError(err.message); }
  }

  return (
    <div className="rxp-detail" dir={curDir()}>
      <div className="rxp-detail-top">
        <div className="rxp-detail-meta">
          <StatusBadge status={row.status} />
          <span>{tr("تاریخ نسخه:")}{" "}<b>{fmtDate(row.createdAt)}</b></span>
          <span>{tr("بیمار:")}{" "}<b>{row.patientName}</b></span>
        </div>
        <div className="rxp-detail-actions">
          <button type="button" className="btn btn-ghost btn-sm" onClick={onPrint}><Printer size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("چاپ")}</button>
          <button type="button" className="btn btn-ghost btn-sm" onClick={onPdf}><Download size={14} style={{ verticalAlign: "-2px" }} /> PDF</button>
          {canEdit
            ? <button type="button" className="btn btn-primary btn-sm" onClick={onEdit}><Pencil size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("ویرایش")}</button>
            : <span className="rxp-muted" title={tr("وضعیت نسخه را ادمین تعیین می‌کند")}>{tr("این نسخه قفل است و قابل ویرایش نیست")}</span>}
        </div>
      </div>

      <div className="rxp-tabs" role="tablist">
        {[["details", tr("💊 جزئیات نسخه")], ["file", tr("🗂️ پرونده مریض")], ["timeline", tr("🕒 تاریخچه (Timeline)")]].map(([k, label]) => (
          <button key={k} type="button" role="tab" aria-selected={tab === k} className={tab === k ? "active" : ""} onClick={() => setTab(k)}>{label}</button>
        ))}
      </div>

      {loading && (
        <div className="rxp-detail-loading" aria-busy="true">
          <span className="rxp-skeleton rxp-skeleton-block" />
          <span className="rxp-skeleton rxp-skeleton-block" />
          <span className="rxp-skeleton rxp-skeleton-block tall" />
        </div>
      )}

      {!loading && error && (
        <div className="rxp-state rxp-state-error" role="alert">
          <AlertTriangle size={30} />
          <h4>{tr("بارگذاری اطلاعات ناموفق بود")}</h4>
          <p>{error}</p>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setReloadTick((t) => t + 1)}>{tr("تلاش دوباره")}</button>
        </div>
      )}

      {!loading && !error && data && tab === "details" && (
        <>
          {(allergies.length > 0 || profileAllergies.length > 0) && (
            <div className="rxp-alert" role="note">
              <AlertTriangle size={18} />
              <div>
                <b>{tr("حساسیت‌های ثبت‌شده‌ی بیمار — پیش از تجویز بررسی شود")}</b>
                <p>{[...allergies.map((a) => `${a.allergen}${a.severity ? ` (${SEVERITY_LABEL[a.severity] || a.severity})` : ""}`), ...profileAllergies].join(tr("، "))}</p>
              </div>
            </div>
          )}

          <section className="rxp-card rxp-block">
            <h4>{tr("تشخیص")}</h4>
            <p>{rx?.diagnosis || row.diagnosis || tr("تشخیصی برای این نسخه ثبت نشده است.")}</p>
          </section>

          <section className="rxp-card rxp-block">
            <h4>{tr("داروهای نسخه ({0})", [meds.length.toLocaleString(numLocale())])}</h4>
            {meds.length === 0 ? (
              <p className="rxp-muted">{tr("اقلام این نسخه یافت نشد.")}</p>
            ) : (
              <div className="rxp-table-wrap">
                <table className="rxp-table rxp-table-compact">
                  <thead>
                    <tr><th>#</th><th>{tr("نام دارو")}</th><th>{tr("دوز")}</th><th>{tr("تعداد")}</th><th>{tr("مدت")}</th><th>{tr("نحوه مصرف")}</th><th>{tr("توضیحات")}</th></tr>
                  </thead>
                  <tbody>
                    {meds.map((m, i) => (
                      <tr key={m.id}>
                        <td data-label="#">{(i + 1).toLocaleString(numLocale())}</td>
                        <td data-label={tr("نام دارو")}><b>{m.medicationName}</b></td>
                        <td data-label={tr("دوز")}>{m.dosage || "—"}</td>
                        <td data-label={tr("تعداد")}>{m.quantity || "—"}</td>
                        <td data-label={tr("مدت")}>{m.duration || "—"}</td>
                        <td data-label={tr("نحوه مصرف")}>{m.frequency || "—"}</td>
                        <td data-label={tr("توضیحات")}>{m.medicineNotes || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>

          <div className="rxp-info-grid">
            <section className="rxp-card rxp-block"><h4>{tr("دستور مصرف کلی")}</h4><p>{rx?.instructions || "—"}</p></section>
            <section className="rxp-card rxp-block"><h4>{tr("توضیحات داکتر")}</h4><p>{rx?.notes || "—"}</p></section>
          </div>
          {rx?.followUpDate && <p className="rxp-muted">{tr("تاریخ پیگیری:")}{" "}<b>{fmtDate(rx.followUpDate)}</b></p>}
        </>
      )}

      {!loading && !error && data && tab === "file" && (
        <PatientFile data={data} allGroups={allGroups} currentId={row.id} onDownloadLab={downloadLab} />
      )}

      {!loading && !error && data && tab === "timeline" && (
        <PatientTimeline data={data} allGroups={allGroups} currentId={row.id} />
      )}
    </div>
  );
}

// ---------- پرونده‌ی مریض با ترتیب: اطلاعات ← سوابق ← تشخیص‌ها ← نسخه‌ها ← آزمایش‌ها ← رادیولوژی ← حساسیت‌ها ← یادداشت‌ها ----------
function PatientFile({ data, allGroups, currentId, onDownloadLab }) {
  const p = data.patient || {};
  const encounters = data.encounters || [];
  const diagnoses = data.diagnoses || [];
  const labs = data.labResults || [];
  const radiology = data.radiologyReports || [];
  const allergies = data.allergies || [];
  const noted = encounters.filter((e) => e.notes);

  return (
    <div className="rxp-history">
      <section className="rxp-card">
        <h4>{tr("۱. اطلاعات مریض")}</h4>
        <dl>
          <div><dt>{tr("نام مریض")}</dt><dd>{p.fullName || "—"}</dd></div>
          <div><dt>{tr("جنسیت")}</dt><dd>{GENDER_LABEL[p.gender] || "—"}</dd></div>
          <div><dt>{tr("تاریخ تولد")}</dt><dd>{fmtDate(p.dateOfBirth)}</dd></div>
          <div><dt>{tr("گروه خونی")}</dt><dd>{p.bloodGroup || "—"}</dd></div>
          <div><dt>{tr("شماره تماس")}</dt><dd dir="ltr">{p.phone || "—"}</dd></div>
        </dl>
      </section>

      <FileSection title={tr("۲. سوابق طبی (ویزیت‌ها)")} icon="📋" count={encounters.length} emptyText={tr("ویزیتی ثبت نشده است.")}>
        {encounters.map((e) => (
          <li key={e.id}>
            <div className="rxp-hist-head"><b>{fmtDate(e.visitDate || e.createdAt)}</b><span>{e.doctorName || "—"}</span></div>
            {e.symptoms && <p><em>{tr("علائم:")}</em> {e.symptoms}</p>}
            {e.treatment && <p><em>{tr("تداوی:")}</em> {e.treatment}</p>}
          </li>
        ))}
      </FileSection>

      <FileSection title={tr("۳. تشخیص‌ها")} icon="🩺" count={diagnoses.length} emptyText={tr("تشخیصی ثبت نشده است.")}>
        {diagnoses.map((d) => (
          <li key={d.id}>
            <div className="rxp-hist-head"><b>{d.title}</b><span>{DIAGNOSIS_STATUS_LABEL[d.status] || d.status}</span></div>
            <p>{[d.icdCode && `ICD: ${d.icdCode}`, d.doctorName, fmtDate(d.createdAt)].filter(Boolean).join(" — ")}</p>
          </li>
        ))}
      </FileSection>

      <FileSection title={tr("۴. نسخه‌ها")} icon="💊" count={allGroups.length} emptyText={tr("نسخه‌ای ثبت نشده است.")}>
        {allGroups.map((g) => (
          <li key={g.id}>
            <div className="rxp-hist-head">
              <b>{`RX-${String(g.id).padStart(6, "0")}`}{g.medicines.some((m) => m.id === currentId) ? tr(" (همین نسخه)") : ""}</b>
              <span>{fmtDate(g.createdAt)}</span>
            </div>
            <p>{g.medicines.map((m) => [m.medicationName, m.dosage].filter(Boolean).join(" ")).join(tr("، "))}</p>
            <p className="rxp-muted">{[g.doctorName, g.diagnosis].filter(Boolean).join(" — ")}</p>
          </li>
        ))}
      </FileSection>

      <FileSection title={tr("۵. آزمایش‌ها")} icon="🧪" count={labs.length} emptyText={tr("نتیجه‌ی آزمایشی ثبت نشده است.")}>
        {labs.map((l) => (
          <li key={l.id}>
            <div className="rxp-hist-head"><b>{l.testName}</b><span>{LAB_STATUS_LABEL[l.status] || l.status}</span></div>
            <p>{[l.result && tr("نتیجه: {0}{1}", [l.result, l.unit ? ` ${l.unit}` : ""]), l.referenceRange && tr("محدوده‌ی نرمال: {0}", [l.referenceRange]), fmtDate(l.testDate || l.createdAt)].filter(Boolean).join(" — ")}</p>
            {l.reportUrl && <button type="button" className="btn btn-ghost btn-sm" onClick={() => onDownloadLab(l.id)}><Download size={13} style={{ verticalAlign: "-2px" }} />{" "}{tr("گزارش آزمایش")}</button>}
          </li>
        ))}
      </FileSection>

      <FileSection title={tr("۶. رادیولوژی")} icon="🩻" count={radiology.length} emptyText={tr("گزارش رادیولوژی ثبت نشده است.")}>
        {radiology.map((r) => (
          <li key={r.id}>
            <div className="rxp-hist-head"><b>{r.examType}</b><span>{fmtDate(r.examDate || r.createdAt)}</span></div>
            {r.findings && <p><em>{tr("یافته‌ها:")}</em> {r.findings}</p>}
            {r.impression && <p><em>{tr("نتیجه‌گیری:")}</em> {r.impression}</p>}
          </li>
        ))}
      </FileSection>

      <FileSection title={tr("۷. حساسیت‌ها")} icon="⚠️" count={allergies.length} emptyText={tr("حساسیتی ثبت نشده است.")}>
        {allergies.map((a) => (
          <li key={a.id}>
            <div className="rxp-hist-head"><b>{a.allergen}</b><span>{SEVERITY_LABEL[a.severity] || a.severity}</span></div>
            {a.reaction && <p><em>{tr("واکنش:")}</em> {a.reaction}</p>}
          </li>
        ))}
      </FileSection>

      <FileSection title={tr("۸. یادداشت‌های پزشکی")} icon="📝" count={noted.length} emptyText={tr("یادداشتی ثبت نشده است.")}>
        {noted.map((e) => (
          <li key={e.id}>
            <div className="rxp-hist-head"><b>{fmtDate(e.visitDate || e.createdAt)}</b><span>{e.doctorName || "—"}</span></div>
            <p>{e.notes}</p>
          </li>
        ))}
      </FileSection>
    </div>
  );
}

function FileSection({ title, icon, count, emptyText, children }) {
  return (
    <details className="rxp-hist" open={count > 0 && count <= 3}>
      <summary>
        <span>{icon} {title}</span>
        <span className="rxp-hist-count">{Number(count).toLocaleString(numLocale())}</span>
      </summary>
      {count === 0 ? <p className="rxp-muted rxp-hist-empty">{emptyText}</p> : <ul>{children}</ul>}
    </details>
  );
}

// ---------- Timeline: نسخه‌های قبلی (برجسته) + ویزیت/آزمایش/رادیولوژی به ترتیب زمان ----------
function PatientTimeline({ data, allGroups, currentId }) {
  const [onlyRx, setOnlyRx] = useState(true);

  const events = useMemo(() => {
    const list = allGroups.map((g) => ({
      key: `rx-${g.id}`, type: "rx", date: g.createdAt,
      title: tr("نسخه RX-{0}", [String(g.id).padStart(6, "0")]),
      body: g.medicines.map((m) => [m.medicationName, m.dosage].filter(Boolean).join(" ")).join(tr("، ")),
      meta: [g.doctorName, g.diagnosis].filter(Boolean).join(" — "),
      current: g.medicines.some((m) => m.id === currentId),
    }));
    if (!onlyRx) {
      (data.encounters || []).forEach((e) => list.push({ key: `en-${e.id}`, type: "visit", date: e.visitDate || e.createdAt, title: tr("ویزیت"), body: e.treatment || e.symptoms || "", meta: e.doctorName || "" }));
      (data.labResults || []).forEach((l) => list.push({ key: `lab-${l.id}`, type: "lab", date: l.testDate || l.createdAt, title: tr("آزمایش: {0}", [l.testName]), body: l.result ? tr("نتیجه: {0}{1}", [l.result, l.unit ? ` ${l.unit}` : ""]) : "", meta: "" }));
      (data.radiologyReports || []).forEach((r) => list.push({ key: `rad-${r.id}`, type: "rad", date: r.examDate || r.createdAt, title: tr("رادیولوژی: {0}", [r.examType]), body: r.impression || "", meta: "" }));
    }
    return list.sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [data, allGroups, currentId, onlyRx]);

  return (
    <div className="dxp-timeline-wrap">
      <label className="dxp-check">
        <input type="checkbox" checked={onlyRx} onChange={(e) => setOnlyRx(e.target.checked)} />{" "}{tr("فقط نسخه‌ها")}</label>
      {events.length === 0 ? (
        <p className="rxp-muted">{tr("رویدادی برای نمایش وجود ندارد.")}</p>
      ) : (
        <ol className="dxp-timeline">
          {events.map((ev) => (
            <li key={ev.key} className={`dxp-tl-item dxp-tl-${ev.type} ${ev.current ? "is-current" : ""}`}>
              <span className="dxp-tl-dot" />
              <div className="dxp-tl-card">
                <div className="rxp-hist-head"><b>{ev.title}{ev.current ? tr(" (همین نسخه)") : ""}</b><span>{fmtDate(ev.date)}</span></div>
                {ev.body && <p>{ev.body}</p>}
                {ev.meta && <p className="rxp-muted">{ev.meta}</p>}
              </div>
            </li>
          ))}
        </ol>
      )}
    </div>
  );
}

import { AlertCircle, Inbox, RefreshCw, SearchX } from "lucide-react";

import { tr } from "../../../i18n/tr.js";
// ==========================================================================
// اجزای نمایشی مشترک داشبورد بیمار (Design System — کلاس‌های pd-*)
// این فایل فقط UI است: هیچ درخواست شبکه‌ای، State داده‌ای یا منطق پزشکی/مالی ندارد.
// استایل‌ها در pages/dashboard/user/UserDashboard.css و فقط زیر .dash-shell--patient اعمال می‌شوند
// تا داشبوردهای داکتر/ادمین/سوپرادمین هیچ تغییری نکنند.
// ==========================================================================

// هدر استاندارد هر بخش: آیکون + عنوان + توضیح کوتاه + (اختیاری) اکشن سمت چپ
export function PageHeader({ icon: Icon, title, subtitle, actions, titleId }) {
  return (
    <header className="pd-page-header">
      {Icon && (
        <span className="pd-page-header-icon" aria-hidden="true">
          <Icon size={22} />
        </span>
      )}
      <div className="pd-page-header-text">
        <h2 id={titleId}>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>
      {actions && <div className="pd-page-header-actions">{actions}</div>}
    </header>
  );
}

// کارت پایه با عنوان بخش (برای دسته‌بندی اطلاعات)
export function SectionCard({ icon: Icon, title, hint, children, className = "" }) {
  return (
    <section className={`pd-card ${className}`}>
      {title && (
        <div className="pd-card-head">
          {Icon && (
            <span className="pd-card-head-icon" aria-hidden="true">
              <Icon size={17} />
            </span>
          )}
          <div>
            <h3>{title}</h3>
            {hint && <p>{hint}</p>}
          </div>
        </div>
      )}
      {children}
    </section>
  );
}

// Badge استاندارد — tone: success | warning | info | danger | neutral
export function Badge({ tone = "neutral", icon: Icon, children }) {
  return (
    <span className={`pd-badge pd-badge-${tone}`}>
      {Icon && <Icon size={12} aria-hidden="true" />}
      {children}
    </span>
  );
}

// کارت آمار خلاصه
export function StatCard({ icon: Icon, label, value, tone = "neutral", hint }) {
  return (
    <div className={`pd-stat pd-stat-${tone}`}>
      {Icon && (
        <span className="pd-stat-icon" aria-hidden="true">
          <Icon size={18} />
        </span>
      )}
      <div className="pd-stat-body">
        <span className="pd-stat-label">{label}</span>
        <strong className="pd-stat-value">{value}</strong>
        {hint && <span className="pd-stat-hint">{hint}</span>}
      </div>
    </div>
  );
}

// ردیف «برچسب / مقدار» در کارت اطلاعات. مقدار خالی با متن کم‌رنگ «ثبت نشده» نمایش داده می‌شود
// (هیچ مقدار ساختگی‌ای نمایش داده نمی‌شود).
export function InfoItem({ label, value, wide = false, dir, emptyText = tr("ثبت نشده") }) {
  const empty = value === null || value === undefined || value === "";
  return (
    <div className={`pd-info-item ${wide ? "pd-info-item-wide" : ""}`}>
      <span className="pd-info-label">{label}</span>
      {empty ? (
        <span className="pd-info-value pd-info-empty">{emptyText}</span>
      ) : (
        <strong className="pd-info-value" dir={dir}>
          {value}
        </strong>
      )}
    </div>
  );
}

// اسکلت بارگذاری — به‌جای صفحه‌ی خالی/متن «در حال بارگذاری»
export function Skeleton({ width, height = 14, radius, style }) {
  return <span className="pd-skeleton" style={{ width, height, borderRadius: radius, ...style }} aria-hidden="true" />;
}

export function SkeletonBlock({ rows = 4, label = tr("در حال بارگذاری") }) {
  return (
    <div className="pd-skeleton-block" role="status" aria-live="polite" aria-label={label}>
      {Array.from({ length: rows }).map((_, i) => (
        <div className="pd-skeleton-row" key={i}>
          <Skeleton width="22%" height={12} />
          <Skeleton width={`${55 + ((i * 13) % 35)}%`} height={12} />
        </div>
      ))}
    </div>
  );
}

export function SkeletonStats({ count = 4 }) {
  return (
    <div className="pd-stats" role="status" aria-label={tr("در حال بارگذاری آمار")}>
      {Array.from({ length: count }).map((_, i) => (
        <div className="pd-stat" key={i}>
          <Skeleton width={38} height={38} radius="12px" />
          <div className="pd-stat-body">
            <Skeleton width={70} height={11} />
            <Skeleton width={46} height={20} />
          </div>
        </div>
      ))}
    </div>
  );
}

// حالت خالی
export function EmptyState({ icon: Icon = Inbox, title, description, action }) {
  return (
    <div className="pd-state pd-state-empty">
      <span className="pd-state-icon" aria-hidden="true">
        <Icon size={26} />
      </span>
      <h4>{title}</h4>
      {description && <p>{description}</p>}
      {action}
    </div>
  );
}

// «نتیجه‌ای برای جستجو/فیلتر یافت نشد»
export function NoResults({ onReset }) {
  return (
    <EmptyState
      icon={SearchX}
      title={tr("نتیجه‌ای یافت نشد")}
      description={tr("هیچ موردی با جستجو یا فیلتر انتخاب‌شده مطابقت ندارد.")}
      action={
        onReset && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={onReset}>
            {tr("پاک‌کردن فیلترها")}
          </button>
        )
      }
    />
  );
}

// حالت خطا — با دکمه‌ی تلاش دوباره در صورت ارائه‌ی onRetry
export function ErrorState({ message, onRetry }) {
  return (
    <div className="pd-state pd-state-error" role="alert">
      <span className="pd-state-icon" aria-hidden="true">
        <AlertCircle size={26} />
      </span>
      <h4>{tr("دریافت اطلاعات ناموفق بود")}</h4>
      {message && <p>{message}</p>}
      {onRetry && (
        <button type="button" className="btn btn-ghost btn-sm" onClick={onRetry}>
          <RefreshCw size={14} aria-hidden="true" />
          {tr("تلاش دوباره")}
        </button>
      )}
    </div>
  );
}

// پیام وضعیت درون‌خطی (موفقیت/خطا) برای فرم‌ها
export function Notice({ type = "error", children }) {
  if (!children) return null;
  return (
    <div className={`pd-notice pd-notice-${type}`} role={type === "error" ? "alert" : "status"}>
      {children}
    </div>
  );
}

// فیلد فرم با برچسب، راهنما و خطای همان فیلد
export function FormField({ id, label, required, hint, error, wide = false, children }) {
  return (
    <div className={`pd-field ${error ? "has-error" : ""} ${wide ? "pd-field-wide" : ""}`}>
      <label htmlFor={id}>
        {label}
        {required && <span className="pd-required" aria-hidden="true"> *</span>}
      </label>
      {children}
      {error ? (
        <span className="pd-field-error" id={`${id}-error`} role="alert">
          {error}
        </span>
      ) : (
        hint && <span className="pd-field-hint">{hint}</span>
      )}
    </div>
  );
}

import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { ArrowRight, ClipboardList, Loader2, AlertTriangle, RefreshCw, Stethoscope } from "lucide-react";
import { apiRequest, apiDownload } from "../../utils/api.js";
import useHighlightParam from "../../hooks/useHighlightParam.js";
import ReportView from "../../pages/dashboard/doctor/healthRecord/ReportView.jsx";
import { ImagePreview } from "../../pages/dashboard/doctor/healthRecord/hrFields.jsx";
import { fmtDay, fmtDateTime, toFa } from "../../pages/dashboard/doctor/healthRecord/hrConstants.js";
import { tr } from "../../i18n/tr.js";
import "../../pages/dashboard/doctor/healthRecord/HealthRecordForm.css";

// ============================================================================
// پنل بیمار «پرونده‌های صحی من» — کاملاً فقط‌خواندنی
// ----------------------------------------------------------------------------
//   GET /api/users/health-records                      فهرست پرونده‌های ثبت‌شده‌ی خودِ بیمار (پیش‌نویس‌ها هرگز)
//   GET /api/users/health-records/:id                  جزئیات (۴۰۴ برای پرونده‌ی دیگران)
//   GET /api/users/health-records/files/:fileId        تصویر/سند — فقط بعد از «ارسال» گزارش توسط داکتر
// مالکیت سمت سرور از روی توکن بررسی می‌شود؛ هیچ دکمه‌ی ساخت/ویرایش/حذف وجود ندارد.
// توصیه‌ها، پیگیری و فایل‌ها تا قبل از ارسال گزارش توسط داکتر نمایش داده نمی‌شوند.
// ============================================================================
const str = (v) => (v == null ? "" : String(v));

function toReportData(detail) {
  const { record: r, labResults, files } = detail;
  const form = {
    visitDate: str(r.visitDate).slice(0, 10), visitReason: str(r.visitReason),
    bloodPressure: str(r.bloodPressure), pulse: str(r.pulse), temperature: str(r.temperature), respiratoryRate: str(r.respiratoryRate),
    weight: str(r.weight), height: str(r.height), spo2: str(r.spo2),
    chiefComplaint: str(r.chiefComplaint), symptoms: str(r.symptoms),
    generalCondition: "", examFindings: "", systemsReview: {}, abnormalFindings: "", examNotes: "",
    primaryDiagnosis: str(r.primaryDiagnosis), diagnosis: str(r.diagnosis), diagnosisNotes: str(r.diagnosisNotes),
    recommendations: r.recommendations || {},
    followUpRequired: !!Number(r.followUpRequired), followUpDate: str(r.followUpDate).slice(0, 10), followUpStatus: r.followUpStatus || "", followUpNotes: str(r.followUpNotes),
  };
  return {
    patient: { fullName: r.patientName, publicCode: r.patientCode },
    doctor: { fullName: r.doctorName, department: r.department },
    form,
    labs: labResults.map((l) => ({ key: `l${l.id}`, testName: l.testName, result: l.result, unit: l.unit, referenceRange: l.referenceRange, testDate: str(l.testDate).slice(0, 10), status: l.status })),
    sentAt: r.sentToPatientAt, sentNote: r.sentNote,
    _files: files, _released: !!r.released,
  };
}

// تصویرها و اسناد پیوستِ پرونده را برای ReportView آماده می‌کند (مشترک بین صفحه‌ی پرونده‌ها و مودال «همه اسناد»)
function attachFiles(data, setPreview, openFile) {
  data.images = data._files.filter((f) => f.kind === "image").map((f) => ({
    key: `f${f.id}`, title: f.title, category: f.category, fileDate: f.fileDate, description: f.description, path: `/users/health-records/files/${f.id}`,
    onOpen: () => setPreview({ path: `/users/health-records/files/${f.id}`, title: f.title, date: f.fileDate, description: f.description }),
  }));
  data.docs = data._files.filter((f) => f.kind === "document").map((f) => ({
    key: `f${f.id}`, title: f.title, category: f.category, fileDate: f.fileDate, originalName: f.originalName, onOpen: (dl) => openFile(f.id, f.originalName, dl),
  }));
}

// جزئیات فقط‌خواندنیِ یک پرونده‌ی صحی (بدون هدر/دکمه‌ی بازگشت) — برای نمایش داخل مودال «همه اسناد»
// همان مسیر GET /api/users/health-records/:id؛ مالکیت سمت سرور بررسی می‌شود.
export function HealthRecordDetailView({ id }) {
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [preview, setPreview] = useState(null);
  const [actionError, setActionError] = useState("");

  useEffect(() => {
    let cancelled = false;
    setLoading(true); setError(""); setDetail(null);
    apiRequest(`/users/health-records/${id}`)
      .then((d) => { if (!cancelled) setDetail(d); })
      .catch((e) => { if (!cancelled) setError(e.message || tr("بارگذاری پرونده انجام نشد.")); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [id]);

  async function openFile(fileId, name, download) {
    setActionError("");
    try { await apiDownload(`/users/health-records/files/${fileId}${download ? "?download=1" : ""}`, name || "file", { openInNewTab: !download }); } catch (e) { setActionError(e.message); }
  }

  const data = detail ? toReportData(detail) : null;
  if (data) attachFiles(data, setPreview, openFile);
  return (
    <div className="hr-page">
      {loading && <div className="hr-state"><Loader2 className="hr-spin" size={22} /> {tr("در حال بارگذاری...")}</div>}
      {error && <div className="hr-state hr-state-err"><AlertTriangle size={22} /><p>{error}</p></div>}
      {actionError && <div className="hr-banner hr-banner-error" role="alert">{actionError}</div>}
      {data && <ReportView data={data} variant="patient" released={data._released} />}
      <ImagePreview item={preview} onClose={() => setPreview(null)} />
    </div>
  );
}

export default function PatientHealthRecords() {
  const { highlightId } = useHighlightParam();
  const [, setSearchParams] = useSearchParams();
  const [records, setRecords] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [openId, setOpenId] = useState(null);
  const [detail, setDetail] = useState(null);
  const [detailLoading, setDetailLoading] = useState(false);
  const [detailError, setDetailError] = useState("");
  const [preview, setPreview] = useState(null);
  const [actionError, setActionError] = useState("");

  function load() {
    setLoading(true);
    setError("");
    apiRequest("/users/health-records")
      .then((d) => setRecords(d.records || []))
      .catch((e) => setError(e.message || tr("بارگذاری پرونده‌ها انجام نشد.")))
      .finally(() => setLoading(false));
  }
  useEffect(load, []);

  function open(id) {
    setOpenId(id);
    setDetail(null);
    setDetailError("");
    setDetailLoading(true);
    apiRequest(`/users/health-records/${id}`)
      .then((d) => setDetail(d))
      .catch((e) => setDetailError(e.message || tr("بارگذاری پرونده انجام نشد.")))
      .finally(() => setDetailLoading(false));
  }
  // پرونده‌ی اشاره‌شده در اعلان یک‌بار باز می‌شود و پارامتر از آدرس پاک می‌شود (تا با برگشت به تب دوباره باز نشود)
  useEffect(() => {
    if (!highlightId) return;
    open(highlightId);
    setSearchParams((prev) => { const n = new URLSearchParams(prev); n.delete("highlight"); return n; }, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [highlightId]);

  async function openFile(fileId, name, download) {
    setActionError("");
    try { await apiDownload(`/users/health-records/files/${fileId}${download ? "?download=1" : ""}`, name || "file", { openInNewTab: !download }); } catch (e) { setActionError(e.message); }
  }

  if (openId) {
    const data = detail ? toReportData(detail) : null;
    if (data) attachFiles(data, setPreview, openFile);
    return (
      <div className="hr-page">
        <header className="hr-head">
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setOpenId(null); setDetail(null); }}><ArrowRight size={15} aria-hidden="true" /> {tr("بازگشت به فهرست")}</button>
          <div className="hr-head-text"><h2>{tr("پرونده صحی")}</h2><p>{tr("این صفحه فقط برای مشاهده است.")}</p></div>
          {data && (data._released ? <span className="hr-badge hr-badge-sent">{tr("گزارش ارسال‌شده")}</span> : <span className="hr-badge hr-badge-ok">{tr("ثبت‌شده")}</span>)}
        </header>
        {detailLoading && <div className="hr-state"><Loader2 className="hr-spin" size={22} /> {tr("در حال بارگذاری...")}</div>}
        {detailError && <div className="hr-state hr-state-err"><AlertTriangle size={22} /><p>{detailError}</p></div>}
        {actionError && <div className="hr-banner hr-banner-error" role="alert">{actionError}</div>}
        {data && <ReportView data={data} variant="patient" released={data._released} />}
        <ImagePreview item={preview} onClose={() => setPreview(null)} />
      </div>
    );
  }

  return (
    <div className="hr-page">
      <header className="hr-head">
        <span className="hr-section-no"><ClipboardList size={16} /></span>
        <div className="hr-head-text"><h2>{tr("پرونده‌های صحی من")}</h2><p>{tr("گزارش‌هایی که داکتر برای شما ثبت یا ارسال کرده است (فقط مشاهده)")}</p></div>
        <button type="button" className="btn btn-ghost btn-sm" onClick={load} disabled={loading}><RefreshCw size={14} className={loading ? "hr-spin" : undefined} aria-hidden="true" /> {tr("بروزرسانی")}</button>
      </header>
      {error && <div className="hr-state hr-state-err"><AlertTriangle size={22} /><p>{error}</p><button type="button" className="btn btn-ghost btn-sm" onClick={load}>{tr("تلاش دوباره")}</button></div>}
      {loading && !records && !error && <div className="hr-state"><Loader2 className="hr-spin" size={22} /> {tr("در حال بارگذاری...")}</div>}
      {records && records.length === 0 && <div className="hr-state"><Stethoscope size={22} /> {tr("هنوز پرونده صحی‌ای برای شما ثبت نشده است.")}</div>}
      {records && records.length > 0 && (
        <div className="hr-my-list">
          {records.map((r) => (
            <button key={r.id} type="button" className="hr-my-card" onClick={() => open(r.id)}>
              <div className="hr-my-meta">
                <span>{fmtDay(r.visitDate)}</span>
                {r.released ? <span className="hr-badge hr-badge-sent">{tr("گزارش ارسال‌شده")}</span> : <span className="hr-badge hr-badge-ok">{tr("ثبت‌شده")}</span>}
              </div>
              <h4>{r.diagnosis || r.visitReason || tr("پرونده صحی")}</h4>
              <p>{r.doctorName ? tr("داکتر {0}", [r.doctorName]) : ""}{r.department ? ` — ${r.department}` : ""}</p>
              {r.released && <p>{r.fileCount > 0 ? tr("{0} فایل پیوست", [toFa(r.fileCount)]) : ""}{r.sentToPatientAt ? ` • ${tr("ارسال: {0}", [fmtDateTime(r.sentToPatientAt)])}` : ""}</p>}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

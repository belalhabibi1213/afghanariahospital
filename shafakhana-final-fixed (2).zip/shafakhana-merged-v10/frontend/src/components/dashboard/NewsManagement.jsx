import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  Search, X, Eye, Pencil, Trash2, Pin, PinOff, MoreVertical, Plus, Newspaper, CheckCircle2,
  Clock, FileText, BarChart3, EyeOff, Image as ImageIcon, Upload, Star, ChevronRight, ChevronLeft, Link2,
} from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import { useDepartmentToasts, DepartmentToastContainer } from "./DepartmentToast.jsx";
import { apiRequest, apiUpload, resolvePhotoUrl } from "../../utils/api.js";
import { isScrollbarClick } from "../../utils/scrollbarClick.js";

import { JalaliDateTimeInput } from "../JalaliDateInput.jsx";
import { tr, trc, numLocale } from "../../i18n/tr.js";
import { sanitizeHtml } from "../../utils/sanitizeHtml.js";
// ============================================================================
// مدیریت اخبار و اعلانات (Admin Dashboard)
// ----------------------------------------------------------------------------
// فقط رابط کاربری حرفه‌ای‌سازی شده است؛ هیچ API/مدل/جدول جدیدی ساخته نشده و همه‌ی
// عملیات به همان endpointهای قبلی /admin/news وصل است:
//   GET  /admin/news                    فهرست همه‌ی اخبار (همه‌ی وضعیت‌ها)
//   GET  /admin/news/stats              آمار واقعی (مجموع/منتشرشده/پیش‌نویس/زمان‌بندی/سنجاق/بازدید)
//   POST /admin/news  ·  PUT /admin/news/:id         ایجاد / ویرایش
//   PUT  /admin/news/:id/status         انتشار / لغو انتشار (draft | published)
//   PUT  /admin/news/:id/pin            سنجاق / برداشتن سنجاق
//   POST /admin/news/:id/image          آپلود عکس شاخص
//   GET/POST/DELETE /admin/news/:id/gallery[/:imageId]   گالری تصاویر
//   DELETE /admin/news/:id              حذف
// جستجو، فیلتر، مرتب‌سازی و صفحه‌بندی روی همان فهرست دریافت‌شده در مرورگر انجام می‌شود.
// استایل‌ها: components/dashboard/NewsManagement.css (کلاس‌های nm-*) و فقط از توکن‌های تم موجود استفاده می‌کنند.
// ============================================================================

const STATUS_LABEL = trc({ published: "منتشرشده", scheduled: "زمان‌بندی‌شده", draft: "پیش‌نویس" });
const STATUS_FILTERS = ["all", "published", "scheduled", "draft"];
const PAGE_SIZE = 10;
const ALLOWED_PHOTO_TYPES = ["image/jpeg", "image/png", "image/webp"];
const MAX_PHOTO_SIZE = 2 * 1024 * 1024; // ۲ مگابایت (همان محدودیت بک‌اند)
const SORT_OPTIONS = trc([
  { value: "default", label: "پیش‌فرض (سنجاق‌شده‌ها اول)" },
  { value: "newest", label: "جدیدترین" },
  { value: "oldest", label: "قدیمی‌ترین" },
  { value: "views", label: "بیشترین بازدید" },
  { value: "published", label: "ترتیب انتشار" },
]);
const EDITOR_TABS = trc([
  { key: "content", label: "محتوا" },
  { key: "media", label: "رسانه" },
  { key: "taxonomy", label: "دسته‌بندی و برچسب" },
  { key: "publish", label: "انتشار" },
  { key: "seo", label: "سئو (SEO)" },
]);
const emptyForm = {
  title: "", excerpt: "", content: "", titleEn: "", excerptEn: "", contentEn: "", tag: "", tags: [], author: "",
  status: "draft", scheduledAt: "", isPinned: false, metaTitle: "", metaDescription: "",
};

const fa = (n) => Number(n || 0).toLocaleString(numLocale());
const fmtDate = (v) => (v ? new Date(v).toLocaleDateString(numLocale()) : "—");
const fmtDateTime = (v) => (v ? new Date(v).toLocaleString(numLocale()) : "—");

function validatePhotoFile(file) {
  if (!ALLOWED_PHOTO_TYPES.includes(file.type)) return tr("فرمت عکس مجاز نیست. فقط JPG، PNG یا WEBP مجاز است.");
  if (file.size > MAX_PHOTO_SIZE) return tr("حجم عکس نباید بیشتر از ۲ مگابایت باشد.");
  return null;
}

// برای فیلد datetime-local: مقدار ISO سرور را به «YYYY-MM-DDTHH:mm» به وقت محلی تبدیل می‌کند
function toLocalInput(v) {
  if (!v) return "";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// ---------- ویرایشگر متن غنی (RTL) — همان قابلیت‌های قبلی، بدون کتابخانه‌ی جانبی ----------
// خروجی HTML در بک‌اند دوباره پاک‌سازی می‌شود (utils/sanitizeNewsContent.js).
const RICH_TEXT_TOOLBAR = trc([
  { cmd: "bold", label: "B", title: "ضخیم" },
  { cmd: "italic", label: "I", title: "مورب" },
  { cmd: "underline", label: "U", title: "زیرخط" },
  { cmd: "formatBlock:h2", label: "H2", title: "عنوان بزرگ" },
  { cmd: "formatBlock:h3", label: "H3", title: "عنوان متوسط" },
  { cmd: "insertUnorderedList", label: "•", title: "لیست نقطه‌ای" },
  { cmd: "insertOrderedList", label: "۱.", title: "لیست شماره‌دار" },
  { cmd: "formatBlock:blockquote", label: "❝", title: "نقل‌قول" },
  { cmd: "removeFormat", label: "پاک", title: "حذف قالب‌بندی" },
]);

function RichTextEditor({ value, onChange, dir = "rtl", label = tr("متن کامل خبر") }) {
  const editorRef = useRef(null);

  useEffect(() => {
    // فقط وقتی محتوای بیرونی واقعاً عوض شده DOM را همگام می‌کنیم تا مکان‌نما نپرد
    if (editorRef.current && editorRef.current.innerHTML !== (value || "")) {
      editorRef.current.innerHTML = value || "";
    }
  }, [value]);

  function exec(cmd) {
    editorRef.current?.focus();
    if (cmd.startsWith("formatBlock:")) document.execCommand("formatBlock", false, cmd.split(":")[1]);
    else document.execCommand(cmd, false, null);
    onChange(editorRef.current?.innerHTML || "");
  }

  function insertLink() {
    editorRef.current?.focus();
    const url = window.prompt(tr("آدرس لینک را وارد کنید:"), "https://");
    if (url) document.execCommand("createLink", false, url);
    onChange(editorRef.current?.innerHTML || "");
  }

  return (
    <div className="rich-text-editor nm-editor">
      <div className="rich-text-toolbar" role="toolbar" aria-label={tr("ابزار قالب‌بندی متن")}>
        {RICH_TEXT_TOOLBAR.map((btn) => (
          <button key={btn.cmd} type="button" title={btn.title} aria-label={btn.title} onClick={() => exec(btn.cmd)}>
            {btn.label}
          </button>
        ))}
        <button type="button" title={tr("افزودن لینک")} aria-label={tr("افزودن لینک")} onClick={insertLink}><Link2 size={14} /></button>
      </div>
      <div
        ref={editorRef}
        className="rich-text-content"
        contentEditable
        dir={dir}
        role="textbox"
        aria-multiline="true"
        aria-label={label}
        onInput={(e) => onChange(e.currentTarget.innerHTML)}
        suppressContentEditableWarning
      />
    </div>
  );
}

// ---------- ورودی برچسب‌ها (چیپ) — در نهایت با کاما جدا و مثل قبل ذخیره می‌شود ----------
function TagInput({ value, onChange, suggestions }) {
  const [draft, setDraft] = useState("");

  function commit(raw) {
    const parts = String(raw).split(/[,،]/).map((t) => t.trim()).filter(Boolean);
    if (parts.length === 0) return;
    const next = [...value];
    parts.forEach((p) => { if (!next.includes(p)) next.push(p); });
    onChange(next);
    setDraft("");
  }

  return (
    <div className="nm-tags">
      <div className="nm-chips">
        {value.map((t) => (
          <span className="nm-chip" key={t}>
            {t}
            <button type="button" aria-label={tr("حذف برچسب {0}", [t])} onClick={() => onChange(value.filter((x) => x !== t))}><X size={12} /></button>
          </span>
        ))}
      </div>
      <input
        id="nm-tags-input"
        list="nm-tags-suggest"
        value={draft}
        placeholder={tr("برچسب را بنویسید و Enter بزنید")}
        onChange={(e) => (/[,،]$/.test(e.target.value) ? commit(e.target.value) : setDraft(e.target.value))}
        onKeyDown={(e) => {
          if (e.key === "Enter") { e.preventDefault(); commit(draft); }
          if (e.key === "Backspace" && !draft && value.length) onChange(value.slice(0, -1));
        }}
        onBlur={() => commit(draft)}
      />
      <datalist id="nm-tags-suggest">{suggestions.filter((s) => !value.includes(s)).map((s) => <option key={s} value={s} />)}</datalist>
    </div>
  );
}

function StatusBadge({ status }) {
  return <span className={`nm-status is-${status}`}>{STATUS_LABEL[status] || status}</span>;
}

function Thumb({ item, className = "" }) {
  return item.imageUrl
    ? <img className={`nm-thumb ${className}`} src={resolvePhotoUrl(item.imageUrl)} alt={item.title} loading="lazy" />
    : <span className={`nm-thumb nm-thumb-empty ${className}`} aria-hidden="true"><ImageIcon size={20} /></span>;
}

// ---------- گالری (حالت ویرایش: همان endpointهای قبلی؛ حالت خبر جدید: صف آپلود پس از ثبت) ----------
function GalleryManager({ newsId, queued, setQueued, onError, onChanged }) {
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(!!newsId);
  const [uploading, setUploading] = useState(false);
  const [removingId, setRemovingId] = useState(null);

  const load = useCallback(() => {
    if (!newsId) return;
    setLoading(true);
    apiRequest(`/admin/news/${newsId}/gallery`)
      .then((d) => setImages(d.gallery || []))
      .catch((err) => onError(err.message))
      .finally(() => setLoading(false));
  }, [newsId, onError]);

  useEffect(load, [load]);

  const queuedPreviews = useMemo(() => queued.map((f) => ({ file: f, url: URL.createObjectURL(f) })), [queued]);
  useEffect(() => () => queuedPreviews.forEach((p) => URL.revokeObjectURL(p.url)), [queuedPreviews]);

  async function handlePick(e) {
    const files = Array.from(e.target.files || []);
    e.target.value = "";
    if (files.length === 0) return;
    for (const f of files) {
      const err = validatePhotoFile(f);
      if (err) { onError(err); return; }
    }
    if (!newsId) {
      setQueued([...queued, ...files].slice(0, 8));
      return;
    }
    setUploading(true);
    try {
      const fd = new FormData();
      files.slice(0, 8).forEach((f) => fd.append("images", f));
      await apiUpload(`/admin/news/${newsId}/gallery`, fd);
      load();
      onChanged?.(tr("عکس‌های گالری اضافه شد"));
    } catch (err) {
      onError(err.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(imageId) {
    if (!window.confirm(tr("آیا از حذف این عکس گالری مطمئن هستید؟"))) return;
    setRemovingId(imageId);
    try {
      await apiRequest(`/admin/news/${newsId}/gallery/${imageId}`, { method: "DELETE" });
      load();
      onChanged?.(tr("عکس از گالری حذف شد"));
    } catch (err) {
      onError(err.message);
    } finally {
      setRemovingId(null);
    }
  }

  return (
    <div className="nm-gallery">
      {loading && <div className="nm-gallery-grid">{[0, 1, 2].map((i) => <div key={i} className="pm-skel nm-gallery-skel" />)}</div>}
      {!loading && (
        <div className="nm-gallery-grid">
          {images.map((img) => (
            <div className="nm-gallery-item" key={img.id}>
              <img src={resolvePhotoUrl(img.imageUrl)} alt={tr("گالری خبر")} loading="lazy" />
              <button type="button" className="nm-gallery-remove" disabled={removingId === img.id} onClick={() => handleDelete(img.id)} aria-label={tr("حذف عکس")}>
                <X size={14} />
              </button>
            </div>
          ))}
          {queuedPreviews.map((p, i) => (
            <div className="nm-gallery-item is-queued" key={p.url}>
              <img src={p.url} alt={tr("پیش‌نمایش")} />
              <button type="button" className="nm-gallery-remove" onClick={() => setQueued(queued.filter((_, idx) => idx !== i))} aria-label={tr("حذف از صف")}>
                <X size={14} />
              </button>
            </div>
          ))}
          {images.length === 0 && queued.length === 0 && <p className="pm-muted nm-gallery-empty">{tr("هنوز عکسی به گالری اضافه نشده است.")}</p>}
        </div>
      )}
      <label className="btn btn-ghost btn-sm nm-upload-btn">
        <Upload size={14} /> {uploading ? tr("در حال آپلود...") : tr("افزودن عکس به گالری (حداکثر ۸ عکس)")}
        <input type="file" accept="image/jpeg,image/png,image/webp" multiple hidden disabled={uploading} onChange={handlePick} />
      </label>
      {!newsId && queued.length > 0 && <p className="pm-muted">{tr("این عکس‌ها بعد از ثبت خبر آپلود می‌شوند.")}</p>}
    </div>
  );
}

// ---------- پنل جزئیات خبر (مودال وسط صفحه) ----------
function NewsDetailDrawer({ item, onClose, onEdit, onDelete }) {
  const [gallery, setGallery] = useState(null);

  useEffect(() => {
    if (!item) return undefined;
    let cancelled = false;
    setGallery(null);
    apiRequest(`/admin/news/${item.id}/gallery`)
      .then((d) => { if (!cancelled) setGallery(d.gallery || []); })
      .catch(() => { if (!cancelled) setGallery([]); });
    return () => { cancelled = true; };
  }, [item?.id]);

  return (
    <GlobalModal
      isOpen={!!item}
      onClose={onClose}
      title={tr("جزئیات خبر")}
      size="md"
      className="nm-drawer"
      footer={item && (
        <>
          <button type="button" className="btn btn-primary" onClick={() => onEdit(item)}><Pencil size={14} />{" "}{tr("ویرایش")}</button>
          <button type="button" className="btn btn-ghost danger" onClick={() => onDelete(item)}><Trash2 size={14} />{" "}{tr("حذف")}</button>
        </>
      )}
    >
      {item && (
        <div className="nm-view">
          {item.imageUrl ? <img className="nm-view-cover" src={resolvePhotoUrl(item.imageUrl)} alt={item.title} /> : <div className="nm-view-cover nm-thumb-empty"><ImageIcon size={32} /></div>}
          <div className="nm-view-badges">
            <StatusBadge status={item.status} />
            {item.isPinned && <span className="nm-pin-badge"><Pin size={12} />{" "}{tr("سنجاق‌شده")}</span>}
          </div>
          <h3 className="nm-view-title">{item.title}</h3>
          <p className="nm-view-excerpt">{item.excerpt}</p>
          {item.content && <div className="nm-view-content" dangerouslySetInnerHTML={{ __html: sanitizeHtml(item.content) }} />}

          <h4 className="dm-form-title">{tr("اطلاعات خبر")}</h4>
          <dl className="dm-info">
            <div><dt>{tr("دسته‌بندی")}</dt><dd>{item.tag || "—"}</dd></div>
            <div><dt>{tr("نویسنده")}</dt><dd>{item.author || "—"}</dd></div>
            <div><dt>{tr("تاریخ انتشار")}</dt><dd>{fmtDateTime(item.publishedAt)}</dd></div>
            <div><dt>{tr("آخرین ویرایش")}</dt><dd>{fmtDateTime(item.updatedAt)}</dd></div>
            {item.status === "scheduled" && <div><dt>{tr("زمان انتشار برنامه‌ریزی‌شده")}</dt><dd>{fmtDateTime(item.scheduledAt)}</dd></div>}
            <div><dt>{tr("سنجاق")}</dt><dd>{item.isPinned ? tr("بله") : tr("خیر")}</dd></div>
            <div className="dm-info-wide"><dt>{tr("برچسب‌ها")}</dt><dd>{item.tags?.length ? <span className="nm-chips">{item.tags.map((t) => <span className="nm-chip" key={t}>{t}</span>)}</span> : "—"}</dd></div>
          </dl>

          <h4 className="dm-form-title">{tr("آمار")}</h4>
          <div className="nm-view-stats">
            <div><BarChart3 size={16} /><strong className="pm-num">{fa(item.views)}</strong><span>{tr("بازدید")}</span></div>
            <div><Clock size={16} /><strong className="pm-num">{fmtDate(item.publishedAt)}</strong><span>{tr("تاریخ انتشار")}</span></div>
          </div>

          <h4 className="dm-form-title">{tr("گالری تصاویر")}</h4>
          {gallery === null && <div className="nm-gallery-grid">{[0, 1, 2].map((i) => <div key={i} className="pm-skel nm-gallery-skel" />)}</div>}
          {gallery && gallery.length === 0 && <p className="pm-muted">{tr("گالری این خبر خالی است.")}</p>}
          {gallery && gallery.length > 0 && (
            <div className="nm-gallery-grid">
              {gallery.map((g) => <div className="nm-gallery-item" key={g.id}><img src={resolvePhotoUrl(g.imageUrl)} alt={tr("گالری خبر")} loading="lazy" /></div>)}
            </div>
          )}

          {(item.metaTitle || item.metaDescription) && (
            <>
              <h4 className="dm-form-title">{tr("اطلاعات سئو")}</h4>
              <dl className="dm-info dm-info-1">
                <div><dt>{tr("عنوان سئو")}</dt><dd className="dm-plain">{item.metaTitle || "—"}</dd></div>
                <div><dt>{tr("توضیحات سئو")}</dt><dd className="dm-plain">{item.metaDescription || "—"}</dd></div>
              </dl>
            </>
          )}
        </div>
      )}
    </GlobalModal>
  );
}

// ============================================================================
export default function NewsManagement() {
  const { toasts, showToast, dismissToast } = useDepartmentToasts();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");
  const [stats, setStats] = useState(null);

  // جستجو / فیلتر / مرتب‌سازی / صفحه‌بندی
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sort, setSort] = useState("default");
  const [page, setPage] = useState(1);

  // پنل‌ها
  const [viewingId, setViewingId] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [tab, setTab] = useState("content");
  const [form, setForm] = useState(emptyForm);
  const [formErrors, setFormErrors] = useState({});
  const [formBanner, setFormBanner] = useState("");
  const [imageFile, setImageFile] = useState(null);
  const [queuedGallery, setQueuedGallery] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [deletingBusy, setDeletingBusy] = useState(false);
  const [busyId, setBusyId] = useState(null);
  const [menuId, setMenuId] = useState(null);
  const rowImageInput = useRef(null);
  const rowImageTarget = useRef(null);

  const loadItems = useCallback(() => {
    return apiRequest("/admin/news")
      .then((d) => { setItems(d.news || []); setLoadError(""); })
      .catch((err) => setLoadError(err.message))
      .finally(() => setLoading(false));
  }, []);
  const loadStats = useCallback(() => {
    return apiRequest("/admin/news/stats").then((d) => setStats(d.stats)).catch(() => setStats(null));
  }, []);
  const refresh = useCallback(() => Promise.all([loadItems(), loadStats()]), [loadItems, loadStats]);

  useEffect(() => { refresh(); }, [refresh]);
  useEffect(() => { setPage(1); }, [query, statusFilter, categoryFilter, sort]);

  // بستن منوی عملیات با کلیک بیرون / Escape
  useEffect(() => {
    if (menuId === null) return undefined;
    const close = (e) => { if (e.type !== "keydown" && isScrollbarClick(e)) return; if (e.type === "keydown" ? e.key === "Escape" : !e.target.closest?.(".nm-menu-wrap")) setMenuId(null); };
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", close);
    return () => { document.removeEventListener("mousedown", close); document.removeEventListener("keydown", close); };
  }, [menuId]);

  // منوی عملیات (⋮) همیشه باید کامل داخل صفحه دیده شود: اگر از لبه‌ی چپ/راست پنجره بیرون
  // بزند به داخل جابه‌جا می‌شود، و اگر از پایین پنجره بیرون بزند رو به بالا باز می‌شود
  useLayoutEffect(() => {
    if (menuId === null) return;
    const el = document.querySelector(".nm-menu");
    if (!el) return;
    const GAP = 8;
    el.style.transform = "";
    let r = el.getBoundingClientRect();
    let dx = 0;
    if (r.left < GAP) dx = GAP - r.left;
    else if (r.right > window.innerWidth - GAP) dx = window.innerWidth - GAP - r.right;
    if (dx) el.style.transform = `translateX(${Math.round(dx)}px)`;
    if (!el.classList.contains("is-up") && r.bottom > window.innerHeight - GAP) {
      el.style.top = "auto";
      el.style.bottom = "calc(100% + 6px)";
      r = el.getBoundingClientRect();
      if (r.top < GAP) { el.style.bottom = ""; el.style.top = "calc(100% + 6px)"; }
    }
  }, [menuId]);

  const categories = useMemo(() => [...new Set(items.map((n) => n.tag).filter(Boolean))].sort((a, b) => a.localeCompare(b, "fa")), [items]);
  const allTags = useMemo(() => [...new Set(items.flatMap((n) => n.tags || []))], [items]);
  const authors = useMemo(() => [...new Set(items.map((n) => n.author).filter(Boolean))], [items]);

  const filtersActive = query.trim() !== "" || statusFilter !== "all" || categoryFilter !== "all";

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = items.filter((n) => {
      if (statusFilter !== "all" && n.status !== statusFilter) return false;
      if (categoryFilter !== "all" && n.tag !== categoryFilter) return false;
      if (!q) return true;
      return [n.title, n.author, n.tag, ...(n.tags || [])].some((f) => String(f || "").toLowerCase().includes(q));
    });
    const time = (v) => (v ? new Date(v).getTime() : 0);
    if (sort === "newest") list = [...list].sort((a, b) => time(b.updatedAt) - time(a.updatedAt));
    else if (sort === "oldest") list = [...list].sort((a, b) => time(a.updatedAt) - time(b.updatedAt));
    else if (sort === "views") list = [...list].sort((a, b) => (b.views || 0) - (a.views || 0));
    else if (sort === "published") list = [...list].sort((a, b) => time(b.publishedAt) - time(a.publishedAt));
    return list;
  }, [items, query, statusFilter, categoryFilter, sort]);

  // خبر ویژه: فقط وقتی هیچ جستجو/فیلتری فعال نیست و خبر سنجاق‌شده‌ای وجود دارد
  const featured = !filtersActive ? items.find((n) => n.isPinned) || null : null;
  const listItems = featured ? filtered.filter((n) => n.id !== featured.id) : filtered;
  const totalPages = Math.max(1, Math.ceil(listItems.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageItems = listItems.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);
  const viewing = items.find((n) => n.id === viewingId) || null;

  // ---------- فرم ----------
  function setField(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
    if (formErrors[key]) setFormErrors((e) => ({ ...e, [key]: undefined }));
  }

  function openCreate() {
    setEditingId(null); setForm(emptyForm); setFormErrors({}); setFormBanner("");
    setImageFile(null); setQueuedGallery([]); setTab("content"); setFormOpen(true);
  }

  function openEdit(item, startTab = "content") {
    setViewingId(null); setMenuId(null);
    setEditingId(item.id);
    setForm({
      title: item.title || "", excerpt: item.excerpt || "", content: item.content || "",
      titleEn: item.titleEn || "", excerptEn: item.excerptEn || "", contentEn: item.contentEn || "",
      tag: item.tag || "", tags: Array.isArray(item.tags) ? item.tags : [], author: item.author || "",
      status: item.status || "draft", scheduledAt: item.status === "scheduled" ? toLocalInput(item.scheduledAt) : "",
      isPinned: !!item.isPinned, metaTitle: item.metaTitle || "", metaDescription: item.metaDescription || "",
    });
    setFormErrors({}); setFormBanner(""); setImageFile(null); setQueuedGallery([]);
    setTab(startTab); setFormOpen(true);
  }

  function closeForm() {
    if (submitting) return;
    setFormOpen(false);
  }

  function pickCover(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    const err = validatePhotoFile(file);
    if (err) { setFormBanner(err); return; }
    setFormBanner(""); setImageFile(file);
  }
  const coverPreview = useMemo(() => (imageFile ? URL.createObjectURL(imageFile) : null), [imageFile]);
  useEffect(() => () => { if (coverPreview) URL.revokeObjectURL(coverPreview); }, [coverPreview]);
  const editingItem = items.find((n) => n.id === editingId) || null;

  function validate() {
    const errors = {};
    if (!form.title.trim()) errors.title = tr("عنوان خبر الزامی است");
    else if (form.title.trim().length > 255) errors.title = tr("عنوان خبر نباید بیشتر از ۲۵۵ کاراکتر باشد");
    if (!form.excerpt.trim()) errors.excerpt = tr("توضیح کوتاه الزامی است");
    else if (form.excerpt.trim().length > 500) errors.excerpt = tr("توضیح کوتاه نباید بیشتر از ۵۰۰ کاراکتر باشد");
    if (!form.tag.trim()) errors.tag = tr("دسته‌بندی خبر الزامی است");
    else if (form.tag.trim().length > 100) errors.tag = tr("دسته‌بندی نباید بیشتر از ۱۰۰ کاراکتر باشد");
    if (form.status === "scheduled") {
      if (!form.scheduledAt) errors.scheduledAt = tr("برای زمان‌بندی انتشار، تاریخ و ساعت را انتخاب کنید");
      else if (new Date(form.scheduledAt).getTime() <= Date.now()) errors.scheduledAt = tr("تاریخ زمان‌بندی باید در آینده باشد");
    }
    return errors;
  }

  const FIELD_TAB = { title: "content", excerpt: "content", tag: "taxonomy", scheduledAt: "publish" };

  async function submit(e) {
    e?.preventDefault();
    const errors = validate();
    setFormErrors(errors);
    const firstKey = Object.keys(errors)[0];
    if (firstKey) { setTab(FIELD_TAB[firstKey]); setFormBanner(tr("لطفاً خطاهای فرم را برطرف کنید")); return; }

    setSubmitting(true); setFormBanner("");
    try {
      const payload = {
        title: form.title.trim(), excerpt: form.excerpt.trim(), content: form.content.trim(),
        titleEn: form.titleEn.trim(), excerptEn: form.excerptEn.trim(), contentEn: form.contentEn.trim(),
        tag: form.tag.trim(), tags: form.tags.join(", "), author: form.author.trim(),
        status: form.status, scheduledAt: form.status === "scheduled" ? form.scheduledAt : null,
        isPinned: !!form.isPinned, metaTitle: form.metaTitle.trim(), metaDescription: form.metaDescription.trim(),
      };
      const res = editingId
        ? await apiRequest(`/admin/news/${editingId}`, { method: "PUT", body: payload })
        : await apiRequest("/admin/news", { method: "POST", body: payload });
      const news = res.news;

      // آپلودها بعد از ذخیره‌ی خبر؛ اگر آپلود شکست بخورد خود خبر ثبت شده و فقط پیام خطا نشان داده می‌شود
      let uploadError = "";
      if (news?.id && imageFile) {
        try { const fd = new FormData(); fd.append("image", imageFile); await apiUpload(`/admin/news/${news.id}/image`, fd); }
        catch (err) { uploadError = tr("خبر ذخیره شد اما آپلود عکس شاخص ناموفق بود: {0}", [err.message]); }
      }
      if (news?.id && !editingId && queuedGallery.length > 0) {
        try { const fd = new FormData(); queuedGallery.forEach((f) => fd.append("images", f)); await apiUpload(`/admin/news/${news.id}/gallery`, fd); }
        catch (err) { uploadError = tr("خبر ذخیره شد اما آپلود گالری ناموفق بود: {0}", [err.message]); }
      }

      setFormOpen(false);
      showToast(editingId ? tr("خبر به‌روزرسانی شد") : tr("خبر جدید ثبت شد"), "success");
      if (uploadError) showToast(uploadError, "error");
      refresh();
    } catch (err) {
      setFormBanner(err.message);
    } finally {
      setSubmitting(false);
    }
  }

  // ---------- عملیات سریع (همان endpointهای قبلی) ----------
  async function togglePin(item) {
    setMenuId(null); setBusyId(item.id);
    try {
      await apiRequest(`/admin/news/${item.id}/pin`, { method: "PUT", body: { isPinned: !item.isPinned } });
      showToast(item.isPinned ? tr("سنجاق خبر برداشته شد") : tr("خبر سنجاق شد"), "success");
      await refresh();
    } catch (err) { showToast(err.message, "error"); } finally { setBusyId(null); }
  }

  async function togglePublish(item) {
    setMenuId(null); setBusyId(item.id);
    const next = item.status === "published" ? "draft" : "published";
    try {
      await apiRequest(`/admin/news/${item.id}/status`, { method: "PUT", body: { status: next } });
      showToast(next === "published" ? tr("خبر منتشر شد") : tr("انتشار خبر لغو شد"), "success");
      await refresh();
    } catch (err) { showToast(err.message, "error"); } finally { setBusyId(null); }
  }

  function startRowImage(item) { setMenuId(null); rowImageTarget.current = item.id; rowImageInput.current?.click(); }
  async function handleRowImage(e) {
    const file = e.target.files?.[0];
    e.target.value = "";
    const id = rowImageTarget.current;
    if (!file || !id) return;
    const err = validatePhotoFile(file);
    if (err) { showToast(err, "error"); return; }
    setBusyId(id);
    try {
      const fd = new FormData(); fd.append("image", file);
      await apiUpload(`/admin/news/${id}/image`, fd);
      showToast(tr("تصویر شاخص به‌روزرسانی شد"), "success");
      await loadItems();
    } catch (error) { showToast(error.message, "error"); } finally { setBusyId(null); }
  }

  async function confirmDelete() {
    if (!deleting) return;
    setDeletingBusy(true);
    try {
      await apiRequest(`/admin/news/${deleting.id}`, { method: "DELETE" });
      if (viewingId === deleting.id) setViewingId(null);
      if (editingId === deleting.id) setFormOpen(false);
      setDeleting(null);
      showToast(tr("خبر حذف شد"), "success");
      refresh();
    } catch (err) { showToast(err.message, "error"); } finally { setDeletingBusy(false); }
  }

  function clearFilters() { setQuery(""); setStatusFilter("all"); setCategoryFilter("all"); }

  // ---------- بخش‌های نمایش ----------
  const statCards = [
    { key: "total", label: tr("مجموع اخبار"), value: stats?.total, icon: Newspaper, tone: "total", filter: "all" },
    { key: "published", label: tr("منتشرشده"), value: stats?.published, icon: CheckCircle2, tone: "published", filter: "published" },
    { key: "scheduled", label: tr("زمان‌بندی‌شده"), value: stats?.scheduled, icon: Clock, tone: "scheduled", filter: "scheduled" },
    { key: "draft", label: tr("پیش‌نویس"), value: stats?.draft, icon: FileText, tone: "draft", filter: "draft" },
    { key: "pinned", label: tr("سنجاق‌شده"), value: stats?.pinned, icon: Pin, tone: "pinned", filter: null },
    { key: "views", label: tr("بازدید کل"), value: stats?.totalViews, icon: BarChart3, tone: "views", filter: null },
  ];

  function RowMenu({ n, up }) {
    const open = menuId === n.id;
    return (
      <div className="nm-menu-wrap">
        <button type="button" className="pm-iconbtn" aria-haspopup="menu" aria-expanded={open} aria-label={tr("عملیات بیشتر")} disabled={busyId === n.id} onClick={() => setMenuId(open ? null : n.id)}>
          <MoreVertical size={16} />
        </button>
        {open && (
          <div className={`pm-menu nm-menu${up ? " is-up" : ""}`} role="menu">
            <button type="button" role="menuitem" onClick={() => togglePublish(n)}>
              {n.status === "published" ? <><EyeOff size={15} />{" "}{tr("لغو انتشار")}</> : <><CheckCircle2 size={15} /> {n.status === "scheduled" ? tr("انتشار فوری") : tr("انتشار")}</>}
            </button>
            <button type="button" role="menuitem" onClick={() => startRowImage(n)}><ImageIcon size={15} />{" "}{tr("تغییر تصویر شاخص")}</button>
            <button type="button" role="menuitem" onClick={() => openEdit(n, "media")}><Upload size={15} />{" "}{tr("مدیریت گالری")}</button>
            <hr />
            <button type="button" role="menuitem" className="is-danger" onClick={() => { setMenuId(null); setDeleting(n); }}><Trash2 size={15} />{" "}{tr("حذف خبر")}</button>
          </div>
        )}
      </div>
    );
  }

  function RowActions({ n, up }) {
    return (
      <div className="pm-actions nm-actions">
        <button type="button" className="pm-iconbtn" title={tr("مشاهده")} aria-label={tr("مشاهده")} onClick={() => setViewingId(n.id)}><Eye size={16} /></button>
        <button type="button" className="pm-iconbtn" title={tr("ویرایش")} aria-label={tr("ویرایش")} onClick={() => openEdit(n)}><Pencil size={16} /></button>
        <button type="button" className={`pm-iconbtn nm-pinbtn${n.isPinned ? " is-on" : ""}`} title={n.isPinned ? tr("برداشتن سنجاق") : tr("سنجاق کردن")} aria-label={n.isPinned ? tr("برداشتن سنجاق") : tr("سنجاق کردن")} aria-pressed={n.isPinned} disabled={busyId === n.id} onClick={() => togglePin(n)}>
          {n.isPinned ? <PinOff size={16} /> : <Pin size={16} />}
        </button>
        {RowMenu({ n, up })}
      </div>
    );
  }

  const noNewsAtAll = !loading && !loadError && items.length === 0;

  return (
    <div className="pm-page nm-page">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />
      <input ref={rowImageInput} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={handleRowImage} />

      {/* ---- سربرگ ---- */}
      <div className="pm-head">
        <div>
          <h2>{tr("مدیریت اخبار و اعلانات")}</h2>
          <p>{tr("ایجاد، انتشار و مدیریت محتوای اطلاع‌رسانی شفاخانه")}</p>
        </div>
        <div className="pm-head-actions">
          <button type="button" className="btn btn-primary" onClick={openCreate}><Plus size={16} />{" "}{tr("ایجاد خبر جدید")}</button>
        </div>
      </div>

      {loadError && <div className="form-message error" role="alert">{loadError} <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setLoading(true); refresh(); }}>{tr("تلاش دوباره")}</button></div>}

      {/* ---- کارت‌های آماری (از /admin/news/stats) ---- */}
      <div className="pm-stats nm-stats">
        {statCards.map((c) => {
          const Icon = c.icon;
          const clickable = c.filter !== null;
          const Tag = clickable ? "button" : "div";
          return (
            <Tag key={c.key} type={clickable ? "button" : undefined} className={`pm-stat nm-stat nm-tone-${c.tone}${stats ? "" : " is-loading"}`}
              aria-pressed={clickable ? statusFilter === c.filter && !query && categoryFilter === "all" : undefined}
              style={clickable ? undefined : { cursor: "default" }}
              onClick={clickable ? () => setStatusFilter(c.filter) : undefined}>
              <span className="pm-stat-icon"><Icon size={20} /></span>
              <span>
                {stats ? <span className="pm-stat-num">{fa(c.value)}</span> : <span className="pm-skel nm-skel-num" />}
                <span className="pm-stat-label">{c.label}</span>
              </span>
            </Tag>
          );
        })}
      </div>
      {stats?.mostViewed?.length > 0 && stats.mostViewed[0].views > 0 && (
        <p className="pm-muted nm-topline"><Star size={13} />{" "}{tr("پربازدیدترین خبر:")}{" "}<strong>{stats.mostViewed[0].title}</strong> — <span className="pm-num">{fa(stats.mostViewed[0].views)}</span>{" "}{tr("بازدید")}</p>
      )}

      {/* ---- جستجو و فیلتر ---- */}
      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="pm-search">
            <Search size={16} />
            <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder={tr("جستجو در عنوان، نویسنده، دسته‌بندی یا برچسب...")} aria-label={tr("جستجو در اخبار")} />
          </div>
          <select className="pm-select nm-select" value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} aria-label={tr("فیلتر دسته‌بندی")}>
            <option value="all">{tr("همه‌ی دسته‌بندی‌ها")}</option>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <select className="pm-select nm-select" value={sort} onChange={(e) => setSort(e.target.value)} aria-label={tr("مرتب‌سازی")}>
            {SORT_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          {filtersActive && <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={clearFilters}><X size={14} />{" "}{tr("پاک‌کردن فیلترها")}</button>}
        </div>
        <div className="nm-status-tabs" role="group" aria-label={tr("فیلتر وضعیت")}>
          {STATUS_FILTERS.map((s) => (
            <button key={s} type="button" className={`nm-status-tab${statusFilter === s ? " is-active" : ""}`} aria-pressed={statusFilter === s} onClick={() => setStatusFilter(s)}>
              {s === "all" ? tr("همه") : STATUS_LABEL[s]}
            </button>
          ))}
        </div>
      </div>

      {/* ---- خبر ویژه ---- */}
      {loading && !items.length && <div className="nm-featured nm-featured-skel"><div className="pm-skel nm-skel-cover" /><div className="nm-skel-stack"><div className="pm-skel" /><div className="pm-skel" style={{ width: "70%" }} /><div className="pm-skel" style={{ width: "40%" }} /></div></div>}
      {featured && (
        <section className="nm-featured" aria-label={tr("خبر ویژه")}>
          <div className="nm-featured-media">
            {featured.imageUrl ? <img src={resolvePhotoUrl(featured.imageUrl)} alt={featured.title} /> : <div className="nm-thumb-empty"><ImageIcon size={36} /></div>}
          </div>
          <div className="nm-featured-body">
            <div className="nm-featured-meta">
              <span className="nm-pin-badge"><Pin size={12} />{" "}{tr("خبر ویژه")}</span>
              <StatusBadge status={featured.status} />
            </div>
            <h3>{featured.title}</h3>
            <p>{featured.excerpt}</p>
            <div className="nm-featured-info pm-muted">
              <span>{featured.tag}</span><span>•</span>
              <span>{fmtDate(featured.publishedAt)}</span><span>•</span>
              <span className="pm-num">{tr("{0} بازدید", [fa(featured.views)])}</span>
            </div>
            <div className="nm-featured-actions">
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setViewingId(featured.id)}><Eye size={14} />{" "}{tr("مشاهده")}</button>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => openEdit(featured)}><Pencil size={14} />{" "}{tr("ویرایش")}</button>
              <button type="button" className="btn btn-ghost btn-sm" disabled={busyId === featured.id} onClick={() => togglePin(featured)}><PinOff size={14} />{" "}{tr("برداشتن سنجاق")}</button>
            </div>
          </div>
        </section>
      )}

      {/* ---- لیست اخبار ---- */}
      <div className="pm-tablewrap nm-list" aria-busy={loading}>
        <div className="nm-row nm-row-head" aria-hidden="true">
          <span>{tr("تصویر")}</span><span>{tr("عنوان")}</span><span>{tr("دسته‌بندی")}</span><span>{tr("نویسنده")}</span><span>{tr("وضعیت")}</span><span>{tr("تاریخ انتشار")}</span><span>{tr("بازدید")}</span><span>{tr("عملیات")}</span>
        </div>

        {loading && Array.from({ length: 5 }).map((_, i) => (
          <div className="nm-row" key={`s${i}`}>
            <span className="pm-skel nm-skel-thumb" /><span className="pm-skel" /><span className="pm-skel" /><span className="pm-skel" /><span className="pm-skel" /><span className="pm-skel" /><span className="pm-skel" /><span className="pm-skel" />
          </div>
        ))}

        {noNewsAtAll && (
          <div className="pm-state">
            <strong>{tr("هنوز خبری ثبت نشده است")}</strong>{tr("برای اطلاع‌رسانی به بیماران و کاربران، اولین خبر خود را ایجاد کنید.")}<div><button type="button" className="btn btn-primary" onClick={openCreate}><Plus size={16} />{" "}{tr("ایجاد اولین خبر")}</button></div>
          </div>
        )}

        {!loading && items.length > 0 && listItems.length === 0 && (
          <div className="pm-state">
            <strong>{tr("خبری مطابق جستجوی شما یافت نشد")}</strong>{tr("عبارت جستجو یا فیلترها را تغییر دهید.")}<div><button type="button" className="btn btn-ghost" onClick={clearFilters}>{tr("پاک‌کردن فیلترها")}</button></div>
          </div>
        )}

        {!loading && pageItems.map((n, idx) => (
          <div className={`nm-row${busyId === n.id ? " is-busy" : ""}`} key={n.id}>
            <span className="nm-cell nm-cell-thumb"><Thumb item={n} /></span>
            <span className="nm-cell nm-cell-title">
              <button type="button" className="nm-title-btn" onClick={() => setViewingId(n.id)}>
                {n.isPinned && <Pin size={13} className="nm-pin-inline" aria-label={tr("سنجاق‌شده")} />}{n.title}
              </button>
              {n.tags?.length > 0 && <span className="pm-sub">{n.tags.slice(0, 3).join(tr("، "))}{n.tags.length > 3 ? "…" : ""}</span>}
            </span>
            <span className="nm-cell" data-label={tr("دسته‌بندی")}>{n.tag || "—"}</span>
            <span className="nm-cell" data-label={tr("نویسنده")}>{n.author || "—"}</span>
            <span className="nm-cell" data-label={tr("وضعیت")}>
              <StatusBadge status={n.status} />
              {n.status === "scheduled" && n.scheduledAt && <span className="pm-sub">{fmtDateTime(n.scheduledAt)}</span>}
            </span>
            <span className="nm-cell pm-num" data-label={tr("تاریخ انتشار")}>{fmtDate(n.publishedAt)}</span>
            <span className="nm-cell pm-num" data-label={tr("بازدید")}>{fa(n.views)}</span>
            <span className="nm-cell nm-cell-actions">{RowActions({ n, up: idx >= pageItems.length - 2 && pageItems.length > 3 })}</span>
          </div>
        ))}

        {!loading && listItems.length > PAGE_SIZE && (
          <div className="pm-pager">
            <span>{tr("نمایش {0} تا {1} از {2} خبر", [fa((currentPage - 1) * PAGE_SIZE + 1), fa(Math.min(currentPage * PAGE_SIZE, listItems.length)), fa(listItems.length)])}</span>
            <div className="pm-pages">
              <button type="button" className="pm-page-btn" disabled={currentPage <= 1} onClick={() => setPage(currentPage - 1)} aria-label={tr("صفحه قبل")}><ChevronRight size={16} /></button>
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter((p) => p === 1 || p === totalPages || Math.abs(p - currentPage) <= 1)
                .map((p, i, arr) => (
                  <span key={p} style={{ display: "contents" }}>
                    {i > 0 && p - arr[i - 1] > 1 && <span>…</span>}
                    <button type="button" className="pm-page-btn" aria-current={p === currentPage ? "page" : undefined} onClick={() => setPage(p)}>{fa(p)}</button>
                  </span>
                ))}
              <button type="button" className="pm-page-btn" disabled={currentPage >= totalPages} onClick={() => setPage(currentPage + 1)} aria-label={tr("صفحه بعد")}><ChevronLeft size={16} /></button>
            </div>
          </div>
        )}
      </div>

      {/* ---- پنل جزئیات ---- */}
      <NewsDetailDrawer item={viewing} onClose={() => setViewingId(null)} onEdit={openEdit} onDelete={(n) => setDeleting(n)} />

      {/* ---- ویرایشگر خبر (مودال وسط صفحه) ---- */}
      <GlobalModal
        isOpen={formOpen}
        onClose={closeForm}
        title={editingId ? tr("ویرایش خبر") : tr("ایجاد خبر جدید")}
        size="lg"
        className="nm-form-modal"
        closeOnOverlayClick={false}
        footer={
          <>
            <button className="btn btn-primary" type="submit" form="nm-news-form" disabled={submitting}>
              {submitting ? tr("در حال ذخیره...") : editingId ? tr("ذخیره تغییرات") : form.status === "published" ? tr("ذخیره و انتشار") : form.status === "scheduled" ? tr("ثبت زمان‌بندی انتشار") : tr("ذخیره پیش‌نویس")}
            </button>
            <button className="btn btn-ghost" type="button" disabled={submitting} onClick={closeForm}>{tr("انصراف")}</button>
          </>
        }
      >
        <form id="nm-news-form" className="login-form nm-form" onSubmit={submit} noValidate>
          {formBanner && <div className="form-message error" role="alert">{formBanner}</div>}

          <div className="dm-tabs" role="tablist" aria-label={tr("بخش‌های فرم خبر")}>
            {EDITOR_TABS.map((t) => (
              <button key={t.key} type="button" role="tab" aria-selected={tab === t.key} id={`nm-tab-${t.key}`} aria-controls={`nm-panel-${t.key}`} className={`dm-tab${tab === t.key ? " is-active" : ""}`} onClick={() => setTab(t.key)}>
                {t.label}{Object.keys(formErrors).some((k) => formErrors[k] && FIELD_TAB[k] === t.key) && <span className="nm-tab-dot" aria-label={tr("دارای خطا")} />}
              </button>
            ))}
          </div>

          <div role="tabpanel" id={`nm-panel-${tab}`} aria-labelledby={`nm-tab-${tab}`} className="dm-tabpanel">
            {tab === "content" && (
              <>
                <div className="field">
                  <label htmlFor="nm-title">{tr("عنوان خبر")}</label>
                  <input id="nm-title" value={form.title} maxLength={255} onChange={(e) => setField("title", e.target.value)} />
                  {formErrors.title && <p className="field-error">{formErrors.title}</p>}
                </div>
                <div className="field">
                  <label htmlFor="nm-excerpt">{tr("خلاصه خبر")}</label>
                  <textarea id="nm-excerpt" rows={3} maxLength={500} value={form.excerpt} onChange={(e) => setField("excerpt", e.target.value)} />
                  <span className="dm-counter pm-num">{fa(form.excerpt.length)} / {fa(500)}</span>
                  {formErrors.excerpt && <p className="field-error">{formErrors.excerpt}</p>}
                </div>
                <div className="field">
                  <label>{tr("محتوای کامل")}</label>
                  <RichTextEditor value={form.content} onChange={(html) => setField("content", html)} />
                </div>

                <h4 className="dm-form-title">{tr("نسخه‌ی انگلیسی (اختیاری)")}</h4>
                <p style={{ fontSize: 12.5, color: "var(--text-3)", margin: "0 0 10px" }}>{tr("اگر پر شود، وقتی بازدیدکننده زبان سایت را انگلیسی کند همین متن نمایش داده می‌شود؛ در غیر این صورت متن دری نشان داده می‌شود.")}</p>
                <div className="field">
                  <label htmlFor="nm-title-en">Title</label>
                  <input id="nm-title-en" dir="ltr" value={form.titleEn} maxLength={255} onChange={(e) => setField("titleEn", e.target.value)} />
                </div>
                <div className="field">
                  <label htmlFor="nm-excerpt-en">Excerpt</label>
                  <textarea id="nm-excerpt-en" dir="ltr" rows={3} maxLength={500} value={form.excerptEn} onChange={(e) => setField("excerptEn", e.target.value)} />
                  <span className="dm-counter pm-num">{fa(form.excerptEn.length)} / {fa(500)}</span>
                </div>
                <div className="field">
                  <label>Full content</label>
                  <RichTextEditor dir="ltr" label="Full article content (English)" value={form.contentEn} onChange={(html) => setField("contentEn", html)} />
                </div>
              </>
            )}

            {tab === "media" && (
              <>
                <h4 className="dm-form-title">{tr("تصویر شاخص")}</h4>
                <div className="nm-cover">
                  <div className="nm-cover-preview">
                    {coverPreview || editingItem?.imageUrl
                      ? <img src={coverPreview || resolvePhotoUrl(editingItem.imageUrl)} alt={tr("پیش‌نمایش تصویر شاخص")} />
                      : <span className="nm-thumb-empty"><ImageIcon size={28} /></span>}
                  </div>
                  <div className="nm-cover-actions">
                    <label className="btn btn-ghost btn-sm nm-upload-btn">
                      <Upload size={14} /> {coverPreview || editingItem?.imageUrl ? tr("تغییر تصویر") : tr("انتخاب تصویر")}
                      <input type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={pickCover} />
                    </label>
                    {imageFile && <button type="button" className="btn btn-ghost btn-sm" onClick={() => setImageFile(null)}>{tr("لغو انتخاب")}</button>}
                    <p className="pm-muted">{tr("JPG، PNG یا WEBP — حداکثر ۲ مگابایت{0}", [imageFile ? tr(" • پس از ذخیره آپلود می‌شود") : ""])}</p>
                  </div>
                </div>
                <h4 className="dm-form-title">{tr("گالری تصاویر")}</h4>
                <GalleryManager newsId={editingId} queued={queuedGallery} setQueued={setQueuedGallery} onError={setFormBanner} onChanged={(m) => showToast(m, "success")} />
              </>
            )}

            {tab === "taxonomy" && (
              <>
                <div className="field">
                  <label htmlFor="nm-tag">{tr("دسته‌بندی")}</label>
                  <input id="nm-tag" list="nm-cat-list" value={form.tag} maxLength={100} placeholder={tr("مثال: قلب و عروق")} onChange={(e) => setField("tag", e.target.value)} />
                  <datalist id="nm-cat-list">{categories.map((c) => <option key={c} value={c} />)}</datalist>
                  {categories.length > 0 && (
                    <div className="nm-chips nm-suggest">
                      {categories.slice(0, 8).map((c) => <button type="button" key={c} className={`nm-chip is-btn${form.tag === c ? " is-on" : ""}`} onClick={() => setField("tag", c)}>{c}</button>)}
                    </div>
                  )}
                  {formErrors.tag && <p className="field-error">{formErrors.tag}</p>}
                </div>
                <div className="field">
                  <label htmlFor="nm-tags-input">{tr("برچسب‌ها")}</label>
                  <TagInput value={form.tags} onChange={(t) => setField("tags", t)} suggestions={allTags} />
                </div>
                <div className="field">
                  <label htmlFor="nm-author">{tr("نویسنده")}</label>
                  <input id="nm-author" list="nm-author-list" value={form.author} maxLength={150} placeholder={tr("نام نویسنده")} onChange={(e) => setField("author", e.target.value)} />
                  <datalist id="nm-author-list">{authors.map((a) => <option key={a} value={a} />)}</datalist>
                </div>
              </>
            )}

            {tab === "publish" && (
              <>
                <h4 className="dm-form-title">{tr("وضعیت انتشار")}</h4>
                <div className="dm-seg" role="radiogroup" aria-label={tr("وضعیت انتشار")}>
                  {["draft", "published", "scheduled"].map((s) => (
                    <button key={s} type="button" role="radio" aria-checked={form.status === s} className={form.status === s ? "is-active" : ""} onClick={() => setField("status", s)}>{STATUS_LABEL[s]}</button>
                  ))}
                </div>
                <p className="pm-muted">
                  {form.status === "draft" && tr("پیش‌نویس در صفحه عمومی اخبار نمایش داده نمی‌شود.")}
                  {form.status === "published" && tr("خبر بلافاصله در صفحه عمومی اخبار نمایش داده می‌شود.")}
                  {form.status === "scheduled" && tr("خبر در زمان انتخاب‌شده به‌صورت خودکار منتشر می‌شود.")}
                </p>
                {form.status === "scheduled" && (
                  <div className="field">
                    <label htmlFor="nm-sched">{tr("زمان انتشار")}</label>
                    <JalaliDateTimeInput id="nm-sched" value={form.scheduledAt} onChange={(e) => setField("scheduledAt", e.target.value)} />
                    {formErrors.scheduledAt && <p className="field-error">{formErrors.scheduledAt}</p>}
                  </div>
                )}
                {editingItem && editingItem.publishedAt && <p className="pm-muted">{tr("تاریخ انتشار فعلی: {0}", [fmtDateTime(editingItem.publishedAt)])}</p>}
                <label className="checkbox-row nm-pin-toggle">
                  <input type="checkbox" checked={form.isPinned} onChange={(e) => setField("isPinned", e.target.checked)} />
                  <Pin size={14} />{" "}{tr("سنجاق کردن این خبر")}</label>
              </>
            )}

            {tab === "seo" && (
              <>
                <div className="field">
                  <label htmlFor="nm-mt">{tr("عنوان سئو (اختیاری)")}</label>
                  <input id="nm-mt" value={form.metaTitle} maxLength={255} placeholder={tr("در صورت خالی بودن، همان عنوان خبر استفاده می‌شود")} onChange={(e) => setField("metaTitle", e.target.value)} />
                  <span className="dm-counter pm-num">{fa(form.metaTitle.length)} / {fa(255)}</span>
                </div>
                <div className="field">
                  <label htmlFor="nm-md">{tr("توضیحات سئو (اختیاری)")}</label>
                  <textarea id="nm-md" rows={3} value={form.metaDescription} maxLength={300} placeholder={tr("در صورت خالی بودن، همان خلاصه خبر استفاده می‌شود")} onChange={(e) => setField("metaDescription", e.target.value)} />
                  <span className="dm-counter pm-num">{fa(form.metaDescription.length)} / {fa(300)}</span>
                </div>
              </>
            )}
          </div>
        </form>
      </GlobalModal>

      {/* ---- تایید حذف ---- */}
      <GlobalModal
        isOpen={!!deleting}
        onClose={() => (deletingBusy ? null : setDeleting(null))}
        size="sm"
        className="logout-confirm-modal"
        overlayClassName="logout-confirm-overlay"
        labelledBy="nm-delete-title"
        closeOnOverlayClick={!deletingBusy}
        closeOnEsc={!deletingBusy}
        bare
      >
        {deleting && (
          <>
            <h3 id="nm-delete-title">{tr("تایید حذف خبر")}</h3>
            <p>{tr("آیا از حذف خبر «{0}» مطمئن هستید؟ تصویر شاخص و گالری آن هم حذف می‌شود و این عملیات قابل بازگشت نیست.", [deleting.title])}</p>
            <div className="modal-actions">
              <button type="button" className="btn btn-primary danger-solid" onClick={confirmDelete} disabled={deletingBusy}>{deletingBusy ? tr("در حال حذف...") : tr("بله، حذف شود")}</button>
              <button type="button" className="btn btn-ghost" onClick={() => setDeleting(null)} disabled={deletingBusy}>{tr("انصراف")}</button>
            </div>
          </>
        )}
      </GlobalModal>
    </div>
  );
}

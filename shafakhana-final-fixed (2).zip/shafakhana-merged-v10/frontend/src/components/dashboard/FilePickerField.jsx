import { CheckCircle2, Upload } from "lucide-react";
import { tr } from "../../i18n/tr.js";
import "./FilePickerField.css";

// انتخاب فایل/عکس با وضعیت واضح: قبل از انتخاب «فایلی انتخاب نشده است»، بعد از انتخاب تیک سبز + نام فایل.
// input بومی مرورگر مخفی است (متن «No file chosen» انگلیسی و بعد از پاک‌کردن value خالی می‌ماند)؛
// وضعیت از state والد (file) خوانده می‌شود، پس با ذخیره/بستن فرم خودکار به حالت اول برمی‌گردد.
// onChange همان رویداد بومی را می‌گیرد، پس handlerهای قبلی (که e.target.value را پاک می‌کنند) بدون تغییر کار می‌کنند.
export default function FilePickerField({ id, accept, file, onChange, disabled = false, emptyLabel, chooseLabel, changeLabel, readyLabel }) {
  return (
    <div className={`fpf${file ? " is-ok" : ""}`}>
      <input id={id} className="fpf-input" type="file" accept={accept} onChange={onChange} disabled={disabled} />
      <label htmlFor={id} className={`btn btn-ghost btn-sm fpf-btn${disabled ? " is-disabled" : ""}`}>
        <Upload size={14} aria-hidden="true" />
        {file ? (changeLabel || tr("تغییر عکس")) : (chooseLabel || tr("انتخاب عکس"))}
      </label>
      <span className="fpf-status" role="status" aria-live="polite">
        {file ? (
          <>
            <CheckCircle2 size={18} className="fpf-check" aria-hidden="true" />
            <span className="fpf-name" dir="ltr" title={file.name}>{file.name}</span>
            <span className="fpf-ready">{readyLabel || tr("تأیید شد — هنگام ذخیره آپلود می‌شود")}</span>
          </>
        ) : (
          <span className="fpf-empty">{emptyLabel || tr("فایلی انتخاب نشده است")}</span>
        )}
      </span>
    </div>
  );
}

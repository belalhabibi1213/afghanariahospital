import { describe, it, expect } from "vitest";
import { useState } from "react";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import FilePickerField from "./FilePickerField.jsx";

function Harness() {
  const [file, setFile] = useState(null);
  return (
    <FilePickerField
      id="t-photo"
      accept="image/png"
      file={file}
      onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ""; if (f) setFile(f); }}
    />
  );
}

describe("FilePickerField", () => {
  it("قبل از انتخاب پیام خالی و بعد از انتخاب تیک تأیید + نام فایل را نشان می‌دهد (حتی با پاک‌شدن value)", async () => {
    const { container } = render(<Harness />);
    expect(screen.getByText("فایلی انتخاب نشده است")).toBeInTheDocument();
    await userEvent.upload(container.querySelector("input[type=file]"), new File(["x"], "doctor.png", { type: "image/png" }));
    expect(await screen.findByText("doctor.png")).toBeInTheDocument();
    expect(screen.getByText(/تأیید شد/)).toBeInTheDocument();
    expect(screen.queryByText("فایلی انتخاب نشده است")).not.toBeInTheDocument();
    expect(screen.getByText("تغییر عکس")).toBeInTheDocument();
  });
});

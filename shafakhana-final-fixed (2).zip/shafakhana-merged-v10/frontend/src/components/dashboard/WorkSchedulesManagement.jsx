import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Search, X, Plus, Pencil, Trash2, FileText, FileSpreadsheet, ChevronRight, ChevronLeft,
  Users, CalendarDays, CalendarCheck, UserX, Clock, Moon, Sun,
} from "lucide-react";
import GlobalModal from "../GlobalModal.jsx";
import TimePairPicker from "./TimePairPicker.jsx";
import { useDepartmentToasts, DepartmentToastContainer } from "./DepartmentToast.jsx";
import { apiRequest, resolvePhotoUrl } from "../../utils/api.js";
import { escapeHtml } from "../../utils/escapeHtml.js";

import { tr, numLocale, jdate, MONTH_NAMES, tdigits } from "../../i18n/tr.js";
// ============================================================================
// برنامه‌های کاری داکتران (Admin Dashboard)
// ----------------------------------------------------------------------------
// فقط رابط کاربری بازطراحی شده است. هیچ API/جدول/مایگریشن جدیدی ساخته نشده:
//   GET    /admin/schedules        همه‌ی برنامه‌ها (JOIN با داکتر: doctorName, department)
//   POST   /admin/schedules        ثبت برنامه برای «یک روز هفته»
//   PUT    /admin/schedules/:id    ویرایش
//   DELETE /admin/schedules/:id    حذف
//   GET    /admin/doctors          اطلاعات داکتر (کد، عکس، بخش)
// مدل داده: هر ردیف یک «الگوی هفتگی تکرارشونده» است (doctorId, dayOfWeek, startTime,
// endTime, breakStart, breakEnd). تاریخ مشخص، نوع شیفت، وضعیت و توضیحات در دیتابیس
// وجود ندارد، پس نمایش روزانه/ماهانه از روی روز هفته‌ی همان تاریخ محاسبه می‌شود و
// «تعطیل» یعنی آن داکتر در آن روز هفته برنامه‌ای ندارد.
// ============================================================================

const WEEKDAYS = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];

const faNum = (n) => Number(n || 0).toLocaleString(numLocale());
const faDigits = (v) => tdigits(String(v ?? ""));
const hhmm = (v) => (v ? String(v).slice(0, 5) : "");
const fmtT = (v) => faDigits(hhmm(v));

const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const noon = (d) => { const x = new Date(d); x.setHours(12, 0, 0, 0); return x; };
const dayIndex = (d) => (d.getDay() + 1) % 7; // شنبه = ۰
const sameDay = (a, b) => a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
const weekStart = (d) => addDays(noon(d), -dayIndex(d));

const faFmt = (d, opts) => new Intl.DateTimeFormat(numLocale(), opts).format(d);
const jalali = (d) => {
  const parts = new Intl.DateTimeFormat("en-US-u-ca-persian", { year: "numeric", month: "numeric", day: "numeric" }).formatToParts(d);
  const g = (t) => Number(parts.find((p) => p.type === t)?.value);
  return { y: g("year"), m: g("month"), d: g("day") };
};
const dateLong = (d) => jdate(d, { month: "long" });
const dateShort = (d) => jdate(d, { month: "short" });

function monthDays(anchor) {
  let s = noon(anchor);
  while (jalali(s).d > 1) s = addDays(s, -1);
  const m = jalali(s).m;
  const days = [];
  for (let c = s; jalali(c).m === m; c = addDays(c, 1)) days.push(c);
  return days;
}

const minutes = (t) => { const [h, m] = hhmm(t).split(":").map(Number); return h * 60 + m; };
// شیفت شب: چون ساعت‌ها در دیتابیس فقط داخل «یک روز» معتبرند (۰۰:۰۰ تا ۲۳:۵۹)، شیفتی که از نیمه‌شب
// عبور می‌کند به دو ردیف ثبت می‌شود: [شروع تا ۲۳:۵۹ در روز اول] و [۰۰:۰۰ تا پایان در روز بعد].
const NIGHT_END = "23:59";
const isNightPart = (s) => hhmm(s.endTime) === NIGHT_END || hhmm(s.startTime) === "00:00";
const endDisp = (v) => (hhmm(v) === NIGHT_END ? "24:00" : hhmm(v)); // ۲۳:۵۹ به‌صورت «۲۴:۰۰» نمایش داده می‌شود
const fmtEnd = (v) => faDigits(endDisp(v));
const SHIFT_PRESETS = {
  day: { startTime: "08:00", endTime: "20:00" },
  night: { startTime: "20:00", endTime: "08:00" },
};
function durationLabel(s) {
  const endMin = hhmm(s.endTime) === NIGHT_END ? 1440 : minutes(s.endTime);
  let total = endMin - minutes(s.startTime);
  if (s.breakStart && s.breakEnd) total -= minutes(s.breakEnd) - minutes(s.breakStart);
  if (!(total > 0)) return "";
  const h = Math.floor(total / 60), m = total % 60;
  return `${h ? tr("{0} ساعت", [faNum(h)]) : ""}${h && m ? tr(" و ") : ""}${m ? tr("{0} دقیقه", [faNum(m)]) : ""}`;
}

function Avatar({ doctor, size = 40 }) {
  const src = doctor?.photoUrl ? resolvePhotoUrl(doctor.photoUrl) : null;
  return (
    <span className="wsch-avatar" style={{ width: size, height: size }}>
      {src ? <img src={src} alt="" loading="lazy" /> : <span>{doctor?.fullName?.charAt(0) || "🩺"}</span>}
    </span>
  );
}

function splitOvernight(f, day) {
  const next = WEEKDAYS[(WEEKDAYS.indexOf(day) + 1) % 7];
  const hasBreak = f.breakStart && f.breakEnd;
  const inFirst = hasBreak && f.breakStart >= f.startTime;
  return [
    { dayOfWeek: day, startTime: f.startTime, endTime: NIGHT_END, breakStart: inFirst ? f.breakStart : "", breakEnd: inFirst ? f.breakEnd : "" },
    { dayOfWeek: next, startTime: "00:00", endTime: f.endTime, breakStart: hasBreak && !inFirst ? f.breakStart : "", breakEnd: hasBreak && !inFirst ? f.breakEnd : "" },
  ];
}

const emptyForm = { shiftType: "custom", doctorId: "", days: [], dayOfWeek: WEEKDAYS[0], startTime: "08:00", endTime: "14:00", breakStart: "", breakEnd: "" };

// ============================================================================
export default function WorkSchedulesManagement() {
  const { toasts, showToast, dismissToast } = useDepartmentToasts();
  const [doctors, setDoctors] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState("");

  const [view, setView] = useState("week"); // day | week | month
  const [anchor, setAnchor] = useState(() => noon(new Date()));
  const [q, setQ] = useState("");
  const [deptFilter, setDeptFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all"); // all | has | none
  const [dayFilter, setDayFilter] = useState("all");
  const [selectedId, setSelectedId] = useState(null);

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null); // ردیف برنامه در حال ویرایش
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [deleting, setDeleting] = useState(null); // { ids, text }
  const [deletingBusy, setDeletingBusy] = useState(false);
  const [exporting, setExporting] = useState(false);

  const load = useCallback(() => {
    return Promise.all([apiRequest("/admin/doctors"), apiRequest("/admin/schedules")])
      .then(([d, s]) => { setDoctors(d.doctors || []); setSchedules(s.schedules || []); setLoadError(""); })
      .catch((err) => setLoadError(err.message))
      .finally(() => setLoading(false));
  }, []);
  useEffect(() => { load(); }, [load]);

  // ---------- داده‌ی مشتق (فقط از داده‌ی واقعی) ----------
  const byDoctor = useMemo(() => {
    const map = new Map();
    for (const s of schedules) {
      if (!map.has(s.doctorId)) map.set(s.doctorId, []);
      map.get(s.doctorId).push(s);
    }
    map.forEach((list) => list.sort((a, b) => WEEKDAYS.indexOf(a.dayOfWeek) - WEEKDAYS.indexOf(b.dayOfWeek) || hhmm(a.startTime).localeCompare(hhmm(b.startTime))));
    return map;
  }, [schedules]);

  const departments = useMemo(() => [...new Set(doctors.map((d) => d.department).filter(Boolean))].sort((a, b) => a.localeCompare(b, "fa")), [doctors]);

  const filteredDoctors = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return doctors.filter((d) => {
      const list = byDoctor.get(d.id) || [];
      if (deptFilter !== "all" && d.department !== deptFilter) return false;
      if (statusFilter === "has" && list.length === 0) return false;
      if (statusFilter === "none" && list.length > 0) return false;
      if (dayFilter !== "all" && !list.some((s) => s.dayOfWeek === dayFilter)) return false;
      if (!needle) return true;
      return [d.fullName, d.doctorCode, d.department].some((f) => String(f || "").toLowerCase().includes(needle));
    });
  }, [doctors, byDoctor, q, deptFilter, statusFilter, dayFilter]);

  const filtersActive = q.trim() !== "" || deptFilter !== "all" || statusFilter !== "all" || dayFilter !== "all";
  const clearFilters = () => { setQ(""); setDeptFilter("all"); setStatusFilter("all"); setDayFilter("all"); };

  const todayName = WEEKDAYS[dayIndex(new Date())];
  const doctorsWithSchedule = new Set(schedules.map((s) => s.doctorId)).size;
  const workingToday = new Set(schedules.filter((s) => s.dayOfWeek === todayName).map((s) => s.doctorId)).size;

  const selected = doctors.find((d) => d.id === selectedId) || null;
  const dayList = (doctorId, dayName) => (byDoctor.get(doctorId) || []).filter((s) => s.dayOfWeek === dayName);

  // ---------- ناوبری تقویم ----------
  const shift = (dir) => {
    if (view === "day") setAnchor((a) => addDays(a, dir));
    else if (view === "week") setAnchor((a) => addDays(a, dir * 7));
    else {
      const days = monthDays(anchor);
      setAnchor(dir > 0 ? addDays(days[days.length - 1], 1) : addDays(days[0], -1));
    }
  };
  const days7 = Array.from({ length: 7 }, (_, i) => addDays(weekStart(anchor), i));
  const rangeLabel = view === "day"
    ? tr("{0}، {1}", [tr(WEEKDAYS[dayIndex(anchor)]), dateLong(anchor)])
    : view === "week"
      ? tr("{0} تا {1}", [dateShort(days7[0]), dateLong(days7[6])])
      : `${MONTH_NAMES[jalali(anchor).m - 1]} ${tdigits(jalali(anchor).y)}`;

  // ---------- فرم ----------
  function openAdd(doctorId = "") {
    setEditing(null); setForm({ ...emptyForm, doctorId: doctorId ? String(doctorId) : "" }); setFormError(""); setFormOpen(true);
  }
  function openEdit(s) {
    setEditing(s);
    setForm({ shiftType: "custom", doctorId: String(s.doctorId), days: [], dayOfWeek: s.dayOfWeek, startTime: hhmm(s.startTime), endTime: hhmm(s.endTime), breakStart: hhmm(s.breakStart), breakEnd: hhmm(s.breakEnd) });
    setFormError(""); setFormOpen(true);
  }
  const setF = (k, v) => { setForm((f) => ({ ...f, [k]: v })); setFormError(""); };
  const pickShift = (type) => setForm((f) => ({ ...f, shiftType: type, ...(SHIFT_PRESETS[type] || {}), breakStart: "", breakEnd: "" }));
  const isOvernight = !editing && !!form.startTime && !!form.endTime && form.endTime < form.startTime;
  const toggleDay = (d) => setF("days", form.days.includes(d) ? form.days.filter((x) => x !== d) : [...form.days, d]);

  function validate() {
    if (!form.doctorId) return tr("لطفاً یک داکتر انتخاب کنید");
    if (!editing && form.days.length === 0) return tr("لطفاً حداقل یک روز را انتخاب کنید");
    if (!form.startTime || !form.endTime) return tr("ساعت شروع و ختم الزامی است");
    if (form.startTime === form.endTime) return tr("ساعت شروع و ختم نمی‌تواند یکی باشد");
    if (editing && form.startTime > form.endTime) return tr("در ویرایش، ساعت ختم باید بعد از شروع باشد. هر بخش شیفت شب (قبل و بعد از نیمه‌شب) را جداگانه ویرایش کنید");
    if (!!form.breakStart !== !!form.breakEnd) return tr("برای استراحت، هر دو ساعت شروع و پایان را وارد کنید");
    if (form.breakStart && form.breakEnd) {
      if (form.breakStart >= form.breakEnd) return tr("پایان استراحت باید بعد از شروع آن باشد");
      if (isOvernight) {
        const beforeMidnight = form.breakStart >= form.startTime;
        const afterMidnight = form.breakEnd <= form.endTime;
        if (!beforeMidnight && !afterMidnight) return tr("زمان استراحت باید داخل بازه‌ی کاری و کاملاً قبل یا کاملاً بعد از نیمه‌شب باشد");
      } else if (form.breakStart < form.startTime || form.breakEnd > form.endTime) return tr("زمان استراحت باید داخل بازه‌ی کاری باشد");
    }
    return "";
  }

  async function submit(e) {
    e.preventDefault();
    const err = validate();
    if (err) { setFormError(err); return; }
    setSubmitting(true); setFormError("");
    const base = { doctorId: form.doctorId, startTime: form.startTime, endTime: form.endTime, breakStart: form.breakStart, breakEnd: form.breakEnd };
    try {
      if (editing) {
        await apiRequest(`/admin/schedules/${editing.id}`, { method: "PUT", body: { ...base, dayOfWeek: form.dayOfWeek } });
        showToast(tr("برنامه کاری به‌روزرسانی شد"), "success");
      } else {
        // بک‌اند هر برنامه را برای یک روز ذخیره می‌کند؛ برای چند روز، یک درخواست به‌ازای هر روز (مثل قبل)
        const failed = [];
        for (const dayOfWeek of form.days) {
          // شیفت شب: دو ردیف (شب همان روز + بامداد روز بعد)؛ در غیر این صورت یک ردیف
          const parts = isOvernight ? splitOvernight(form, dayOfWeek) : [{ dayOfWeek, startTime: form.startTime, endTime: form.endTime, breakStart: form.breakStart, breakEnd: form.breakEnd }];
          for (const part of parts) {
            try { await apiRequest("/admin/schedules", { method: "POST", body: { doctorId: form.doctorId, ...part } }); }
            catch (ex) { failed.push(`${tr(part.dayOfWeek)} (${ex.message})`); }
          }
        }
        if (failed.length > 0 && failed.length >= form.days.length * (isOvernight ? 2 : 1)) { setFormError(tr("ثبت نشد: {0}", [failed.join(tr("، "))])); setSubmitting(false); return; }
        showToast(failed.length ? tr("بخشی ثبت شد. ناموفق: {0}", [failed.join(tr("، "))]) : tr("برنامه کاری ثبت شد"), failed.length ? "error" : "success");
        setSelectedId(Number(form.doctorId));
      }
      setFormOpen(false);
      load();
    } catch (ex) {
      setFormError(ex.message);
    } finally {
      setSubmitting(false);
    }
  }

  // حذف یک روز؛ اگر بخشی از شیفت شب باشد، بخش مکمل آن (قبل/بعد از نیمه‌شب) هم پیشنهاد حذف می‌شود
  function askDeleteOne(s, name) {
    const list = byDoctor.get(s.doctorId) || [];
    let partner = null;
    if (hhmm(s.endTime) === NIGHT_END) {
      const next = WEEKDAYS[(WEEKDAYS.indexOf(s.dayOfWeek) + 1) % 7];
      partner = list.find((x) => x.dayOfWeek === next && hhmm(x.startTime) === "00:00");
    } else if (hhmm(s.startTime) === "00:00") {
      const prev = WEEKDAYS[(WEEKDAYS.indexOf(s.dayOfWeek) + 6) % 7];
      partner = list.find((x) => x.dayOfWeek === prev && hhmm(x.endTime) === NIGHT_END);
    }
    const doc = doctors.find((d) => d.id === s.doctorId);
    setDeleting({
      ids: partner ? [s.id, partner.id] : [s.id],
      text: partner
        ? tr("شیفت شب داکتر «{0}» (هر دو بخش: {1} و {2})", [doc?.fullName || "", tr(s.dayOfWeek), tr(partner.dayOfWeek)])
        : tr("برنامه‌ی {0} ({1} - {2}) داکتر «{3}»", [name, fmtT(s.startTime), fmtEnd(s.endTime), doc?.fullName || ""]),
    });
  }

  async function confirmDelete() {
    if (!deleting) return;
    setDeletingBusy(true);
    try {
      for (const id of deleting.ids) await apiRequest(`/admin/schedules/${id}`, { method: "DELETE" });
      showToast(tr("برنامه کاری حذف شد"), "success");
      setDeleting(null);
      load();
    } catch (ex) {
      showToast(ex.message, "error");
      load();
    } finally { setDeletingBusy(false); }
  }

  // ---------- خروجی ----------
  const exportRows = useMemo(() => {
    const rows = [];
    filteredDoctors.forEach((d) => (byDoctor.get(d.id) || []).forEach((s) => {
      if (dayFilter !== "all" && s.dayOfWeek !== dayFilter) return;
      rows.push({ "کد داکتر": d.doctorCode, "داکتر": d.fullName, "بخش": d.department, "روز": s.dayOfWeek, "ساعت شروع": hhmm(s.startTime), "ساعت ختم": endDisp(s.endTime), "استراحت": s.breakStart && s.breakEnd ? `${hhmm(s.breakStart)} - ${hhmm(s.breakEnd)}` : "—", "مدت کار": durationLabel(s) });
    }));
    return rows;
  }, [filteredDoctors, byDoctor, dayFilter]);

  async function exportExcel() {
    if (!exportRows.length) return;
    setExporting(true);
    try {
      const { downloadXlsx } = await import("../../utils/exportXlsx.js");
      await downloadXlsx(`work-schedules-${Date.now()}.xlsx`, [{ name: "برنامه‌های کاری", rows: exportRows }]);
    } catch { showToast(tr("خطا در ساخت فایل Excel"), "error"); } finally { setExporting(false); }
  }

  async function exportPdf() {
    if (!exportRows.length) return;
    setExporting(true);
    // جدول ساده‌ی سفید/مشکی مخصوص خروجی (مستقل از تم تیره/روشن تا همیشه خوانا باشد).
    // نکته: از <h2> استفاده نمی‌کنیم چون استایل سراسری h1–h4 مقدار letter-spacing منفی دارد و
    // html2canvas در این حالت حروف فارسی را جدا رسم می‌کند (اتصال حروف به‌هم می‌ریزد).
    const box = document.createElement("div");
    box.dir = "rtl";
    box.style.cssText = "position:fixed;left:-10000px;top:0;width:1100px;padding:24px;background:#fff;color:#111;font-family:Vazirmatn,sans-serif;letter-spacing:normal;word-spacing:normal;";
    const cols = Object.keys(exportRows[0]);
    box.innerHTML = `<div style="margin:0 0 4px;font-size:22px;font-weight:700;letter-spacing:normal;line-height:1.6">برنامه‌های کاری داکتران</div><p style="margin:0 0 14px;color:#555;font-size:13px">${dateLong(new Date())}</p>
      <table style="width:100%;border-collapse:collapse;font-size:13px"><thead><tr>${cols.map((c) => `<th style="border:1px solid #bbb;padding:7px;background:#eef2f7;text-align:right">${escapeHtml(c)}</th>`).join("")}</tr></thead>
      <tbody>${exportRows.map((r) => `<tr>${cols.map((c) => `<td style="border:1px solid #ccc;padding:6px 7px">${escapeHtml(faDigits(r[c]))}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
    document.body.appendChild(box);
    try {
      const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
      // برش بین سطرها (نه وسط سطر) + تکرار سرستون در هر صفحه — utils/pdfTable.js
      const { tableBoxToPdf } = await import("../../utils/pdfTable.js");
      await tableBoxToPdf(box, { html2canvas, jsPDF, fileName: `work-schedules-${Date.now()}.pdf` });
    } catch { showToast(tr("خطا در ساخت فایل PDF"), "error"); } finally { box.remove(); setExporting(false); }
  }

  // ---------- اجزای نمایش ----------
  function Shift({ s, compact }) {
    return (
      <span className="wsch-shift" title={durationLabel(s) ? tr("مدت کار: {0}", [durationLabel(s)]) : undefined}>
        <strong className="pm-num">{fmtT(s.startTime)} - {fmtEnd(s.endTime)}</strong>
        {isNightPart(s) && <span className="wsch-night-tag"><Moon size={10} />{" "}{tr("شب")}</span>}
        {!compact && s.breakStart && s.breakEnd && <small>{tr("استراحت {0}–{1}", [fmtT(s.breakStart), fmtT(s.breakEnd)])}</small>}
      </span>
    );
  }

  const stats = [
    { label: tr("داکتران دارای برنامه"), value: doctorsWithSchedule, sub: tr("از {0} داکتر", [faNum(doctors.length)]), icon: Users, tone: "blue" },
    { label: tr("کل برنامه‌های کاری"), value: schedules.length, sub: tr("روز-شیفت هفتگی ثبت‌شده"), icon: CalendarDays, tone: "violet" },
    { label: tr("داکتران فعال امروز"), value: workingToday, sub: tr("{0}، {1}", [tr(todayName), dateShort(new Date())]), icon: CalendarCheck, tone: "green" },
    { label: tr("داکتران بدون برنامه"), value: doctors.length - doctorsWithSchedule, sub: tr("هنوز برنامه‌ای ثبت نشده"), icon: UserX, tone: "amber" },
  ];

  const noDoctors = !loading && !loadError && doctors.length === 0;

  return (
    <div className="pm-page wsch-page">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* ---- سربرگ ---- */}
      <div className="pm-head">
        <div>
          <h2>{tr("برنامه‌های کاری داکتران")}</h2>
          <p>{tr("مشاهده و مدیریت برنامه‌های کاری داکتران شفاخانه")}</p>
        </div>
        <div className="pm-head-actions wsch-head-actions">
          <button type="button" className="btn btn-primary" onClick={() => openAdd(selectedId || "")} disabled={noDoctors}><Plus size={16} />{" "}{tr("افزودن برنامه کاری")}</button>
          <button type="button" className="btn btn-ghost" onClick={exportPdf} disabled={exporting || exportRows.length === 0}><FileText size={16} />{" "}{tr("خروجی PDF")}</button>
          <button type="button" className="btn btn-ghost" onClick={exportExcel} disabled={exporting || exportRows.length === 0}><FileSpreadsheet size={16} />{" "}{tr("خروجی Excel")}</button>
        </div>
      </div>

      {loadError && <div className="form-message error" role="alert">{loadError} <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setLoading(true); load(); }}>{tr("تلاش دوباره")}</button></div>}

      {/* ---- کارت‌های آماری ---- */}
      <div className="pm-stats wsch-stats">
        {stats.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className={`pm-stat wsch-stat wsch-tone-${c.tone}`} style={{ cursor: "default" }}>
              <span className="pm-stat-icon"><Icon size={20} /></span>
              <span>
                {loading ? <span className="pm-skel wsch-skel-num" /> : <span className="pm-stat-num">{faNum(c.value)}</span>}
                <span className="pm-stat-label">{c.label}</span>
                {!loading && <span className="wsch-stat-sub">{c.sub}</span>}
              </span>
            </div>
          );
        })}
      </div>

      {/* ---- جستجو و فیلتر ---- */}
      <div className="pm-filterbar">
        <div className="pm-filter-row">
          <div className="pm-search">
            <Search size={16} />
            <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={tr("جستجوی داکتر بر اساس نام، کد یا بخش...")} aria-label={tr("جستجوی داکتر")} />
          </div>
          <select className="wsch-select" value={deptFilter} onChange={(e) => setDeptFilter(e.target.value)} aria-label={tr("فیلتر بخش / تخصص")}>
            <option value="all">{tr("همه‌ی بخش‌ها / تخصص‌ها")}</option>
            {departments.map((d) => <option key={d} value={d}>{d}</option>)}
          </select>
          <select className="wsch-select" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} aria-label={tr("فیلتر وضعیت")}>
            <option value="all">{tr("همه‌ی وضعیت‌ها")}</option>
            <option value="has">{tr("دارای برنامه")}</option>
            <option value="none">{tr("بدون برنامه")}</option>
          </select>
          <select className="wsch-select" value={dayFilter} onChange={(e) => setDayFilter(e.target.value)} aria-label={tr("فیلتر روز هفته")}>
            <option value="all">{tr("همه‌ی روزهای هفته")}</option>
            {WEEKDAYS.map((d) => <option key={d} value={d}>{tr(d)}</option>)}
          </select>
          {filtersActive && <button type="button" className="btn btn-ghost btn-sm pm-clear" onClick={clearFilters}><X size={14} />{" "}{tr("پاک‌کردن فیلترها")}</button>}
        </div>
      </div>

      {noDoctors && (
        <div className="pm-tablewrap"><div className="pm-state"><strong>{tr("هنوز داکتری ثبت نشده است")}</strong>{tr("برای ثبت برنامه کاری، ابتدا از بخش «مدیریت داکتران» یک داکتر اضافه کنید.")}</div></div>
      )}

      {!noDoctors && (
        <div className="wsch-layout">
          {/* ---- تقویم ---- */}
          <section className="wsch-calendar" aria-label={tr("تقویم برنامه کاری")}>
            <div className="wsch-cal-bar">
              <div className="dm-seg wsch-seg" role="radiogroup" aria-label={tr("نوع نمایش")}>
                {[["week", tr("هفتگی")], ["day", tr("روزانه")], ["month", tr("ماهانه")]].map(([k, l]) => (
                  <button key={k} type="button" role="radio" aria-checked={view === k} className={view === k ? "is-active" : ""} onClick={() => setView(k)}>{l}</button>
                ))}
              </div>
              <div className="wsch-nav">
                <button type="button" className="pm-iconbtn" aria-label={tr("قبلی")} onClick={() => shift(-1)}><ChevronRight size={16} /></button>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setAnchor(noon(new Date()))}>{view === "day" ? tr("امروز") : view === "week" ? tr("هفته جاری") : tr("ماه جاری")}</button>
                <button type="button" className="pm-iconbtn" aria-label={tr("بعدی")} onClick={() => shift(1)}><ChevronLeft size={16} /></button>
                <span className="wsch-range">{rangeLabel}</span>
              </div>
            </div>

            {loading && <div className="wsch-skel-grid">{Array.from({ length: 5 }).map((_, i) => <div key={i} className="pm-skel" />)}</div>}

            {!loading && filteredDoctors.length === 0 && (
              <div className="pm-state"><strong>{tr("داکتری مطابق فیلترها یافت نشد")}</strong><button type="button" className="btn btn-ghost" onClick={clearFilters}>{tr("پاک‌کردن فیلترها")}</button></div>
            )}

            {/* هفتگی */}
            {!loading && filteredDoctors.length > 0 && view === "week" && (
              <div className="wsch-scroll">
                <table className="wsch-grid">
                  <thead>
                    <tr>
                      <th className="wsch-th-doctor">{tr("داکتر / تخصص")}</th>
                      {days7.map((d, i) => (
                        <th key={i} className={sameDay(d, new Date()) ? "is-today" : ""}>{tr(WEEKDAYS[i])}<small>{dateShort(d)}</small></th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {filteredDoctors.map((doc) => (
                      <tr key={doc.id} className={selectedId === doc.id ? "is-selected" : ""}>
                        <th className="wsch-td-doctor">
                          <button type="button" onClick={() => setSelectedId(doc.id)}>
                            <Avatar doctor={doc} size={38} />
                            <span><strong>{doc.fullName}</strong><small>{doc.department}</small></span>
                          </button>
                        </th>
                        {WEEKDAYS.map((name, i) => {
                          const list = dayList(doc.id, name);
                          return (
                            <td key={name} className={sameDay(days7[i], new Date()) ? "is-today" : ""}>
                              {list.length === 0
                                ? <span className="wsch-off">{tr("تعطیل")}</span>
                                : list.map((s) => <button type="button" key={s.id} className={`wsch-cell${isNightPart(s) ? " is-night" : ""}`} onClick={() => setSelectedId(doc.id)}><Shift s={s} /></button>)}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* روزانه */}
            {!loading && filteredDoctors.length > 0 && view === "day" && (() => {
              const name = WEEKDAYS[dayIndex(anchor)];
              const working = filteredDoctors.map((d) => ({ d, list: dayList(d.id, name) })).filter((x) => x.list.length).sort((a, b) => hhmm(a.list[0].startTime).localeCompare(hhmm(b.list[0].startTime)));
              const off = filteredDoctors.filter((d) => dayList(d.id, name).length === 0);
              return (
                <div className="wsch-day">
                  {working.length === 0 && <div className="pm-state"><strong>{tr("در این روز هیچ داکتری برنامه کاری ندارد")}</strong></div>}
                  {working.map(({ d, list }) => (
                    <button type="button" key={d.id} className={`wsch-day-row${selectedId === d.id ? " is-selected" : ""}`} onClick={() => setSelectedId(d.id)}>
                      <Avatar doctor={d} size={42} />
                      <span className="wsch-day-info"><strong>{d.fullName}</strong><small>{d.department} • {d.doctorCode}</small></span>
                      <span className="wsch-day-times">{list.map((s) => <span key={s.id} className={`wsch-chip-time${isNightPart(s) ? " is-night" : ""}`}><Shift s={s} /><em>{durationLabel(s)}</em></span>)}</span>
                    </button>
                  ))}
                  {off.length > 0 && (
                    <div className="wsch-day-off"><span className="wsch-off">{tr("تعطیل ({0})", [faNum(off.length)])}</span>{off.map((d) => <button type="button" key={d.id} className="wsch-mini" onClick={() => setSelectedId(d.id)}>{d.fullName}</button>)}</div>
                  )}
                </div>
              );
            })()}

            {/* ماهانه */}
            {!loading && filteredDoctors.length > 0 && view === "month" && (() => {
              const days = monthDays(anchor);
              const lead = dayIndex(days[0]);
              return (
                <div className="wsch-scroll">
                  <div className="wsch-month">
                    {WEEKDAYS.map((n) => <div key={n} className="wsch-month-h">{tr(n)}</div>)}
                    {Array.from({ length: lead }).map((_, i) => <div key={`b${i}`} className="wsch-month-blank" />)}
                    {days.map((d) => {
                      const name = WEEKDAYS[dayIndex(d)];
                      const working = filteredDoctors.filter((doc) => dayList(doc.id, name).length > 0);
                      return (
                        <button type="button" key={d.getTime()} className={`wsch-month-cell${sameDay(d, new Date()) ? " is-today" : ""}`} onClick={() => { setAnchor(noon(d)); setView("day"); }}>
                          <span className="wsch-month-day">{faFmt(d, { day: "numeric" })}</span>
                          {working.length === 0 ? <span className="wsch-off">{tr("تعطیل")}</span> : (
                            <>
                              <span className="wsch-month-count">{tr("{0} داکتر", [faNum(working.length)])}</span>
                              {working.slice(0, 2).map((w) => <span key={w.id} className="wsch-month-name">{w.fullName}</span>)}
                              {working.length > 2 && <span className="wsch-month-more">+{faNum(working.length - 2)}</span>}
                            </>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              );
            })()}
          </section>

          {/* ---- ستون کناری: لیست داکتران + جزئیات ---- */}
          <aside className="wsch-aside">
            {selected && (
              <div className="wsch-detail" aria-label={tr("جزئیات برنامه")}>
                <button type="button" className="wsch-detail-close pm-iconbtn" aria-label={tr("بستن")} onClick={() => setSelectedId(null)}><X size={15} /></button>
                <div className="wsch-detail-head">
                  <Avatar doctor={selected} size={64} />
                  <div>
                    <h3>{selected.fullName}</h3>
                    <p>{selected.department}</p>
                    <span className="pm-muted">{tr("کد داکتر:")}{" "}<bdi className="pm-num">{selected.doctorCode}</bdi></span>
                  </div>
                </div>
                <div className="wsch-detail-stats">
                  <div><strong className="pm-num">{faNum((byDoctor.get(selected.id) || []).length)}</strong><span>{tr("روز کاری در هفته")}</span></div>
                  <div><span className={`wsch-state ${(byDoctor.get(selected.id) || []).length ? "is-on" : "is-off"}`}>{(byDoctor.get(selected.id) || []).length ? tr("دارای برنامه") : tr("بدون برنامه")}</span><span>{tr("وضعیت برنامه")}</span></div>
                </div>
                <h4>{tr("برنامه‌ی هفته")}</h4>
                <ul className="wsch-week-list">
                  {WEEKDAYS.map((name) => {
                    const list = dayList(selected.id, name);
                    return (
                      <li key={name}>
                        <span className="wsch-wd">{tr(name)}</span>
                        {list.length === 0 ? <span className="wsch-off">{tr("تعطیل")}</span> : (
                          <span className="wsch-wd-items">
                            {list.map((s) => (
                              <span key={s.id} className="wsch-wd-item">
                                <Shift s={s} />
                                {durationLabel(s) && <em>{durationLabel(s)}</em>}
                                <span className="wsch-wd-actions">
                                  <button type="button" className="pm-iconbtn" title={tr("ویرایش برنامه")} aria-label={tr("ویرایش برنامه {0}", [name])} onClick={() => openEdit(s)}><Pencil size={13} /></button>
                                  <button type="button" className="pm-iconbtn" title={tr("حذف برنامه")} aria-label={tr("حذف برنامه {0}", [name])} onClick={() => askDeleteOne(s, name)}><Trash2 size={13} /></button>
                                </span>
                              </span>
                            ))}
                          </span>
                        )}
                      </li>
                    );
                  })}
                </ul>
                <div className="wsch-detail-actions">
                  <button type="button" className="btn btn-primary btn-sm" onClick={() => openAdd(selected.id)}><Plus size={14} />{" "}{tr("افزودن برنامه")}</button>
                  {(byDoctor.get(selected.id) || []).length > 0 && (
                    <button type="button" className="btn btn-ghost btn-sm danger" onClick={() => setDeleting({ ids: (byDoctor.get(selected.id) || []).map((s) => s.id), text: tr("همه‌ی برنامه‌های کاری داکتر «{0}»", [selected.fullName]) })}><Trash2 size={14} />{" "}{tr("حذف همه")}</button>
                  )}
                </div>
              </div>
            )}

            <div className="wsch-doctors">
              <h4><Users size={15} />{" "}{tr("داکتران")}{" "}<span className="pm-muted">({faNum(filteredDoctors.length)})</span></h4>
              {loading && Array.from({ length: 4 }).map((_, i) => <div key={i} className="pm-skel wsch-skel-row" />)}
              {!loading && filteredDoctors.map((d) => {
                const count = (byDoctor.get(d.id) || []).length;
                return (
                  <button type="button" key={d.id} className={`wsch-doctor${selectedId === d.id ? " is-selected" : ""}`} onClick={() => setSelectedId(d.id)}>
                    <Avatar doctor={d} size={38} />
                    <span className="wsch-doctor-info"><strong>{d.fullName}</strong><small>{d.department} • {d.doctorCode}</small></span>
                    <span className={`wsch-state ${count ? "is-on" : "is-off"}`}>{count ? tr("{0} روز", [faNum(count)]) : tr("بدون برنامه")}</span>
                  </button>
                );
              })}
            </div>
          </aside>
        </div>
      )}

      {/* ---- فرم افزودن / ویرایش ---- */}
      <GlobalModal
        isOpen={formOpen}
        onClose={() => !submitting && setFormOpen(false)}
        title={editing ? tr("ویرایش برنامه کاری") : tr("افزودن برنامه کاری")}
        size="md"
        className="wsch-drawer wsch-form-modal"
        closeOnOverlayClick={false}
        footer={
          <>
            <button className="btn btn-primary" type="submit" form="wsch-form" disabled={submitting}>{submitting ? tr("در حال ذخیره...") : editing ? tr("ذخیره تغییرات") : tr("ثبت برنامه")}</button>
            <button className="btn btn-ghost" type="button" disabled={submitting} onClick={() => setFormOpen(false)}>{tr("انصراف")}</button>
          </>
        }
      >
        <form id="wsch-form" className="login-form dm-form" onSubmit={submit} noValidate>
          {formError && <div className="form-message error" role="alert">{formError}</div>}
          <h4 className="dm-form-title">{tr("داکتر")}</h4>
          <div className="field">
            <label htmlFor="ws-doc">{tr("داکتر")}</label>
            <select id="ws-doc" className="wsch-select wsch-select-full" value={form.doctorId} disabled={!!editing} onChange={(e) => setF("doctorId", e.target.value)}>
              <option value="">{tr("انتخاب کنید")}</option>
              {doctors.map((d) => <option key={d.id} value={d.id}>{d.fullName} — {d.department}</option>)}
            </select>
          </div>

          <h4 className="dm-form-title">{editing ? tr("روز") : tr("روز(ها)")}</h4>
          {editing ? (
            <select className="wsch-select wsch-select-full" aria-label={tr("روز هفته")} value={form.dayOfWeek} onChange={(e) => setF("dayOfWeek", e.target.value)}>
              {WEEKDAYS.map((d) => <option key={d} value={d}>{tr(d)}</option>)}
            </select>
          ) : (
            <div className="wsch-days-pick" role="group" aria-label={tr("روزهای هفته")}>
              {WEEKDAYS.map((d) => <button type="button" key={d} aria-pressed={form.days.includes(d)} className={form.days.includes(d) ? "is-on" : ""} onClick={() => toggleDay(d)}>{tr(d)}</button>)}
            </div>
          )}

          {!editing && (
            <>
              <h4 className="dm-form-title">{tr("نوع شیفت")}</h4>
              <div className="dm-seg wsch-seg" role="radiogroup" aria-label={tr("نوع شیفت")}>
                <button type="button" role="radio" aria-checked={form.shiftType === "day"} className={form.shiftType === "day" ? "is-active" : ""} onClick={() => pickShift("day")}><Sun size={13} />{" "}{tr("شیفت روز")}</button>
                <button type="button" role="radio" aria-checked={form.shiftType === "night"} className={form.shiftType === "night" ? "is-active" : ""} onClick={() => pickShift("night")}><Moon size={13} />{" "}{tr("شیفت شب")}</button>
                <button type="button" role="radio" aria-checked={form.shiftType === "custom"} className={form.shiftType === "custom" ? "is-active" : ""} onClick={() => setF("shiftType", "custom")}>{tr("دلخواه")}</button>
              </div>
              <p className="pm-muted">{tr("شیفت روز ۰۸:۰۰ تا ۲۰:۰۰ و شیفت شب ۲۰:۰۰ تا ۰۸:۰۰ بامداد روز بعد است؛ ساعت‌ها قابل تغییرند.")}</p>
            </>
          )}
          <h4 className="dm-form-title">{tr("ساعت کاری")}</h4>
          <TimePairPicker
            startId="ws-s" endId="ws-e" startLabel={tr("ساعت شروع")} endLabel={tr("ساعت ختم")}
            startValue={form.startTime} endValue={form.endTime}
            onStartChange={(v) => setForm((f) => ({ ...f, shiftType: "custom", startTime: v }))}
            onEndChange={(v) => setForm((f) => ({ ...f, shiftType: "custom", endTime: v }))}
          />
          {isOvernight && (
            <div className="wsch-overnight-note">
              <Moon size={14} />
              <span>{tr("این شیفت از نیمه‌شب عبور می‌کند و برای هر روز انتخابی در دو بخش ثبت می‌شود: همان روز از {0} تا ۲۴:۰۰، و روز بعد از ۰۰:۰۰ تا {1}.", [faDigits(form.startTime), faDigits(form.endTime)])}</span>
            </div>
          )}
          <h4 className="dm-form-title">{tr("زمان استراحت (اختیاری)")}</h4>
          <TimePairPicker
            startId="ws-bs" endId="ws-be" startLabel={tr("شروع استراحت")} endLabel={tr("پایان استراحت")}
            startValue={form.breakStart} endValue={form.breakEnd}
            onStartChange={(v) => setF("breakStart", v)}
            onEndChange={(v) => setF("breakEnd", v)}
            clearable
          />
          <p className="pm-muted"><Clock size={12} />{" "}{tr("ساعت‌های داخل زمان استراحت برای نوبت‌دهی بیماران نمایش داده نمی‌شوند.")}</p>
        </form>
      </GlobalModal>

      {/* ---- تایید حذف (همان دیالوگ استاندارد سیستم) ---- */}
      <GlobalModal
        isOpen={!!deleting}
        onClose={() => (deletingBusy ? null : setDeleting(null))}
        size="sm"
        className="logout-confirm-modal"
        overlayClassName="logout-confirm-overlay"
        labelledBy="wsch-delete-title"
        closeOnOverlayClick={!deletingBusy}
        closeOnEsc={!deletingBusy}
        bare
      >
        {deleting && (
          <>
            <h3 id="wsch-delete-title">{tr("تایید حذف برنامه کاری")}</h3>
            <p>{tr("آیا از حذف {0} مطمئن هستید؟ این عملیات قابل بازگشت نیست.", [deleting.text])}</p>
            <div className="modal-actions">
              <button type="button" className="btn btn-primary danger-solid" onClick={confirmDelete} disabled={deletingBusy}>{deletingBusy ? tr("در حال حذف...") : tr("بله، حذف شود")}</button>
              <button type="button" className="btn btn-ghost" onClick={() => setDeleting(null)} disabled={deletingBusy}>{tr("انصراف")}</button>
            </div>
          </>
        )}
      </GlobalModal>
    </div>
  );
}

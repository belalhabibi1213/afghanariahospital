import { useEffect, useMemo, useState } from "react";
import {
  Search, X, Eye, Printer, Download, RefreshCw, Pill, FileText, FlaskConical, Image as ImageIcon, Users,
  ClipboardList, AlertTriangle, FilterX, ArrowUp, ArrowDown, ChevronsUpDown, CheckCircle2, Clock, XCircle, Plus,
} from "lucide-react";
import { useDepartmentToasts, DepartmentToastContainer } from "./DepartmentToast.jsx";
import { apiRequest, apiDownload } from "../../utils/api.js";

import { JalaliDateInput } from "../JalaliDateInput.jsx";
import { tr, trc, numLocale, jdate } from "../../i18n/tr.js";
// ============================================================================
// «نسخه و سوابق طبی» — فهرست یکپارچه‌ی اسناد (مشترک بین داشبورد ادمین و داکتر)
// ----------------------------------------------------------------------------
// APIهای استفاده‌شده (همه فقط‌خواندنی و سمت سرور فیلتر/صفحه‌بندی می‌شوند):
//   ادمین: GET /api/admin/medical-documents[/stats | /:type/:id]
//   داکتر: GET /api/doctors/me/medical-documents[/stats | /:type/:id]
//   موجود: GET /api/admin/doctors (گزینه‌های فیلتر داکتر — فقط ادمین)
//          GET /api/medical-records/prescriptions/:id/pdf  (چاپ/PDF نسخه)
//          GET /api/medical-records/lab-results/:id/report (گزارش آزمایش)
//          GET /api/medical-records/files/:id              (ضمیمه‌های سابقه صحی)
//          PUT /api/admin/prescriptions/:id/status         (فقط ادمین؛ تکمیل / لغو / فعال‌سازی نسخه)
// کنترل دسترسی در بک‌اند اعمال می‌شود؛ این کامپوننت فقط چیزی را نشان می‌دهد که سرور اجازه داده است
// (مثلاً دکمه‌ی چاپ فقط وقتی ردیف canDownload دارد).
// استایل: components/dashboard/MedicalDocumentsPanel.css (mdoc-*) روی کلاس‌های پایه‌ی rxp-*
// ============================================================================

const TYPES = trc({
  prescription: { label: "نسخه", Icon: Pill, tone: "prescription" },
  record: { label: "سابقه صحی", Icon: FileText, tone: "record" },
  lab: { label: "نتیجه آزمایش", Icon: FlaskConical, tone: "lab" },
  imaging: { label: "تصویر پزشکی", Icon: ImageIcon, tone: "imaging" },
});
const STATUS_LABEL = trc({
  active: "در حال اجرا",
  completed: "تکمیل‌شده",
  cancelled: "لغوشده",
  registered: "ثبت‌شده",
  draft: "پیش‌نویس",
  pending: "در انتظار نتیجه",
});
// وضعیت‌هایی که از قبل کلاس rxp-badge-* دارند؛ بقیه کلاس mdoc-badge-* می‌گیرند
const BASE_BADGES = ["active", "completed", "cancelled"];
const GENDER_LABEL = trc({ male: "مرد", female: "زن", other: "سایر" });
const EMPTY_FILTERS = { type: "", status: "", doctorId: "", dateFrom: "", dateTo: "" };
const PAGE_SIZES = [10, 20, 50, 100];
const SORTABLE = trc({ date: "تاریخ ثبت", patient: "نام مریض", type: "نوع سند", doctor: "نام داکتر", status: "وضعیت" });

const faNum = (n) => Number(n || 0).toLocaleString(numLocale());
const fmtDate = (v) => jdate(v);
const fmtTime = (v) => (v ? new Date(v).toLocaleTimeString(numLocale(), { hour: "2-digit", minute: "2-digit" }) : "");

function ageOf(dob) {
  if (!dob) return "";
  const d = new Date(dob);
  if (Number.isNaN(d.getTime())) return "";
  const years = Math.floor((Date.now() - d.getTime()) / (365.25 * 24 * 3600 * 1000));
  return years >= 0 ? tr("{0} سال", [faNum(years)]) : "";
}

function useDebounced(value, delay = 400) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

function StatusBadge({ status }) {
  if (!STATUS_LABEL[status]) return <span className="rxp-muted">—</span>;
  const cls = BASE_BADGES.includes(status) ? `rxp-badge-${status}` : `mdoc-badge-${status}`;
  return <span className={`rxp-badge ${cls}`}>{STATUS_LABEL[status]}</span>;
}

function TypeBadge({ type }) {
  const t = TYPES[type];
  if (!t) return null;
  return (
    <span className="mdoc-type">
      <span className={`mdoc-type-icon mdoc-type-${t.tone}`}><t.Icon size={16} /></span>
      {t.label}
    </span>
  );
}

// صفحه‌های اطراف صفحه‌ی جاری (مثلاً 1 … 4 5 [6] 7 8 … 20)
function pageWindow(current, total) {
  const set = new Set([1, total, current - 1, current, current + 1]);
  const list = [...set].filter((p) => p >= 1 && p <= total).sort((a, b) => a - b);
  const out = [];
  list.forEach((p, i) => {
    if (i > 0 && p - list[i - 1] > 1) out.push("gap");
    out.push(p);
  });
  return out;
}

function KV({ label, value, wide }) {
  if (value === null || value === undefined || value === "") return null;
  return <div className={wide ? "wide" : undefined}><span>{label}</span><b>{value}</b></div>;
}

function TextSection({ title, text }) {
  if (!text || !String(text).trim()) return null;
  return <section className="mdoc-section"><h4>{title}</h4><p>{text}</p></section>;
}

// ---------- پنل جزئیات ----------
function DetailPanel({ role, basePath, selected, onClose, onDownload, onChangeStatus }) {
  const [state, setState] = useState({ loading: true, error: "", data: null });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setState({ loading: true, error: "", data: null });
    apiRequest(`${basePath}/${selected.docType}/${selected.id}`)
      .then((data) => { if (!cancelled) setState({ loading: false, error: "", data }); })
      .catch((err) => { if (!cancelled) setState({ loading: false, error: err.message, data: null }); });
    return () => { cancelled = true; };
  }, [basePath, selected.docType, selected.id, tick]);

  const { loading, error, data } = state;
  const doc = data?.document;
  const perm = data?.permissions || {};
  const t = TYPES[selected.docType];
  const patient = doc?.patient;

  return (
    <aside className="mdoc-panel glass" aria-label={tr("جزئیات سند")}>
      <div className="mdoc-panel-head">
        <h3><t.Icon size={18} />{" "}{tr("جزئیات سند")}</h3>
        <button type="button" className="rxp-icon-btn" onClick={onClose} aria-label={tr("بستن")}><X size={16} /></button>
      </div>

      <div className="mdoc-panel-body">
        {loading && (
          <div className="rxp-detail-loading" aria-busy="true">
            <span className="rxp-skeleton rxp-skeleton-block tall" />
            <span className="rxp-skeleton rxp-skeleton-block" />
            <span className="rxp-skeleton rxp-skeleton-block" />
          </div>
        )}

        {error && (
          <div className="rxp-state rxp-state-error" role="alert">
            <AlertTriangle size={30} />
            <h4>{tr("بارگذاری جزئیات ناموفق بود")}</h4>
            <p>{error}</p>
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setTick((n) => n + 1)}>{tr("تلاش دوباره")}</button>
          </div>
        )}

        {doc && (
          <>
            <div className="mdoc-person">
              <span className="mdoc-avatar">{(patient?.fullName || "؟").trim().charAt(0)}</span>
              <div>
                <b>{patient?.fullName || "—"}</b>
                <small>{[patient?.publicCode, patient?.phone].filter(Boolean).join(" • ")}</small>
              </div>
            </div>

            <div className="mdoc-kv">
              <KV label={tr("شماره سند")} value={doc.docNumber} />
              <KV label={tr("نوع سند")} value={t.label} />
              <KV label={tr("جنسیت")} value={GENDER_LABEL[patient?.gender]} />
              <KV label={tr("سن")} value={ageOf(patient?.dateOfBirth)} />
              <KV label={tr("داکتر ثبت‌کننده")} value={doc.doctor?.name} />
              <KV label={tr("بخش / تخصص")} value={doc.doctor?.department} />
              <KV label={tr("تاریخ ثبت")} value={`${fmtDate(doc.createdAt)} ${fmtTime(doc.createdAt)}`.trim()} />
              <div><span>{tr("وضعیت")}</span><b><StatusBadge status={doc.status} /></b></div>
            </div>

            {doc.type === "prescription" && (
              <>
                <TextSection title={tr("تشخیص")} text={doc.diagnosis} />
                <section className="mdoc-section">
                  <h4>{tr("داروها ({0})", [faNum(doc.items.length)])}</h4>
                  <table className="mdoc-items">
                    <thead><tr><th>{tr("دارو")}</th><th>{tr("دوز")}</th><th>{tr("تعداد")}</th><th>{tr("مدت")}</th></tr></thead>
                    <tbody>
                      {doc.items.map((it) => (
                        <tr key={it.id}>
                          <td>
                            <b>{it.medicationName}</b>
                            {it.frequency && <small className="rxp-sub">{it.frequency}</small>}
                            {it.medicineNotes && <small className="rxp-sub">{it.medicineNotes}</small>}
                          </td>
                          <td>{it.dosage || "—"}</td>
                          <td>{it.quantity || "—"}</td>
                          <td>{it.duration || "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </section>
                <TextSection title={tr("دستور مصرف")} text={doc.instructions} />
                <TextSection title={tr("توضیحات داکتر")} text={doc.notes} />
                {doc.followUpDate && <div className="mdoc-kv"><KV label={tr("تاریخ پیگیری")} value={fmtDate(doc.followUpDate)} wide /></div>}
              </>
            )}

            {doc.type === "record" && (
              <>
                <div className="mdoc-kv">
                  <KV label={tr("تاریخ مراجعه")} value={doc.visitDate ? fmtDate(doc.visitDate) : ""} />
                  <KV label={tr("دلیل مراجعه")} value={doc.visitReason} />
                  <KV label={tr("فشار خون")} value={doc.vitals.bloodPressure} />
                  <KV label={tr("نبض")} value={doc.vitals.pulse} />
                  <KV label={tr("دمای بدن")} value={doc.vitals.temperature} />
                  <KV label={tr("تنفس")} value={doc.vitals.respiratoryRate} />
                  <KV label={tr("اشباع اکسیژن")} value={doc.vitals.spo2} />
                  <KV label={tr("قد")} value={doc.vitals.height} />
                  <KV label={tr("وزن")} value={doc.vitals.weight} />
                </div>
                <TextSection title={tr("شکایت اصلی")} text={doc.chiefComplaint} />
                <TextSection title={tr("علائم و شرح حال")} text={doc.symptoms} />
                <TextSection title={tr("یافته‌های معاینه")} text={doc.examFindings} />
                <TextSection title={tr("تشخیص اولیه")} text={doc.primaryDiagnosis} />
                <TextSection title={tr("تشخیص")} text={doc.diagnosis} />
                <TextSection title={tr("توضیحات تشخیص")} text={doc.diagnosisNotes} />
                <TextSection title={tr("درمان")} text={doc.treatment} />
                <TextSection title={tr("یادداشت")} text={doc.notes} />
                {doc.followUpDate && <div className="mdoc-kv"><KV label={tr("تاریخ پیگیری")} value={fmtDate(doc.followUpDate)} wide /></div>}
                {doc.files.length > 0 && (
                  <section className="mdoc-section">
                    <h4>{tr("فایل‌های ضمیمه ({0})", [faNum(doc.files.length)])}</h4>
                    <ul className="mdoc-files">
                      {doc.files.map((f) => (
                        <li key={f.id}>
                          <span>{f.title || f.originalName}</span>
                          <button type="button" className="rxp-icon-btn" title={tr("مشاهده فایل")} aria-label={tr("مشاهده فایل")} onClick={() => onDownload(`/medical-records/files/${f.id}`, f.originalName, { openInNewTab: true })}>
                            <Eye size={15} />
                          </button>
                        </li>
                      ))}
                    </ul>
                  </section>
                )}
              </>
            )}

            {doc.type === "lab" && (
              <>
                <div className="mdoc-kv">
                  <KV label={tr("نام آزمایش")} value={doc.testName} wide />
                  <KV label={tr("نتیجه")} value={[doc.result, doc.unit].filter(Boolean).join(" ")} />
                  <KV label={tr("محدوده‌ی مرجع")} value={doc.referenceRange} />
                  <KV label={tr("تاریخ آزمایش")} value={doc.testDate ? fmtDate(doc.testDate) : ""} />
                </div>
              </>
            )}

            {doc.type === "imaging" && (
              <>
                <div className="mdoc-kv">
                  <KV label={tr("نوع تصویربرداری")} value={doc.examType} wide />
                  <KV label={tr("تاریخ معاینه")} value={doc.examDate ? fmtDate(doc.examDate) : ""} />
                </div>
                <TextSection title={tr("یافته‌ها")} text={doc.findings} />
                <TextSection title={tr("نتیجه‌گیری")} text={doc.impression} />
              </>
            )}
          </>
        )}
      </div>

      {doc && (perm.pdf || perm.labReport || (role === "admin" && doc.type === "prescription")) && (
        <div className="mdoc-panel-actions">
          {perm.pdf && (
            <>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => onDownload(`/medical-records/prescriptions/${doc.id}/pdf`, `prescription-${doc.id}.pdf`, { print: true })}>
                <Printer size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("چاپ")}</button>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => onDownload(`/medical-records/prescriptions/${doc.id}/pdf`, `prescription-${doc.id}.pdf`, { openInNewTab: true })}>
                <Download size={14} style={{ verticalAlign: "-2px" }} /> PDF
              </button>
            </>
          )}
          {perm.labReport && (
            <button type="button" className="btn btn-primary btn-sm" onClick={() => onDownload(`/medical-records/lab-results/${doc.id}/report`, `lab-${doc.id}`, { openInNewTab: true })}>
              <Download size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("دریافت گزارش آزمایش")}</button>
          )}
          {role === "admin" && doc.type === "prescription" && (
            <>
              {doc.status !== "completed" && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={async () => { if (await onChangeStatus(doc, "completed")) setTick((n) => n + 1); }}>
                  <CheckCircle2 size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("تکمیل‌شده")}</button>
              )}
              {doc.status !== "active" && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={async () => { if (await onChangeStatus(doc, "active")) setTick((n) => n + 1); }}>
                  <Clock size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("در حال اجرا")}</button>
              )}
              {doc.status !== "cancelled" && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={async () => { if (await onChangeStatus(doc, "cancelled")) setTick((n) => n + 1); }}>
                  <XCircle size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("لغو نسخه")}</button>
              )}
            </>
          )}
        </div>
      )}
    </aside>
  );
}

// ---------- پنل اصلی ----------
export default function MedicalDocumentsPanel({ role = "admin", onNewPrescription }) {
  const isAdmin = role === "admin";
  const basePath = isAdmin ? "/admin/medical-documents" : "/doctors/me/medical-documents";

  const [search, setSearch] = useState("");
  const [filters, setFilters] = useState(EMPTY_FILTERS);
  const [sort, setSort] = useState({ key: "date", order: "desc" });
  const [page, setPage] = useState(1);
  const [limit, setLimit] = useState(10);
  const [items, setItems] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [stats, setStats] = useState(null);
  const [statsError, setStatsError] = useState(false);
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [selected, setSelected] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [reloadTick, setReloadTick] = useState(0);
  const { toasts, showToast, dismissToast } = useDepartmentToasts();

  const debouncedSearch = useDebounced(search);
  const hasFilters = Boolean(search || Object.values(filters).some(Boolean));

  // با تغییر جستجو/فیلتر/مرتب‌سازی/اندازه‌ی صفحه به صفحه‌ی اول برمی‌گردیم
  useEffect(() => setPage(1), [debouncedSearch, filters, sort, limit]);

  // گزینه‌های فیلتر داکتر (فقط ادمین؛ برای داکتر فهرست خودکار فقط اسناد بیماران خودش است)
  useEffect(() => {
    if (!isAdmin) return;
    apiRequest("/admin/doctors").then((d) => setDoctors(d.doctors || [])).catch(() => {});
  }, [isAdmin]);

  // فهرست — درخواست‌های قدیمی‌تر که دیر برسند نادیده گرفته می‌شوند
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError("");
    const usp = new URLSearchParams({ page, limit, sort: sort.key, order: sort.order });
    if (debouncedSearch.trim()) usp.set("q", debouncedSearch.trim());
    Object.entries(filters).forEach(([k, v]) => { if (v && (isAdmin || k !== "doctorId")) usp.set(k, v); });
    apiRequest(`${basePath}?${usp.toString()}`)
      .then((data) => {
        if (cancelled) return;
        setItems(data.documents || []);
        setPagination(data.pagination || null);
      })
      .catch((err) => { if (!cancelled) setError(err.message); })
      .finally(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [basePath, isAdmin, debouncedSearch, filters, sort, page, limit, reloadTick]);

  // آمار کارت‌ها
  useEffect(() => {
    setStatsError(false);
    apiRequest(`${basePath}/stats`)
      .then((d) => setStats(d.stats))
      .catch(() => setStatsError(true));
  }, [basePath, reloadTick]);

  function setFilter(key, value) { setFilters((f) => ({ ...f, [key]: value })); }
  function clearAll() { setSearch(""); setFilters(EMPTY_FILTERS); }
  function toggleSort(key) {
    setSort((cur) => (cur.key === key ? { key, order: cur.order === "asc" ? "desc" : "asc" } : { key, order: key === "date" ? "desc" : "asc" }));
  }

  async function download(path, fileName, options, busyKey) {
    setBusyId(busyKey || path);
    try {
      await apiDownload(path, fileName, options);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      setBusyId(null);
    }
  }
  const rowDownload = (row, options) => {
    if (row.docType === "prescription") {
      return download(`/medical-records/prescriptions/${row.id}/pdf`, `prescription-${row.id}.pdf`, options, `${options.print ? "print" : "dl"}-${row.docType}-${row.id}`);
    }
    return download(`/medical-records/lab-results/${row.id}/report`, `lab-${row.id}`, options, `dl-${row.docType}-${row.id}`);
  };

  // تغییر وضعیت نسخه (فقط ادمین) — همان مسیر موجود PUT /admin/prescriptions/:id/status
  async function changeStatus(doc, status) {
    const confirmText = {
      cancelled: tr("نسخه {0} لغو شود؟ نسخه حذف نمی‌شود و فقط وضعیت آن «لغوشده» می‌شود.", [doc.docNumber]),
      completed: tr("نسخه {0} به‌عنوان «تکمیل‌شده» ثبت شود؟", [doc.docNumber]),
    }[status];
    if (confirmText && !window.confirm(confirmText)) return false;
    try {
      const res = await apiRequest(`/admin/prescriptions/${doc.id}/status`, { method: "PUT", body: { status } });
      showToast(res.message || tr("وضعیت نسخه تغییر کرد"), "success");
      setReloadTick((n) => n + 1);
      return true;
    } catch (err) {
      showToast(err.message, "error");
      return false;
    }
  }

  const statCards = useMemo(() => [
    { key: "patients", label: isAdmin ? tr("کل مریضان") : tr("مریضان من"), Icon: Users },
    { key: "record", label: tr("سوابق صحی"), Icon: FileText },
    { key: "prescription", label: tr("نسخه‌ها"), Icon: Pill },
    { key: "lab", label: tr("نتایج آزمایش"), Icon: FlaskConical },
    { key: "imaging", label: tr("تصاویر پزشکی"), Icon: ImageIcon },
  ], [isAdmin]);

  const statusOptions = filters.type === "prescription" ? ["active", "completed", "cancelled"]
    : filters.type === "record" ? ["registered", ...(isAdmin ? [] : ["draft"])]
      : filters.type === "lab" ? ["pending", "completed"]
        : filters.type === "imaging" ? ["registered"]
          : ["active", "completed", "cancelled", "registered", "pending", ...(isAdmin ? [] : ["draft"])];

  const from = pagination && pagination.total > 0 ? (pagination.page - 1) * pagination.limit + 1 : 0;
  const to = pagination ? Math.min(pagination.total, pagination.page * pagination.limit) : 0;
  const sortHead = (k) => (
    <button type="button" className={`mdoc-th-sort ${sort.key === k ? "active" : ""}`} onClick={() => toggleSort(k)} aria-label={tr("مرتب‌سازی بر اساس {0}", [SORTABLE[k]])}>
      {SORTABLE[k]}
      {sort.key === k ? (sort.order === "asc" ? <ArrowUp size={13} /> : <ArrowDown size={13} />) : <ChevronsUpDown size={13} />}
    </button>
  );

  return (
    <div className="rxp mdoc">
      <DepartmentToastContainer toasts={toasts} onDismiss={dismissToast} />

      {/* هدر */}
      <div className="rxp-header glass">
        <div className="rxp-header-main">
          <span className="rxp-header-icon"><ClipboardList size={26} /></span>
          <div>
            <h2>{tr("نسخه و سوابق طبی")}</h2>
            <p>{isAdmin ? tr("مدیریت و مشاهده‌ی تمام نسخه‌ها و سوابق طبی مریضان") : tr("نسخه‌ها و سوابق طبی مریضان شما")}</p>
          </div>
        </div>
        <div className="rxp-header-actions">
          {hasFilters && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>
              <FilterX size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("پاک‌کردن فیلترها")}</button>
          )}
          {!isAdmin && onNewPrescription && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={onNewPrescription}>
              <Plus size={14} style={{ verticalAlign: "-2px" }} />{" "}{tr("نسخه جدید")}</button>
          )}
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setReloadTick((n) => n + 1)} disabled={loading}>
            <RefreshCw size={14} className={loading ? "rxp-spin" : ""} style={{ verticalAlign: "-2px" }} />{" "}{tr("بازخوانی")}</button>
        </div>
      </div>

      {/* کارت‌های آماری */}
      <div className="rxp-stats">
        {statCards.map((c) => (
          <div key={c.key} className={`rxp-stat mdoc-tone-${c.key} glass`}>
            <span className="rxp-stat-icon"><c.Icon size={20} /></span>
            <div>
              <span className="rxp-stat-label">{c.label}</span>
              {stats
                ? <strong>{faNum(stats[c.key])}</strong>
                : statsError ? <strong>—</strong> : <span className="rxp-skeleton rxp-skeleton-num" />}
            </div>
          </div>
        ))}
      </div>

      {/* جستجو و فیلتر */}
      <div className="rxp-toolbar glass">
        <div className="rxp-search">
          <Search size={17} />
          <input
            type="search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={tr("جستجو: نام مریض، شماره پرونده، شماره تماس، شماره سند (مثلاً RX-000012)…")}
            aria-label={tr("جستجوی اسناد طبی")}
            maxLength={100}
          />
          {search && (
            <button type="button" className="rxp-search-clear" onClick={() => setSearch("")} aria-label={tr("پاک‌کردن جستجو")}><X size={15} /></button>
          )}
        </div>
        <div className="rxp-filters">
          <div className="field">
            <label htmlFor="mdoc-f-type">{tr("نوع سند")}</label>
            <select id="mdoc-f-type" value={filters.type} onChange={(e) => setFilters((f) => ({ ...f, type: e.target.value, status: "" }))}>
              <option value="">{tr("همه اسناد")}</option>
              {Object.entries(TYPES).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
            </select>
          </div>
          {isAdmin && (
            <div className="field">
              <label htmlFor="mdoc-f-doctor">{tr("داکتر")}</label>
              <select id="mdoc-f-doctor" value={filters.doctorId} onChange={(e) => setFilter("doctorId", e.target.value)}>
                <option value="">{tr("همه داکتران")}</option>
                {doctors.map((d) => <option key={d.id} value={d.id}>{d.fullName}</option>)}
              </select>
            </div>
          )}
          <div className="field">
            <label htmlFor="mdoc-f-status">{tr("وضعیت")}</label>
            <select id="mdoc-f-status" value={filters.status} onChange={(e) => setFilter("status", e.target.value)}>
              <option value="">{tr("همه وضعیت‌ها")}</option>
              {statusOptions.map((k) => <option key={k} value={k}>{STATUS_LABEL[k]}</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="mdoc-f-from">{tr("از تاریخ")}</label>
            <JalaliDateInput id="mdoc-f-from" value={filters.dateFrom} max={filters.dateTo || undefined} onChange={(e) => setFilter("dateFrom", e.target.value)} />
          </div>
          <div className="field">
            <label htmlFor="mdoc-f-to">{tr("تا تاریخ")}</label>
            <JalaliDateInput id="mdoc-f-to" value={filters.dateTo} min={filters.dateFrom || undefined} onChange={(e) => setFilter("dateTo", e.target.value)} />
          </div>
        </div>
      </div>

      <div className={`mdoc-layout ${selected ? "has-panel" : ""}`}>
        {/* جدول */}
        <div className="rxp-table-card glass">
          {error && (
            <div className="rxp-state rxp-state-error" role="alert">
              <AlertTriangle size={34} />
              <h4>{tr("بارگذاری اسناد ناموفق بود")}</h4>
              <p>{error}</p>
              <button type="button" className="btn btn-primary btn-sm" onClick={() => setReloadTick((n) => n + 1)}>{tr("تلاش دوباره")}</button>
            </div>
          )}

          {!error && (
            <div className="rxp-table-wrap">
              <table className="rxp-table">
                <thead>
                  <tr>
                    <th>#</th>
                    <th>{sortHead("patient")}</th>
                    <th>{tr("شماره پرونده")}</th>
                    <th>{sortHead("type")}</th>
                    <th>{sortHead("doctor")}</th>
                    <th>{sortHead("date")}</th>
                    <th>{sortHead("status")}</th>
                    <th>{tr("عملیات")}</th>
                  </tr>
                </thead>
                <tbody>
                  {loading && items.length === 0 && Array.from({ length: 6 }).map((_, i) => (
                    <tr key={`sk-${i}`} className="rxp-row-skeleton" aria-hidden="true">
                      {Array.from({ length: 8 }).map((__, j) => <td key={j}><span className="rxp-skeleton" /></td>)}
                    </tr>
                  ))}
                  {items.map((row, idx) => {
                    const isSel = selected && selected.docType === row.docType && selected.id === row.id;
                    return (
                      <tr
                        key={`${row.docType}-${row.id}`}
                        className={`rxp-row mdoc-row ${isSel ? "is-selected" : ""} ${loading ? "is-loading" : ""}`}
                        onClick={() => setSelected({ docType: row.docType, id: row.id })}
                      >
                        <td data-label="#">{faNum(from + idx)}</td>
                        <td data-label={tr("نام مریض")}><b>{row.patientName || "—"}</b></td>
                        <td data-label={tr("شماره پرونده")}><span className="rxp-rxnum">{row.patientCode || "—"}</span></td>
                        <td data-label={tr("نوع سند")}>
                          <TypeBadge type={row.docType} />
                          <small className="rxp-sub">{row.docNumber}</small>
                        </td>
                        <td data-label={tr("داکتر")}>{row.doctorName || <span className="rxp-muted">{tr("بدون داکتر")}</span>}</td>
                        <td data-label={tr("تاریخ ثبت")}>{fmtDate(row.docDate)}<span className="mdoc-row-time">{fmtTime(row.docDate)}</span></td>
                        <td data-label={tr("وضعیت")}><StatusBadge status={row.status} /></td>
                        <td data-label={tr("عملیات")} onClick={(e) => e.stopPropagation()}>
                          <div className="rxp-actions">
                            <button type="button" className="rxp-icon-btn rxp-view" title={tr("مشاهده جزئیات")} aria-label={tr("مشاهده جزئیات")} onClick={() => setSelected({ docType: row.docType, id: row.id })}><Eye size={16} /></button>
                            {row.canDownload && row.docType === "prescription" && (
                              <button type="button" className="rxp-icon-btn" title={tr("چاپ")} aria-label={tr("چاپ")} disabled={busyId === `print-${row.docType}-${row.id}`} onClick={() => rowDownload(row, { print: true })}><Printer size={16} /></button>
                            )}
                            {row.canDownload && (
                              <button type="button" className="rxp-icon-btn" title={row.docType === "lab" ? tr("دریافت گزارش") : tr("دانلود PDF")} aria-label={tr("دریافت فایل")} disabled={busyId === `dl-${row.docType}-${row.id}`} onClick={() => rowDownload(row, { openInNewTab: true })}><Download size={16} /></button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {!loading && items.length === 0 && (
                <div className="rxp-state">
                  <ClipboardList size={38} />
                  <h4>{hasFilters ? tr("سندی با این مشخصات یافت نشد") : tr("هنوز سندی ثبت نشده است")}</h4>
                  <p>{hasFilters ? tr("جستجو یا فیلترها را تغییر دهید.") : tr("نسخه‌ها و سوابق طبی ثبت‌شده در این فهرست نمایش داده می‌شوند.")}</p>
                  {hasFilters && <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>{tr("پاک‌کردن فیلترها")}</button>}
                </div>
              )}
            </div>
          )}

          {!error && pagination && (
            <div className="mdoc-footer">
              <span className="mdoc-footer-info">
                {pagination.total > 0
                  ? tr("نمایش {0} تا {1} از {2} رکورد", [faNum(from), faNum(to), faNum(pagination.total)])
                  : tr("۰ رکورد")}
                {hasFilters && stats ? tr(" (کل اسناد: {0})", [faNum(stats.total)]) : ""}
              </span>
              <div className="mdoc-pages" role="navigation" aria-label={tr("صفحه‌بندی")}>
                <button type="button" className="mdoc-page-btn" disabled={page <= 1 || loading} onClick={() => setPage(page - 1)} aria-label={tr("صفحه قبل")}>{tr("قبلی")}</button>
                {pageWindow(pagination.page, pagination.totalPages).map((p, i) => (p === "gap"
                  ? <span key={`g${i}`} className="rxp-muted">…</span>
                  : <button key={p} type="button" className={`mdoc-page-btn ${p === pagination.page ? "active" : ""}`} disabled={loading} onClick={() => setPage(p)} aria-current={p === pagination.page ? "page" : undefined}>{faNum(p)}</button>))}
                <button type="button" className="mdoc-page-btn" disabled={page >= pagination.totalPages || loading} onClick={() => setPage(page + 1)} aria-label={tr("صفحه بعد")}>{tr("بعدی")}</button>
              </div>
              <label className="mdoc-page-size">{tr("تعداد در صفحه")}<select value={limit} onChange={(e) => setLimit(Number(e.target.value))}>
                  {PAGE_SIZES.map((n) => <option key={n} value={n}>{faNum(n)}</option>)}
                </select>
              </label>
            </div>
          )}
        </div>

        {selected && (
          <>
            <div className="mdoc-backdrop" onClick={() => setSelected(null)} aria-hidden="true" />
            <DetailPanel
              role={role}
              basePath={basePath}
              selected={selected}
              onClose={() => setSelected(null)}
              onDownload={(path, name, options) => download(path, name, options)}
              onChangeStatus={changeStatus}
            />
          </>
        )}
      </div>
    </div>
  );
}

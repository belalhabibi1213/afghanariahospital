import { useEffect, useMemo, useState } from "react";
import { CalendarCheck, ChevronDown, ChevronUp, Star } from "lucide-react";
import usePublicDoctors from "./doctors/usePublicDoctors.js";
import "./doctors/Doctors.css";
import "./departments/Departments.css"; // دکمه‌ی «نمایش بیشتر» (dpt-more) مشترک با بخش خدمات
import { resolvePhotoUrl } from "../utils/api.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { ensureAuthenticated } from "../utils/authGuard.js";

// مقدار داخلی تب «همه» — به متن ترجمه‌شده وابسته نیست تا با عوض‌شدن زبان فیلتر به‌هم نریزد
const ALL = "__all__";
// مثل بخش «خدمات»: در هر نما حداکثر این تعداد کارت (دو ردیف ۴تایی) نمایش داده می‌شود؛ بقیه با دکمه‌ی «نمایش بیشتر»
const DOCTORS_LIMIT = 8;

export function DoctorPhoto({ doctor }) {
  const [broken, setBroken] = useState(false);
  const { t } = useLanguage();
  const initials = (doctor.fullName || "؟").replace("داکتر", "").replace("ه", "").trim().charAt(0) || t("doctors.initialFallback");
  // عکس آپلودشده توسط ادمین به‌صورت مسیر نسبی (مثل /uploads/doctors/xxx.jpg) از سرور برمی‌گردد؛
  // باید با resolvePhotoUrl به آدرس کامل سرور بک‌اند تبدیل شود، وگرنه مرورگر آن را نسبت به
  // آدرس خودِ فرانت‌اند (پورت/دامنه‌ی دیگر) جستجو می‌کند و همیشه شکست می‌خورد — دقیقاً همان
  // چیزی که باعث می‌شد تغییر عکس داکتر توسط ادمین در سایت اصلی نمایش داده نشود.
  // فقط عکسی که ادمین خودش آپلود کرده (/uploads/...) نمایش داده می‌شود؛ بدون آن، حرف اول نام داکتر.
  const src = doctor.photoUrl && String(doctor.photoUrl).startsWith("/uploads/") ? resolvePhotoUrl(doctor.photoUrl) : null;

  if (broken || !src) {
    return (
      <div className="doctor-avatar-fallback">
        <span>{initials}</span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={doctor.fullName}
      loading="lazy"
      onError={() => setBroken(true)}
    />
  );
}

export default function Doctors() {
  const { isAuthenticated } = useAuth();
  const { t, formatNumber, dept, days, docName } = useLanguage();
  const { doctors, status } = usePublicDoctors();
  const [activeDept, setActiveDept] = useState(ALL);
  const [expanded, setExpanded] = useState(false);

  // جستجوی هیرو (HeroSearch) فقط با انتخاب بخش، همین فیلتر را روی این بخش اعمال می‌کند
  useEffect(() => {
    function onFilter(e) {
      const department = e.detail?.department;
      setActiveDept(department ? department : ALL);
    }
    window.addEventListener("shafakhana:filter-department", onFilter);
    return () => window.removeEventListener("shafakhana:filter-department", onFilter);
  }, []);

  const departments = useMemo(
    () => [ALL, ...new Set(doctors.map((d) => d.department).filter(Boolean))],
    [doctors]
  );

  // در حالت «همه» به‌جای نمایش شلوغ و تکراری همه‌ی داکتران هر بخش، فقط یک کارت
  // نماینده از هر بخش نشان داده می‌شود (بهترین امتیاز آن بخش) — دقیقاً مثل سایت‌های
  // حرفه‌ای که در نمای کلی یک نمونه از هر تخصص را معرفی می‌کنند، نه فهرست کامل.
  // با کلیک روی یک بخش خاص (مثلاً «اطفال»)، همان رفتار قبلی حفظ می‌شود: تمام
  // داکتران آن بخش نمایش داده می‌شوند — منطق فیلتر قبلی دست‌نخورده باقی می‌ماند.
  const representativeDoctors = useMemo(() => {
    const bestByDept = new Map();
    for (const d of doctors) {
      if (!d.department) continue;
      const current = bestByDept.get(d.department);
      const rating = d.rating != null ? Number(d.rating) : 0;
      const currentRating = current ? (current.rating != null ? Number(current.rating) : 0) : -1;
      if (!current || rating > currentRating) {
        bestByDept.set(d.department, d);
      }
    }
    return Array.from(bestByDept.values());
  }, [doctors]);

  const filtered = useMemo(
    () => (activeDept === ALL ? representativeDoctors : doctors.filter((d) => d.department === activeDept)),
    [doctors, representativeDoctors, activeDept]
  );

  // با عوض‌شدن فیلتر بخش، فهرست دوباره به حالت جمع‌شده (دو ردیف) برمی‌گردد
  useEffect(() => {
    setExpanded(false);
  }, [activeDept]);

  const hasMore = filtered.length > DOCTORS_LIMIT;
  const shown = expanded ? filtered : filtered.slice(0, DOCTORS_LIMIT);

  return (
    <section id="doctors" className="pub-section dr">
      <div className="container">
        <div className="pub-head">
          <div className="pub-head-text">
            <span className="pub-eyebrow">{t("doctors.eyebrow")}</span>
            <h2>{t("doctors.title")}</h2>
            <p>
              {status === "ok" && doctors.length > 0
                ? t("doctors.subtitleCount", { count: formatNumber(doctors.length) })
                : t("doctors.subtitle")}
            </p>
          </div>
        </div>

        {status === "loading" && <p className="pub-state" role="status">{t("doctors.loading")}</p>}
        {status === "error" && <p className="pub-state" role="alert">{t("common.serverUnreachableDb")}</p>}
        {status === "ok" && doctors.length === 0 && <p className="pub-state">{t("doctors.empty")}</p>}

        {status === "ok" && doctors.length > 0 && (
          <>
            <div className="dr-tabs" role="tablist" aria-label={t("doctors.eyebrow")}>
              {departments.map((dep) => (
                <button
                  key={dep}
                  type="button"
                  role="tab"
                  aria-selected={activeDept === dep}
                  className={`dr-tab${activeDept === dep ? " active" : ""}`}
                  onClick={() => setActiveDept(dep)}
                >
                  {dep === ALL ? t("doctors.all") : dept(dep)}
                </button>
              ))}
            </div>

            <ul className="dr-track">
              {shown.map((d) => {
                // امتیاز فقط وقتی نمایش داده می‌شود که در پایگاه‌داده واقعاً ثبت شده باشد
                const rating = d.rating != null && Number(d.rating) > 0 ? Number(d.rating) : null;
                const workDays = d.workDays ? days(d.workDays) : t("doctors.defaultWorkDays");
                const years = d.yearsExperience != null ? d.yearsExperience : null;
                return (
                  <li className="dr-item" key={d.id}>
                    <article className="dr-card pub-card">
                      <div className="dr-photo">
                        <DoctorPhoto doctor={d} />
                      </div>
                      <div className="dr-body">
                        <h3>{docName(d.fullName)}</h3>
                        <span className="dr-role">{dept(d.department)}</span>
                        <ul className="dr-facts">
                          {years != null && <li>{t("doctors.experience", { years })}</li>}
                          <li>{t("doctors.workDays", { days: workDays })}</li>
                          {rating != null && (
                            <li className="dr-rating">
                              <Star size={14} fill="currentColor" aria-hidden="true" />
                              {t("doctors.rating", { value: rating.toFixed(1) })}
                            </li>
                          )}
                        </ul>
                        <a
                          href="#appointment"
                          className="pub-btn pub-btn--primary pub-btn--block dr-book"
                          onClick={(e) => {
                            // مهمان‌ها اجازه‌ی گرفتن نوبت ندارند؛ به‌جای رفتن به فورمه نوبت‌دهی،
                            // مودال «ورود الزامی است» نمایش داده می‌شود
                            if (!ensureAuthenticated(isAuthenticated)) {
                              e.preventDefault();
                              return;
                            }
                            // ناوبری پیش‌فرض انکر (پرش هش ساده) مسدود می‌شود چون AppointmentSection
                            // خودش، همراه با ثبت مرحله‌ی ویزارد در تاریخچه‌ی مرورگر (برای اینکه دکمه‌ی
                            // Back از مرحله‌های ۲/۳/۴ به‌جای پرش کامل به این صفحه، یک مرحله عقب برود)،
                            // به #appointment می‌رود؛ اگر هر دو ناوبری هم‌زمان انجام شود یک رکورد
                            // اضافی/نادرست در تاریخچه ایجاد می‌شود.
                            e.preventDefault();
                            // بخش تخصصی و داکتر انتخاب‌شده را به فورمه نوبت‌دهی (AppointmentSection) اعلام می‌کند
                            // تا کاربر مجبور به انتخاب دوباره بخش/داکتر نباشد و مستقیم ادامه ثبت نوبت را انجام دهد
                            window.dispatchEvent(
                              new CustomEvent("shafakhana:book-doctor", {
                                detail: { doctorId: d.id, department: d.department },
                              })
                            );
                          }}
                        >
                          <CalendarCheck size={16} aria-hidden="true" />
                          {t("doctors.book")}
                        </a>
                      </div>
                    </article>
                  </li>
                );
              })}
            </ul>

            {hasMore && (
              <div className="dpt-more">
                <button type="button" className="dpt-more-btn" aria-expanded={expanded} onClick={() => setExpanded((v) => !v)}>
                  {expanded ? <ChevronUp className="dpt-more-icon" size={17} aria-hidden="true" /> : <ChevronDown className="dpt-more-icon" size={17} aria-hidden="true" />}
                  <span>{expanded ? t("doctors.showLess") : t("doctors.showMore", { count: formatNumber(filtered.length - DOCTORS_LIMIT) })}</span>
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}

import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate, useNavigationType } from "react-router-dom";
import { API_BASE, authFetch } from "../utils/api.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { ensureAuthenticated, AUTH_REQUIRED_EVENT } from "../utils/authGuard.js";
import { isValidPersianName } from "../utils/persianName.js";
import { readBookingIntent, clearBookingIntent } from "../utils/bookingIntent.js";

import { JalaliDateInput } from "./JalaliDateInput.jsx";
const DOCTORS_URL = `${API_BASE}/doctors`;
const APPOINTMENTS_URL = `${API_BASE}/appointments`;

// تاریخ «امروز» به وقت محلی کاربر (toISOString تاریخ UTC می‌دهد و نزدیک نیمه‌شب یک روز عقب می‌افتد)
function localTodayStr() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

export default function AppointmentSection() {
  const { isAuthenticated } = useAuth();
  const { t, tm, formatDate, digits, dept, docName } = useLanguage();
  const STEP_LABELS = t("appointment.steps");
  const navigate = useNavigate();
  const location = useLocation();
  const navigationType = useNavigationType();
  const [doctors, setDoctors] = useState([]);
  const [loadingDoctors, setLoadingDoctors] = useState(true);

  const [step, setStep] = useState(0);
  const [form, setForm] = useState({
    department: "",
    doctorId: "",
    appointmentDate: "",
    appointmentTime: "",
    fullName: "",
    phone: "",
    email: "",
    notes: "",
  });
  const [status, setStatus] = useState({ type: "", text: "" });
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [queueNumber, setQueueNumber] = useState(null); // شماره‌ی ملاقات (نفر چندم در همان ساعت)

  // ساعت‌های واقعاً قابل‌رزروِ داکتر انتخاب‌شده برای تاریخ انتخاب‌شده (الزام شماره ۵:
  // نمایش ساعت‌های قابل‌رزرو به بیمار — بر اساس برنامه کاری واقعی داکتر، نه فهرست ثابت)
  const [slots, setSlots] = useState([]);
  const [slotsLoading, setSlotsLoading] = useState(false);
  const [slotsMessage, setSlotsMessage] = useState("");

  // هر بار که کاربر با دکمه «مرحله بعد»/کلیک روی «گرفتن نوبت یک داکتر» به مرحله‌ی جدیدی از
  // ویزارد می‌رود، همان مرحله در تاریخچه‌ی مرورگر (history state) هم ثبت می‌شود؛ آدرس تغییر
  // نمی‌کند (همیشه همان #appointment می‌ماند)، فقط یک رکورد state جدید اضافه می‌شود. با این
  // کار دکمه‌ی Back مرورگر (یا «مرحله قبل» که خودش را با navigate(-1) هماهنگ می‌کند) کاربر را
  // یک مرحله به عقبِ ویزارد برمی‌گرداند، نه مستقیم به صفحه‌ای که قبل از ویزارد در آن بود.
  function goToStep(next, hash) {
    setStep(next);
    // آدرس فعلیِ واقعیِ مرورگر خوانده می‌شود (نه location از closure) چون این تابع از داخل
    // شنونده‌ی رویداد «shafakhana:book-doctor» هم صدا زده می‌شود که فقط یک‌بار در mount ثبت
    // شده و ممکن است location قدیمی را در closure نگه داشته باشد. hash فقط وقتی داده می‌شود
    // که لازم است آدرس هم واقعاً تغییر کند (مثلاً میان‌بر «گرفتن نوبت» از بخش داکتران)؛ در حالت
    // عادی (مرحله بعد/قبل داخل ویزارد) همان هش فعلی (#appointment) حفظ می‌شود.
    navigate(`${window.location.pathname}${hash ?? (window.location.hash || "#appointment")}`, { state: { appointmentStep: next } });
  }

  // وقتی خودِ کاربر با دکمه‌ی Back/Forward مرورگر جابه‌جا می‌شود (navigationType === "POP")،
  // مرحله‌ی محلی (step) را با همان چیزی که در تاریخچه ثبت شده هماهنگ می‌کنیم. اگر رکورد
  // تاریخچه‌ی فعلی هیچ appointmentStep ای نداشته باشد (یعنی کاربر از ورودی‌های ویزارد هم عقب‌تر
  // رفته، مثلاً به بخش داکتران قبل از کلیک «گرفتن نوبت»)، ویزارد به مرحله‌ی اول بازنشانی می‌شود.
  useEffect(() => {
    if (navigationType !== "POP") return;
    const s = location.state?.appointmentStep;
    setStep(typeof s === "number" ? s : 0);
  }, [location.state, navigationType]);

  // مهمان (کاربر واردنشده) اجازه ندارد ویزارد چهار مرحله‌ای نوبت‌دهی را ببیند؛ به‌محض
  // رسیدن به این بخش، به‌جای فورمه، مودال «ورود به حساب الزامی است» یک‌بار نمایش داده
  // می‌شود (از طریق همان رویداد سراسری AUTH_REQUIRED_EVENT که LoginRequiredModal در
  // App.jsx به آن گوش می‌دهد).
  const guestPromptedRef = useRef(false);
  useEffect(() => {
    if (!isAuthenticated && !guestPromptedRef.current) {
      guestPromptedRef.current = true;
      window.dispatchEvent(new CustomEvent(AUTH_REQUIRED_EVENT));
    }
    if (isAuthenticated) {
      guestPromptedRef.current = false;
    }
  }, [isAuthenticated]);

  useEffect(() => {
    fetch(DOCTORS_URL)
      .then((res) => res.json())
      .then((data) => setDoctors(data.doctors || []))
      .catch(() => setStatus({ type: "error", text: t("appointment.doctorsFailed") }))
      .finally(() => setLoadingDoctors(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // وقتی کاربر روی دکمه «گرفتن نوبت» یک داکتر مشخص (در بخش داکتران) کلیک می‌کند،
  // بخش تخصصی و همان داکتر از قبل انتخاب می‌شوند و ویزارد مستقیم به مرحله «داکتر و زمان»
  // می‌رود؛ کاربر دیگر لازم نیست بخش/داکتر را دوباره از ابتدا انتخاب کند
  useEffect(() => {
    function handleBookDoctor(e) {
      const { doctorId, department } = e.detail || {};
      if (!doctorId) return;
      setDone(false);
      setStatus({ type: "", text: "" });
      setForm((f) => ({ ...f, department: department || f.department, doctorId: String(doctorId) }));
      goToStep(1, "#appointment");

      // اسکرول دستی و تضمینی به بخش نوبت‌دهی: صرفِ تغییر هش آدرس در goToStep بالا
      // کافی نیست. افکت اسکرول خودکار صفحه‌ی اصلی (Home.jsx) فقط زمانی اجرا می‌شود که
      // مقدار location.hash واقعاً تغییر کند؛ اما چون در طول ویزارد نوبت‌دهی هش همیشه
      // روی «#appointment» نگه داشته می‌شود (برای هماهنگی با دکمه‌ی Back مرورگر)، اگر
      // کاربر قبلاً یک‌بار وارد این بخش شده باشد و با اسکرول دستی به بخش داکتران
      // برگردد، هش از قبل «#appointment» است و با کلیک دوباره تغییر نمی‌کند — در نتیجه
      // فرم پر می‌شود ولی صفحه اسکرول نمی‌شود. این‌جا مستقل از آن افکت، همیشه و
      // به‌صورت تضمینی اسکرول انجام می‌شود.
      setTimeout(() => {
        document.getElementById("appointment")?.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 60);
    }
    window.addEventListener("shafakhana:book-doctor", handleBookDoctor);
    return () => window.removeEventListener("shafakhana:book-doctor", handleBookDoctor);
  }, []);

  // ورود از صفحه‌ی جزئیات بخش («گرفتن وقت ملاقات»): بخش از قبل انتخاب شده است، پس ویزارد مرحله‌ی «انتخاب
  // بخش» را رد می‌کند و مستقیم به مرحله‌ی «انتخاب داکتر» می‌رود (و اگر کاربر روی یک داکتر مشخص زده بود، همان
  // داکتر هم انتخاب می‌شود). مهمان تا وقتی وارد نشده باشد منتظر می‌ماند؛ بعد از ورود همین افکت دوباره اجرا می‌شود.
  useEffect(() => {
    if (!isAuthenticated || loadingDoctors) return;
    const intent = readBookingIntent();
    if (!intent) return;
    clearBookingIntent();
    const deptDoctors = doctors.filter((d) => d.department === intent.department);
    if (deptDoctors.length === 0) return; // بخشی بدون داکتر: کاربر خودش از مرحله‌ی اول انتخاب می‌کند
    const doctorId = intent.doctorId && deptDoctors.some((d) => String(d.id) === intent.doctorId) ? intent.doctorId : "";
    setDone(false);
    setStatus({ type: "", text: "" });
    setForm((f) => ({ ...f, department: intent.department, doctorId, appointmentDate: "", appointmentTime: "" }));
    goToStep(1, "#appointment");
    setTimeout(() => {
      document.getElementById("appointment")?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 160);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAuthenticated, loadingDoctors, doctors]);

  useEffect(() => {
    if (!form.doctorId || !form.appointmentDate) {
      setSlots([]);
      setSlotsMessage("");
      return;
    }
    let cancelled = false;
    setSlotsLoading(true);
    setSlotsMessage("");
    fetch(`${DOCTORS_URL}/${form.doctorId}/availability?date=${form.appointmentDate}`)
      .then((res) => res.json())
      .then((data) => {
        if (cancelled) return;
        if (!data.working) {
          setSlots([]);
          setSlotsMessage(t("appointment.notWorking"));
          return;
        }
        setSlots(data.slots || []);
        if (!(data.slots || []).some((s) => s.available)) {
          setSlotsMessage(t("appointment.noSlots"));
        }
        // اگر ساعت قبلاً انتخاب‌شده دیگر در فهرست جدید موجود/آزاد نیست، پاک می‌شود
        setForm((f) => {
          const stillAvailable = (data.slots || []).some((s) => s.time === f.appointmentTime && s.available);
          return stillAvailable ? f : { ...f, appointmentTime: "" };
        });
      })
      .catch(() => {
        if (!cancelled) setSlotsMessage(t("appointment.slotsFailed"));
      })
      .finally(() => {
        if (!cancelled) setSlotsLoading(false);
      });
    return () => {
      cancelled = true;
    };
      // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [form.doctorId, form.appointmentDate]);

  const departments = useMemo(() => [...new Set(doctors.map((d) => d.department))], [doctors]);
  const filteredDoctors = useMemo(
    () => doctors.filter((d) => d.department === form.department),
    [doctors, form.department]
  );
  const selectedDoctor = useMemo(
    () => doctors.find((d) => String(d.id) === String(form.doctorId)),
    [doctors, form.doctorId]
  );

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function canNext() {
    if (step === 0) return !!form.department;
    if (step === 1) return !!form.doctorId && !!form.appointmentDate && !!form.appointmentTime;
    if (step === 2) return !!form.fullName && isValidPersianName(form.fullName) && !!form.phone;
    return true;
  }

  async function handleSubmit() {
    // محافظت سمت فرانت‌اند (لایه دوم): حتی اگر مهمان بدون کلیک روی دکمه‌های نوبت‌دهی به این
    // فورمه رسیده باشد، تلاش برای ثبت نهایی نوبت باز هم مسدود و مودال ورود نمایش داده می‌شود.
    // محافظت اصلی و قطعی همیشه سمت سرور (middleware requireAuth روی POST /appointments) است.
    if (!ensureAuthenticated(isAuthenticated)) return;

    setStatus({ type: "", text: "" });
    setLoading(true);
    try {
      const res = await authFetch(APPOINTMENTS_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();

      if (!res.ok) {
        setStatus({ type: "error", text: tm(data.message) || t("appointment.submitFailed") });
        return;
      }

      setQueueNumber(data?.appointment?.queueNumber ?? null);
      setDone(true);
    } catch (err) {
      setStatus({
        type: "error",
        text: t("common.serverUnreachable"),
      });
    } finally {
      setLoading(false);
    }
  }

  function resetWizard() {
    setQueueNumber(null);
    setForm({
      department: "", doctorId: "", appointmentDate: "", appointmentTime: "",
      fullName: "", phone: "", email: "", notes: "",
    });
    setStep(0);
    setDone(false);
    setStatus({ type: "", text: "" });
  }

  // مهمان: به‌جای ویزارد چهار مرحله‌ای، فقط یک کارت راهنما با دکمه‌ی ورود/ثبت‌نام نمایش
  // داده می‌شود (مودال سراسری هم به‌صورت خودکار باز شده است — افکت بالا را ببینید).
  if (!isAuthenticated) {
    return (
      <section id="appointment" className="pub-section">
        <div className="container">
          <div className="section-head">
            <span className="pub-eyebrow">{t("appointment.eyebrow")}</span>
            <h2>{t("appointment.title")}</h2>
          </div>
          <div className="wizard-card pub-card">
            <div className="wizard-done">
              <h3>{t("appointment.loginRequired")}</h3>
              <p>{t("appointment.loginRequiredText")}</p>
              <button
                type="button"
                className="pub-btn pub-btn--primary"
                onClick={() => window.dispatchEvent(new CustomEvent(AUTH_REQUIRED_EVENT))}
              >
                {t("appointment.loginRegister")}
              </button>
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="appointment" className="pub-section">
      <div className="container">
        <div className="section-head">
          <span className="pub-eyebrow">{t("appointment.eyebrow")}</span>
          <h2>{t("appointment.title")}</h2>
          <p>{t("appointment.subtitle")}</p>
        </div>

        {loadingDoctors ? (
          <p style={{ textAlign: "center" }}>{t("common.loading")}</p>
        ) : done ? (
          <div className="wizard-card pub-card">
            <div className="wizard-done">
              <div className="wizard-done-icon">✓</div>
              <h3>{t("appointment.doneTitle")}</h3>
              <p>
                {t("appointment.doneText", {
                  doctor: selectedDoctor?.fullName,
                  date: formatDate(form.appointmentDate, { month: "long" }),
                  time: digits(form.appointmentTime),
                })}
              </p>
              {queueNumber && (
                <p className="wizard-done-queue">
                  {t("appointment.queueNumber")}: <b>{digits(String(queueNumber))}</b>
                </p>
              )}
              <p className="wizard-done-hint">{t("appointment.screenshotHint")}</p>
              <button className="pub-btn pub-btn--primary" onClick={resetWizard}>{t("appointment.newBooking")}</button>
            </div>
          </div>
        ) : (
          <div className="wizard-card pub-card">
            <div className="wizard-steps">
              {STEP_LABELS.map((label, i) => (
                <div key={label} className={`wizard-step ${i === step ? "active" : i < step ? "done" : ""}`}>
                  <span className="wizard-step-num">{i < step ? "✓" : i + 1}</span>
                  <span className="wizard-step-label">{label}</span>
                </div>
              ))}
            </div>

            {status.text && <div className={`form-message ${status.type}`}>{status.text}</div>}

            {step === 0 && (
              <div className="wizard-grid-select">
                {departments.map((dep) => (
                  <button
                    key={dep}
                    type="button"
                    className={`wizard-option ${form.department === dep ? "active" : ""}`}
                    onClick={() => update("department", dep)}
                  >
                    {dept(dep)}
                  </button>
                ))}
              </div>
            )}

            {step === 1 && (
              <div className="wizard-form-grid">
                <div className="field" style={{ gridColumn: "1 / -1" }}>
                  <label>{t("appointment.chooseDoctor")}</label>
                  <select value={form.doctorId} onChange={(e) => update("doctorId", e.target.value)}>
                    <option value="">{t("common.select")}</option>
                    {filteredDoctors.map((d) => (
                      <option key={d.id} value={d.id}>{t("appointment.doctorOption", { name: docName(d.fullName), rating: Number(d.rating || 4.5).toFixed(1) })}</option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label>{t("appointment.date")}</label>
                  <JalaliDateInput
                    value={form.appointmentDate}
                    min={localTodayStr()}
                    disabled={!form.doctorId}
                    onChange={(e) => update("appointmentDate", e.target.value)}
                  />
                </div>
                <div className="field">
                  <label>{t("appointment.time")}</label>
                  <select
                    value={form.appointmentTime}
                    onChange={(e) => update("appointmentTime", e.target.value)}
                    disabled={!form.doctorId || !form.appointmentDate || slotsLoading || slots.length === 0}
                  >
                    <option value="">
                      {!form.doctorId || !form.appointmentDate
                        ? t("appointment.pickDoctorDateFirst")
                        : slotsLoading
                        ? t("appointment.loadingSlots")
                        : t("common.select")}
                    </option>
                    {slots.map((s) => (
                      <option key={s.time} value={s.time} disabled={!s.available}>
                        {s.time}
                        {!s.available ? t("appointment.slotFull") : ""}
                      </option>
                    ))}
                  </select>
                  {slotsMessage && <span className="field-error">{slotsMessage}</span>}
                  {!slotsMessage && slots.some((s) => !s.available) && (
                    <span className="field-error">
                      {t("appointment.someSlotsFull")}
                    </span>
                  )}
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="wizard-form-grid">
                <div className="field">
                  <label>{t("appointment.fullName")}</label>
                  <input type="text" placeholder={t("appointment.fullNamePlaceholder")} value={form.fullName} onChange={(e) => update("fullName", e.target.value)} />
                  {form.fullName && !isValidPersianName(form.fullName) && (
                    <span className="field-error">{t("validation.nameInvalid")}</span>
                  )}
                </div>
                <div className="field">
                  <label>{t("appointment.phone")}</label>
                  <input type="tel" placeholder={t("appointment.phonePlaceholder")} value={form.phone} onChange={(e) => update("phone", e.target.value)} />
                </div>
                <div className="field" style={{ gridColumn: "1 / -1" }}>
                  <label>{t("appointment.email")}</label>
                  <input type="email" placeholder={t("appointment.emailPlaceholder")} value={form.email} onChange={(e) => update("email", e.target.value)} />
                </div>
                <div className="field" style={{ gridColumn: "1 / -1" }}>
                  <label>{t("appointment.notes")}</label>
                  <textarea rows="3" placeholder={t("appointment.notesPlaceholder")} value={form.notes} onChange={(e) => update("notes", e.target.value)} />
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="wizard-summary">
                <div className="wizard-summary-row"><span>{t("appointment.summary.department")}</span><b>{dept(form.department)}</b></div>
                <div className="wizard-summary-row"><span>{t("appointment.summary.doctor")}</span><b>{docName(selectedDoctor?.fullName)}</b></div>
                <div className="wizard-summary-row"><span>{t("appointment.summary.dateTime")}</span><b>{formatDate(form.appointmentDate, { month: "long" })} — {digits(form.appointmentTime)}</b></div>
                <div className="wizard-summary-row"><span>{t("appointment.summary.patient")}</span><b>{form.fullName}</b></div>
                <div className="wizard-summary-row"><span>{t("appointment.summary.phone")}</span><b>{form.phone}</b></div>
              </div>
            )}

            <div className="wizard-actions">
              {step > 0 && (
                <button
                  type="button"
                  className="pub-btn pub-btn--ghost"
                  onClick={() => navigate(-1)}
                >
                  {t("appointment.prev")}
                </button>
              )}
              {step < 3 ? (
                <button
                  type="button"
                  className="pub-btn pub-btn--primary"
                  disabled={!canNext()}
                  onClick={() => goToStep(step + 1)}
                >
                  {t("appointment.next")}
                </button>
              ) : (
                <button type="button" className="pub-btn pub-btn--primary" disabled={loading} onClick={handleSubmit}>
                  {loading ? t("appointment.confirming") : t("appointment.confirm")}
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

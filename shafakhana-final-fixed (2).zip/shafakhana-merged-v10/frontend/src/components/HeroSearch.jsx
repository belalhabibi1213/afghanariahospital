import { useMemo, useState } from "react";
import { CalendarCheck, Search } from "lucide-react";
import usePublicDoctors from "./doctors/usePublicDoctors.js";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { ensureAuthenticated } from "../utils/authGuard.js";

// کارت جستجو/نوبت‌دهی هیرو. فقط داده‌ی واقعی GET /api/doctors را به کار می‌برد:
//  • با انتخاب «داکتر» ← همان رویداد سراسری دکمه‌ی «گرفتن نوبت» کارت داکتران (shafakhana:book-doctor)
//    پخش می‌شود و ویزارد نوبت‌دهی مستقیم به مرحله‌ی «داکتر و زمان» می‌رود (مهمان مودال ورود می‌بیند).
//  • فقط با انتخاب «بخش» ← بخش داکتران با همان فیلتر بخش باز می‌شود (رویداد shafakhana:filter-department).
export default function HeroSearch() {
  const { isAuthenticated } = useAuth();
  const { t, dept, docName } = useLanguage();
  const { doctors, status } = usePublicDoctors();
  const [department, setDepartment] = useState("");
  const [doctorId, setDoctorId] = useState("");

  const departments = useMemo(() => [...new Set(doctors.map((d) => d.department).filter(Boolean))], [doctors]);
  const doctorOptions = useMemo(
    () => (department ? doctors.filter((d) => d.department === department) : doctors),
    [doctors, department]
  );

  if (status !== "ok" || doctors.length === 0) return null; // بدون داکتر، فرم بی‌معنی/غیرفعال نشان داده نمی‌شود

  function onDepartment(value) {
    setDepartment(value);
    setDoctorId("");
  }

  function onDoctor(value) {
    setDoctorId(value);
    const picked = doctors.find((d) => String(d.id) === value);
    if (picked) setDepartment(picked.department || "");
  }

  function submit(e) {
    e.preventDefault();
    if (doctorId) {
      if (!ensureAuthenticated(isAuthenticated)) return;
      const picked = doctors.find((d) => String(d.id) === doctorId);
      window.dispatchEvent(
        new CustomEvent("shafakhana:book-doctor", { detail: { doctorId: picked?.id, department: picked?.department } })
      );
      return;
    }
    window.dispatchEvent(new CustomEvent("shafakhana:filter-department", { detail: { department } }));
    document.getElementById("doctors")?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  return (
    <form className="hero-search pub-card" onSubmit={submit} aria-label={t("hero.search.title")}>
      <h2 className="hero-search-title">
        <CalendarCheck size={18} aria-hidden="true" />
        {t("hero.search.title")}
      </h2>
      <div className="hero-search-fields">
        <label className="hero-search-field">
          <span>{t("hero.search.deptLabel")}</span>
          <select value={department} onChange={(e) => onDepartment(e.target.value)}>
            <option value="">{t("hero.search.deptAll")}</option>
            {departments.map((d) => (
              <option key={d} value={d}>{dept(d)}</option>
            ))}
          </select>
        </label>
        <label className="hero-search-field">
          <span>{t("hero.search.doctorLabel")}</span>
          <select value={doctorId} onChange={(e) => onDoctor(e.target.value)}>
            <option value="">{t("hero.search.doctorAny")}</option>
            {doctorOptions.map((d) => (
              <option key={d.id} value={String(d.id)}>{docName(d.fullName)}</option>
            ))}
          </select>
        </label>
        <button type="submit" className="pub-btn pub-btn--primary hero-search-submit">
          {doctorId ? <CalendarCheck size={18} aria-hidden="true" /> : <Search size={18} aria-hidden="true" />}
          {doctorId ? t("hero.book") : t("hero.seeDoctors")}
        </button>
      </div>
    </form>
  );
}

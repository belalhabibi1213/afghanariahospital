import { useEffect, useState } from "react";
import { MessagesSquare, Hospital, Stethoscope } from "lucide-react";
import { photos } from "../data/photos.js";
import { useLanguage } from "../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../i18n/useLocalizedSettings.js";
import { DepartmentLucideIcon, DEPARTMENT_ICONS } from "./dashboard/DepartmentIconPicker.jsx";
import { apiRequest, resolvePhotoUrl } from "../utils/api.js";

// آیکون مورد: «lucide:Name» ← آیکون برداری انتخاب‌شده در داشبورد؛ در غیر این صورت ایموجی/متن ساده
function renderPointIcon(icon) {
  if (typeof icon === "string" && icon.startsWith("lucide:")) {
    const name = icon.slice(7);
    return DEPARTMENT_ICONS[name] ? <DepartmentLucideIcon name={name} size={22} /> : "⭐";
  }
  // آیکن‌های پیش‌فرض (وقتی ادمین چیزی ثبت نکرده): آیکن برداری هماهنگ به‌جای ایموجی
  if (icon === "🩺") return <Stethoscope size={22} strokeWidth={1.8} />;
  if (icon === "🏥") return <Hospital size={22} strokeWidth={1.8} />;
  if (icon === "💬") return <MessagesSquare size={22} strokeWidth={1.8} />;
  return icon;
}

// آیکن/عنوان/متن پیش‌فرض موارد از دیکشنری زبان خوانده می‌شود (about.points.<key>)؛
// اگر ادمین در «مدیریت بخش معرفی» محتوا ذخیره کرده باشد، آن محتوا جایگزین می‌شود.
const POINTS = [
  { key: "team", icon: "🩺" },
  { key: "equipment", icon: "🏥" },
  { key: "online", icon: "💬" },
];

// مقدار یک فیلد چندزبانه برای زبان فعلی؛ در نبودِ آن، دری و بعد هر زبان دیگری که پر باشد
const pickAny = (obj, lang) => {
  const v = obj?.[lang]?.trim();
  if (v) return v;
  return obj?.fa?.trim() || obj?.ps?.trim() || obj?.en?.trim() || "";
};

export default function About() {
  const { settings } = useLocalizedSettings();
  const { t, lang } = useLanguage();
  const [custom, setCustom] = useState(null);

  useEffect(() => {
    let alive = true;
    apiRequest("/settings/about")
      .then((data) => alive && setCustom(data?.about || null))
      .catch(() => {}); // بدون سرور، متن‌های پیش‌فرض نمایش داده می‌شوند
    return () => { alive = false; };
  }, []);

  const hospital = settings.hospitalName;
  const fill = (s) => s.replace(/\{hospital\}/g, hospital);
  // فیلد سرتاسری: اگر ادمین برای همین زبان چیزی نوشته همان، وگرنه متن پیش‌فرض همین زبان
  const field = (name, params) => {
    const own = custom?.[name]?.[lang]?.trim();
    return own ? fill(own) : t(`about.${name}`, params);
  };

  const imageSrc = custom?.imageUrl ? resolvePhotoUrl(custom.imageUrl) : photos.heroBuilding; // تصویر محلی پروژه (بدون وابستگی به URL بیرونی)
  const points = Array.isArray(custom?.points)
    ? custom.points.map((p) => ({ key: p.id, icon: p.icon, title: fill(pickAny(p.title, lang)), text: fill(pickAny(p.text, lang)) }))
    : POINTS.map((p) => ({ key: p.key, icon: p.icon, title: t(`about.points.${p.key}.title`), text: t(`about.points.${p.key}.text`) }));

  return (
    <section id="about" className="pub-section pub-section--alt about">
      <div className="container">
        <div className="about-grid">
          <figure className="about-figure">
            <img src={imageSrc} alt={t("about.imageAlt", { hospital })} loading="lazy" />
          </figure>

          <div className="about-copy">
            <span className="pub-eyebrow">{field("eyebrow", { hospital })}</span>
            <h2>{field("title")}</h2>
            <p className="about-text">{field("text", { hospital })}</p>

            <ul className="about-points">
              {points.map((p) => (
                <li className="about-point" key={p.key}>
                  <span className="pub-icon">{renderPointIcon(p.icon)}</span>
                  <div>
                    <h3>{p.title}</h3>
                    <p>{p.text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

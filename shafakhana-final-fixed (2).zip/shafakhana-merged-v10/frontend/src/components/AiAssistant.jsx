import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { useLanguage } from "../context/LanguageContext.jsx";
import { apiRequest } from "../utils/api.js";
import "./AiAssistant.css";

const MAX_LEN = 800;

// دستیار هوشمند پزشکی — فقط برای بیمار واردشده (نقش user). پاسخ‌ها از POST /api/ai/chat می‌آیند؛
// هشدار اورژانسی و پیشنهاد بخش/داکتر (با دکمه‌ی نوبت) را هم نشان می‌دهد.
export default function AiAssistant() {
  const { user, isAuthenticated } = useAuth();
  const { t, lang, dept, docName } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]); // { role, content, emergency?, suggestion?, error? }
  const [busy, setBusy] = useState(false);
  const [slow, setSlow] = useState(false);
  const idRef = useRef(0);
  const nextId = () => ++idRef.current;
  const listRef = useRef(null);
  const inputRef = useRef(null);

  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [messages, busy, open]);

  // اگر پاسخ بیش از ۷ ثانیه طول کشید، یک پیام دلداری نشان می‌دهیم (سرویس رایگان گاهی شلوغ است)
  useEffect(() => {
    if (!busy) {
      setSlow(false);
      return undefined;
    }
    const timer = setTimeout(() => setSlow(true), 7000);
    return () => clearTimeout(timer);
  }, [busy]);

  useEffect(() => {
    if (open) inputRef.current?.focus();
  }, [open]);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open]);

  if (!isAuthenticated || user?.role !== "user") return null;

  async function send(e) {
    e?.preventDefault();
    const text = input.trim();
    if (!text || busy) return;
    const history = messages.filter((m) => !m.error).map((m) => ({ role: m.role, content: m.content }));
    setMessages((prev) => [...prev, { id: nextId(), role: "user", content: text }]);
    setInput("");
    setBusy(true);
    try {
      const data = await apiRequest("/ai/chat", { method: "POST", body: { message: text, history, lang } });
      setMessages((prev) => [
        ...prev,
        { id: nextId(), role: "assistant", content: data.reply, emergency: !!data.emergency, suggestion: data.suggestion || null },
      ]);
    } catch (err) {
      // پیام دقیق سرور (کلید نامعتبر، شلوغی، ...) نشان داده می‌شود؛ جزئیات فنی فقط در حالت توسعه می‌آید
      let msg =
        err.code === "AI_NOT_CONFIGURED"
          ? t("ai.notConfigured")
          : err.code === "AI_DAILY_LIMIT" || (err.status === 429 && !err.code)
            ? t("ai.limit")
            : err.code === "AI_BUSY" || err.code === "AI_KEY_REJECTED"
              ? err.message
              : t("ai.error");
      if (err.data?.detail) msg += `\n(${err.data.detail})`;
      setMessages((prev) => [...prev, { id: nextId(), role: "assistant", content: msg, error: true }]);
    } finally {
      setBusy(false);
    }
  }

  const removeMsg = (id) => setMessages((prev) => prev.filter((m) => m.id !== id));
  const clearAll = () => setMessages([]);

  function book(doctorId, department) {
    setOpen(false);
    // بدون داکتر مشخص فقط به فورمه‌ی نوبت‌دهی می‌رویم؛ با داکتر، فورمه از قبل پر می‌شود
    const fire = () =>
      doctorId
        ? window.dispatchEvent(new CustomEvent("shafakhana:book-doctor", { detail: { doctorId, department } }))
        : document.getElementById("appointment")?.scrollIntoView({ behavior: "smooth", block: "start" });
    if (location.pathname === "/" || location.pathname === "/home") {
      fire();
    } else {
      navigate("/home#appointment");
      setTimeout(fire, 700);
    }
  }

  return (
    <div className="ai-assistant" data-open={open ? "true" : "false"}>
      {open && (
        <section className="ai-panel" role="dialog" aria-label={t("ai.title")}>
          <header className="ai-head">
            <span className="ai-head-icon" aria-hidden="true">✚</span>
            <div className="ai-head-text">
              <strong>{t("ai.title")}</strong>
              <small>{t("ai.subtitle")}</small>
            </div>
            {messages.length > 0 && (
              <button type="button" className="ai-close ai-clear" onClick={clearAll} aria-label={t("ai.clearAll")} title={t("ai.clearAll")}>
                🗑
              </button>
            )}
            <button type="button" className="ai-close" onClick={() => setOpen(false)} aria-label={t("ai.close")}>
              ✕
            </button>
          </header>

          <div className="ai-messages" ref={listRef} aria-live="polite">
            <div className="ai-msg ai-msg-bot">{t("ai.welcome")}</div>
            {messages.map((m, i) => (
              <div key={i}>
                <div className={`ai-row ${m.role === "user" ? "ai-row-user" : ""}`}>
                <div
                  className={`ai-msg ${m.role === "user" ? "ai-msg-user" : "ai-msg-bot"}${m.emergency ? " is-emergency" : ""}${m.error ? " is-error" : ""}`}
                  dir="auto"
                >
                  {m.content}
                </div>
                <button type="button" className="ai-del" onClick={() => removeMsg(m.id)} aria-label={t("ai.deleteMsg")} title={t("ai.deleteMsg")}>
                  🗑
                </button>
                </div>
                {m.suggestion && (
                  <div className="ai-suggest">
                    <span>
                      {t("ai.suggestDept")} <b>{dept(m.suggestion.department)}</b>
                    </span>
                    <div className="ai-suggest-list">
                      {m.suggestion.doctors.length === 0 && (
                        <button type="button" className="ai-chip" onClick={() => book("", m.suggestion.department)}>
                          {t("ai.book")}
                        </button>
                      )}
                      {m.suggestion.doctors.map((d) => (
                        <button key={d.id} type="button" className="ai-chip" onClick={() => book(d.id, d.department)}>
                          {t("ai.bookWith", { name: docName(d.fullName) })}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}
            {busy && (
              <div className="ai-msg ai-msg-bot ai-typing" aria-label={t("ai.typing")}>
                <i /><i /><i />
                {slow && <span className="ai-slow">{t("ai.slow")}</span>}
              </div>
            )}
          </div>

          <p className="ai-disclaimer">{t("ai.disclaimer")}</p>

          <form className="ai-form" onSubmit={send}>
            <input
              ref={inputRef}
              type="text"
              dir="auto"
              value={input}
              maxLength={MAX_LEN}
              placeholder={t("ai.placeholder")}
              onChange={(e) => setInput(e.target.value)}
              enterKeyHint="send"
              autoComplete="off"
              spellCheck={false}
            />
            <button type="submit" className="btn btn-primary ai-send" disabled={busy || !input.trim()}>
              {t("ai.send")}
            </button>
          </form>
        </section>
      )}

      {/* دکمه‌ی شناور فقط وقتی پنل بسته است دیده می‌شود؛ وقتی باز است، بستن با ✕ بالای پنل (یا کلید Esc) انجام می‌شود */}
      {!open && (
        <button
          type="button"
          className="ai-fab"
          onClick={() => setOpen(true)}
          aria-expanded={false}
          aria-label={t("ai.open")}
          title={t("ai.open")}
        >
          <span aria-hidden="true">🩺</span>
          <span className="ai-fab-label">{t("ai.fabLabel")}</span>
        </button>
      )}
    </div>
  );
}

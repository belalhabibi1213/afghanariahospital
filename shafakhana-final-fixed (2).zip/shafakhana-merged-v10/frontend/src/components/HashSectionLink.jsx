import { Link, useLocation } from "react-router-dom";

// لینک به یک بخش از صفحه‌ی اصلی (مثلاً «#doctors»، «#appointment»). مشکل قبلی:
// این لینک‌ها همیشه یک <a href="#id"> ساده بودند که فقط وقتی کاربر از قبل در
// صفحه‌ی اصلی است درست کار می‌کند — چون href فقط-هش نسبت به آدرس فعلی صفحه
// حل می‌شود، نه نسبت به صفحه‌ی اصلی. برای مثال از داخل جزئیات خبر (/news/12)
// کلیک روی «داکتران» فقط هش آدرس فعلی را به /news/12#doctors تغییر می‌داد و
// هیچ‌جا نمی‌رفت.
//
// راه‌حل: اگر کاربر همین حالا در صفحه‌ی اصلی است، دقیقاً مثل قبل یک انکر ساده
// رندر می‌شود (رفتار فعلی/اسکرول طبیعی مرورگر دست‌نخورده می‌ماند). اگر در
// صفحه‌ی دیگری است، با React Router به «/home#id» می‌رود؛ همان مکانیزم
// موجود در Home.jsx (افکتی که به‌خاطر بازگشت بعد از ورود از قبل وجود داشت) بعد
// از رندر شدن صفحه، به‌صورت نرم به بخش درست اسکرول می‌کند.
export default function HashSectionLink({ hash, className, onClick, children }) {
  const { pathname } = useLocation();
  const isHome = pathname === "/" || pathname === "/home";

  if (isHome) {
    return (
      <a href={hash} className={className} onClick={onClick}>
        {children}
      </a>
    );
  }

  return (
    <Link to={`/home${hash}`} className={className} onClick={onClick}>
      {children}
    </Link>
  );
}

import { memo, useCallback, useMemo } from "react";
import { CategoryIcon } from "./searchIcons.jsx";

// هایلایت‌کردن بخش(های) متن که با عبارت جستجو مطابقت دارند. اگر بک‌اند بازه‌های
// دقیق تطابق را فرستاده باشد (ranges — پشتیبان جستجوی جزئی و فازی/تحمل غلط‌املایی،
// نگاه کنید به backend/utils/fuzzySearch.js) از همان استفاده می‌شود؛ در غیر این
// صورت (سازگاری با نسخه‌های قدیمی‌تر پاسخ) به جستجوی ساده‌ی substring برمی‌گردد.
//
// محاسبه‌ی parts با useMemo کش می‌شود: کارِ برش/ساخت آرایه‌ی JSX فقط وقتی متن/
// عبارت جستجو/بازه‌ها واقعاً تغییر کنند دوباره اجرا می‌شود، نه در هر رندر والد.
function HighlightedText({ text, query, ranges }) {
  const content = useMemo(() => {
    if (!text) return null;

    if (Array.isArray(ranges) && ranges.length > 0) {
      const parts = [];
      let cursor = 0;
      ranges.forEach(([start, end], i) => {
        if (start > cursor) parts.push(<span key={`t-${i}`}>{text.slice(cursor, start)}</span>);
        parts.push(
          <mark key={`m-${i}`} className="search-result-highlight">
            {text.slice(start, end)}
          </mark>
        );
        cursor = end;
      });
      if (cursor < text.length) parts.push(<span key="t-last">{text.slice(cursor)}</span>);
      return parts;
    }

    const term = (query || "").trim();
    if (!term) return text;

    const lower = text.toLowerCase();
    const idx = lower.indexOf(term.toLowerCase());
    if (idx === -1) return text;

    return (
      <>
        {text.slice(0, idx)}
        <mark className="search-result-highlight">{text.slice(idx, idx + term.length)}</mark>
        {text.slice(idx + term.length)}
      </>
    );
  }, [text, query, ranges]);

  return <>{content}</>;
}

// یک ردیف نتیجه‌ی جستجو — قابل استفاده هم داخل SearchDropdown (دسکتاپ/تبلت) و
// هم داخل SearchModal (موبایل). active یعنی این آیتم با کیبورد (فلش بالا/پایین)
// انتخاب شده و باید هایلایت بصری بگیرد.
//
// با React.memo پیچیده شده: در فهرستی با ده‌ها نتیجه، فقط آیتمی که واقعاً active
// آن تغییر کرده (یا داده‌اش عوض شده) باید دوباره رندر شود، نه کل فهرست.
function SearchResultItem({ item, query, active, onSelect, onHoverItem, itemId, id }) {
  // closure ساخت onMouseEnter داخل خودِ این کامپوننت انجام می‌شود (نه در والد
  // SearchCategory) تا onHoverItem پایدار (setActiveId از useState) بدون نیاز
  // به بسته‌بندی هربار در SearchCategory مستقیماً پاس شود؛ این یعنی props
  // SearchResultItem بین رندرهای SearchCategory مرجع پایدار می‌مانند و
  // React.memo واقعاً از رندر دوباره جلوگیری می‌کند.
  const handleMouseEnter = useCallback(() => onHoverItem(itemId), [onHoverItem, itemId]);
  const handleMouseDown = useCallback(
    (e) => {
      // onMouseDown به‌جای onClick تا قبل از blur شدن input اجرا شود
      e.preventDefault();
      onSelect(item);
    },
    [onSelect, item]
  );

  return (
    <li
      id={id}
      role="option"
      aria-selected={active}
      className={`search-result-item${active ? " is-active" : ""}`}
      onMouseEnter={handleMouseEnter}
      onMouseDown={handleMouseDown}
    >
      <span className="search-result-icon">
        <CategoryIcon icon={item.category} />
      </span>
      <span className="search-result-text">
        <span className="search-result-title">
          <HighlightedText text={item.title} query={query} ranges={item.titleHighlight} />
        </span>
        {item.subtitle && (
          <span className="search-result-subtitle">
            <HighlightedText text={item.subtitle} query={query} ranges={item.subtitleHighlight} />
          </span>
        )}
      </span>
      {item.meta && <span className="search-result-meta">{item.meta}</span>}
    </li>
  );
}

export default memo(SearchResultItem);

import { useEffect } from "react";
import SearchBar from "./SearchBar.jsx";
import { CloseIcon } from "./searchIcons.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";

// نسخه‌ی موبایل جستجوی سراسری: به‌جای نوار جستجوی وسط هدر (که در عرض کم جا
// نمی‌شود)، یک آیکن جستجو در هدر نمایش داده می‌شود که این مودال تمام‌صفحه را
// باز می‌کند. از همان SearchBar با variant="modal" استفاده می‌کند تا منطق
// جستجو/کیبورد/انتخاب نتیجه در یک‌جا (SearchBar) بماند و تکرار نشود.
export default function SearchModal({ open, onClose }) {
  const { t } = useLanguage();
  useEffect(() => {
    if (!open) return undefined;
    function handleEscape(e) {
      if (e.key === "Escape") onClose();
    }
    document.addEventListener("keydown", handleEscape);
    return () => document.removeEventListener("keydown", handleEscape);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="search-modal-overlay"
      role="dialog"
      aria-modal="true"
      aria-label={t("search.dialogLabel")}
      onMouseDown={(e) => {
        // کلیک روی فضای تیره‌ی بیرون پنل (در دسکتاپ) جستجو را می‌بندد
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="search-modal-panel">
        <div className="search-modal-header">
          <SearchBar variant="modal" autoFocus onNavigate={onClose} />
          <button type="button" className="search-modal-close" aria-label={t("search.close")} onClick={onClose}>
            <CloseIcon />
          </button>
        </div>
      </div>
    </div>
  );
}

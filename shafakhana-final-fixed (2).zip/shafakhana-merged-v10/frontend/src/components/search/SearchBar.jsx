import { useCallback, useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useGlobalSearch } from "./useGlobalSearch.js";
import SearchDropdown from "./SearchDropdown.jsx";
import { SearchIcon, CloseIcon } from "./searchIcons.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../../i18n/useLocalizedSettings.js";
import { isScrollbarClick } from "../../utils/scrollbarClick.js";

// جستجوی سراسری سایت (نه فقط اخبار) — در وسط هدر دسکتاپ/تبلت نمایش داده می‌شود.
// این کامپوننت state باز/بسته‌بودن dropdown، ناوبری با کیبورد (فلش بالا/پایین،
// Enter، Escape، Tab) و انتخاب نتیجه را مدیریت می‌کند؛ خودِ رندر نتایج به
// SearchDropdown/SearchCategory/SearchResultItem واگذار شده است.
export default function SearchBar({ variant = "desktop", autoFocus = false, onNavigate }) {
  const navigate = useNavigate();
  const { settings } = useLocalizedSettings();
  const { t } = useLanguage();
  const wrapperRef = useRef(null);
  const inputRef = useRef(null);

  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeId, setActiveId] = useState(null);

  const { groups, flatResults, loading, isEmpty, hasQuery, error } = useGlobalSearch(query);

  // بستن dropdown با کلیک بیرون از کامپوننت (همان الگوی UserMenu/NotificationBell)
  useEffect(() => {
    if (variant === "modal") return undefined; // داخل مودال تمام‌صفحه، بستن با کلیک بیرون معنا ندارد
    function handleClickOutside(e) {
      if (isScrollbarClick(e)) return;
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [variant]);

  // وقتی نتایج تغییر می‌کنند، آیتم فعال کیبورد را بازنشانی می‌کن (همیشه اولین آیتم)
  useEffect(() => {
    setActiveId(flatResults.length > 0 ? flatResults[0].id : null);
  }, [flatResults]);

  useEffect(() => {
    if (!autoFocus) return undefined;
    // rAF یک فریم را عقب می‌اندازد تا اجرای focus() بعد از commit شدن DOM/اعمال
    // انیمیشن ورودی مودال باشد (مخصوصاً روی موبایل که focus زودهنگام گاهی نادیده
    // گرفته می‌شود)، و باز شدن کیبورد را هم قابل‌اعتمادتر می‌کند.
    const frame = requestAnimationFrame(() => inputRef.current?.focus());
    return () => cancelAnimationFrame(frame);
  }, [autoFocus]);

  // useCallback: مرجع پایدار برای selectItem/handleKeyDown نگه‌داشته می‌شود تا
  // props پاس‌شده به SearchDropdown/SearchCategory/SearchResultItem (که با
  // React.memo پیچیده شده‌اند) بین رندرها یکسان بماند و رندر دوباره‌ی غیرضروری
  // زیردرخت نتایج جلوگیری شود.
  const selectItem = useCallback(
    (item) => {
      if (!item) return;
      const categoryMeta = groups.find((g) => g.category.key === item.category)?.category;
      setQuery("");
      setOpen(false);
      setActiveId(null);
      if (categoryMeta?.route) {
        navigate(categoryMeta.route);
      }
      onNavigate?.();
      inputRef.current?.blur();
    },
    [groups, navigate, onNavigate]
  );

  const handleKeyDown = useCallback(
    (e) => {
      if (e.key === "ArrowDown") {
        e.preventDefault();
        if (flatResults.length === 0) return;
        const idx = flatResults.findIndex((r) => r.id === activeId);
        const next = flatResults[(idx + 1) % flatResults.length];
        setActiveId(next.id);
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        if (flatResults.length === 0) return;
        const idx = flatResults.findIndex((r) => r.id === activeId);
        const prevIdx = idx <= 0 ? flatResults.length - 1 : idx - 1;
        setActiveId(flatResults[prevIdx].id);
      } else if (e.key === "Enter") {
        // هنگام ترکیب حروف با کیبورد (IME پشتو/دری روی موبایل) Enter فقط تأیید کلمه است
        if (e.nativeEvent?.isComposing || e.keyCode === 229) return;
        e.preventDefault();
        const active = flatResults.find((r) => r.id === activeId) || flatResults[0];
        if (active) selectItem(active);
      } else if (e.key === "Escape") {
        if (open) {
          e.preventDefault();
          setOpen(false);
          setQuery("");
        }
      } else if (e.key === "Tab") {
        setOpen(false);
      }
    },
    [flatResults, activeId, open, selectItem]
  );

  const listboxId = `global-search-listbox-${variant}`;
  const statusId = `global-search-status-${variant}`;

  // متن وضعیت برای screen reader ها (aria-live) — تعداد نتایج/بارگذاری/خطا را
  // اعلام می‌کند بدون این‌که چیزی به‌صورت بصری اضافه شود (سازگار با ساختار موجود).
  let statusMessage = "";
  if (open && hasQuery) {
    if (loading) statusMessage = t("search.searching");
    else if (error) statusMessage = t("search.serverError");
    else if (isEmpty) statusMessage = t("search.noResults", { query });
    else if (flatResults.length > 0) statusMessage = t("search.found", { count: flatResults.length });
  }

  return (
    <div className={`search-bar-wrapper search-bar-${variant}`} ref={wrapperRef}>
      <div className={`search-bar glass${open ? " is-open" : ""}`}>
        <span className="search-bar-icon">
          <SearchIcon />
        </span>
        <input
          ref={inputRef}
          type="text"
          className="search-bar-input"
          dir="auto"
          inputMode="search"
          enterKeyHint="search"
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck={false}
          role="combobox"
          aria-label={t("search.ariaLabel", { hospital: settings.hospitalName })}
          aria-expanded={open}
          aria-controls={listboxId}
          aria-autocomplete="list"
          aria-describedby={statusId}
          aria-activedescendant={activeId ? `${listboxId}-${activeId}` : undefined}
          placeholder={t("search.placeholder")}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          onKeyDown={handleKeyDown}
        />
        <span id={statusId} className="sr-only" role="status" aria-live="polite">
          {statusMessage}
        </span>
        {query && (
          <button
            type="button"
            className="search-bar-clear"
            aria-label={t("search.clear")}
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              setQuery("");
              inputRef.current?.focus();
            }}
          >
            <CloseIcon />
          </button>
        )}
      </div>

      {open && (
        <SearchDropdown
          query={query}
          groups={groups}
          loading={loading}
          isEmpty={isEmpty}
          hasQuery={hasQuery}
          error={error}
          activeId={activeId}
          onSelect={selectItem}
          onHoverItem={setActiveId}
          idPrefix={listboxId}
          listboxId={listboxId}
          variant={variant}
        />
      )}
    </div>
  );
}

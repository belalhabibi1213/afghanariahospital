import { memo } from "react";
import { CategoryIcon } from "./searchIcons.jsx";
import SearchResultItem from "./SearchResultItem.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";

// یک بخش از نتایج جستجو مربوط به یک دسته (داکتران/خدمات/اخبار/...)؛ عنوان دسته
// + فهرست SearchResultItem های همان دسته را رندر می‌کند. activeId برای شاخص‌گذاری
// آیتم فعال هنگام ناوبری با کیبورد در سراسر همه‌ی دسته‌ها استفاده می‌شود.
//
// با React.memo پیچیده شده تا وقتی activeId داخل یک دسته‌ی دیگر تغییر می‌کند
// (و props این دسته عوض نشده)، این دسته و آیتم‌های داخلش دوباره رندر نشوند.
function SearchCategory({ group, query, activeId, onSelect, onHoverItem, idPrefix }) {
  const { category, items } = group;
  const { t } = useLanguage();
  const label = t(`search.categories.${category.key}`);

  return (
    <div className="search-category" role="group" aria-label={label}>
      <div className="search-category-head">
        <CategoryIcon icon={category.icon} />
        <span>{label}</span>
      </div>
      {/* role="presentation" چون role="listbox" واقعی روی کانتینر بیرونی
          (SearchDropdown) قرار دارد؛ این <ul> فقط برای چیدمان بصری است. */}
      <ul className="search-category-list" role="presentation">
        {items.map((item) => (
          <SearchResultItem
            key={item.id}
            id={`${idPrefix}-${item.id}`}
            itemId={item.id}
            item={item}
            query={query}
            active={activeId === item.id}
            onSelect={onSelect}
            onHoverItem={onHoverItem}
          />
        ))}
      </ul>
    </div>
  );
}

export default memo(SearchCategory);

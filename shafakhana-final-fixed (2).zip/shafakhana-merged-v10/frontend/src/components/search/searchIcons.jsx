// آیکن‌های SVG اینلاین مورد استفاده در جستجوی سراسری — بدون وابستگی به هیچ
// پکیج آیکنی (پروژه فعلاً کتابخانه‌ی آیکن ندارد)، هم‌راستا با الگوی SearchIcon
// موجود در Navbar.jsx پیشین.

export function SearchIcon(props) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      <circle cx="11" cy="11" r="7" />
      <line x1="21" y1="21" x2="16.65" y2="16.65" />
    </svg>
  );
}

export function CloseIcon(props) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      <line x1="18" y1="6" x2="6" y2="18" />
      <line x1="6" y1="6" x2="18" y2="18" />
    </svg>
  );
}

export function SpinnerIcon(props) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true" className="search-spinner-icon" {...props}>
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeOpacity="0.2" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

const CATEGORY_PATHS = {
  doctor: (
    <>
      <circle cx="12" cy="8" r="3.4" />
      <path d="M5 20c0-3.6 3.1-6 7-6s7 2.4 7 6" />
      <path d="M12 11v3M10.5 12.5h3" />
    </>
  ),
  service: (
    <>
      <rect x="4" y="4" width="16" height="16" rx="3" />
      <path d="M12 8v8M8 12h8" />
    </>
  ),
  department: (
    <>
      <path d="M4 21V9l8-5 8 5v12" />
      <path d="M9 21v-6h6v6" />
    </>
  ),
  news: (
    <>
      <rect x="3.5" y="4.5" width="17" height="15" rx="2" />
      <path d="M7.5 8.5h9M7.5 12h9M7.5 15.5h5" />
    </>
  ),
  article: (
    <>
      <path d="M6 4h9l3 3v13H6z" />
      <path d="M9 10h6M9 13h6M9 16h3" />
    </>
  ),
  specialty: (
    <>
      <circle cx="12" cy="8" r="5" />
      <path d="M8.5 12.5 7 21l5-2.5L17 21l-1.5-8.5" />
    </>
  ),
  medicine: (
    <>
      <rect x="7" y="3" width="10" height="18" rx="4" transform="rotate(0 12 12)" />
      <path d="M7 12h10" />
    </>
  ),
};

// آیکن مخصوص هر دسته‌ی جستجو (داکتران/خدمات/بخش‌ها/اخبار/مقالات/کلینیک‌ها/ادویه)
export function CategoryIcon({ icon, ...props }) {
  const content = CATEGORY_PATHS[icon] || CATEGORY_PATHS.service;
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" {...props}>
      {content}
    </svg>
  );
}

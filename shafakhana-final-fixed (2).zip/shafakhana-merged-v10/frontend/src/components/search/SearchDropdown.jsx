import { memo } from "react";
import SearchCategory from "./SearchCategory.jsx";
import { SpinnerIcon, SearchIcon } from "./searchIcons.jsx";
import { useLanguage } from "../../context/LanguageContext.jsx";
import { useLocalizedSettings } from "../../i18n/useLocalizedSettings.js";

// پنل کشویی نتایج جستجو — دقیقاً زیر SearchBar باز می‌شود (دسکتاپ/تبلت) یا داخل
// SearchModal به‌صورت تمام‌صفحه (موبایل) قرار می‌گیرد. حالت‌های بارگذاری/خالی/نتایج
// را مدیریت می‌کند؛ ناوبری با کیبورد در SearchBar/SearchModal کنترل می‌شود، این
// کامپوننت فقط بر اساس activeId هایلایت بصری را نشان می‌دهد.
//
// با React.memo پیچیده شده: چون SearchBar در هر رندر (مثلاً هنگام تایپ کاراکتر
// بعدی که هنوز دیبانس نشده) دوباره رندر می‌شود، این جلوی رندر دوباره‌ی کل درخت
// نتایج را می‌گیرد وقتی هیچ‌کدام از props واقعاً تغییر نکرده باشند.
function SearchDropdown({
  query,
  groups,
  loading,
  isEmpty,
  hasQuery,
  error,
  activeId,
  onSelect,
  onHoverItem,
  idPrefix = "search-dropdown",
  listboxId,
  variant = "desktop",
}) {
  const { settings } = useLocalizedSettings();
  const { t } = useLanguage();
  if (!hasQuery) {
    return (
      <div className={`search-dropdown search-dropdown-${variant} is-idle`} id={listboxId} role="listbox">
        <div className="search-dropdown-idle">
          <SearchIcon />
          <p>{t("search.idle", { hospital: settings.hospitalName })}</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className={`search-dropdown search-dropdown-${variant}`}
      id={listboxId}
      role="listbox"
      aria-label={t("search.results")}
      aria-busy={loading}
    >
      {loading && (
        <div className="search-dropdown-loading">
          <SpinnerIcon />
          <span>{t("search.searching")}</span>
        </div>
      )}

      {!loading && error && (
        <div className="search-dropdown-empty">
          <span className="search-dropdown-empty-icon" aria-hidden="true">
            ⚠️
          </span>
          <p>{t("search.serverError")}</p>
          <span>{t("search.tryAgain")}</span>
        </div>
      )}

      {!loading && !error && isEmpty && (
        <div className="search-dropdown-empty">
          <span className="search-dropdown-empty-icon" aria-hidden="true">
            🔍
          </span>
          <p dir="auto">
            {t("search.noResults", { query: "\u0000" })
              .split("\u0000")
              .flatMap((part, i, arr) => (i < arr.length - 1 ? [part, <strong key={i}>{query}</strong>] : [part]))}
          </p>
          <span>{t("search.tryOther")}</span>
        </div>
      )}

      {!loading && !error && !isEmpty && groups.length > 0 && (
        <div className="search-dropdown-results">
          {groups.map((group) => (
            <SearchCategory
              key={group.category.key}
              group={group}
              query={query}
              activeId={activeId}
              onSelect={onSelect}
              onHoverItem={onHoverItem}
              idPrefix={idPrefix}
            />
          ))}
        </div>
      )}
    </div>
  );
}

export default memo(SearchDropdown);

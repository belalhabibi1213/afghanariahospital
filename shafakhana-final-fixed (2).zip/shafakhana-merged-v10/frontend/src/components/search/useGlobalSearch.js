import { useEffect, useMemo, useRef, useState } from "react";
import { apiRequest } from "../../utils/api.js";
import { groupSearchResponse } from "./searchData.js";

const DEBOUNCE_MS = 300; // تایپ رو به جلو (اضافه‌کردن کاراکتر) — همان تاخیر قبلی، برای کاهش فشار روی سرور
const DELETE_DEBOUNCE_MS = 50; // حذف کاراکتر (بک‌اسپیس/دیلیت) — تاخیر ناچیز تا نتایج تقریباً فوری به‌روز شوند
const MIN_QUERY_LENGTH = 2; // با MIN_QUERY_LENGTH بک‌اند (controllers/searchController.js) هماهنگ است

// هوک جستجوی سراسری — به GET /api/search?q=... وصل است (backend/routes/search.js).
// دیبانس روی تایپ کاربر + جلوگیری از race condition (اگر پاسخ یک درخواست قدیمی‌تر
// دیرتر از یک درخواست جدیدتر برسد، نادیده گرفته می‌شود) را مدیریت می‌کند.
//
// وقتی کاربر کاراکتر حذف می‌کند (عبارت کوتاه‌تر از قبل می‌شود)، دیبانس تقریباً صفر
// است تا نتایج فوراً به‌روز شوند؛ دیبانس معمولی فقط هنگام اضافه‌کردن کاراکتر (تایپ
// رو به جلو) اعمال می‌شود تا تعداد درخواست‌های هم‌زمان به سرور محدود بماند.
export function useGlobalSearch(query) {
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const debounceRef = useRef(null);
  const latestRequestId = useRef(0);
  const prevTermRef = useRef("");

  useEffect(() => {
    clearTimeout(debounceRef.current);

    const term = query.trim();
    const isDeletion = term.length < prevTermRef.current.length;
    prevTermRef.current = term;

    if (term.length < MIN_QUERY_LENGTH) {
      latestRequestId.current += 1; // پاسخ هر درخواست در حال پرواز را هم بی‌اثر کن
      setLoading(false);
      setError(null);
      setGroups([]);
      return undefined;
    }

    setLoading(true);
    setError(null);

    debounceRef.current = setTimeout(() => {
      const requestId = ++latestRequestId.current;
      apiRequest(`/search?q=${encodeURIComponent(term)}`)
        .then((data) => {
          if (latestRequestId.current !== requestId) return; // پاسخ قدیمی/منقضی، نادیده گرفته شود
          setGroups(groupSearchResponse(data));
          setLoading(false);
        })
        .catch((err) => {
          if (latestRequestId.current !== requestId) return;
          setError(err);
          setGroups([]);
          setLoading(false);
        });
    }, isDeletion ? DELETE_DEBOUNCE_MS : DEBOUNCE_MS);

    return () => clearTimeout(debounceRef.current);
  }, [query]);

  const flatResults = useMemo(() => groups.flatMap((group) => group.items), [groups]);
  const hasQuery = query.trim().length > 0;
  const isEmpty = hasQuery && !loading && !error && flatResults.length === 0;

  return { groups, flatResults, loading, isEmpty, hasQuery, error };
}

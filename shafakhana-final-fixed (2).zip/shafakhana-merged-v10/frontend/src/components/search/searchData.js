// متادیتای دسته‌های جستجوی سراسری — کلیدها دقیقاً باید با کلیدهای پاسخ
// GET /api/search (backend/controllers/searchController.js) یکی باشند:
// doctors, departments, services, specialties, news, articles, medicines.
// این ماژول دیگر داده‌ی نمایشی (mock) تولید نمی‌کند؛ خودِ جستجو از بک‌اند واقعی
// می‌آید (نگاه کنید به useGlobalSearch.js) و این‌جا فقط برچسب فارسی/آیکن/مسیر
// مقصد هر دسته برای رندر UI نگه‌داری می‌شود.
export const SEARCH_CATEGORIES = {
  doctors: { key: "doctors", label: "داکتران", icon: "doctor", route: "/home#doctors" },
  departments: { key: "departments", label: "بخش‌های شفاخانه", icon: "department", route: "/home#services" },
  services: { key: "services", label: "خدمات", icon: "service", route: "/home#services" },
  specialties: { key: "specialties", label: "تخصص‌های بالینی", icon: "specialty", route: "/home#doctors" },
  news: { key: "news", label: "اخبار", icon: "news", route: "/home#news" },
  articles: { key: "articles", label: "مقالات صحی", icon: "article", route: "/home#news" },
  medicines: { key: "medicines", label: "ادویه", icon: "medicine", route: null },
};

// ترتیب نمایش دسته‌ها در نتایج (وقتی همه‌ی دسته‌ها نتیجه دارند)
export const CATEGORY_ORDER = [
  "doctors",
  "departments",
  "services",
  "specialties",
  "news",
  "articles",
  "medicines",
];

// پاسخ خام GET /api/search را (که یک شیء تخت است: { query, doctors:[...], ... })
// به همان شکل «آرایه‌ی گروه‌بندی‌شده» تبدیل می‌کند که SearchDropdown/SearchCategory
// انتظار دارند: [{ category, items }, ...] — فقط دسته‌هایی که واقعاً نتیجه دارند.
export function groupSearchResponse(data) {
  if (!data) return [];
  return CATEGORY_ORDER.map((key) => ({
    category: SEARCH_CATEGORIES[key],
    // آیتم‌های خام بک‌اند فیلد category ندارند (چون از قبل زیر کلید همان دسته گروه‌بندی
    // شده‌اند)؛ این‌جا اضافه می‌شود تا SearchResultItem/SearchCategory/SearchBar (که به
    // item.category برای آیکن و مسیر مقصد نیاز دارند) بدون تغییر کار کنند.
    // id هم با پیشوند دسته یکتا می‌شود؛ چون id خام فقط داخل جدول خودش یکتاست (مثلاً هم
    // یک داکتر و هم یک دارو می‌توانند id=1 داشته باشند) و ناوبری با کیبورد/React key به
    // یکتایی سراسری id در کل نتایج نیاز دارد.
    items: (Array.isArray(data[key]) ? data[key] : []).map((item) => ({
      ...item,
      recordId: item.id,
      id: `${key}-${item.id}`,
      category: key,
    })),
  })).filter((group) => group.items.length > 0);
}

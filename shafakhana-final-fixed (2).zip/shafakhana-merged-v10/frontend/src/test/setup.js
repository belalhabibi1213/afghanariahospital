import "@testing-library/jest-dom/vitest";
import { afterEach } from "vitest";
import { cleanup } from "@testing-library/react";
import { loadLocale } from "../i18n/locales/registry.js";
import { loadTrDict } from "../i18n/tr.js";

// دیکشنری‌های en/ps در برنامه تنبل بارگذاری می‌شوند؛ در تست‌ها از ابتدا آماده‌اند
await Promise.all([loadLocale("en"), loadLocale("ps"), loadTrDict("en"), loadTrDict("ps")]);

// بعد از هر تست: DOM پاک شود و حافظه‌ی مرورگر (localStorage / sessionStorage) خالی شود
afterEach(() => {
  cleanup();
  localStorage.clear();
  sessionStorage.clear();
});

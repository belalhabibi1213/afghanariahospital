import { render } from "@testing-library/react";
import { MemoryRouter, Routes, Route, useLocation } from "react-router-dom";
import { AuthProvider } from "../context/AuthContext.jsx";

// نمایش مسیر فعلی داخل DOM تا تست‌ها بتوانند هدایت‌ها (redirect) را بررسی کنند
export function LocationProbe() {
  const loc = useLocation();
  return <div data-testid="location">{loc.pathname + loc.search}</div>;
}

// route می‌تواند رشته یا آبجکت location (مثلاً با state.from) باشد
// رندر یک کامپوننت داخل Router + AuthProvider واقعی
export function renderWithProviders(ui, { route = "/", routes } = {}) {
  return render(
    <MemoryRouter initialEntries={[route]}>
      <AuthProvider>
        {routes ? (
          <Routes>{routes}</Routes>
        ) : (
          ui
        )}
        <LocationProbe />
      </AuthProvider>
    </MemoryRouter>
  );
}

export function jsonResponse(status, body) {
  return { ok: status >= 200 && status < 300, status, json: async () => body, clone() { return this; } };
}

export { Route };

import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

// App فقط «منطق دروازه» را تست می‌کنیم (حالت تعمیرات و تغییر رمز اجباری)؛ صفحه‌های سنگین ساختگی‌اند
const stubs = {
  Home: "صفحه خانه", Login: "صفحه ورود", Register: "ثبت نام", VerifyEmail: "تایید ایمیل",
  ForgotPassword: "فراموشی", ResetPassword: "بازنشانی", AccessDenied: "۴۰۳", NewsDetail: "خبر",
  Maintenance: "سایت در حال تعمیر است", ChangePasswordRequired: "تغییر رمز اجباری",
};
for (const [name, text] of Object.entries(stubs)) {
  vi.doMock(`./pages/${name}.jsx`, () => ({ default: () => <div>{text}</div> }));
}
vi.doMock("./components/LoginRequiredModal.jsx", () => ({ default: () => null }));
vi.doMock("./components/LogoutConfirmModal.jsx", () => ({ default: () => null }));
vi.doMock("./components/ScrollToTop.jsx", () => ({ default: () => null }));

let auth;
let settings;
vi.doMock("./context/AuthContext.jsx", () => ({
  useAuth: () => auth,
  AuthProvider: ({ children }) => children,
}));
vi.doMock("./context/SettingsContext.jsx", () => ({ useSiteSettings: () => ({ settings }) }));

async function renderApp(route = "/") {
  vi.resetModules();
  const { default: App } = await import("./App.jsx");
  return render(<MemoryRouter initialEntries={[route]}><App /></MemoryRouter>);
}

const asUser = (user) => ({
  user,
  loading: false,
  isAuthenticated: !!user,
  hasRole: (...roles) => !!user && roles.includes(user.role),
});

beforeEach(() => {
  settings = { maintenanceMode: "off" };
  auth = asUser(null);
});

describe("App — دروازه‌ی تغییر رمز اجباری", () => {
  it("کاربر با mustChangePassword در هر مسیری فقط صفحه‌ی تغییر رمز را می‌بیند", async () => {
    auth = asUser({ id: 1, role: "user", mustChangePassword: true });
    for (const route of ["/", "/home", "/login", "/dashboard/user"]) {
      const { unmount } = await renderApp(route);
      expect(screen.getByText("تغییر رمز اجباری")).toBeInTheDocument();
      expect(screen.queryByText("صفحه خانه")).not.toBeInTheDocument();
      unmount();
    }
  });

  it("بعد از برداشته‌شدن پرچم، مسیر عادی نمایش داده می‌شود", async () => {
    auth = asUser({ id: 1, role: "user", mustChangePassword: false });
    await renderApp("/home");
    expect(await screen.findByText("صفحه خانه")).toBeInTheDocument();
    expect(screen.queryByText("تغییر رمز اجباری")).not.toBeInTheDocument();
  });
});

describe("App — حالت تعمیرات", () => {
  beforeEach(() => { settings = { maintenanceMode: "on" }; });

  it("مهمان و بیمار و داکتر صفحه‌ی تعمیرات را می‌بینند", async () => {
    for (const u of [null, { id: 1, role: "user" }, { id: 2, role: "doctor" }]) {
      auth = asUser(u);
      const { unmount } = await renderApp("/home");
      expect(screen.getByText("سایت در حال تعمیر است")).toBeInTheDocument();
      unmount();
    }
  });

  it("مسیر /login همیشه در دسترس است تا ادمین بتواند وارد شود", async () => {
    await renderApp("/login");
    expect(await screen.findByText("صفحه ورود")).toBeInTheDocument();
  });

  it("ادمین و مدیر کل از قفل مستثنا هستند", async () => {
    for (const role of ["admin", "superadmin"]) {
      auth = asUser({ id: 9, role });
      const { unmount } = await renderApp("/home");
      expect(await screen.findByText("صفحه خانه")).toBeInTheDocument();
      unmount();
    }
  });
});

import { describe, it, expect } from "vitest";
import { getPasswordError, isStrongPassword, PASSWORD_POLICY_MESSAGE } from "./passwordPolicy.js";
import { isValidPersianName } from "./persianName.js";
import { isEmailFormatValid, getEmailError, EMAIL_INVALID_MESSAGE } from "./emailValidation.js";
import { escapeHtml } from "./escapeHtml.js";

describe("passwordPolicy", () => {
  it("رمز خالی را رد می‌کند", () => {
    expect(getPasswordError("")).toBe("رمز عبور الزامی است.");
    expect(getPasswordError(undefined)).toBe("رمز عبور الزامی است.");
  });
  it("رمز کوتاه‌تر از ۸ کاراکتر را رد می‌کند", () => {
    expect(getPasswordError("Ab1!xyz")).toBe(PASSWORD_POLICY_MESSAGE);
  });
  it("دقیقاً ۸ کاراکتر مجاز را می‌پذیرد", () => {
    expect(getPasswordError("Abcdef1!")).toBe("");
    expect(isStrongPassword("Xk9#mP2q")).toBe(true);
  });
  it("حروف فارسی و فاصله را رد می‌کند", () => {
    expect(isStrongPassword("پسورد1234")).toBe(false);
    expect(isStrongPassword("abcd efgh1")).toBe(false);
  });
  it("حداکثر ۷۲ کاراکتر (حد bcrypt)", () => {
    expect(isStrongPassword("aB3$".repeat(18))).toBe(true);
    expect(isStrongPassword("aB3$".repeat(18) + "x")).toBe(false);
  });
  it("رمزهای بسیار رایج را رد می‌کند", () => {
    expect(isStrongPassword("12345678")).toBe(false);
    expect(isStrongPassword("Password123")).toBe(false);
  });
});

describe("persianName", () => {
  it("نام فارسی/دری را می‌پذیرد", () => {
    expect(isValidPersianName("احمد ضیا")).toBe(true);
    expect(isValidPersianName("  پژمان گل‌محمد ")).toBe(true); // نیم‌فاصله
  });
  it("نام پشتو و انگلیسی را می‌پذیرد", () => {
    expect(isValidPersianName("Ahmad")).toBe(true);
    expect(isValidPersianName("Mary-Anne O'Brien")).toBe(true);
    expect(isValidPersianName("ګل ښاغلی ډاکټر ړوند")).toBe(true);
  });
  it("عدد، نماد و رشته‌ی خالی را رد می‌کند", () => {
    expect(isValidPersianName("1234")).toBe(false);
    expect(isValidPersianName("Ahmad_99")).toBe(false);
    expect(isValidPersianName("-.'")).toBe(false);
    expect(isValidPersianName("احمد۱")).toBe(false);
    expect(isValidPersianName("احمد<script>")).toBe(false);
    expect(isValidPersianName("   ")).toBe(false);
    expect(isValidPersianName(null)).toBe(false);
    expect(isValidPersianName(123)).toBe(false);
  });
});

describe("emailValidation", () => {
  it("ایمیل‌های معتبر را می‌پذیرد", () => {
    expect(isEmailFormatValid("belal.dev@example.com")).toBe(true);
    expect(isEmailFormatValid("  user+tag@mail.example.org ")).toBe(true);
    expect(isEmailFormatValid("belal12345@gmail.com")).toBe(true);
  });
  it("فرمت‌های نادرست را رد می‌کند", () => {
    for (const bad of ["", "a", "a@b", "@x.com", "a@.com", "a..b@x.com", "احمد@x.com", "a b@x.com", null, 5]) {
      expect(isEmailFormatValid(bad)).toBe(false);
    }
  });
  it("اشتباهات تایپی رایج دامنه را رد می‌کند", () => {
    expect(isEmailFormatValid("someone@gmial.com")).toBe(false);
    expect(isEmailFormatValid("someone@hotmial.com")).toBe(false);
  });
  it("نام کاربری Gmail کوتاه‌تر از ۶ کاراکتر را رد می‌کند", () => {
    expect(isEmailFormatValid("abc@gmail.com")).toBe(false);
  });
  it("پیام خطا", () => {
    expect(getEmailError("")).toBe("ایمیل الزامی است.");
    expect(getEmailError("bad")).toBe(EMAIL_INVALID_MESSAGE);
    expect(getEmailError("ok.user@example.com")).toBe("");
  });
});

describe("escapeHtml (جلوگیری از XSS در خروجی PDF)", () => {
  it("تگ و نقل‌قول را بی‌اثر می‌کند", () => {
    expect(escapeHtml('<img src=x onerror="alert(1)">')).toBe("&lt;img src=x onerror=&quot;alert(1)&quot;&gt;");
    expect(escapeHtml("a & b 'c'")).toBe("a &amp; b &#39;c&#39;");
  });
  it("null/undefined را رشته‌ی خالی می‌کند و عدد را رشته", () => {
    expect(escapeHtml(null)).toBe("");
    expect(escapeHtml(undefined)).toBe("");
    expect(escapeHtml(42)).toBe("42");
  });
  it("متن فارسی را دست‌نخورده نگه می‌دارد", () => {
    expect(escapeHtml("داکتر احمد")).toBe("داکتر احمد");
  });
  it("نتیجه هنگام ورود به innerHTML تگ واقعی نمی‌سازد", () => {
    const el = document.createElement("div");
    el.innerHTML = `<td>${escapeHtml("<img src=x onerror=alert(1)>")}</td>`;
    expect(el.querySelector("img")).toBeNull();
    expect(el.textContent).toBe("<img src=x onerror=alert(1)>");
  });
});

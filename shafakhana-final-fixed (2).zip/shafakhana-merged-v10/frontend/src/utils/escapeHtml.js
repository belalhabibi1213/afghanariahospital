// جلوگیری از XSS: هر مقدار متنی که قرار است داخل رشته‌ی HTML (مثلاً innerHTML خروجی PDF) برود
// باید اول از این تابع رد شود تا <, >, &, " و ' به معادل امن تبدیل شوند.
const MAP = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

export function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => MAP[ch]);
}

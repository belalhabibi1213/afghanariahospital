// تقویم هجری شمسی (جلالی) — تنها منبع تبدیل/قالب‌بندی تاریخ در کل فرانت‌اند.
//
// قرارداد: در تمام سیستم، مقدار ذخیره‌شده/ارسالی به API همیشه «میلادی ISO» است (YYYY-MM-DD یا
// YYYY-MM-DDTHH:mm)؛ این ماژول فقط برای «نمایش» و «انتخاب» تاریخ به شمسی تبدیل می‌کند.
// تبدیل‌ها بر پایه‌ی تقویم persian در Intl (ICU) است تا نمایش، انتخابگر و فیلترها همیشه با هم یکی باشند.

// نام ماه‌ها: دری افغانستان (حمل … حوت). برای نام‌های ایرانی (فروردین …) کافی است ماه‌ها را عوض کنید.
export const MONTH_NAMES = ["حمل", "ثور", "جوزا", "سرطان", "اسد", "سنبله", "میزان", "عقرب", "قوس", "جدی", "دلو", "حوت"];
// هفته از شنبه شروع می‌شود
export const WEEKDAY_NAMES = ["شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه"];
export const WEEKDAY_SHORT = ["ش", "ی", "د", "س", "چ", "پ", "ج"];

const PERSIAN_DIGITS = "۰۱۲۳۴۵۶۷۸۹";
const pad2 = (n) => String(n).padStart(2, "0");

export function toFaDigits(value) {
  return String(value).replace(/\d/g, (d) => PERSIAN_DIGITS[d]);
}
// ارقام فارسی/عربی → لاتین
export function toLatinDigits(value) {
  return String(value)
    .replace(/[۰-۹]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[٠-٩]/g, (d) => String(d.charCodeAt(0) - 0x0660));
}

const partsFormatter = new Intl.DateTimeFormat("en-US-u-ca-persian-nu-latn", { year: "numeric", month: "numeric", day: "numeric", timeZone: "UTC" });

// میلادی (ماه ۱ تا ۱۲) → شمسی
export function gregorianToJalali(gy, gm, gd) {
  const parts = partsFormatter.formatToParts(new Date(Date.UTC(gy, gm - 1, gd)));
  const pick = (type) => Number(parts.find((p) => p.type === type).value);
  return { jy: pick("year"), jm: pick("month"), jd: pick("day") };
}

const dayOfJalaliYear = (jm, jd) => (jm <= 6 ? (jm - 1) * 31 + jd : 186 + (jm - 7) * 30 + jd);

// شمسی → میلادی؛ برای تاریخ نامعتبر (مثلاً ۳۰ اسفند سال غیرکبیسه) null برمی‌گرداند
export function jalaliToGregorian(jy, jm, jd) {
  if (!Number.isInteger(jy) || !Number.isInteger(jm) || !Number.isInteger(jd)) return null;
  if (jm < 1 || jm > 12 || jd < 1 || jd > 31 || jy < 1 || jy > 9999) return null;
  // تخمین اولیه (نوروز ≈ ۲۱ مارس) و سپس اصلاح با خودِ تقویم تا دقیقاً به همان روز برسیم
  let ms = Date.UTC(jy + 621, 2, 21 + dayOfJalaliYear(jm, jd) - 1);
  for (let i = 0; i < 6; i += 1) {
    const d = new Date(ms);
    const j = gregorianToJalali(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
    if (j.jy === jy && j.jm === jm && j.jd === jd) return { gy: d.getUTCFullYear(), gm: d.getUTCMonth() + 1, gd: d.getUTCDate() };
    const diff = (jy - j.jy) * 365 + (dayOfJalaliYear(jm, jd) - dayOfJalaliYear(j.jm, j.jd));
    // اگر تخمین اختلاف صفر شد (مرز کبیسه)، جهت حرکت را با مقایسه‌ی ترتیبی (سال، ماه، روز) تعیین می‌کنیم
    const targetIsLater = jy !== j.jy ? jy > j.jy : jm !== j.jm ? jm > j.jm : jd > j.jd;
    ms += (diff || (targetIsLater ? 1 : -1)) * 86400000;
  }
  return null;
}

export function isJalaliLeapYear(jy) {
  return jalaliToGregorian(jy, 12, 30) !== null;
}

export function jalaliMonthLength(jy, jm) {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isJalaliLeapYear(jy) ? 30 : 29;
}

// روز هفته‌ی یک تاریخ شمسی: ۰ = شنبه … ۶ = جمعه
export function jalaliWeekday(jy, jm, jd) {
  const g = jalaliToGregorian(jy, jm, jd);
  return (new Date(Date.UTC(g.gy, g.gm - 1, g.gd)).getUTCDay() + 1) % 7;
}

// ---------- ISO (میلادی) ----------
const DATE_ONLY = /^(\d{4})-(\d{2})-(\d{2})$/;
const LOCAL_DT = /^(\d{4})-(\d{2})-(\d{2})[T ](\d{2}):(\d{2})(?::\d{2})?$/;

export function toISODate(gy, gm, gd) {
  return `${gy}-${pad2(gm)}-${pad2(gd)}`;
}

// تاریخ امروز (به وقت محلی) به‌صورت ISO میلادی
export function todayISO() {
  const n = new Date();
  return toISODate(n.getFullYear(), n.getMonth() + 1, n.getDate());
}

// هر ورودی (رشته‌ی تاریخ ساده، datetime-local، رشته‌ی ISO سرور، Date) → اجزای محلی
export function parseDateValue(value) {
  if (value === null || value === undefined || value === "") return null;
  if (value instanceof Date) {
    if (Number.isNaN(value.getTime())) return null;
    return { gy: value.getFullYear(), gm: value.getMonth() + 1, gd: value.getDate(), hh: value.getHours(), mm: value.getMinutes(), hasTime: true };
  }
  const str = String(value).trim();
  let m = DATE_ONLY.exec(str);
  if (m) return { gy: +m[1], gm: +m[2], gd: +m[3], hh: 0, mm: 0, hasTime: false }; // بدون جابه‌جایی منطقه‌ی زمانی
  m = LOCAL_DT.exec(str);
  if (m) return { gy: +m[1], gm: +m[2], gd: +m[3], hh: +m[4], mm: +m[5], hasTime: true };
  const d = new Date(str);
  if (Number.isNaN(d.getTime())) return null;
  return { gy: d.getFullYear(), gm: d.getMonth() + 1, gd: d.getDate(), hh: d.getHours(), mm: d.getMinutes(), hasTime: true };
}

// ---------- قالب‌بندی برای نمایش ----------
// formatJalaliDate("2026-10-09") → «۱۴۰۵/۰۷/۱۷»
// { month: "long" } → «۱۷ میزان ۱۴۰۵»  |  { weekday: true } روز هفته هم اضافه می‌کند  |  { latin: true } ارقام لاتین
export function formatJalaliDate(value, { month = "numeric", weekday = false, latin = false, empty = "—" } = {}) {
  const p = parseDateValue(value);
  if (!p) return empty;
  const j = gregorianToJalali(p.gy, p.gm, p.gd);
  let text;
  if (month === "long") text = `${j.jd} ${MONTH_NAMES[j.jm - 1]} ${j.jy}`;
  else if (month === "short") text = `${j.jd} ${MONTH_NAMES[j.jm - 1]}`;
  else text = `${j.jy}/${pad2(j.jm)}/${pad2(j.jd)}`;
  if (weekday) text = `${WEEKDAY_NAMES[jalaliWeekday(j.jy, j.jm, j.jd)]} ${text}`;
  return latin ? text : toFaDigits(text);
}

export function formatTime(value, { latin = false, empty = "" } = {}) {
  if (typeof value === "string" && /^\d{2}:\d{2}/.test(value)) return latin ? value.slice(0, 5) : toFaDigits(value.slice(0, 5)); // «HH:mm[:ss]»
  const p = parseDateValue(value);
  if (!p || !p.hasTime) return empty;
  const t = `${pad2(p.hh)}:${pad2(p.mm)}`;
  return latin ? t : toFaDigits(t);
}

// «۱۴۰۵/۰۷/۱۷ ۱۴:۳۵»
export function formatJalaliDateTime(value, opts = {}) {
  const p = parseDateValue(value);
  if (!p) return opts.empty ?? "—";
  const date = formatJalaliDate(value, opts);
  return p.hasTime ? `${date} ${formatTime(value, opts)}` : date;
}

// ---------- ورودی متنی ----------
// «۱۴۰۵/۰۷/۱۷» (یا با - . ، و ارقام فارسی/عربی) → «YYYY-MM-DD» میلادی؛ نامعتبر → null
export function parseJalaliInput(text) {
  const clean = toLatinDigits(String(text || "")).trim().replace(/[\u200c\u200f\u200e\s]+/g, "");
  const m = /^(\d{4})[/\-.،](\d{1,2})[/\-.،](\d{1,2})$/.exec(clean);
  if (!m) return null;
  const [jy, jm, jd] = [+m[1], +m[2], +m[3]];
  const g = jalaliToGregorian(jy, jm, jd);
  return g ? toISODate(g.gy, g.gm, g.gd) : null;
}

// ISO میلادی → متن قابل ویرایش «۱۴۰۵/۰۷/۱۷» (برای مقدار input)
export function isoToJalaliInput(value) {
  return value ? formatJalaliDate(String(value).slice(0, 10), { empty: "" }) : "";
}

// شروع «هفته‌ی جاری» (شنبه) و «ماه شمسی جاری» به‌صورت ISO میلادی — برای فیلترهای «این هفته / این ماه»
export function currentWeekRange(now = new Date()) {
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  start.setDate(start.getDate() - ((start.getDay() + 1) % 7));
  return { from: toISODate(start.getFullYear(), start.getMonth() + 1, start.getDate()), to: toISODate(now.getFullYear(), now.getMonth() + 1, now.getDate()) };
}
export function currentJalaliMonthRange(now = new Date()) {
  const j = gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  const g = jalaliToGregorian(j.jy, j.jm, 1);
  return { from: toISODate(g.gy, g.gm, g.gd), to: toISODate(now.getFullYear(), now.getMonth() + 1, now.getDate()) };
}

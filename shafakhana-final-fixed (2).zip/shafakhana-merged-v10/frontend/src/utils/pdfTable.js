// ساخت PDF از یک جدول HTML (که به‌صورت تصویر رسم می‌شود) بدون بریدن سطرها.
// مشکل قبلی: کل جدول یک تصویر بلند بود و با فاصله‌ی ثابت بین صفحه‌ها برش می‌خورد؛ پس سطری که
// روی مرز صفحه می‌افتاد نصفه در پایین یک صفحه و نصفه‌ی دیگرش بالای صفحه‌ی بعد چاپ می‌شد
// (یک خط روی متن می‌افتاد و ناخوانا می‌شد). حالا برش فقط بین دو سطر انجام می‌شود و سرستون‌ها
// (thead) بالای هر صفحه‌ی بعدی تکرار می‌شود.
//
// box: المنت حاوی عنوان + <table> (باید در DOM باشد تا اندازه‌ی سطرها خوانده شود)
const MARGIN = 20; // pt
const EDGE = 2; // px تصویر؛ برای اینکه خط پایین آخرین سطر هر صفحه بریده نشود

export async function tableBoxToPdf(box, { html2canvas, jsPDF, fileName, orientation = "landscape", scale = 2 }) {
  const table = box.querySelector("table");
  const thead = table?.querySelector("thead");
  const rows = table ? [...table.querySelectorAll("tbody tr")] : [];
  const canvas = await html2canvas(box, { scale, backgroundColor: "#ffffff" });
  const pdf = new jsPDF({ orientation, unit: "pt", format: "a4" });
  const pw = pdf.internal.pageSize.getWidth();
  const ph = pdf.internal.pageSize.getHeight();
  const iw = pw - MARGIN * 2; // عرض تصویر روی صفحه (pt)
  const k = iw / canvas.width; // هر پیکسلِ تصویر چند pt است
  const availPx = Math.floor((ph - MARGIN * 2) / k); // ارتفاع قابل‌استفاده‌ی هر صفحه به پیکسل تصویر

  // بدون جدول/سطر: همان تصویر کامل با برش ساده
  if (!thead || rows.length === 0) {
    addSlices(pdf, canvas, [{ parts: [[0, canvas.height]] }], k, iw);
    pdf.save(fileName);
    return;
  }

  const boxTop = box.getBoundingClientRect().top;
  const toPx = (y) => Math.round((y - boxTop) * scale);
  const headRect = thead.getBoundingClientRect();
  const headTop = toPx(headRect.top);
  const headBottom = toPx(headRect.bottom);
  const headH = headBottom - headTop;
  const rowPx = rows.map((tr) => {
    const r = tr.getBoundingClientRect();
    return { top: toPx(r.top), bottom: toPx(r.bottom) };
  });

  const pages = [];
  let i = 0;
  while (i < rowPx.length) {
    const first = pages.length === 0;
    const startY = first ? 0 : rowPx[i].top; // صفحه‌ی اول از بالای عنوان شروع می‌شود
    const avail = first ? availPx : availPx - headH;
    let j = i;
    // تا جایی که سطر کامل در صفحه جا می‌شود جلو می‌رویم (حداقل یک سطر در هر صفحه)
    while (j < rowPx.length && (j === i || rowPx[j].bottom - startY <= avail)) j += 1;
    const endY = Math.min(canvas.height, rowPx[j - 1].bottom + EDGE);
    pages.push({ parts: first ? [[0, endY]] : [[headTop, headBottom], [startY, endY]] });
    i = j;
  }
  addSlices(pdf, canvas, pages, k, iw);
  pdf.save(fileName);
}

// هر صفحه = یک یا چند برش [yStart, yEnd] از تصویر اصلی که زیر هم چسبانده می‌شوند
function addSlices(pdf, canvas, pages, k, iw) {
  pages.forEach((page, idx) => {
    const totalH = page.parts.reduce((s, [a, b]) => s + (b - a), 0);
    const out = document.createElement("canvas");
    out.width = canvas.width;
    out.height = Math.max(1, totalH);
    const ctx = out.getContext("2d");
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, out.width, out.height);
    let y = 0;
    page.parts.forEach(([a, b]) => {
      const h = b - a;
      if (h > 0) ctx.drawImage(canvas, 0, a, canvas.width, h, 0, y, canvas.width, h);
      y += h;
    });
    if (idx > 0) pdf.addPage();
    pdf.addImage(out.toDataURL("image/png"), "PNG", MARGIN, MARGIN, iw, totalH * k);
  });
}

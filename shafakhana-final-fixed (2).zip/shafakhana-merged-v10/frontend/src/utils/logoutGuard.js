// نام رویداد سراسری برای درخواست تایید خروج. LogoutConfirmModal (مانت‌شده یک‌بار در
// App.jsx) به این رویداد گوش می‌دهد و مودال تایید را باز می‌کند — به همین ترتیب هر
// دکمه‌ی «خروج» در سایت (سایدبار داشبوردها، نوار بالای سایت عمومی) به‌جای خروج فوری،
// کافی است این رویداد را پخش کند.
export const LOGOUT_REQUIRED_EVENT = "shafakhana:logout-request";

export function requestLogout() {
  window.dispatchEvent(new CustomEvent(LOGOUT_REQUIRED_EVENT));
}

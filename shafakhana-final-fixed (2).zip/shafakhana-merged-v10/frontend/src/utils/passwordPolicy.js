// سیاست رمز عبور مشترک (سمت فرانت‌اند) — استفاده در فرم‌های ثبت‌نام کاربر (Register.jsx)،
// ساخت حساب ادمین/داکتر (SuperAdminDashboard.jsx)، بازیابی رمز عبور (ResetPassword.jsx)
// و تغییر رمز عبور (UserDashboard.jsx). معادل سمت بک‌اند: backend/utils/passwordPolicy.js —
// این دو فایل باید همیشه هم‌خوان بمانند تا پیام خطای frontend/backend یکسان باشد.
//
// قانون فعلی (تعمداً ساده نگه داشته شده): فقط حداقل طول ۸ کاراکتر الزامی است.
// بدون حداکثر طول. حروف بزرگ/کوچک/عدد/کاراکتر خاص هیچ‌کدام اجباری نیستند (اما مجازند).
// فقط حروف انگلیسی، اعداد و کاراکترهای خاص مجاز مجاز هستند؛ حروف فارسی/عربی رد می‌شوند.

const MIN_PASSWORD_LENGTH = 8;

// فقط این کاراکترها مجاز هستند: حروف انگلیسی (A-Z, a-z)، اعداد (0-9) و
// کاراکترهای خاص رایج: @ # $ % & * ! _ - + و چند کاراکتر خاص دیگر
const ALLOWED_CHARS_REGEX = /^[A-Za-z0-9!@#$%^&*()_+\-=?.,]*$/;


// رمزهای بسیار رایج (حدس‌زدنی در چند ثانیه) رد می‌شوند؛ فهرست عمداً کوتاه و دقیق است.
const COMMON_PASSWORDS = new Set([
  "12345678", "123456789", "1234567890", "11111111", "00000000", "12341234", "87654321",
  "password", "password1", "password123", "passw0rd", "qwerty123", "qwertyuiop", "1q2w3e4r",
  "iloveyou", "abc12345", "admin123", "admin1234", "welcome1", "letmein123",
]);
// bcrypt فقط ۷۲ بایت اول رمز را در نظر می‌گیرد؛ رمز بلندتر بی‌صدا بریده می‌شد و امنیت کاذب می‌داد.
const MAX_PASSWORD_LENGTH = 72;
const COMMON_PASSWORD_MESSAGE = "این رمز عبور بسیار رایج و قابل حدس است؛ رمز دیگری انتخاب کنید.";
const TOO_LONG_PASSWORD_MESSAGE = "رمز عبور نباید بیشتر از ۷۲ کاراکتر باشد.";

export const PASSWORD_POLICY_MESSAGE =
  "رمز عبور باید حداقل ۸ کاراکتر باشد و فقط از حروف انگلیسی، اعداد و کاراکترهای مجاز استفاده کند.";

// متن کمکی همیشه‌قابل‌مشاهده زیر فیلد رمز عبور (نه فقط پیام خطا) تا کاربر پیش از
// اشتباه کردن هم قانون را ببیند.
export const PASSWORD_HINT_FA =
  "حداقل ۸ کاراکتر — فقط حروف انگلیسی، عدد و کاراکترهای خاص (@ # $ % & * ! _ - + و مشابه). حداکثر ۷۲ کاراکتر؛ رمزهای بسیار رایج (مثل 12345678) پذیرفته نمی‌شود.";

/**
 * رمز عبور را طبق سیاست بالا بررسی می‌کند.
 * @param {string} password
 * @returns {string} پیام خطا، یا رشته‌ی خالی در صورت معتبر بودن
 */
export function getPasswordError(password) {
  if (!password) return "رمز عبور الزامی است.";
  if (password.length < MIN_PASSWORD_LENGTH || !ALLOWED_CHARS_REGEX.test(password)) {
    return PASSWORD_POLICY_MESSAGE;
  }
  if (password.length > MAX_PASSWORD_LENGTH) return TOO_LONG_PASSWORD_MESSAGE;
  if (COMMON_PASSWORDS.has(password.toLowerCase())) return COMMON_PASSWORD_MESSAGE;
  return "";
}

export function isStrongPassword(password) {
  return getPasswordError(password) === "";
}

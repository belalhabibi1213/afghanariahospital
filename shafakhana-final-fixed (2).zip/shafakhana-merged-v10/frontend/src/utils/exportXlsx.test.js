import { describe, it, expect, vi, beforeEach } from "vitest";
import { downloadXlsx } from "./exportXlsx.js";

let capturedBlob;
let anchor;

beforeEach(() => {
  capturedBlob = null;
  anchor = { click: vi.fn(), remove: vi.fn(), href: "", download: "" };
  vi.spyOn(document, "createElement").mockImplementation((tag) => (tag === "a" ? anchor : document.constructor.prototype.createElement.call(document, tag)));
  vi.spyOn(document.body, "appendChild").mockImplementation(() => {});
  URL.createObjectURL = vi.fn((b) => { capturedBlob = b; return "blob:fake"; });
  URL.revokeObjectURL = vi.fn();
});

// فایل xlsx یک zip است: باید با امضای «PK» شروع شود
// (Blob در jsdom با Response نود سازگار نیست؛ پس با FileReader خوانده می‌شود)
function readBytes(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(new Uint8Array(reader.result));
    reader.onerror = reject;
    reader.readAsArrayBuffer(blob);
  });
}
async function startsWithPK(blob) {
  const buf = await readBytes(blob);
  return buf.length > 100 && buf[0] === 0x50 && buf[1] === 0x4b;
}

describe("downloadXlsx", () => {
  it("یک شیت: فایل zip معتبر با نام درست دانلود می‌شود", async () => {
    await downloadXlsx("report.xlsx", [{ name: "نوبت‌ها", rows: [{ نام: "الف", سن: 30 }, { نام: "ب", سن: null }] }]);
    expect(anchor.download).toBe("report.xlsx");
    expect(anchor.href).toBe("blob:fake");
    expect(anchor.click).toHaveBeenCalledTimes(1);
    expect(anchor.remove).toHaveBeenCalled();
    expect(await startsWithPK(capturedBlob)).toBe(true);
  });

  it("چند شیت و شیت خالی بدون خطا ساخته می‌شود", async () => {
    await downloadXlsx("multi.xlsx", [
      { name: "خلاصه", rows: [{ a: 1 }] },
      { name: "خالی", rows: [] },
    ]);
    expect(await startsWithPK(capturedBlob)).toBe(true);
  });

  it("نام شیت با کاراکتر ممنوع یا طولانی‌تر از ۳۱ حرف خطا نمی‌دهد", async () => {
    await expect(
      downloadXlsx("x.xlsx", [{ name: "گزارش:کل/سال*[۱۴۰۵]؟" + "x".repeat(50), rows: [{ a: 1 }] }])
    ).resolves.toBeUndefined();
  });

  it("مقادیر عجیب (undefined، boolean، متن HTML) بدون خطا نوشته می‌شوند", async () => {
    await expect(
      downloadXlsx("x.xlsx", [{ name: "s", rows: [{ a: undefined, b: true, c: "<b>x</b>", d: 1.5, e: "" }] }])
    ).resolves.toBeUndefined();
  });
});

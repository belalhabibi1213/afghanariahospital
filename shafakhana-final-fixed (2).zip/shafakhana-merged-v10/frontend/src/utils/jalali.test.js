import { describe, it, expect } from "vitest";
import {
  gregorianToJalali, jalaliToGregorian, jalaliMonthLength, isJalaliLeapYear, jalaliWeekday, formatJalaliDate,
  formatJalaliDateTime, parseJalaliInput, isoToJalaliInput, parseDateValue, formatTime, currentJalaliMonthRange,
} from "./jalali.js";

describe("jalali conversions", () => {
  it("نقاط مرجع معروف", () => {
    expect(gregorianToJalali(2025, 3, 21)).toEqual({ jy: 1404, jm: 1, jd: 1 }); // نوروز ۱۴۰۴
    expect(gregorianToJalali(2026, 3, 21)).toEqual({ jy: 1405, jm: 1, jd: 1 }); // نوروز ۱۴۰۵
    expect(gregorianToJalali(2026, 10, 9)).toEqual({ jy: 1405, jm: 7, jd: 17 });
    expect(jalaliToGregorian(1405, 7, 17)).toEqual({ gy: 2026, gm: 10, gd: 9 });
    expect(jalaliToGregorian(1403, 12, 30)).toEqual({ gy: 2025, gm: 3, gd: 20 }); // ۱۴۰۳ کبیسه
  });
  it("کبیسه و طول ماه", () => {
    expect(isJalaliLeapYear(1403)).toBe(true);
    expect(isJalaliLeapYear(1404)).toBe(false);
    expect(jalaliToGregorian(1404, 12, 30)).toBeNull();
    expect(jalaliMonthLength(1404, 12)).toBe(29);
    expect(jalaliMonthLength(1403, 12)).toBe(30);
    expect([1, 6, 7, 11].map((m) => jalaliMonthLength(1405, m))).toEqual([31, 31, 30, 30]);
  });
  it("روز هفته (شنبه = ۰)", () => {
    expect(jalaliWeekday(1405, 7, 17)).toBe(6); // جمعه ۹ اکتبر ۲۰۲۶
    expect(jalaliWeekday(1405, 7, 18)).toBe(0); // شنبه
  });
  it("رفت‌وبرگشت برای هر روز ۱۲۰۰ تا ۱۶۰۰ هجری شمسی (با Intl یکی است)", () => {
    const ref = new Intl.DateTimeFormat("en-US-u-ca-persian-nu-latn", { year: "numeric", month: "numeric", day: "numeric", timeZone: "UTC" });
    let ms = Date.UTC(1821, 2, 21);
    const end = Date.UTC(2222, 2, 21);
    let count = 0;
    for (; ms < end; ms += 86400000 * 3) { // هر ۳ روز؛ بازه‌ی ~۴۰۰ سال
      const d = new Date(ms);
      const j = gregorianToJalali(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate());
      const f = ref.formatToParts(d);
      expect(j.jm).toBe(Number(f.find((p) => p.type === "month").value));
      const back = jalaliToGregorian(j.jy, j.jm, j.jd);
      expect(back).toEqual({ gy: d.getUTCFullYear(), gm: d.getUTCMonth() + 1, gd: d.getUTCDate() });
      count += 1;
    }
    expect(count).toBeGreaterThan(40000);
  });
});

describe("formatters", () => {
  it("قالب‌ها و ارقام فارسی", () => {
    expect(formatJalaliDate("2026-10-09")).toBe("۱۴۰۵/۰۷/۱۷");
    expect(formatJalaliDate("2026-10-09", { latin: true })).toBe("1405/07/17");
    expect(formatJalaliDate("2026-10-09", { month: "long" })).toBe("۱۷ میزان ۱۴۰۵");
    expect(formatJalaliDate("2026-10-09", { weekday: true })).toBe("جمعه ۱۴۰۵/۰۷/۱۷");
    expect(formatJalaliDate(null)).toBe("—");
    expect(formatJalaliDate("garbage")).toBe("—");
  });
  it("تاریخ ساده بدون جابه‌جایی منطقه‌ی زمانی و datetime-local", () => {
    expect(parseDateValue("2026-03-21")).toMatchObject({ gy: 2026, gm: 3, gd: 21, hasTime: false });
    expect(formatJalaliDateTime("2026-10-09T14:35")).toBe("۱۴۰۵/۰۷/۱۷ ۱۴:۳۵");
    expect(formatJalaliDateTime("2026-10-09")).toBe("۱۴۰۵/۰۷/۱۷");
    expect(formatTime("09:05:00")).toBe("۰۹:۰۵");
  });
  it("ورودی متنی: ارقام فارسی/لاتین و جداکننده‌ها", () => {
    expect(parseJalaliInput("۱۴۰۵/۰۷/۱۷")).toBe("2026-10-09");
    expect(parseJalaliInput("1405-7-17")).toBe("2026-10-09");
    expect(parseJalaliInput("1404/12/30")).toBeNull();
    expect(parseJalaliInput("1405/13/01")).toBeNull();
    expect(parseJalaliInput("abc")).toBeNull();
    expect(isoToJalaliInput("2026-10-09")).toBe("۱۴۰۵/۰۷/۱۷");
    expect(isoToJalaliInput("")).toBe("");
  });
  it("ابتدای ماه شمسی جاری", () => {
    const r = currentJalaliMonthRange(new Date(2026, 9, 9));
    expect(r.from).toBe("2026-09-23"); // ۱ میزان ۱۴۰۵
    expect(r.to).toBe("2026-10-09");
  });
});

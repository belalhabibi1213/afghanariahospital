import { describe, it, expect, vi } from "vitest";
import { ensureAuthenticated, AUTH_REQUIRED_EVENT } from "./authGuard.js";
import { requestLogout, LOGOUT_REQUIRED_EVENT } from "./logoutGuard.js";
import { groupPrescriptions } from "./prescriptionGroups.js";

describe("authGuard", () => {
  it("کاربر واردشده: true و بدون رویداد", () => {
    const spy = vi.fn();
    window.addEventListener(AUTH_REQUIRED_EVENT, spy);
    expect(ensureAuthenticated(true)).toBe(true);
    expect(spy).not.toHaveBeenCalled();
    window.removeEventListener(AUTH_REQUIRED_EVENT, spy);
  });
  it("مهمان: false و پخش رویداد ورود اجباری", () => {
    const spy = vi.fn();
    window.addEventListener(AUTH_REQUIRED_EVENT, spy);
    expect(ensureAuthenticated(false)).toBe(false);
    expect(spy).toHaveBeenCalledTimes(1);
    window.removeEventListener(AUTH_REQUIRED_EVENT, spy);
  });
});

describe("logoutGuard", () => {
  it("requestLogout رویداد تایید خروج را پخش می‌کند", () => {
    const spy = vi.fn();
    window.addEventListener(LOGOUT_REQUIRED_EVENT, spy);
    requestLogout();
    expect(spy).toHaveBeenCalledTimes(1);
    window.removeEventListener(LOGOUT_REQUIRED_EVENT, spy);
  });
});

describe("groupPrescriptions", () => {
  it("داروهای هم‌گروه را به یک نسخه تبدیل می‌کند و ترتیب ورودی را حفظ می‌کند", () => {
    const list = [
      { id: 3, groupId: "g1", patientId: 1, doctorId: 9, medicine: "B", diagnosis: "" },
      { id: 2, groupId: "g1", patientId: 1, doctorId: 9, medicine: "A", diagnosis: "سرماخوردگی" },
      { id: 1, patientId: 1, doctorId: 9, medicine: "قدیمی" },
    ];
    const out = groupPrescriptions(list);
    expect(out).toHaveLength(2);
    expect(out[0].medicines.map((m) => m.medicine)).toEqual(["A", "B"]); // بر اساس id مرتب می‌شود
    expect(out[0].diagnosis).toBe("سرماخوردگی"); // فیلد خالی از رکورد پرِ گروه پر می‌شود
    expect(out[1].medicines).toHaveLength(1);
  });
  it("گروه‌های بیماران یا داکتران متفاوت را قاطی نمی‌کند", () => {
    const out = groupPrescriptions([
      { id: 1, groupId: "g", patientId: 1, doctorId: 1 },
      { id: 2, groupId: "g", patientId: 2, doctorId: 1 },
      { id: 3, groupId: "g", patientId: 1, doctorId: 2 },
    ]);
    expect(out).toHaveLength(3);
  });
  it("ورودی خالی", () => {
    expect(groupPrescriptions()).toEqual([]);
  });
});

// اعتبارسنجی مشترک ایمیل (سمت فرانت‌اند) — فقط برای فرم «ثبت‌نام» (Register.jsx) و فقط
// برای تجربه‌ی کاربری فوری (جلوگیری از ارسال درخواست/کد تایید با ایمیل واضحاً نامعتبر).
// معادل سمت بک‌اند: backend/utils/emailValidation.js — همان مرجع نهایی و امنیتی است؛
// این دو فایل باید همیشه هم‌خوان بمانند تا پیام خطای frontend/backend یکسان باشد.

export const EMAIL_INVALID_MESSAGE = "ایمیل وارد شده معتبر نیست. لطفاً ایمیل خود را بررسی کنید.";

// فرمت کلی یک ایمیل معتبر: local-part@domain.tld — کلاس‌های کاراکتر زیر فقط ASCII
// هستند، پس هر حرف فارسی/عربی/یونیکد دیگر خودبه‌خود رد می‌شود.
const EMAIL_FORMAT_REGEX =
  /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,24}$/;

const CONSECUTIVE_DOTS_REGEX = /\.\./;

// فقط دامنه‌ی دقیقاً «gmail.com» جیمیل در نظر گرفته می‌شود (هم‌خوان با بک‌اند)
const GMAIL_DOMAIN = "gmail.com";

// نام کاربری Gmail: ۶ تا ۳۰ کاراکتر، فقط حروف/عدد/نقطه، بدون شروع/پایان با نقطه
const GMAIL_LOCAL_PART_REGEX = /^[a-zA-Z0-9](?:[a-zA-Z0-9.]{4,28})[a-zA-Z0-9]$/;

// همان فهرست اشتباهات تایپی رایج دامنه که در backend/utils/emailValidation.js تعریف شده
const KNOWN_TYPO_DOMAINS = new Set([
  "gmial.com", "gmal.com", "gamil.com", "gmai.com", "gmaill.com", "gmailcom",
  "gmail.co", "gmail.cm", "gmail.con", "gnail.com", "gmail.comm", "gmil.com",
  "yahooo.com", "yaho.com", "yahoo.co", "yahoo.con", "yaoo.com", "yahoocom",
  "hotmial.com", "hotnail.com", "hotmail.co", "hotmal.com", "hotmai.com", "hotmailcom",
  "outlok.com", "outllook.com", "outlook.co", "outlok.co", "outlookcom",
]);

/**
 * فرمت ایمیل را طبق قوانین بالا بررسی می‌کند (فقط فرمت — نه مالکیت واقعی؛ مالکیت واقعی
 * فقط با کد ۶ رقمی ارسالی به همان ایمیل اثبات می‌شود).
 * @param {string} email
 * @returns {boolean}
 */
export function isEmailFormatValid(email) {
  if (typeof email !== "string") return false;
  const trimmed = email.trim();
  if (!trimmed) return false;

  if (!EMAIL_FORMAT_REGEX.test(trimmed)) return false;
  if (CONSECUTIVE_DOTS_REGEX.test(trimmed)) return false;

  const atIndex = trimmed.lastIndexOf("@");
  const localPart = trimmed.slice(0, atIndex);
  const domain = trimmed.slice(atIndex + 1).toLowerCase();

  if (KNOWN_TYPO_DOMAINS.has(domain)) return false;

  if (domain === GMAIL_DOMAIN && !GMAIL_LOCAL_PART_REGEX.test(localPart)) {
    return false;
  }

  return true;
}

/**
 * @param {string} email
 * @returns {string} پیام خطا، یا رشته‌ی خالی در صورت معتبر بودن
 */
export function getEmailError(email) {
  if (!email || !email.trim()) return "ایمیل الزامی است.";
  return isEmailFormatValid(email) ? "" : EMAIL_INVALID_MESSAGE;
}

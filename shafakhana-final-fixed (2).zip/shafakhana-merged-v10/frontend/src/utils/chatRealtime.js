// پل ساده‌ی بین اتصال Socket.IO (useVoiceCall) و پنل‌های چت: وقتی سرور «پیام تازه» را push کند،
// چت بلافاصله پیام‌ها را می‌گیرد؛ و تا وقتی اتصال زنده است، polling دوره‌ای فقط پشتیبان کم‌تکرار است.
// اگر اتصال قطع شود، polling به‌طور خودکار به ریتم قبلی (۸ ثانیه) برمی‌گردد — هیچ پیامی گم نمی‌شود.
const listeners = new Set();
let connected = false;

export function setChatSocketConnected(value) {
  connected = !!value;
}

export function isChatSocketConnected() {
  return connected;
}

export function emitChatNew(conversationId) {
  listeners.forEach((fn) => {
    try { fn(conversationId); } catch { /* شنونده‌ی خراب نباید بقیه را مختل کند */ }
  });
}

export function onChatNew(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

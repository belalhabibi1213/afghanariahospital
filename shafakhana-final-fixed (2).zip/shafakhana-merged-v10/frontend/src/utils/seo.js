// ابزار سبک مدیریت SEO — بدون وابستگی جدید (مثل react-helmet)، فقط با دستکاری مستقیم
// <head> صفحه. برای صفحاتی استفاده می‌شود که باید عنوان/توضیح/برچسب‌های Open Graph
// اختصاصی داشته باشند (مثلاً صفحه‌ی «ادامه مطلب» یک خبر خاص برای اشتراک‌گذاری در شبکه‌های اجتماعی).

const MANAGED_ATTR = "data-seo-managed";

function upsertMeta(attrName, attrValue, content) {
  if (!content) return;
  let el = document.head.querySelector(`meta[${attrName}="${attrValue}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attrName, attrValue);
    el.setAttribute(MANAGED_ATTR, "true");
    document.head.appendChild(el);
  }
  el.setAttribute("content", content);
}

function upsertLink(rel, href) {
  if (!href) return;
  let el = document.head.querySelector(`link[rel="${rel}"]`);
  if (!el) {
    el = document.createElement("link");
    el.setAttribute("rel", rel);
    el.setAttribute(MANAGED_ATTR, "true");
    document.head.appendChild(el);
  }
  el.setAttribute("href", href);
}

function upsertJsonLd(id, data) {
  let el = document.getElementById(id);
  if (!el) {
    el = document.createElement("script");
    el.type = "application/ld+json";
    el.id = id;
    el.setAttribute(MANAGED_ATTR, "true");
    document.head.appendChild(el);
  }
  el.textContent = JSON.stringify(data);
}

/**
 * عنوان و متاتگ‌های صفحه را برای SEO/اشتراک‌گذاری اجتماعی تنظیم می‌کند.
 * یک تابع "پاکسازی" برمی‌گرداند که باید در cleanup مربوط به useEffect فراخوانی شود
 * تا وقتی کاربر از صفحه خارج شد، مقادیر پیش‌فرض سایت بازگردانده شوند.
 */
export function setPageSEO({ title, description, image, url, type = "article", structuredData }) {
  const previousTitle = document.title;
  if (title) document.title = title;

  upsertMeta("name", "description", description);
  upsertMeta("property", "og:title", title);
  upsertMeta("property", "og:description", description);
  upsertMeta("property", "og:type", type);
  if (image) upsertMeta("property", "og:image", image);
  if (url) upsertMeta("property", "og:url", url);
  upsertMeta("name", "twitter:card", image ? "summary_large_image" : "summary");
  upsertMeta("name", "twitter:title", title);
  upsertMeta("name", "twitter:description", description);
  if (url) upsertLink("canonical", url);

  if (structuredData) upsertJsonLd("seo-structured-data", structuredData);

  return function cleanupPageSEO() {
    document.title = previousTitle;
    document.head.querySelectorAll(`[${MANAGED_ATTR}]`).forEach((el) => el.remove());
  };
}

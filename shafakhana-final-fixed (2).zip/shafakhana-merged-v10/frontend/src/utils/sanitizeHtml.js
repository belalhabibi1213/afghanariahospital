// لایه‌ی دوم دفاع XSS در فرانت‌اند: پیش از dangerouslySetInnerHTML، HTML خبر یک‌بار دیگر با allowlist
// پاک‌سازی می‌شود (لیست مجاز دقیقاً هم‌خوان با backend/utils/sanitizeNewsContent.js). اگر بک‌اند یا دیتابیس
// دستکاری شود یا پاک‌سازی سمت سرور دور زده شود، اسکریپت/event handler/iframe اینجا حذف می‌شود.
// بدون وابستگی خارجی: از DOMParser (که اسکریپت اجرا نمی‌کند) استفاده می‌شود.
const ALLOWED_TAGS = new Set([
  "P", "BR", "STRONG", "B", "EM", "I", "U", "S", "STRIKE",
  "H2", "H3", "H4", "UL", "OL", "LI", "A", "BLOCKQUOTE", "SPAN",
]);
// محتوای این تگ‌ها کاملاً حذف می‌شود (نه فقط خود تگ)
const DROP_WITH_CONTENT = new Set(["SCRIPT", "STYLE", "IFRAME", "OBJECT", "EMBED", "NOSCRIPT", "TEMPLATE", "SVG", "MATH"]);
const SAFE_HREF = /^(https?:|mailto:|\/(?!\/)|#)/i;

function cleanNode(node, doc) {
  for (const child of Array.from(node.childNodes)) {
    if (child.nodeType === 3) continue; // متن
    if (child.nodeType !== 1) { child.remove(); continue; } // کامنت و ...
    const tag = child.tagName.toUpperCase();
    if (DROP_WITH_CONTENT.has(tag)) { child.remove(); continue; }
    cleanNode(child, doc); // اول فرزندان پاک می‌شوند
    if (!ALLOWED_TAGS.has(tag)) {
      // تگ غیرمجاز: خودش حذف و متن/فرزندان پاک‌شده‌اش حفظ می‌شود
      while (child.firstChild) node.insertBefore(child.firstChild, child);
      child.remove();
      continue;
    }
    for (const attr of Array.from(child.attributes)) {
      const name = attr.name.toLowerCase();
      const keep = tag === "A" && (name === "href" || name === "target" || name === "rel");
      if (!keep) child.removeAttribute(attr.name);
    }
    if (tag === "A") {
      const href = (child.getAttribute("href") || "").replace(/[\u0000- ]/g, "");
      if (href && !SAFE_HREF.test(href)) child.removeAttribute("href");
      child.setAttribute("rel", "noopener noreferrer");
      child.setAttribute("target", "_blank");
    }
  }
}

export function sanitizeHtml(html) {
  if (!html) return "";
  if (typeof DOMParser === "undefined") {
    // محیط بدون DOM: امن‌ترین حالت، متن escape‌شده
    return String(html).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  const doc = new DOMParser().parseFromString(`<body>${String(html)}</body>`, "text/html");
  cleanNode(doc.body, doc);
  return doc.body.innerHTML;
}

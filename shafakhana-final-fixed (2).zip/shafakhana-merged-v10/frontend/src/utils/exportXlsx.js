// خروجی Excel (.xlsx) برای همه‌ی بخش‌های داشبورد — جایگزین پکیج آسیب‌پذیر «xlsx» (SheetJS).
// ورودی: آرایه‌ی شیت‌ها؛ هر شیت { name, rows } است و rows آرایه‌ای از آبجکت‌هاست
// (کلیدهای اولین سطر به‌عنوان عنوان ستون‌ها استفاده می‌شوند، مثل json_to_sheet قبلی).
// کتابخانه فقط هنگام کلیک روی «خروجی Excel» بارگذاری می‌شود (dynamic import).

// نام شیت در Excel حداکثر ۳۱ کاراکتر است و نباید شامل  []:*?/\  باشد
function safeSheetName(name, index) {
  const cleaned = String(name || `Sheet${index + 1}`).replace(/[[\]:*?/\\]/g, " ").trim().slice(0, 31);
  return cleaned || `Sheet${index + 1}`;
}

function toCell(value) {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number" && Number.isFinite(value)) return { type: Number, value };
  if (typeof value === "boolean") return { type: Boolean, value };
  return { type: String, value: String(value) };
}

function buildSheet(sheet, index) {
  const rows = Array.isArray(sheet.rows) ? sheet.rows : [];
  const headers = rows.length ? Object.keys(rows[0]) : [];
  const headerRow = headers.map((h) => ({ type: String, value: h, fontWeight: "bold" }));
  const body = rows.map((row) => headers.map((h) => toCell(row[h])));
  const data = headers.length ? [headerRow, ...body] : [[null]];
  const columns = headers.map((h) => {
    const longest = Math.max(String(h).length, ...rows.map((r) => String(r[h] ?? "").length));
    return { width: Math.min(Math.max(longest + 2, 10), 50) };
  });
  return { data, sheet: safeSheetName(sheet.name, index), columns, rightToLeft: true };
}

export async function downloadXlsx(fileName, sheets) {
  const { default: writeExcelFile } = await import("write-excel-file/universal");
  const prepared = sheets.map(buildSheet);
  const blob = await (prepared.length === 1
    ? writeExcelFile(prepared[0].data, prepared[0])
    : writeExcelFile(prepared)
  ).toBlob();

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

import { describe, it, expect, vi, beforeEach } from "vitest";
import { apiRequest, authFetch, setCsrfToken, hasSessionHint, resolvePhotoUrl, SERVER_ORIGIN, SESSION_EXPIRED_EVENT, USER_KEY } from "./api.js";

// پاسخ ساختگی fetch
function jsonResponse(status, body) {
  return {
    ok: status >= 200 && status < 300,
    status,
    json: async () => body,
    clone() { return this; },
  };
}

let fetchMock;
beforeEach(() => {
  fetchMock = vi.fn();
  vi.stubGlobal("fetch", fetchMock);
  setCsrfToken(null);
});

describe("apiRequest — نشست و CSRF", () => {
  it("همیشه کوکی نشست را می‌فرستد (credentials: include)", async () => {
    fetchMock.mockResolvedValue(jsonResponse(200, { ok: true }));
    await apiRequest("/doctors");
    expect(fetchMock.mock.calls[0][1].credentials).toBe("include");
  });

  it("درخواست GET هدر CSRF نمی‌فرستد، حتی اگر توکن در حافظه باشد", async () => {
    setCsrfToken("tok-123");
    fetchMock.mockResolvedValue(jsonResponse(200, {}));
    await apiRequest("/doctors");
    expect(fetchMock.mock.calls[0][1].headers["X-CSRF-Token"]).toBeUndefined();
  });

  it.each(["POST", "PUT", "PATCH", "DELETE"])("درخواست %s هدر X-CSRF-Token می‌فرستد", async (method) => {
    setCsrfToken("tok-123");
    fetchMock.mockResolvedValue(jsonResponse(200, {}));
    await apiRequest("/x", { method, body: { a: 1 } });
    expect(fetchMock.mock.calls[0][1].headers["X-CSRF-Token"]).toBe("tok-123");
  });

  it("بدنه را JSON می‌کند و Content-Type می‌گذارد", async () => {
    fetchMock.mockResolvedValue(jsonResponse(200, {}));
    await apiRequest("/x", { method: "POST", body: { a: 1 } });
    const opts = fetchMock.mock.calls[0][1];
    expect(opts.body).toBe('{"a":1}');
    expect(opts.headers["Content-Type"]).toBe("application/json");
  });

  it("با CSRF_INVALID یک بار توکن تازه از /auth/me می‌گیرد و درخواست را تکرار می‌کند", async () => {
    setCsrfToken("old");
    fetchMock
      .mockResolvedValueOnce(jsonResponse(403, { code: "CSRF_INVALID", message: "x" })) // درخواست اول
      .mockResolvedValueOnce(jsonResponse(200, { csrfToken: "fresh" })) // /auth/me
      .mockResolvedValueOnce(jsonResponse(200, { saved: true })); // تکرار
    const data = await apiRequest("/x", { method: "POST", body: {} });
    expect(data).toEqual({ saved: true });
    expect(fetchMock).toHaveBeenCalledTimes(3);
    expect(fetchMock.mock.calls[1][0]).toMatch(/\/auth\/me$/);
    expect(fetchMock.mock.calls[2][1].headers["X-CSRF-Token"]).toBe("fresh");
  });

  it("حلقه‌ی بی‌پایان نمی‌سازد: اگر دوباره CSRF_INVALID بیاید، خطا می‌دهد", async () => {
    fetchMock
      .mockResolvedValueOnce(jsonResponse(403, { code: "CSRF_INVALID" }))
      .mockResolvedValueOnce(jsonResponse(200, { csrfToken: "fresh" }))
      .mockResolvedValueOnce(jsonResponse(403, { code: "CSRF_INVALID", message: "نامعتبر" }));
    await expect(apiRequest("/x", { method: "POST", body: {} })).rejects.toMatchObject({ status: 403 });
    expect(fetchMock).toHaveBeenCalledTimes(3);
  });
});

describe("apiRequest — خطاها و انقضای نشست", () => {
  it("خطا شامل status، code و پیام سرور است", async () => {
    fetchMock.mockResolvedValue(jsonResponse(400, { message: "ایمیل تکراری است", code: "DUP" }));
    await expect(apiRequest("/x", { method: "POST", body: {} })).rejects.toMatchObject({
      message: "ایمیل تکراری است",
      status: 400,
      code: "DUP",
    });
  });

  it("بدنه‌ی غیر JSON → پیام پیش‌فرض فارسی", async () => {
    fetchMock.mockResolvedValue({ ok: false, status: 500, json: async () => { throw new Error("no json"); }, clone() { return this; } });
    await expect(apiRequest("/x")).rejects.toThrow("خطایی در ارتباط با سرور رخ داد");
  });

  it.each(["SESSION_EXPIRED", "ACCOUNT_DISABLED", "SESSION_TERMINATED"])(
    "با کد %s نشست محلی پاک و رویداد انقضا پخش می‌شود",
    async (code) => {
      localStorage.setItem(USER_KEY, '{"id":1}');
      const spy = vi.fn();
      window.addEventListener(SESSION_EXPIRED_EVENT, spy);
      fetchMock.mockResolvedValue(jsonResponse(401, { code, message: "x" }));
      await expect(apiRequest("/auth/me")).rejects.toMatchObject({ status: 401 });
      expect(spy).toHaveBeenCalledTimes(1);
      expect(hasSessionHint()).toBe(false);
      window.removeEventListener(SESSION_EXPIRED_EVENT, spy);
    }
  );

  it("رمز اشتباه در فرم ورود (۴۰۱ بدون کد نشست) کاربر را بیرون نمی‌اندازد", async () => {
    localStorage.setItem(USER_KEY, '{"id":1}');
    const spy = vi.fn();
    window.addEventListener(SESSION_EXPIRED_EVENT, spy);
    fetchMock.mockResolvedValue(jsonResponse(401, { message: "ایمیل یا رمز عبور اشتباه است" }));
    await expect(apiRequest("/auth/login", { method: "POST", body: {} })).rejects.toThrow("ایمیل یا رمز عبور اشتباه است");
    expect(spy).not.toHaveBeenCalled();
    expect(hasSessionHint()).toBe(true);
    window.removeEventListener(SESSION_EXPIRED_EVENT, spy);
  });
});

describe("authFetch / resolvePhotoUrl", () => {
  it("هدرهای سفارشی را همراه هدر CSRF ادغام می‌کند", async () => {
    setCsrfToken("t");
    fetchMock.mockResolvedValue(jsonResponse(200, {}));
    await authFetch("http://x/y", { method: "POST", headers: { "X-Test": "1" } });
    expect(fetchMock.mock.calls[0][1].headers).toMatchObject({ "X-CSRF-Token": "t", "X-Test": "1" });
  });
  it("آدرس نسبی عکس را به آدرس کامل سرور تبدیل می‌کند", () => {
    expect(resolvePhotoUrl("/uploads/a.jpg")).toBe(`${SERVER_ORIGIN}/uploads/a.jpg`);
    expect(resolvePhotoUrl("https://cdn.x/a.jpg")).toBe("https://cdn.x/a.jpg");
    expect(resolvePhotoUrl("")).toBeNull();
    expect(resolvePhotoUrl(null)).toBeNull();
  });
});

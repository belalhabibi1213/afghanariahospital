// ============================================================================
// isScrollbarClick — آیا این mousedown روی «اسکرول‌بار» یک عنصر بوده است؟
// ----------------------------------------------------------------------------
// مرورگر برای کلیک/کشیدن روی اسکرول‌بار هم رویداد mousedown می‌فرستد و target آن خودِ
// عنصر اسکرول‌شونده (مثلاً بدنه‌ی مودال) است. منوها و پنل‌های بازشو که با «کلیک بیرون»
// بسته می‌شوند، این را «بیرون» حساب می‌کردند و وقتی کاربر اسکرول‌بار را می‌گرفت زود
// بسته می‌شدند. هر handler کلیک‌بیرون باید در ابتدا این تابع را چک کند.
// ============================================================================
export function isScrollbarClick(e) {
  const el = e && e.target;
  if (!el || el.nodeType !== 1 || typeof el.getBoundingClientRect !== "function") return false;
  // روی خود <html> اسکرول‌بار صفحه است
  if (el === document.documentElement) return e.clientX >= el.clientWidth || e.clientY >= el.clientHeight;
  const hasV = el.offsetWidth > el.clientWidth + el.clientLeft;
  const hasH = el.offsetHeight > el.clientHeight + el.clientTop;
  if (!hasV && !hasH) return false;
  const r = el.getBoundingClientRect();
  const x = e.clientX - r.left - el.clientLeft; // در RTL اسکرول‌بار سمت چپ است و داخل clientLeft حساب می‌شود
  const y = e.clientY - r.top - el.clientTop;
  const onV = hasV && (x < 0 || x >= el.clientWidth);
  const onH = hasH && y >= el.clientHeight;
  return onV || onH;
}

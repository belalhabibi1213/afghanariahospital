import { describe, it, expect } from "vitest";
import { sanitizeHtml } from "./sanitizeHtml";

describe("sanitizeHtml", () => {
  it("اسکریپت و event handler را حذف می‌کند", () => {
    const out = sanitizeHtml('<p onclick="x()">سلام</p><script>alert(1)</script><img src=x onerror=alert(1)>');
    expect(out).toBe("<p>سلام</p>");
  });
  it("iframe، svg و style را حذف می‌کند", () => {
    expect(sanitizeHtml('<iframe src="https://evil"></iframe><svg onload=alert(1)></svg><style>a{}</style>ok')).toBe("ok");
  });
  it("لینک javascript: را خنثی و rel/target امن می‌گذارد", () => {
    const out = sanitizeHtml('<a href="java\nscript:alert(1)">x</a><a href="https://a.com">y</a>');
    expect(out).not.toMatch(/javascript/i);
    expect(out).toContain('href="https://a.com"');
    expect(out).toContain('rel="noopener noreferrer"');
  });
  it("تگ‌های مجاز قالب‌بندی را نگه می‌دارد", () => {
    expect(sanitizeHtml("<h2>t</h2><ul><li><strong>a</strong></li></ul>")).toBe("<h2>t</h2><ul><li><strong>a</strong></li></ul>");
  });
  it("ورودی خالی رشته‌ی خالی می‌دهد", () => {
    expect(sanitizeHtml(null)).toBe("");
  });
});

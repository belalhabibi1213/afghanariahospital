// چند دارویی که داکتر در یک بار «ثبت نسخه» نوشته است، یک «نسخه»ی واحد هستند (groupId مشترک).
// این تابع لیست رکوردهای دارو را به نسخه‌ها تبدیل می‌کند: هر نسخه = اولین رکورد گروه + آرایه‌ی
// medicines شامل همه‌ی داروهای آن. نسخه‌های قدیمی بدون groupId هر کدام یک نسخه‌ی تک‌دارویی می‌مانند.
// ترتیب نسخه‌ها همان ترتیب لیست ورودی است (معمولاً جدیدترین اول).
export function groupPrescriptions(list = []) {
  const groups = [];
  const byKey = new Map();
  for (const pr of list) {
    const key = pr.groupId ? `${pr.groupId}|${pr.patientId}|${pr.doctorId ?? ""}` : `single-${pr.id}`;
    let members = byKey.get(key);
    if (!members) {
      members = [];
      byKey.set(key, members);
      groups.push(members);
    }
    members.push(pr);
  }
  return groups.map((members) => {
    const medicines = [...members].sort((a, b) => a.id - b.id);
    const base = { ...medicines[0] };
    // فیلدهای مشترک اگر در رکورد اول خالی بودند از اولین رکوردِ پرِ گروه برداشته می‌شوند
    for (const field of ["diagnosis", "instructions", "notes", "followUpDate"]) {
      if (!base[field]) base[field] = medicines.find((m) => m[field])?.[field] ?? base[field];
    }
    return { ...base, medicines };
  });
}

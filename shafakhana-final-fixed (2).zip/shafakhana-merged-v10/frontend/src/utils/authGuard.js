// نام رویداد سراسری برای درخواست ورود اجباری (مثلاً وقتی مهمان روی «گرفتن نوبت» کلیک می‌کند).
// LoginRequiredModal (مانت‌شده یک‌بار در App.jsx) به این رویداد گوش می‌دهد و مودال را باز می‌کند.
export const AUTH_REQUIRED_EVENT = "shafakhana:auth-required";

// اگر کاربر وارد نشده باشد، مودال «ورود الزامی است» را با پخش یک رویداد سراسری باز می‌کند
// و false برمی‌گرداند (یعنی ادامه‌ی عملیات مجاز نیست). اگر کاربر وارد شده باشد، true
// برمی‌گرداند و هیچ تغییری در رفتار قبلی ایجاد نمی‌شود.
export function ensureAuthenticated(isAuthenticated) {
  if (isAuthenticated) return true;
  window.dispatchEvent(new CustomEvent(AUTH_REQUIRED_EVENT));
  return false;
}

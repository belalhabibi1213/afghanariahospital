// اعتبارسنجی مشترک «نام: حروف دری، پشتو یا انگلیسی» (سمت فرانت‌اند) — برای فیلد نام کامل بیمار
// (Patient Full Name) در فرم‌های ثبت‌نام (Register.jsx)، ویرایش پروفایل (UserDashboard.jsx)،
// مدیریت بیماران پنل ادمین (AdminDashboard.jsx) و فورمه‌ی نوبت‌دهی (AppointmentSection.jsx).
// معادل سمت بک‌اند: backend/utils/persianName.js — این دو فایل باید همیشه هم‌خوان بمانند
// تا پیام خطای frontend/backend یکسان باشد. اعتبارسنجی نهایی و قطعی همیشه سمت سرور است؛
// این فایل فقط برای بازخورد سریع‌تر به کاربر است.

export const PERSIAN_NAME_REGEX =
  /^(?=.*[A-Za-z\u00C0-\u024F\u0621-\u063A\u0641-\u064A\u0671-\u06D3])[A-Za-z\u00C0-\u024F\u0621-\u063A\u0641-\u064A\u0671-\u06D3\u200c\s'.-]+$/;

export function isValidPersianName(value) {
  if (typeof value !== "string") return false;
  const trimmed = value.trim();
  if (!trimmed) return false;
  return PERSIAN_NAME_REGEX.test(trimmed);
}

export const PERSIAN_NAME_ERROR_MESSAGE =
  "نام باید فقط شامل حروف (دری، پشتو یا انگلیسی) و فاصله بین کلمات باشد (عدد و نمادهای دیگر مجاز نیست)";

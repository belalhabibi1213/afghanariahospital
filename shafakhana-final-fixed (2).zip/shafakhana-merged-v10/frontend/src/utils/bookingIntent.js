// «نیت نوبت‌گیری» — وقتی کاربر در صفحه‌ی جزئیات یک بخش روی «گرفتن وقت ملاقات» می‌زند، بخش (و در صورت
// کلیک روی یک داکتر، همان داکتر) اینجا نگه داشته می‌شود تا فرم نوبت‌دهی در صفحه‌ی اصلی (AppointmentSection)
// پس از رسیدن، مرحله‌ی «انتخاب بخش» را رد کند و مستقیم به مرحله‌ی «انتخاب داکتر» برود.
// چرا sessionStorage و نه فقط state مسیر؟ مهمان بعد از ورود/ثبت‌نام صفحه را از نو می‌سازد و state مسیر
// از بین می‌رود؛ این مقدار همان‌جا می‌ماند. ۳۰ دقیقه اعتبار دارد تا نیت کهنه بعداً ویزارد را نپراند.
const KEY = "shafakhana:booking-intent";
const TTL_MS = 30 * 60 * 1000;

export function saveBookingIntent({ department, doctorId = null }) {
  try {
    sessionStorage.setItem(KEY, JSON.stringify({ department: String(department || ""), doctorId: doctorId ? String(doctorId) : null, at: Date.now() }));
  } catch { /* حالت خصوصی/بدون ذخیره‌سازی: ویزارد همان مرحله‌ی اول را نشان می‌دهد */ }
}

export function readBookingIntent() {
  try {
    const raw = sessionStorage.getItem(KEY);
    if (!raw) return null;
    const v = JSON.parse(raw);
    if (!v || !v.department || Date.now() - Number(v.at) > TTL_MS) {
      sessionStorage.removeItem(KEY);
      return null;
    }
    return { department: v.department, doctorId: v.doctorId || null };
  } catch {
    return null;
  }
}

export function clearBookingIntent() {
  try { sessionStorage.removeItem(KEY); } catch { /* بی‌اثر */ }
}

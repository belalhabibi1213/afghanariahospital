import { getCurrentLang } from "../i18n/languages.js";

// یک لایه‌ی کوچک روی fetch برای مدیریت یکنواخت نشست و خطاها.
// نشست کاربر در یک کوکی httpOnly است (جاوااسکریپت آن را نمی‌بیند و در localStorage هم نیست)؛
// برای همین همه‌ی درخواست‌ها با credentials: "include" ارسال می‌شوند و درخواست‌های
// تغییردهنده (POST/PUT/PATCH/DELETE) هدر X-CSRF-Token هم می‌فرستند. توکن CSRF فقط در حافظه‌ی
// صفحه نگه‌داری می‌شود و بعد از ورود یا رفرش (از GET /auth/me) دوباره گرفته می‌شود.

// آدرس بک‌اند از متغیر محیطی Vite (VITE_API_BASE_URL) خوانده می‌شود تا هنگام deploy کردن
// فرانت‌اند روی یک دامنه/سرور واقعی، نیازی به تغییر کد نباشد — فقط .env ساخت (build) را تنظیم کنید.
// در نبود این متغیر (مثلاً توسعه محلی بدون .env)، همان آدرس پیش‌فرض قبلی استفاده می‌شود.
// پیش‌فرض توسعه: همان hostname که صفحه با آن باز شده (localhost یا 127.0.0.1) تا کوکی نشست
// «هم‌سایت» بماند؛ اگر صفحه با 127.0.0.1 و API با localhost باشد، مرورگر کوکی را نمی‌فرستد.
// مقدار ویژه‌ی VITE_SERVER_ORIGIN=same-origin یعنی فرانت و API از همان آدرسی سرو می‌شوند که صفحه از آن باز شده
// (استقرار تک‌سرویس، مثل Render: بک‌اند خودش فرانت را هم سرو می‌کند) → آدرس‌ها نسبی می‌شوند.
const ENV_ORIGIN = import.meta.env.VITE_SERVER_ORIGIN;
export const SERVER_ORIGIN = ENV_ORIGIN === "same-origin" ? "" : ENV_ORIGIN || `http://${window.location.hostname}:5000`;
export const API_BASE = import.meta.env.VITE_API_BASE_URL || `${SERVER_ORIGIN}/api`;

// پروفایل عمومی کاربر (بدون هیچ توکنی) برای نمایش سریع رابط بعد از رفرش در localStorage می‌ماند.
// وجود آن فقط «اشاره» است که شاید نشست فعالی هست؛ اعتبار واقعی نشست را همیشه سرور با کوکی می‌سنجد.
export const USER_KEY = "shafakhana_user";
// کلید قدیمیِ ذخیره‌ی JWT در localStorage؛ فقط برای پاک‌سازی نشست‌های قبل از این تغییر نگه داشته شده
export const LEGACY_TOKEN_KEY = "shafakhana_token";

export function hasSessionHint() {
  return !!localStorage.getItem(USER_KEY);
}

// ---------- توکن CSRF (فقط در حافظه) ----------
let csrfToken = null;
export function setCsrfToken(value) {
  csrfToken = value || null;
}

const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);
function csrfHeaders(method = "GET") {
  return csrfToken && !SAFE_METHODS.has(String(method).toUpperCase()) ? { "X-CSRF-Token": csrfToken } : {};
}

// اگر توکن CSRF در حافظه نباشد یا قدیمی شده باشد (مثلاً قبل از پایان بازیابی نشست)، سرور ۴۰۳ با
// کد CSRF_INVALID می‌دهد. یک بار توکن تازه از /auth/me گرفته می‌شود و همان درخواست دوباره می‌رود.
async function refreshCsrfToken() {
  try {
    const res = await fetch(`${API_BASE}/auth/me`, { credentials: "include" });
    if (!res.ok) return false;
    const data = await res.json();
    setCsrfToken(data.csrfToken);
    return !!data.csrfToken;
  } catch {
    return false;
  }
}

// fetch با credentials و هدر CSRF؛ برای جاهایی که از apiRequest استفاده نمی‌شود (مثلاً فرم‌ها و دانلود CSV)
export async function authFetch(url, options = {}) {
  const method = options.method || "GET";
  const send = () =>
    fetch(url, {
      ...options,
      credentials: "include",
      headers: { ...csrfHeaders(method), "Accept-Language": getCurrentLang(), ...(options.headers || {}) },
    });
  let res = await send();
  if (res.status === 403 && !SAFE_METHODS.has(method.toUpperCase())) {
    const data = await res.clone().json().catch(() => null);
    if (data && data.code === "CSRF_INVALID" && (await refreshCsrfToken())) res = await send();
  }
  return res;
}

// نام رویدادی که در سراسر برنامه پخش می‌شود تا AuthContext بفهمد نشست کاربر
// (به دلیل نامعتبر یا منقضی‌بودن توکن) باید پاک شود. از این طریق، هر درخواست API
// در هر صفحه‌ای از برنامه — نه فقط بارگذاری اولیه — می‌تواند خروج امن کاربر و
// هدایت به صفحه‌ی ورود را فعال کند.
export const SESSION_EXPIRED_EVENT = "shafakhana:session-expired";

// فعال می‌شود وقتی بک‌اند کد SESSION_EXPIRED (که فقط توسط requireAuth تنظیم می‌شود)،
// ACCOUNT_DISABLED (حساب کاربر توسط ادمین غیرفعال شده) یا SESSION_TERMINATED (Super Admin
// این نشست را از پنل «نشست‌ها و دستگاه‌ها» خاتمه داده) برگرداند؛ به این ترتیب با ۴۰۱/۴۰۳
// مسیرهای عمومی مثل ایمیل/رمز اشتباه در فرم ورود اشتباه گرفته نمی‌شود.
function handleUnauthorized(data) {
  if (data && (data.code === "SESSION_EXPIRED" || data.code === "ACCOUNT_DISABLED" || data.code === "SESSION_TERMINATED")) {
    localStorage.removeItem(LEGACY_TOKEN_KEY);
    localStorage.removeItem(USER_KEY);
    setCsrfToken(null);
    window.dispatchEvent(new CustomEvent(SESSION_EXPIRED_EVENT));
  }
}

export async function apiRequest(path, { method = "GET", body, headers = {} } = {}) {
  const res = await authFetch(`${API_BASE}${path}`, {
    method,
    headers: { "Content-Type": "application/json", ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });

  let data = null;
  try {
    data = await res.json();
  } catch (err) {
    data = null;
  }

  if (!res.ok) {
    if (res.status === 401 || res.status === 403) handleUnauthorized(data);
    const error = new Error((data && data.message) || "خطایی در ارتباط با سرور رخ داد");
    error.status = res.status;
    error.code = data && data.code;
    error.data = data;
    throw error;
  }

  return data;
}

// برای آپلود فایل (مثل عکس پروفایل) با FormData استفاده می‌شود.
// عمداً هدر Content-Type تنظیم نمی‌شود تا مرورگر خودش boundary صحیح multipart را بسازد.
export async function apiUpload(path, formData) {
  const res = await authFetch(`${API_BASE}${path}`, { method: "POST", body: formData });

  let data = null;
  try {
    data = await res.json();
  } catch (err) {
    data = null;
  }

  if (!res.ok) {
    if (res.status === 401 || res.status === 403) handleUnauthorized(data);
    const error = new Error((data && data.message) || "آپلود فایل ناموفق بود");
    error.status = res.status;
    error.data = data;
    throw error;
  }

  return data;
}

// مسیر نسبی ذخیره‌شده در دیتابیس (مثل /uploads/avatars/xxx.jpg) را به لینک کامل قابل نمایش تبدیل می‌کند
export function resolvePhotoUrl(photoUrl) {
  if (!photoUrl) return null;
  if (photoUrl.startsWith("http")) return photoUrl;
  return `${SERVER_ORIGIN}${photoUrl}`;
}

// دانلود یک فایل (مثل خروجی PDF/Excel گزارش‌ها) که نیاز به نشست (کوکی) دارد؛
// چون تگ <a href> یا window.open نمی‌توانند هدر سفارشی بفرستند، فایل را با fetch
// می‌گیرد و به‌صورت Blob دانلود می‌کند.
// اگر openInNewTab=true باشد، به‌جای دانلود اجباری، فایل (مثلاً PDF نسخه) در یک
// تب جدید باز می‌شود تا از نمایشگر PDF مرورگر برای «چاپ» هم بتوان استفاده کرد.
export async function apiDownload(path, fallbackFileName = "download", { openInNewTab = false, print = false } = {}) {
  const res = await authFetch(`${API_BASE}${path}`);

  if (!res.ok) {
    let data = null;
    try {
      data = await res.json();
    } catch (err) {
      data = null;
    }
    if (res.status === 401 || res.status === 403) handleUnauthorized(data);
    const error = new Error((data && data.message) || "دانلود فایل ناموفق بود");
    error.status = res.status;
    throw error;
  }

  const disposition = res.headers.get("Content-Disposition") || "";
  const match = disposition.match(/filename="?([^"]+)"?/);
  const fileName = match ? match[1] : fallbackFileName;

  const blob = await res.blob();
  const url = URL.createObjectURL(blob);

  // چاپ مستقیم: PDF در یک iframe مخفی بارگذاری می‌شود و دیالوگ چاپ مرورگر باز می‌شود
  // (بدون اینکه کاربر اول فایل را دانلود کند). اگر مرورگر اجازه‌ی چاپ از iframe را ندهد،
  // PDF در تب جدید باز می‌شود تا با Ctrl+P چاپ شود.
  if (print) {
    const iframe = document.createElement("iframe");
    iframe.setAttribute("aria-hidden", "true");
    iframe.style.cssText = "position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden;";
    const cleanup = () => {
      setTimeout(() => {
        iframe.remove();
        URL.revokeObjectURL(url);
      }, 60000);
    };
    iframe.onload = () => {
      setTimeout(() => {
        try {
          iframe.contentWindow.focus();
          iframe.contentWindow.print();
        } catch (err) {
          window.open(url, "_blank");
        }
        cleanup();
      }, 400);
    };
    iframe.src = url;
    document.body.appendChild(iframe);
    return;
  }

  if (openInNewTab) {
    window.open(url, "_blank");
    // آدرس Blob را کمی بعد آزاد می‌کنیم تا تب تازه‌بازشده فرصت بارگذاری فایل را داشته باشد
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return;
  }

  const link = document.createElement("a");
  link.href = url;
  link.download = fileName;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

// دریافت یک فایل تصویری خصوصی (مثل امضای دیجیتال داکتر) که نیاز به نشست (کوکی)
// دارد و برگرداندن یک Blob URL برای استفاده‌ی مستقیم در <img src>. برخلاف apiDownload
// هیچ دانلود/تب جدیدی باز نمی‌کند — فقط برای پیش‌نمایش درون همان صفحه است.
// اگر فایلی وجود نداشته باشد (۴۰۴)، به‌جای throw کردن null برمی‌گرداند تا کامپوننت‌ها
// بتوانند به‌سادگی «هنوز آپلود نشده» را نمایش دهند.
export async function apiFetchImageUrl(path) {
  const res = await authFetch(`${API_BASE}${path}`);

  if (!res.ok) {
    if (res.status === 404) return null;
    let data = null;
    try {
      data = await res.json();
    } catch (err) {
      data = null;
    }
    if (res.status === 401 || res.status === 403) handleUnauthorized(data);
    const error = new Error((data && data.message) || "دریافت فایل ناموفق بود");
    error.status = res.status;
    throw error;
  }

  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

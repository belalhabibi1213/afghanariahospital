import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
  // تست‌های واحد/کامپوننت (Vitest + Testing Library) — اجرا: npm test
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: ["./src/test/setup.js"],
    include: ["src/**/*.test.{js,jsx}"],
    css: false,
    restoreMocks: true,
  },
  build: {
    rollupOptions: {
      output: {
        // کتابخانه‌های ثابت (React، React Router) در یک chunk جدا از کد خودِ پروژه قرار
        // می‌گیرند؛ چون این کتابخانه‌ها به‌ندرت تغییر می‌کنند، مرورگر می‌تواند این chunk را
        // بین دیپلوی‌های بعدی از کش استفاده کند و فقط کد تغییریافته‌ی پروژه را دوباره دانلود کند.
        manualChunks: {
          "react-vendor": ["react", "react-dom", "react-router-dom"],
        },
      },
    },
  },
});

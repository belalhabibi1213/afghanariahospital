// تنظیمات ESLint (flat config) برای فرانت‌اند — اجرا: npm run lint
// عمداً فقط قواعدی فعال‌اند که باگ واقعی پیدا می‌کنند (متغیر تعریف‌نشده، هوک‌های اشتباه، import بی‌استفاده)،
// نه قواعد سلیقه‌ای؛ تا بدون دست‌زدن به منطق برنامه قابل استفاده باشد.
import js from "@eslint/js";
import globals from "globals";
import react from "eslint-plugin-react";
import reactHooks from "eslint-plugin-react-hooks";

export default [
  { ignores: ["dist/**", "node_modules/**", "public/**"] },
  js.configs.recommended,
  { linterOptions: { reportUnusedDisableDirectives: "off" } },
  {
    files: ["**/*.{js,jsx}"],
    plugins: { react, "react-hooks": reactHooks },
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: { ...globals.browser },
      parserOptions: { ecmaFeatures: { jsx: true } },
    },
    settings: { react: { version: "18.3" } },
    rules: {
      // JSX: متغیرهایی که فقط در JSX استفاده می‌شوند (کامپوننت‌ها) «استفاده‌شده» حساب شوند
      "react/jsx-uses-vars": "error",
      "react/jsx-uses-react": "off",
      "react/jsx-key": "error",
      "react/jsx-no-duplicate-props": "error",
      "react/jsx-no-undef": "error",
      "react/jsx-no-target-blank": "error",
      "react/no-danger-with-children": "error",
      "react/no-direct-mutation-state": "error",
      "react/no-unknown-property": "error",
      "react/void-dom-elements-no-children": "error",
      // هوک‌ها
      "react-hooks/rules-of-hooks": "error",
      "react-hooks/exhaustive-deps": "warn",
      // عمومی
      "no-unused-vars": ["warn", { args: "none", ignoreRestSiblings: true, varsIgnorePattern: "^_", caughtErrors: "none" }],
      "no-empty": ["warn", { allowEmptyCatch: true }],
      "no-console": "off",
    },
  },
  {
    // تست‌هایی که فایل‌های پیکربندی (vercel.json و ...) را با Node می‌خوانند
    files: ["src/config/**/*.test.js"],
    languageOptions: { globals: { ...globals.node } },
  },
  {
    files: ["vite.config.js", "eslint.config.js"],
    languageOptions: { globals: { ...globals.node } },
  },
];

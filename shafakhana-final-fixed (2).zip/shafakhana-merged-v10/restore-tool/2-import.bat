@echo off
chcp 65001 >nul
cd /d "%~dp0"
set MYSQL=C:\xampp\mysql\bin\mysql.exe
if not exist "%MYSQL%" (echo mysql.exe در C:\xampp\mysql\bin پیدا نشد. مسیر XAMPP را در این فایل عوض کنید. & pause & exit /b 1)
if not exist restored.sql (echo اول 1-decrypt.bat را اجرا کنید. & pause & exit /b 1)
echo هشدار: دیتابیس shafakhana پاک و از restored.sql دوباره ساخته می‌شود.
echo MySQL باید در XAMPP روشن (Start) باشد.
pause
"%MYSQL%" -u root -e "DROP DATABASE IF EXISTS shafakhana; CREATE DATABASE shafakhana CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
if errorlevel 1 (echo خطا: به MySQL وصل نشد. اگر root رمز دارد، با من در میان بگذارید. & pause & exit /b 1)
"%MYSQL%" -u root --default-character-set=utf8mb4 shafakhana < restored.sql
if errorlevel 1 (echo خطا در import. & pause & exit /b 1)
echo.
echo تمام شد ✔ تعداد جدول‌ها:
"%MYSQL%" -u root -e "USE shafakhana; SHOW TABLES;" | find /c /v ""
pause

@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js نصب نیست. اول Node.js را نصب کنید: https://nodejs.org & pause & exit /b 1)
node decrypt.mjs
echo.
pause

import crypto from "crypto";
import fs from "fs";
import path from "path";
import readline from "readline";
import { fileURLToPath } from "url";

const dir = path.dirname(fileURLToPath(import.meta.url));
const encs = fs.readdirSync(dir).filter(f => f.toLowerCase().endsWith(".enc"))
  .map(f => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs })).sort((a, b) => b.t - a.t);
if (!encs.length) { console.error("\nERROR: هیچ فایل .enc در این پوشه نیست. فایل بکاپ (.sql.enc) را کنار این فایل‌ها بگذارید."); process.exit(1); }
const inFile = path.join(dir, encs[0].f);
console.log("فایل بکاپ:", encs[0].f);

let key = process.env.BACKUP_ENCRYPTION_KEY;
if (!key) {
  // سعی کن از فایل key.txt یا .env کنار این فایل بخوانی
  for (const name of ["key.txt", ".env"]) {
    const p = path.join(dir, name);
    if (fs.existsSync(p)) {
      const txt = fs.readFileSync(p, "utf8");
      const m = name === "key.txt" ? [null, txt.trim()] : txt.match(/^BACKUP_ENCRYPTION_KEY=(.*)$/m);
      if (m && m[1]) { key = m[1].trim().replace(/^["']|["']$/g, ""); console.log("کلید از", name, "خوانده شد"); break; }
    }
  }
}
if (!key) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  key = await new Promise(r => rl.question("BACKUP_ENCRYPTION_KEY را paste کنید و Enter بزنید: ", a => { rl.close(); r(a.trim()); }));
}

const MAGIC = Buffer.from("SFBK1\0", "latin1");
const buf = fs.readFileSync(inFile);
if (!buf.subarray(0, 6).equals(MAGIC)) { console.error("ERROR: این فایل رمزنگاری‌شده با قالب شفاخانه نیست."); process.exit(1); }
let off = 6;
const salt = buf.subarray(off, (off += 16));
const iv = buf.subarray(off, (off += 12));
const tag = buf.subarray(buf.length - 16);
const ct = buf.subarray(off, buf.length - 16);
try {
  const k = crypto.scryptSync(key, salt, 32, { N: 2 ** 15, r: 8, p: 1, maxmem: 128 * 1024 * 1024 });
  const d = crypto.createDecipheriv("aes-256-gcm", k, iv);
  d.setAAD(MAGIC); d.setAuthTag(tag);
  const out = path.join(dir, "restored.sql");
  fs.writeFileSync(out, Buffer.concat([d.update(ct), d.final()]));
  console.log("\nOK ✔ فایل ساخته شد: restored.sql");
} catch {
  console.error("\nERROR: رمزگشایی نشد. کلید اشتباه است یا فایل خراب است.");
  process.exit(1);
}
